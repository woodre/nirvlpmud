start(who,func,args) {
  mixed ret;

  shadow(who,1);
  call_other(who,func,args);
  destruct(this_object());
  return ret;
}
