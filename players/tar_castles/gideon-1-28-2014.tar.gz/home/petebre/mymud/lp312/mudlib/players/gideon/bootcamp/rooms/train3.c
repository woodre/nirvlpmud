inherit "room/room";
reset(arg) {
  object monster;
  if(arg) 
    return ;    
  set_light(1); 
    short_desc = "Combat Training";
  long_desc  =
 "This is near the end of the boot camps combat training course.\n"+
  "The course has begun to take its toll on you, although training is near over.\n"+
  "There is only two more combat instructors to fight to finish the entire\n"+
  "course.\n";
  items =
  ({
    "instructor",
   "The Combat Instructor stands tall and firm",
    "grass",
   "The grass is very green and freshly mowed",
  });
  dest_dir =
  ({ 
 "/players/gideon/bootcamp/rooms/train2.c", "west",
 "/players/gideon/bootcamp/rooms/train4.c", "east",
  });
  move_object(clone_object("/players/gideon/bootcamp/mobs/instructor2.c"), this_object());
}
