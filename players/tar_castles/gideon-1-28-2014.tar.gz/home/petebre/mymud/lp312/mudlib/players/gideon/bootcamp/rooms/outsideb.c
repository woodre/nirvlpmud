inherit "room/room";
reset(arg) {
  if(arg) 
    return ;    
  set_light(1); 
  short_desc = "Outside the Barracks"; 
  long_desc  =
  "A steel barracks has been built here.  It was built to house\n"+
  "the recruits of the boot camp. It is not very large at all, but\n"+
  "it seems rather sturdy.\n";

  items =
  ({
    "barracks",
    "The small, but very sturdy barracks",
    
  });
  dest_dir =
  ({ 
  "/players/gideon/bootcamp/rooms/barracks.c", "barracks",
  "/players/gideon/bootcamp/rooms/room1.c", "east",
  });
}
