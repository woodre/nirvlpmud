inherit "room/room";
reset(arg) {
  object monster;
  if(arg) 
    return ;    
  set_light(1); 
  short_desc = "Combat Training"; 
  long_desc  =
 "This area has been designed for combat exercises.\n"+
 "There is another Combat Instuctor here. The man seems\n"+
 "to be staring you down with a twisted grin on his face.\n"+
 "The field leads back to the west and further east.\n";

  items =
  ({
    "instructor",
    "The Combat Instructor has a wicked grin on his face",
    "field",
    "The field is covered in well kept grass",
  });

  dest_dir =
  ({ 
  "/players/gideon/bootcamp/rooms/train1.c", "west",
  "/players/gideon/bootcamp/rooms/train3.c", "east",
  });
  move_object(clone_object("/players/gideon/bootcamp/mobs/instructor2.c"), this_object());
}
