inherit "/room/room";
#include <ansi.h>

reset(arg)
{
::reset(arg);

if(arg) return;
        set_light(1);
        short_desc = "Boot Camp Cargo Net Obstacle";
        long_desc =
  "There is a huge cargo net here. The sun seems even hotter than before.\n"+
  "The cargo net strecthes high up into the air. Several other recruits\n"+
  "have already made thier way up and over to the other side.\n"+
  "There seems to be only one to to get passed this obstacle.\n";

items =

({
        "net",
        "The cargo net is well made and seems very sturdy",
       "obstacle",
        "The goal of this obstacle is to simply climb up the cargo net",
});
dest_dir =
({

});
}


init()
{
        ::init();
        
        add_action("climb", "climb");
}

climb(str)
{
        if(!str)
        {
                write("What would you like to climb up?\n");
                return 1;
        }
        
        if(str != "up net")
        {
                write("You cannot climb up that!\n");
                return 1;
        }
        
        if(str == "up net")
        {
            call_other(this_player(), "move_player","crawls under#players/gideon/bootcamp/rooms/entrance.c");
                say(this_player()->query_name()+" climbs up the cargo net.\n");
            call_other(this_player(), "add_exp", 1223);
            this_player()->add_money(1000);
                return 1;
        }
}
