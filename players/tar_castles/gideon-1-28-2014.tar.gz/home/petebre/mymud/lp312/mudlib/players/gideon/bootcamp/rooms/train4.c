inherit "room/room";
reset(arg) {
  object monster;
  if(arg) 
    return ;    
  set_light(1); 
    short_desc = "Combat Training";
  long_desc  =
 "This is the end of the boot camps combat training course.\n"+
  "The wind has calmed a bit and the suns heat begins to pick back up.\n"+
  "There is one more combat instructor to fight to finish this\n"+
  "course.\n";
  items =
  ({
    "instructor",
   "The Combat Instructor stands tall and firm",
    "grass",
   "The grass is very green and freshly mowed",
  });
  dest_dir =
  ({ 
 "/players/gideon/bootcamp/rooms/train3.c", "west",
 "/players/gideon/bootcamp/rooms/room1.c", "back",
  });
  move_object(clone_object("/players/gideon/bootcamp/mobs/instructor2.c"), this_object());
}
