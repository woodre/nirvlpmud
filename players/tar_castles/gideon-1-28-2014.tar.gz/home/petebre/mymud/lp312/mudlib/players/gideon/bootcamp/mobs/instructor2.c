inherit "/obj/monster";

object gold;

reset(arg){

 ::reset(arg);
  if (arg) return;

  set_name("instructor");
  set_alt_name("combat instructor");
  set_race("human");
  set_alias("combat_instructor");
  set_short("A Combat Instructor");
  set_long("The man standing before you appears ready for you to attack.\n"+
           "He is here to help cadets train in the ways battle.\n");
  set_level(2);
  set_ac(2);
  set_wc(2);
  set_hp(30);
  set_al(100);
  set_aggressive(0);
  set_chat_chance(7);
      load_chat("What are you waiting for? Lets get this over with!\n");
  set_dead_ob(this_object());

  move_object(clone_object("/players/gideon/bootcamp/obj/puniform.c"
),
      (this_object()));
  init_command("wear armor");

}

  monster_died(){
      tell_room(environment(),
          "You hear gold coins hitting the floor.\n");
  gold = clone_object("/obj/money.c");
  gold->set_money(500);
  move_object(gold, environment());
}
