static object owner;
int slevel;
string sname;
string srname;
string sshort;
string spre;

start(ob)
{
  owner=ob;
  sname = owner->query_name();
  srname = owner->query_real_name();
  slevel = owner->query_level();
  sshort = owner->short();
  spre = "";
  shadow (owner,1);
   add_action("slevel","slevel");
   add_action("slevel","slev");
   add_action("sname","sname");
   add_action("sshort","sshort");
   add_action("spre","spre");
   add_action("communicate","say");
   add_action("communicate","'",1);
  return this_object();
}

query_name(){ return sname; }
query_real_name(){ return srname; }
query_level(){ return slevel; }
short(){
  if (spre=="") return sshort;
  return "\b\b\b\b\b\b\b\b"+spre+" "+sshort;
}
id(str,lvl){ return str==lower_case(sname); }

sshort(arg) {
  string str;

  if(!arg) {
    write("sshort: " + sshort + "\n");
    return 1;
  }
  if (sscanf(arg,"%s",str)==1) {
    sshort=str;
    write("Shadow short: " + sshort + "\n");
    return 1;
  }
  write("usage: sshort  or  sshort <string>\n");
  return 1;
}

spre(arg) {
  string str;

  if(!arg) {
    write("spre cleared\n");
    return 1;
  }
  if (sscanf(arg,"%s",str)==1) {
    spre=str;
    write("Shadow short:       " + short() + "\n");
    return 1;
  }
  write("usage: spre  or  spre <string>\n");
  return 1;
}

sname(arg) {
  string str;
  string pre,rest;

  if(!arg) {
    write("sname: " + sname + "\n");
    return 1;
  }

  if (sscanf(arg,"%s",str)==1) {
    if ((sscanf(sshort,"%s"+sname+"%s",pre,rest)!=2)
      && (sscanf(owner->short(),"%s"+owner->query_name()+"%s",pre,rest)!=2))
        write("Neither short did not contain name and could not be fixed.\n");
    else   /* Fix short with new real name */
      sshort=pre+capitalize(str)+rest;
    sname=capitalize(str);
    srname=lower_case(str);

    write("Shadow name: " + sname + "\n");
    write("Shadow short: " + sshort + "\n");
    return 1;
  }
  write("Usage:  sname  or sname <string>\n");
  return 1;
}

slevel(arg) {
  int num;

  if(!arg) {
    write("slev: "+slevel+"\n");
    return 1;
  }
  if (sscanf(arg,"%d",num)==1) {
    spre="";
    slevel=num;
    write("Shadow level: " + slevel + "\n");
    return 1;
  }
  write("Usage:  slevel <int>  or  slevel\n");
  return 1;
}

drink_alcohol(str) { return 1; }

hit_player() {
  tell_room(environment(owner),"A hit bounces off of Jubal's armor.\n");
  return 0;
}

kill(str) {
   object ob;

   if (!str) {
      write("Kill what ?\n");
      return 1;
   }
   ob = present(lower_case(str), environment(this_player()));
   if (!ob) {
      write("No " + str + " here !\n");
      return 1;
   }
   if (!living(ob)) {
      write(str + " is not a living thing !\n");
      say(this_player()->query_name()+" tries foolishly to attack "+str+".\n");
      return 1;
   }
   if (ob == this_object()) {
      write("What ? Attack yourself ?\n");
      return 1;
   }
   if (this_player()->query_attack() == ob) {
      write("Yes, yes.\n");
      return 1;
   }  /* query_attack returns attacker_ob.  see living.c */
   /* If changed, just take out whole if :) */
   this_player()->attack_object(ob);
   return 1;
}


communicate(str) {
   string verb;
   string sayverb;
   string temp;
 
   verb = query_verb();
   if (str == 0)
      str = "";
   if (verb[0] == "'"[0])
      str = extract(verb, 1) + " " + str;
   if (str == "" || str == " ") {
      say(short()+"mumbles incoherently.");
      write("You mumble incoherently.");
      return 1;
   }
   sayverb=" say";
   if ((sscanf(str,"%s!",temp)==1)) sayverb=" exclaim";
   if ((sscanf(str,"%s?",temp)==1)) sayverb=" ask";
   say(query_name()+sayverb+"s: "+str+"\n");
   write("You"+sayverb+": "+str+"\n");
   return 1;
 }

