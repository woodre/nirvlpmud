object owner;

start(me) {
  owner=me;
  shadow(me,1);
  return this_object();
}

print_prompt() {
  write("Shadow prompt> ");
}
