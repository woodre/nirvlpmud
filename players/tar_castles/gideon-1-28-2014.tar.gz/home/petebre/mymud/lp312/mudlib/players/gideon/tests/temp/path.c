#define PATH "This could cost you your life"
#define FILE "none"

static object owner;

start(me) {
  owner=me;
  shadow(owner,1);
  return this_object();
}

query_path() { 
  if(this_player()==owner) return owner->query_path();
  return PATH;
}
query_file_name() {
  if(this_player()==owner) return owner->query_file_name();
  return FILE;
}
