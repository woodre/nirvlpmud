object owner;

start(me) {
  owner=me;
  shadow(owner,1);
  return this_object();
}

exit() { return 1; }
destructor() { return 1; }
/* later use function_exists too see if there is an ::init */
init() { return 1; }
