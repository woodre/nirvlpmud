inherit "room/room";
reset(arg) {
  if(arg) 
    return ;    
  set_light(1); 
  short_desc = "Recruit Barracks";
  long_desc  =
  "The barracks seems even smaller once inside.  There.\n"+
  "are other recruits in here; some are resting, while\n"+
  "others are eating their grub. This is the place all\n"+
  "recruits come after hard training.\n";

  items =
  ({
    "recruits",
    "The other recruits are spread out, eating or resting",
  });
  dest_dir =
  ({ 
    "/players/gideon/bootcamp/rooms/outsideb.c", "out",
  });
}
