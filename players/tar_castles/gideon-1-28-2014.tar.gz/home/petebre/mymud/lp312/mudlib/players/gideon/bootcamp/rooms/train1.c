inherit "room/room";
  object monster;
reset(arg) {
  if(arg) 
    return ;    
  set_light(1); 
    short_desc = "Combat Training";
  long_desc  =
 "The grass in the field well kept, there is a Combat Instructor here.\n"+
 "It's rather windy, cooling you from your progess getting to this point.\n"+
 "The instructor appears to be ready for your attack.\n";
  items =
  ({
    "instructor",
   "The Combat Instructor stands tall and firm",
    "grass",
   "The grass is very green and freshly mowed",
    "barracks",
    "The barracks is rather small and off to your west",
  });
  dest_dir =
  ({ 
 "/players/gideon/bootcamp/rooms/room1.c", "west",
 "/players/gideon/bootcamp/rooms/train11.c", "east",
  });
  move_object(clone_object("/players/gideon/bootcamp/mobs/instructor2.c"), this_object());
}
