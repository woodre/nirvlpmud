object carrier,listener;
string prepend;

start(to,from) {
  carrier=to;
  listener=from;
  prepend=carrier->query_real_name()+"* ";
  shadow(carrier,1);
  return this_object();
}

catch_tell(str) {
  if(listener) tell_object(listener,prepend+str);
  tell_object(carrier,str);
}
