#define ctpqn capitalize(this_player()->query_name())
#define ACTIONS ({"setenv","sset","reply","r"})

static object owner;
string sid,name,prompt;
string prompt1,prompt2;
string action;
string lasttell;

start(me) {
  owner=me;
  name=capitalize(owner->query_real_name());
  if(name!="Gideon") return report(name+" tried to wear your cloak.\n");
  sid=lower_case(name);
  prompt1="[";
  prompt2="]";
  shadow (owner,1);
  add_ACTIONS();
/*  does not stop trying to call command() when destructed..  :-(
  add_action("command","",1);
  add_action("communicate","say");
  add_action("communicate","'",1);
*/
  return this_object();
}

add_ACTIONS() {
  int i;

  for(i=0;i<sizeof(ACTIONS);i+=2)
    write("Adding action: "+ACTIONS[i+1]+" to function: "
          +add_action(ACTIONS[i],ACTIONS[i+1])+"\n");
  write("Actions added.\n");
}

remove_ACTIONS() {
  int i;

  return 1;  /* doesn't work */
  for(i=0;i<sizeof(ACTIONS);i+=2)
    write("Removing action: "+ACTIONS[i+1]+" returns: "
          +remove_action(ACTIONS[i+1])+"\n");
  return 1;
}

/* This is my personal protection against function calls */
mystatic(func,arg) {
  if(this_player()!=owner) {
    tell_object(owner,ctpqn+" attempted "+func+"("+arg+")\n");
    return 1;
  }
  tell_object(owner,"Allowing "+func+"("+arg+")\n");
  call_other(owner,func,arg);
  return 1;
}

/* protected */
clear_pretitle(arg) { return mystatic("clear_pretitle",arg); }
set_pretitle(arg) { return mystatic("set_pretitle",arg); }
set_level(arg) { return mystatic("set_level",arg); }
set_title(arg) { return mystatic("set_title",arg); }
set_align(arg) { return mystatic("set_align",arg); }
set_alignment(arg) { return mystatic("set_aligment",arg); }
set_str(arg) { return mystatic("set_str",arg); }
set_dex(arg) { return mystatic("set_dex",arg); }
set_con(arg) { return mystatic("set_con",arg); }
set_int(arg) { return mystatic("set_int",arg); }
set_quest(arg) { return mystatic("set_quest",arg); }

/* more protected -- little stuff */
set_guild_string(arg) { return mystatic("set_guild_string",arg); }
set_blind(arg) { return mystatic("set_blind",arg); }
set_edtitle(arg) { return mystatic("set_edtitle",arg); }
set_edalign(arg) { return mystatic("set_edalign",arg); }
clear_desc(arg) { return mystatic("clear_desc",arg); }
describe(arg) { return mystatic("describe",arg); }

/* catch all incoming for client mode */
catch_tell(str) {
  string tmp,who;

  if(str=="> ") str=do_prompt() /*+"> "*/ ;
  if(sscanf(str,"%s tells you: %s",who,tmp)==2)
    if(who==lasttell) str=who+" also tells you: "+tmp;
    else lasttell=who;
  tell_object(owner,str);
}

do_prompt() {
  if(prompt) return prompt+" ";
  return prompt1+owner->query_path()+prompt2+" ";
}

/* catch all outgoing for client mode (works on vr) */
/*
cmd_hook(act) {
write("Shadow command("+query_verb()+","+act+") by "+ctpqn+"\n");
  if(query_verb()=="#" && action) {
    return write(owner->command(action)+" steps to evaluate "+action+".\n");
  }
  if(act) action=query_verb()+" "+act;
  else action=query_verb();
  return owner->cmd_hook(act);
}
*/

/* catch all outgoing for client mode (doesn't work..)*/
command(act) {
write("Shadow command("+act+")\n");
  if(act=="#" && action)
    return write(owner->command(action)+" steps to evaluate "+action+".\n");
  action=act;
  return 0;
}





/* Serious protection of me.  desting, moving, quitting, etc. */
exit(arg) {
  tell_object(owner,"**I got EXIT(void)\n");
}

quit(arg) {
  if(this_player()!=owner && this_player()->query_real_name()!="jubal") {
    tell_object(owner,ctpqn+" attempted quit("+arg+")\n");
    return 1;
  }
  tell_object(owner,"Allowing quit("+arg+")\n");
  owner->quit(arg);
  return 1;
}

destructor(arg) {
  remove_ACTIONS();
  if(this_player() && owner && this_player()==owner)
    return write("**Allowing DESTRUCT("+arg+")\n");
  if(owner) {  /* for updates, there is no owner */
    tell_object(owner,"**I got DESTRUCT("+arg+")\n");
    if(this_player()) tell_object(owner,"**From "+ctpqn+"\n");
    tell_object(owner,"**KILLING DESTRUCT ATTEMPT\n");
  }
  if(this_player()) {
    tell_object(this_player(),"Jubal gives you a dirty look.\n");
    destruct(0); /* this is too late..  :-( */
  }
  return 1;
}


/* cloak utility functions */
static string keep;
reply() {
  if(!lasttell)
    return !notify_fail("No one has told you anything to reply to yet.\n");
  keep="tell "+lasttell+" ";
  write(keep);
  input_to("reply_to");
  return 1;
}

reply_to(str) {
  if(str!="") "players/jubal/shad/utils"->commandme(keep+str);
  write(do_prompt());  /* this is a "bug" in input_to.. can't catch the prompt,
                          so just print both */
}

report(arg) {
  object me;
  if(!(me=find_player("jubal"))) return;
  return tell_object(me,arg);
}

setenv(arg) {
  string what,val,rest;

  if(!arg) {
    write("prompt: "+do_prompt()+"\nsid: "+sid+"\n");
    if(lasttell) write("last tell: "+lasttell+"\n");
    return 0;
  }
  if(sscanf(arg,"%s %s",what,val)!=2)
    return write("Usage: set <what> <value>\n");
  if(what=="prompt") {
    prompt=val;
    if(sscanf(prompt,"%s`pwd`%s",prompt1,prompt2)==2) prompt=0;
  }
  if(what=="sid")  sid=val;
  return 0;
}

/* these are shadows of lfunctions as protection */
id(str,lvl){ return str==lower_case(sid); }

drink_alcohol(str) { return 1; }

hit_player() {
  tell_object(owner,"You cloak protects you from attack.\n");
  tell_room(environment(owner),"A hit bounces off of "+name+"'s armor.\n");
  return 0;
}

kill(str) {
   object ob;

   if (!str) {
      write("Kill what ?\n");
      return 1;
   }
   ob = present(lower_case(str), environment(this_player()));
   if (!ob) {
      write("No " + str + " here !\n");
      return 1;
   }
   if (!living(ob)) {
      write(str + " is not a living thing !\n");
      say(this_player()->query_name()+" tries foolishly to attack "+str+".\n");
      return 1;
   }
   if (ob == this_object()) {
      write("What ? Attack yourself ?\n");
      return 1;
   }
   if (this_player()->query_attack() == ob) {
      write("Yes, yes.\n");
      return 1;
   }  /* query_attack returns attacker_ob.  see living.c */
   /* If changed, just take out whole if :) */
   this_player()->attack_object(ob);
   return 1;
}

/*
communicate(str) {
   string verb;
   string sayverb;
   string temp;

   verb = query_verb();
   if (str == 0)
      str = "";
   if (verb[0] == "'"[0])
      str = extract(verb, 1) + " " + str;
   if (str == "" || str == " ") {
      say(short()+"mumbles incoherently.\n");
      write("You mumble incoherently.\n");
      return 1;
   }
   sayverb=" say";
   if ((sscanf(str,"%s!",temp)==1)) sayverb=" exclaim";
   if ((sscanf(str,"%s?",temp)==1)) sayverb=" ask";
   say(query_name()+sayverb+"s: "+str+"\n");
   write("You"+sayverb+": "+str+"\n");
   return 1;
 }

*/
