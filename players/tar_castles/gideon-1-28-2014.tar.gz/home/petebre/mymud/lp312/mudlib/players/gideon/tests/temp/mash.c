start(tp) {
  object ob;

  if(!(ob=find_object("obj/master")))
    return tell_object(tp,"Couldn't find master\n");
  return shadow(ob,1);
}

valid_exec() { return 1; }
query_allow_shadow(ob) { return 1; }
