object me;

start(tp) {
  object ob;

  if(!(ob=find_object("obj/simul_efun"))) {
    tell_object(tp,"Couldn't find simul_efun\n");
    destruct(this_object());
  }
  me=ob;
  return shadow(ob,1);
}

destruct(ob) {
  tell_object(me,this_player()->query_name()+" :: destruct("+ob+")\n");
  return ::destruct(ob);
}
