inherit "room/room";
  object monster;
reset(arg) {
  if(arg) 
    return ;    
  set_light(1); 
    short_desc = "Combat Training";
  long_desc  =
  "The field has brought you to another instructor. He stands ready\n"+
  "before you. There are other instructors you can see off in the distance.\n"+
  "The man here ready to train you seems young and an easy target.\n";
  items =
  ({
    "instructor",
   "The Combat Instructor stands tall and firm",
  });
  dest_dir =
  ({ 
 "/players/gideon/bootcamp/rooms/room1.c", "west",
 "/players/gideon/bootcamp/rooms/train2.c", "east",
  });
  move_object(clone_object("/players/gideon/bootcamp/mobs/instructor2.c"), this_object());
}
