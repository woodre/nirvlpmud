object owner;
object env;

start(me) {
  owner=me;
  env=environment(owner);
  if(!env) return 0;
  shadow(env,1);
  return this_object();
}

exit() {
  object me;

  if(!(me=find_player("gideon"))) return;
  if(me!=this_player()) return;
  if(previous_object()) {
    tell_object(previous_object(),
                "Gideon doesn't move, he has his seatbelt on.\n");
    tell_object(me,"**Aborted exit due to: "
                +previous_object()->query_name()+"\n");
  }
  destruct(0);
  return 1;
}
