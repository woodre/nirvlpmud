#define TP this_player()
#define SHORTS ({"Gideon loves Welch's Grape Soda (sparkling)", \
  "Gideon is too cool to be a woman (manly man)", \
  "Gideon is too sexy for this mud", \
  "Gideon is better than "+TP->query_name(), \
  "Gideon of the many titles", \
  "Have you sent a dollar to Gideon today? ($$$)",\
  "              -- gids", \
  "this_player()->query_real_name() { return \"gideon\"; } /"+"* me */", \
  "Your sensitive mind notices a gideoness in the fabric of space.", \
  TP->query_pretitle()+" Gideon "+TP->query_title()+" ("+ \
  TP->query_align_title()+")", \
  "\b\b\b\b\b\b\b[Gideon] ;)", \
  "Gideon says: Beep me if its not important!", \
  })


static object owner;
static int sz;

start(me) {
  owner=me;
  shadow (owner,1);
  sz=sizeof(SHORTS);
  return this_object();
}

short() { return SHORTS[random(sz)]; }

