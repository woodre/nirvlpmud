/* unfortunately you can't do this in a shadow in 3.1.2 -DR compat :( */
commandme(what) {
  command(what,this_player());
}
