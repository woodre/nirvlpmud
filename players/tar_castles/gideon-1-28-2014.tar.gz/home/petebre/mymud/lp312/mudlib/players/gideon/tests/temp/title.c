#define TP this_player()
#define TITLES ({"loves Welch's Grape Soda (sparkling)", \
  "is too cool to be a woman (manly man)", \
  "is too sexy for this mud", \
  "is better than "+TP->query_name(), \
  "of the many titles", \
  "\b\b\b\b\b\bHave you sent a dollar to Gideon today? ($$$)", \
  "\b\b\b\b\b\b              -- gids", \
  "\b\b\b\b\b\bthis_player()->query_real_name() { return \"gideon\"; }", \
"\b\b\b\b\b\bYour sensitive mind notices a gideoness in the fabric of space.", \
  "\b\b\b\b\b\b"+TP->query_pretitle()+" Gideon "+TP->query_title()+" ("+ \
  TP->query_align_title()+")", \
  "\b\b\b\b\b\b\b\b\b\b\b\b\b[Gideon] ;)", \
  "says: Beep me if its not important!", \
  })


static object owner;
static int sz;

start(me) {
  owner=me;
  shadow (owner,1);
  sz=sizeof(TITLES);
  return this_object();
}

title() { return TITLES[random(sz)]; }
