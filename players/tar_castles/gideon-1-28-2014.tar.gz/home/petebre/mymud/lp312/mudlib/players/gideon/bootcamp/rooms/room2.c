inherit "/room/room";
#include <ansi.h>

reset(arg)
{
::reset(arg);

if(arg) return;
        set_light(1);
        short_desc = "Boot Camp Rope Swing Obstacle";
        long_desc =
  "You're standing before the begining of the boot camps\n"+
  "first obstacle in the course. It seems rather simple, there\n"+
  "is a rope tied to a high beem. Maybe if you were to try you\n"+
  "could swing across to the other side.\n";

items =

({
        "rope",
        "The rope is tied to a high beam, maybe you should swing on it",
        "obstacle",
        "A long rope tied to a high beam, maybe you should try to swing across",
});

dest_dir =
({

});
}


init()
{
        ::init();
        
        add_action("swing", "swing");
}

swing(str)
{
        if(!str)
        {
                write("What would you like to swing on?\n");
                return 1;
        }
        
        if(str != "on rope")
        {
                write("You cannot swing on that!\n");
                return 1;
        }
        
        if(str == "on rope")
        {
            call_other(this_player(), "move_player","swings away#players/gideon/bootcamp/rooms/room3.c");
                say(this_player()->query_name()+" swings away on the rope.\n");
            call_other(this_player(), "add_exp", 523);
            this_player()->add_money(500);
                return 1;
        }
}
