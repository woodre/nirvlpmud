inherit "/obj/monster";

object gold;

reset(arg){

 ::reset(arg);
  if (arg) return;

  set_name("drill instructor");
  set_alt_name("instructor");
  set_race("human");
  set_alias("drill_instructor");
  set_short("A grizzly old Drill Instructor");
  set_long("This old yet hard man stands tall before you.\n"+
           "He appears to be no novice when it comes to battle.\n");
  set_level(25);
  set_ac(45);
  set_wc(45);
  set_hp(500);
  set_al(100);
  set_aggressive(0);
  set_chat_chance(3);
      load_chat("Drill Instructor says: Welcome to HELL puke face!\n");
  set_dead_ob(this_object());

  move_object(clone_object("/players/gideon/bootcamp/obj/item1.c"
),
      (this_object()));
  init_command("wear armor");

}

  monster_died(){
      tell_room(environment(),
          "You hear gold coins hitting the floor.\n");
  gold = clone_object("/obj/money.c");
  gold->set_money(1500);
  move_object(gold, environment());
}
