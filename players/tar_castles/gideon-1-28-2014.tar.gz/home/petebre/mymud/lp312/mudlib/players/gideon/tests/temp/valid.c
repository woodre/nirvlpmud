static object owner;

start(me) {
  owner=me;
  shadow(owner,1);
  if(me->query_real_name()!="gideon") return 0;
  return this_object();
}

valid_write(str) {
  return extract(owner->mk_path(str),1);
}

valid_read(str) {
  return extract(owner->mk_path(str),1);
}
