start(me) {
  shadow(me,1);
  return this_object();
}

init() { ::init(); return 1; }
