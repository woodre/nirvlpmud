inherit "room/room";

string *rifle, *uniform;

reset(arg) {

  if( (sizeof(rifle) + sizeof(uniform)) > 0)
  {
    if(arg) return 0;
  }
  else
  {

    rifle = ({ });
    uniform = ({ });  

    if(arg) 
      return ;    
    set_light(1); 
    short_desc = "The Entrance to Boot Camp"; 
    long_desc  =
      "This room is where all new recruits hoping to be trained \n"+
      "in the ways of war come. There is a rack with uniforms \n"+
      "hanging near by. There is also a stand with starter \n"+
"rifles off in the room. Uniforms and rifles are here \n"+
"to grab before heading out.\n";

    items =
    ({
      "rack",
      "A standard rack with a number of military uniforms hanging on it",
      "uniforms",
      "These are the uniforms issued to new recruits",
      "rifles",
      "These rifles are issued to all new recruits",
      "stand",
      "The stand is covered is basic rifles, given to new recruits",
    });

    dest_dir =
    ({ 
    "/players/gideon/bootcamp/rooms/room1.c", "north",
    });
 
     move_object(clone_object("/players/gideon/bootcamp/mobs/drill.c"), this_object());
  }
}
    query_no_fight(){ return 1; }

init()
{
  ::init();

  add_action("Cmd_grab", "grab");
}

Cmd_grab(str)
{
  if(!str)
  { 
    notify_fail("What would you like to grab?\n");
    return 0;
  }
  if(str != "rifle" && str != "uniform")
  {
    notify_fail("You can only grab a 'rifle' or a 'uniform'.\n");
    return 0;
  }
 
  if(str == "rifle")
  {
    if(member_array(this_player()->query_real_name(), rifle) > -1)
    {
      write("You have already received a rifle today.\n");
      return 1;
    }
    write("You grab a new rifle from the stand.\n");
    say(capitalize(this_player()->query_real_name())+" grabs a rifle off the stand.\n");

    rifle += this_player()->query_real_name();

move_object(clone_object("/players/gideon/bootcamp/obj/rifle1.c"), this_player());

    return 1;
  }
  if(str == "uniform")
  {
    if(member_array(this_player()->query_real_name(), uniform) > -1)
    {
      write("You have already received a uniform today.\n");
      return 1;
    }
    write("You grab a uniform from the rack.\n");
    say(capitalize(this_player()->query_real_name())+" grabs a uniform from the rack.\n");
  
    uniform += this_player()->query_real_name();
  
move_object(clone_object("/players/gideon/bootcamp/obj/puniform.c"), this_player());

    return 1;
  }
}
    
  
