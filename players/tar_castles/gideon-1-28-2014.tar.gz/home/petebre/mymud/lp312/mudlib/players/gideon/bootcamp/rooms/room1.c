inherit "room/room";
reset(arg) {
  if(arg) 
    return ;    
  set_light(1); 
  short_desc = "Boot Camp"; 
  long_desc  =
 "This is a large training ground. The wind blows hard across your face.\n"+
  "There are several obstacle courses in the distance, as well as\n"+
  "several combat instructors to the east. There is a sign here.\n"+
 "To the west you see a small barracks.\n";

  items =
  ({
    "obstacles",
    "They appear to be standard training obstacles",
    "sign",
    "It is recommended to begin with the obstacle courses\n"+
    "to the north, then move on to the instructors to the east\n"+ 
    "for your combat training.\n",
    "barracks",
    "The barracks is rather small and off to your west",
  });
  dest_dir =
  ({ 
  "/players/gideon/bootcamp/rooms/entrance.c", "back",
  "/players/gideon/bootcamp/rooms/train1.c", "east",
  "/players/gideon/bootcamp/rooms/outsideb.c", "west",
  "/players/gideon/bootcamp/rooms/room2.c", "north",
  });
}
