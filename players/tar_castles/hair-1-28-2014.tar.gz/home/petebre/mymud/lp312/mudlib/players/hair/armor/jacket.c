inherit "obj/armor";
