inherit "room/room";

reset(arg) {

if(!arg) {

set_light(1);
short_desc="short";
long_desc=
"long description";

items=({

});

dest_dir=({

});

}}


init() {
  ::init();
   add_action("fcn","cmd");
}
