inherit "room/room";

reset(arg){

if(!arg) {

  set_light(1);
short_desc="City Limits";
long_desc=
"You are now on the outskirts of the city. City Hall and the County Jail\n"+
"are a couple of blocks south. Cooter's Garage is around the corner to the\n"+
"east. The speed limit here is 10 MPH, and Roscoe P. Cotrain will try to\n"+
"arrest you for WALKING too fast. So Beware.\n";

items=({
  "sign","Try reading it\n",
});   

dest_dir=({
  "/players/hair/rooms/path2.c","north",
  "/players/hair/rooms/city1.c","south",
  "/players/hair/rooms/wmain1.c","west",
  "/players/hair/rooms/emain1.c","east",
  });
}
}
init() {
  ::init();
  add_action("read_sign","read");
}
read_sign() {
  write("\n\n				WELCOME TO THE CITY\n\n"+
	"				Population 	500\n\n");
  say(this_player()->query_name() +" reads the sign.\n");
  return 1;
}
