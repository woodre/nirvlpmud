inherit "/obj/monster.c";

reset(arg) {
::reset(arg);

if(!arg) {

set_name("Luke");
set_alias("luke");
set_short("Luke Duke");
set_long("Luke Duke.\n"+
	"Just a Good 'ol boy never meaning no harm.  One of those country\n"+
	"boys.  One renegade of Hazzard County.");

move_object(clone_object("/players/hair/armor/flannel.c"),this_object());
init_command("wear shirt");

set_level(15);
set_hp(200);
set_wc(20);
set_ac(10);
set_al(500);
set_aggressive(0);
set_chat_chance(10);
set_a_chat_chance(15);
load_chat("Luke asks: You wanna go for a ride in the General Lee?\n");
load_chat("Luke says: I know that you want my cousin Daisy.\n");
load_chat("You hear Daisy Dukes' voice over the CB radio.\n");
load_chat("Luke says: C'mon Bo, Daisy needs us.");
load_a_chat("Luke punches you in the eye. OUCH!\n");
}
}
