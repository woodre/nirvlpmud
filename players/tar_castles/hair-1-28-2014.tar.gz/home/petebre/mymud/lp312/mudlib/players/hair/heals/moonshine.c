
int swigs, price;

id(str) { return str == "moonshine" || str == "moonshine" || str == "bottle"; }

reset(arg) {

  if(!arg) swigs = 12;
    price = swigs * 400;

}

long() {
       write("This is a bottle of Uncle Jessie's finest moonshine.\n"+
             "There are ["+swigs+"] swigs left.\n\n"+
	     "Usage: swig moonshine\n\n");}

short() {
  return "Uncle Jessie's Bottle of Moonshine [" + swigs + "]";}

query_save_flag() { return 1; }

query_value() { return price; }

init() {
    add_action("swig"); add_verb("swig");
}

swig(arg){
  object tp;
  tp = this_player();
  if(!arg || arg != "moonshine"){
    return 0;}

else {
  if(!tp->eat_food(12)){
       return 1;}

else{
  if(arg == "moonshine"){
  swigs=swigs - 1;
  tp->heal_self(random(15)+35);
  write("You take a swig. WHEW! There are ["+swigs+"] swigs left in Uncle\n"+
	"Jessie's Bottle of Moonshine.\n");
        say(capitalize(tp->query_name()) + " swigs the moonshine.\n");

if(swigs == 0){
	destruct(this_object());
	write("You take the last swig and break the bottle over your head.\n");
	tp->add_weight(-1);}
	return 1;}
        }
}}

get() { return 1; }

query_weight() { return 1;}
