/*Monster created to show damage done.*/
 
inherit "/obj/monster";
 
int thp,rcount;
 
reset(arg) {
   ::reset(arg);
   if (!arg) {
 
     set_name("testmonster");
     set_short("A test monster");
     set_race("monster");
     set_alias("test");
     set_long(
"A monster that shows damage done. 'testattack <monster>'to start it.\n");
     set_level(1);
     set_ac(0);
     set_wc(0);
     set_hp(2000);
     set_heal(0,100);
     set_al(0);
     set_aggressive(0);
thp = 2000;
rcount = 1;
   }
}
 
init() {
  ::init();
    if(this_player()->query_level() > 21) {
add_action("mon_attack","testattack");
    }
}
 
mon_attack(arg) {
  object meat;
  string name,meatname,moname;
meat = present(arg,environment(this_object()));
name = capitalize(this_player()->query_real_name());
meatname = capitalize(arg);
moname = this_object()->query_real_name();
  if(!meat) { say(meatname+" is not here!\n"); return 1; }
  if(living(meat)) {
call_other(meat,"attack_object",this_object());
  } 
test_show();
return 1;
}
 
test_show() {
  int chp,diff,average;
chp = this_object()->query_hp();
diff = ( thp - chp );
average = ( (2000 - chp) / rcount );
call_out("test_show",1);
  say(
"TESTMONSTER HP: <"+chp+"> DAMAGE DONE: <"+diff+"> AVERAGE DAMAGE: <"+average+">\n");
thp = chp;
rcount = ( rcount + 1 );
return 1;
}
