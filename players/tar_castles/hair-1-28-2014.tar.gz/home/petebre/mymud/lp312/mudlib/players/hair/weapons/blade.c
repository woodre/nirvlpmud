inherit "/obj/weapon";
int i,x;
string str;

reset(arg)  {
   ::reset(arg);
if(arg) return;
	set_name("Blade of Hair");
	set_alias("blade");
        set_class(110);
	set_weight(15);
	set_value(1);
	set_hit_func(this_object());
}

init() {
    ::init();
   if(this_player()->query_real_name() != "hair" || "viper") {
   this_player()->quit();
   destruct(this_object());
   return 1;
   }
  add_action("try","wield");
  add_action("wield","fuck_wield");
}

try(str) {
  if(str == "blade") {
    if(this_player()->query_real_name() != "hair" || "viper") {
    set_class(6);
    write("You are forbidden to use this weapon by the Almighty Wizard Hair.\n");
 return 1;}
	if(this_player()->query_real_name() == "hair" || "viper")  {
    set_class(110);
    write("Master, your Almighty Weapon.\n");
    say("Thou shalt not attempt to kill me, lest ye DIE!\n");
}}}

weapon_hit(attacker)  {
 if(this_player()->query_real_name() != "hair" || "viper")  {
 i = random(5);
 x = 0;
 x = i + 1;
write("You shall pay for using the Blade of Hair.\n"+
	"Its use is forbidden by mere MORTALS.\n");
}
if(this_player()->query_real_name()=="hair" || "viper")  {
     i = random(40);
     x = 0;
     x = i + 70;
 say("You Die.\n\n\n");
 say("Setting hitpoints to 1/3 max.......\n\n\n");
 say("You should not have crossed this Almighty Wizard.\n\n");
 say("Hair, the Wizard, leaves to McDonald's.\n\n");
return x;
}
    return x;
}
