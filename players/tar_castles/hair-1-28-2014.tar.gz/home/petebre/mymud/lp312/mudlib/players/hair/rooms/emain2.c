inherit "room/room";
 
reset(arg) {
 
if(!arg) {
 
set_light(1);
short_desc="200 Block of East Main Street";
long_desc=
"This is the 200 Block of East Main Street. To the north, you see the town\n"+
"bar. There are a lot of rowdy country boys in there, maybe you shouldn't\n"+
"visit the bar. Then again, where else are you gonna get drunk if not\n"+ 
"here with all of the local drunks. The road continues on to the east,\n"+
"leading towards the outskirts of town.\n\n"+
"There is also a portal here, you can try to 'enter' it.\n";
 
items=({
     "bar","It is a nice bar, but there are a lot of country boys in there",
});
 
dest_dir=({
     "/players/hair/rooms/bar.c","north",
	"/players/hair/rooms/dirt1.c","south",
     "/players/hair/rooms/emain1.c","west",
});
 
}}
 
init() {
  ::init();
  add_action("enter_portal","enter");
}
 
enter_portal() {
 call_other(this_player(),"move_player","enter#players/hair/rooms/knight1.c");
 write("You get a strange feeling as you are vaporized into the portal.\n");
 say(this_player()->query_name() +" is vaporized as they enter the portal.\n");
}

