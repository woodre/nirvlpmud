inherit "/obj/monster";

reset(arg) {
::reset(arg);
if (!arg) {
set_name("Becky");
set_alias("becky");
set_short("Becky");
set_long("Becky Marinier is 5 feet 5 inches tall, with brown hair,\n"+
	"blue eyes, and an incredible body.  You wish that you could\n"+
	"have her, but you know she is too good for you.\n");
set_level(69);
set_wc(69);
set_ac(15);
set_hp(10000);
set_al(-500);
set_aggressive(0);
set_chat_chance(10);
set_a_chat_chance(20);
money = (69000);
	}
}
