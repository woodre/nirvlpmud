i
 /* A Garbage collector
  This monster will roam around the mud, picking up objects that are:
  1. Light enough for the monster to pick up.
  2. Objects such as flyers or tablets or such that a wizard
     placed in the church to get more popularity.
 
  This monster will _NOT_ pick up objects that are:
  1. Corpses, dispensers, banks, clocks, trashcans, signs,
     computers, notices, boards, lists or monsters.
 
 */
 
inherit "/obj/monster";
#define CAN "/players/pathfinder/trashcan.c"
 
reset(arg)
{
  ::reset(arg);
  if(arg) return 0;
  set_name("garbageman");
  set_alias("garbage man");
  set_short("A garbageman");
  set_long(
   "You peer at the garbage man.  He stinks from picking up all the\n" +
   "garbage the people of nirvana, including you, have left about to\n" +
   "to be cleaned up.  He has various things on him.  Some might be\n" +
   "worth killing him for.\n");
  set_wc(16);
  set_ac(5);
  set_hp(100 + random(100));
  set_al(100);
  set_ep(50000);
  enable_commands();
  call_out("random_movement", 5);  /* make him try to move every 5 seconds */
}
 
 /*
  This is the function that is called to make the monster move randomly
  and also calls a function to see if there is anything to be
  picked up or excluded from being picked up
 */
 
random_movement() {
  int i, j, k;
  string dir;
 
  call_out("random_movement", 5);
 
  if(present("trashcan", environment(this_object()))) {
    trash_all();
  }
 
  i = random(11);
  if(i == 0) dir = "north";
  if(i == 1) dir = "south";
  if(i == 2) dir = "east";
  if(i == 3) dir = "west";
  if(i == 4) dir = "northeast";
  if(i == 5) dir = "northwest";
  if(i == 6) dir = "southeast";
  if(i == 7) dir = "southwest";
  if(i == 8) dir = "up";
  if(i == 9) dir = "down";
  if(i == 10) dir = "leave";
  command(dir);
 
  pick_up_things();
return 1;
}
 
trash_all() {
  object items;
  string name;
  int i;
items = all_inventory(this_object());
  for(i = 0; i < sizeof(items); i++) {
    name = items[i]->query_short();
    say("You see the garbageman open the lid of the trashcan and throw\n");
    say(name + " into the trash.\n");
    destruct(items[i]);
  }
return 1;
}
 
pick_up_things() {
  object ob;
  int i;
ob = first_inventory(environment(this_object()));
say("ATTEMPT PICK UP\n");
  while(ob) {
    if(!living(ob) &&
       !is_player(ob) &&
       !(ob->query_ip_num()) &&
       !(ob->query_name() == "computer") &&
       !(ob->id() == "computer") &&
       !(ob->query_name() =="notice") &&
       !(ob->id() == "notice") &&
       !(ob->query_name() == "list") &&
       !(ob->id() == "list") &&
       !(ob->query_name() == "trashcan") &&
       !(ob->id() == "trashcan") &&
       !(ob->query_name() == "sign") &&
       !(ob->id() == "sign") &&
       !(ob->query_name() == "bank") &&
       !(ob->id() == "bank") &&
       !(ob->query_name() == "corpse") &&
       !(ob->id() == "corpse") &&
       !(ob->query_name() == "castle") &&
       !(ob->id() == "castle") &&
       !(ob->query_name() == "board") &&
       !(ob->id() == "board") &&
       !(ob->query_get() == 1) ) {
         say("The garbage man carefully picks up a " + ob->short() + ".\n");
         move_object(ob, this_object());
        ob = next_inventory(ob);
       }
else
      ob = next_inventory(ob);
  }
  return 1;
}
 
