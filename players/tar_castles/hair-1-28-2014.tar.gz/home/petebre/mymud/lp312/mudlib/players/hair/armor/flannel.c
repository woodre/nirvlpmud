inherit "obj/armor";

reset(arg){
   ::reset(arg);

   set_name("Flannel Shirt");
   set_short("A Flannel Shirt");
   set_alias("shirt");
   set_long("A flannel shirt.\n"+
	    "Maybe if you wear it, you would fit in around here.\n");
   set_type("cloak");

   /* options for set_type() are...boots, armor, helmet, shield, ring,*
    * amulet, glove, cloak, and misc. 				      */

   set_ac(1);
   set_weight(1);
   set_value(2500);
}
