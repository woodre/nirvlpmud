inherit "room/room";

reset(arg){

if(!arg) {

  set_light(1);
short_desc="Dirt Road through Hazzard County";
long_desc=
"You are on the road that continues into Hazzard County. You hear sirens and\n"+
"what appears to be a carchase in the background. There is an old abandoned\n"+
"shack to the west. Maybe you should check it out.\n";


dest_dir=({
  "/players/hair/rooms/path1.c","north",
  "/players/hair/rooms/path3.c","south",
  "/players/hair/rooms/shack.c","shack",
  });
}
}
