inherit "/obj/monster";

reset(arg) {
 ::reset(arg)

 if(!arg) {

  set_name("name");
  set_alias("alias");
  set_short("short");
  set_long("long");
  move_object(clone_object("/players/hair/armors/filename.c"),this_object());
  move_object(clone_object("/players/hair/weapons/filename.c"),this_object());
  init_command("wear armor");
  init_command("wield weapon");
  set_level(15);
  set_hp(350);
  set_wc(13);
  set_ac(4);
  set_al(500);
  set_aggressive(0); /* 1 -> Aggressive, 0 -> Non-aggressive */

   object gold;
  gold = clone_object("obj/money");
  gold->set_money(random(101) + 550);
  move_object(gold,this_object());

  set_chat_chance(10);
  set_a_chat_chance(10);
  load_chat("msg");
  load_a_chat("battle msg");
 }
}
