inherit "obj/monster";

reset(arg)
{
  object gold,armor,weapon;
  ::reset(arg);
  if(arg) return;
set_name("Gary Wayne Hopewell");
  set_race("");
  set_alias("gary");
set_short("McDonald's Employee");
set_long( "Gary Hopewell,M.P.\n");
set_level(15);
set_hp(433);
set_al(500);
set_money(69);
set_wc(15);
set_ac(1);
  set_chat_chance(2);
  load_chat("Hello there You FUCK. I am a Crew Chief.\n");
  load_chat("I am Gary Hopewell M.P.\n");
  move_object(gold,this_object());
}
