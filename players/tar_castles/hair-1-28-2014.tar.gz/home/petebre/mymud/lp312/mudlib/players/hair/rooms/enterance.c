inherit "room/room";

reset(arg){

if(!present("hair")) {
move_object(clone_object("/players/hair/monsters/hair2.c"),this_object());
}

if(!arg) {

set_light(1);
short_desc="Hazzard County Line";
long_desc=
"You have reached the edge of Hazzard County. This area is governed by a \n"+
"corrupt man in Boss Hogg. Take caution as you enter this area because\n"+
"Roscoe P. Cotrain and his dog Flash will try to lock you up. There is a\n"+
"road that leads of to the south. There is also an old wooden sign here with\n"+
"something written on it. Off to the east, you think that you see the\n"+
"outskirts of a city, but you cannot quite make out clearly what is there.\n"+
"The area to the east is not open yet. Please continue south.\n"+
"\n\nIf you have any problems with or suggestions for this area, mail Hair.\n";

items=({
   "sign","Maybe you should try to 'read' it",
   "road","It is a dirt road that leads deeper into Hazzard County",
});

dest_dir=({
   "/players/hair/rooms/dontknowyet","east",
   "/players/hair/rooms/path1.c","south",
});

  }
}

init()  {
  ::init();
  add_action("read_sign","read");
}

read_sign()  {
  write("You have entered the famous Hazzard County, the Castle of Hair.\n"+
	"You should proceed further only if you are brave enough, strong\n"+
	"enough, and smart enough to be able to escape unscathed.\n");
  say (this_player()->query_name() +" reads the sign.\n");
  return 1;
}
