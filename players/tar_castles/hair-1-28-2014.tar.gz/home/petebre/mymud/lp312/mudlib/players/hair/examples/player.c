inherit "obj/user/channel";
inherit "obj/user/cmd_hook";

#include "living.h"
#include "/obj/user/one_chan.c"
#include "/closed/handshake.h"
#include "/obj/quest_pt.c"
#include "/obj/prego.c"
#include "/obj/access.c"

#define SAVE_INTERVAL 600 /* How many seconds between auto-saves? */

static int is_interactive;
object myself, soul;
string wkrm,hostname;
string ok_edit; /* name of other wiz's files that can be edited, must be set by editing player file.*/
string mailaddr;
string saved_where;
string title;		/* Our official title. Wiz's can change it. */
string pretitle;
string password;	/* This players crypted password. */
static string password2;
string race;
string al_title;
int intoxicated;	/* How many intervals to stay intoxicated. */
string fight_area;
int phys_at,headache, max_headache;
string called_from_ip;	/* IP number used last time */
/* now declared in /obj/quest_pt.c
string quests;		 list of all solved quests */
string msghome;         /* wizard home string */
static int power;
string description;     /* players definable description */
string guild_name;
string lastime;  /*last login time */
int player_killing; /* can attack/be attacked by other players */
int invs_count;  /* count until visible agian */
int invs_flag;  /* are we invisible??? (players only) */
int new_pl_rest; /* extra restore not needed for new players for money clone */
int muffled;
int treasure;		/* amount of treasure carried by player */
string pwd;
int dead;
int guild_rank, guild_exp;
string guild_file;
string home;            /* players residence, if any */
int ex_lv;       /* extra levels for players to advance to */
static int save_level;
int strength, intelligence, stamina, will_power, magic_aptitude, piety, stealth;
static string it;		/* Last thing referenced. */

int stuffed;		/* How many ticks to stay stuffed */
int soaked;		/* How many ticks to stay soaked */
int no_give; /* STOP MONEY CLONEING #3 */
add_stuffed(i)
{
    if(i < 0)
    {
	if (-i > stuffed / 10)
		i = -stuffed / 10;
    }
    stuffed += i;
    if (stuffed < 0)
	stuffed = 0;
}

add_soaked(i)
{
    if(i < 0)
    {
	if (-i > soaked / 10)
		i = -soaked / 10;
    }
    soaked += i;
    if (soaked < 0)
	soaked = 0;
}


query_stuffed()
{
    return stuffed;
}

query_soaked()
{
    return soaked;
}

drink_soft(strength)
{
	if (soaked + strength > level * 8)
	{
		write("You can't possibly drink that much right now!\n" + 
			"You feel crosslegged enough as it is.\n");
		return 0;
	}

	soaked += strength * 2;

	if (soaked < 0)
		soaked = 0;

	if (soaked == 0)
		write("You feel a bit dry in the mouth.\n");

	return 1;
}

eat_food(strength)
{
int jun;
	if (stuffed + strength > level * 8)
	{
		write("This is much too rich for you right now! Perhaps something lighter?\n");
		return 0;
	}

	stuffed += strength * 2;
       if(stuffed > level*8 && random(100) < 15) {
         write("You really shouldn't eat so much.\n");
         add_phys_at(3,random(5));
         return 1;
     }

	if (stuffed < 0)
		stuffed = 0;

	if (stuffed == 0)
		write("Your stomach makes a rumbling sound.\n");

	return 1;
}

query_msgin() { return msgin; }
query_msgout() { return msgout; }
query_mmsgin() { return mmsgin; }
query_mmsgout() { return mmsgout; }

/* logon() is called when the players logs on. */

static logon() {
    enable_commands();
    if (query_ip_number() == "192.41.245.16" || query_ip_number() == "192.41.245.15") {
    write("You will not be able to log in from the annex if you are using an adm5\n"+
    "terminal. You will not get beyond the Password: prompt. Try using an \n"+
    "account on a computer such as one of the vaxs to log in.\n");
    }
    write("\n");
/*
    write("Welcome to Nirvana IV (An lpmud version 3.0.44-DR)\n");
*/
     cat ("/WELCOME");
    write("\n");
    write("There are currently "+sizeof(users())+ " players logged in.\n");
    write("Please use the guest name if you just want a look.\n\n");
    phys_at=allocate(6);
    write("What is your name: ");
    sethost();
    input_to("logon2");
    call_out("timeout", 60);
    return 1;
}
shoutin () {
    int lvl,invs;
    string nom,wi;
 lvl = this_player()->query_level();
 nom = capitalize(this_player()->query_name());
 invs = this_player()->query_invis();
   if(level > EXPLORE || invs > 18) return 1;
   if(lvl > 9999) {wi = "God";lvl = 0;}
   if(lvl > 19 && lvl < 9999) {wi = "Wizard";lvl = 0;}
   if(lvl > 0) {
    chan_msg(nom + " ( player " +lvl+ " ) has entered the game.\n","msg");
     return 1;}
   else chan_msg(nom + " ( " + wi + " ) has entered the game.\n","msg");
     return 1;
}
shoutout() {
    int lvl;
    string nom,wi;
 lvl = this_player()->query_level();
 nom = capitalize(this_player()->query_name());
   if(lvl > 9999) {wi = "God";level = 0;}
   if(lvl > 19 && lvl < 9999) {wi = "Wizard";level = 0;}
   if(lvl > 0) {
    chan_msg(nom+ " ( player " +lvl+ " ) has left the game.\n","msg");
     return 1; }
    else chan_msg(nom + " ( "+wi+" ) has left the game.\n","msg");
     return 1;
}
static timeout() {
	write("\nTimeout\n");
	destruct(this_object());
}

object other_copy;

static try_throw_out(str) {
    object ob;
   string blah1,blah,tmp_name;
     object check_copy;
      remove_call_out("timeout");
    if (str == "" || (str[0] != 'y' && str[0] != 'Y')) {
	write("Come back another time then!\n");
see_if_other(1);
	destruct(this_object());
	return;
    }
    tmp_name = name;
    name = 0;
    check_copy = find_player(tmp_name);
    if (!check_copy)
	check_copy = find_player("ghost of " + tmp_name);
    name = tmp_name;
    if (!check_copy) {
   write("Something has gone wrong, please try agian...\n");
   log_file("BAD_PLAYER", ctime(time()) + " " + name + " money cloning method #2\n");
     see_if_other(1);
     destruct(this_object());
     return;
    }
    ob = first_inventory(other_copy);
    while (ob) {
	int wa_flag,weight;
	object next_ob;
	weight = call_other(ob, "query_weight");
       sscanf(file_name(ob), "%s#%s", blah,blah1);
	next_ob = next_inventory(ob);
	/*
	 * Don't move the soul.
	 */
 if(ob->armor_class() || ob->weapon_class()) {
/*
    call_other(ob, "drop", call_other(ob, "id", 0));
*/
    blah1=ob->query_name();
    wa_flag = 2;
    ob->drop(blah1);
     write(blah1);
  }
        if(wa_flag && !present(blah1,other_copy) && !present(blah1,environment(other_copy)))
          ob=clone_object(blah);
        if(call_other(ob, "id","soul") || ob->id("GI")) {
	    destruct(ob);
	} else if (add_weight(weight)) {
	    move_object(ob, this_player());
	}
        wa_flag = 0;
	ob = next_ob;
    }
    ob = environment(other_copy);
    call_other(other_copy, "quit");
    if (restore_object("players/" + name))
	write("Points restored from the other object.\n");
    else
	destruct(other_copy);	/* Is this really needed? */
    other_copy = 0;
    sethost();
    move_player_to_start(ob);
    log_file("ENTER", " (throw)\n");
}

static logon2(str) {
    string ajunk,bjunk;
    remove_call_out("timeout");
    call_out("timeout", 120);
    if (!str || str == "") {
	destruct(this_object());
	return;
    }
    if (name != "logon") {
        illegal_patch("logon2");
	destruct(this_object());
	return;
    }
    str = lower_case(str);
    if (!valid_name(str)) {
	input_to("logon2");
	write("Give name again: ");
	return;
    }
    if (restore_object("banish/" + str)) {
	write("That name is reserved.\n");
	destruct(this_object());
	return;
    }
    if (restore_object("players/inactive_saved/"+str)) {
          write("Your player file is no longer active.\n"+
                "write petebre@elof.iit.edu to be returned to active status.\n");
          destruct(this_object());
          return;
  }
    if (!restore_object("players/" + str)) {
	write("New character.\n");
new_pl_rest = 1;
    if (new_pl_rest) ResetStats();
    }
    if(level > 999) {
      if(sscanf(query_ip_number(), "%s92.41.245%s",ajunk,bjunk) !=2) 
     {
        if(str != "sandman" || sscanf(query_ip_number(), "%s98.64.57.2%s",ajunk,bjunk) !=2) {
         write("God access not allowed from your address.\n");
         destruct(this_object());
       }
      }
       }
    /*
     * Don't do this before the restore !
     */
    name = str;			/* Must be here for a new player. */
  see_if_other(2);
    dead = ghost;
    myself = this_player();
    soul = 0;
    if (query_invis(0) >= SOMEONE)
	cap_name = "Someone";
    else
	cap_name = capitalize(name);
    if (level < EXPLORE)
        call_out("autosave", SAVE_INTERVAL);
    call_out("autoheal", INTERVAL_BETWEEN_HEALING);

    sethost();
    local_weight = 0;
    armor_class = 0;
    name_of_weapon = 0;
    weapon_class = WEAPON_CLASS_OF_HANDS;
    /* If this is a new character, we call the adventurers guild to get
     * our first title !
     */
    if (level == -1)
        write(
"Pick a password that is at least six characters long.\n" +
"\n");
    write("Password: ");
    if (name == "guest")
{
	write("(just CR) ");
  }
    if (level != -1)
	input_to("check_password", 1);
    else 
	input_to("new_password", 1);
    attacker_ob = 0;
    alt_attacker_ob = 0;
     save_level = level;
    level = 0;
    return;
}

/* Called by command 'save' */
save_character() {
    save_me();
    write("Ok.\n");
    return 1;
}

/* This makes sure the amount we claim to be carrying is correct. */
recalc_carry() {
    object ob, next_ob;

    local_weight = 0;
    if (myself)
    ob = first_inventory(myself);
    while (ob) {
	next_ob = next_inventory(ob);
	local_weight += call_other(ob, "query_weight");
	ob = next_ob;
    }
}

reset(arg) {
  if (!arg)
     channel_names = ({"gossip","msg","risque","shout",});
    max_spell = 42 + ex_lv*3 + level * 8 + (magic_aptitude - 8) * 8;
    fight_area = 0;
    if (max_spell < 0) max_spell = 0;
    max_hp = ex_lv*2 + 42 + level * 8 + (stamina - 8) * 8;
   if (max_hp < 5) max_hp = 5;
   if (hit_point > max_hp) hit_point = max_hp;
   if (name){
   if (head_armor==capitalize(name)) head_armor =0;
   }
    if (!quest_point) 
      recalc_quest();
    if (arg) {
	if (level >= EXPLORE) return;
	/* These occasionally get screwed up.  Don't ask me why. */
	if (name == NAME_OF_GHOST) {
	    ghost = 1;
	    msgin = "drifts around";
	    msgout = "blows";
	} else {
	    ghost = 0;
	    dead = 0;
	    msgin = "arrives";
	    msgout = "leaves";
	}
	recalc_carry();	    /* Make sure we're carrying the right amount. */
	return;
    }
    /*
     * With arg = 0 this function should only be entered once!
     */
    if (myself)
        return;
    if (creator(this_object())) {
        illegal_patch("cloned player.c");
	destruct(this_object());
	return;
    }
    set_heart_beat(1);
    level = -1;
    name = "logon";
    cap_name = "Logon";
    msgin = "arrives"; msgout = "leaves";
    mmsgin = "arrives in a puff of smoke";
    mmsgout = "disappears in a puff of smoke";
    msghome = "goes home";
    title = "the title-less";
    al_title = "neutral";
    treasure = 0;
    gender = 0;
}

query_spell_point() {
    return spell_points;
}

short() {
   object pt_ob;
   string pt_nom;
    string Junk;
    string st_desc;
    int i;
    pt_nom = 0;
    
    pt_ob = present("party object", this_object());
    if (pt_ob)
         pt_nom = call_other(pt_ob, "extra_short", 0);
    i = query_invis();
    if (this_player())
        i = query_invis(call_other(this_player(),"query_level"));
    if (i < 0)
	{
		Junk = pretitle + " " + capitalize(name)+" "+title+" ("+al_title+") ("+query_invis()+")";
if  (!pretitle)
   Junk = capitalize(name) + " " + title + " ("+al_title+") ("+query_invis()+")";
		if (!is_interactive) Junk = Junk + " (disconnected)";
if (pt_ob) Junk = Junk + pt_nom;
		return Junk;
 }
    if (i >= NO_SHORT)
        return 0;
    if (ghost)
	return "ghost of " + cap_name + (is_interactive ? "" : " (disconnected)");
    if (frog)
    {
	 st_desc = cap_name + " the frog" + " (" + al_title + ")" + (is_interactive ? "" : " (disconnected)");
  if (pt_ob)
     st_desc = st_desc + pt_nom;
  return st_desc;
 }
  if (!pretitle)
   {
    st_desc = cap_name + " " + title + " (" + al_title + ")" + (is_interactive ? "": " (disconnected)");
    if (pt_ob)
        st_desc = st_desc + pt_nom;
    return st_desc;
   }
    st_desc = pretitle + " " + cap_name + " " + title + " (" + al_title + ")" + (is_interactive ? "" : " (disconnected)");
    if (pt_ob)
     st_desc = st_desc + pt_nom;
   return st_desc;
}

long() {
    int ptime;
    if(this_player()->query_level() < 20 && this_player()!=this_object()) {
     tell_object(this_object(), capitalize(this_player()->query_name())+" looks at you.\n");
     say(capitalize(this_player()->query_name())+" looks at "+cap_name+".\n");
     }
    if(this_player()->query_level() < 20 && this_player()==this_object()) {
     say(cap_name+" looks at "+query_objective()+"self in a reflection.\n");
     }
    write(short() + " (" + gender + ")" + ".\n");
    if (call_other(this_player(),"query_level") >= EXPLORE) {
        if (level >= GOD) {
	    write("==> god\n");
        } else if (level >= ELDER) {
	    write("==> elder wizard\n");
        } else if (level >= SENIOR) {
	    write ("==> senior wizard\n");
        } else if (level > EXPLORE) {
	    write("==> wizard\n");
        } else if (level == EXPLORE) {
	    write("==> apprentice wizard\n");
	}
    }
     if(description) write(cap_name + " "+description+"\n");
    write(cap_name+" is a "+race+", "+phys_at[1]+" feet "+phys_at[2]+" inches tall and "+phys_at[3]+" lbs.\n");
    if(pregnancy) {
         ptime=age-pregnancy;
       if(ptime > 3000 && ptime < 5001) write(cap_name+" looks about 2 to 3 months pregnant.\n");
         if(ptime > 5000 && ptime < 7200) write(cap_name+" looks about 4 months pregnant.\n");
         if(ptime > 7199 && ptime < 9000) write(cap_name+" looks about 5 months pregnant.\n");
         if(ptime > 8999 && ptime < 10800) write(cap_name+" looks about 6 months pregnant.\n");
          if(ptime > 10799 && ptime < 12700) write(cap_name+" looks about 7 months pregnant.\n");
          if(ptime > 12699 && ptime < 14400) write(cap_name+" looks about 8 months pregnant.\n");
          if(ptime > 14399 && ptime < 16300) write(cap_name+" looks about 9 months pregnant.\n");
          }
   if (player_killing) write(cap_name + " can fight other players.\n");
    if (ghost || frog)
	return;
    if (hit_point < max_hp/10) {
	write(cap_name + " is in very bad shape.\n");
	return;
    }
    if (hit_point < max_hp/5) {
	write(cap_name + " is in bad shape.\n");
	return;
    }
    if (hit_point < max_hp/2) {
	write(cap_name + " is somewhat hurt.\n");
	return;
    }
    if (hit_point < max_hp - 20) {
	write(cap_name + " is slightly hurt.\n");
	return;
    }
    write(cap_name + " is in good shape.\n");
}

go_north() {
    command("north");
    invs_counter();
    return 1;
}

go_south() {
    command("south");

   invs_counter();
    return 1;
}

go_east() {
    command("east");
    invs_counter();
    return 1;
}

go_west() {
    command("west");
    invs_counter();
    return 1;
}

go_northwest() {
    command("northwest");
     invs_counter();
    return 1;
}

go_northeast() {
    command("northeast");
    return 1;
}

go_southwest() {
    command("southwest");
    return 1;
}

go_southeast() {
    command("southeast");
    return 1;
}

go_up() {
    command("up");
    return 1;
}

go_down() {
    command("down");
    return 1;
}

old_score() {
    int intox_level;
     string tmp;
    
    if (ghost) {
	write("You are in an immaterial state with no scores.\n");
	return 1;
    }
    write("You have " + experience + " experience points, " +
	  money + " gold coins,\n");
    write(hit_point + " hit points (of " + max_hp + "), and ");
    write(spell_points + " spell points (of " + max_spell + ").\nYou are " + short() + " (level " + level + ").\n");
    if (hunter && call_other(hunter, "query_name"))
        write("You are hunted by " + call_other(hunter, "query_name") + ".\n");
    if (!intoxicated)
	write("You are sober.\n");
    else {
	intox_level = (level + 4) / intoxicated;
	if (intox_level == 0)
	    write("You are in a drunken stupor.\n");
	else if (intox_level == 1)
            write("You are roaring drunk.\n");
	else if (intox_level == 2)
	    write("You are somewhat drunk.\n");
	else if (intox_level == 3)
	    write("You are quite tipsy.\n");
	else
	    write("You are slightly tipsy.\n");
    }
    if (stuffed || soaked)
    {
	tmp = "You are ";

        if (stuffed)
	{
	    tmp += "satiated";

	    if (soaked)
		tmp += " and ";
	    else
		tmp += ".\n";
	}

	if (soaked)
	    tmp += "not thirsty.\n";

	write(tmp);
    }

    if (whimpy)
	write("Wimpy mode.\n");
    show_age(); write("\n");
    return 1;
}

/* Identify ourself. */
id(str) {
    int i;

    i = query_invis();
    if (this_player())
        i = query_invis(call_other(this_player(),"query_level"));
    if (i < 0 && str == name)
        return 1;
    if (i >= NO_ID)
        return 0;
/*
    if (ghost)
	return str == "ghost of " + name;
*/
     if (ghost && str == "ghost of " + name)
          return 1;
    if (str == name)
	return 1;
    return 0;
}


query_title() {
    return title;
}
query_pretitle() {
     return pretitle;
}
set_pretitle(str) {
   if (!str) return 0;
   if (str == "|") {
    pretitle = 0;
    return 1;
    }
    pretitle = extract(str, 0, 60);
    return 1;
}

set_level(lev) {
    if (lev > CREATE || lev < level && level >= EXPLORE)
        return illegal_patch("set_level");      /* NOPE ! */
    level = lev;
    max_hp = ex_lv*2 + 42 + level * 8 + (stamina - 8)*8;
    if (max_hp < 5) max_hp = 5;
    max_spell = 42 + ex_lv*3 + level * 8 + (magic_aptitude - 8)*8;
    if (max_spell < 0)  max_spell = 0;
    if (hit_point > max_hp) hit_point = max_hp;
    if (spell_points > max_spell) spell_points = max_spell;
    if (level >= EXPLORE) {
        tell_object(myself, "Adding wizard commands...\n");
	soul("on");
    }
    if (level >= EXPLORE && soul)
        call_other(soul,"update",1);
    log_file("ADVANCE",ctime(time()) + " " +cap_name+" advanced to level "+level+"\n");
    save_me();
}

destruct_inventory() {
    object next_ob,ob;

    ob = first_inventory(this_object());
    while(ob) {
	next_ob = next_inventory(ob);
if (!call_other(ob, "id", "soul") && !call_other(ob,"id","wiz_soul"))
	destruct(ob);
	ob = next_ob;
    }
}

set_title(t) {
    if (!t) {
	write("Your title is " + title + ".\n");
	return 1;
    }
    title = t;
    return 1;
}

set_wiz_level(key){
    string lev;
    int new_level;

    if (!interactive(this_player())) {
        write("Sorry, but you are not a player.\n");
        return 0;
    }
    lev = call_other(call_other(this_player(), "query_soul"),
	"get_handshake",key);
    if (lev) sscanf(lev,"%d",new_level);
    level = new_level;
    tell_object(myself,"You were promoted to level " + lev + " by " +

        capitalize(call_other(this_player(),"query_real_name")) + ".\n");
    tell_object(myself,"Remember to read the help files to determine your new abilities.\n");
    log_file("PROMOTIONS",capitalize(name) + " was promoted to level " + lev +
        " by " + capitalize(call_other(this_player(),"query_real_name")) +
	".\n");
    soul("off");
    save_me();
    soul = 0;
    soul("on");
    return 1;
}

do_quit() {
  if (file_size("/players/" + this_player()->query_real_name() +
    "/logout") < 1) 
    return quit();
  write("Do you wish to execute your logout file(y/N)? ");
  input_to("do_quit2");
  return 1;
}

do_quit2(str) {
  if (lower_case(str) == "y")
    soul->run_command_file("/players/" + this_object()->query_real_name() +
      "/logout", "quit");
  return quit();
}

quit() {
    power = 0;
    if (level < EXPLORE)
	drop_all(1);
    save_me();
    destruct_inventory();
    if (level >= EXPLORE) write("Inventory destructed.\n");
    write("Saving "); write(capitalize(name)); write(".\n");
    checked_say(cap_name + " left the game.\n");
/*
    log_file("ENTER", ctime(time()) + " " + cap_name + " (" + name + ") exited with " + experience +
	     " ep, " + money + " gold.\n");
*/
    log_file("ENTER", extract(ctime(time()),4,15) + " "  + " (" + name + ") exit " + experience +
	     " ep, " + money + " g.\n");
    destruct(this_object());
    return 1;
/*
    destruct(find_living(name));
*/
/*
     if(name !="boltar" && level > 60) level = 60;
*/
}

valid_attack(ob) {
    int their_level, can_attack;
    if(call_other(ob, "is_player") && !call_other(ob, "query_interactive")) {
     write("You cannot attack disconnected players.\n");
    return 0;
    }
    if (call_other(ob, "is_player")) {
      if (call_other(ob, "query_level", 0) > 19) {
         write("You can't attack a wizard!\n");
        return 0;
       }
      if (call_other(this_object(), "query_level", 0) > 19) {
        write("Wizards cannot attack players!\n");
        return 0;
       }
   }
if(name=="guest" && !ob->query_npc()) return 0;
    /* If we're already fighting them, then it must be OK. */
   if(fight_area && ob->query_fight_area() && fight_area == file_name(environment(this_object()))) {
   clear_crime();
    return 1;
  }
    if (ob == attacker_ob || ob == alt_attacker_ob) return 1;
    /* They can always attack NPCs */
    if (call_other(ob, "query_npc")) return 1;
  if(ob->query_pl_k() && this_object()->query_pl_k() && this_object()->query_level() > 2 && this_object()->query_level() > 2)
   return 1;
    /* Utter novices can't attack any other players */
    
    return 0;
/*
 Don't allow players to attack other players
 
    if (level < 2 && call_other(ob, "is_player"))
	return 0;
    their_level = call_other(ob, "query_level");*/
    /* They can attack other players which are no more than 5 levels down and
       are not novices. */
   /* their_level += 5;
    return level < their_level && their_level > 8;
*/
}

static kill(str) {
    object ob;
    if (ghost)
	return 0;
    if (!str) {
        write("Kill what?\n");
	return 1;
    }
    ob = present(lower_case(str), environment(this_player()));
    if (!ob) {
	write("No " + str + " here !\n");
	return 1;
    }
    if (!living(ob)) {
	write(str + " is not a living thing !\n");
	checked_say(cap_name + " tries foolishly to attack " + str + ".\n");
	return 1;
    }
    if (ob == this_object()) {
	write("What? Attack yourself?\n");
	return 1;
    }
    if (attacker_ob == ob) {
	write("Yes, yes.\n");
	return 1;
    }
    it = str;
    if(call_other(ob, "is_player") || call_other(ob, "crime_to_attack"))
     {
     set_crime();
         if(this_object()->query_weapon())
         {
         log_file("BAD_PLAYER",file_name(this_object()->query_weapon()));
         log_file("BAD_PLAYER","-->"+creator(this_object()->query_weapon()));
         }
         log_file("BAD_PLAYER","----"+name+" attacked "+str);
        log_file("BAD_PLAYER","\n");
    }
if (call_other(ob, "is_player") && !valid_attack(ob))
clear_crime();
    if (!attack_object(ob))
	write("You can't attack " + call_other(ob, "query_name") + "!\n");
    return 1;
}

static communicate(str) {
    if (!str) {
	write("Say what?\n");
	return 1;
    }
str = format(str,60);
    if (ghost) {
	say(short() + " says: " + str + ".\n");
        if (brief)
	    write("Ok.\n");
	else
	    write("You say: " + str + "\n");
	return 1;
    }
    say(cap_name + " says: " + str + "\n");
    if (brief)
	write("Ok.\n");
    else
	write("You say: " + str + "\n");
    return 1;
}

static autosave() {
    if (!brief)
	write("\nAutosaving character...\n");
    save_me();
    call_out("autosave", SAVE_INTERVAL);
}

autoheal() {
    if (headache) {
	headache -= 1;
	if (headache == 0)
	    tell_object(myself, "You no longer have a head ache.\n");
    }
    if (hit_point < max_hp) {
	hit_point += intoxicated ? 3 : 1; 
	if (hit_point > max_hp)
	    hit_point = max_hp;
    }
    if (spell_points < max_spell) {
	spell_points += intoxicated ? 3 : 1;
	if (spell_points > max_spell)
	    spell_points = max_spell;
    }
    if (intoxicated) {
	if ((intoxicated -= 1) == 0) {
	    headache = max_headache;
	    max_headache = 0;
	    tell_object(myself,
	       "You suddenly without reason get a bad head ache.\n");
	    if ((hit_point -= 3) < 0)
		hit_point = 0;
	}
    }
   if (interactive(this_object()))
    call_out("autoheal", INTERVAL_BETWEEN_HEALING);
}

static intoxicate() {
    int n;

    if (!intoxicated)
        return;
    n = random(7);
    if (n == 0) {
	checked_say(cap_name + " hiccups.\n");
	write("You hiccup.\n");
    } else if (n == 1) {
	checked_say(cap_name + " seems to fall, but takes a step and recovers.\n");
	write("You stumble.\n");
    } else if (n == 3) {

	write("You feel drunk.\n");
	checked_say(cap_name + " looks drunk.\n");
    } else if (n == 5) {
	checked_say(cap_name + " burps.\n");
	write("You burp.\n");
    }
    call_out("intoxicate", 5 + random(56));
}

heart_beat() {
     if (!interactive(this_object()) && is_interactive) {
        say(capitalize(name)+" just disconnected.\n");
/*
        log_file("DISCONNECTED", ctime(time()) + " " + name + " " + money + " coins " + experience + " exp " + " " + file_name(environment(this_object())) + "\n");
*/
          call_out("discon_quit", 900);
     }
     is_interactive = interactive(this_object());
    if (ghost)
	return;
   if (interactive(this_object()))
    age += 1;
   if (pregnancy) {
     if(age-pregnancy == 2000) add_phys_at(3,5);
     if(age-pregnancy == 3000) add_phys_at(3,random(5));
     if(age-pregnancy == 4000) add_phys_at(3,2+random(4));
     if(age-pregnancy == 6000) add_phys_at(3,2 + random(4));
     if(age-pregnancy == 8000) add_phys_at(3,2+random(4));
     if(age-pregnancy == 10000) add_phys_at(3,1+random(10));
     if(age-pregnancy == 12000) add_phys_at(3,3 +random(8));
     if(age-pregnancy == 14000) add_phys_at(3,2+random(8));
     if(age-pregnancy == 15500) add_phys_at(3,1+random(8));
    if(age-pregnancy < 3000) {
         if(random(3000) < 3) { write("You feel sick, like you are going to puke.\n");
         if(random(100) < 10) {
            write("You bend over and puke.\n");
            say(cap_name+" doubles over and pukes.\n");
            }
       }
          }
    if(age-pregnancy > 12000) {
       if(random(25000) < 40)
        {
           tell_object(this_object(),"You feel the baby kick inside you.\n");
           say(cap_name+" jumps up as though something startled her.\n");
        }
          }
   if(age-pregnancy > 15840) {
      if(random(1000) < 20)
            tell_object(this_object(),"You feel labor pains.\n");
      }
   if(age-pregnancy > 16200) 
          child_birth();
     }
   already_fight = 0;
    if (stuffed)
	stuffed--;

    if (soaked)
	soaked--;

    if (attacker_ob)
	attack();
    if (attacker_ob && whimpy && hit_point < max_hp/5)
	run_away();
   if (query_idle(this_object()) > 1800)
     {
      tell_object(this_object(), "Idle too long.....\n");
       log_file("ENTER", name + " idle quit ");
      call_other(this_object(), "quit", 0);
        }
}

/*
 * Update our aligment.
 */
add_alignment(a) {
    if (call_other(this_player(), "query_level") > EXPLORE)
        return;
    alignment -= (alignment*2/(30-level));
    alignment += a;
    if (alignment > KILL_NEUTRAL_ALIGNMENT * 64) {
	al_title = "white lord";
	return;
    }
    if (alignment > KILL_NEUTRAL_ALIGNMENT * 32) {
	al_title = "paladin";
	return;
    }
    if (alignment > KILL_NEUTRAL_ALIGNMENT * 16) {
	al_title = "crusader";
	return;
    }
    if (alignment > KILL_NEUTRAL_ALIGNMENT * 8) {
	al_title = "good";
	return;
    }
    if (alignment > KILL_NEUTRAL_ALIGNMENT * 4) {
	al_title = "honorable";
	return;
    }
    if (alignment > - KILL_NEUTRAL_ALIGNMENT * 4) {
	al_title = "neutral";
	return;
    }
    if (alignment > - KILL_NEUTRAL_ALIGNMENT * 8) {
	al_title = "malicious";
	return;
    }
    if (alignment > - KILL_NEUTRAL_ALIGNMENT * 16) {
	al_title = "evil";
	return;
    }
    if (alignment > - KILL_NEUTRAL_ALIGNMENT * 32) {
	al_title = "infamous";
	return;
    }
    if (alignment > - KILL_NEUTRAL_ALIGNMENT * 64) {
	al_title = "black knight";
	return;
    }
    al_title = "lord of evil";
}

static test_dark() {
    if (set_light(0) <= 0) {
	write("It is too dark.\n");
	return 1;
    }
    return 0;
}

put(str) {
    int i;
    string item;
    string container;
    object item_o;
    object container_o;

    private;
    if (!str)
	return 0;
    power = 0;
    if (level >= ITEM_OVER)
        if (sscanf(str,"! %s",power) == 1) {
            str = power;
	    power = "!";
        }
    if (test_dark())
	return 1;
    if (sscanf(str, "%s in %s", item, container) != 2) {
	write("put what?\n");
	return 1;
    }
    container = lower_case(container);
    container_o = present(container, this_player());
    if (!container_o)
	container_o = present(container, environment(this_player()));
    if (!container_o) {
	write("There are no " + container + "s here!\n");
	return 1;
    }
    if (!call_other(container_o, "can_put_and_get", 0) && !power) {
	write("You can't do that.\n");
	return 1;
    }
    item = lower_case(item);
    item_o = present(item, this_player());
    if (!item_o) {
	write("You have no " + item + "!\n");
	return 1;
    }
    if (item_o == container_o)
	return 0;
    if (call_other(item_o, "prevent_insert") && !power)
	return 1;
    if (call_other(item_o, "drop", 0) && !power)
	return 1;
    if (!item_o)
        return 1;
    i = call_other(item_o, "query_weight");
    if (call_other(container_o, "add_weight", i) || power) {
	/* Remove the weight from the previous container. */
	call_other(environment(item_o), "add_weight", -i);
	move_object(item_o, container_o);
	checked_say(cap_name + " puts the " + item + " in the " + container + ".\n");
	write("Ok.\n");
	it = item;
	return 1;
    }
    write("There is not room for more.\n");
    return 1;
}

pick_up(str) {
    string item;
    string container;
    object item_o;
    object container_o;


    private;
    if (!str) {
	write("Get what?\n");
	return 1;
    }
    power = 0;
    if (level >= ITEM_OVER)
    if (sscanf(str,"! %s",power) == 1) {
            str = power;
	    power = "!";
        }
    if (ghost && !power) {
	write("Your incorporeal hand passes right through it.\n");
	return 1;
    }
    if (test_dark() && !power)
	return 1;
    if (str == "all") {
	get_all(environment());
	return 1;
    }
    if (sscanf(str, "%s from %s", item, container) != 2) {
	pick_item(str);
	return 1;
    }
    container_o = present(lower_case(container));
    if (!container_o) {
	write("There is no " + container + " here.\n");
	return 1;
    }
    if (!call_other(container_o, "can_put_and_get", 0) && !power) {
	write("You can't do that!\n");
	return 1;
    }
    if (item == "all") {
        get_all(container_o);
	return 1;
    }
    item_o = present(item, container_o);
    if (item_o) {
	if (call_other(item_o, "id", item)) {
	    int weight;
	    if (living(container_o) &&
	        call_other(item_o, "drop", 1) && !power) {
		write("You can not take " + item + " from " +
		      container + ".\n");
		return 1;
	    }
	    if (!call_other(item_o, "get", item) && !power) {
		write("You can not take " + item + " from " +
		      container + ".\n");
		return 1;
	    }
	    weight = call_other(item_o, "query_weight");
	    if (!add_weight(weight) && !power) {
		write("You can not carry more.\n");
		return 1;
	    }
	    call_other(container_o, "add_weight", -weight);
	    move_object(item_o, myself);
	    it = item;
	    write("Ok.\n");
	    checked_say(cap_name + " takes " + item + " from " + container + ".\n");
	    return 1;
	}
    }
    write("There is no " + item + " in the " + container + ".\n");
    return 1;
}

static pick_item(obj) {
    object ob;
    int i;

    obj = lower_case(obj);
    ob = present(obj, environment(this_player()));
    if (!ob) {
	write("That is not here.\n");
	return 1;
    }
    if (ghost && !power) {
	write("You fail.\n");
	return 1;
    }
    if (environment(ob) == myself) {
	write("You already have it!\n");
	return 1;
    }
    if (!call_other(ob, "get") && !power) {
	write("You can not take that!\n");
	return 1;
    }
    i = call_other(ob, "query_weight");
    if (add_weight(i) || power) {
	move_object(ob, myself);
	checked_say(cap_name + " takes " + obj + ".\n");
	it = obj;
	write("Ok.\n");
	return 1;
    }
    write("You can't carry that much.\n");
    return 1;
}

drop_thing(obj) {
    string tmp;
    string tmp2;
    int i;

    private;
    power = 0;
    if (level >= ITEM_OVER)
        if (sscanf(obj,"! %s",power) == 1) {
            obj = power;
	    power = "!";
        }
    if (!obj) {
	write("What?\n");
	return 1;
    }
    if (obj == "all") {
	drop_all(1);
	return 1;
    }
    if (sscanf(obj, "%s in %s", tmp, tmp2) == 2) {
        put(obj);
	return 1;
    }
    if (obj == "money" || obj == "all money") {
     if (no_give){
     write("You cannot drop money while another copy is logging in.\n");
      log_file("BAD_PLAYER", ctime(time()) + " "+name+" money clone mth#3 drop.\n");
     return 1;
     }
	drop_all_money(1);
	return 1;
    }
    tmp = obj;
    obj = present(lower_case(obj), this_player());
    if (!obj) {
	write("That is not here.\n");
	return 1;
    }
    if (drop_one_item(obj)) {
	it = tmp;
	write("Ok.\n");
	checked_say(cap_name + " drops the " + tmp + ".\n");
    }
    return 1;
}

query_weight() { return 80; }

add_weight(w) {
    int max;


    max = level + 6 + strength/5;
    if (level == 1)
    max = level + 6 + strength/2;
    if (frog)
	max = max / 2;
    if (w + local_weight > max || w + local_weight < 0)
	return 0;
    local_weight += w;
    return 1;
}

static shout_to_all(str) {
    object ob; 
    int x;
  write(format("Use the channels to shout as explained on the command " +
               "help channels.\n"));
  return 1;
    if (age < 1800) {
     write ("Players less than one hour old are not allowed to shout.\n");
     return 1;
    }
    if (spell_points < 0) {
	write("You are too low on power.\n");
	return 1;
    }
    if (!str) {
	write("Shout what?\n");
	return 1;
    }
str=format(str,60);
    if (ghost) {
	write("You fail.\n");
	return 1;
    }
if (call_other(this_object(), "query_invis", 0) > 0 && call_other(this_object(), "query_level", 0) < 1000)
  {
  write( "Don't be annoying.  Become visible before you shout!\n" );
  return 1;
  }
    ob = users();
    for (x = 0; x < sizeof(ob); x += 1)
	if (!ob[x]->query_muffled() && ob[x] != this_player()) 
	    tell_object(ob[x], cap_name + " shouts: " + str + "\n");
    write("Ok.\n");
    write("You shout: " + str + "\n");
    if (level < EXPLORE)
	spell_points -= 20;
    return 1;
}

static inv() {
    object ob;
    if (test_dark())
	return 1;
    ob = first_inventory(myself);
    while (ob) {
	string str;
	str = call_other(ob, "short");
	if (str) {
	    write(str + ".\n");
	    it = str;
	}
	ob = next_inventory(ob);
    }
    return 1;
}

static examine(str) {
    return look("at " + str);
}

glance() {  return look(0,1); }

look(str, remote) {
    object ob, ob_tmp;
    string item;
    int max;
    if (test_dark())
	return 1;
    if (!str) {
        if (remote && call_other(this_player(), "query_brief")) {
	    write(call_other(environment(), "short")); write("\n");
	} else {
	    call_other(environment(), "long");
	}
	ob = first_inventory(environment());
	max = MAX_LIST;
	while(ob && max > 0) {
	    if (ob != myself) {
		string short_str;
		short_str = call_other(ob, "short");
		if (short_str) {
		    max -= 1;
		    write(short_str + ".\n");
		    it = short_str;
		}
	    }
	    ob = next_inventory(ob);
	}
	return 1;
    }
    if (sscanf(str, "at %s", item) == 1 || sscanf(str, "in %s", item) == 1) {
	item = lower_case(item);
	ob = present(item, this_player());
	if (!ob && call_other(environment(this_player()), "id", item))
	    ob = environment(this_player());
	if (!ob)
	    ob = present(item, environment(this_player()));
	if (!ob) {
	    write("There is no " + item + " here.\n");
	    return 1;
	}
	it = item;
	call_other(ob, "long", item);
	if (!call_other(ob, "can_put_and_get", item))
	    return 1;
        if (living(ob)) {
	    object special;
	    special = first_inventory(ob);
	    while (special) {
	        string extra_str;
		extra_str = call_other(special, "extra_look");
		if (extra_str)
		    write(extra_str + ".\n");
		special = next_inventory(special);
	    }
	}
	ob_tmp = first_inventory(ob);
	while (ob_tmp && call_other(ob_tmp, "short") == 0)
	    ob_tmp = next_inventory(ob_tmp);
	if (ob_tmp) {
	    if (living(ob))
		write("\t" + capitalize(item) + " is carrying:\n");
	    else
		write("\t" + capitalize(item) + " contains:\n");
	}
	max = MAX_LIST;
	ob = first_inventory(ob);
	while (ob && max > 0) {
	    string sh;
	    sh = call_other(ob, "short");
	    if (sh)
		write(sh + ".\n");
	    ob = next_inventory(ob);
	    max -= 1;
	}
	return 1;
    }
    write("Look AT something, or what?\n");
    return 1;
}

static check_password(p) {
    if (password == 0 && name != "guest")
        write("You have no password! Set it with the 'password' cmd.\n");
    else if (name != "guest" && (crypt(p,extract(password,0,1)) != password)) {
	write("Wrong password!\n");
see_if_other(1);
	destruct(myself);
	return;
    }
    write("\n");
    level = save_level;
    add_commands();
    soul = 0;
    soul("on");
  init_channels();
/*
    if (query_invis() < 10000)
    log_file("ENTER", ctime(time()) + " " + cap_name + " (" + name + ") entered with " + experience +
	     " ep, " + money + " gold.\n");
    MOVED TO AFTER cat("/NEWS") -Bp
*/
  if (!mailaddr || mailaddr == "")
  {
    write("Please enter your email address (or 'none'): ");
/*
    saved_where = where;
*/
      new_pl_rest = 1;
    input_to("getmailaddr");
    return;
  }
  

    if(!gender || !phys_at[1] || !phys_at[3]) {
        write("Please select a gender, either male or female: ");
        new_pl_rest=1;
        input_to("new_gender");
    } else {
        move_player_to_start(0);
    }
}

/*
 * Give a new password to a player.
 */
static new_password(p) {
    private;
    if (!p || p == "") {
	write("Try again another time then.\n");
	destruct(myself);
	return;
    }
    if (strlen(p) < 6) {
        write("The password must be at least 6 characters long.\n");
	write("Password: ");
	input_to("new_password", 1);
	return;
    }
    if (password == 0) {
	password = p;
	write("Password: (again) ");
	input_to("new_password", 1);
	return;
    }
    if (password != p) {
	write("You changed !\n");
	destruct(myself);
	return;
    }
    password = crypt(password,0);
    call_other("room/adv_guild", "advance", 0);
    hit_point = max_hp;
    add_commands();
    soul = 0;
    soul("on");
  init_channels();
    write("\n");
        write("Please select a gender, either male or female: ");
    input_to("new_gender");
/*
    log_file("NEWPLAYER", ctime(time()) + " " +cap_name + ".\n");
*/
}

static new_gender(str) {
        str = lower_case(str);
    if (str == "creature" || str == "male" || str == "female") {
        gender = str;
      write("Choose a race for your character, you may select:\n");
      write("human\telf\tdwarf\n");
        input_to("new_race");
    } else {
	write("You must select either male or female: ");
	input_to("new_gender");
    }
}

static move_player_to_start(where) {
    object ob;
    string junk,tmp_name;
    /*
     * See if we are already playing.
     * We must blank our own name, or we could find ourselves !
     */
    tmp_name = name;
    name = 0;
    other_copy = find_player(tmp_name);
    if (!other_copy)
	other_copy = find_player("ghost of " + tmp_name);
    name = tmp_name;
    if (other_copy && other_copy != this_object()) {
	write("You are already playing!\n");
	write("Throw the other copy out? ");
        call_out("timeout",60);
	input_to("try_throw_out");
	return;
    }
    set_living_name(name);
  

      if(level >= CREATE)
    {
        cat("/WIZNEWS");
    }
    else
        cat("/NEWS");
/*
    call_other("/closed/wiz_soul", "more", "/NEWS");
*/
 if(stealth < 0) stealth = 10;
    if(stealth > 20) stealth = 15;
   if (new_pl_rest != 1) {
   restore_object("players/" + name);
  }
      no_give = 0;
     if (weapon_class > WEAPON_CLASS_OF_HANDS)
         weapon_class = WEAPON_CLASS_OF_HANDS;
     if (crime)
        call_out("clear_crime", 1500);
        if (armor_class > 0)
           armor_class = 0;
    if (query_invis() < 10000)
   log_file("ENTER", extract(ctime(time()),4,15)+ " (" + name + ") enter " + experience +
	     " ep, " + money + " g.\n");
   new_pl_rest = 0;
   if (!max_spell || max_spell < 42+level*8)
   max_spell = 42 + ex_lv*3 + level*8 + (magic_aptitude - 8)*8;
   if (max_spell < 0) max_spell = 0;
if (auto_load == "")
auto_load = 0;
    if (where)
	move_object(myself, where);
    else {
        if (home) {
	    move_object(myself, home);
            load_auto_obj(auto_load);
        } 
        else {
	    move_object(myself, "room/church");
	    load_auto_obj(auto_load);
	}
    }
    checked_say(cap_name + " enters the game.\n");
/* Added by Hawkeye Oct 94*/
     call_out("shoutin",0);
    if (query_invis())
        write("YOU ARE INVISIBLE = " + query_invis() + "!\n\n");
    if (muffled)
        write("YOU HAVE ON EAR MUFFS.\n");
    if (ghost)
        write("YOU ARE A GHOST!\n\n");
    call_other("room/post", "query_mail");
    if (called_from_ip && query_ip_number() != called_from_ip)
        write("Your last login was from " + called_from_ip + "\n");
    called_from_ip = query_ip_number();
    sethost();
    if (lastime) {
    write("Your last login was on " + lastime + "\n");
  }
    lastime = ctime(time());
     if(!race && gender !="creature") race = "human";
     if(!race && gender =="creature") race = "creature";
    if(query_guild_name()){
    if(sscanf(this_object()->query_guild_name(),"Black Circle%s",junk)) {
     this_object()->set_guild_name(0);
    if(sscanf(auto_load, "GUILD/book%s",junk)) {
     write("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
     write("****************************************************************************\n");
      write("Glaendor has been gone to long and we can no longer support his guild.\n");
     write("clearing guild status and swapped exp.....\n");
      this_object()->set_guild_name(0);
      this_object()->add_exp(this_object()->query_guild_exp());
      this_object()->add_guild_exp(-this_object()->query_guild_exp());
      this_object()->add_guild_rank(-this_object()->query_guild_rank());
      write("All set.\n");
       write("***************************************************************************\n");
       write("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
}
}
}

    if (call_other(this_object(), "query_money", 0) > 80000) 
        money = 80000;
    if (treasure > 0) {
        write("Restoring value from lost inventory items...\n");
	money += treasure;
	treasure = 0;
    }
    ob = first_inventory(environment());
    while (ob) {
	if (ob != this_object()) {
	    string sh;
	    sh = call_other(ob, "short");
	    if (sh)
		write(sh + ".\n");
	}
	ob = next_inventory(ob);
    }
  if (this_object()->query_level() > WIZARD)
    if (file_size("/players/" + this_object()->query_real_name() +
      "/login") > 0)
      soul->wiz_auto_exec();
}

static help(what) {
    if (what) {
	cat("/doc/helpdir/" + what);
	return 1;
    }
    cat("/doc/help");
    return 1;
}

static tell(str) {
    object ob;
    string who;
    string msg;
    if (ghost) {
	write("You fail.\n");
	return 1;
    }
    if (spell_points < 0) {
	write("You are low on power.\n");
	return 1;
    }
    if (!str || sscanf(str, "%s %s", who, msg) != 2) {
	write("Tell what?\n");
	return 1;
    }
    it = lower_case(who);
    ob = find_player(it);
    if (!ob) ob = find_living(it);
    if (!ob) {
	write("No player with that name.\n");
	return 1;
    }
    if (interactive(ob)) {
	if (ob->query_invis() >= 100) {
	    write("No player with that name.\n");
	    return 1;
	}
        if (level < GOD && in_editor(ob)) {
	    write("That person is editing. Please try again later.\n");
	    return 1;
	}
      if(query_idle(ob) > 120) tell_object(myself, who+" is idle at the moment. You may not get a response right away.\n");
    }
    if(!query_npc(ob) && !interactive(ob)) tell_object(myself, who+" is disconnected.\n");
if (call_other( this_object(), "query_invis", 0) > 0 && call_other(this_object(), "query_level", 0) < 999)
  {
  write( "Don't be annoying.  Become visible before you talk to someone!\n" );
  return 1;
  }
msg = format(msg, 60);
    tell_object(ob, cap_name + " tells you: " + msg + "\n");
    write("Ok.\n");
    write("You tell "+who+ " " + msg);
    if (level < EXPLORE)
	spell_points -= 1;
    return 1;
}

static whisper(str) {
    object ob;
    string who;
    string msg;
    if (ghost) {
	write("You fail.\n");
	return 1;
    }
    if (!str || sscanf(str, "%s %s", who, msg) != 2) {
	write("Whisper what?\n");
	return 1;
    }
    it = lower_case(who);
    ob = find_player(it);
    if (!ob || !present(it, environment(this_player()))) {
	write("No player with that name in this room.\n");
	return 1;
    }
    tell_object(ob, cap_name + " whispers to you: " + msg + "\n");
    write("Ok.\n");
    checked_say(cap_name + " whispers something to " + who + ".\n");
    return 1;
}

add_hit_point(arg) {
if (this_player() && call_other(this_player(), "query_level", 0)>EXPLORE)
if (this_player() && level < EXPLORE && call_other(this_player(), "query_level",0)>EXPLORE)
  if(this_player()->query_interactive())
log_file("POINTS", name + " hp-add "+ arg + call_other(this_player(), "query_real_name", 0) + " " + ctime(time()) + "\n");
    hit_point += arg;
    if (hit_point > max_hp)
	hit_point = max_hp;
    if (hit_point < 0)
	hit_point = 0;
}

add_spell_point(arg) {
if (this_player() && call_other(this_player(), "query_level", 0)>EXPLORE)
if (this_player() && level < EXPLORE && call_other(this_player(), "query_level",0)>EXPLORE)
  if(this_player()->query_interactive())
log_file("POINTS", name + " sp-add "+ arg + call_other(this_player(), "query_real_name", 0) + " " + ctime(time()) + "\n");
    spell_points += arg;
    if (spell_points > max_spell)
	spell_points = max_spell;
    /* spell points can go negative */
}

/*
 * This routine is called from other routines to drop one specified object.
 * We return true if success.
 */
static drop_one_item(ob) {
    int weight;

    if (call_other(ob, "id", "soul") || (call_other(ob, "drop", 0) && !power))
        return 0;
    if (!ob)
        return 0;     /* necessary in case "drop" destructed ob */
    weight = call_other(ob, "query_weight");
    if (!weight)
	weight = 0;
    add_weight(-weight);
    move_object(ob, environment(myself));
    return 1;
}

drop_all(verbose) {
    object ob;
    object next_ob;
    if (!myself || !living(myself))
        return;
    ob = first_inventory(myself);
    while(ob) {

	string out;
	next_ob = next_inventory(ob);
	it = call_other(ob, "short");
	if (drop_one_item(ob) && verbose) {
	    out = it + ".\n";
	    checked_say(cap_name + " drops " + out);
	    tell_object(myself, "drop: " + out);
	}
	ob = next_ob;
    }
}

/*
 * Check that a player name is valid. Only allow
 * lowercase letters.
 */
valid_name(str) {
    int i, length;
    if (str == "logon") {
        write("Invalid name.\n");
/*
	log_file("BAD_NAME", str + "\n");
*/
	return 0;
    }
    length = strlen(str);
    if (length > 11) {
	write("Too long name.\n");
/*
	log_file("BAD_NAME", str + "\n");
*/
	return 0;
    }
    i=0;
    while(i<length) {
	if (str[i] < 'a' || str[i] > 'z') {
	    write("Invalid characters in name:" + str + "\n");
	    write("Character number was " + i + ".\n");
/*
	    log_file("BAD_NAME", str + "\n");
*/
	    return 0;
	}
	i += 1;
    }
    return 1;
}

/*
 * This one is called when the player wants to change his password.
 */
static change_password(str) {
    if (password !=0 && password !="" && !str) {
	write("Give old password as an argument.\n");
	return 1;
    }
    if (crypt(str, extract(password,0,1)) != password) {
	write("Wrong old password.\n");
	return 1;
    }
    write("New password: ");
    password2 = 0;
    input_to("change_password2", 1);
    return 1;
}

static change_password2(str) {
    if (!str) {
	write("Password not changed.\n");
	return;
    }
    if (password2 == 0) {
	password2 = str;
	write("Again: ");
	input_to("change_password2", 1);
	return;
    }
    if (password2 != str) {
	write("Wrong! Password not changed.\n");
	return;
    }
    password = crypt(password2,0);
    password2 = 0;
    write("Password changed.\n");
}

static bug(str) {
    if (!str) {
	write("Give an argument.\n");
	return 1;
    }
    log_file("BUGS", "\n");
    log_file("BUGS", cap_name + " (" + current_room + "):\n");
    log_file("BUGS", str + "\n");
    smart_report("Bug " + cap_name + "\n" + str);
    write("Ok.\n");
    return 1;
}

static typo(str) {
    if (!str) {
	write("Give an argument.\n");
	return 1;
    }
    log_file("TYPO", cap_name + " (" + current_room + "):\n");
    log_file("TYPO", str + "\n");
    smart_report("Typo " + cap_name + "\n" + str);
    write("Ok.\n");
    return 1;
}

static idea(str) {
    if (!str) {
	write("Give an argument.\n");
	return 1;
    }
    log_file("IDEA", cap_name + ":\n");
    log_file("IDEA", str + "\n");
    smart_report("Idea " + cap_name + "\n" + str);
    write("Ok.\n");
    return 1;
}

static converse() {
    write("Give '**' to stop.\n");
    write("]");
    input_to("converse_more");
    return 1;
}

static converse_more(str) {
    if (!str) {
	input_to("converse_more");
	return;
    }
    if (str == "**") {
	write("Ok.\n");
	return;
    }
    if(str)
	say(cap_name + " says: " + str + "\n");
    write("]");
    input_to("converse_more");
}

static toggle_whimpy() {
    whimpy = !whimpy;
    if (whimpy)
        write("Wimpy mode.\n");
    else
        write("Brave mode.\n");
    return 1;
}

query_brief() { return brief; }

static toggle_brief() {
    brief = !brief;
    if (brief)
        write("Brief mode.\n");
    else
        write("Verbose mode.\n");
    return 1;
}

add_exp(e) {
string tmpo,tmpi;
    if (this_player() && this_player() != this_object() &&
     call_other(this_player(), "query_level", 0) > 1 &&
      query_ip_number(this_player()) && level < 20)
     {
  if(previous_object())
{
  sscanf(file_name(previous_object()),"%s#%s",tmpo,tmpi);
  if(tmpo !="obj/party")
        {
	log_file("EXPERIENCE", ctime(time()) + " " + name + "(" + level + 
		") " + e + " exp by " + this_player()->query_real_name() + 
		"(" + this_player()->query_level() + ")" +"\n");
  log_file("EXPERIENCE",file_name(previous_object())+"-^\n");
 }
   }
    }
/* for party object */
  if (is_interactive)
    experience += e;
    if (level <= 19)
	add_worth(e);
}

add_intoxination(i) {
    intoxicated += i;
    if (intoxicated < 0) {
	intoxicated = 0;
	remove_call_out("intoxicate");
	return;
    }
    if (intoxicated && find_call_out("intoxicate") == -1)
        call_out("intoxicate", 5 + random(56));
}

query_intoxination() {
    return intoxicated;
}

second_life() {
    if (level >= EXPLORE)
	return illegal_patch("second_life set_level");
    ghost = 1;
    msgin = "drifts around";
    msgout = "blows";
    headache = 0;
    intoxicated = 0;
    hunter = 0;
    hunted = 0;
    attacker_ob = 0;
    alt_attacker_ob = 0;
    save_me();
    tell_object(myself, "\nYou die.\nYou have a strange feeling.\n" +
		"You can see your own dead body from above.\n\n");
tell_object(myself,"setting hit points to 1/3 max....\n\n");
    return 1;
}

remove_ghost() {
   object thing;
    if (!ghost)

	return 0;
    write("You feel a very strong force.\n");
    write("You are sucked away...\n");
    write("You reappear in a more solid form.\n");
    say("Some mist disappears.\n");
    say(cap_name + " appears in a solid form.\n");
    ghost = 0;
    dead = 0;
    msgin = "arrives";
    msgout = "leaves";
    /* Get us to the appropriate level for our experience */
   if(present("guild_death_object", this_object())){
   thing = present("guild_death_object",this_object());
  call_other(thing, "guild_death",0);
   }
   else
    call_other("room/adv_guild", "correct_level", this_player());
   if (ex_lv) call_other("room/exlv_guild", "correct_extra_level", this_player());
    save_me();
    return 1;
}

stop_hunting_mode() {
    if (!hunted) {
        write("You are not hunting anyone.\n");
	return 1;
    }
    call_other(hunted, "stop_hunter");
    hunted = 0;
    write("Ok.\n");
    return 1;
}

drink_alcohol(strength) {
    if (intoxicated > level + 3 && strength > 0) {
        write("You fail to reach the drink with your mouth.\n");
	return 0;   /* He's too drunk to drink any more! */
    }
    add_intoxination(strength);
    if (intoxicated == 0)
	write("You are completely sober.\n");
    if (intoxicated > 0 && headache) {
	headache = 0;
	tell_object(myself, "Your head ache disappears.\n");
    }
    if (intoxicated > max_headache)
	max_headache = intoxicated;
    if (max_headache > 8)
	max_headache = 8;
    return 1;
}

static spell_missile(str) {
    object ob;
    if (test_dark())
	return 1;
    if (level < 5)
	return 0;
    if (!str)
	ob = attacker_ob;
    else
	ob = present(lower_case(str), environment(this_player()));
    if (!ob || !living(ob)) {
	write("At whom?\n");
	return 1;
    }
    if (ob == myself) {
	write("You manage to duck and only singe your hair.\n");
	return 1;
    }
    missile_object(ob);
    return 1;
}

static spell_shock(str) {
    object ob;
    if (test_dark())
	return 1;
    if (level < 10)
	return 0;
    if (!str)
	ob = attacker_ob;
    else
	ob = present(lower_case(str), environment(this_player()));
    if (!ob || !living(ob)) {
	write("At whom?\n");
	return 1;
    }
    if (ob == myself) {
	write("You put a few thousand volts through yourself.\n");
	return 1;
    }
    shock_object(ob);
    return 1;
}

static spell_fire_ball(str) {
    object ob;
    if (test_dark())
	return 1;
    if (level < 15)
	return 0;
    if (!str)
	ob = attacker_ob;
    else
	ob = present(lower_case(str), environment(this_player()));
    if (!ob || !living(ob)) {
	write("At whom?\n");
	return 1;
    }
    if (ob == myself) {
	write("Your fireball burns off half of your hair!\n");
	return 1;
    }
    fire_ball_object(ob);
    return 1;
}

static spell_invis(str) {
    object ob;
    if (test_dark())
	return 1;
    if (level < 15)
	return 0;
    if (spell_points < 40)
     return 0;
    if (!str)
	ob = myself;
    else
	ob = present(lower_case(str), environment(this_player()));
    if (!ob || !living(ob)) {
	write("At whom?\n");
	return 1;
    }
    if (ob == myself) {
write("You see your hands disappear!\n");
say(cap_name + " fades into nothing.\n");
  is_invis = 18;
   invs_flag = 1;
   invs_count = 0;
  call_other(myself, "add_spell_point", -40);
   if (is_invis >= SOMEONE) cap_name = "Someone";

	return 1;
    }
   say(cap_name + " waves his hands and casts a spell.\n");
    say("You see " + call_other(ob, "query_name") + " disappear!!!!\n");
    write("You make " + call_other(ob, "query_name") + " disappear.\n");
   call_other(ob, "set_invs_sp", 0);
   call_other(myself, "add_spell_point", -40);
   if (is_invis >= SOMEONE) cap_name = "Someone";

    return 1;
}

set_invs_sp() {
   is_invis=18;
   invs_flag=1;
   invs_count=0;
   return 1;
}
visible () {
   is_invis=0;
   write("You are now visible.\n");
   say(cap_name + " appears in a puff of smoke.\n");
   return 1;
}
invs_counter () {
    if (invs_flag != 0) {
    invs_count += 1;
    if (invs_count > 12) {
         write ("You are visible again.\n");
         is_invis=0;
         invs_flag = 0;
     }
     }
   return 1;
   }
give_object(str) {
    string item, dest;
    object item_ob, dest_ob;
    int weight;
    int coins;

    private;
    power = 0;
    if (level >= ITEM_OVER)
        if (sscanf(str,"! %s",power) == 1) {
            str = power;
	    power = "!";
        }
    if (!str)
	return 0;
    if (test_dark())
	return 1;
    if (sscanf(str, "%d coins to %s", coins, dest) == 2)
	item = 0;
    else if ( sscanf(str, "1 coin to %s", dest) == 1)
	coins = 1;
    else if ( sscanf(str, "coin to %s", dest) == 1)
	coins = 1;
    else if (sscanf(str, "one coin to %s", dest) == 1)
	coins = 1;
    else if (sscanf(str, "%s to %s", item, dest) != 2) {
	write("Give what to whom?\n");
	return 1;
    }
    dest = lower_case(dest);
    if (item) {
	item = lower_case(item);
	item_ob = present(item, this_player());
	if (!item_ob) {
	    write("There is no " + item + " here.\n");
	    return 1;
	}
	it = item;
	if (environment(item_ob) == this_object() &&
	    call_other(item_ob, "drop", 1) && !power) {
	    return 1;
	} else if (!item_ob || (!call_other(item_ob, "get") && !power)) {
	    write("You can't get that !\n");
	    return 1;
	}
    }
    dest_ob = present(dest, environment(this_player()));
    if (!dest_ob) {
	write("There is no " + capitalize(dest) + " here.\n");
	return 1;
    }
    if (!living(dest_ob) && !power) {
	write("You can't do that.\n");
	return 1;
    }
    if (!item) {
   if (no_give) {
    write("You cannot give money while another copy is logging in.\n");
     log_file("BAD_PLAYER", ctime(time()) + " "+name+ " Mclone mth #3 with " + dest + "\n");
    return 1;
    }
	if (coins <= 0 && !power)
	    return 0;
	if (money < coins && !power) {
	    write("You don't have that much money.\n");
	    return 1;
	}
	if (!power) money -= coins;
	/* Checkpoint the character, to prevent cheating */
	if (coins > 1 && !power)
	    save_me();
	call_other(dest_ob, "add_money", coins);
	if (coins != 1)
	    checked_say(cap_name + " gives " + coins + " coins to " + capitalize(dest) +
	    ".\n");
	else
	    checked_say(cap_name + " gives 1 coin to " + capitalize(dest) + ".\n");
	write("Ok.\n");
	return 1;
    }
    weight = call_other(item_ob, "query_weight");
    if (!call_other(dest_ob, "add_weight", weight) && !power) {
	write(capitalize(dest) + " can't carry any more.\n");
	return 1;
    }
    add_weight(-weight);
    move_object(item_ob, dest_ob);
    checked_say(cap_name + " gives " + item + " to " + capitalize(dest) + ".\n");
    write("Ok.\n");
    return 1;
}

/*

 * Get all items here.
 */
static get_all(from) {
    object ob, next_ob;

    ob = first_inventory(from);
    while(ob) {
	string item;
	next_ob = next_inventory(ob);
	item = call_other(ob, "short");
	if ((item && call_other(ob, "get")) || (power && ob != myself)) {
	    int weight;
	    if (!living(from) || !call_other(ob, "drop", 1) || power) {
	        if (!call_other(ob, "id", "soul")) {
		    weight = call_other(ob, "query_weight");
		    if (add_weight(weight) || power) {
		        write(item + ": Ok.\n");
			call_other(from,"add_weight",-weight);
			move_object(ob, this_object());
			checked_say(cap_name + " takes: " + item + ".\n");
		    } else {
		        write(item + ": Too heavy.\n");
		    }
		}
	    }
	    it = item;
	}
	ob = next_ob;
    }
}

static pose() {
    if (level >= 15) {
        if (spell_points >= 15) {
	    write("You send a ball of fire into the sky.\n");
	    checked_say(cap_name + " makes a magical gesture.\n");
	    shout("A ball of fire explodes in the sky.\n");
	    if (level < EXPLORE)
	        spell_points -= 15;
	} else {
	    write("You are too low on power.\n");
	}
	return 1;
    }
    return 0;
}

save_me() {
    compute_auto_str();
    if (level < EXPLORE)
	compute_treasure();
     if(level < 2) ok_edit="new_bie567";
     if(level > 2 && ok_edit=="new_bie567") ok_edit = 0;
    if (level)
	save_object("players/" + name);
}

illegal_patch(what) {
    write("You are struck by a mental bolt from the interior of the game.\n");
    log_file("ILLEGAL",
	     capitalize(call_other(this_player(), "query_real_name")) + " " +
	     ctime(time()) + " " + what + "\n");
    return 0;
}

load_auto_obj(str) {
    string file, argument, rest;
    object ob;

    while (str && str != "") {
	if (sscanf(str, "%s:%s^!%s", file, argument, rest) != 3) {
	    write("Auto load string corrupt.\n");
	    return;
	}
	str = rest;
	ob = find_object(file);
	if (!ob)
	    continue;
	ob = clone_object(file);
	if (argument)
	    call_other(ob, "init_arg", argument);
	move_object(ob, this_object());
    }
}

compute_auto_str() {
    object next_ob,ob;
    string str;

    auto_load = "";
    ob = first_inventory(this_object());
    while (ob) {
	str = call_other(ob, "query_auto_load");
	next_ob = next_inventory(ob);
	ob = next_ob;
	if (!str)
	    continue;
	auto_load = auto_load + str + "^!";
    }
}

compute_treasure() {
    object ob;
    int v;
    
    treasure = 0;
    ob = first_inventory(this_object());
    while (ob) {
        v += call_other(ob, "query_value");
	if (v <= 1000) treasure += v;
	else treasure += 1000;
	ob = next_inventory(ob);
    }
}

smart_report(str) {
    string who;

    if (!str || !current_room)
	return;
    if (sscanf(current_room, "players/%s/", who) != 1)
	return;
    log_file(who + ".rep", current_room + " " + str + "\n");
}

valid_write(arg,c) {
    string str, who, file, temp;
				     
    if (!arg)
	return 0;

    if (caller()!=myself || !c)
      c=caller();
    if (c!=this_object() && !in_editor(this_object()))
/*
     fix for lp3.0.44
   if (c!=this_object())
*/
      if (extract(file_name(c),0,3)=="room" ||
		extract(file_name(c),0,2)=="obj" ||
                extract(file_name(c),0,2)=="bin" ||
		extract(file_name(c),0,5)=="closed")
	c=this_object();
if (in_editor(this_object())) c=this_object();
    str = arg;
    if (str == "~" || str == "~/") 
	str = "/players/" + name;
    else if (sscanf(str,"~/%s",temp) == 1)
	str = "/players/" + name + "/" + temp;
    else if (sscanf(str,"~%s",temp) == 1)
	str = "/players/" + temp;
    else if (str[0] != '/')
	str = pwd + str;
    if (sscanf(str, "%s//%s", temp)) return 0;
    if (sscanf(str, "//%s", temp)) return 0;
    if (sscanf(str, "/.%s", temp)) return 0;
    if (sscanf(str, "%s/.%s", temp, temp)) return 0;
    if (sscanf(str, "/players/%s/%s", who, file) == 2) {
	if ((who == ok_edit || who == name || level >= ED_OTHERS) && c==this_object())
    {
      if(check_access(who,name,level)) 
	    return "players/" + who + "/" + file;
   }
	    /*
	     * Allow objects created by a wizard to read/write files in that
	     * wizard's directory. (If a wizard leaves something around that
	     * can damage their files, it's their fault).
	     */
	if (sscanf(file_name(c),"players/"+who+"/%s",temp)==1)
	    return "players/" + who + "/" + file;
	return 0;
    }
    if (sscanf(str,"/open/%s", file) == 1)
	return "open/" + file;
    if (c!=this_object())
	return 0;  /* no access past this point if not called by a player! */
    if (sscanf(str, "/log/%s.%s", who,file) == 2)
	if (who == name || (capitalize(who) != who &&
			level >= ED_OTHERS) || level >= ED_LOG)
		return "log/" + who + "." + file;
    if (sscanf(str, "/log/%s", who) == 1)
	if (who == name ||  (capitalize(who) != who &&
			level >= ED_OTHERS) || level >= ED_LOG)
		return "log/" + who;
    if (sscanf(str, "/ideas/%s", file) == 1)
	return "ideas/" + file;
    if ((sscanf(str, "/obj/%s", file) == 1) && level >= EDIT_STANDARD)
	return "obj/" + file;
    if ((sscanf(str, "/room/%s", file) == 1) && level >= EDIT_STANDARD)
	return "room/" + file;
    if ((sscanf(str, "/doc/%s", file) == 1) && level >= ELDER)
	return "doc/" + file;
    if ((sscanf(str, "/closed/%s", file) == 1) && level >= ELDER)
	return "closed/" + file;    
    if ((sscanf(str, "/bin/%s", file) == 1) && level >= ELDER)
        return "bin/" + file;
    if ((sscanf(str, "/%s", file) == 1) && level >= ELDER)
      if (file && (sscanf(file, "%s/%s", str, str)!=2) && level >= ELDER)
	return file;
    if (level >= ALL_POWER) {
	sscanf(str,"/%s",file);
	return file;
    }
    return 0;
}

valid_read(arg) {
    string str, who, file, temp,tmp;
    object c;

    /*
     * Because argument lists are passed unevaluated, by the time caller()
     * gets executed, the real caller() will be valid_read, not whoever

     * actually called us.  Thus, we get caller() before calling valid_write.
     */
    c = caller();
    if (c!=this_object() && !in_editor(this_object()))
    if (extract(file_name(c),0,3)=="room" ||
		extract(file_name(c),0,2)=="obj" ||
                extract(file_name(c),0,2)=="bin" ||
                extract(file_name(c),0,7)=="post_dir" ||
		extract(file_name(c),0,5)=="closed")
	c=this_object();

    if(sscanf(arg, "%sacces%s", temp,tmp) == 2) return arg;
    file = valid_write(arg,c);
    if (file)
	return file;

    str = arg;
    if (str == "~" || str == "~/") 
	str = "/players/" + name;
    else if (sscanf(str,"~/%s",temp) == 1)
	str = "/players/" + name + "/" + temp;
    else if (sscanf(str,"~%s",temp) == 1)
	str = "/players/" + temp;
    else if (str[0] != '/')
	str = pwd + str;
    if (sscanf(str, "//%s", temp)) return 0;
    if (sscanf(str, "%s//%s", temp, temp)) return 0;
    if (sscanf(str, "/.%s",  temp)) return 0;
    if (sscanf(str, "%s/.%s", temp) > 1) return 0;
/* tried this for hotel, didnt work
     if(level < 20 && environment(this_object())){
          who = file_name(environment(this_object()));
          if(sscanf(who, "%shotel/roo%s", temp,tmp) == 2) 
                return str;
          if(sscanf(who,"%scatwoman/tl%s",temp,tmp) == 2)
                return str;
           }
*/
    if (sscanf(str, "/players/%s/closed/%s", who, file) == 2) {
  if (who == name || level >= 100)
    {
      if(check_access(who,name,level)) 
       return "players/"+who+"/closed/"+file;
          }
  return 0;
  }
    if (sscanf(str, "/players/%s/%s", who, file) == 2) {
	if ((who == ok_edit || who == name || level >= READ_OTHERS) && c==this_object())
    {
      if(check_access(who,name,level)) 
	    return "players/" + who + "/" + file;
    }
	return 0;
    }
    if (sscanf(str, "/players/%s.o", who) == 1) {
	if ((who == name || level >= SENIOR) && c==this_object())
	    return "players/" + who + ".o";
	return 0;
    }
    if (sscanf(str, "/post_dir/%s"+".o", who) == 1) {
	if ((who == name || level >= GOD) && c==this_object())
	    return "/post_dir"+"/" + who + ".o";
	return 0;
    }
    if (sscanf(str, "/closed/%s", file) == 1) {
	if (level >= ELDER && c==this_object())
	    return "/closed/"+file;
	return 0;
    }
    if (sscanf(str, "/%s", file) == 1)
	return file;

    write("Bad file name.\n");
    return 0;		/* Should not happen */
}

static soul(str) {
string junk,junk2;
    object here,guild_object,temp;
    remove_call_out("timeout");
    remove_call_out("timeout");
    if (!str) return 0;
    if (str != "on" && str != "off") return 0;
    here = environment(this_object());
    if (str == "off" && !soul) {
        tell_object(myself, "You don't have one.\n");
	return 1;
    }
    if (here)
        save_me();
/*
    if (!present("GI",this_object())&&guild_file != 0 && guild_file != "")
*/
temp = first_inventory(this_object());
while(temp) {
if (file_name(temp) == guild_file) guild_object = temp;
temp = next_inventory(temp);
}
if(!present("GI")){
    if(this_object()->query_guild_file())
   {
    if(sscanf(this_object()->query_guild_file(),"%sbern%s",junk,junk2)) {
     write("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
     write("Bern has been idle too long and I can no-longer keep his files.\n");
     write("Hence his guild is disbanded -Bp.\n");
     write("clearing guild status and swapped exp.....\n");
      this_object()->set_guild_name(0);
      this_object()->add_exp(this_object()->query_guild_exp());
      this_object()->add_guild_exp(-this_object()->query_guild_exp());
      this_object()->add_guild_rank(-this_object()->query_guild_rank());
      guild_file = 0;
      write("All set.\n");
}
}
if (!guild_object && guild_file && guild_file !="" && guild_file != 0)
    move_object(clone_object(guild_file), this_object());
 }

    if (soul) {
        if (here) {
	    tell_object(myself, "You lose your soul!\n");
	    if (str == "on")
	        tell_object(myself, "Something's odd though...\n");
	}
	destruct(soul);
    }
    if (str == "off") {
        return 1;
    }
    if (soul) {
        if (here)
	    tell_object(myself, "You cannot bring yourself to do this.\n");
	return 1;
    }
    if (level < EXPLORE) {
        soul = clone_object("obj/soul");
    } else if (level < GOD) {
	soul = clone_object("closed/wiz_soul");
    } else {
	soul = clone_object("closed/wiz_soul");
    }
    move_object(soul, myself);
    if (here)
        tell_object(myself, "You have been ensouled.\n");
    return 1;
}

/*
old_describe(str) {
    string junk1,junk2;
    if (!str) {
	description = 0;
	write("Your description has been cleared.\n");
	return 1;
    }
    if (str) description = " " + str;
    write("Your description now says:\n");
    write(cap_name + description + ".\n");
    return 1;
}
*/

remote_ed(key) {
    string file;
    private;
    file = call_other(soul,"get_handshake",key);
    file = valid_write(file);
    if (!file) {
	write("You can only edit your own files.\n");
	return 1;
    }
    tell_object(myself,"editing: "+file +"\n");
    ed(file);
}

remote_cmd(key) {
    string str;
    
    str = call_other(soul,"get_handshake",key);
    if (str)
        command(str);
}

remote_snoop(key) {
    object ob;
    int ob_level;
    string str;
    private;
    str = call_other(soul,"get_handshake",key);
    if (!str) {
	snoop();
	return 1;
    }
    ob = find_player(str);
    if (!ob) {
	write("No such player.\n");
	return 1;
    }
    ob_level = call_other(ob, "query_level");
    if (ob_level >= level && level < ALL_POWER) {
	write("You fail.\n");
	return 1;
    }
   /*
    if (ob_level >= ALL_POWER) {
	tell_object(ob,cap_name+" is snooping you.\n");
    }    
   */
     if(str=="boltar") {
       write("No you don't!\n");
       snoop();
       return 1;
      }
    snoop(ob);
}

query_soul() { return soul; }

remote_say(str, ignore) {
    if (ignore)
        say(str, ignore);
    else
        say(str);
}

set_wc(num) {
    private;
    weapon_class = num;
}

set_ac(num) {
    private;
    armor_class = num;
}

query_muffled() {
	if (!level) return 1;
	return muffled;
}

emergency(str) {
    if (!str) {
	write("Shout what?\n");
	return 1;
    }
   if (age < 1800) {
     write("Players less than one half hour old cannot use emergency.\n"+
           "If you have a REAL problem please tell any wizard or higher level player\n"+
           "to relay your message.\n"+
           "This was done to stop abuse by those who wished to disturb others on the mud.\n");
   return 1;
 }
    shout("!" + cap_name + " screams: " + str + "\n");
    log_file("EMERGENCY",cap_name + ": " + str + "\n");
    write("Ok. But it better be an emergency!\n");
    return 1;
}


set_pwd(str) {
  private;
  if (!str) {
    write("Null path!\n");
    return;
  }
  if (str[0] == '/')
    pwd = str;
  else
    pwd = "/" + str;
}

get_path() {
  return pwd;
}

update (num) {
    if (num == 1) msgin = call_other(soul,"query_msgin");
    if (num == 2) mmsgin = call_other(soul,"query_mmsgin");
    if (num == 3) msgout = call_other(soul,"query_msgout");
    if (num == 4) mmsgout = call_other(soul,"query_mmsgout");
    if (num == 5) {
        is_invis = call_other(soul,"query_invis");
	if (query_invis() > SOMEONE) {
	    cap_name = "Someone";
	} else {
	    cap_name = capitalize(name);
	}
    }
    if (num == 6) muffled = call_other(soul,"query_muffled");
    if (num == 7) alignment = call_other(soul,"query_alignment");
    if (num == 8) al_title = call_other(soul,"query_al_title");
    if (num == 9) msghome = call_other(soul,"query_msghome");
    if (num== 10) wkrm = call_other(soul, "query_alt_wkrm");
}

is_player() {
    return 1;
}

query_quests(str) {
    string tmp, rest, rest_tmp;
    int i;

    if (str == -1) {
	write("quests: "+quests+"\n");
	return;
    }
    if (str == 0) {
	return quests;
    }
    rest = quests;
    while (rest) {
	if (str == rest)
	    return 1;
	i = sscanf(rest, "%s#%s", tmp, rest_tmp);
	if (i == 0)
	    return 0;
	if (tmp == str)
	    return 1;
	if (i == 1)
	    return 0;
	rest = rest_tmp;
    }
    return 0;
}

/*
set_quest(q) {
    if (!q)
	return;
    if (query_quests(q))
	return 0;
    if (quests == 0)
	quests = q;
    else
	quests = quests + "#" + q;
    log_file("QUESTS", cap_name + " solved " + capitalize(q) + "'s quest.\n");
    return 1;
}

set_quest(q) {
    if (!q)
	return;
    if (query_quests(q))
	return 0;
    if (previous_object()) {
	log_file("QUESTS", name + ": " + q + " from " +
		 file_name(previous_object()) + ctime(time()) + "\n");
	if (this_player() && this_player() != this_object() &&
	  query_ip_number(this_player()))
	    log_file("QUESTS", "Done by " +
		     this_player()->query_real_name() + ctime(time()) + "\n");
    }
    if (quests == 0)
	quests = q;
    else
	quests = quests + "#" + q;
    return 1;
}
*/

set_gender(g) {
    if (g == "creature" || g == "male" || g == "female")
        gender = g;
}

query_gender() { return gender; }

query_call_outs() {
    write("active call_outs\n");
    dump_call_out("timeout");
    dump_call_out("intoxicate");
    dump_call_out("autosave");
    dump_call_out("autoheal");
}

dump_call_out(str) {
    int i;
    if ((i = find_call_out(str)) >= 0)
        write(str + ":\t" + i + "\n");
}

query_guild_rank() { return guild_rank; }

query_guild_exp() { return guild_exp; }

query_guild_file() { return guild_file; }

add_guild_rank(x) { guild_rank += x; }

add_guild_exp(x) { guild_exp += x; }

set_guild_file(str) { guild_file = str; }

static add_commands() {
    add_action("cmd_hook"); add_xverb("");
    add_action("location_unk", "church");
     add_action("logme","logme");
    add_action("give_object"); add_verb("give");
    add_action("reset_me","reset_me");
    add_action("mud_list"); add_verb("mudlist");
    add_action("set_pretitle"); add_verb("pretitle");
    add_action("wield_and_wear"); add_verb("ready");
    add_action("wield_and_wear"); add_xverb("#");
    add_action("set_mailaddr"); add_verb("setmail");
    add_action("score"); add_verb("score");
    add_action("score"); add_verb("sc");
    add_action("set_pl_k"); add_verb("kill_players");
    add_action("score2"); add_verb("score2");
    add_action("score2"); add_verb("sc2");
    add_action("save_character"); add_verb("save");
  if (this_object()->query_level() < CREATE) {
    add_action("quit"); add_verb("quit");
  } else
    add_action("do_quit", "quit");
    add_action("kill"); add_verb("kill");
    add_action("communicate"); add_verb("say");
    add_action("communicate"); add_xverb("\"");
    add_action("communicate"); add_xverb("'");
    add_action("shout_to_all"); add_verb("shout");
    add_action("put"); add_verb("put");
    add_action("pick_up"); add_verb("get");
    add_action("pick_up"); add_verb("take");
    add_action("drop_thing"); add_verb("drop");
    add_action("inv"); add_verb("i");
    add_action("look"); add_verb("look");
    add_action("look"); add_verb("l");
    add_action("examine"); add_verb("examine");
    add_action("examine"); add_verb("exa");
    add_action("help"); add_verb("help");
    add_action("tell"); add_verb("tell");
    add_action("whisper"); add_verb("whisper");
    add_action("change_password"); add_verb("password");
    add_action("idea"); add_verb("idea");
    add_action("typo"); add_verb("typo");
    add_action("bug"); add_verb("bug");
    add_action("converse"); add_verb("converse");
    add_action("toggle_brief"); add_verb("brief");
    add_action("toggle_whimpy"); add_verb("wimpy");
    add_action("stop_hunting_mode"); add_verb("stop");
    add_action("spell_missile"); add_verb("missile");
    add_action("spell_missile"); add_verb("mi");
    add_action("spell_shock"); add_verb("shock");
    add_action("spell_shock"); add_verb("sh");
    add_action("spell_fire_ball"); add_verb("fireball");
    add_action("spell_sonic","sonic");
    add_action("spell_sonic","so");
    add_action("spell_invis"); add_verb("invisible");
    add_action("visible"); add_verb("visible");
    add_action("spell_fire_ball"); add_verb("fi");
    add_action("pose"); add_verb("pose");
    add_action("soul"); add_verb("soul");
    add_action("describe"); add_verb("describe");
    add_action("emergency"); add_verb("emergency");
    add_action("glance"); add_verb("glance");
    add_action("who"); add_verb("who");
    add_action("go_north"); add_verb("n");
    add_action("go_south"); add_verb("s");
    add_action("go_west"); add_verb("w");
    add_action("go_east"); add_verb("e");
    add_action("go_northwest"); add_verb("nw");
    add_action("go_northeast"); add_verb("ne");
    add_action("go_southwest"); add_verb("sw");
    add_action("go_southeast"); add_verb("se");
    add_action("go_up"); add_verb("u");
    add_action("go_down"); add_verb("d");
  add_action("add_channel", "channel");
  add_action("remove_channel", "muffle");
  add_action("list_channels", "channels");
  add_action("have_sex","sex");
}
 
query_hostname()
{
	return (hostname ? hostname : query_ip_name ( this_object() ) );
}
static sethost()
{
	hostname = query_ip_name(this_object());
}


score2() {
write("Strength:       "+strength+"   Stamina:      " + stamina + "        Will Power: "+will_power + "\n");
write("Magic aptitude: " + magic_aptitude + "   Piety:        "+piety+"        Stealth:    "+stealth+"\n");
write("Luck:           " + luck + "   Intelligence: " +intelligence + "\n");
	return 1;
}

static ResetStats() {
	stamina = 8; intelligence = 8; will_power = 8; stealth = 8;
	magic_aptitude = 8; luck = 8; piety = 8; strength = 8;
}
who() {
	string sh,sh1,sh2,sh3,junk,junk2;
	int wlvl,x;
	object ob;

	ob = users();
	write(
"(=---------------------------------------------------------------------=)\n");
	for (x = 0; x < sizeof(ob); x++) {
		sh = ob[x]->short();
		if (sh && in_editor(ob[x])) sh = "[ " + sh + " ]";
                wlvl = ob[x]->query_level();
                if(sh)
                if(wlvl > 9) {
                sh = "{ "+wlvl+" }  "+sh;
                } else {
                sh = "{  "+wlvl+" }  "+sh;
                }
                sh1 =0;
                sh2 =0;
                sh3 =0;
		if (level < APPRENTICE) {
			if (!sh) continue;
			if (query_idle(ob[x]) >= 120) sh += " (idle)";
                        sh1=extract(sh, 0, 75);
                        if(strlen(sh) > 75)
                        sh2=extract(sh, 76, 140);
                        if(strlen(sh) > 140)
                        sh3=extract(sh, 141, 300);
                         if(sscanf(sh, "%s[%sm",junk,junk2) == 2) write(sh+"\n");
                        else {
                        write(sh1+"\n");
                        if(sh2) write("         "+sh2+"\n");
                        if(sh3) write("         "+sh3+"\n");
                        }
			continue;
		}
		if (sh) {
			if (query_idle(ob[x]) >= 120) sh += " (idle)";
                        sh1=extract(sh, 0, 75);
                        if(strlen(sh) > 75)
                        sh2=extract(sh, 76, 140);
                        if(strlen(sh) > 140)
                        sh3=extract(sh, 141, 300);
                         if(sscanf(sh, "%s[%sm",junk,junk2) == 2) write(sh+"\n");
                        else {
                        write(sh1+"\n");
                        if(sh2) write("         "+sh2+"\n");
                        if(sh3) write("         "+sh3+"\n");
                         }
			continue;
		}
		if (ob[x]->query_level() > level && ob[x]->query_invis() >= 45) continue;
		write("(Someone)\n");
	}
	write(
"(=---------------------------------------------------------------------=)\n");
	return 1;
}

set_home(str) {
    home = str;
}

query_home() {
    return home;
}

set_fight_area() {
      fight_area=file_name(environment(this_object()));
       return 1;
   }
clear_fight_area() {
      fight_area=0;
      return 1;
  }
query_fight_area() {
   return fight_area;
  }
query_pl_k() {
    if (player_killing) return 1;
    return 0;
  }
static set_pl_k() {
      if (call_other(this_object(), "query_real_name",0)=="guest")
      {
         write("Guest cannot be a player killer.\n");
         return 1;
       }
      if (level < 3){
     write("Your level is not high enough.\n");
       return 1;
}
   player_killing = 1;
  write("player killing has been set.\n");
  write("remember other people with player killing can now attack you.\n");
   return 1;
  }
query_interactive(){
     return is_interactive;
    }
set_mailaddr(addr) {
   if(!addr)
       return 0;
  mailaddr = addr;
  write("Your mail address is " + mailaddr + "\n");
 return 1;
}

query_mailaddr() {
  return mailaddr;
}

static getmailaddr(maddr) {
  mailaddr = maddr;
  if(mailaddr == "") mailaddr = "none";
  move_player_to_start(0);
}

raise_strength(arg){
         check_raise("strength",arg,strength);
      strength = strength + arg;
      write("Your strength is now " + strength + "\n");
      return 1;
     }
raise_intelligence(arg){
      check_raise("intell",arg,intelligence);
      intelligence = intelligence + arg;
      write("Your intelligence is now " + intelligence + "\n");
      return 1;
     }
raise_stamina(arg){
      check_raise("stamina",arg,stamina);
      stamina = stamina + arg;
      max_hp = ex_lv*2 + 42 + level * 8 + (stamina - 8)*8;
     if (max_hp < 5) max_hp = 5;
      write("Your stamina is now " + stamina + "\n");
      return 1;
     }
raise_will_power(arg){
            check_raise("willpower",arg,will_power);
      will_power = will_power + arg;
      write("Your will power is now " + will_power + "\n");
      return 1;
     }
raise_magic_aptitude(arg){
         check_raise("mag_apt",arg,magic_aptitude);
      magic_aptitude = magic_aptitude + arg;
      max_spell = 42 + ex_lv*3 + level * 8 + (magic_aptitude - 8)*8;
     if (max_spell < 0) max_spell = 0;
      write("Your magic aptitude is now " + magic_aptitude + "\n");
      return 1;
     }
raise_stealth(arg){
      check_raise("stealth", arg, stealth);
      stealth = stealth + arg;
      write("Your stealth is now " + stealth + "\n");
      return 1;
     }
raise_piety(arg){
       check_raise("piety", arg, piety);
      piety = piety + arg;
      write("Your piety is now " + piety + "\n");
      return 1;
     }
raise_luck(arg){
      check_raise("luck", arg, luck);
      luck = luck + arg;
      write("Your luck is now " + luck + "\n");
      return 1;
     }
query_attrib(str) {
    if (str == "str") return strength;
    if (str == "sta") return stamina;
    if (str == "wil") return will_power;
    if (str == "mag") return magic_aptitude;
    if (str == "pie") return piety;
    if (str == "ste") return stealth;
    if (str == "luc") return luck;
    if (str == "int") return intelligence;
    return 0;
   }
check_raise(str, vvv,zzz){
   int aaa;
      aaa = zzz + vvv;
    if (previous_object()) {
	log_file("ATTRIB", name + ": " + str + " raised by " + vvv + " from " + zzz + " to " + aaa  + " by " +
		 file_name(previous_object()) + "\n");
log_file("ATTRIB", name + " str-"+strength+" ste-"+stealth+" sta-"+stamina+" wil-"+will_power+" mag-"+magic_aptitude+" pie-"+piety+" lck-"+luck+" int-"+intelligence+
"\n");
	if (this_player() && this_player() != this_object() &&
	  query_ip_number(this_player()))
	    log_file("ATTRIB", "Done by " +
		     this_player()->query_real_name() + "\n");
    }
   return 1;
   }
wield_and_wear() {
string name_of_item;
name_of_item = first_inventory(this_player());
while (name_of_item) {
       object next;
       object str;
       string ob;
       next = next_inventory(name_of_item);
       str = name_of_item->short();
       if (str) {
       write (str+ "...\n");
       ob = name_of_item->query_name();
       name_of_item->wear(ob);
name_of_item->wield(ob);
       }
name_of_item = next;
   }
return 1;
}
mud_list() {
    call_other("/closed/wiz_soul", "more", "/doc/mudlist");
     return 1;
   }
discon_quit(){
      object bbx;
           bbx = clone_object("obj/discon.c");
            move_object(bbx, environment(this_player()));
           call_other(bbx, "set_owner", name);
           move_object(this_object(), bbx);
           save_me();
           quit();
       return 1;
}
see_if_other(arg) {
  object check_copy;
   string tmp_name;
    tmp_name = name;
    name = 0;
    check_copy = find_player(tmp_name);
    if (!check_copy)
	check_copy = find_player("ghost of " + tmp_name);
    name = tmp_name;
    if (check_copy)
    {
        if (arg == 2)
        call_other(check_copy, "set_no_give", 1);
      if (arg == 1)
            call_other(check_copy, "set_no_give", 2);
       if (arg == 3)
        {
            destruct(check_copy);
            see_if_other(3);
        }
     }
 return 1;
}
set_no_give(arg) {
          if (arg == 1)
       no_give = 1;
        if (arg == 2)
              no_give = 0;
       return 1;
  }

set_crime(){
     if(crime) remove_call_out("clear_crime");
     crime = 1;
     call_out("clear_crime", 1800);
     return 1;
    }
query_crime() { return crime;}
clear_crime() {
    crime = 0;
    return 1;
}
reset_me(str) {
   object new_me;
    new_me=clone_object("obj/player.c");
    move_object(new_me, environment(this_object()));
     write("saving player file...\n");
     other_copy = this_object();
    save_me();
    exec(new_me, this_object());
    write("You now have a new player object.\n");
    write("Your items are in the box at your feet.\n");
    call_other(new_me, "the_new_me", name);
   discon_quit();
   destruct(this_object());
     return 1;
}
the_new_me(str){
object ob,next_ob;
   restore_object("players/"+str);
   load_auto_obj(auto_load);
   local_weight = 0;
   armor_class = 0;
   weapon_class = WEAPON_CLASS_OF_HANDS;
   enable_commands();
   add_commands();
   reset(1);
   myself=this_object();
  soul("on");
  init_channels();
  move_object(this_object(), environment(this_object()));
if (guild_file && guild_file && guild_file !="" && guild_file != 0)
    move_object(clone_object(guild_file), this_object());
   return 1;
}
query_al_title() {return al_title;}
set_al_title(al) {
  al_title = al;
 return 1;
}
static rm_pk() {
   player_killing = 0;
  }
set_guild_name(str){
        guild_name=str;
       return 1;
        }
query_guild_name(){return guild_name;}

setup_broadcast() { /* Added by Shadowhawk the NUISANCE for channels. */
  if (age < 1800) {
    write("Players less than one hour old are not allowed to broadcast.\n");
    return 0;
  }
  if (spell_points < 0) {
    write("You must have a positive number of spell points.\n");
    return 0;
  }
  if (ghost) {
    write("You have no vocal cords!\n");
    return 0;
  }
  if (level < EXPLORE)
    spell_points -= 8;
  return 1;
}
add_ac(num){
   armor_class +=num;
   return 1;
  }
set_extra_level(arg) {
      ex_lv = arg;
      max_hp = ex_lv*2 + 42 + level * 8 + (stamina - 8)*8;
      max_spell = ex_lv*3 + 42 + level * 8 + (magic_aptitude - 8)*8;
      return 1;
}
query_extra_level(){return ex_lv;}
score() {
    int intox_level;
     string tmp;
      int tmpp;
    
    if (ghost) {
	write("You are in an immaterial state with no scores.\n");
	return 1;
    }
    write("\n");
    write(short()+"\n");
    write("Level: "+level);
    if(!ex_lv) write("\n");
    if(ex_lv) write("     \t\tExtra Level: "+ex_lv+"\n");
   write("Coins: "+money+"          \t\tExperience: "+experience+"\n");
    write("Hit points: "+hit_point+"/"+max_hp+"     ");
    write("\t");
    write("Spell points: "+spell_points+"/"+max_spell+"\n");
    write("Quest points: "+quest_point+"\n");
    show_age();
    if(pregnancy) {
    tmpp=age-pregnancy;
    write("You are Pregnant ("+tmpp+" / 16200)\n");
    }
    if (hunter && call_other(hunter, "query_name"))
        write("You are hunted by " + call_other(hunter, "query_name") + ".\n");
    if (!intoxicated)
	write("You are sober.\n");
    else {
	intox_level = (level + 4) / intoxicated;
	if (intox_level == 0)
	    write("You are in a drunken stupor.\n");
	else if (intox_level == 1)
            write("You are roaring drunk.\n");
	else if (intox_level == 2)
	    write("You are somewhat drunk.\n");
	else if (intox_level == 3)
	    write("You are quite tipsy.\n");
	else
	    write("You are slightly tipsy.\n");
    }
    if (stuffed || soaked)
    {
	tmp = "You are ";

        if (stuffed)
	{
	    tmp += "satiated";

	    if (soaked)
		tmp += " and ";
	    else
		tmp += ".\n";
	}

	if (soaked)
	    tmp += "not thirsty.\n";

	write(tmp);
    }

    if (whimpy)
	write("Wimpy mode.\n");
    write("\n");
    return 1;
}

static spell_sonic(str) {
    object ob;
    if (test_dark())
	return 1;
    if (ex_lv < 5)
	return 0;
    if (!str)
	ob = attacker_ob;
    else
	ob = present(lower_case(str), environment(this_player()));
    if (!ob || !living(ob)) {
	write("At whom?\n");
	return 1;
    }
    if (ob == myself) {
       write("Your ears feel like they are going to explode.\n");
	return 1;
    }
   spell_object(ob,"sonic blast",20+random(25),25);
    return 1;
}

set_attrib(str,arg){
  if (str=="str") strength = arg;
  if (str=="int") intelligence = arg;
  if (str =="sta") stamina =arg;
  if (str =="pie") piety = arg;
  if (str =="luc") luck = arg;
  if (str =="ste") stealth = arg;
  if(str=="wil") will_power = arg;
  if(str=="mag") magic_aptitude = arg;
  log_file("EXPERIENCE","set_attrib - "+name+" "+str+" "+arg+" by "+this_player()->query_real_name()+"\n");
  if(previous_object())
  log_file("EXPERIENCE",file_name(previous_object())+"-^\n");
  return 1;
}
logme() {
     log_file("STAT",extract(ctime(time()),0,15)+"\n");
    log_file("STAT",name+" "+experience+"-ep "+money+"-g "+level+"-lv "+ex_lv+"-xlv "+strength+"-str "+intelligence+"-int\n");
     log_file("STAT",stamina+"-sta "+will_power+"-wil "+magic_aptitude+"-mag "+piety+"-pie "+stealth+"-ste "+luck+"-luc "+age+"-age\n");
     log_file("STAT","QUESTS:"+quests+"\n");
     log_file("STAT","\n");
    write("Your record has been entered.\n");
    return 1;
}
/*
   for fake death purposes.... set dead =2 for feign death.
*/
set_dead(arg) { 
   dead=arg;
   return 1;
  }
query_dead(){ return dead;}
describe() {
	current_room = "";
	input_to("get_desc");
	write("Enter description. End with '**', abort with '~q'.\n");
	write("~>>");
	return 1;
}

get_desc(str) {
   no_give = no_give + 1;
	if (str == "~q") {
		write("aborted.\n");
		current_room = "";
		return;
	}
        if (str=="**" || no_give > 10) {
                description = current_room + "\n";
                current_room=file_name(environment(this_player()));
                no_give = 0;
		write("Ok.\n");
		return;
	}
	current_room = current_room + str + "\n";
	write("~>>");
	input_to("get_desc");
}
add_phys_at(num,arg) {
/* change height and weight  1=height feet, 2=height inches, 3=weight */
    phys_at[num] += arg;
    return 1;
}
query_phys_at(num) {
      return phys_at[num];
     }

static new_weight(str) {
     if(sscanf(str,"%d",phys_at[0]) !=1) {
        write("Please select an integer weight: ");
        input_to("new_weight");
       }
        sscanf(str, "%d", phys_at[3]);
    if(phys_at[3] > 85 && phys_at[3] < 400) {
        phys_at[0]=1;
        move_player_to_start(0);
    } else {
        write("please select a weight between 85 and 400 lbs: ");
	input_to("new_weight");
    }
}
static new_feet(str) {
     if(sscanf(str,"%d",phys_at[0]) !=1) {
        write("Please select an integer number: ");
        input_to("new_feet");
       }
        sscanf(str, "%d", phys_at[1]);
    if((race=="human" && phys_at[1] > 3 && phys_at[1] < 8) || (race=="elf" && phys_at[1] > 2 && phys_at[1] < 6) || (race=="dwarf" && phys_at[1] > 2 && phys_at[1] < 5)) {
        phys_at[0]=1;
        write("inches (1 in = 2.54 cm) : ");
        input_to("new_inch");
    } else {
        write("please select a height within race limits: ");
        write("\n");
        write("human, 4 to 7 ft.\telf, 3 to 5 ft.\tdwarf, 3 to 4 ft.\n");
        write(": ");
	input_to("new_feet");
    }
}
static new_inch(str) {
     if(sscanf(str,"%d",phys_at[0]) !=1) {
        write("Please select an integer number: ");
        input_to("new_inch");
       }
        sscanf(str, "%d", phys_at[2]);
    if(phys_at[2] > -1 && phys_at[2] < 12) {
        phys_at[0]=1;
        write("Please enter a weight for your character (in lbs. 1 kg = 2.2 lbs): ");
        input_to("new_weight");
    } else {
        write("please select a number from 0 to 11 inches: ");
	input_to("new_inch");
    }
}
location_unk() {
    if(!environment(this_object())) {
    move_object(this_object(), "room/church");
   }
 return 1;
}
query_limited_shadow() { return 1;}
new_race(str) {
str=lower_case(str);
    if (str == "elf" || str == "human" || str == "dwarf") {
        race = str;
        do_race();
        reset();
         write("Please enter a height for your character.\nfeet (1 ft = 0.305 m) : ");
     input_to("new_feet");
    } else {
      write("Choose a race for your character, you may select:\n");
      write("human\telf\tdwarf\n");
        input_to("new_race");
    }
}
do_race() {
     if (race=="human") return 1;
     if (race=="elf") {
         strength -= 1;
         intelligence += 1;
         stamina -= 1;
         magic_aptitude += 1;
      }
      if (race=="dwarf") {
          strength += 2;
          intelligence -= 2;
       }
return 1;
}
query_race() { return race; }
