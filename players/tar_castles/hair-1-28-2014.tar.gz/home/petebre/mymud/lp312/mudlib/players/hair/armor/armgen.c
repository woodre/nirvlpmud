inherit "obj/armor";

reset(arg){
   ::reset(arg);

   set_name("armorname");
   set_short("shortdesc");
   set_alias("alias");
   set_long("longdesc\n");
   set_type("boots");

   /* options for set_type() are...boots, armor, helmet, shield, ring,*
    * amulet, glove, cloak, and misc. 				      */

   set_ac(1);
   set_weight(2);
   set_value(100);
}
