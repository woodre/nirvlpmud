inherit "room/room";

reset(arg) {

if(!arg) {

set_light(1);
short_desc="Swampy Creek";
long_desc=
"You have stepped into a creek. There are water lilies growing on the water.\n"+
"It is a very creepy area. There is a sign here.  Maybe you should read it.\n";

items=({
  "sign","Maybe you should read it!",
});

dest_dir=({
   "/players/hair/rooms/path1.c","shore",
});

}}


init() {
  ::init();
   add_action("read_sign","read");
}


read_sign() {
 write("You feel as if you are going to be.....\n\n"+
       "			            ATTACKED!!!!!!!!\n\n\n"+
       "at any minute......MUHAHAHAHAHAHAHAHA!!!!!!\n\n");
 say(this_player()->query_name() +" reads the sign and shall perish.\n");
 write("The hungry Alligator storms out of the swamp with his mouth open.\n");
 if(!present("alligator")) {
  move_object(clone_object("/players/hair/monsters/alligator.c"),this_object());
 }
}
