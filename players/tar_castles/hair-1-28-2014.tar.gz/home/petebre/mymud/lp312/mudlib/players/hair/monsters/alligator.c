inherit "/obj/monster";

reset(arg) {
 ::reset(arg);

 if(!arg) {

  set_name("Alligator");
  set_alias("alligator");
  set_short("A Fierce Hungry Alligator");
  set_long("The Alligator has his mouth wide open waiting to gnaw on you.\n");
/*move_object(clone_object("/players/hair/armors/filename.c"),this_object());
  move_object(clone_object("/players/hair/weapons/filename.c"),this_object());
  init_command("wear armor");
  init_command("wield weapon");*/
  set_level(25);
  set_hp(400);
  set_wc(50);
  set_ac(5);
  set_al(-500);
  set_aggressive(1);
  set_chat_chance(10);
  set_a_chat_chance(10);
/*load_chat("msg");*/
  load_a_chat("The Alligator gnaws at your bones.\n");
 }
}
