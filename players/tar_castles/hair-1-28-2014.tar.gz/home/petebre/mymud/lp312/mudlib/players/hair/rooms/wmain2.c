inherit "room/room";
 
reset(arg) {
 
if(!arg) {
 
set_light(1);
short_desc="200 Block of West Main Street";
long_desc=
"This is the 200 Block of West Main Street. To the north, you see an armor\n"+
"shop of some sort. There are citizens of Hazzard County walking through\n"+
"the streets here. The road dead ends here except for the shop to the north\n";
 
items=({
     "shop","It is a hardware shop. Maybe they have weapons.....",
});
 
dest_dir=({
     "/players/hair/rooms/weapon_shop.c","north",
     "/players/hair/rooms/wmain1.c","east",
});
 
}}

