inherit "room/room";

reset(arg) {

if(!arg) {

  set_light(1);
short_desc="Dirt Road through Hazzard County";
long_desc=
"You are on the road that continues into Hazzard County. Watch out\n"+
"for the Good 'ol Boys driving by in the General Lee. (If you don't remember,\n"+
"that is the orange 1978 Dodge Charger with 01 painted on the side.)\n"+
"You see a sign here with directions. There is also a swamp to the east.\n";

items=({
  "sign","It is a sign with the milage to town...Maybe you should 'read' it",
   "swamp","It is a swampy area....YUCK!",
});

dest_dir=({
  "/players/hair/rooms/enterance.c","north",
  "/players/hair/rooms/path2.c","south",
  "/players/hair/rooms/swamp.c","east",
  });
}
}


init() { 
 ::init();
  add_action("read_sign","read");
}

read_sign() {
  write("County Road X\n\n"+
         "City Hall                      5 Miles\n"+
         "County Jail                    5 Miles\n"+
         "Cooter's Garage                6 Miles\n"+
         "Dukes' Farm House              8 Miles\n");
  say(this_player()->query_name() +" reads the sign.\n");
  return 1;
}
