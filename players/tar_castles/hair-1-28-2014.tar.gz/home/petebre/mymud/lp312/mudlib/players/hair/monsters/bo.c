inherit "/obj/monster.c";

reset(arg) {
::reset(arg);
if(!arg) {
set_name("Bo");
set_alias("bo");
set_short("Bo Duke");
set_long("Bo Duke.\n"+
	"Just a Good 'ol boy never meaning no harm.  One of those country\n"+
	"boys.  One renegade of Hazzard County.\n");
move_object(clone_object("/players/hair/weapons/crossbow.c"),this_object());
move_object(clone_object("/players/hair/armor/flannel.c"),this_object());
init_command("wear shirt");
init_command("wield bow");
set_level(15);
set_hp(500);
set_wc(17);
set_ac(10);
set_al(700);
set_aggressive(0);
set_chat_chance(10);
set_a_chat_chance(5);
load_chat("Bo says: I wish that Luke would quit getting me into trouble.\n");
load_chat("Bo says: Yeeeeeee Haaaaawwww!\n");
load_a_chat("Bo lights the tip of an arrow and places it in his Crossbow.\n"+
	"He raises it up, pulls back the arrow, and fires.  BOOM!!!\n"+
	"You are engulfed in flames.\n");
}
}
