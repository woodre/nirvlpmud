
inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {

object gold;
  gold = clone_object("obj/money");
  gold->set_money(random(101) + 550);
  move_object(gold,this_object());

	set_name("Karen Wollscheid");
     set_short("Karen Wollscheid");
     set_race( "spirit");
     set_alias("karen");
set_long("Your eyes are stricken with desire as you gaze into her eyes.\n");
     set_level(19);
     set_ac(8 + random(3));
     set_wc(18 + random(3));
     set_hp(160 + random(40));
     set_al(-500);
     set_aggressive(0);
     set_chat_chance(7);
     set_a_chat_chance(7);
     load_chat("Karen puts her arm around you.\n");
    load_chat("Karen says: Hey Buddy!.\n");
     load_a_chat("Karen winks at you suggestively. She wants you.\n");
     load_a_chat("Karen throws you on the ground and rips off her clothes and starts having sex with you.\n");
   }
}
