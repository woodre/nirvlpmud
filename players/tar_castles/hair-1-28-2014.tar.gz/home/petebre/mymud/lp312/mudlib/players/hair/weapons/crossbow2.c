inherit "obj/weapon";
int i,x;
reset(arg) {
 ::reset(arg);
 if(arg) return;
  set_alias("bow");
  set_name("Flaming Crossbow");
  set_short("A Flaming Crossbow");
  set_long("A Flaming Crossbow.  Bo and Luke Duke's favorite weapon.\n"+
           "It is EXPLOSIVE of sorts.\n");
  set_class(22);
  set_weight(2);
  set_value(5000);
  set_hit_func(this_object());
 }

 weapon_hit(attacker) {
  if(this_player()->query_alignment() > 500) {
  say(this_player()->query_name() + " shoots like the Good 'ol Boys!\n");
  write("Your shot EXPLODES as it hits your target!\n");
  write("Your enemy is severely hurt.\n");
  i = random(5);
  x= 0;
  x= i + 17;
 }
 return x;
}
