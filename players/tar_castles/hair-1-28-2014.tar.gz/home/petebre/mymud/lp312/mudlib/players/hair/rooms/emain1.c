inherit "room/room";
 
reset(arg) {
 
if(!arg) {
 
set_light(1);
short_desc="100 Block of East Main Street";
long_desc=
"This is the 100 Block of East Main Street. To the north, you see a toy\n"+
"shop of some sort. There are little children here looking in the windows\n"+
"at all of the wonderful toys inside. The road continues on to the east,\n"+
"leading towards some more shops.\n";
 
items=({
     "shop","It is a cute little toy shop. Maybe you should check it out",
});
 
dest_dir=({
     "/players/hair/rooms/toy_shop.c","north",
     "/players/hair/rooms/emain2.c","east",
     "/players/hair/rooms/city1.c","west",
});
 
}}

