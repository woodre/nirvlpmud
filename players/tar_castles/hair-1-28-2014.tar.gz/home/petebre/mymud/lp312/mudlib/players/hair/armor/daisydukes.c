inherit "obj/armor";

reset(arg){
   ::reset(arg);

   set_name("Daisy Dukes");
   set_short("Daisy Dukes Shorts");
   set_alias("shorts");
   set_long("Wow they are mighty small. I don't know if you will be able to\n"+
	    "wear them at all.\n);
   set_type("armor");
   /* options for set_type() are...boots, armor, helmet */
   set_ac(1);
   set_weight(2);
   set_value(2500);
}
