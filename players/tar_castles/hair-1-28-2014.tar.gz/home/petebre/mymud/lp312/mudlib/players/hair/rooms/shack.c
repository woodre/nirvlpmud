inherit "room/room";

int searched;
reset(arg) {


if(!arg) {

set_light(1);
short_desc="An old wooden shack";
long_desc=
"It is an old wooden shack. It looks like it could have been used as a\n"+
"hideout. Maybe you should 'search' the place.\n";

/*
items=({

});
*/

dest_dir=({
  "/players/hair/rooms/path2.c","out",
});

}}


init() {
  ::init();
   add_action("search","search");
}

search() {
   if(searched == 1) {
    write("You find nothing more.\n");
   return 1; }
   else
    searched = 1;
  move_object(clone_object("/players/hair/monsters/burglar.c"),this_object());
  move_object(clone_object("/players/hair/monsters/burglar.c"),this_object());
  write("You see a couple of Burglars here with money sacks.\n");
   return 1;
}

