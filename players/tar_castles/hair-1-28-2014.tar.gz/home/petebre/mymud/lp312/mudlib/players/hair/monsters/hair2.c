inherit "/obj/monster";

reset(arg) {
 ::reset(arg);
 if (!arg) {
  set_name( "hair" );
  set_alias("android");
  set_short("An Android of the Almighty Wizard Sanborn Hair");
  set_long("This is an android of Sanborn Hair. Do not attack him if you\n"+
  	   "wish to continue living. He is very powerful and has been placed\n"+
	   "here to protect the magnificent Hazzard County (coded by Hair).\n");
  set_level(100);
  set_ac(14);
  set_wc(150);
  set_hp(100000);
 
  move_object(clone_object("/players/hair/weapons/blade.c"),this_object());
  init_command("fuck_wield blade");
 
  set_al(1000);
  set_aggressive(0);
  set_chat_chance(9);
  set_a_chat_chance(20);
  load_chat("Hair says: Please continue along the Dirt Road into Hazzard County.\n");
  load_chat("Hair says: Don't forget to read the sign before you proceed.\n");
  load_a_chat("Hair knows you cannot kill him.\n");
  load_a_chat("Hair announces: Thou shalt not kill me.\n");
   }
}

