inherit "/obj/monster";

reset(arg) {
 ::reset(arg);

 if(!arg) {

  set_Uncle Jessie("name");
  set_uncle("alias");
 set_short("Uncle Jessie");
 set_long("Uncle Jessie.\n"+
	"He is the elder member of the Duke family. He is here to watch over\n"+
	"the farm when the boys aren't around.\n\n"+
	"P.S. Don't forget to try his famous Moonshine.\n");
  move_object(clone_object("/players/hair/heals/moonshine.c"),this_object());
  set_level(22);
  set_hp(650 + random(350));
  set_wc(34);
  set_ac(18);
  set_al(500);
  set_aggressive(0); /* 1 -> Aggressive, 0 -> Non-aggressive */
  int gold;
   object gold;
  gold = clone_object("obj/money");
  gold->set_money(random(101) + 550);
  move_object(gold,this_object());

  set_chat_chance(10);
  set_a_chat_chance(10);
  load_chat("Uncle Jessie says: Would you like to buy some Moonshine?");
  load_a_chat("Uncle Jessie BASHES you over the head with a bottle of moonshine.");
 }
}
