inherit "/obj/monster";

object gold;

reset(arg) {
 ::reset(arg);

 if(!arg) {

  set_name("Burglar");
  set_alias("burglar");
  set_short("Burglar");
  set_long("The burglar has two money bags in his hands. I guess you could \n"+
  	  "say that you caught him red handed. He must have stolen the money.");
/*move_object(clone_object("/players/hair/armors/filename.c"),this_object());
  move_object(clone_object("/players/hair/weapons/filename.c"),this_object());
  init_command("wear armor");
  init_command("wield weapon");*/
  set_level(32);
  set_hp(750 + random(750));
  set_wc(30 + random(5));
  set_ac(35);
  set_al(-500);
  set_aggressive(1); /* 1 -> Aggressive, 0 -> Non-aggressive */

  gold = clone_object("obj/money");
  gold->set_money(random(1500) + 7500);
  move_object(gold,this_object());

  set_chat_chance(10);
  set_a_chat_chance(10);
  load_chat("Burglar says:  Get Outta Here!\n");
  load_a_chat("Burglar says:  Get Outta Here!\n");
  load_a_chat("The Burglar bashes you over the head with a money bag.\n");
 }
}
