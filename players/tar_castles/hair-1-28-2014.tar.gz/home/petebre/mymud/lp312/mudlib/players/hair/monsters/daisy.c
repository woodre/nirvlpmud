inherit "/obj/monster.c";

reset(arg) {
::reset(arg);

if(!arg) {

set_name("Daisy");
set_alias("daisy");
set_short("Daisy Duke");
set_long("Daisy Duke.\n"+
	"The Beautiful Daisy Duke....and she is lookin' mighty fine in those tight\n"+
	"shorts.\n");

move_object(clone_object("/players/hair/armors/daisydukes.c"),this_object());
init_command("wear shorts");

set_level(15);
set_hp(350);
set_wc(13);
set_ac(4);
set_al(500);
set_aggressive(0);
set_chat_chance(10);
load_chat("Daisy sees you and immediately grabs her CB radio.\n");
load_chat("Daisy says: Little Bo Peep to Lost Sheep. Boys, are you there?\n");
load_chat("Daisy says: Some people are here, I think they want trouble.\n");
}
}
