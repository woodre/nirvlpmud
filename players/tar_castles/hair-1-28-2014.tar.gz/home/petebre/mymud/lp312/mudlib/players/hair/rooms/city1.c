inherit "room/room";
 
reset(arg){
 
if(!arg) {
 
  set_light(1);
short_desc="Intersection of the Dirt Path and Main Street";
long_desc=
"You are now standing at the corner of the Dirt Path and Main Street.\n"+
"City Hall and the County Jail are further south as well as the rest of\n"+
"the city. There are shops to the east and to the west.\n\n"+
"The speed limit here is still only 10 MPH, and Roscoe P. Cotrain will\n"+
"arrest you for WALKING too fast. So Beware.\n";
 
dest_dir=({
  "/players/hair/rooms/path3.c","north",
  "/players/hair/rooms/city2.c","south",
  "/players/hair/rooms/wmain1.c","west",
  "/players/hair/rooms/emain1.c","east",
  });
}}

