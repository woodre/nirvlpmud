inherit "room/room";
 
reset(arg) {
 
if(!arg) {
 
set_light(1);
short_desc="100 Block of West Main Street";
long_desc=
"This is the 100 Block of West Main Street. To the north, you see an armor\n"+
"shop of some sort. There are citizens of Hazzard County walking through\n"+
"the streets. The road continues on to the west for at least one more\n"+
"block.\n";
 
items=({
     "shop","It is a heavy duty armor shop. Maybe you should check it out",
});
 
dest_dir=({
     "/players/hair/rooms/armor_shop.c","north",
     "/players/hair/rooms/city1.c","east",
     "/players/hair/rooms/wmain2.c","west",
});
 
}}

