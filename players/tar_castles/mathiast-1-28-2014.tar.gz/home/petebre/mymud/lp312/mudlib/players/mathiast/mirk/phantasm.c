inherit "/obj/monster";

reset(arg) 
{
   ::reset(arg);
   if (!arg) 
      {
      set_name("phantasm");
      set_race( "spirit");
      set_short("A Phantasm");
      set_long("Is this real or a figment of your imagination?\n"+
         "It looks like someone you once knew, but it can't be!\n");
      set_level(11);
      set_wc(15);
      set_ac(10);
      set_hp(150);
      set_al(-150);
      set_chat_chance(10);
      load_chat("A voice whispers: Leave this place...\n");
      set_a_chat_chance(10);
      load_a_chat("A chill runs down your spine.\n");
      add_money(random(500));
   }
}
