#include "/obj/clean.c"

id(str){ return str=="magic"; }
query_name(){ return "magic"; }
short(){ return; }
long(){
   if(this_player()->query_level()<30){
      write("This object does not exist in your reality!\n");
      return 0;
   }
   else write("This is magic!\n");
   return 1;
}

get(){ return 1; }
drop(){ return 1; }
query_weight(){ return 0; }
query_value(){ return 60000; }

init(){
   if(this_player()->query_level()<30){
      destruct(this_object());
      return 0;
   }
   add_action("scan","scan");
}

scan(str){
   object ob;
   object gold;
   ob = find_player(str);
   if(!ob) ob = present(str);
   if(!ob) ob = present(str, environment(this_player()));
   if(!ob)
      {
      notify_fail("There is no "+str+" here.\n");
      return 0;
   }
   if(ob->is_player()){
      write(ob->short()+"\n");
      write("Level: "+ob->query_level()+"\n");
      write("Exp:   "+ob->query_exp()+"\n");
      write("Money: "+ob->query_money()+"\n");
      write("HP:    "+ob->query_hp()+"/"+ob->query_mhp()+"\n");
      write("SP:    "+ob->query_sp()+"/"+ob->query_msp()+"\n");
      write("WC:    "+ob->query_wc()+"\n");
      write("AC:    "+ob->query_ac()+"\n");
      write("Align: "+ob->query_alignment()+"\n");
      return 1;
   }
   else if(living(ob)){
      write(file_name(ob)+"\n");
      write(ob->short()+"\n");
      write("Level: "+ob->query_level()+"\n");
      write("Exp:   "+ob->calculate_worth()+"\n");
      gold = present("coins",ob);
      if(gold) write("Money: "+gold->short()+"\n");
      else write("Money: 0\n");
      write("HP:    "+ob->query_hp()+"/"+ob->query_mhp()+"\n");
      write("WC:    "+ob->query_wc()+"\n");
      write("AC:    "+ob->query_ac()+"\n");
      write("Align: "+ob->query_alignment()+"\n");
      return 1;
   }
   else if(ob->weapon_class()){
      write(file_name(ob)+"\n");
      write(ob->short()+"\n");
      write("WC:     "+ob->weapon_class()+"\n");
      write("Wear:   "+ob->query_wear()+"\n");
      write("Value:  "+ob->query_value()+"\n");
      write("Weight: "+ob->query_weight()+"\n");
      return 1;
   }
   else if(ob->armor_class()){
      write(file_name(ob)+"\n");
      write(ob->short()+"\n");
      write("AC:     "+ob->armor_class()+"\n");
      write("Type:   "+ob->query_type()+"\n");
      write("Value:  "+ob->query_value()+"\n");
      write("Weight: "+ob->query_weight()+"\n");
      return 1;
   }
   else
      {
      write(file_name(ob)+"\n");
      write(ob->short()+"\n");
      write("Value: "+ob->query_value()+"\n");
      write("Weight: "+ob->query_weight()+"\n");
      return 1;
   }
   
}
