inherit "/obj/monster.c";

reset(arg){
   ::reset(arg);
   if(!arg){
      set_name("knight");
      set_race("human");
      set_alias("blue knight");
      set_short("A Royal Knight Dressed in Blue");
      set_long(
         "This is a royal knight wields his powerful longsword with \n"+
         "practiced skill. He wears a blue steel breastplate and a blue \n"+
         "hooded cloak. The blue crest on his breastplate symbolizes his \n"+
         "nobility. This warrior is known throughout the land as a symbol \n"+
         "of magestic power and royal might. \n");
      set_level(20);
      set_hp(500);
      set_wc(30);
      set_ac(20);
      set_al(500);
      set_chance(10);
      set_spell_dam(20);
      set_spell_mess1("The knight smashes you with devestating blow.\n");
      set_spell_mess2("The knight smashing his foe with a devestating blow.\n");
      add_money(2500);
    move_object(clone_object("/players/mathiast/obj/weapons/blue_longsword.c"), this_object());
    move_object(clone_object("/players/mathiast/obj/armor/blue_plate.c"), this_object());
   }
}
