inherit "room/room";

reset(arg)
{
   if(!arg)
      {
      set_light(1);
      short_desc="A wide open plain.";
      long_desc=
      "You are on a wide open plain.\n"+
      "There is nothing much of interest to see here.\n";
      
      dest_dir=
      ({
            "/players/mathiast/rooms/enter.c","east",
            "/players/mathiast/rooms/plain_2w.c","west",
       });
   }   
}


init()
{
   ::init();
   add_action("search_room","search");
}

search_room()
{
   write("You search but find nothing.");
   say (this_player()->query_name() +" searches the area\n");
   return 1;
}

