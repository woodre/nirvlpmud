#define EXITS "church, post, adv"
#define COM   "ears, shields, flick"
#define MATH_EXITS "more to come"
#define NOTIN \
"Mathiast is not in right now.  Please leave a message at the post office.\n"
#define BUSY \
"Mathiast is busy right now.  Please stop by some other time.\n"
string Ears, Shields, Lights;
string *Exits, *Dests, *MyExit;

reset(arg){
   if(arg) return;
   enable_commands();
   set_light(1);
   Ears = "off";
   Shields = "off";
   Lights = "on";
   Exits =
   ({ "church", "post", "adv", });
   Dests =
   ([ "church":"/room/church", "post":"/room/post", "adv":"/room/adv_guild", ]);
}
init(){
   int x;
   if(!present("mathiast")){
      write(NOTIN);
      this_player()->move_player("off the shields#/room/church");
      return 1;
   }
   if(this_player()->is_player() && Shields=="on" && !is_mathiast()){
      write(BUSY);
      this_player()->move_player("off the shields#/room/church");
      return 1;
   }
   if(is_mathiast()){
      add_action("toggle_ears","ears");
      add_action("toggle_shields","shields");
      add_action("toggle_lights","flick");
/*
   for(x=0;x<sizeof(MyExit);x++){ add_action("move",MyExit[x]); }
*/
   }
   for(x=0;x<sizeof(Exits);x++){
      add_action("move",Exits[x]);
   }
}

is_mathiast(){
   if(this_player()->query_real_name()=="mathiast") return 1;
}
static toggle_ears(){
   if(Ears == "off") Ears="on";
   else Ears="off"; 
   write("Ears turned "+Ears+".\n");
   return 1; 
}
static toggle_shields(){
   if(Shields=="off") Shields="on";
   else Shields="off";
   write("Shields turned "+Shields+".\n");
   return 1; 
}
static toggle_lights(){
   if(Lights=="on") Lights="off";
   else Lights="on";
   write("Lights turned "+Lights+".\n");
   return 1; 
}
move(){
   string com, dest;
   com = query_verb();
   dest = Dests[com];
   this_player()->move_player(com+"#"+dest);
   return 1;
}
short(){ return "Home Sweet Home"; }
long(){
   if(is_mathiast())
      write("This is your workroom.\n"+
      "Shields "+Shields+".     Ears "+Ears+".     Lights "+Lights+".\n"+
      "Commands:  "+COM+".\n"+
      "Exits:    "+EXITS+", "+MATH_EXITS+".\n");
   else if(Lights=="off") write("It is too dark.\n");
   else write("This is the workroom of Mathiast.\n"+
         "Exits:  "+EXITS+".\n");
   return 1;
}
catch_tell(str){
   if(!present("mathiast")) Ears = "off"; 
   if(Ears=="on") 
      tell_object(present("mathiast"),"Ears :=->\n"+str+"*END*\n");
   return 1;
}
