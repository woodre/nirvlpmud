inherit "/room/room.c";

reset(arg){
   if(arg) return;
   set_light(1);
   short_desc = "Main St. Genoa";
   long_desc = 
   format("	You are on the main street in Genoa.  The business district is to the east.  There is a bar to the north, and an inn to the south.",65);
   dest_dir = ({ "/players/mathiast/room/town/bar.c","north",
         "/players/mathiast/room/town/inn.c","south",
         "/players/mathiast/room/town/market.c","east",
         "/players/mathiast/room/town/enter.c","west", });
}
