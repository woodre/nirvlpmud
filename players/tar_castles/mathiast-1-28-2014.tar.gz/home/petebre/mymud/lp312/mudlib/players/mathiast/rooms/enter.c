inherit "room/room";

reset(arg)
{
   if(!arg)
      {
      set_light(1);
move_object(clone_object("/players/mathiast/rooms/portal.c"), this_object());
      short_desc="A wide open plain.";
      long_desc=
      "You are in the middle of wide open plain. It stretches \n"+
      "as far as the eye can see in every direction. The tall \n"+
      "grass here sways gently in the wind.\n";
      
      dest_dir=
      ({
            "/players/mathiast/rooms/plain_n.c","north",
            "/players/mathiast/rooms/plain_s.c","south",
            "/players/mathiast/rooms/plain_e.c","east",
            "/players/mathiast/rooms/plain_w.c","west",
       });
   }
}


init()
{
   ::init();
   add_action("search_room","search");
}

search_room()
{
   write("You search but find nothing.");
   say (this_player()->query_name() +" searches the area\n");
   return 1;
}

