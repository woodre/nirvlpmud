inherit "/room/room.c";

reset(arg){
  if(!arg){
    set_light(1);
    short_desc = "The Briarwoods";
    long_desc = 
    "You have entered the briarwoods. This is an ancient wilderness \n"+
    "full of myth and lore. Many magical creatures inhabit this area. \n"+
    "You are surrounded by rolling hills and green pastures. Small \n"+
    "trees and thickets of briars spot the landscape everywhere.\n";
    dest_dir = ({ 
      "/players/mathiast/workroom.c", "north", 
      "/players/mathiast/workroom.c", "south", 
      "/players/mathiast/workroom.c", "east",  
      "/players/mathiast/workroom.c", "west", });
  }
}

init(){
  ::init();
  add_action("search_room","search");
}

search_room(){
  write("You search but find nothing.\n");
  say(this_player()->query_name()+ " searches the area.\n");
  return 1;
}
