short(){ return "The Fireside Tavern"; }
long(){
   write("You have entered the Fireside tavern.\n\n"+
      "A sign above the bar reads:\n"+
      "	1. A draft style beer		200  gold coins.\n"+
      "	2. A strawberry daquerie	400  \n"+
      "	3. A whiskey sour		600  \n"+
      "	4. A shot of Goldenslager	1000 \n"+
      "	5. A cup of coffee		20   \n"+
      "You may 'order <#>'\n\n"+
      "The only obvious exit is south.\n");
}
string Drink;
int Intox, Heal, Cost;

reset(arg){
   if(arg) return;
   set_light(1);
   Drink = ({ "draft style beer","strawberry daquerie","whiskey sour","shot Goldenslager","cup of coffee", });
   Intox = ({ 1,2,3,4,-2 });
   Heal = ({ 10,20,30,50,0 });
   Cost = ({ 200,400,600,1000,20 });
}

get_drink(drink,intox,heal,cost){
   string name;
   name = this_player()->query_name()+" ";
   if(this_player()->query_money() < cost){
      notify_fail("The bartender says: You can't afford that, Jerk.\n");
      return 0;
   }
   if(this_player()->drink_alcohol(intox)==0){
      notify_fail("The bartender says: You've had enough, Buddy.\n");
      return 0;
   }
   this_player()->add_money(-cost);
   write("You order a "+drink+" and gulp it down.\n");
   say(name+" orders a "+drink+" and gulps it down quickly.\n");
   this_player()->heal_self(heal);
   return 1;
}

buy_drink(str){
   int i;
   if(!str) str = "?";
   sscanf(str,"%d",i);
   if(i<1 || i>5){
      notify_fail("The bartender grumbles: Order a number between one and five, Dipstick.\n");
      return 0;
   }
   return get_drink(Drink[i-1],Intox[i-1],Heal[i-1],Cost[i-1]);
}

init(){
   add_action("south","south");
   add_action("buy_drink","order");
}

south(){
   this_player()->move_player("south#/players/mathiast/room/town/main1.c");
   return 1;
}
