inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "The smell of death is all around. This is a dreadful mirky \n"+
      "place. It seems as though there is no escape.\n";
      this_room_num = 8;
   }
   if(!present("ghoul"))
      move_object(clone_object("/players/mathiast/mirk/ghoul.c"),this_object());
}
