inherit "/obj/monster.c";

reset(arg){
  ::reset(arg);
  if(!arg){
    set_name("bat");
    set_race("animal");
    set_short("A Black Bat");
    set_long(
      "This is your run of the mill bat. It a nasty flying rodent. It \n"+
      "is black and blind and rabid.\n");
    set_level(1);
    set_hp(15);
    set_wc(5);
    set_ac(3);
    set_al(0);
  }
}
