inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "Eerie noises penetrate the silence of the night. Your fear \n"+
      "begins to grow. You don't know which way to turn. You feel that \n"+
      "you must find a way out of here.\n";
      this_room_num = 6;
   }
   if(!present("phantom"))
      move_object(clone_object("/players/mathiast/mirk/phantom.c"),this_object());
}

