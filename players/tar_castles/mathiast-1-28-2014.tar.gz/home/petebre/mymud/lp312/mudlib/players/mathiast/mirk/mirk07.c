inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "You get a feeling of impending doom. Voices seem to be \n"+
      "whispering in your head. Where do you go? What do you do?\n";
      this_room_num = 7;
   }
   if(!present("wraith"))
      move_object(clone_object("/players/mathiast/mirk/wraith.c"),this_object());
   
}
