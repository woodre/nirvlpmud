inherit "/room/room.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "A Wide Open Plain";
      long_desc = 
      "You are on a wide open plain. You smell some smoke coming from \n"+
      "the north. A strange mythical aura seems to be rising from the \n"+
      "south. To the west you see a strange mirk in the air.\n";
      dest_dir = ({
            "/players/mathiast/rooms/fireswamp/enter.c", "north",
            "/players/mathiast/rooms/briarwoods/enter.c", "south",
            "/players/mathiast/rooms/plain_w.c", "east",
 "/players/mathiast/mirk/enter.c","west"  });
      items = ({
            "smoke", 
            "The smoke to the north appears be very thick. Perhaps you should \n"+
            "go see what it is coming from.\n",
            "aura", "This is the stuff of myth and lore.\n",
            "mirk", "A foggy mirk.\n", });
   }
}

init(){
   ::init();
   add_action("search_room","search");
}

search_room(){
   write("You search but find nothing.\n");
   say(this_player()->query_name()+ " searches the area.\n");
   return 1;
}
