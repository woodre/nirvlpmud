inherit "/room/room.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Ever Forest";
      long_desc = 
      "You have come to a small clearing in the forest. There is an old \n"+
      "dead log lying on the ground. It is hollow and looks like it may \n"+
      "be inhabitted.\n";
      dest_dir = ({
            "/players/mathiast/rooms/ever/beaver_dam.c", "south",
            "/players/mathiast/rooms/ever/enter.c", "west", });
      items = ({
            "tree", "This hollow log looks like a good shelter for a small animal.\n", });
      
  if(!present("rabbit", this_object()))
         move_object(clone_object("/players/mathiast/living/rabbit.c"), this_object());
   }
}

init(){
   ::init();
   add_action("search_room","search");
}

search_room(){
   write("You search but find nothing.\n");
   say(this_player()->query_name()+ " searches the area.\n");
   return 1;
}
