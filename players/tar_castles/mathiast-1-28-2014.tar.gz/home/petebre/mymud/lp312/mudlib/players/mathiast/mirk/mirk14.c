inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "The light of moon barely penetrates the thick mist that \n"+
      "surrounds you. It gives only enough light to see in any \n"+
      "direction. You wonder: Where do I go from here?\n";
      this_room_num = 14;
   }
}
