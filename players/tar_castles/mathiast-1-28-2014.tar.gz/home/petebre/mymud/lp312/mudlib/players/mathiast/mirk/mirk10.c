inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "The aura of death is all around you. Your soul is filled with \n"+
      "fear. The blackness of the night seems to draw the life out of \n"+
      "you.\n";
      this_room_num = 10;
   }
   if(!present("reaper"))
      move_object(clone_object("/players/mathiast/mirk/grimm_reaper.c"),this_object());
}
