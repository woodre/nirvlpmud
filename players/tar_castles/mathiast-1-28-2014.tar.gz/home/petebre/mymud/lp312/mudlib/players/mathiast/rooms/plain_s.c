inherit "room/room";

reset(arg)
{
   if(!arg)
      {
      set_light(1);
      short_desc="A wide open plain.";
      long_desc=
      "You are on a wide open plain.\n" +
      "To the south is a large forest.\n";
      
      dest_dir=
      ({
            "/players/mathiast/rooms/enter.c","north",
            "/players/mathiast/rooms/ever/enter.c","south",
       });
   }   
}


init()
{
   ::init();
   add_action("search_room","search");
}

search_room()
{
   write("You search but find nothing.");
   say (this_player()->query_name() +" searches the area\n");
   return 1;
}

