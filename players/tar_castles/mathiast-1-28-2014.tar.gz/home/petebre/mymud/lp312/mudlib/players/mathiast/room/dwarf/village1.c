inherit "/room/room.c";
reset(arg){
   if(arg) return;
   set_light(1);
   short_desc = "Dwarvenbane";
   long_desc =
      "     You are within a large clearing.  The village of dwarvenbane\n"+
      "is here.  Before you is a small wooden bridge that leads over a\n"+
      "swift flowing creek and into the village.  \n";
   dest_dir = ({
      "/players/mathiast/room/dwarf/village2","west",
      "/players/mathiast/room/dwarvenbane","east",
       });
}
