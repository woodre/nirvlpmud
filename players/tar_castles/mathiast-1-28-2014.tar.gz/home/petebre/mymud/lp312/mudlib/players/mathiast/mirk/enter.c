inherit "/room/room.c";

reset(arg){
  if(!arg){
    set_light(1);
    short_desc = "Entrance to the Foggy Mirk";
    long_desc = 
      "To the west you see a dark cloud lingering at ground level. It \n"+
      "seems to smother out the light of day. There is a  wide open \n"+
      "plain lying to the east.\n";
    dest_dir = ({
      "/players/mathiast/rooms/plain_2w.c", "east",
      "/players/mathiast/mirk/mirk00.c", "west", });
    items = ({
      "cloud", 
      "It is dark and dreary. You hear strange nosies coming from it. \n"+
      "Do you dare enter it?\n", });
  }
}

init(){
  ::init();
  add_action("search_room","search");
}

search_room(str){
  write("You search but find nothing.\n");
  say(this_player()->query_name()+ " searches the area.\n");
  return 1;
}
