inherit "obj/monster";

reset(arg){
   object coins;
   ::reset(arg);
   if(arg) return;
   set_name("elf");
   set_race("elf");
   set_short("A Mischieveous Elf");
   set_long(
      "This mischievious little fellow wants to play a trick on you.\n"+
      "You had better keep your eye on him.\n");
   set_level(5);
   set_hp(100);
   set_al(0);
   set_wc(10);
   set_ac(5);
   set_chance(10);
   set_spell_dam(10);
   set_spell_mess1("The elf tickles you ferociously.\n");
   set_spell_mess2("The elf tickles someone.\n");
   add_money(100+random(100));
}
