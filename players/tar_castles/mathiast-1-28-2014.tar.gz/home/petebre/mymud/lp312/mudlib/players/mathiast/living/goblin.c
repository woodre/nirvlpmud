inherit "/obj/monster.c";

reset(arg){
  ::reset(arg);
  if(!arg){
    set_name("goblin");
    set_race("goblin");
    set_short("A Hideous Goblin");
    set_long("He is too hideous to look at and too tough to mess with.\n");
    set_level(11);
    set_hp(200);
    set_wc(15);
    set_ac(10);
    set_al(-500);
  add_money(500);
  }
}
