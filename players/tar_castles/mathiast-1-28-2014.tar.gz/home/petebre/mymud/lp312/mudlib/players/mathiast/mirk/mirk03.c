inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "You are lost in a foggy mirk. You feel disoriented. Your sense of \n"+
      "direction seems to fail you here.\n";
      this_room_num = 3;
   }
   if(!present("specter"))
      move_object(clone_object("/players/mathiast/mirk/specter.c"),this_object());
}
