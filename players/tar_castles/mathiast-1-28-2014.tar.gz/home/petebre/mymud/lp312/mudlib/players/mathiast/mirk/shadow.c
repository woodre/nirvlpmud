inherit "/obj/monster";

reset(arg) 
{
   ::reset(arg);
   if (!arg){ 
     set_name("shadow");
     set_alias("ghost");
     set_race( "spirit");
     set_short("A Dark Shadow");
     set_long("You see a dark shadow, but are not sure where its coming from.\n");
     set_level(11);
     set_wc(15);
     set_ac(10);
     set_hp(150);
     set_al(-150);
     set_aggressive(0);
     set_chat_chance(10);
     load_chat("A voice whispers: Leave this place...\n");
     set_a_chat_chance(10);
     load_a_chat("A chill runs down your spine.\n");
     add_money(random(500));
   }
}
