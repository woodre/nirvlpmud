inherit "/obj/monster.c";

reset(arg){
  ::reset(arg);
  if(!arg){
    set_name("spirit");
    set_race("spirit");
    set_short("A Wandering Spirit");
    set_long("This is the spirit of someone who was lost long ago.\n");
    set_level(11);
    set_hp(150);
    set_wc(15);
    set_ac(10);
    set_al(-100);
    set_move_at_reset();
    set_chance(10);
    set_spell_dam(10);
    set_spell_mess1("You feel a shiver run down your spine.\n");
    set_spell_mess2("You feel a shiver run down your spine.\n");
    set_chat_chance(10);
    load_chat("You feel that someone is watching you.\n");
    load_chat("You hear eerie noises coming from somewhere.\n");
    load_chat("A voice whispers: Go away...\n");
    set_a_chat_chance(10);
    load_a_chat("You feel something move through you.\n");
    load_a_chat("You get a haunting feeling.\n");
    load_a_chat("You get a feeling of impending doom.\n");
    add_money(random(500));
  }
}
