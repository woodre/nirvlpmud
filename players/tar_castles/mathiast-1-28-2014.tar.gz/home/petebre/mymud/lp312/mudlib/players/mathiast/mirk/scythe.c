inherit "/obj/weapon.c";

reset(arg){
   ::reset(arg);
   if(!arg){
      set_name("scythe");
      set_short("A Long Scythe");
      set_long(
         "This is a long scythe. It looks like it could be used to harvest \n"+
         "crops or much worse... human lives. It looks as though it has \n"+
         "seen much use.\n");
      set_class(15);
      set_value(875);
      set_weight(3);
   }
}
