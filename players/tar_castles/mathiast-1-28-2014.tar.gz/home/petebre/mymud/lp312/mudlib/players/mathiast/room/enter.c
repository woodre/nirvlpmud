inherit "/room/room.c";

reset(arg){
   if(!present("gateway"))
   move_object(clone_object("/players/mathiast/guild/gate"),this_object());
   if(arg) return;
   set_light(1);
   short_desc = "Entrance to the land of Rift";
   long_desc =
   format("	You are at the entrance to the land of Rift.  A path leads north into the mountains.  A road leads eastward around the base of the mountains.",65);
   dest_dir = ({ "/players/mathiast/room/town.c","east",
         "/players/mathiast/room/hills.c","north",
         "/room/???.c","out", });
}
