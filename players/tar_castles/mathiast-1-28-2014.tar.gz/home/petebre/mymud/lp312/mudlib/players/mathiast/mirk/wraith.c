inherit "/obj/monster";

reset(arg) 
{
   ::reset(arg);
   if (!arg){ 
     set_name("wraith");
     set_race( "spirit");
     set_alias("ghost");
     set_short("A Wraith");
     set_long("This an exact likeness of a living person seen right before death.\n"+
        "It has unsubstantial form or semblence.\n");
     set_level(11);
     set_wc(15);
     set_ac(10);
     set_hp(150);
     set_al(-150);
     set_aggressive(0);
     set_chat_chance(10);
     load_chat("A voice whispers: Leave this place...\n");
     set_a_chat_chance(10);
     load_a_chat("A chill runs down your spine.\n");
     add_money(random(500));
   }
}
