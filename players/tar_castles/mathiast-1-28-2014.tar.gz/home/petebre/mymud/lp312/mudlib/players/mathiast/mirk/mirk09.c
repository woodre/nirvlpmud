inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "Strange voices beckon you from the darkness. You can't quite \n"+
      "make out what they are saying and have no idea where they are \n"+
      "coming from.\n";
      this_room_num = 9;
   }
   if(!present("soul"))
      move_object(clone_object("/players/mathiast/mirk/lost_soul.c"),this_object());
}
