inherit "/obj/monster.c";

reset(arg) 
{
  ::reset(arg);
  if (!arg){
    set_name("ghost");
    set_race( "spirit");
    set_short("A Ghost");
    set_long("Do you believe in ghosts?\n"+
      "Is this being real or a figment of your imagination?\n");
    set_level(11);
    set_wc(15);
    set_ac(10);
    set_hp(150);
    set_al(-100);
    set_chat_chance(10);
    load_chat("The ghost says: BOO!\n");
    set_a_chat_chance(10);
    load_a_chat("A chill runs down your spine.\n");
    add_money(random(500));
  }
}
