inherit "/room/room.c";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_light(1);
   short_desc = "East shore of Sweetwater Lake";
   long_desc = 
   "   You have come to the eastern shore of Sweetwater Lake.  The water of the lake is so clear that you can see all of the fish swimming about in the lake.  There is also a large shade tree just north of here."
   long_desc = format(long_desc,65);
}
