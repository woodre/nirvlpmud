/* 
* This file is to be inherited by the other rooms in the foggy mirk.
* The random destinations make it impossible to map the area.
* Players must 'search desperately' to exit the mirk.
*/

#include "/room/clean.c"

string short_desc;
string long_desc;
int exit_found;
int no_leaving;
int this_room_num;

id(str){
   if(str=="mirk") return 1;
   else if(str=="fog") return 1;
   else if(str=="mist") return 1;
   else return;
}

short(){ 
   if(!short_desc) return "A Foggy Mirk";
   else return short_desc; 
}

long(str){
   if(!str){
      if(!long_desc) write("You are lost in a foggy mirk.\n");
      else write(long_desc);
      write("There are no obvious exits.\n");
   }
   else if(str=="mirk") write("It is cold dark and gloomy.\n");
   else if(str=="fog") write("A thick fog that hovers at ground level. \nThe light of the moon can barely penetrate it.\n");
   else if(str=="mist") write("A thick mist seems to be coming up from the ground.\n");
   return 1;
}

reset(arg){
   set_light(1);
   exit_found = 0;
   no_leaving = 0;
}

init(){
   add_action("move","north");
   add_action("move","south");
   add_action("move","east");
   add_action("move","west");
   add_action("search_room","search");
   add_action("leave","leave");
}

move(){
   int i;
   string *destinations;
   destinations = ({
         "/players/mathiast/mirk/mirk01.c",
         "/players/mathiast/mirk/mirk02.c",
         "/players/mathiast/mirk/mirk03.c",
         "/players/mathiast/mirk/mirk04.c",
         "/players/mathiast/mirk/mirk05.c",
         "/players/mathiast/mirk/mirk06.c",
         "/players/mathiast/mirk/mirk07.c",
         "/players/mathiast/mirk/mirk08.c",
         "/players/mathiast/mirk/mirk09.c",
         "/players/mathiast/mirk/mirk10.c",
         "/players/mathiast/mirk/mirk11.c",
         "/players/mathiast/mirk/mirk12.c",
         "/players/mathiast/mirk/mirk13.c",
         "/players/mathiast/mirk/mirk14.c",
         "/players/mathiast/mirk/mirk15.c", });
   i = random(sizeof(destinations));
   if(this_room_num == i+1) /* we don't want them to return to the same room */
      this_player()->move_player(query_verb()+"#/players/mathiast/mirk/mirk.c");
   else
      this_player()->move_player(query_verb()+"#"+destinations[i]);
   return 1;
}

search_room(str){
   say (this_player()->query_name() +" searches the area.\n");
   if(str == "desperately" && random(5)){
      write("You think you have found way out. You might be able to leave.\n");
      exit_found = 1;
   }
   else
      write("You search but find nothing.");
   return 1;
}

leave(){
   if(!exit_found) return;
   else 
      this_player()->move_player("the mirk#/players/mathiast/enter.c");
   return 1;
}

query_short(){ return short_desc; }
query_long(){ return long_desc; }
query_property(){ return; }
query_info(){ return "A random maze."; }
query_drop_castle(){ return; }
query_numbers(){ return "no"; }
query_dest_dir(){ return; }
