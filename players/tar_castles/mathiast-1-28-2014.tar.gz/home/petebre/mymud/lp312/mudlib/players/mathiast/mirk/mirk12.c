inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "Shadows seem to dance in the light of the moonlight here. A cold \n"+
      "breeze blows past you sending a shiver up your spine.\n";
      this_room_num = 12;
   }
   if(!present("shadow"))
      move_object(clone_object("/players/mathiast/mirk/shadow.c"),this_object());
}
