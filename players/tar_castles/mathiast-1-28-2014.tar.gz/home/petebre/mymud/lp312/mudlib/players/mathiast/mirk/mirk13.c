inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "A light rain begins to fall. You draw your clothing closer, \n"+
      "trying to fend off the cold. This is a terrible night to be out \n"+
      "in the rain.\n";
      this_room_num = 13;
   }
   if(!present("zombie"))
      move_object(clone_object("/players/mathiast/mirk/zombie.c"),this_object());
}
