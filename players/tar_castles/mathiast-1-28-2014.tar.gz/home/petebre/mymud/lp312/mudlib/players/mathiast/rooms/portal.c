id(str) { return str == "portal"; }

short() { return "A Shimmering Blue Portal"; }
long() 
{ 
   write("You see nothing special.\n");
   return 1;
}

init() 
{
   add_action("leave"); add_verb("leave");
}

leave() 
{
   tell_room("/room/wild1.c", 
      capitalize(this_player()->query_name()) 
      + " emerges from the portal.\n");
   write("You leave through the portal.\n");
   move_object(this_player(),"/room/wild1");
   command("look",this_player());
   tell_room("/players/mathiast/rooms/enter.c",
      capitalize(this_player()->query_name()) 
      + " leaves through the portal.\n");
   return 1;
}

