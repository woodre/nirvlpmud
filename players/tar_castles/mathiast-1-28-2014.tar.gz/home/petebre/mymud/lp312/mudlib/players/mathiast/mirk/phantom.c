inherit "/obj/monster";

reset(arg) 
{
   ::reset(arg);
   if (!arg){ 
     set_name("ghost");
     set_alias("ghost");

     set_race( "spirit");
     set_short("A Phantom");
     set_long("This is an elusive vision of continual dread.\n");
     set_level(15);
     set_wc(15);
     set_ac(5);
     set_hp(150);
     set_al(-150);
     set_aggressive(0);
     set_chat_chance(10);
     load_chat("A voice whispers: Leave this place...\n");
     set_a_chat_chance(10);
     load_a_chat("A chill runs down your spine.\n");
     add_money(random(500));
   }
}
