inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "A light mist seems to feed the fog here, making it only worse. \n"+
      "You get cold shiver as you look for a way out.\n";
      this_room_num = 4;
   }
   if(!present("phantasm"))
      move_object(clone_object("/players/mathiast/mirk/phantasm.c"),this_object());
}
