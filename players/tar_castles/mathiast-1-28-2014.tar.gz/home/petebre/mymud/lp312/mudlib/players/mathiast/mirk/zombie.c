inherit "/obj/monster";

reset(arg) 
{
   ::reset(arg);
   if (!arg){ 
     set_name("zombie");
     set_race( "undead");
     set_short("A Zombie");
     set_long("The soul has left the the body, but the body won't die.\n"+
		 "This creature is rotting alive. It looks and smells aweful.\n"+
		 "Be careful that it doesn't steal your soul.\n");
     set_level(11);
     set_wc(15);
     set_ac(10);
     set_hp(150);
     set_al(-150);
     set_chat_chance(10);
     load_chat("A voice whispers: Leave this place...\n");
     load_chat("The zombie mumbles an incoherent sentance.\n");
     set_a_chat_chance(10);
     load_a_chat("A chill runs down your spine.\n");
     load_a_chat("The zombie takes a bite of your flesh.\n");
     add_money(random(500));
   }
}
