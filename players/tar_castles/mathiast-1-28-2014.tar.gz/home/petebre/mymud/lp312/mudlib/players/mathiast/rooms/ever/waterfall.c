inherit "/room/room.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "Above a large waterfall.";
      long_desc = 
      "You are at the edge of a high cliff overlooking a great valley \n"+
      "in the Ever Forest. A raging river flows over the cliff creating \n"+
      "a breathtaking waterfall. The roar of the water drowns out any \n"+
      "other sounds. You find it impossible to talk here.  Looking into \n"+
      "the valley you can nothing but the tops of huge green trees. It \n"+
      "looks like it is a wonderful day in there. Perhaps you can find \n"+
      "a way down into the valley.\n";
      dest_dir = ({
            "/players/mathiast/rooms/ever/enter.c", "north", });
      items = ({
            "waterfall", "A breathtaking 1000 foot drop of cascading water.", });
   }
}

init(){
   ::init();
   add_action("search_room","search");
   add_action("move_down","down");
}

search_room(){
   if(this_player()->query_level() > 10) write("You search but find nothing.\n");
   else write("You discover a secret passage down into the valley.\n");
   say(this_player()->query_name()+ " searches the area.\n");
   return 1;
}

move_down(){
   if(this_player()->query_level()<11){
      this_player()->move_player("down#/players/mathiast/rooms/ever/valley1.c");
      return 1;
   }
   else return;
}
