inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   ::reset(arg);
   if(!arg){
      short_desc = "A Foggy Mirk";
      long_desc=
      "You are in the foggy mirk. A thick fog constantly clings to \n"+
      "the earth here. It is cold and dark and dreary. The light of \n"+
      "moon barely diffuses the mist as you find it difficult to \n"+
      "see in any direction. Eerie noises penetrate the somber \n"+
      "night causing your heart to jump. You get a dark feeling of \n"+
      "impending gloom deep within your soul. You believe that you \n"+
      "must search desperately to find your way out of this realm.\n";
      this_room_num = 0;
   }
}
