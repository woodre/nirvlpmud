inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "You are in a foggy mirk. It is cold and dark and gloomy \n"+
      "here. You find yourself wishing that light of day would come and \n"+
      "drive away the fog.\n";
      this_room_num = 1;
   }
   if(!present("ghost"))
      move_object(clone_object("/players/mathiast/mirk/ghost.c"),this_object());
}
