inherit "/obj/monster";

reset(arg) 
{
   ::reset(arg);
   if (!arg){ 
     set_name("soul");
     set_alias("lost soul");
     set_race( "spirit");
     set_short("A Lost Soul");
     set_long("A lost soul damned to wander forever in the depths of sorrow.\n");
     set_level(11);
     set_wc(15);
     set_ac(10);
     set_hp(150);
     set_al(-150);
     set_chat_chance(10);
     load_chat("A voice whispers: Leave this place...\n");
     load_chat("A lost soul moans for forgiveness.\n");
     set_a_chat_chance(10);
     load_a_chat("A chill runs down your spine.\n");
     add_money(random(500));
   }
}
