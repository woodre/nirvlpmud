inherit "/room/room.c";

reset(arg){
  if(!arg){
    set_light(1);
    short_desc = "Welcome to the Ever Forest";
    long_desc = 
    "Welcome to the Ever Forest. You are surrounded by massive and \n"+
    "ancient trees. It is quite a serene setting here. The birds are \n"+
    "chirping and the sun is shining. You feel your worries melt away \n"+
    "as you take in the peace and beauty of the forest.\n";
    dest_dir = ({
      "/players/mathiast/rooms/plain_s.c", "north", 
      "/players/mathiast/rooms/ever/waterfall.c", "south", 
      "/players/mathiast/rooms/ever/rabbit_hole.c", "east", });
  }
}

init(){
  ::init();
  add_action("search_room","search");
}

search_room(){
  write("You search but find nothing.\n");
  say(this_player()->query_name()+ " searches the area.\n");
  return 1;
}
