inherit "/obj/monster.c";

reset(arg){
  ::reset(arg);
  if(!arg){
    set_name("beaver");
    set_race("animal");
    set_alias("pest");
    set_short("A Busy Beaver");
    set_long(
      "This is a fat old beaver. It appears to be busy damming up the \n"+
      "stream. Perhaps you should kill this pest before he destroys the \n"+
      "stream. But be careful of its tail, it can really pack a whallop.\n");
    set_level(3);
    set_hp(40);
    set_wc(8);
    set_ac(4);
    set_al(-100);
    set_chance(5);
    set_spell_dam(5);
    set_spell_mess1("The beaver whallops you with its tail.\n");
    set_spell_mess2("The beaver whallops its attacker with its tail.\n");
    set_chat_chance(5);
    load_chat("A beaver begins nawing on a tree limb.\n");
    load_chat("A beaver swims out to the dam with a stick.\n");
    move_object(clone_object("/players/mathiast/obj/beaver_pelt.c"),this_object());
  }
}
