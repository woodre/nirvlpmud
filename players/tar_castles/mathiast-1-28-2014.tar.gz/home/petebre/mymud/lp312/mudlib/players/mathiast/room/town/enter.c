inherit "/room/room.c";

reset(arg){
   if(arg) return;
   set_light(1);
   short_desc = "Gates of Genoa";
   long_desc =
   format("	You are at the Genoa city gates.  There are usually guards here to prevent rifraff from entering the city.  Genoa is a trading town, and an adventurer can find many useful things to buy there.",65);
   dest_dir = ({ "/players/mathiast/room/town/main1.c","east",
         "/players/mathiast/room/town/enter.c","west", });
}
