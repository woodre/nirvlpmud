inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "You are lost in the fog. You get the strange feeling that \n"+
      "someone is watching you. You turn around quickly as you think \n"+
      "you hear footsteps from behind you.\n";
      this_room_num = 5;
   }
   if(!present("stalker"))
      move_object(clone_object("/players/mathiast/mirk/stalker.c"),this_object());
}
