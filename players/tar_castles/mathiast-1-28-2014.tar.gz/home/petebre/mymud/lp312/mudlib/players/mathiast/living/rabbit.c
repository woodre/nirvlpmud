inherit "/obj/monster.c";

reset(arg){
  ::reset(arg);
  if(!arg){
    set_name("rabbit");
    set_race("animal");
    set_alias("cottontail");
    set_short("A Furry Rabbit");
    set_long(
      "This is a cute little bunny with a fluffy cotton tail. \n"+
      "Try not to scare him, or he may try to run away.\n");
    set_level(1);
    set_hp(15);
    set_wc(6);
    set_ac(3);
    set_al(100);
    set_chat_chance(1);
    load_chat("The rabbit wrinkles its nose.\n");
    load_chat("The rabbit wiggles its ears.\n");
    load_chat("The rabbit squints its eyes.\n");
    move_object(clone_object("/players/mathiast/obj/rabbit_foot.c"),this_object());
  }
}
