inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "You wander through a thick fog. It is easy to get lost here. You \n"+
      "feel lost. You feel that you must search desperately for a way \n"+
      "out.\n";
      this_room_num = 15;
   }
}
