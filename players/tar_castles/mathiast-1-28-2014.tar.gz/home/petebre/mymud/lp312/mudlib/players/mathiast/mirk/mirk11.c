inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "You hear the flutter of bat wings in night. Something wizzes \n"+
      "past your head giving you a start.\n";
      this_room_num = 11;
   }
   if(!present("bat"))
      move_object(clone_object("/players/mathiast/mirk/bat.c"),this_object());
}
