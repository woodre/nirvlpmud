inherit "/players/mathiast/mirk/mirk.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "The Foggy Mirk";
      long_desc = 
      "You are wandering in a foggy mirk. The thick fog makes it \n"+
      "difficult to tell which direction you are going and there are no \n"+
      "landmarks to show the way.\n";
      this_room_num = 2;
   }
   if(!present("spirit"))
      move_object(clone_object("/players/mathiast/mirk/spirit.c"),this_object());
}
