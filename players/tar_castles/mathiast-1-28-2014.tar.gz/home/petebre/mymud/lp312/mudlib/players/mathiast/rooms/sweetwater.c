inherit "/room/room.c";

reset(arg){
  if(!arg){
    set_light(1);
    short_desc = "Swimming in Sweetwater Lake.";
    long_desc = 
    "You are swimming in sweetwater lake. The water is cool, clear \n"+
    "and quite refreshing. Occasionally fish will brush your side\n"+
    "giving you a startle and a tickling sensation. There are many \n"+
    "colors of fish swimming in schools beneath the water's surface. \n";
    dest_dir = ({ "/players/mathiast/workroom.c", "north", });
    items = ({ "fish", "This is a long thin silvery fish that darts about in the water.", });
  }
}

init(){
  ::init();
  add_action("search_room","search");
}

search_room(){
  write("You search but find nothing.\n");
  say(this_player()->query_name()+ " searches the area.\n");
  return 1;
}
