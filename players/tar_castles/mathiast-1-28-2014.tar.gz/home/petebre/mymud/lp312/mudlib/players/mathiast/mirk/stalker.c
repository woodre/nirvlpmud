inherit "/obj/monster";

reset(arg) 
{
   ::reset(arg);
   if (!arg) 
{
     set_name("stalker");
     set_race( "spirit");
     set_alias("ghost");
     set_short("A Night Stalker");
     set_long("You see a dark figure that you can't quite make out.\n"+
        "It appear to be searching for its next victim.\n");
     set_level(11);
     set_wc(15);
     set_ac(10);
     set_hp(150);
     set_al(-150);
     set_chat_chance(10);
     load_chat("A voice whispers: Leave this place...\n");
     load_chat("You think you hear some movement behind you.\n");
     set_a_chat_chance(10);
     load_a_chat("A chill runs down your spine.\n");
     load_a_chat("The stalker staps you in the back.\n");
     add_money(random(500));
   }
}
