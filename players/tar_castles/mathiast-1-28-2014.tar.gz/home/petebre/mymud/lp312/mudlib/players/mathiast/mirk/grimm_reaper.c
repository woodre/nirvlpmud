inherit "/obj/monster.c";

reset(arg){
  ::reset(arg);
  if(!arg){
    set_name("grimm");
    set_race("spirit");
    set_alias("reaper");
    set_short("The Grimm Reaper");
    set_long(
      "This is the grimm reaper. He face is pale white and his eyes are \n"+
      "black and hollow. He looks like a frail old man, but looks can \n"+
      "be decieving. He will come to visit you when the time comes die.\n");
    set_level(15);
    set_hp(225);
    set_wc(20);
    set_ac(12);
    set_al(0);
    set_chance(5);
    set_spell_dam(10);
    set_spell_mess1("The grimm reaper slashes you with his scythe.\n");
    set_spell_mess2("The grimm reaper slashes his victim with his scythe.\n");
    set_chat_chance(5);
    load_chat("The Grimm Reaper says: Your time will come.\n");
    load_chat("The Grimm Reaper says: It is not your time yet.\n");
    set_a_chat_chance(5);
    load_a_chat("The Grimm Reaper says: Now your time has come to die.\n");
    move_object(clone_object("/players/mathiast/mirk/scythe.c"), this_object());
  }
}
