inherit "/room/room.c";

reset(arg){
   if(!arg){
      set_light(1);
      short_desc = "A Beaver's Dam";
      long_desc = 
      "You have come to the edge of a river running through the \n"+
      "forest. Some beavers have begun to dam up the river.\n";
      dest_dir = ({
            "/players/mathiast/rooms/ever/rabbit_hole.c", "north", });
      items = ({
            "dam", 
            "What a mess! This dam will surely ruin the downstream habitat \n"+
            "if it is completed.\n", });
   }
   
   if(!present("beaver", this_object())){
    move_object(clone_object("/players/mathiast/living/beaver.c"), this_object());
    move_object(clone_object("/players/mathiast/living/beaver.c"), this_object());
   }
}

init(){
   ::init();
   add_action("search_room","search");
}

search_room(){
   write("You search but find nothing.\n");
   say(this_player()->query_name()+ " searches the area.\n");
   return 1;
}
