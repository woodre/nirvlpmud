#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

	void create() {
	::create();

	set_short(BOLD+"Corner"+NORM);
	set_long(BOLD+
	    "Corner\n"+NORM+
	    "You follow the punk Duck, and the moment you step into\n"+
	    "this corner you are befallen by a pack of ruthless\n"+
	    "Duck punks.  They are all dressed like the first Duck\n"+
	    "and seem to be packing switch blades.  They seem to\n"+
	    "have you surrounded with no other way out but to fight!\n");
	set_items(([
	    "exit" :
	    "The only way out is to fight!\n",
	    ]));
	set_smells(([
	    "default" :
	    "The smell of blood and perspiration mingle together here...\n",
	    "blood" :
	    "If you don't stop smelling stuff, this could be your blood!\n",
	    "duck" :
	    "They stink.  'Nuff said.\n",
	    ]));
	set_sounds(([
	    "default" :
	    "The sound of muttering and laughing from the punks...\n",
	    "duck" :
	    "Their clothes jingle as their buckles and chains clink\n"+
	    "together as they ever so slowly inch forward...\n",
	    ]));
	set_chat_frequency(50);
	load_chats(({
	    "The feeling of dread creeps up on you as you feel your\n"+
	    "maker coming to meet you.\n",
	    "The scratching of a Duck's boot startles you...\n",
	    }));
	set_exits(([
	    "north" : "/players/reflex/realms/tiny/c1",
	    ]));
	set_light(1);
	replace_program(ROOM);
}
