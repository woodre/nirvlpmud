#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

	void create() {
	::create();
	set_short("Dive");
	set_long(
	    "Upon entering this establishment, you are bombarded by waves\n"+
	    "of smoke and noise.  All around you are Duck people engaging\n"+
	    "in various things.  The whole place isn't that big.  There's a\n"+
	    "juke boxoff to one side, a bar across the room from the entrance,\n"+
	    "and many, many chairs and tables.  There doesn't seem to be any\n"+
	    "place to sit, and the citizens seem to be staring at you.......\n");
	set_items(([
	    "smoke" :
	    "Nasty, tar infested billows of tainted air.  You are appaled!\n",
	    "jukebox" :
	    "It's about 3' tall, covered in puke and booze.  It probably at\n"+
	    "one time actually had a wider selection of music, but now it's\n"+
	    "stuck on, 'Satisfaction' by the Rolling Stones...\n",
	    "bar" :
	    "A long wooden bar with stools in front, occupied by denziens\n"+
	    "of Duck World.  The Bartender looks up from his want ads, only\n"+
	    "to make another drink for someone.  It looks like you could\n"+
	    "possibly order some booze and grub.  You may have to 'ask' the\n"+
	    "Bartender for a list though, cause the sign that was posted\n"+
	    "on the wall has long since been torn down...\n",
	    "chairs" :
	    "Short devices used to rest ones body upon it...\n",
	    "tables" :
	    "Long, wide things used to put food, booze, and other things on\n",
	    "citizens" :
	    "These Duck worlders aren't quite as friendly as the other folk\n"+
	    "you have run into.  They look grizzled and unkept, with\n"+
	    "unsavory items in front of them on their respective tables.\n",
	    "sign" :
	    "A nice wooden wall.  Nothing special about it, or atleast\n"+
	    "now a days.  You might want to 'ask' the Bartender for a\n"+
	    "list of foods and booze if you are so inclined.\n",
	    ]));
	set_smells(([
	    "default" :
	    "The smell of smoke, booze, puke, and other nasty stenches\n"+
	    "fill your nostrils.\n",
	    "puke" :
	    "It smells very bad.  But, then again, so does the booze, but\n"+
	    "that probably won't stop you from getting something...\n",
	    "duck" :
	    "Just down right nasty.  No other explanation need be given.\n"+
	    "If you want a better description, stick your head between\n"+
	    "your mother's legs...\n",
	    ]));
	set_sounds(([
	    "default" :
	    "The sound of Ducks' talking, music playing and fights\n"+
	    "occurring.\n",
	    "jukebox" :
	    "You hear a all too familiar song that goes something like...\n"+
	    "'I can't get no, satisfaction...cause I try, and I try, and I\n"+
	    "try, and I try.  I can't get no, satisfaction' and it continues\n"+
	    "to loop like such till it ends...then begins again cause it's on\n"+
	    "a continuous music jam.\n",
	    "music" :
	    "You hear a all too familiar song that goes something like...\n"+
	    "'I can't get no, satisfaction...cause I try, and I try, and I\n"+
	    "try, and I try.  I can't get no, satisfaction' and it continues\n"+
	    "to loop like such till it ends...then begins again cause it's on\n"+
	    "a continuous music jam.\n",
	    "silence" :
	    "Barking spiders?  Paul Simon?  Naa...wrong place for that...\n",
	    ]));
	set_chat_frequency(30);
	load_chats(({
	    "You catch a glass of booze on your shirt.  And you "+BOLD+"liked"+
	    NORM+"that\nshirt\n",
	    "You hear the same song played over and over again...\n",
	    "Someone stumbles into you...\n",
	    "Smoke cascades into you...\n",
	    }));
	set_exits(([
        "assembly" : "/players/mythos/closed/guild/assembly",
        "boards" : "/room/adv_inner",
        ]));
	set_light(1);
	replace_program(ROOM);
}
