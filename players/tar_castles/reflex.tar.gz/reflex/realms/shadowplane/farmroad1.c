#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Farmer's Road [w,n]"+NORM);
    set_long(BOLD+BLK+
	"You are on a deeply rutted north-south road used by the farmers to tend\n"+
	"the various crops grown to feed the villagers.\n"+
	"    There are two obvious exits: west and north"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "west" : "/players/reflex/realms/shadowplane/lanceroad4",
        "north" : "/players/reflex/realms/shadowplane/farmroad2",
        ]));
    set_light(0);
}
