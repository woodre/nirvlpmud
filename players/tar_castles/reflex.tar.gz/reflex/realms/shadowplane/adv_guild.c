#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"The adventurers guild"+NORM);
    set_long(BOLD+BLK+
	"You have to come here when you want to advance your level.\n" +
	"You can also buy points for a new level.\n" +
	"Commands: cost, advance, list (number).\n" +
	"raise <str, sta, wil, mag, pie, ste, luc, int>\n" +
	"There are some stairs leading up to the second level.\n" +
   	"There is an opening to the south, and some shimmering\n" +
   	"blue light in the doorway.\n"+
	"    There is one obvious exit: north"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "north" : "/players/reflex/realms/shadowplane/vill_road2",
        ]));
    set_light(0);
}
