#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"East road [n,s,w]"+NORM);
    set_long(BOLD+BLK+
	"East road runs north-south.\n"+
	"Sun alley is to the west.\n"+
	"    There are three obvious exits: north, south and west"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "north" : "/players/reflex/realms/shadowplane/eastroad4",
        "south" : "/players/reflex/realms/shadowplane/eastroad2",
        "west" : "/players/reflex/realms/shadowplane/sunalley1",
        ]));
    set_light(0);
}
