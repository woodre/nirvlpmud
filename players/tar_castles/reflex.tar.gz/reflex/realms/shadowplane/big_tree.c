#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Big tree [east]"+NORM);
    set_long(BOLD+BLK+
	"A big single tree on the plain.\n"+
	"There is one obvious exit, east."+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/realms/shadowplane/plane7",
        ]));
    set_light(0);
}
