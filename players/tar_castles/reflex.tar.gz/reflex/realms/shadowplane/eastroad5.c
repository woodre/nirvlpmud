#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"East road [s,n,w]"+NORM);
    set_long(BOLD+BLK+
	"East road runs south from here.\n"+
	"To the west lies the Eastroad Inn.\n"+
	"    There are three obvious exits: south, north and west"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "south" : "/players/reflex/realms/shadowplane/eastroad4",
        "west" : "/players/reflex/realms/shadowplane/inn",
        ]));
    set_light(0);
}
