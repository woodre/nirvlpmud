#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Fields [n]"+NORM);
    set_long(BOLD+BLK+
	"You are in the middle of the fields where the city grows all its crops.\n"+
	"A road runs north of here.\n"+
	"    There is one obvious exit: north"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "north" : "/players/reflex/realms/shadowplane/vill_shore",
        ]));
    set_light(0);
}
