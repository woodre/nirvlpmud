#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
#include "/players/reflex/realms/shadowplane/include/room.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Humpbacked bridge [e,w]"+NORM);
    set_long(BOLD+BLK+
	"An old humpbacked bridge.\n"+
	"    There are two obvious exits: east and west"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/realms/shadowplane/vill_green",
        "west" : "/players/reflex/realms/shadowplane/wild1",
        ]));
    set_light(0);
}
