#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Clearing [e,w,n]"+NORM);
    set_long(BOLD+BLK+
	"A small clearing. There are trees all around you.\n" +
	"However, the trees are sparse to the north.\n"+
	"    There are three obvious exits: east, west and north"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/realms/shadowplane/forest1",
        "west" : "/players/reflex/realms/shadowplane/forest2",
        "north" : "/players/reflex/realms/shadowplane/north",
        ]));
    set_light(0);
}
