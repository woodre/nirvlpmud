#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Deep forest [e]"+NORM);
    set_long(BOLD+BLK+
	"In the deep forest. The wood lights up to the east.\n"+
	"    There is one obvious exit: east"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/realms/shadowplane/plane12",
        ]));
    set_light(0);
}
