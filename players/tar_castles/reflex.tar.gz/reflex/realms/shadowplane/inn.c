#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Eastroad Inn [e]"+NORM);
    set_long(BOLD+BLK+
	"You are in the Eastroad Inn. Here you can buy food to still your\n"+
	"hunger, but only a limited selection is available.\n"+
	"    There is one obvious exit: east"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/realms/shadowplane/eastroad5",
        ]));
    set_light(0);
}
