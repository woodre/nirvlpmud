#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"backroom of bank"+NORM);
    set_long(BOLD+BLK+
	"You are in the backroom of the bank."+	
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "west" : "/players/reflex/realms/shadowplane/bank",
        ]));
    set_light(0);
}
