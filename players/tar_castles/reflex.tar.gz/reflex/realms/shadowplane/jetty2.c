#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Jetty [w,e]"+NORM);
    set_long(BOLD+BLK+
	"You are at a jetty. The waves rolls in from east.\n"+
	"A small path leads back to west.\n"+
	"    There are two obvious exits: west and east"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "west" : "/players/reflex/realms/shadowplane/vill_shore2",
        "east" : "/players/reflex/realms/shadowplane/sea",
        ]));
    set_light(0);
}
