#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"In a forest [e,w]"+NORM);
    set_long(BOLD+BLK+
	"You are in a big forest.\n"+
	"    There are two obvious exits: east and west"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/realms/shadowplane/clearing",
        "west" : "/players/reflex/realms/shadowplane/slope",
        ]));
    set_light(0);
}
