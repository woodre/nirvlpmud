#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"East road [n,s]"+NORM);
    set_long(BOLD+BLK+
	"The East Road runs north-south. Sitting off to the west is a temple.\n"+
	"You can hear the clashing of weapons from beyond the temple's high\n"+
	"granite walls, and menacing bronze gate.\n"+
	"    There are two obvious exits: north and south"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "north" : "/players/reflex/realms/shadowplane/eastroad2",
        "south" : "/players/reflex/realms/shadowplane/vill_shore",
        ]));
    set_light(0);
}
