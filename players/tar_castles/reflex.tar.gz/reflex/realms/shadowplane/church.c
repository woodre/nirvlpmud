#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Village church"+NORM);
    set_long(BOLD+BLK+
	"You are in the local village church.\n"+
	"There is a huge pit in the center,\n"+
	"and a door in the west wall. There is a button beside the door.\n"+
	"This church has the service of reviving ghosts. Dead people come\n"+
	"to the church and pray.\n"+
	"There is a clock on the wall.\n"+
	"The are exits to the south, east and north."+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "south" : "/players/reflex/realms/shadowplane/vill_green",
        "north" : "/players/reflex/realms/shadowplane/townh",
        ]));
    set_light(0);
}
