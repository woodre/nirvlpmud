#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Deep forest [n,w,e,s]"+NORM);
    set_long(BOLD+BLK+
	"You are in the deep forest.\n"+
	"    There are four obvious exits: north, west, east and south"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "north" : "/players/reflex/realms/shadowplane/forest3",
        "west" : "/players/reflex/realms/shadowplane/forest5",
        "east" : "/players/reflex/realms/shadowplane/forest6",
        "south" : "/players/reflex/realms/shadowplane/forest7",
        ]));
    set_light(0);
}
