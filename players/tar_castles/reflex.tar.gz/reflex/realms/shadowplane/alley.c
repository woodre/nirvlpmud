#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Dirty alley [east,south]"+NORM);
    set_long(BOLD+BLK+
	"A dirty, trash-strewn alley."+
	"    There are two obvious exits, east and south."+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/realms/shadowplane/yard",
        "south" : "/players/reflex/realms/shadowplane/pub3",
        ]));
    set_light(0);
}
