#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Deep forest [n,s]"+NORM);
    set_long(BOLD+BLK+
	"You are in the deep forest.\n"+
	"    There are two obvious exits: north and south"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "north" : "/players/reflex/realms/shadowplane/slope",
        "south" : "/players/reflex/realms/shadowplane/forest4",
        ]));
    set_light(0);
}
