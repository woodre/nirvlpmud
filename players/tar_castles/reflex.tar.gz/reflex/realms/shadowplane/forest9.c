#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+BLK+"Deep forest [n,e,w]"+NORM);
    set_long(BOLD+BLK+
	"You are in the deep forest.\n"+
	"    There are three obvious exits: north, east and west"+
	NORM+"\n");
    set_smells(([
        "default" :
        "You smell something rotting...\n",
        ]));
    set_sounds(([
        "default" :
        "It is deathly quiet...\n",
    ]));
    set_exits(([
        "north" : "/players/reflex/realms/shadowplane/forest8",
        "east" : "/players/reflex/realms/shadowplane/forest10",
        ]));
    set_light(0);
}
