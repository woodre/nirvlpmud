#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

void create() {
::create();
    set_short("Between two cliffs and a hard place");
    set_long(
        "You are at the western end of a pass, standing between hills\n"+
	"to the west and north.  You can go south between the hills or\n"+
	"east into a mountain pass from here.  The wind screams into\n"+
	"the pass to the east, and overhead dark clouds pour down rain\n"+
	"on everything.\n");
    set_items(([
        "path" :
        "This is a muddy path leading south and east.\n",
        "hill" :
        "There is a hill to the west blocking your path.\n",
        "pass" :
        "The pass leads off to the west.\n",
        "clouds" :
        "Lightning streaks the sky as the clouds poor rain on you.\n",
        ]));
    set_smells(([
	"default" :
	"You detect the slight smell of ozone in the salty sea air.\n",
	"wind" :
	"The air smells very moist from the rain.\n",
	]));
    set_sounds(([
	"default" :
	"You hear a screaming noise as the winds whip through the pass.\n",
	"wind" :
	"Thunder crashes overhead.\n",
	]));
    set_chat_frequency(80);
    load_chats(({
	"Thunder rumbles overhead.\n",
	"The wind howls through the mountains.\n",
	"Lightning "+BOLD+YEL+"strikes"+NORM+" above!\n",
	}));
    set_exits(([
        "south" : "/players/reflex/realms/coastline/mount_ents1",
	"east" : "/players/reflex/realms/coastline/pass",
        ]));
    set_light(1);
    replace_program(ROOM);
}


void
reset(int arg){
int blah;
  ::reset(arg);

  if(!present("templar_guard", this_object())){
    for(blah = 0; blah < 2; blah++){
    move_object(clone_object("/players/maledicta/cont/war/templar_guard.c"), this_object());
    }
   }
 }  
