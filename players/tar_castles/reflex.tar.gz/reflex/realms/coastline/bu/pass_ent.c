#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

void create() {
::create();
    set_short("Entrance to a mountain pass");
    set_long(
        "Before you to the west stands a narrow pass between two\n"+
	"mountains leading to the coastline.  The path you are on\n"+
	"is slightly muddy here, and you can see the bootprints of\n"+
	"what must be many men tracked through the mud.  It is\n"+
	"raining lightly, and there is a horrible screeching sound\n"+
	"coming out of the pass from the wind, drowning out all other\n"+
	"sounds beyond.  There is a small path along the mountains\n"+
	"to the north and south, however it is blocked off by some\n"+
	"rockslides, eastward you can head back to the village, and\n"+
	"west leads through the pass.\n");
    set_items(([
        "path" :
        "This is a dusty path leading east and west.\n", 
        "mountains" :
        "This is a small mountain range blocking your path to the west.\n"+
        "You think you could pass it by the small opening between two hills\n"+
	"directly westward.\n",
        "pass" :
        "There is a pass leading between the two mountains in front of you.\n"+
	"You it appears to be the only way to the coastline beyond...\n",
        "sky" :
        "The sky is overcast and you can feel the slightest drizzel in the\n"+
	"air around you.  It looks like rain is coming.\n",
        "rockslides" :
        "There are rockslides to the north and south, making the pass the\n"+
	"only entrance to the coastline.\n",
        ]));
    set_smells(([
	"default" :
	"You detect the slight smell of ozone in the salty sea air.\n",
	"wind" :
	"It smells like rain is coming...\n",
	]));
    set_sounds(([
	"default" :
	"You hear a screaming noise as the winds whip through the pass.\n",
	"wind" :
	"You hear thunder in the distance to the west.\n",
	]));
    set_chat_frequency(80);
    load_chats(({
	"Thunder rumbles in the distance.\n",
	"The wind screams through the pass, drowning out everything else.\n",
	"Lightning "+BOLD+YEL+"strikes"+NORM+" in the distance...\n",
	}));
    set_exits(([
        "west" : "/players/reflex/realms/coastline/pass",
	"east" : "/players/reflex/realms/coastline/path",
        ]));
    set_light(1);
    replace_program(ROOM);
}

void
reset(int arg){
int blah;
  ::reset(arg);
   if(!present("templar_guard", this_object())){
    for(blah = 0; blah < 2; blah++){
    move_object(clone_object("/players/maledicta/cont/war/templar_guard.c"), this_object());
    }
   }
   if(!present("templar_tent", this_object())){
   move_object(clone_object("/players/maledicta/cont/war/ttent.c"), this_object()); 
   } 

 }  

