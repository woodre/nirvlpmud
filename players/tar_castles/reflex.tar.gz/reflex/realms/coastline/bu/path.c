#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

void create() {
::create();
    set_short("A path leading West");
    set_long(
        "You are on a path heading west to the coastal mountain range.\n"+
	"The sky is overcast and there is a brisk wind that chills you\n"+
	"to your bones.  The mountain range to the west is small, and\n"+
	"you can see a break in the hills leading to the coast.  To the\n"+
	"east the path widens and heads to the main village.  There is\n"+
	"no path to the north or south.\n");
    set_items(([
        "path" :
        "This is a dusty path leading east and west.\n", 
        "mountain" :
        "This is a small mountain range blocking your path to the west.\n"+
        "You think you could pass it by the small opening between two hills\n"+
	"directly westward.\n",
        "range" :
        "This is a small mountain range blocking your path to the west.\n"+
        "You think you could pass it by the small opening between two hills\n"+
        "directly westward.\n",
        "sky" :
        "The sky is overcast and you can feel the slightest drizzel in the\n"+
	"air around you.  It looks like rain is coming.\n",
        "hills" :
        "This is a small mountain range blocking your path to the west.\n"+
        "You think you could pass it by the small opening between two hills\n"+
	"directly westward.\n",
        ]));
    set_smells(([
	"default" :
	"You detect the slight smell of ozone in the salty sea air.\n",
	"wind" :
	"It smells like rain is coming...\n",
	]));
    set_sounds(([
	"default" :
	"You hear the sound of the breeze through the mountains ahead.\n",
	"wind" :
	"You hear thunder in the distance to the west.\n",
	]));
    set_chat_frequency(120);
    load_chats(({
	"Thunder rumbles in the distance.\n",
	"The wind whistles through the mountains to the west.\n",
	"You hear armor clanging in the distance.\n",
	"Lightning "+BOLD+YEL+"strikes"+NORM+" in the distance...\n",
	}));
    set_exits(([
        "west" : "/players/reflex/realms/coastline/pass_ent",
	"east" : "/room/orc_dump",
        ]));
    set_light(1);
    replace_program(ROOM);
}

void
reset(int arg){
int blah;
  ::reset(arg);

  if(!present("templar_guard", this_object())){
    for(blah = 0; blah < 2; blah++){
    move_object(clone_object("/players/maledicta/cont/war/templar_guard.c"), this_object());
    }
   }
 }  


query_no_fight(){ return 1; }