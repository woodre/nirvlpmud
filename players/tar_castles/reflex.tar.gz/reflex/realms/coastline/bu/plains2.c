#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

void create() {
::create();
    set_short("Western Coastal Plains");
    set_long(
	"You are at the southeastern corner of the western coastal plains.\n"+
	"South and east are blocked by tall mountains, while to the north\n"+
	"and west the plains continue on.  You can hear the sounds of waves\n"+
	"crashing into the shoreline to the west, and rain falls from the\n"+
	"skies overhead, soaking you to the bone.  All around you is soggy\n"+
	"grasslands, and the wind is whipped to a frenzy here by the tall\n"+
	"mountainsides south and east of you.\n");
    set_items(([
        "mountains" :
        "Tall mountains rise to the south and east, blocking you.\n",
        "plains" :
        "Wide open plains lead out towards the coastline.\n",
        "grasslands" :
        "Scrub grass grows up through the somewhat sandy soil here.\n",
        "skies" :
        "Visibility is reduced around you as the grey sky above dumps\n"+
	"rain down on everything.\n",
	"hill" :
	"A small but steep hill blocks your way to the north.\n",
        ]));
    set_smells(([
	"default" :
	"The saltwater smell of the sea permeates the air around you\n",
	"wind" :
	"The air smells very moist from the sea.\n",
	]));
    set_sounds(([
	"default" :
	"Thunder rumbles overhead as the sea storm builds.\n",
	"waves" :
	"Waves crash violently into the shore in the distance.\n",
	]));
    set_chat_frequency(80);
    load_chats(({
	"Waves crash into the shoreline in the distance.\n",
	"You hear a whistling noise as the winds whip through the"+
	"grasslands.\n",
	"Thunder "+BOLD+"rumbles"+NORM+" overhead menacingly...\n",
	}));
    set_exits(([
        "north" : "/players/reflex/realms/coastline/plains1",
        "west" : "/players/reflex/realms/coastline/plains3",
        "northwest" : "/players/reflex/realms/coastline/plains4",
        ]));
    set_light(1);
    replace_program(ROOM);
}
