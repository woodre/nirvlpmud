#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

void create() {
::create();
    set_short("Western Coastal Plains");
    set_long(
        "You are on the edge of the western coastal plains.  Scrub grass\n"+
	"stretches westward across the plains ending in the coastline in\n"+
	"the distance.  The sky is a very sullen grey color overhead, and\n"+
	"cold rain pours down torrentially everywhere, saturating the grass\n"+
	"beneath your feet.  To the north is a small hill blocking you, but\n"+
	"there is a path eastward into the mountains, and you can go west\n"+
	"and south onto the plains.\n");
    set_items(([
        "path" :
        "This is a muddy path leading into the mountains to the east.\n",
        "plains" :
        "Wide open plains lead out towards the coastline.\n",
        "grass" :
        "Scrub grass grows up through the somewhat sandy soil here.\n",
        "sky" :
        "Visibility is reduced around you as the grey sky above dumps\n"+
	"rain down on everything.\n",
	"hill" :
	"A small but steep hill blocks your way to the north.\n",
        ]));
    set_smells(([
	"default" :
	"The saltywater smell of the sea permeates the air around you\n",
	"wind" :
	"The air smells very moist from the sea.\n",
	]));
    set_sounds(([
	"default" :
	"Thunder rumbles overhead as the sea storm builds.\n",
	"wind" :
	"You hear the breeze whipping through the grasslands.\n",
	]));
    set_chat_frequency(80);
    load_chats(({
	"You hear waves crashing into the shore in the distance.\n",
	"You hear a whistling noise as the winds whip through the"+
	"grasslands.\n",
	"Thunder "+BOLD+"rumbles"+NORM+" overhead menacingly...\n",
	}));
    set_exits(([
        "west" : "/players/reflex/realms/coastline/plains4",
        "east" : "/players/reflex/realms/coastline/mount_ents1",
        "south" : "/players/reflex/realms/coastline/plains2",
        "southwest" : "/players/reflex/realms/coastline/plains3",
        ]));
    set_light(1);
    replace_program(ROOM);
}
