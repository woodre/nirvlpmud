#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

void create() {
::create();
    set_short("Entrance to the plains");
    set_long(
        "The path widens here, opening up onto a plain to the west,\n"+
	"while north it leads back into the mountains.  East and south\n"+
	"are blocked by steep hills, and far off to the west you hear\n"+
	"the distant sound of waves crashing into a shoreline.  The storm\n"+
	"overhead is very intense, and your standing ankle deep in mud.\n");
    set_items(([
        "path" :
        "This is a muddy path leading north and west.\n",
        "plains" :
        "Wide open plains lead out to the west.\n",
        "pass" :
        "The pass leads off to the west.\n",
        "storm" :
        "Lightning streaks the sky as the clouds poor rain on you.\n",
        ]));
    set_smells(([
	"default" :
	"You detect the slight smell of ozone in the salty sea air.\n",
	"wind" :
	"The air smells very moist from the rain.\n",
	]));
    set_sounds(([
	"default" :
	"You hear a screaming noise as the winds whip through the pass.\n",
	"wind" :
	"Thunder crashes overhead.\n",
	]));
    set_chat_frequency(80);
    load_chats(({
	"Thunder rumbles overhead.\n",
	"The wind howls through the mountains.\n",
	"Lightning "+BOLD+YEL+"strikes"+NORM+" above!\n",
	}));
    set_exits(([
        "west" : "/players/reflex/realms/coastline/plains1",
        "north" : "/players/reflex/realms/coastline/mount_ent",
        ]));
    set_light(1);
    replace_program(ROOM);
}


void
reset(int arg){
int blah;
  ::reset(arg);

  if(!present("templar_guard", this_object())){
    for(blah = 0; blah < 2; blah++){
    move_object(clone_object("/players/maledicta/cont/war/templar_guard.c"), this_object());
    }
   }
 }  
