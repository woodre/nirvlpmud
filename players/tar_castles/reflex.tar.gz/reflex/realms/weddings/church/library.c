#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    query_no_fight(){ return 1; }
void create() {
if(!present("monk_book", this_object())){
move_object(clone_object("/players/maledicta/closed/w/OBJ/trainer_monk.c"), this_object());
}
::create();
    set_short(BOLD+"A Reading Room"+NORM);
    set_long(BOLD+
        "The Monk reading room.\n"+NORM+
	"The reading room is circular in design, with shelving lining\n"+
	"the walls from one side of the door all the way around to the\n"+
	"other.  Books fill the shelves, and several tables are arrayed\n"+
	"around a central pedestal upon which rests a large tome.  The\n"+
	"ceiling is low in here, and is covered in a painting depicting\n"+
	"the last supper of Christ while the floor is painted over with\n"+
	"a large symbol and several smaller ones.  There is a small\n"+
	"wooden door to the west leading into the Cathedral.\n");
    set_items(([
        "shelving" :
        "These wooden shelves are crammed with books from end to end.\n", 
        "ceiling" :
        "There is a large painting depicting The Last Supper of Christ.\n",
        "tables" :
        "Large wooden tables arranged in a circle around the central pedastal\n",
        "walls" :
        "The walls are loaded with shelving that is covered in books\n",
        "door" :
        "This is a plain wooden door, barely tall enough for the average person\n"+
	"to fit through.\n",
        "books" :
        "Many ancient books line the shelves, there are crammed very tightly into\n"+
	"the available space.\n",
        "pedestal" :
        "This is a large pedestal engraved with phrases written in Latin.\n",
	"painting" :
	"This painting depicts the last support of Christ.\n",
	"floor" :
	"There is a large symbol of a cross intersecting the pedestal on the floor.\n",
        ]));
    set_smells(([
	"default" :
	"The smell of aged paper permeates this room.\n",
	]));
    set_sounds(([
	"default" :
	"It is very silent here.\n",
	]));
    set_exits(([
        "west" : "/players/reflex/realms/weddings/church/church",
        ]));
    set_light(1);
    replace_program(ROOM);
}
