#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
#define DAEMON "/players/maledicta/closed/imm/imm_daemon.c"
inherit ROOM;

string *rules;
string *info;
string *join;

    query_no_fight(){ return 1; }
void create() {
::create();


 set_short(BOLD+"First Church of Nirvana"+NORM);
    set_long(BOLD+
        "First Church of Nirvana.\n"+NORM+
        "You are in a very large Cathedral.  There are stained glass\n"+
        "windows up both sides, leading all the way up to the arched\n"+
        "ceiling.  The ceiling is supported by huge arches, curving\n"+
        "majestically above you.  Everything is made of the finest oak,\n"+
        "and the pews are inlaid with gold trim.  At the front stands\n"+
        "a podium, and before it a small platform where weddings are\n"+
        "performed.  There is a rune inscribed on the floor here.\n\n"+
	"There is a large set of double doors exiting to the north,\n"+
	"a small door with the inscription of a book on it to the\n"+
	"east, and a door with the emblem of crossed swords to the\n"+
	"north.\n");
    set_items(([
        "rune" :
        "Type 'rules' to begin your journey into The Gathering.\n",
        "windows" :
        "The stained glass depicts several scenes of Christ from the bible.\n", 
        "ceiling" :
        "There is a large mural of the sermon on the mount depicted with\n"+
        "multi-colored tiles across the length of the ceiling.\n",
        "arches" :
        "Huge arches made of Oak, well polished and decorated with carvings\n"+
        "of Christ and the Virgin Mary.\n",
        "pews" :
        "Oak pews, they are padded and covered in the finest velvet.  The\n"+
        "trim is in the finest gold.\n",
        "podium" :
        "A ornate podium from which a Reverand could deliver a stirring\n"+
        "sermon.  It has two angels depicted in fine carvings, inlaid with\n"+
        "gold.\n",
        "platform" :
        "A raised dias, still lower than the podium, but higher than the\n"+
        "floor level.  It is where weddings are performed.\n",
        "doors" :
        "Two large ornate oak doors, they open north to exit the church.\n"+
        "They are covered in carvings and symbols from the Bible.\n",
        ]));
    set_smells(([
	"default" :
	"You smell incense burning.\n",
	"pews" :
	"Pee-Yew!(what did you expect..?)\n",
	]));
    set_sounds(([
	"default" :
	"You hear the organ playing in the background.\n",
	"organ" :
	"A organ plays quietly in the background...\n",
	]));
    set_chat_frequency(120);
    load_chats(({
	"The organ plays softly...\n",
	"A sense of calm overcomes you...\n",
	"You are at peace here...\n",
	"You feel a "+BOLD+"higher power's"+NORM+" presence...\n",
	}));
    set_exits(([
        "north" : "/players/reflex/realms/weddings/church/yard",
        "west" : "/players/reflex/realms/weddings/church/altar",
        "east" : "/players/reflex/realms/weddings/church/library",
        ]));
    set_light(1);
    join = allocate(300);
    info = allocate(300);
    rules = allocate(300);
    restore_object("players/reflex/realms/weddings/church/save");
    replace_program(ROOM);
}


init(){
 ::init();
 add_action("hl_rules", "rules");
 add_action("hl_info", "info");
 add_action("hl_join", "join");
}

hl_rules(){

write(
"                     "+HIW+"["+HIB+"The Gathering II"+HIW+"]"+NORM+"\n"+
" Welcome to The Gathering.  Here you will read the rules of\n"+
" this Immortal contest.  Let us begin.\n"+
HIR+" 1.  You may only enter TWO characters in this.  If you enter a\n"+
"     third character that you own, you will be kicked out and\n"+
"     PUNISHED SEVERLY! If a character dies, you may not reenter\n"+
"     a character in their place.  TWO MAX, EVER."+NORM+"\n"+ 
" 2.  You MUST be pk.  If you die to an Immortal you are removed\n"+
"     from the Gathering.  If you die to a monster or non-Immortal\n"+
"     you must reset your pk within 300 seconds or be disqualified.\n"+
" 3.  No Fighting on Holy Ground. Churches, places of worship, etc.\n"+
"     are offlimits.  You will lose all of your kill points if you\n"+
"     violate this.\n"+
" 4.  No Fighting your own kind in Guild Halls! Violate this one and\n"+
"     you are removed from the contest and possibly your guild!\n"+
" 5.  If your guild limits you from infighting and you wish to fight\n"+
"     another Immortal in your guild, you HAVE to ask them each time!\n"+
" 6.  No griping because another Immortal massacres you.  Immortals gain\n"+
"     the ability to do more damage versus other Immortals as they gain\n"+
"     more Immortal kills.  If you join the Gathering, you agree that this\n"+
"     is acceptable.\n"+
" 7.  In the end there can be only ONE.  After a few months elapses,\n"+
"     whoever is left will be forced to go and fight to the death. You\n"+
"     will be given only so much time to prepare and then be forced to\n"+
"     go in and live or die in a fight. Once again, No Griping.\n"+
" 8.  Falling below 8th level will remove you from the game.\n\n"+
"Now, Type, 'info' for more information on the Gathering.\n");
    restore_object("players/reflex/realms/weddings/church/save");
if(!get_rules(this_player()->query_real_name())){
    add_rules(this_player()->query_real_name());
    save_object("players/reflex/realms/weddings/church/save");
    }
return 1;
}

hl_info(){
write(
"OVERVIEW\n"+
"  After you 'join' here at the Church, you are enrolled in the\n"+
"Gathering.  Look at yourself to see how to get help on new commands\n"+
"that are available.  Your goal is to kill as many other Immortals\n"+
"as you can before the time of The Gathering.  This means you CAN kill\n"+
"your own guildmates, but NOT in the Guild hall!  If someone is in\n"+
"your guild and you want to fight them, ask them to fight if your guild\n"+
"limits infighting. (e.g. A Knight wishes to fight another Immortal Knight.\n"+
"Because the guild does not allow infighting, the Knight MUST ask the other\n"+
"to a fight.) If someone denies you the fight, don't worry...It will all\n"+
"work itself out during the time of the Gathering.\n\n"+
"KILL POINTS\n"+
"You gain kill points by killing other Immortals. Each one you kill will give\n"+
"1 point plus whatever points they have earned. Dying to an Immortal removes\n"+
"you from the Gathering. When an Immortal dies, whoever he/she was attacking\n"+
"is the one to gain the kill points.\n\n"+
"THING TO REMEMBER\n"+
"  If you die to a non Immortal, you must reset pk within 300 seconds.\n"+
"  Also, the more kills you have the more effective you become versus other\n"+
"  Immortals in combat.\n\n"+
"You may now 'join' if you accept all of these rules and concepts.\n");
    restore_object("players/reflex/realms/weddings/church/save");
if(!get_info(this_player()->query_real_name())){
    add_info(this_player()->query_real_name());
    save_object("players/reflex/realms/weddings/church/save");
    }
return 1;
}

hl_join(){
 if(this_player()->query_ghost()) return 1;
 if(this_player()->query_level() < 8){
   write("You must be at least 8th level.\n");
   return 1;
   }
 if(!this_player()->query_pl_k()){
   write("Your PK must be set!\n");
   return 1;
   }
 if(present("immortal_object", this_player())){
    write("You are already enrolled!\n");
    return 1;
    }
 if(get_join(this_player()->query_real_name())){
    write("You have already been in the Gathering.\n"+
          "NOTE: This does not mean you can rejoin with another character!\n");
    return 1;
    }
 if(!get_info(this_player()->query_real_name())){
    write("You must first read the INFO!  type 'info' to do so now.\n");
    return 1;
    }
 if(!get_rules(this_player()->query_real_name())){
    write("You must first read the RULES!  type 'rules' to do so now.\n");
    return 1;
    }
 add_join(this_player()->query_real_name());
 write("Welcome to the Gathering. Remember, there can be only One.\n");
 move_object(clone_object("/players/maledicta/closed/imm/imm"), this_player());
 write_file("/players/reflex/realms/weddings/church/JOINED",
 this_player()->query_real_name()+" joined the Gathering on "+ctime(time())+"\n");
 save_object("players/reflex/realms/weddings/church/save");
 return 1;
 }

get_rules(str){
 if(member_array(str, rules) != -1) return 1;
 return 0;
 }

add_rules(str){
 if(!rules) rules = ({ str });
 else rules += ({ str });
 }


get_info(str){
 if(member_array(str, info) != -1) return 1;
 return 0;
 }

add_info(str){
 if(!info) info = ({ str });
 else info += ({ str });
 }

get_join(str){
 if(member_array(str, join) != -1) return 1;
 return 0;
 }

add_join(str){
 if(!join) join = ({ str });
 else join += ({ str });
 }
