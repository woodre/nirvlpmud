#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    query_no_fight(){ return 1; }
void create() {
if(!present("monk_book", this_object())){
  move_object(clone_object("/players/maledicta/closed/w/OBJ/trainer_paladin"), this_object());
   }
::create();
    set_short(BOLD+"A Holy Place"+NORM);
    set_long(BOLD+
        "The Altar room.\n"+NORM+
	"You are in a large circular room.  Weapons line the walls\n"+
	"ranging from a small pair of hand axes to a giant GreatSword\n"+
	"as tall as you are.  The floor has a giant symbol of a cross,\n"+
	"with the lines intersecting at the base of a plain looking altar.\n"+
	"There is a inset at the base of the altar where rests a book.\n"+
	"With the exception of the symbol on the floor, the rest of the\n"+
	"room and ceiling are completely bare except for a small mat for\n"+
	"kneeling before the altar.  There is a wooden door exiting to\n"+
	"the east.\n");
    set_items(([
        "weapons" :
        "Weapons of all types, from Sai to battleaxes' line the walls.\n", 
        "axes" :
        "One of the many weapons that are mounted on the wall.\n",
        "greatsword" :
        "This exquisite sword is as large as you are!!!\n",
        "floor" :
        "The floor is completely bare with except for the mat in front of\n"+
	"the altar and the symbol of a cross, intersecting the altar\n",
        "symbol" :
        "The symbol of a cross, intersecting the alter.\n",
        "altar" :
        "This is a plain altar with a mat in front of it for you to kneel.\n",
        "inset" :
        "This is a small shelf set slightly into the altar.  A book rests upon it.\n",
	"ceiling" :
	"A completely bare wood ceiling.\n",
	"mat" :
	"A small mat placed in front of the alter.\n",
	"door" :
	"This is a plain wooden door leading east to the cathedral.\n",
        ]));
    set_smells(([
	"default" :
	"The smell of oiled weapons permeates this room.\n",
	]));
    set_sounds(([
	"default" :
	"It is very silent here.\n",
	]));
    set_exits(([
        "east" : "/players/reflex/realms/weddings/church/church",
        ]));
    set_light(1);
    replace_program(ROOM);
}
