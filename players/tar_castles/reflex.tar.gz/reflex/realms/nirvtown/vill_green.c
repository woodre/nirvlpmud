#include "/players/reflex/lib/lib.h"
inherit ROOM;

    query_no_fight(){ return 1; }
void create() {
::create();
    set_short("The Village Green");
    set_long(
        "The Village Green.\n"+
        "This is an open place south of the village church.  People\n"+
        "gather here to share stories, buy and sell equipment, and\n"+
        "generally socialize.  The green is a small park with\n"+
        "benches in a semi-circle on the southern and northern side,\n"+
        "seperated by a path that runs to the east and west.  To the\n"+
        "east is the main village, while to the west you can see a\n"+
        "small bridge along the path.  To the north are the open\n"+
        "doors of the church.\n"
        );
    set_items(([
        "church" :
        "An old village church to the north.\n", 
        "benches" :
        "Several wooden benches are arrayed around the park for seating.\n",
        "path" :
        "The path is paved here, but to the west you can see that it\n"+
        "quickly becomes a dirt road, while to the east it is pavement.\n",
        "bridge" :
        "A small, hump-backed bridge can be seen off to the west.\n",
        "doors" :
        "The wooden doors to the church are open.\n",
        ]));
    set_smells(([
        "default" :
        "The air is fresh and you can smell freshly cut grass.\n",
        ]));
    set_sounds(([
        "default" :
        "Birds chirp and you can feel the breeze in your hair.\n",
        ]));
    set_exits(([
        "north" : "/players/reflex/realms/nirvtown/church",
        "east" : "/players/reflex/realms/nirvtown/vill_track",
        "west" : "/players/reflex/realms/nirvtown/hump",
        ]));
    set_light(1);
    replace_program(ROOM);
}
