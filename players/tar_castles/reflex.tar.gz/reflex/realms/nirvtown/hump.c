#include "/players/reflex/lib/lib.h"
inherit ROOM;

    query_no_fight(){ return 1; }
void create() {
::create();
    set_short("A Humpbacked Bridge");
    set_long(
        "A Humpbacked Bridge.\n"+
        "This is an old humpbacked bridge marking the western edge\n"+
        "of the main village.  A small stream runs underneath and\n"+
        "you can see many fish in its waters.  To the east you can\n"+
        "see a large park and beyond that the main village, while\n"+
        "to the west the path continues into a dark wooded area.\n"
        );
    set_items(([
        "bridge" :
        "This is an old bridge marking the boundries to the village.\n", 
        "stream" :
        "This stream is probably the villages main source of water.\n",
        "path" :
        "The path is is a dirt road to the west, but is paved to the\n"+
        "east as it enters the village.\n",
        "fish" :
        "You can make out several fish swimming in the stream below.\n",
        "village" :
        "A small village is visible to the east.\n",
        ]));
    set_smells(([
	  "default" :
	  "The air is fresh and somewhat humid.\n",
	  ]));
    set_sounds(([
	  "default" :
	  "The stream gurgles loudly beneath the bridge.\n",
	  ]));
    set_exits(([
        "east" : "/players/reflex/realms/nirvtown/vill_green",
        "west" : "/players/reflex/realms/nirvtown/wild1",
        ]));
    set_light(1);
    replace_program(ROOM);
}
