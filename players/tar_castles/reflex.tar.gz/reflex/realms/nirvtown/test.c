#include "std.h"
#include "/players/reflex/lib/lib.h"
inherit ROOM;

int lamp_is_lit, reboot_time, time_from_reset, last_reset_cycle;
int list_length;
object weath;

    query_no_fight(){ return 1; }
void create() {
::create();

reset(arg)
{
    call_other("room/test", "short", 0)
    ;
  if(!present("clock", find_object("room/test.c"))) {
    weath=clone_object("obj/autoshut");
    move_object(weath, "room/test.c");
  }

  if(!present("candles",this_object())){
  move_object(
    clone_object("/obj/candles"),
  this_object()); 
  }

    if (time_from_reset)
        last_reset_cycle = time() - time_from_reset;
    time_from_reset = time();
    if (arg)
        return;
    /* Next if-statement is to prevent against wizards. */
    if (reboot_time == 0)

if(!arg)
    set_light(1);
    reboot_time = time();
}

    set_short("The Village Church");
    set_long(
        "The Village Church.\n"+
        "This is a small village church in the center of town.  Here\n"+
        "it is said that ghosts can come to be revived.  The church\n"+
        "is built of brick, morter and wood, with a vaulted ceiling\n"+
        "that reaches high above your head.  There are several wooden\n"+
        "pews lining the right and left sides of the church, and a\n"+
        "large area before a pit for worship.  There is a door in the\n"+
        "western wall, and there is a button beside it.  To the south\n"+
        "the doors stand open, and you can see a village green beyond.\n"+
        "There is an exit to a clinic to the east, and the town hall\n"+
        "lies to the north.  "
        );
        if (lamp_is_lit)
        write("The lamp beside the elevator is lit.\n");
    set_items(([
        "brick" :
        "The bricks are very old with many cracks in them.\n", 
        "mortor" :
        "The mortor is a dirty grey color and is missing between many\n"+
        "of the bricks.\n",
        "wood" :
        "Ancient hardwood beams support the building.\n",
        "ceiling" :
        "The high ceiling has many paintings of the various gods that\n"+
        "have been worshipped here over the centuries.\n",
        "paintings" :
        "The ceiling is adorned with several of these paintings, among\n"+
        "them you recognize the images of Larn, the God of Healing,\n"+
        "Shardak, the Demon of Death, and Boltar, Lord of the Land.\n",
        "pews" :
        "Very basic wooden pews for seating.\n",
        "pit" :
        "This is a deep pit.  In older times it was used for sacrifices\n"+
        "to the Gods, but now it is only used for tourists to look at.\n",
        "doors" :
        "Double wooden doors stand open providing a view of the green to\n"+
        "the south.\n",
        ]));
    set_smells(([
	  "default" :
	  "The room smells of fresh air from outside.\n",
	  "pews" :
	  "Pee-Yew!(what did you expect..?)\n",
	  ]));
    set_sounds(([
	  "default" :
	  "You hear muffled conversation from outside.\n",
	  ]));
    set_exits(([
        "south" : "/players/reflex/realms/nirvtown/vill_green",
        "north" : "/players/reflex/realms/nirvtown/townh",
        "east" : "/players/reflex/realms/nirvtown/clinic",
        ]));
    set_light(1);
    replace_program(ROOM);
}

xyzzy() {
    write("Everything shimmers.\n");
    write("You wake up elsewhere...\n");
    call_other(this_player(), "move_player", "elsewhere#room/test");
}

init()
{
   rem_agg();
    add_action("west"); add_verb("west");
    add_action("open"); add_verb("open");
    add_action("push"); add_verb("push");
    add_action("push"); add_verb("press");
    add_action("close"); add_verb("close");
    add_action("pray"); add_verb("pray");
    add_action("pray", "regenerate");
}

west() {
    if (call_other("room/elevator", "query_door", 0) ||
        call_other("room/elevator", "query_level", 0) != 2) {
        write("The door is closed.\n");
        return 1;
    }
    call_other(this_player(), "move_player", "west#room/elevator");
    return 1;
}

open(str)
{
    if (str != "door")
        return 0;
    if (call_other("room/elevator", "query_level", 0) != 2) {
        write("You can't when the elevator isn't here.\n");
        return 1;
    }
    call_other("room/elevator", "open_door", "door");
    return 1;
}

close(str)
{
    if (str != "door")
        return 0;
    call_other("room/elevator", "close_door", "door");
    return 1;
}

push(str)
{
    if (str && str != "button")
        return 0;
    if (call_other("room/elevator", "call_elevator", 2))
        lamp_is_lit = 1;
    return 1;
}

elevator_arrives()
{
    say("The lamp on the button beside the elevator goes out.\n");
    lamp_is_lit = 0;
}

pray() {
    if(this_player()->query_guild_name() == "shardak")
    {
      object mark;
      if(mark = present("shardak_mark", this_player()))
      {
        write("You may not pray at this most holiest of places.\n");
        return 1;
      }
    }
    return call_other(this_player(), "remove_ghost", 0);
}

prevent_look_at_inv(str)
{
    return str != 0;
}

/*
 * The next call of combine_free_list() is dependant of how long the free list
 * is. However, resorting the free list goes fast if the list is already
 * sorted.
 */

call_combine() {
    int tmp;
    tmp = time();
    list_length = combine_free_list();
    if (time() - tmp > 20)
        shout("Game driver shouts: Sorry for the delay. I had some garbage"+
            "collection to do.\n");
    if (list_length < 1000)
        call_out("call_combine", 10);
    else if (list_length < 5000)
        call_out("call_combine", 30);
    else
        call_out("call_combine", 60 * 2);
}

query_drop_castle() {
    return 1;
}
query_reboot_time(){
       return reboot_time;
}
nomask string valid_read(string path) { }
nomask string valid_write(string path) { }
rem_agg() {
   object what;
   object ob;
   what = this_object();
   ob = first_inventory(what);
   if (ob) {
      
      while(ob) {
          if(ob->query_aggressive()) { 
            write(ob->short()+" vanishes in a puff of smoke.\n");
            move_object(ob,"room/south/sforst29");
          }
         ob = next_inventory(ob);
       }
   }
   return 1;
}
