#include "/players/reflex/lib/lib.h"
inherit ROOM;

    query_no_fight(){ return 1; }
void create() {
::create();
    set_short("Village Path");
    set_long(
        "Village Path.\n"+
        "This is the path into the main village.  The pavement here\n"+
        "is well worn, and there is a lot of traffic passing you by\n"+
        "going to the east and west.  Trees line the path to the\n"+
        "north and south.  The path continues east into the village,\n"+
        "and heads west to the village green.  To the south you see\n"+
        "a small footpath, and to the north there is another path.\n"
        );
    set_items(([
        "pavement" :
        "The pavement is worn and cracked from heavy travel.\n", 
        "traffic" :
        "People pass you on either side, most going east or west.\n",
        "trees" :
        "Tall trees line the path to the north and south.\n",
        "trees" :
        "These are large oak trees.\n",
        "footpath" :
        "This is a small path leading through the trees to the south.\n",
        ]));
    set_smells(([
        "default" :
        "The air is dusty here from the heavy traffic.\n",
        ]));
    set_sounds(([
        "default" :
        "The hustle and bustle of people traveling.\n",
        ]));
    set_exits(([
        "north" : "/players/catt/AREAS/TEMPLE/monkroom1",
        "south" : "/players/reflex/realms/nirvtown/path2",
        "east" : "/players/reflex/realms/nirvtown/vill_road1",
        "west" : "/players/reflex/realms/nirvtown/vill_green",
        ]));
    set_light(1);
    replace_program(ROOM);
}
