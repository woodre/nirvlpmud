#include "/players/reflex/lib/lib.h"
inherit ROOM;

    query_no_fight(){ return 1; }
void create() {
::create();
    set_short("The Village Church");
    set_long(
        "The Village Church.\n"+
        "This is a small village church in the center of town.  Here\n"+
        "it is said that ghosts can come to be revived.  The church\n"+
        "is built of brick, morter and wood, with a vaulted ceiling\n"+
        "that reaches high above your head.  There are several wooden\n"+
        "pews lining the right and left sides of the church, and a\n"+
        "large area before a pit for worship.  There is a door in the\n"+
        "western wall, and there is a button beside it.  To the south\n"+
        "the door stands open, and you can see a village green beyond.\n"
        );
    set_items(([
        "brick" :
        "The bricks are very old with many cracks in them.\n", 
        "morter" :
        "The mortor is a dirty grey color and is missing between many\n"+
        "of the bricks.\n",
        "wood" :
        "Ancient hardwood beams support the building.\n",
        "ceiling" :
        "The high ceiling has many paintings of the various gods that\n"+
        "have been worshipped here over the centuries.\n",
        "paintings" :
        "The ceiling is adorned with several of these paintings, among\n"+
        "them you recognize the images of Larn, the God of Healing,\n"+
        "Shardak, the Demon of Death, and Boltar, Lord of the Land.\n",
        "pews" :
        "Very basic wooden pews for seating.\n",
        "pit" :
        "This is a deep pit.  In older times it was used for sacrifices\n"+
        "to the Gods, but now it is only used for tourists to look at.\n",
        "door" :
        "Double wooden doors stand open providing a view of the green to\n"+
        "the south.\n",
        ]));
    set_smells(([
	  "default" :
	  "The room smells of fresh air from outside.\n",
	  "pews" :
	  "Pee-Yew!(what did you expect..?)\n",
	  ]));
    set_sounds(([
	  "default" :
	  "You hear muffled conversation from outside.\n",
	  ]));
    set_exits(([
        "south" : "/players/reflex/realms/nirvtown/vill_green",
        ]));
    set_light(1);
    replace_program(ROOM);
}
