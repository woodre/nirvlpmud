#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

void create() {
::create();
    set_short(BOLD+"Nirvana Council Chamber"+NORM);
    set_long(
	"The council chamber has a large round table in the middle.  Arrayed\n"+
	"around the table are large, comfortable looking chairs, each with the\n"+
	"symbol of a Nirvana guild on the back.  There is one chair set\n"+
	"aside for the moderator, and a row of seats along one side of the\n"+
	"room for guests to occupy.  Torches glowing with a magical blue\n"+
	"flame ring the room, and a large hanging lamp is over the center of\n"+
	"the table.  Everything is done in oak with a gold trim, and you get\n"+
	"the feeling that decisions of great import are made in this place.\n"+
	"There is a oak door to the south leading out of the chamber.\n");
    set_items(([
        "table" :
        "A large, solid oak table with plenty of space for members of all\n"+
	"guilds to gather around to discuss the issues of the day.\n",
	"chair" :
	"Each chair has the symbol of the guild who is assigned that seat.\n"+
	"There is one chair emblazened with the symbol of Nirvana for the\n"+
	"moderator to occupy.\n",
	"seats" :
	"These seats line the west wall and are for other visitors to occupy\n"+
	"while listening in on council sessions.\n",
	"torches" :
	"These wrought iron torches glow with a mystical blue flame,\n"+
	"strangly they are not hot to the touch.\n",
	"lamp" :
	"This lamp hangs from the ceiling above the table.  It casts its\n"+
	"light upon those who are gathered in council together.\n",
        ]));
    set_smells(([
	"default" :
	"You smell nothing in paticuliar.\n",
	]));
    set_sounds(([
	"default" :
	"You hear nothing in paticuliar.\n",
	]));
    set_chat_frequency(80);
    set_exits(([
        "south" : "/players/reflex/realms/council/entry",
        ]));
    set_light(1);
    replace_program(ROOM);
}
