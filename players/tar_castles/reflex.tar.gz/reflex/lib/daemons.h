#ifndef _DAEMONS_H_
#define _DAEMONS_H_

#define DIR_DAEMONS "/players/reflex/lib/daemons/"

#define SOULD (DIR_DAEMONS + "atmos")
#define POPULATIOND (DIR_DAEMONS + "populous")
#define CHANNELD (DIR_DAEMONS + "channel")

#endif
