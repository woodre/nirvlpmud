#define file "/players/reflex/all.help"

status main(string arg)
{
    string *help_files;
    int i, s, column;
    if(arg) return 0;
    s = sizeof(help_files = get_dir("/doc/helpdir/"));
    rm(file);
    write("Making all...\n");
    write_file(file, "\n");
    for(i = 0; i < s; i ++)
    {
      if(!column)
        write_file(file, " ");

      write_file(file, pad(help_files[i], 15));
      if(column ++ > 2)
      {
        write_file(file, "\n");
        column = 0;
      }
    }

    write_file(file, "\n");
    write("Ok.\n");
    return 1;
}

id(str) { return (str=="makeall"||str=="obj"||str=="makeall obj"); }

init()
{
  if(this_player()->query_level() < 21) return;
  add_action("main", "makeall");
}

short() { return "makeall obj"; }

drop() { return 1; }
get() { return 1; }

