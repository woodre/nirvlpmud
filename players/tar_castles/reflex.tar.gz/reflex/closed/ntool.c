#include "/players/maledicta/ansi.h"
int filen;
int nroom;
string rtype;
string dirlist;
int snum;
int newx;
int ldang;
int ddang;
int e1;
string et1;
int e2;
string et2;
int e3;
string et3;
int e4;
string et4;
string *room_num;

id(str) { return str == "rtool"; }

query_weight(){ return 0; }
query_value(){ return 0; }

short(){return "a room tool"; }
long(){
	write("'make'\n");
	return 1;}

reset(arg){
if(arg) return;

}

init(){
if(!environment()) return;
if(environment()->query_level() < 20){
destruct(this_object());
}
add_action("make_it", "make");
add_action("what_room","rtype");
add_action("set_up_array", "setarray");
}

what_room(int x){

sscanf(x, "%d", newx);
	write(""+room_num[newx]+"\n");
	return 1;
}

set_up_array(){
room_num = allocate(999);
room_num = ({ "X",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","#","~",
"~","~","~","~","~","#","~","~",
"@","#","~","~","~","~","~","~",
"~","~","~","#","M","~","~","~",
"~","~","#","#","#","@","@","#",
"~","~","~","~","#","#","#","#",
"@","@","@","#","#","~","~","~",
"~","~","~","@","@","M","~","~",
"~","~","#","#","@","@","@","#",
"~","~","~","~","n","#","#","#",
"@","@","@","@","#","#","#","~",
"~","~","~","#","@","M","~","~",
"~","~","~","#","@","@","@","@",
"~","~","~","~","~","n","#","@",
"@","@","@","@","@","#","#","#",
"#","~","~","~","#","#","~","~",
"~","~","~","#","@","@","@","@",
"~","~","~","~","M","n","@","@",
"@","@","@","@","@","@","#","#",
"#","#","~","~","~","~","~","~",
"~","~","~","#","@","@","@","@",
"#","~","~","M","M","n","n","@",
"@","@","@","@","@","@","@","#",
"#","#","~","~","~","~","~","~",
"~","~","~","~","@","@","@","#",
"~","~","~","M","M","n","#","n",
"@","@","@","@","@","@","#","#",
"#","@","#","#","~","~","~","~",
"~","~","~","#","@","@","@","#",
"~","~","~","M","n","n","#","n",
"n","n","@","@","@","#","#","#",
"@","@","@","#","#","~","~","~",
"~","~","~","#","#","@","#","~",
"~","~","~","M","M","n","#","n",
"#","#","#","@","@","@","#","#",
"@","@","#","#","#","~","~","~",
"~","~","~","~","#","#","#","~",
"~","~","~","~","~","M","n","#",
"#","#","#","#","@","@","@","#",
"#","#","~","~","~","~","~","~",
"~","~","~","~","#","#","~","~",
"~","-","+","n","~","M","n","#",
"@","#","#","@","@","@","@","#",
"~","~","#","#","#","~","~","~",
"~","~","~","~","~","~","~","~",
"~","n","|","n","n","~","n","@",
"@","@","#","#","@","@","@","~",
"#","#","@","#","#","~","~","~",
"~","~","~","~","~","~","n","n",
"n","n","|","n","n","n","#","@",
"@","@","#","|","@","@","~","#",
"@","@","@","#","#","~","~","~",
"~","~","~","~","@","@","@","n",
"n","n","+","-","-","-","-","-",
"-","-","-","+","#","@","M","@",
"@","@","@","@","~","~","~","~",
"~","~","~","@","@","@","@","@",
"n","n","|","n","#","#","@","@",
"@","#","#","|","#","M","M","@",
"@","@","@","@","@","~","~","~",
"~","~","@","@","@","@","@","@",
"#","n","|","n","n","#","#","#",
"@","#","#","|","M","M","M","@",
"@","@","@","@","@","@","~","~",
"~","~","@","@","@","@","@","@",
"#","n","|","#","n","n","#","@",
"@","@","#","|","M","M","@","@",
"@","+","-","-","-","-","~","~",
"~","~","@","#","@","@","@","#",
"#","n","|","#","n","n","#","#",
"@","@","#","+","-","-","-","-",
"-","+","@","@","@","~","~","~",
"~","~","#","#","@","@","#","#",
"#","#","|","#","#","n","n","@",
"@","@","@","|","#","M","n","n",
"#","@","@","@","@","@","~","~",
"~","~","~","#","#","@","#","#",
"+","-","+","n","#","n","n","@",
"@","@","@","|","#","M","M","n",
"n","#","@","@","@","~","~","~",
"~","~","~","~","~","~","#","#",
"|","#","n","M","n","n","@","@",
"@","#","#","|","#","~","M","n",
"n","n","@","@","@","#","~","~",
"~","~","#","#","#","#","#","#",
"|","#","n","M","M","n","#","@",
"@","+","-","+","~","M","M","n",
"n","#","#","@","#","#","~","~",
"~","~","#","@","@","@","#","#",
"|","#","#","n","M","n","#","#",
"@","|","@","#","~","M","n","n",
"#","#","#","#","@","~","~","~",
"~","~","@","@","@","@","@","#",
"|","#","#","n","M","M","n","#",
"#","|","#","#","~","M","n","n",
"#","#","@","#","@","~","~","~",
"~","~","-","-","-","-","-","-",
"+","#","n","M","M","M","n","#",
"#","#","#","~","~","~","n","n",
"~","~","~","#","#","~","~","~",
"~","~","~","@","@","@","@","#",
"#","#","n","M","M","M","n","#",
"#","#","~","~","~","~","n","~",
"~","~","#","#","#","#","~","~",
"~","~","~","@","@","@","#","#",
"~","#","#","n","M","~","n","#",
"#","~","~","~","~","~","~","~",
"#","#","#","#","~","#","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
"~","~","~","~","~","~","~","~",
});
return 1; } 


check1(int x){
     if(room_num[nroom - 62] == "~") return HIB+room_num[nroom - 62]+NORM; 
else if(room_num[nroom - 62] == "M") return BOLD+room_num[nroom - 62]+NORM; 
else if(room_num[nroom - 62] == "n") return YEL+room_num[nroom - 62]+NORM; 
else if(room_num[nroom - 62] == "@") return HIG+room_num[nroom - 62]+NORM; 
else if(room_num[nroom - 62] == "#") return GRN+room_num[nroom - 62]+NORM; 
else return HIR+room_num[nroom - 62]+NORM;
}
check2(int x){
     if(room_num[nroom - 63] == "~") return HIB+room_num[nroom - 63]+NORM; 
else if(room_num[nroom - 63] == "M") return BOLD+room_num[nroom - 63]+NORM; 
else if(room_num[nroom - 63] == "n") return YEL+room_num[nroom - 63]+NORM; 
else if(room_num[nroom - 63] == "@") return HIG+room_num[nroom - 63]+NORM; 
else if(room_num[nroom - 63] == "#") return GRN+room_num[nroom - 63]+NORM; 
else return HIR+room_num[nroom - 63]+NORM;
}
check3(int x){
     if(room_num[nroom - 64] == "~") return HIB+room_num[nroom - 64]+NORM; 
else if(room_num[nroom - 64] == "M") return BOLD+room_num[nroom - 64]+NORM; 
else if(room_num[nroom - 64] == "n") return YEL+room_num[nroom - 64]+NORM; 
else if(room_num[nroom - 64] == "@") return HIG+room_num[nroom - 64]+NORM; 
else if(room_num[nroom - 64] == "#") return GRN+room_num[nroom - 64]+NORM; 
else return HIR+room_num[nroom - 64]+NORM;
}

check4(int x){
     if(room_num[nroom - 65] == "~") return HIB+room_num[nroom - 65]+NORM; 
else if(room_num[nroom - 65] == "M") return BOLD+room_num[nroom - 65]+NORM; 
else if(room_num[nroom - 65] == "n") return YEL+room_num[nroom - 65]+NORM; 
else if(room_num[nroom - 65] == "@") return HIG+room_num[nroom - 65]+NORM; 
else if(room_num[nroom - 65] == "#") return GRN+room_num[nroom - 65]+NORM; 
else return HIR+room_num[nroom - 65]+NORM;
}

check5(int x){ 
     if(room_num[nroom - 66] == "~") return HIB+room_num[nroom - 66]+NORM; 
else if(room_num[nroom - 66] == "M") return BOLD+room_num[nroom - 66]+NORM; 
else if(room_num[nroom - 66] == "n") return YEL+room_num[nroom - 66]+NORM; 
else if(room_num[nroom - 66] == "@") return HIG+room_num[nroom - 66]+NORM; 
else if(room_num[nroom - 66] == "#") return GRN+room_num[nroom - 66]+NORM; 
else return HIR+room_num[nroom - 66]+NORM;
}

check6(int x){ 
     if(room_num[nroom - 30] == "~") return HIB+room_num[nroom - 30]+NORM; 
else if(room_num[nroom - 30] == "M") return BOLD+room_num[nroom - 30]+NORM; 
else if(room_num[nroom - 30] == "n") return YEL+room_num[nroom - 30]+NORM; 
else if(room_num[nroom - 30] == "@") return HIG+room_num[nroom - 30]+NORM; 
else if(room_num[nroom - 30] == "#") return GRN+room_num[nroom - 30]+NORM; 
else return HIR+room_num[nroom - 30]+NORM;
}

check7(int x){ 
     if(room_num[nroom - 31] == "~") return HIB+room_num[nroom - 31]+NORM; 
else if(room_num[nroom - 31] == "M") return BOLD+room_num[nroom - 31]+NORM; 
else if(room_num[nroom - 31] == "n") return YEL+room_num[nroom - 31]+NORM; 
else if(room_num[nroom - 31] == "@") return HIG+room_num[nroom - 31]+NORM; 
else if(room_num[nroom - 31] == "#") return GRN+room_num[nroom - 31]+NORM; 
else return HIR+room_num[nroom - 31]+NORM;
}

check8(int x){ 
     if(room_num[nroom - 32] == "~") return HIB+room_num[nroom - 32]+NORM; 
else if(room_num[nroom - 32] == "M") return BOLD+room_num[nroom - 32]+NORM; 
else if(room_num[nroom - 32] == "n") return YEL+room_num[nroom - 32]+NORM; 
else if(room_num[nroom - 32] == "@") return HIG+room_num[nroom - 32]+NORM; 
else if(room_num[nroom - 32] == "#") return GRN+room_num[nroom - 32]+NORM; 
else return HIR+room_num[nroom - 32]+NORM;
}

check9(int x){ 
     if(room_num[nroom - 33] == "~") return HIB+room_num[nroom - 33]+NORM; 
else if(room_num[nroom - 33] == "M") return BOLD+room_num[nroom - 33]+NORM; 
else if(room_num[nroom - 33] == "n") return YEL+room_num[nroom - 33]+NORM; 
else if(room_num[nroom - 33] == "@") return HIG+room_num[nroom - 33]+NORM; 
else if(room_num[nroom - 33] == "#") return GRN+room_num[nroom - 33]+NORM; 
else return HIR+room_num[nroom - 33]+NORM;
}

check10(int x){  
     if(room_num[nroom - 34] == "~") return HIB+room_num[nroom - 34]+NORM; 
else if(room_num[nroom - 34] == "M") return BOLD+room_num[nroom - 34]+NORM; 
else if(room_num[nroom - 34] == "n") return YEL+room_num[nroom - 34]+NORM; 
else if(room_num[nroom - 34] == "@") return HIG+room_num[nroom - 34]+NORM; 
else if(room_num[nroom - 34] == "#") return GRN+room_num[nroom - 34]+NORM; 
else return HIR+room_num[nroom - 34]+NORM;
}
	
check11(int x){  
     if(room_num[nroom - 2] == "~") return HIB+room_num[nroom - 2]+NORM; 
else if(room_num[nroom - 2] == "M") return BOLD+room_num[nroom - 2]+NORM; 
else if(room_num[nroom - 2] == "n") return YEL+room_num[nroom - 2]+NORM; 
else if(room_num[nroom - 2] == "@") return HIG+room_num[nroom - 2]+NORM; 
else if(room_num[nroom - 2] == "#") return GRN+room_num[nroom - 2]+NORM; 
else return HIR+room_num[nroom - 2]+NORM;
}


check12(int x){ 
     if(room_num[nroom - 1] == "~") return HIB+room_num[nroom - 1]+NORM; 
else if(room_num[nroom - 1] == "M") return BOLD+room_num[nroom - 1]+NORM; 
else if(room_num[nroom - 1] == "n") return YEL+room_num[nroom - 1]+NORM; 
else if(room_num[nroom - 1] == "@") return HIG+room_num[nroom - 1]+NORM; 
else if(room_num[nroom - 1] == "#") return GRN+room_num[nroom - 1]+NORM; 
else return HIR+room_num[nroom - 1]+NORM;
}
 
check14(int x){  
     if(room_num[nroom + 1] == "~") return HIB+room_num[nroom + 1]+NORM; 
else if(room_num[nroom + 1] == "M") return BOLD+room_num[nroom + 1]+NORM; 
else if(room_num[nroom + 1] == "n") return YEL+room_num[nroom + 1]+NORM; 
else if(room_num[nroom + 1] == "@") return HIG+room_num[nroom + 1]+NORM; 
else if(room_num[nroom + 1] == "#") return GRN+room_num[nroom + 1]+NORM; 
else return HIR+room_num[nroom + 1]+NORM;
}


check15(int x){
     if(room_num[nroom + 2] == "~") return HIB+room_num[nroom + 2]+NORM; 
else if(room_num[nroom + 2] == "M") return BOLD+room_num[nroom + 2]+NORM; 
else if(room_num[nroom + 2] == "n") return YEL+room_num[nroom + 2]+NORM; 
else if(room_num[nroom + 2] == "@") return HIG+room_num[nroom + 2]+NORM; 
else if(room_num[nroom + 2] == "#") return GRN+room_num[nroom + 2]+NORM; 
else return HIR+room_num[nroom + 2]+NORM;
} 

check16(int x){
     if(room_num[nroom + 30] == "~") return HIB+room_num[nroom + 30]+NORM; 
else if(room_num[nroom + 30] == "M") return BOLD+room_num[nroom + 30]+NORM; 
else if(room_num[nroom + 30] == "n") return YEL+room_num[nroom + 30]+NORM; 
else if(room_num[nroom + 30] == "@") return HIG+room_num[nroom + 30]+NORM; 
else if(room_num[nroom + 30] == "#") return GRN+room_num[nroom + 30]+NORM; 
else return HIR+room_num[nroom + 30]+NORM;
}
 
check17(int x){
     if(room_num[nroom + 31] == "~") return HIB+room_num[nroom + 31]+NORM; 
else if(room_num[nroom + 31] == "M") return BOLD+room_num[nroom + 31]+NORM; 
else if(room_num[nroom + 31] == "n") return YEL+room_num[nroom + 31]+NORM; 
else if(room_num[nroom + 31] == "@") return HIG+room_num[nroom + 31]+NORM; 
else if(room_num[nroom + 31] == "#") return GRN+room_num[nroom + 31]+NORM; 
else return HIR+room_num[nroom + 31]+NORM;
}
 
check18(int x){ 
     if(room_num[nroom + 32] == "~") return HIB+room_num[nroom + 32]+NORM; 
else if(room_num[nroom + 32] == "M") return BOLD+room_num[nroom + 32]+NORM; 
else if(room_num[nroom + 32] == "n") return YEL+room_num[nroom + 32]+NORM; 
else if(room_num[nroom + 32] == "@") return HIG+room_num[nroom + 32]+NORM; 
else if(room_num[nroom + 32] == "#") return GRN+room_num[nroom + 32]+NORM; 
else return HIR+room_num[nroom + 32]+NORM;
}

check19(int x){ 
     if(room_num[nroom + 33] == "~") return HIB+room_num[nroom + 33]+NORM; 
else if(room_num[nroom + 33] == "M") return BOLD+room_num[nroom + 33]+NORM; 
else if(room_num[nroom + 33] == "n") return YEL+room_num[nroom + 33]+NORM; 
else if(room_num[nroom + 33] == "@") return HIG+room_num[nroom + 33]+NORM; 
else if(room_num[nroom + 33] == "#") return GRN+room_num[nroom + 33]+NORM; 
else return HIR+room_num[nroom + 33]+NORM;
}
	
check20(int x){ 
     if(room_num[nroom + 34] == "~") return HIB+room_num[nroom + 34]+NORM; 
else if(room_num[nroom + 34] == "M") return BOLD+room_num[nroom + 34]+NORM; 
else if(room_num[nroom + 34] == "n") return YEL+room_num[nroom + 34]+NORM; 
else if(room_num[nroom + 34] == "@") return HIG+room_num[nroom + 34]+NORM; 
else if(room_num[nroom + 34] == "#") return GRN+room_num[nroom + 34]+NORM; 
else return HIR+room_num[nroom + 34]+NORM;
}
	
check21(int x){ 
     if(room_num[nroom + 62] == "~") return HIB+room_num[nroom + 62]+NORM; 
else if(room_num[nroom + 62] == "M") return BOLD+room_num[nroom + 62]+NORM; 
else if(room_num[nroom + 62] == "n") return YEL+room_num[nroom + 62]+NORM; 
else if(room_num[nroom + 62] == "@") return HIG+room_num[nroom + 62]+NORM; 
else if(room_num[nroom + 62] == "#") return GRN+room_num[nroom + 62]+NORM; 
else return HIR+room_num[nroom + 62]+NORM;
}
	
check22(int x){ 
     if(room_num[nroom + 63] == "~") return HIB+room_num[nroom + 63]+NORM; 
else if(room_num[nroom + 63] == "M") return BOLD+room_num[nroom + 63]+NORM; 
else if(room_num[nroom + 63] == "n") return YEL+room_num[nroom + 63]+NORM; 
else if(room_num[nroom + 63] == "@") return HIG+room_num[nroom + 63]+NORM; 
else if(room_num[nroom + 63] == "#") return GRN+room_num[nroom + 63]+NORM; 
else return HIR+room_num[nroom + 63]+NORM;
} 
	
check23(int x){ 
     if(room_num[nroom + 64] == "~") return HIB+room_num[nroom + 64]+NORM; 
else if(room_num[nroom + 64] == "M") return BOLD+room_num[nroom + 64]+NORM; 
else if(room_num[nroom + 64] == "n") return YEL+room_num[nroom + 64]+NORM; 
else if(room_num[nroom + 64] == "@") return HIG+room_num[nroom + 64]+NORM; 
else if(room_num[nroom + 64] == "#") return GRN+room_num[nroom + 64]+NORM; 
else return HIR+room_num[nroom + 64]+NORM;
} 
	
check24(int x){ 
     if(room_num[nroom + 65] == "~") return HIB+room_num[nroom + 65]+NORM; 
else if(room_num[nroom + 65] == "M") return BOLD+room_num[nroom + 65]+NORM; 
else if(room_num[nroom + 65] == "n") return YEL+room_num[nroom + 65]+NORM; 
else if(room_num[nroom + 65] == "@") return HIG+room_num[nroom + 65]+NORM; 
else if(room_num[nroom + 65] == "#") return GRN+room_num[nroom + 65]+NORM; 
else return HIR+room_num[nroom + 65]+NORM;
} 
	
check25(int x){ 
     if(room_num[nroom + 66] == "~") return HIB+room_num[nroom + 66]+NORM; 
else if(room_num[nroom + 66] == "M") return BOLD+room_num[nroom + 66]+NORM; 
else if(room_num[nroom + 66] == "n") return YEL+room_num[nroom + 66]+NORM; 
else if(room_num[nroom + 66] == "@") return HIG+room_num[nroom + 66]+NORM; 
else if(room_num[nroom + 66] == "#") return GRN+room_num[nroom + 66]+NORM; 
else return HIR+room_num[nroom + 66]+NORM;
} 
	



make_it(str){
string sline;
string line1;
string line2;
string line3;
string line4;
string item1;
string item11;
string item2;
string item22;
string item3;
string item33;
string item4;
string item44;

sscanf(str,"%d", nroom);

if(!nroom){
write("duh.\n");
return 1;
}

if(room_num[nroom] == "~" || room_num[nroom] == "M"){
	write("Blocked room. "+nroom+"\n");
	return 1;
}

/* Create the short desc */
if(room_num[nroom] == "#"){
rtype = "plain";
sline = "a large plain";
}
else if(room_num[nroom] == "@"){
rtype = "forest";
sline = "a forest";
}
else if(room_num[nroom] == "n"){
rtype = "hills";
sline = "foothills";
}
else if(room_num[nroom] == "-"){
rtype = "road";
sline = "a road";
}
else if(room_num[nroom] == "+"){
rtype = "road";
sline = "a bend in the road";
}
else if(room_num[nroom] == "|"){
rtype = "road";
sline = "a road";
}
/*******************************/

/***** Create the Long desc ****/
if(room_num[nroom] == "#"){
line1 = "  This is a large open plain. All across the";
line2 = "landscape is tall grass which blows in waves";
line3 = "as the wind rushes along. Small rocks and an";
line4 = "occassional tree dot the fields.";
}
else if(room_num[nroom] == "@"){
line1 = "  You find yourself in a forest of giant trees.";
line2 = "All around these behemoths stand as guardians";
line3 = "to this quiet forest. Vegetation is scattered";
line4 = "throughout the forest as well as saplings.";
}
else if(room_num[nroom] == "n"){
line1 = "  This is a small grouping of foothills. Large";
line2 = "rocks jut out from the sides of each hill with";
line3 = "scattered boulders near the base. The ground";
line4 = "at the top of each is brown and weathered.";
}
else if(room_num[nroom] == "|"){
line1 = "  This is a worn road that runs to the north";
line2 = "and south. Alongside the road you see plenty";
line3 = "of vegetation and scattered rocks. Grooves";
line4 = "from wagon wheels have worn into the road.";
}
else if(room_num[nroom] == "-"){
line1 = "  This is a worn road that leads to the east.";
line2 = "and west. Alongside the road you see plenty";
line3 = "of vegetation and scattered rocks. Grooves";
line4 = "from wagon wheels have worn into the road.";
}
else if(room_num[nroom] == "+"){
line1 = "  Here the road curves and begins to lead";
line2 = "another direction. Alongside the road you see";
line3 = "vegetation and rocks. The road itself has many";
line4 = "deep grooves from wagon wheels.";
}
/***************************************************/

/****** Setup Item descs ***************************/
if(room_num[nroom] == "@"){
item1 = "trees";
item11 = "Giant trees that stand over 200 ft tall";
item2 = "saplings";
item22 = "Very young trees that seem to grow well here";
item3 = "vegetation";
item33 = "Scattered ferns and other lush and full plants";
item4 = "canopies";
item44 = "Large green canopies that filter the available light";
}
else if(room_num[nroom] == "#"){
item1 = "tree";
item11 = "The occassional sapling which has taken root outside the forest";
item2 = "grass";
item22 = "A tall thick green that covers this area thoroughly";
item3 = "sapling";
item33 = "A small sapling which has taken root outide the forest";
item4 = "rocks";
item44 = "Scattered rocks that lie about the landscape";
}
else if(room_num[nroom] == "n"){
item1 = "rocks";
item11 = "Large rocks that seem to run deep into the side of the hill";
item2 = "boulders";
item22 = "large rocks that lie strewn about the base of the hill";
item3 = "base";
item33 = "It seems to be cut and shaped by water and wind";
item4 = "ground";
item44 = "A dry and cracked ground at the top of the hills";
}
else if(room_num[nroom] == "+" || room_num[nroom] == "-" || room_num[nroom] == "|"){
item1 = "road";
item11 = "A well-worn dirt road that has deep grooves cut into it";
item2 = "vegetation";
item22 = "Small plants and lots of grass";
item3 = "rocks";
item33 = "Small rocks that lie strewn about the landscape";
item4 = "grooves";
item44 = "Large grooves cut into the dirt road by wagon wheels";
}
/******************************************************/



write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"#include \"/players/maledicta/ansi.h\"\n"+
"#define tp this_player()\n"+
"#define tpn this_player()->query_name()\n"+
"#define tpp this_player()->query_possessive()\n"+
"#define RNUM "+nroom+"\n"+
"inherit \"players/maledicta/cont/inherit/room\";\n\n\n"+
"string rtype;\n"+
"reset(arg){\n"+
"  if(arg) return;\n\n");




write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"short_desc = \""+sline+"\";\n"+
"set_light(1);\n"+
"rtype = \""+rtype+"\";\n");


write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"long_desc = \n"+
"\" "+check5(nroom)+" "+check4(nroom)+" "+check3(nroom)+" "+check2(nroom)+" "+check1(nroom)+" "+line1+"\\n\"+\n"+
"\" "+check10(nroom)+" "+check9(nroom)+" "+check8(nroom)+" "+check7(nroom)+" "+check6(nroom)+" "+line2+"\\n\"+\n"+
"\" "+check11(nroom)+" "+check12(nroom)+" X "+check14(nroom)+" "+check15(nroom)+" "+line3+"\\n\"+\n"+
"\" "+check16(nroom)+" "+check17(nroom)+" "+check18(nroom)+" "+check19(nroom)+" "+check20(nroom)+" "+line4+"\\n\"+\n"+
"\" "+check21(nroom)+" "+check22(nroom)+" "+check23(nroom)+" "+check24(nroom)+" "+check25(nroom)+"\\n\";\n");
/***  Setup exits ***/
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"dest_dir = ({\n");

if(room_num[nroom - 32] != "~" && room_num[nroom - 32] != "M"){
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"\"/players/maledicta/cont/rooms/"+(nroom-32)+".c\",\"north\",\n");
}
if(room_num[nroom + 32] != "~" && room_num[nroom + 32] != "M"){
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"\"/players/maledicta/cont/rooms/"+(nroom+32)+".c\",\"south\",\n");
}
if(room_num[nroom + 1] != "~" && room_num[nroom + 1] != "M"){
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"\"/players/maledicta/cont/rooms/"+(nroom+1)+".c\",\"east\",\n");
}
if(room_num[nroom - 1] != "~" && room_num[nroom - 1] != "M"){
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"\"/players/maledicta/cont/rooms/"+(nroom-1)+".c\",\"west\",\n");
}
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"});\n");
/*************************************************/

/***** Set up item Descs *************************/

write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"items = ({");
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"\""+item1+"\",\n"+
"\""+item11+"\",\n"+
"\""+item2+"\",\n"+
"\""+item22+"\",\n"+
"\""+item3+"\",\n"+
"\""+item33+"\",\n"+
"\""+item4+"\",\n"+
"\""+item44+"\",\n");
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
"});\n"+
"}\n\n\n"+
"init(){\n"+
"   ::init();\n\n"+
"}\n");
write_file("/players/maledicta/cont/rooms/"+nroom+".c",
	     "is_cont_mal(){ return 1; }\n"+
           "query_room_type(){ return rtype; }\n"+
           "query_room_num(){ return RNUM; }\n");
               

write("done "+nroom+"\n");
return 1;
}



