#include "/players/vertebraker/define.h"
inherit TREASURE

drop() { return 1; }
reset(x)
{
   if(x) return;
   set_id("alignment");
   set_short("Alignment setter");
   set_alias("thing");
}
init()
{
   ::init();
   add_action("setal","setal");
}
setal(string str)
{
   TP->set_ghost(str);
   write("Ok, alignment set.\n");
   return 1;
}
