#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short(BOLD+"A Clean Room"+NORM);
    set_long(
        "A clean room.\n"+
	"This is a clean room.  All oxygen has been purified.\n"+
	"This environment is completely sterile for the creation\n"+
	"of pure code.  The only exit is east to the office.\n"
        );
    set_smells(([
        "default" : 
        "Bleach is able to be smelled faintly...\n",
        ]));
    set_sounds(([
        "default" :
        "Enjoy the Silence(copyright Depeche Mode)\n",
    ]));
    set_exits(([
        "east" : "/players/reflex/workroom",
        ]));
    set_light(1);
}



