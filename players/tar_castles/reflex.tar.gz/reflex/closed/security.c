/* Thanks to Eurale for providing this code. */
/* Maledicta 1999                            */

#include "/players/maledicta/ansi.h"
#define TP this_player()
#define NAME "maledicta"
inherit "room/room";
int shield;

reset(arg) {
  if(arg) return;
move_object(clone_object("players/boltar/templar/board"), this_object());
short_desc = "a dark room ("+HIY+"lit up"+NORM+")";
long_desc =
"                   /`.    /`.\n"+
"                  f   \\  ,f  \\\n"+
"      Gee Brain,  |    \\/-`\\  \\      The same thing we do\n"+
"   what do you    i.  _\\';.,X j      every night, Pinky.\n"+
"     want to do    `:_\\ (  \\ \\',-.   Try to take over\n"+
"          tonight?   .'\"`\\ a\\eY' )   the world!  _,.\n"+
"                     `._\"\\`-' `-/            .-;'  |\n"+
"                       /;-`._.-';\\.        ,',\"    |\n"+
"                     .'/   \"'   | `\\.-'\"\"-/ /      j\n"+
"                   ,/ /         i,-\"        (  ,/  /\n"+
"                .-' .f         .'            `\"/  /\n"+
"               / ,,/ffj\\      /          .-\"`.'-.'\n"+
"              / /_\\`--//)     \\ ,--._ .-'_,-'; /\n"+
"             f  \".-\"-._;'      `._ _.,-i; /_; /\n"+
"             `.,'   |; \\          \\`\\_,/-'  \\'\n"+
"              .'    l \\ `.        /\"\\ _ \\`  j\n"+
"              f      : `-'        `._;.\"/`-'\n"+
"              |      `.               ,7  \\\n"+
"              l       j             .'/ - \\`.\n"+
"             .j.  .   <            (.'    .\\ \\f`. |\\,'\n"+
"            ,' `.  \\ / \\           `|      \\,'||-:j\n"+
"          .'  .'\\   Y.  \\___......__\\ ._   /`.||\n"+
"  __.._,-\" .-\"'\"\")  /' ,' _          \\ |  /\"-.`j\"\"``---.._\n"+
"    .'_.-'\"     / .(\"-'-\"\":\\        ._)|_(__. \"'\n"+
"   ;.'         /-'---\"\".--\"'       /,_,^-._ .)\n"+
"   `:=.__.,itz `---._.;'           \"\"      \"\"\n"+
"\n";
set_light(1);

dest_dir = ({
  "room/adv_inner.c","advance",
  "players/maledicta/workroom2.c", "east",
  "players/zeus/workroom.c","zeus",
  "players/dragnar/workroom.c","dragnar",
});

}

init() {
  ::init();
  add_action("move_cyb","cyber");
  add_action("on"); add_verb("on");
  add_action("post"); add_verb("post");
  add_action("off"); add_verb("off");
  add_action("ruins", "ruins");
  add_action("movecastle", "castle");
  add_action("town", "town");

if(this_player()->query_real_name() != NAME && shield == 1) {
  write("Your body impacts suddenly against a solid energy barrier!\n"+
        ""+BYEL+"              ZZZZZZAAAAAAPPPPPPP "+NORM+"\n"+
        "You rebound off of the shield and find yourself somewhere else.\n");
  say(this_player()->query_name()+" has just been sent to the church.\n");
  this_player()->move_player("off the shields#room/church");
  return 1; }
 }

move_cyb() {
  TP->move_player("cyberninja#players/dune/closed/guild/rooms/guildhall.c");
  command("look",this_player());
  return 1; }

static on() {
  write("You "+BOLD+"activate"+NORM+" the shield.\n");
  shield = 1;
  return 1; }

static off() {
if(TP->query_real_name() != NAME) {
  write("You are not allowed to do that!!!!!!!\n");
  return 1; }
  write("You "+BOLD+"deactivate"+NORM+" the shield.\n");
  shield = 0;
  return 1; }

post(){
  TP->move_player("post office#room/post.c");
  return 1; }

ruins(){
  TP->move_player("ruins#players/maledicta/ruins/rooms/r1.c");
  return 1; }

town(){
  TP->move_player("ruins#players/maledicta/town/rooms/t1.c");
  return 1; }
    	
movecastle(){
  TP->move_player("ruins#players/maledicta/castle/rooms/m1.c");
  return 1; }  
  
  