/*   Origanally made by Wizardchild.  Changed by Llew. */
short() { return "A inventory dester"; }
long() { write("Type \"destn <player> <number>\".\n"); return 1; }
get() { return 1; }
drop() { destruct(this_object()); }
id(str) { return str == "dester"; }
init() { add_action("destn", "destn"); }
destn(str) {
  string who;
  int num,x;
  object ob;
  object *obs;
  if(this_player()->query_level() < 21) destruct(this_object());
  if(sscanf(str, "%s %d", who, num) != 2) return 0;
  if(!find_player(who)) {
    write("player not found.\n");
    return 1;
  }
   obs=all_inventory(find_player(who));
   ob=obs[num-1];
  if(!ob) {
    write("Object not present.\n");
    return 1;
  }
  destruct(ob);
  write("dumped.\n");
  tell_object(find_player(who), "Item dested.\n");
  return 1;
}
