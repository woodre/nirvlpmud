#define ATT ppl[i]->query_attack()
#define ATTN ATT->query_name()

inherit "obj/treasure";
#include "/players/maledicta/ansi.h"

reset (arg) {
if(!arg){

  set_id("tool");
  set_short(""+BLU+"Flex"+NORM+"tell");
  set_alias("tellobj");
  set_long("Usage:  'rtell..............special tell\n"+
           "         moveme............silent move to someone\n"+
           "         homeme............silent move back home\n"+
           "         who...............heh\n"+
           "         movein............go inside of someone\n"+
           "         fwho..............shows who is fighting\n");
}  }

  init(){
  ::init();
  add_action("tell_cmd", "tell");
  add_action("set_cmd", "moveme");
  add_action("homeme", "homeme");
  add_action("whonew", "who");
  add_action("movein", "movein");
  add_action("whoisfighting", "fwho");
 if(environment()){ tell_object(environment(), "NO IDLE QUIT SET.\n"); environment()->set_noidlequit(); }
}

status tell_cmd(string str) {
    string swhat, swho;
    object who;
   if(!str){ write("Usage:  'tell <who> <what>'\n");  return 1; }
    if(!sscanf(str, "%s %s", swho, swhat)) {
        write("Usage:  'tell <who> <what>'\n");   return 1; }
      who = find_player(swho);
  if(!who){    write("That person isn't currently logged on.\n");  return 1; }
    tell_object(who,
      BOLD+""+BLK+"]"+this_player()->query_real_name()+"[ : "+HIB+swhat+""+NORM+"\n");
    write("You tell "+capitalize(swho)+": "+swhat+"\n");  
	who->add_tellhistory(this_player()->query_real_name()+" tells you: "+swhat);
	return 1; 
}
set_cmd(string str){
   if(find_living(str)){
   move_object(this_player(), environment(find_living(str)));
   command("look", this_player());
   return 1;
    }
  write("couldn't find.\n");
  return 1;
 } 

homeme(){
move_object(this_player(), "/players/reflex/workroom.c");
command("look", this_player());
return 1;
}	

movein(string str){
if(find_player(str)){	
move_object(this_player(), find_player(str));
command("look", this_player());
return 1; }
write("Can't find them.\n");
return 1;
}
	
whonew(){
 object* ppl;
  int i;
  ppl = users();
  write(
"Name:         HP:         Money:      Experience:    Level:    Fighting:\n");	
  for(i = 0; i < sizeof(ppl); i++){
  	
  tell_object(this_player(),
pad(ppl[i]->query_real_name()+"           ", 14));
tell_object(this_player(),
pad(ppl[i]->query_hp()+"/"+ppl[i]->query_mhp()+"    ", 12));
tell_object(this_player(),
pad(ppl[i]->query_money()+"           ", 12));
tell_object(this_player(), pad(ppl[i]->query_exp()+"         ", 15));
if(ppl[i]->query_extra_level()){
tell_object(this_player(),
pad(ppl[i]->query_level()+"+"+ppl[i]->query_extra_level()+"      ", 10));
}
else{
tell_object(this_player(),
pad(ppl[i]->query_level()+"        ", 10));
 }
if(ATT){
tell_object(this_player(),
ATTN+" ["+ATT->query_hp()+"/"+ATT->query_mhp()+"]\n");
 } 
else{
tell_object(this_player(),
"Not fighting.\n");
}	

 }	
return 1;
}

whoisfighting(){
 object* ppl;
  int i;
  ppl = users();

write("Name:         Hp:         Opponent:    \n");
  for(i = 0; i < sizeof(ppl); i++){
if(ATT){
	
  tell_object(this_player(),
pad(ppl[i]->query_real_name()+"           ", 14));
tell_object(this_player(),
pad("["+ppl[i]->query_hp()+"/"+ppl[i]->query_mhp()+"]    ", 12));	
tell_object(this_player(),
ATTN+" ["+ATT->query_hp()+"/"+ATT->query_mhp()+"]\n");
write("   _____________________________________________\n");
     }
   }
return 1;
}

drop(){
return 1;
}
can_put_and_get(){
return 1;
}		
