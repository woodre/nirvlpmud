#include "/players/vertebraker/define.h"
inherit TREASURE

drop() { return 1; }
reset(x)
{
   if(x) return;
   set_id("guild");
   set_short("Guild setter thing");
   set_alias("thing");
}
init()
{
   ::init();
   add_action("setit","setit");
}
setit(string str)
{
   TP->set_guild_name(str);
   write("Ok, guild name set.\n");
   return 1;
}
