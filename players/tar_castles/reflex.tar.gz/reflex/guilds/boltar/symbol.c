#include "/players/reflex/guilds/harem/harem.h"

query_weight(){ return 0; }
query_value(){ return 0; }
drop(){ return 1; }
get(){ return 1; }

int block;

id(str){ return str == "boltar_priest_symbol" || str == "symbol"; }

query_auto_load(){ return "/players/reflex/guilds/boltar/symbol.c:"; }

extra_look() { write(ETPN+" is wearing a symbol of "+HIY+"Boltar"+NORM+".\n"); }

long(){
   write(
"This is the Symbol of Boltar. It is worn by His worshipers\n"+
"as a symbol to the endlessness of His greatness.\n"+
"As a worshiper you may do the following:\n"+
"  bw  -  This will allow you to state Boltar's greatness on\n"+
"         His worshipers line.\n"+
"  bwe -  This will allow you to emote on Boltar's line.\n"+
"  worshipers -  A who command to see the worshipers currently\n"+
"                logged on.\n"+
"  bblock - to block the channel.\n"+
"  title -  Set your title as a member of Boltar's priesthood.\n"+
"  leave_boltar=(  - To leave the priesthood.\n");
   return 1;
}

init(){
   if(environment() != this_player()) return;
 
   add_action("boltar_tell", "bw");
   add_action("boltar_emote", "bwe");
   add_action("boltar_block", "bblock");
   add_action("boltar_who", "worshipers");
   add_action("get_rid_of", "leave_boltar=(");
   add_action("new_quit", "quit");
   if(this_player()->query_level() < 20 && !this_player()->is_npc())
      boltar_emote("enters the game.");
   }

new_quit(){
 boltar_emote("leaves the game.");
 return;
 }


get_rid_of(){
 write("You leave Boltar forever. To walk the lands alone and in despair.\n");
 destruct(this_object());
 return 1;
 }

boltar_block(){
   if(!block){
      write("You block the Boltar channel.\n");
      block = 1;
   }
   else{
      write("You turn the Boltar channel on.\n");
      block = 0;
   }
   return 1;
}

query_block(){ return block; }


boltar_emote(str) {
   object list;
   object crown;
   int i;
   string myname;
   if(block) {
      write("You are blocking the Boltar Channel.\n");
      return 1;
   }
   if (!str) { write("Use: he <what>\n"); return 1; }
   list = users();
   if(str == "block") {
      for(i=0;i<sizeof(list);i++) {
         crown = present("boltar_priest_symbol",list[i]);
         if(crown && crown->query_block()) {
            write(list[i]->query_name()+" is blocking the Boltar channel.\n");
          }
      }
      return 1;
   }
   myname=TP->query_name();
   for(i=0; i<sizeof(list); i++) {
      crown = present("boltar_priest_symbol",list[i]);
      if (crown && !crown->query_block()) {
         tell_object(list[i], 
            BOLD+"{"+NORM+YEL+"B"+NORM+BOLD+"}"+HIY+myname+" "+str+NORM+"\n");
       }
   }
 return 1;
 }

boltar_who(){
   int i, z;
   object *list;
  
   list = users();
   write(HIY);
   write(pad("",41,'-')+"\n");
   write("|"+NORM+BOLD+"  Name:\tLevel:\tGuild:         "+NORM+HIY+" |\n");
   write(NORM+HIY);
   write("|"+pad("",39,'-')+"|\n");
   write(NORM);
   for(i = 0, z = 0; i < sizeof(list); i++) {
  
      if(!environment(list[i])) continue;
      if(present("boltar_priest_symbol", list[i])){
         write(HIY+"|  "+HIW+pad(list[i]->query_name(),14)+NORM);
         z++;
         
         write(list[i]->query_level() + "\t");
         
         if (!list[i]->query_guild_name())
            write(pad("None",16));
         else
            write(pad(capitalize(list[i]->query_guild_name()),16));
         write(NORM+HIY+"|\n");
       }
   }
   if(!z) write(HIY+"@  "+NORM+pad("No Boltar Worshipers logged on.",37)+NORM+HIY+"|\n");
   write(HIY);
   write("-"+pad("",39,'-')+"-\n");
   write(NORM);
   return 1;
}
 

boltar_tell(str) {
   object list;
   object crown;
   int i;
   string myname;
   string history;
   if(block) {
      write("You are blocking the Boltar Channel.\n");
      return 1;
   }
   if (!str) { write("Use: bw <what>\n"); return 1; }
   list = users();
   if(str == "block") {
      for(i=0;i<sizeof(list);i++) {
         crown = present("boltar_priest_symbol",list[i]);
         if(crown && crown->query_block()) {
            write(list[i]->query_name()+" is blocking the Boltar channel.\n");
          }
      }
      return 1;
   }
   myname=TP->query_name();
   for(i=0; i<sizeof(list); i++) {
      crown = present("boltar_priest_symbol",list[i]);
      if (crown && !crown->query_block()) {
         tell_object(list[i], 
            BOLD+"{"+NORM+YEL+"B"+NORM+BOLD+"}"+HIY+myname+" says in Boltar's name,"+NORM+" \""+str+"\"\n");
       }
   }
   return 1;
   }

