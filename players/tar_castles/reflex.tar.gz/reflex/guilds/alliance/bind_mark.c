inherit "obj/treasure";

reset(arg)
{   if (arg) return;
    set_id("bind_mark");
    set_short();
    set_long("");
    set_weight(0);
    set_value(0);
}

drop()  { return 1; }
get()  { return 0; }

