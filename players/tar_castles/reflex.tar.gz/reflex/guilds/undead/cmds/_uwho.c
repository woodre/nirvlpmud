/* Undead Who Command
// This nice little guild who will give information on 
// various members if the player name is specified.
// Guild commanders get a bit more info on the player.
// Wizards get IP name and number plus the filename of 
// the room that the player is in.
//
// Version 1.1 [06/02/99]
*/

#include "../undead.h"

int cmd(string str)
{
  object *tmp, *ob, life, plyr;
  int i;
  string ret, glvl, level;

  if(str == "")
  {
    tmp = users();
    for(i=sizeof(tmp);i-- > 0;) 
      if(gob(tmp[i]))
        if(!ob) ob = ({ tmp[i] });
        else ob += ({ tmp[i] });
    ret = BOLD+GRN+
"_____________________________________________________________________\n"+
NORM;
    ret += BOLD+
" Name         Level    Glvl     Location\n"+NORM;
    ret += BOLD+GRN+
"_____________________________________________________________________\n"+
NORM;
    for(i=sizeof(ob);i-- > 0;)
    {
      if(QI(ob[i]))
      {
        if(QL(TP) < QL(ob[i]))
          continue;
        if(QL(TP) > QL(ob[i]) || 
          (QL(TP) == QL(ob[i]) && QEL(TP) >= QEL(ob[i])))
        {
          ret += (ob[i]) ? BOLD+"*"+NORM : " "; 
          ret += extract(
            CAP((string)ob[i]->query_real_name())+"           ",0,11)+" ";
        }
        else continue;
      }
      else
      {
        ret += (ob[i]) ? BOLD+"*"+NORM : " "; 
        ret += extract(
          CAP((string)ob[i]->query_real_name())+"            ",0,11)+" ";
      }
      level = (string)QL(ob[i]);
      if(QL(ob[i]) < 20)
        level += (string)QEL(ob[i]) ? "+"+QEL(ob[i]) : "";
      ret += extract(level+"            ",0,7)+" ";
      glvl = (string)QGL(ob[i]);
      ret += extract(glvl+"         ",0,8);
      ret += extract((string)ENV(ob[i])->short()+
        "                                        ",0,39)+"\n";
    }
    ret += BOLD+GRN+
"_____________________________________________________________________\n"+
NORM;
    ret += BOLD+"*"+NORM+" - aware of others\n";
    write(ret);
    return 1;
  }
  if(!(plyr=find_player(str)))
  {
    write(CAP(str)+" doesnt seem to be online.\n");
    return 1;
  }
  if(QI(plyr))
    if(QL(TP) < QL(plyr) || (QL(TP) == QL(plyr) && QEL(TP) < QEL(plyr)))
    {
      write(CAP(str)+" doesnt seem to be online.\n");
      return 1;
    } 
  if(!gob(plyr))
  {
    write("That player is not in the guild.\n");
    return 1;
  }
  ret = BOLD+GRN+
"_____________________________________________________________________\n"+
NORM;
  ret += BOLD+"Name: "+NORM+CAP((string)plyr->query_real_name())+"\n";
  ret += BOLD+"Gender: "+NORM+CAP((string)plyr->query_gender_string())+
	"\n";
  ret += BOLD+"Level: "+NORM+QL(plyr);
  ret += QEL(plyr) != 0 ? "+"+QEL(plyr)+"\n" : "\n";
  ret += BOLD+"Glevel: "+NORM+QGL(plyr)+"\n";

/* if guild commander or wizard, add this to the display */

  if(QGL(TP) >= 10 || QL(TP) > 19)
  {
    ret += BOLD+"GExp: "+NORM+plyr->query_guild_exp()+"\n";
  }

/* ----------^ */

  ret += BOLD+"Location: "+NORM+extract((string)ENV(plyr)->short(),0,69)+"\n";

/* Display this to wizards only */

  if(QL(TP) > 19)
  {
    ret += BOLD+"IP Number: "+NORM+query_ip_number(plyr)+"\n";
    ret += BOLD+"IP Name:   "+NORM+query_ip_name(plyr)+"\n";
    ret += BOLD+"Enviro: "+NORM+extract( file_name(ENV(plyr)),0,68)+"\n";
  }

/* ----------^ */

  ret += BOLD+GRN+
"_____________________________________________________________________\n"+
NORM;
  write(ret);
  return 1;
}
