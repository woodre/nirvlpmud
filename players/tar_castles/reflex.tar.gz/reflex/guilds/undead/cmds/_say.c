#include "../undead.h"

int cmd(string str)
{
  write(BOLD+GRN+"You say: "+NORM+str+"\n");
  tell_room(ENVTP,BOLD+GRN+TPN+
    " says: "+NORM+str+"\n", ({ TP }));
  return 1;
}
