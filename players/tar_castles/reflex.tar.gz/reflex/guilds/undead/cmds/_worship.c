#include "../undead.h"

int cmd(arg)
{  if(arg!="Father") write("Worship who?\n");
   else 
     { say(me()->query_name()+" worships the Unnameable, Father of every Undead. The Father is pleased.\n",me());
       write("You worship the Unnameable, and you can feel He is pleased.\n");
     }
   return 1;
}
