#include "../undead.h"

int cmd(string str)
{
  int i;
  object *ob, life;
    
  if(str == "")
  {
    write("What do you want to send?\n");
    return 1;
  }
  ob = users();
  str = BOLD+GRN+"{"+NORM+BOLD+">"+NORM+TPN+" "+str+BOLD+"<"+GRN+"}\n"+NORM;
  for(i=sizeof(ob);i-- > 0;)
    if(gob(ob[i]))
      tell_object(ob[i],str);
  return 1;
}
