#include "../undead.h"

int cmd(string str)
{
  object ob;
  int lvl;
  string who;
  
  if(QL(TP) < 21)
  {
    write("You cant use this if you are not a wizard.\n");
    return 1;
  }
  if(sscanf(str,"%s %d",who, lvl) != 2)
  {
    write("glevel <player> <level>\n");
    return 1;
  }
  if(!(ob=find_player(who)))
  {
    write("That person doesnt seem to be online.\n");
    return 1;
  }
  gob(ob)->set_guild_level(lvl);
  write("Done.\n");
  return 1;
}
