#include "../undead.h"

int cmd(string str)
{
  object target;

  if(str == "")
  {
    write("You smile cleverly. "+BLINK+BOLD+";"+NORM+">\n");
    tell_room(ENVTP,TPN+" smiles cleverly. "+BLINK+BOLD+";"+NORM+
      ">\n", ({ TP }));
    return 1;
  }
  if(!(target=find_player(str)) || TP == target) return 0;
  if(ENV(target) == ENV(TP))
  {
    write("You smile cleverly at "+
      CAP((string)target->query_name())+
      ". "+BLINK+BOLD+";"+NORM+">\n");
    tell_room(ENVTP, TPN+" smiles cleverly at "+
      CAP((string)target->query_name())+
      ". "+BLINK+BOLD+";"+NORM+">\n",({ TP, target }));
    tell_object(target,TPN+" smiles cleverly at you. "+
      BLINK+BOLD+";"+NORM+">\n");
    return 1;
  }
  else
  {
    write("From afar, You smile cleverly at "+
      CAP((string)target->query_name())+
      ". "+BLINK+BOLD+";"+NORM+">\n");
    tell_object(target,"From afar, "+TPN+
      " smiles cleverly at you. "+BLINK+BOLD+";"+NORM+">\n");
    return 1;
  }
}
