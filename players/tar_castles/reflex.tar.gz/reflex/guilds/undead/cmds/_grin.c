#include "../undead.h"

int cmd(string str)
{
  object target;
  
  if(str == "")
  {
    write("You grin "+BOLD+"darkly"+NORM+", chilling the room.\n");
    tell_room(ENVTP,TPN+
      " grins "+BOLD+"darkly"+NORM+
      ", sending a chill through your spine.\n", ({ TP }));
    return 1;
  }
  if(!(target=find_player(str)) || TP == target) return 0;
  if(ENV(target) == ENV(TP))
  {
    write("You grin "+BOLD+"darkly"+NORM+" at "+
      CAP((string)target->query_name())+", chilling their spine.\n");
    tell_room(ENVTP, TPN+
      " grins "+BOLD+"darkly"+NORM+
      " at "+CAP((string)target->query_name())+
      ", chilling their spine.\n", ({ TP, target }));
    tell_object(target,TPN+" grins "+BOLD+"darkly"+NORM+
      ", chilling your spine.\n");
    return 1;
  }
  else
  {
    write("From afar, You grin "+BOLD+"darkly"+NORM+" at "+
      CAP((string)target->query_name())+", chilling their spine.\n");
    tell_object(target,"From afar, "+TPN+" grins "+BOLD+"darkly"+NORM+
      " at you, chilling your spine.\n");
    return 1;
  }
}
