#include "../undead.h"
#include "/players/reflex/lib/lib.h"
#define VISION_SPELL 30

int cmd(string str) 
{
   object ob, ob_tmp, pla;
   string item;
   string it;
   int max;

   if (!str) {
      write("Who do you want to vision?\n");
      return 1;
   }
   if(call_other(me(),"query_sp") < VISION_SPELL) {
      write("You don't have enough spell points.\n");
      return 1;
   }
   pla=find_player(str);
   if(!pla)  {
      write("No "+str+" on!\n");
      return 1;
   }
   write("**********************************************************\n");
   call_other(me(),"add_spell_point",-VISION_SPELL);
   write(call_other(environment(pla), "short")); write("\n");
   call_other(environment(pla), "long");
   ob = first_inventory(environment(pla));
   max = 20;
   while(ob && max > 0) {
      string short_str;
      short_str = call_other(ob, "short");
      if (short_str) {
         max -= 1;
         write(short_str + ".\n");
         it = short_str;
         }
      ob = next_inventory(ob);
   }
   write("**********************************************************\n");
   return 1;
}
