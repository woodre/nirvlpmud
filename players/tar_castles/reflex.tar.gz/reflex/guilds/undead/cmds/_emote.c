#include "../undead.h"

int cmd(string str)
{
  write(BOLD+TPN+" "+str+NORM+"\n");
  tell_room(ENVTP,BOLD+TPN+
    " "+str+NORM+"\n", ({ TP }));
  return 1;
}
