#include "undead.h"

/* Sets IDS for this object */

id(str) { return str == "life" || str == "life"; }
 
/* description seens when looking at the object */

long() { write("The book of your Life.\n"); }

/* extra_look() sets what is seen when someone */
/* looks at the player when it is worn */

extra_look() { write(ETPN+"'s "+BOLD+GRN+"Life"+NORM+"\n"); }

/* guild objects generally have no weight */

query_weight() { return 0; }

/* setting drop, get and give to 1 to prevent dropping, */
/* giving and getting of this object */

get() { return 1; }
drop() { return 1; }
give() { return 1; }

/* ----------^ */

/* initializes the object and loads player data if found */

init()
{
  if(ENVTO)
  {
    if(file_size(TPSAVE) != -1 && interactive(ENVTO))
      load_data(TPSAVE);
      add_action("command_hook"); add_xverb("");
  }
}

/* saves player data and destructs the object at logout */

end_game()
{
  write("Saving guild information..\n");
  save_data(TPSAVE);
  destruct(TO);
}

/* a simple command hook that can override any command */
/* ( this doesnt seem to be the case for this driver :( ) */
/* used for ALL commands for this object */

command_hook(str)
{
  string cmd, data;
  int ret;

  ENVTO->set_al_title("<UNDEAD>");
  if(!str || str == "") return 0;
  if(sscanf(str,"%s %s",cmd,data) != 2)
  {
    cmd = str;
    data = "";
  }
  if(cmd[0..0] == "'")
  {
    data = cmd[1..-1] + " " + data;
    cmd = "say";
  }
  if(cmd[0..0] == ":")
  {
    data = cmd[1..-1] + " " + data;
    cmd = "emote";
  }
  if(cmd == "quit")
  {
    end_game();
    return 0;
  }
  if(file_size(CMD_DIR+"_"+cmd+".c") == -1)
    return 0;
  catch(ret=call_other(CMD_DIR+"_"+cmd,"cmd",data));
  if(!ret || ret == 1)
    return ret; 
  else
    return 0;
}

/* These saving and loading routines were used to bypass some */
/* annoyances in the save_object() and restore_object() code */

save_data()
{
  string data;

  if(file_size(TPSAVE) != -1)
    rm(TPSAVE);

  write_file(TPSAVE,data);
}

load_data()
{
  string *raw_data, *data, raw_file;
  int i;

  if(file_size(TPSAVE) != -1)
  {
    raw_file = read_file(TPSAVE);
    raw_data = explode(raw_file,"\n");
    for(i=sizeof(raw_data)-1;i-- > 0;)
    {
      data = explode(raw_data[i],":");
      data[1] = to_int(data[1]);
      call_other(TO, "set_"+data[0], data[1]);
    }
  }
}

/* ----------^ */
