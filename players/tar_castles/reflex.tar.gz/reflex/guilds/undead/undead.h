#include "/players/reflex/lib/include/ansi.h"

#define TO this_object()
#define TP this_player()
#define PO previous_object()
#define TPN this_player()->query_name()
#define TPRN this_player()->query_real_name()
#define ETPN environment(this_object())->query_name()
#define CAP(x) capitalize(x)
#define ENV(x) environment(x)
#define ENVTP environment(this_player())
#define ENVTO environment(this_object())
#define FN(x) file_name(x)
#define FNTO file_name(this_object())
#define CMD_DIR "/players/reflex/guilds/undead/cmds/"
#define ROOM_DIR "/players/reflex/undead/guild/"
#define CMD_D "/players/reflex/guilds/undead/daemons/command_d"
#define TPSAVE "players/reflex/guilds/undead/save/"+TPRN
#define LOGO "/players/reflex/guilds/undead/logo"
#define QI(x) x->query_invis()
#define QL(x) x->query_level()
#define QEL(x) x->query_extra_level()
#define QGL(x) gob(x)->query_guild_level()
#define QGE(x) x->query_guild_exp()
#define GOBFILE "/players/reflex/guilds/undead/life"

object gob(object ob)
{
  return present("life",ob);
}

int clean_up()
{
  destruct(TO);
  destruct(FNTO);
  return 1;
}

void remove() { destruct(TO); }
