#include "../shadow.h"

int do_command(string str)
{
  string cmd, data;
  int ret;

  if(!str || str == "") return 0;
  if(sscanf(str,"%s %s",cmd,data) != 2)
  {
    cmd = str;
    data = "";
  }
  if(cmd[0..0] == "'")
  {
    data = cmd[1..-1] + " " + data;
    cmd = "say";
  }
  if(cmd[0..0] == ":")
  {
    data = cmd[1..-1] + " " + data;
    cmd = "emote";
  }
  if(cmd[0..0] == "#")
  {
    data = cmd[1..-1] + " " + data;
    cmd = "ready";
  }
/* Need to add Quit command for saving player data and such */
/* Right now this does nothing */
  if(cmd == "quit")
  {
    write("Saving..\n");
    return 0;
  }
  if(file_size(CMD_DIR+"_"+cmd+".c") == -1)
    return 0;
  catch(ret=(int)call_other(CMD_DIR+"_"+cmd,"cmd",data));
  if(!ret || ret == 1)
    return ret; 
  else
  {
    write("/log/reflex\n");
    return 0;
  }
}
