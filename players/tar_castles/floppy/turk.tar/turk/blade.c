inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Turk's Blade");
set_alias("blade");
set_short("The blade");
set_long(
"Turks blade.. Which he uses to destroy all of his enemies.  It shines with\n"
 + "a lust to kill.\n");
set_value(10000);
set_weight(1);
set_class(100);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100) < 75) {
write(attacker->query_name() + " is consumed by the blade.\n");
return 50;
   }
 }
