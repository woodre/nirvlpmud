#include "room.h"

object Rat;

#undef EXTRA_RESET
#define EXTRA_RESET\
    extra_reset();

extra_reset() {
 if (!Rat || !living(Rat)) {
   Rat = clone_object("obj/monster");
   call_other(Rat, "set_name", "rat");
   call_other(Rat, "set_hp", 75);
  call_other(Rat, "set_ac", 2);
   call_other(Rat, "set_wc", 3);
   call_other(Rat, "set_al", -200);
   call_other(Rat, "set_short", "A thieving rat");
    call_other(Rat, "set_long",
  "A medium sized rat that eats all of Turk's food.\n");
   call_other(Rat, "set_agressive", 0);
move_object(Rat, this_object());
   call_other(Rat, "set_level", 4);
  }
}


ONE_EXIT("players/turk/cabin", "north",
"turks cabin",
"This is Turks cabin back in the mountains near his home in Montana.\n" +
"He doesn't mind other people using it, but when he gets here with guests\n" +
"he likes to have privacy\n", 1)
