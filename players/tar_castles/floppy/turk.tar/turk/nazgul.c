#include "room.h"

object Nazgul;

#undef EXTRA_RESET
#define EXTRA_RESET\
    extra_reset();

extra_reset() {
  object weapon;	
object fear;
if (!Nazgul|| !living(Nazgul)) {
  Nazgul = clone_object("obj/monster");
   call_other(Nazgul, "set_name", "nazgul");
   call_other(Nazgul, "set_a_chat_chance", 35);
call_other(Nazgul, "load_a_chat", "Nazgul says: Never come between a nazgul and its prey!! \n");

call_other(Nazgul, "set_hp", 1100);
call_other(Nazgul, "set_ac", 25);
call_other(Nazgul, "set_wc", 11);
call_other(Nazgul, "set_al", -5000);
call_other(Nazgul, "set_short", "A black cloaked Nazgul");
call_other(Nazgul, "set_long",
"You begin to tremble as you find yourself in front \n" +
"of one of the nine ring wraiths\n");
call_other(Nazgul, "set_agressive", 1);
call_other(Nazgul, "set_level", 22);
move_object(Nazgul, this_object());
    weapon=clone_object("obj/weapon");
call_other(weapon, "set_name", "fear");
call_other(weapon, "set_long", "Fear---> A good weapon for anything\n");
call_other(weapon, "set_class", 18);
    call_other(weapon, "set_hit_func", this_object());
    call_other(weapon, "set_value", 10000);
    call_other(weapon, "set_weight", 2);
call_other(weapon, "set_alt_name", "fear");
move_object(weapon, Nazgul);
call_other(Nazgul, "init_command", "wield fear");
  }
}

weapon_hit(attacker) {
  if (random(100) < 75) {
write("Fear strikes at the heart of " +attacker->query_name() + "\n");
say(attacker->query_name() + " is struck down in pure terror.\n");
   return 6;
  }
     return 0;
   }

TWO_EXIT("players/turk/road1", "south",
    "players/turk/moria", "north",

"Nazgul",
"A huge nazgul sits here upon his foul beast of war, looking for\n" +
"something to strike down\n", 1)
