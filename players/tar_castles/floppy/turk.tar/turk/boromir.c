
#include "std.h"
object Boromir;

#undef EXTRA_RESET
#define EXTRA_RESET\
extra_reset();

extra_reset() {
   object horn;
   object broadsword;
   if (!Boromir || !living(Boromir)) {
      Boromir = clone_object("obj/monster");
      call_other(Boromir, "set_name", "boromir");
      
      call_other(Boromir, "set_a_chat_chance", 10);
      call_other(Boromir, "load_a_chat", "Boromir blows his horn\n");
      call_other(Boromir, "set_hp", 800);
      call_other(Boromir, "set_ac", 15);
      call_other(Boromir, "set_wc", 12);
      call_other(Boromir, "set_al", 200);
      call_other(Boromir, "set_short", "Boromir, a man of Minis Tirith");
      call_other(Boromir, "set_long",
         "Boromir was on a trip to solve a riddle when he fell into Frodo's\n"+
         "group.  He wants the ring...but wont get it\n");
      call_other(Boromir, "set_agressive", 0);
      call_other(Boromir, "set_level", 14);
      move_object(Boromir, this_object());
horn = clone_object("obj/treasure");
call_other(horn, "set_id", "horn");
call_other(horn, "set_short", "A cloven horn");
call_other(horn, "set_long", "Boromirs family heirloom, his horn.\n");
call_other(horn, "set_alt_name", "cloven horn");
      call_other(horn, "set_value", 400);
      call_other(horn, "set_weight", 1);
      move_object(horn, Boromir);
      broadsword=clone_object("obj/weapon");
      call_other(broadsword, "set_name", "broadsword");
      call_other(broadsword, "set_long", "This is Boromir's huge Broadsword\n");
      call_other(broadsword, "set_class", 10);
      call_other(broadsword, "set_hit_func", this_object());
      call_other(broadsword, "set_value", 1100);
      call_other(broadsword, "set_weight", 2);
      call_other(broadsword, "set_alt_name", "sword");
      move_object(broadsword, Boromir);
      call_other(Boromir, "init_command", "wield broadsword");
   }
}

weapon_hit(attacker) {
   if (random(100) < 75) {
      write("Power from Boromir's sword flows into "+ attacker->query_name() + "\n");
      say(attacker->query_name() + " is hit by Boromir's sword\n");
      return 6;
   }
}

TWO_EXIT("players/turk/gimili", "south",
   
"players/turk/pippin", "west",
   "Boromir's area",
   "You find yourself along the edge of a river where Frodo and company\n" +
   "pulled up to stop for a while\n", 1)
