#include "room.h"

object Bolrog;

#undef EXTRA_RESET
#define EXTRA_RESET\
    extra_reset();

extra_reset() {
object money, weapon;
object whip;
 if (!Bolrog || !living(Bolrog)) {
  money = clone_object("obj/money");
     Bolrog = clone_object("obj/monster");
  call_other(Bolrog, "set_name", "bolrog");
  call_other(Bolrog, "set_hp", 850);
  call_other(money, "set_money", random (500));
call_other(Bolrog, "set_ac", 7);

    call_other(Bolrog, "set_wc", 12);
       call_other(Bolrog, "set_al", -600);
  call_other(Bolrog, "set_short", "A Huge Bolrog");
       call_other(Bolrog, "set_long",
"The Bolrog is a huge monster dredged from the foul land of Mordor.\n");
   call_other(Bolrog, "set_aggressive", 1);
 call_other(Bolrog, "set_level", 13);
        move_object(Bolrog, this_object());
       move_object(money, Bolrog);
weapon=clone_object("obj/weapon");
call_other(weapon, "set_name", "whip");
call_other(weapon, "set_long", "A huge whip, powerful in masterly hands\n");
call_other(weapon, "set_class", 12);
call_other(weapon, "set_value", 2000);
call_other(weapon, "set_weight", 1);
call_other(weapon, "set_alt_name", "whip");
move_object(weapon, Bolrog);
call_other(Bolrog, "init_command", "wield whip");
    }
}

THREE_EXIT("players/turk/moria", "south",
  "players/turk/orcs", "east",
   "players/turk/goblin", "north",
    "Bolrog",
"You see standing in the middle of the road a huge Bolrog to\n" +
"Keep aid from reaching the city of Gondor.\n", 1)
