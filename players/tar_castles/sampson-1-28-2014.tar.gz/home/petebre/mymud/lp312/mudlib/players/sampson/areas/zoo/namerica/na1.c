inherit "/players/vertebraker/closed/std/room.c";
#include <ansi.h>
#include "/players/sampson/Defs.h"

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);

  set_short("North America");
  set_long("\
  Welcome to the North American exhibit. Animals from Canada to\n\
Mexico have been assembled here for viewing pleasure. Be careful\n\
though, some of these animals have sharp teeth and claws. Read the\n\
rules of the zoo before proceeding into this exciting new look at\n\
North American wildlife.\n");

  add_exit(ZOO+"zmain","zoo");
  add_exit(NAM+"na10","east");
  add_exit(NAM+"na2","northwest");

  add_item("animals","\
  You see numerous animals roaming beyond the entrance. Funny, they don't appear to be in pens");
  add_item("rules","\
  A list of zoo rules. You should probably read them");
}
init()  {
 ::init();
  add_action("read_rules","read");
}

read_rules(str){
  if(!str){
    notify_fail("What would you like to read?\n");
    return 0;
  }
  if(str != "rules") {
    notify_fail("You may only read the rules.\n");
    return 0;
  }
  write("            The rules of the zoo:\n\n"+
  "1. Our animals are not in pens or cages. They are dangerous\n"+
  "   so do not mess with them.\n\n"+
  "2. Our Zookeeper likes to collect furs, teeth, etc.. If you happen\n"+
  "   to find any on your journey, he will probably barter for them from\n"+
  "   you. He is located in the office at the main entrance.\n\n"+
  "3. For those with animal allergies.  Be careful, smelling too much can be\n"+
  "   bad for your health.\n\n"+
  "4. The zoo is for fun, search around, look around, and enjoy your visit.\n");
  return 1;
}

