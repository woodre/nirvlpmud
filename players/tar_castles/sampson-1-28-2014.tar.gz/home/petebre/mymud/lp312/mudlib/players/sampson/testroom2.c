/* This is a test room to verify I have the correct formatting*/

#include <ansi.h>
inherit "room/room";

reset(arg){


if(!arg){


  set_light(1);


  short_desc=""+BLINK+"Test "+NORM+"Room";


long_desc=
 "This is the "+RED+"test"+NORM+" room of "+HIM+"Sampson "+NORM+"the "+HIG+"Newbie "+HIW+"Wiz."+NORM+"  It has been designed\n" +
 "so that his sponsor, "+HIY+BLINK+"X"+NORM+", can verify that he is properly coding his rooms.\n" +
 "If you have any problems with the room, there is a "+HIR+"book"+NORM+" on the shelf you\n" +
 "may "+HIR+"read"+NORM+".  Let me know if everything is correct.\n";


items=({
  "room", "A test room",
  "book", "A "+HIR+"book"+NORM+" on the shelf that you can "+HIR+"read"+NORM+"",
  "shelf", "A long "+YEL+"wooden shelf"+NORM+" with only one "+HIR+"book"+NORM+" on it",
});


dest_dir=({
 "/players/sampson/workroom.c","sampson",
 "/room/church.c","church",
           });
        }
        }

init()  {
 ::init();
  add_action("read_book","read");
}

read_book(str){
  if(!str){
    notify_fail("What would you like to read?\n");
    return 0;
  }
  if(str != "book") {
    notify_fail("You may only read the book.\n");
    return 0;
  }
  write("The first page of the book states:\n"+
        ""+BLINK+HIY+"WHO CARES WHAT YOU THINK!!!"+NORM+"\n");
  return 1;
}


