#include "/players/sampson/Defs.h"
#include <ansi.h>

inherit "/obj/monster.c";

reset(arg) {
  ::reset(arg);
  if(arg) return;
  /* move_object(clone_object("/players/feldegast/wep/j_rapier.c")); */
  /* move_object(clone_object("/players/feldegast/equip/shield.c")); */
  /* init_command("wear shield"); */
  /* init_command("wield rapier"); */
  set_name("Buffalo");
  set_alt_name("buffalo");
  set_alias("buffalo");
  set_short("A Buffalo");
  set_long(
  "A large buffalo. It's brown fur is matted together, and\n"+
"it has very thick mane like fur on its head.  Two horns\n"+
"stick out from the side of his head.\n"+
  "The buffalo is the largest land mammal in North America\n"+
"Males can stand six feet from hoof to shoulder and weigh\n"+
"between 1000-2000 pounds.\n");

  set_gender("male");
  set_race("bison");
  set_level(22);
  set_wc(34);
  set_ac(19);
  set_hp(700);
  set_al(0);
  /* add_money(4000); */  
  set_chance(5);
  set_spell_mess1(
"\n\tThe buffalo impales his opponent with his horns.\n"+
"\t\t"+RED+"blood"+NORM+" spews of of a gash.\n\n"
  ); /* 3RD PERSON */
  set_spell_mess2(
"\n\tThe buffalo impales you with his horns.\n"+
"\t\tYour "+RED+"blood"+NORM+" gushes out of a huge gash.\n\n"
  ); /* 1ST PERSON */
  set_spell_dam(40);
}
