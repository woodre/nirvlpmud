/* Definations */


#define ZOO		"/players/sampson/areas/zoo/"
#define ZOBJ	"/players/sampson/areas/zoo/obj/"
#define ARM		"/players/sampson/armors/"
#define WEP		"/players/sampson/weps/"
#define MOB		"/players/sampson/mobs/"
#define AFRICA	"/players/sampson/areas/zoo/africa/"
#define AUST	"/players/sampson/areas/zoo/australia/"
#define NAM		"/players/sampson/areas/zoo/namerica/"
#define SAM		"/players/sampson/areas/zoo/samerica/"
#define REPTILE	"/players/sampson/areas/zoo/reptile/"
#define AQUA	"/players/sampson/areas/zoo/aquarium/"


