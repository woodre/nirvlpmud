#include <ansi.h>
inherit "/players/vertebraker/closed/std/room.c";
#include "/players/sampson/Defs.h"

void reset(int arg)
{

object sign;
    
  ::reset(arg);


  
    if(arg) return;
  set_light(1);



set_short("Zoo Entrance");
set_long("\
	This is the entrance to Sampson's Zoological Park. Animals from all\n\
over the world have been collected to give visitors a glimpse of\n\
their lifestyles. Some are dangerous, while others are peaceful. A\n\
sign points the way to the various exhibits. Take a look around and\n\
enjoy your visit.\n");

add_exit(NAM+"na1","east");
add_exit("/players/sampson/workroom","sampson");

add_item("animals","\
A collection of the world's animals are within the walls");
add_item("walls","\
Walls that line the outside of the zoo");
add_item("entrance","\
A large stone gateway with 'Sampson's Zoological Park written across the top");
add_item("visitors","\
People walking and talking, excited about entering the zoo");

add_exit_msg("east",({
  "You enter the North American exhibit.\n",
  "enters the North American exhibit.\n" }));

add_smell("main","Animal fur stinks"); 
  
if(!present("sign")) {
    sign=clone_object("/players/sampson/areas/zoo/obj/sign.c");
    move_object(sign,this_object());
  }
    }

void init(){
  ::init(); /* allow inherited actions */
  add_action("do_smell", "smell");
}

int do_smell(string str){
  if((int)this_player()->query_attrib("luc") < random(31)){
    command("sneeze", this_player());
    /* knock off a few hps */
    this_player()->hit_player(10, "other|sampson");
  }
  /* by not returning any value, we still allow them to smell */
}