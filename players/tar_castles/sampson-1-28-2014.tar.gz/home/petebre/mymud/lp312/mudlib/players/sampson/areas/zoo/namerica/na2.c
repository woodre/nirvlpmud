#include <ansi.h>
inherit "/players/vertebraker/closed/std/room.c";
#include "/players/sampson/Defs.h"

void reset(int arg)
{

  ::reset(arg);
  if(arg) return;
  set_light(1);

  set_short("American Plains");
  set_long("\
  Flat land as far as the eye can see. The sun shines upon the tall\n\
yellow grass casting a golden glow upon the horizon. A gentle breeze\n\
blows across the land making the grasses sway like a dance. Buffalo\n\
roam freely here and appear to not even notice any visitors.\n");

  add_exit(NAM+"na3","north");
  add_exit(NAM+"na1","southeast");

  add_item("land","\
  The ground is flat and almost perfectly smooth.  There isn't a hill in sight");
  add_item("sun","\
  You almost hurt your eyes looking into the bright yellow sun");
  add_item("grass","\
  Tall blades of grass gently swaying in the breeze");
  add_item("grasses","\
  Tall blades of grass gently swaying in the breeze");
  add_item("visitors","\
  People walking and talking, excited about seeing the buffalo");
  add_item("buffalo","\
  Large buffalo roaming through the grass grazing");

  add_smell("main","The smell of the plains is fresh and refreshing.");   
}

void init(){
  ::init(); /* allow inherited actions */
  add_action("do_smell", "smell");
}

int do_smell(string str){
  if((int)this_player()->query_attrib("luc") < random(31)){
  command("sneeze", this_player());
    /* knock off a few hps */
  this_player()->hit_player(5, "other|sampson");
  }
  /* by not returning any value, we still allow them to smell */
}