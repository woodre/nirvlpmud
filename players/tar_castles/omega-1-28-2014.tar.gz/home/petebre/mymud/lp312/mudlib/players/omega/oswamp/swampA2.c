#include "path"
#include "std.h"
#include "living.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

object alligator,hide,teeth;

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

TWO_EXIT(PATH+"swampB2", "south",
   PATH+"swampA1", "west",
   "Swamp",
   "You are in a swamp.\n" +
   "This appears to be the lair of an alligator.\n",
   0)

extra_reset() {
   if (!alligator || !living(alligator)) {

         alligator = clone_object("obj/monster");
         call_other(alligator, "set_name", "a vicious alligator");
         call_other(alligator, "set_al", -50);
         call_other(alligator, "set_alias", "alligator");
         call_other(alligator, "set_race", "animal");
         call_other(alligator, "set_long",
            "A large alligator with LOTS of teeth.\n");
         call_other(alligator, "set_aggressive", 1);
         call_other(alligator, "set_wc", random(10) + 7);
         call_other(alligator, "set_ac", 3);
         call_other(alligator, "set_level", random(2) + 10);
         move_object(alligator, this_object());

         hide = clone_object("obj/armor");
         call_other(hide, "set_name", "alligator hide");
         call_other(hide, "set_short", "An alligator hide");
         call_other(hide, "set_alias", "hide");
         call_other(hide, "set_long",
         "A tough skin that could be worn as a protective cloak.\n");
         call_other(hide,"set_value",650);
         call_other(hide,"set_weight",3);
         call_other(hide,"set_ac",2);
         call_other(hide,"set_type","misc");
         move_object(hide, alligator);

         teeth = clone_object("obj/weapon");
         call_other(teeth,"set_name","alligator teeth");
         call_other(teeth,"set_class",7);
	 call_other(teeth,"set_weight",1);
         call_other(teeth,"set_value",300);
         call_other(teeth,"set_alias","teeth");
         call_other(teeth,"set_long",
         "A nasty pair of teeth that could be used as a weapon.\n"
         );
         move_object(teeth, alligator);
   }
}
