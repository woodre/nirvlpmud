int counter;
object player;

id(str) {
   if(counter > 0) return str == "wywy";
   return str == "sapphire" || str == "blue sapphire" || str == "gem of knowledge";
}
short() {
   if(counter > 0) return 0;
   return "a blue sapphire";
}
long() {
   write("It is a dazzling sapphire.  It looks flawless.\n");
}
init() {
   add_action("crush_gem","crush");
   add_action("crush_gem","squeeze");
}
crush_gem(str) {
   if(!id(str)) return 0;
   if(counter > 0) return 0;
   if(environment() != this_player()) {
      write("You must get it first.\n");
      return 1;
   }
   player = this_player();
   tell_room(environment(player),"You see a blinding flash of blue light!\n");
   write("Something forced you to smash your head with the sapphire.\n");
   say(this_player()->query_name()+
      " smashes his head with a sapphire.\n");
   write("It breaks into a million pieces!\n");
   write("OUCH!  That smarts!\n");
   player->add_hit_point((-1)*(random(10)+10));
   transfer(this_object(),environment(player));
   counter += 1;
   transfer(this_object(),player);
   set_heart_beat(1);
   return 1;
}
heart_beat() {
   if(counter > 48) {
   int exp_change;
      say(player->query_name()+" looks smarter than before.\n");
      exp_change = (player->query_exp() / 5);
      if (exp_change > 10000) exp_change = 10000;
      if (exp_change < 200) exp_change = 200;
      player->add_exp(exp_change);
      set_heart_beat(0);
      tell_object(player,"You have gained some experience!\n");
      destruct(this_object());
      return 1;
   }
   if(counter == 5) tell_object(player,"Your head starts to ache.\n");
   else if (counter == 15) tell_object(player,"You have a major head ache.  OOHHHH.\n");
   else if (counter == 30) tell_object(player,"Your head starts pounding.\n");
   else if (counter == 40) tell_object(player,"Your brain starts to vibrate!\n");
   else if (counter == 44)
      tell_object(player,"The knowledge of the universe has just entered your brain!\n");
   else if (counter == 48)
      tell_object(player,"Unfortunately, your brain is too small to contain it all.\n");
   counter += 1;
}
get() {
   if(counter > 0) return 0;
   return 1;
}
drop() {
   if(counter > 0) return 1;
   return 0;
}
query_value() { return 5000; }
query_weight() {
   if(counter > 0) return 0;
   return 1;
}
reset(arg) {
   if(arg) return;
   counter = 0;
}
