inherit "players/omega/magic/oheal.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("potion of cure light wounds");
  set_alias("potion");
  set_short("Potion of cure light wounds");
  set_long("It will heal 10 hit points if you 'drink' it.\n");
  set_weight(0);
  set_value(300);
  set_verb("drink");
  set_amount(10);
  set_self("You feel the healing effects of the potion.  Ah...");
  set_others("drinks a potion and looks healthier.");
}
