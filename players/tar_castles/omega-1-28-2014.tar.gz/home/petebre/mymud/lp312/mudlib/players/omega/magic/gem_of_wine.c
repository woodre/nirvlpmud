id(str) { return str == "ruby" || str == "red ruby" || str == "gem of wine"; }
short() { return "a red ruby"; }
long() {
   write("You see a small red ruby.  It seems to glow faintly.\n");
}
init() {
   add_action("crush_gem","crush");
   add_action("crush_gem","squeeze");
}
crush_gem(str) {
   if(!id(str)) return;
   if(environment() != this_player()) {
      write("You must get it first.\n");
      return 1;
   }
   write("Your body emits a brilliant flash of red light!\n");
   say(this_player()->query_name()+
      " suddenly emits a brilliant flash of red light!\n");
   this_player()->drink_alcohol(100);
   write("You feel like you just drank a keg of beer.\n");
   write("The ruby vanishes.\n");
   destruct(this_object());
   return 1;
}
get() { return 1; }
query_value() { return 100; }
query_weight() { return 1; }
