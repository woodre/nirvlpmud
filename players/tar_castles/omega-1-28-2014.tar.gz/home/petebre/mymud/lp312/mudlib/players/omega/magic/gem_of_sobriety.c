id(str) { return str == "stone" || str == "brown stone" || str == "gem of sobriety"; }
short() { return "a brown stone"; }
long() {
   write("You see a small brown stone.  It seems to glow faintly.\n");
}
init() {
   add_action("use_gem","squeeze");
   add_action("use_gem","crush");
   add_action("use_gem","grind");
}
use_gem(str) {
   if(!id(str)) return;
   if(environment() != this_player()) {
      write("You must get it first.\n");
      return 1;
   }
   write("You suddenly emit a strange flash of brown light!\n");
   say(this_player()->query_name()+
      " suddenly emits a strange flash of brown light!\n");
   this_player()->drink_alcohol(-10000);
   write("The stone vanishes.\n");
   destruct(this_object());
   return 1;
}
get() { return 1; }
query_value() { return 100; }
query_weight() { return 1; }
