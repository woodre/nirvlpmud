#include "std.h"

THREE_EXIT("players/omega/oforest/forestA2", "north",
   "players/omega/oforest/forestB3", "east",
   "players/omega/oforest/forestC2", "south",
   "Forest",
   "You are in a forest.\n",1)
