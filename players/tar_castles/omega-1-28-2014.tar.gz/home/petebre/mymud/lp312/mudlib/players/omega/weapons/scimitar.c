inherit "obj/weapon.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a scimitar");
  set_class(9);
  set_weight(3);
  set_value(200);
  set_alt_name("scimitar");
}
