inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("magic misc");
  set_short("Magic misc of Omega");
  set_long("~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~\n"+
           "This armor is magically enhanced\n"+
           "and allows you to see in the dark!\n"+
           "It can only be obtained if Omega\n"+
           "grants one to you.  Wear it well.\n"+
           "MAY YOU NEVER FALL IN BATTLE!!!!!\n"+
           "");
  set_type("misc");
  set_light(1);
  set_ac(2);
  set_weight(1);
  set_value(2500);
  set_alias("misc");
}
