inherit "obj/armor";

reset(arg) {
   if(!arg) {
   set_name("player diaper");
   set_alias("diaper");
   set_short("a training diaper");
   set_value(0);
   set_weight(0);
   set_type("diaper");
   }
}

init() {
   ::init();
   add_action("cry_baby","kill");
   add_action("cry_baby","missile");
   add_action("cry_baby","shock");
   add_action("cry_baby","fireball");
   add_action("cry_baby","quit");
   add_action("cry_baby","kick");
   add_action("cry_baby","yawn");
   add_action("cry_baby","cry");
}

cry_baby(str) {
object player;
   if(!str) return 0;
   if(!environment(this_player())) return 0;
   if(!find_player(str)) return 0;
   player = present(find_player(str), environment(this_player()));
   if(!player) return 0;
   write("Nice try kiddo.  But no cigar.\n");
   say(this_player()->query_name()+" throws a violent tantrum!   WAAHH!!!\n");
   return 1;
}

get() {
   if(this_player()->query_name() == "Omega") { return 1; }
   return 0;
}

drop() {
   if(this_player()->query_name() == "Omega") { return 0; }
   wear("diaper");
   return 1;
}

id(str) {
   return ((::id(str)) || str == "ND");
}

query_auto_load() {
   return "players/omega/obj/pdiaper:";
}

init_arg() { return; }

extra_look() {
   write(environment()->query_name()+
      " didn't believe in the power of Omega so she is stuck with this diaper.\n");
}
