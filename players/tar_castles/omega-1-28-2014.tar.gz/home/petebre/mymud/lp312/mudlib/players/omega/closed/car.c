status closed;

id(str) { return str == "porsche" || str == "car"; }

short() {
   return "A Porsche 911";
}
long() {
   if (environment(this_player()) == this_object()) {
      write("You are in the driver's seat of a Porsche 911.\n");
   } else {
      write("You see a brand new, red, Porsche 911 sports car.\n");
      write("It has two doors and tinted windows.\n");
   }
   if(!closed) {
      write("The door is open.\n");
   } else {
      write("The doors are closed.\n");
   }
}
init() {
    add_action("enter"); add_verb("enter");
    add_action("open_door","open");
    add_action("close_door","close");
    if(environment(this_player()) == this_object()) {
       add_action("leave","leave"); add_action("leave","exit");
       add_action("leave","out");
       add_action("look_outside", "look");
       add_action("look_outside", "l");
/*
        add_action("car_commands"); add_xverb("");
*/
    }
}
enter(str) {
string who_name;
   if(!id(str)) return 0;
   if(environment(this_player()) == this_object()) {
      write("You're already in it!\n");
      return 1;
   }
   if(closed) {
      write("The car's door is closed.\n");
      return 1;
   }
   who_name = this_player()->query_name();
   say(who_name+" enters the car.\n");
   move_object(this_player(),this_object());
   say(who_name+" arrives.\n");
   call_other(this_player(),"glance");
   return 1;
}
open_door(str) {
string who_name;
   if(!str) return 0;
   if(str == "door" || str == "car door") {
      who_name = this_player()->query_name();
      if(closed) {
         write("You open the car's door.\n");
         say(who_name+" opens the car's door.\n");
         closed = 0;
         return 1;
      }
      write("The door is already open!\n");
      return 1;
   }
   return 0;
}
close_door(str) {
string who_name;
   if(!str) return;
   if(str == "door" || str == "car door") {
      who_name = this_player()->query_name();
      if(!closed) {
         write("You close the car's door.\n");
         say(who_name+" closes the car's door.\n");
         closed = 1;
         return 1;
      }
      write("The door is already closed.\n");
      return 1;
   }
   return 0;
}
leave() {
object outside;
string who_name;
   outside = environment(this_object());
   if(!outside) {
      write("Huh?  This shouldn't happen!\n");
      return 1;
   }
   who_name = this_player()->query_name();
   say(who_name+" steps outside.\n");
   move_object(this_player(),outside);
   say(who_name+" steps out from the car.\n");
   call_other(this_player(),"glance");
   return 1;
}
look_outside(str) {
   if(str = "out" || str == "outside") {
      move_object(this_player(), environment(this_object()));
      call_other(this_player(), "glance");
      move_object(this_player(), this_object());
      return 1;
   }
   return 0;
}
get() {
   write("Dream on bub!\n");
   return 0;
}
reset(arg) {
   if(arg) return;
   closed = 0;
}
