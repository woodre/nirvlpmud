#include "std.h"

TWO_EXIT("players/omega/oforest/forestB4", "east",
   "players/omega/oforest/forestB2", "west",
   "Forest\n",
   "You are in a forest.\n",
   1)
