#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

extra_reset() {
}

ONE_EXIT("players/omega/oswamp/swampB0", "east",
   "Grotto",
   "You are in an enclosed grotto.\n"+
   "To the east you see a dismal swamp.\n",
/*  "Thoughts of peace and good spirit invade your mind.\n" +
   "The power of the FORCE emanates in this area ...\n", */
   0)
