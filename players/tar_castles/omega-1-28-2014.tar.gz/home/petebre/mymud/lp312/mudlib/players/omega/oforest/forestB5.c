#include "std.h"

THREE_EXIT("players/omega/oforest/forestA5", "north",
   "players/omega/oforest/forestB4", "west",
   "players/omega/oforest/forestC5", "south",
   "Forest",
   "You are in a forest.\n",1)
