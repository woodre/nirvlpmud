#include "std.h"

THREE_EXIT("players/omega/oforest/forestB2", "north",
   "players/omega/oforest/forestC1", "west",
   "players/omega/oforest/forestD2", "south",
   "Forest",
   "You are in a forest.\n" +
   "To the west is a fast flowing river.\n" +
   "There is a bridge which crosses it.\n",
   1)
