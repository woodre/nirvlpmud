id(str) { return str == "emerald" || str == "green emerald" || str == "gem of health"; }
short() { return "a green emerald"; }
long() {
   write("You see a beautiful emerald!  It must be worth a lot!\n");
}
init() {
   add_action("crush_gem","crush");
   add_action("crush_gem","squeeze");
}
crush_gem(str) {
   if(!id(str)) return;
   if(environment() != this_player()) {
      write("You must get it first.\n");
      return 1;
   }
   write("You suddenly emit a brilliant flash of green light!\n");
   say(this_player()->query_name()+
      " suddenly emits a brilliant flash of green light!\n");
   this_player()->heal_self(2000);
   write("The emerald disappears!\n");
   write("You have been healed.\n");
   destruct(this_object());
   return 1;
}
get() { return 1; }
query_value() { return 2500; }
query_weight() { return 1; }
