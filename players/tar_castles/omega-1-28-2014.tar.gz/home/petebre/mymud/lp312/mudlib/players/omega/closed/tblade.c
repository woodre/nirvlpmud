inherit "obj/weapon.c";

object target;
int index, num_targets;
string arr;

reset(arg){
  if(arg) return;
  ::reset(arg);
  arr = allocate(10);
  set_name("blade");
  set_short("Blade of Death");
  set_class(1);
  set_weight(0);
  set_hit_func(this_object());
}
weapon_hit(){
  index=0;
  write("Start\n");
  target=first_inventory(environment(this_player()));
  while(target){
    if(target->query_attack()==this_player()){
      arr[index]=target;
      index += 1;
      write("Targeted: "+index+"\n");
    }
    target=next_inventory(target);
  }
  hit_targets();
  return 20;
}
hit_targets(){
  write("Number of targets: "+index+"\n");
  while(index > 1){
    write("Hit "+index+"\n");
    index -= 1;
    arr[index]->hit_player(10);
    move_object(this_player(),environment(this_player()));
  }
}
