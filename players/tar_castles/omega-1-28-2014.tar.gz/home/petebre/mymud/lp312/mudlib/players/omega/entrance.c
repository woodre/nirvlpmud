#include "std.h"

#undef EXTRA_INIT
#define EXTRA_INIT extra_init();
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object sign;

extra_init() {
   add_action("search","search");
   add_action("news"); add_verb("news");
   add_action("updates"); add_verb("updates");
}

search(str) {
   if(!str || str == "area" || str == "here") {
      say(this_player()->query_name()+" searches the area.\n");
      write("You find nothing else of interest.\n");
      return 1;
   }
   if(sign->id(str)) {
      say(this_player()->query_name()+" searches the billboard.\n");
      write("You find nothing else of interest on the billboard.\n");
      return 1;
   }
   write("search what?\n");
   return 1;
}

extra_reset() {
   if(!present("billboard")) {
      sign = clone_object("players/omega/obj/osign");
      sign->set_name("large billboard");
      sign->set_alias("billboard");
      sign->set_alt_name("board");
      sign->set_short("A large billboard");
      sign->set_long(
   "***************************************************\n"+
   "*  Welcome to Omega's Kingdom:                    *\n"+
   "*  Parts of the kingdom have been completed,      *\n"+
   "*  type 'news' to learn a little about the area   *\n"+
   "*  or 'updates' to hear about any recent changes. *\n"+
   "***************************************************\n");
      move_object(sign, this_object());
   }
}

TWO_EXIT("room/sea", "west",
   "players/omega/pathA0", "east",
   "Entrance to Omega's Kingdom",
   "You are on the shore of the sea.\n"+
   "To the west you see a large sea and to the east you see a crossroads.\n",
   1)

news() {
/*
   write("A deep soothing voice from above speaks:\n");
   write("The kingdom is closed till March 1st, 1991.\n");
   write("Only the housing area can be accessed from this point.\n");
   write("I apologize for any inconvenience this may cause.\n");
*/
   write (
   "A deep soothing voice from above speaks:\n"+
   "\n"+
   "This is the Omegan news ...\n" +
   "\n"+
   "   BEGINNER'S NOTE:  Omega has prepared a present for you.\n"+
   "      Go to the city of Omega to the east, enter through the gate,\n"+
   "      and look in the shops.  The items regenerate at every game reset.\n"+
   "      You may also want to talk to the war vet in BOB's pub.  He has\n"+
   "      much knowledge about this area and knows many stories and rumors\n"+
   "      about the Kingdom of Omega.\n"+
   "   ADVANCED PLAYERS:  Omega understands your need to scavenge for\n"+
   "      objects to sell to the shop for money, but please remember\n"+
   "      that you were once a humble and confused novice as well.\n"+
   "\n"+
   "   The Kingdom of Omega has many features which may interest the\n"+
   "avid adventurer.  To the south, and west off the dirt path lies\n"+
   "a dangerous swamp with many deadly creatures.  Be well equipped\n"+
   "when you enter this area as many creatures are hostile to humans.\n"+
   "To the southeast, and east off the dirt path lies a lovely forest\n"+
   "filled with nature's nicest and not so nice creatures.  Most are\n" +
   "harmless unless provoked.\n"+
/*
   "   The housing contractors are back-logged.  No further applications\n"+
   "for houses are being accepted.  Current orders will be filled as soon\n"+
   "as possible.  However, a new housing development is being planned for\n"+
   "the future.  You will have to try elsewhere till then.  Sorry.\n"
*/
  "");
   return 1;
}

updates() {
   write("A deep soothing voice speaks:\n");
   cat("/players/omega/UPDATES");
   return 1;
}
