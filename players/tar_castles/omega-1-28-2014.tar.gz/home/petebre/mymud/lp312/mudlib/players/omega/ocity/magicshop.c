#include "std.h"

#undef EXTRA_INIT
#define EXTRA_INIT\
    add_action("buy"); add_verb("buy");\
    add_action("list"); add_verb("list");

#undef EXTRA_RESET
#define EXTRA_RESET\
   if(!present("coins")) {\
      object money;\
      money = clone_object("players/omega/obj/utmoney");\
      money->set_money(random(100) + 399);\
      move_object(money, this_object());\
   }

ONE_EXIT("players/omega/ocity/cpathA1","north",
   "City of Omega: Malik's Magic Shop",
   "You are in MALIK'S MAGIC SHOP.  You can certain magic things here.\n"+
   "A posted sign reads: 'Sorry, closed for repairs.'\n", 1)
/*
         "Commands are: 'buy <item>', 'list',\n", 1)
*/

buy(item) {
   write("Sorry ,closed.\n"); return 1;
    if (!item)
        return 0;
    call_other("players/omega/ocity/magicstore", "fill", 0);
    call_other("players/omega/ocity/magicstore", "buy", item);
    return 1;
}

list(obj) {
   write("Sorry ,closed.\n"); return 1;
    call_other("players/omega/ocity/magicstore", "fill", 0);
    call_other("players/omega/ocity/magicstore", "inventory", obj);
    return 1;
}
