#include "std.h"

TWO_EXIT("players/omega/oforest/forestD2", "west",
   "players/omega/oforest/forestD4", "east",
   "Forest\n",
   "You are in a forest.\n",
   1)
