#include "std.h"

FOUR_EXIT("players/omega/ocity/cpathA0","west",
   "players/omega/ocity/cpathA2","east",
   "players/omega/ocity/guild","north",
   "players/omega/ocity/magicshop","south",
   "City fountain",
   "You are on a wooden walkway in the City of Omega.\n"+
   "To the south is a strangely glowing hut.\n"+
   "To the north is a foreboding looking office building.\n",
   1)
