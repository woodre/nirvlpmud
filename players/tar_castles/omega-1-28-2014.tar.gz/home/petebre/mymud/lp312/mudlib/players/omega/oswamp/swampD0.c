#include "path"
#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

THREE_EXIT(PATH+"swampC0", "north",
   PATH+"swampD1", "east",
   PATH+"swampE0", "south",
   "Swamp",
   "You are in a swamp.\n" +
   "A towering mountain range blocks passage to the west.\n",
   0)
