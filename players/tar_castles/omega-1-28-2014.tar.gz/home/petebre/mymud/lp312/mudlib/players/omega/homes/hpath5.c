#include "std.h"

short() {
   return "Highland path east5";
}
long() {
   write("You are in the far eastern section of the Highland area.\n");
   write("The only obvious exit is west.\n");
}
init() {
   add_action("move1","west");
}
move1() {
   this_player()->move_player("west#players/omega/homes/hpath4");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
