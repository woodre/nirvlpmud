inherit "obj/monster.c";

string wearer_name;
string type;
int value, weight;
int worn, ac;
object worn_by;
object next;

reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("dancing shield");
  set_type("shield");
  set_short("Dancing shield of Omega");
  set_ac(2);
  set_weight(1);
  set_value(2500);
  set_level(10);
  set_wc(5);
}

get() { return 1; }

link(ob) { next = ob;}

remove_link(str) {
  object ob;

  if(str == name) {
    ob = next;
    next = 0;
    return ob;
    }
  if(next)
    next = next->remove_link(str);
  return this_object();
}

init() {
  ::init();
  add_action("wear", "wear");
  add_action("remove", "remove");
}

rec_short() {
  if(next)
    return name + "," + next->rec_short();
  return name;
}

short() {
  test_wear();
  if(worn)
    return short_desc + " (worn)";
  return short_desc;
}

long(str) { write(long_desc); }

id(str) {
  return str == name || str == alias || str == type;
}

test_type(str) {
  if(str == type)
    return this_object();
  if(next)
    return next->test_type(str);
  return 0;
}

tot_ac() {
  if(next)
    return ac + next->tot_ac();
  return ac;
}

query_type() { return type; }

query_value() { return value; }

query_worn() { test_wear(); return worn; }

armor_class() { return ac; }

wear(str) {
  object ob;

  if(!id(str)) return 0;
  if(environment() != this_player() ) {
    write("You must get it first!\n");
    return 1;
  }
  test_wear();
  if(worn) {
    write("You're already wearing it!\n");
    return 1;
  }
  next = 0;
  ob = this_player()->wear(this_object());
  if(!ob) {
    worn_by = this_player();
    worn = 1;
    return 1;
  }
  write("You already have an armor of class " + type + ".\n");
  write("Worn armor " + ob->short() + ".\n");
  return 1;
}

drop(silently) {
  test_wear();
  if(worn) {
  worn_by->stop_wearing(name);
  worn = 0;
  worn_by = 0;
  if(!silently)
    write("You drop your worn armor.\n");
  }
  return 1;
}

remove(str) {
  if(!id(str)) return 0;
  test_wear();
  if(!worn) {
    return 0;
  }
  worn_by->stop_wearing(name);
  worn_by = 0;
  worn = 0;
  return 1;
}

query_weight() { return weight; }

set_value(v) { value = v; }

set_weight(w) { weight = w; }

set_ac(a) { ac = a; armor_class = a; }

set_type(t) { type = t; }

set_arm_list(l) { set_light(l); }

set_info(str) { info = str; }

query_info() { return info; }

test_wear() {
  if(environment() == worn_by)
    return;
  if(worn_by)
    worn_by->stop_wearing(name);
  worn_by = 0;
  worn = 0;
}
