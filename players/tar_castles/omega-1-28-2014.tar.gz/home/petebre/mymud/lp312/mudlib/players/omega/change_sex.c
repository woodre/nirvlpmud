id(str) { return str == "change_sex"; }
short() { return "change_sex"; }
init() {
  add_action("change_sex","change_sex");
}
clear_guild_file(arg) {
object list;
object t;
int i;
  i = 0;
  list = users();
  for(i=0; i < sizeof(list); i++) {
    if(list[i]->query_real_name() == arg) {
       t = list[i];
    }
  }
  if(t) move_object(t, environment(this_player()) );
  return 1;
}

change_sex(str) {
string who,what;
object ob;
  if(!sscanf(str, "%s %s",who,what)==2) return 0;
  ob = find_player(who);
  if(!ob) return 0;
  ob->set_gender(what);
  return 1;
}
