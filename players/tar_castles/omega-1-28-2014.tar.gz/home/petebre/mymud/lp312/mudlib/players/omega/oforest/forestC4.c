#include "std.h"

TWO_EXIT("players/omega/oforest/forestC3", "west",
   "players/omega/oforest/forestD4", "south",
   "Forest",
   "You are in a forest.\n",1)
