/* high_office.c - Created by Omega (sung@iitmax.acc.iit.edu)
  */
#define NAME "players/omega/homes/"
#define MAXHOUSES 12
#define BASE_PRICE 60000

string location;    /* an array containing the file names of the rooms where */
                    /* the houses will be built; also the map_id number and */
                    /* which side the house is built on.  Other data may be */
                    /* added at a later date.  */
string owner;       /* an array containing the name of the houses owner */
object house;       /* an array containing pointers to the house objects */
string foo;         /* eats up an unneeded field when using sscanf() */

short() {
   return "Highland Homes Real Estate Office <e>";
}
long(str) {
  if(str=="sign") {
    read(str);
    return 1;
  }
  write("You are in the Highland Homes Real Estate Office.\n");
  write("It is a tastefully designed office with a nice view of the city.\n");
  write("There is a sign on the wall.\n");
  write("The only obvious exit is out.\n");
}
read(str) {
  if(str!="sign") return;
  write("list          : list houses up for sale.\n");
  write("buy <lot #>   : buy a housing lot.\n");
  return 1;
}
list_houses() {
int price;
string side, map_id, owner_name;
int i;
  write("LOT#\tPRICE\tLOCATION ON MAP\t\tOWNER\n");
  i = 0;
  while(i < MAXHOUSES) {
    if(!owner[i]) {
      owner_name = "not yet built";
      price = BASE_PRICE;
   } else {
      owner_name = owner[i];
      price = house[i]->query_price();
   }
   if(price > 0) {
      sscanf(location[i], "%s#%s#%s\n", foo, map_id, side);
      write(i+"\t"+price+"\t"+map_id+" on the "+side+" side"+"\t"+owner_name+
      "\n");
   }
   i += 1;
  }
  return 1;
}
repair_houses(arg) {
int i;
string filename;
   i = 0;
   while(i < MAXHOUSES) {
      if(!house[i]) {
         sscanf(location[i], "%s#%s\n", filename, foo );
         house[i] = clone_object(NAME + "house");
         house[i]->restore_house(i);
         house[i]->set_owner(owner[i]);
         house[i]->save_house();
         move_object(house[i], NAME + filename);
      }
      i = i + 1;
   }
   write("The houses have been repaired.\n");
   return 1;
}
buy_house(arg) {
int lot;
string filename;
   if(!arg) return;
   if(!sscanf(arg, "%d", lot)) {
      return 0;
   }
   if( (lot < 0) || (lot > MAXHOUSES) ) {
      write("Invalid lot number.\n");
      return 1;
   }
   if(!owner[lot]) {
      house[lot] = clone_object(NAME + "house");
      sscanf(location[lot], "%s#%s\n", filename);
      move_object(house[lot], NAME + filename);
      house[lot]->set_owner(this_player()->query_real_name());
      owner[lot] = this_player()->query_real_name();
      save_object( NAME + "high_office" );
      house[lot]->save_house();
      write("You are now the proud owner of a Highland Home!\n");
   } else {
      write("That house is already owned and is not for sale.\n");
   }
   return 1;
}
init() {
   add_action("move2","out");
   add_action("read","read");
   add_action("list_houses","list");
   add_action("buy_house","buy");
   add_action("repair_houses","repair");
}
move2() {
   this_player()->move_player("east#players/omega/homes/hpath1");
   return 1;
}
reset(arg) {
int i;
string filename;
   if(arg) return;
   set_light(1);
   location = allocate(MAXHOUSES);
   owner = allocate(MAXHOUSES);
   house = allocate(MAXHOUSES);
   restore_object(NAME + "high_office");
   i = 0;
   while( i < MAXHOUSES ) {
      location[i] = read_file( "/" + NAME + "high_office.dat", i+1 );
      if(owner[i]) {
         house[i] = clone_object(NAME + "house");
         house[i]->restore_house(i);
         house[i]->set_owner(owner[i]);   /* this is in case of a crash */
         sscanf(location[i], "%s#%s\n", filename, foo);
         move_object(house[i], NAME + filename);
      }
      i = i + 1;
   }
   save_object(NAME + "high_office");
}
