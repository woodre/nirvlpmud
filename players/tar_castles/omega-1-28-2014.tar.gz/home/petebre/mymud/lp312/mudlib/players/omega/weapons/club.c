inherit "obj/weapon.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
   set_name("a club");
  set_class(7);
  set_weight(1);
  set_value(4);
  set_alias("club");
}
