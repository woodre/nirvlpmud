#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

extra_reset() {
}

ONE_EXIT("players/omega/pathA4", "north",
   "Southern dead end",
   "The world suddenly disappears to the south.\n",
   1)
