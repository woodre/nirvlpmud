object muck_dweller;
object money;

short() {
   return "Swamp";
}

long() {
   write("You are in a swamp.\n");
   write("The swamp muck here is especially deep.  It feels like you\n");
   write("are being sucked deeper into the swamp with every step you take.\n");
   write("There are four obvious exits, north, south, east, and west.\n");
}

reset(arg) {
   if(!present("dweller")) {
         muck_dweller = clone_object("obj/monster");
         call_other(muck_dweller, "set_name", "smelly muck dweller");
         call_other(muck_dweller, "set_alias", "dweller");
         call_other(muck_dweller, "set_long",
            "A disgusting muck dweller which smells of swamp gas.\n");
         call_other(muck_dweller, "set_level", random(2) + 6);
         call_other(muck_dweller, "set_al", -120);
         call_other(muck_dweller, "set_aggressive", 0);
         call_other(muck_dweller, "set_ac", 4);
         call_other(muck_dweller, "set_wc", 10);
         call_other(muck_dweller, "set_spell_mess1",
            "Muck dweller attempts to engulf!!");
         call_other(muck_dweller, "set_spell_mess2",
            "Muck dweller engulfs you!!");
         call_other(muck_dweller, "set_chance", 20);
         call_other(muck_dweller, "set_spell_dam", 15);
         move_object(muck_dweller, this_object());

         money = clone_object("obj/money");
         call_other(money,"set_money",random(200) + 400);
         move_object(money,muck_dweller);
   }
   if (arg) return;
}

init() {
   add_action("search","search");
   add_action("move1","west");
   add_action("move2","east");
   add_action("move3","south");
   add_action("move4","north");
}

search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

move1() {
   if(stop_player()) return 1;
   call_other(this_player(),"move_player","west#players/omega/oswamp/swampD0");
   return 1;
}

move2() {
   if(stop_player()) return 1;
   call_other(this_player(),"move_player","east#players/omega/oswamp/swampD2");
   return 1;
}

move3() {
   if(stop_player()) return 1;
   call_other(this_player(),"move_player","south#players/omega/oswamp/swampE1");
   return 1;
}

move4() {
   if(stop_player()) return 1;
   call_other(this_player(),"move_player","north#players/omega/oswamp/swampC1");
   return 1;
}

stop_player() {
string who_name;
   if(this_player()->query_ghost()) return 0;
   if(!present("smelly muck dweller")) return 0;
   if(muck_dweller->query_attack() != this_player()) return 0;
   if(random(5) < 4) {
      write("You are stuck in the mud!\n");
      say(who_name+" tries to run but is stuck in the mud!\n");
      return 1;
   }
   write("You pull free of the mud!\n");
}

