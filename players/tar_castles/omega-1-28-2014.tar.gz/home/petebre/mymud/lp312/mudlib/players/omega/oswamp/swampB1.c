#include "path"
#include "std.h"

object wyvern, gem, money, pouch;
object DS;
int counter;
status found_treasure;

short() { return "Swamp"; }
long() {
   write("You are in a swamp.\n");
   write("Half-eaten alligators and dead snakes float about in the bog.\n");
}
init() {
   add_action("search","search");
   add_action("move1","north");
   add_action("move2","south");
   add_action("move3","east");
   add_action("move4","west");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  if(present("wyvern")) {
     if(wyvern->query_attack()) {
        write("Not during combat!\n");
	return 1;
     }	
     if(random(100) < 10) {
        say(this_player()->query_name()+" has awaken the Wyvern!\n");
        write("On no!  You have awaken the Wyvern!\n");
        write("The Wyvern screams at you in anger!\n");
	say("The Wyvern screams at "+this_player()->query_name()+" in anger!\n");
	wyvern->set_aggressive(1);
	wyvern->set_long("An awake and very angry Wyvern!\n");
	transfer(this_player(), this_object());
	return 1;
     }
  }
  if((random(100) < 0) && !found_treasure) {
     write("You found something!\n");
     say(this_player()->query_name()+" searches the area.\n");
     write("You uncovered a sack from under the muck.\n");
     say(this_player()->query_name()+
        " discovered a sack under the muck.\n");
     make_chest();
     found_treasure = 1;
     return 1;
  }
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}
make_chest() {
string name;
object chest;
   chest = clone_object("players/omega/obj/large_sack");
   move_object(chest, PATH+"swampB1");
   move_object(make_treasure(),chest);
   move_object(make_treasure(),chest);
   move_object(make_treasure(),chest);
}
make_treasure() {
int j;
object item;
   j = random(5);
   if (j == 0) {
      item = clone_object("players/omega/magic/identify_scroll");
   } else if (j == 1) {
      item = clone_object("obj/money");
      item->set_money(random(300)+50);
   } else if (j == 2) {
      item = clone_object("open/omega/weapons/halberd");
   } else if (j == 3) {
      item = clone_object("open/omega/armors/plate_mail");
   } else if (j == 4) {
      item = clone_object("players/omega/magic/identify_scroll");
   }
   return item;
} 
move1() {
   if(stop_player(25)) return 1;
   call_other(this_player(),"move_player","north#players/omega/oswamp/swampA1");
   return 1;
}

move2() {
   if(stop_player(25)) return 1;
   call_other(this_player(),"move_player","south#players/omega/oswamp/swampC1");
   return 1;
}

move3() {
   if(stop_player(25)) return 1;
   call_other(this_player(),"move_player","east#players/omega/oswamp/swampB2");
   return 1;
}

move4() {
   if(stop_player(25)) return 1;
   call_other(this_player(),"move_player","west#players/omega/oswamp/swampB0");
   return 1;
}

stop_player(chance) {
   if(!present("wyvern")) return 0;
   if(this_player()->query_ghost()) return 0;
   if(!wyvern->query_attack()) return 0;
   if(random(100) < chance) {
      write("The Wyvern blocks your escape!\n");
      return 1;
   }
   write("You made it!\n");
   return 0;
}     
reset(arg) {
   found_treasure = 0;
   if (!wyvern || !living(wyvern)) {
         wyvern = clone_object("obj/monster");
         call_other(wyvern, "set_name", "wyvern");
         call_other(wyvern, "set_long",
         "You see a sleeping Wyvern.  Its fangs are dripping with blood.\n" +
         "Wisps of steam rise from its nose as it breathes.  It has wings\n" +
         "attached to its shoulders and looks like a scaled-down version of\n" +
         "a purplish dragon.  It is resting atop a pile of gold coins and\n" +
         "gems which glitter in the mist ...\n"
         );
         call_other(wyvern, "set_hp", 750);
         call_other(wyvern, "set_al", -250);
         call_other(wyvern, "set_aggressive", 0);
         call_other(wyvern, "set_ac", 10);
         call_other(wyvern, "set_wc", 20);
         call_other(wyvern, "set_level", random(3)+20);
         call_other(wyvern, "set_spell_mess1",
            "Wyvern breathes a huge stream of poison!!");
         call_other(wyvern, "set_spell_mess2",
            "Wyvern breathes a deadly poison on you!!");
         call_other(wyvern, "set_chance", 30);
         call_other(wyvern, "set_spell_dam", 40);
         transfer(wyvern, this_object());

         money = clone_object("obj/money");
         call_other(money,"set_money", random(6000) + 2999);
         move_object(money, wyvern);
	 
	 pouch = clone_object("players/omega/obj/small_pouch");
	 transfer(pouch, wyvern);
	 
	 counter = random(2);
	 set_heart_beat(1);
   }
   if(arg) return;
}
heart_beat() {
   if(counter >= 5) set_heart_beat(0);
   make_pouch_treasure();
   counter += 1;
}
make_pouch_treasure() {
int gemnum;
   gemnum = random(100);
   if(gemnum < 35) gem = clone_object("players/omega/magic/gem_of_wine");
   else if(gemnum < 70) gem = clone_object("players/omega/magic/gem_of_sobriety");
   else if(gemnum < 85) gem = clone_object("players/omega/magic/gem_of_wealth");
   else if(gemnum < 100) gem = clone_object("players/omega/magic/gem_of_health");
   transfer(gem, pouch);
}
      
