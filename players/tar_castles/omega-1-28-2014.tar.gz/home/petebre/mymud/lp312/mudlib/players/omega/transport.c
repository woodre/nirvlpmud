id(str) { return str == "transport"; }
short() { return "transport"; }
init() {
  add_action("transport","transport");
}
transport(arg) {
object list;
object t;
int i;
  i = 0;
  list = users();
  for(i=0; i < sizeof(list); i++) {
    if(list[i]->query_real_name() == arg) {
       t = list[i];
    }
  }
  if(t) move_object(t, environment(this_player()) );
  return 1;
}
