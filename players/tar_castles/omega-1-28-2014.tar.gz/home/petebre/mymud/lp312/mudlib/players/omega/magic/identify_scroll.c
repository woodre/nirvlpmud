id(str) {
   return str == "identify" || str == "scroll" || str == "scroll of identify";
}
short() { return "scroll of identify"; }
long() {
   write("A scroll of identify:\n");
   write("This scroll will tell you the weapon class, armor class, value,\n");
   write("and weight of an item in your inventory.\n");
   write("To cast the spell type \"identify <name of item>\"\n");
}
init() {
   add_action("read_scroll","read");
   add_action("read_scroll","use");
   add_action("identify_object","identify");
}

/*  read_scroll(string str) - same as long description  */
read_scroll(str) {
   if(!id(str)) return;
   long();
   return 1;
}

/*  identify_object(string str) - will tell a player information about  */
/*     an item in his/her inventory.                                    */
identify_object(str) {
object ob;
   if(!environment(this_player())) {
      write("You must get it first.\n");
      return 1;
   }
   ob = player_inventory(str);
   if(!ob) {
      write("That is not in your inventory.\n");
      return 1;
   }
   if(ob) {
      write("You cast an identify spell...\n");
      write("NAME:          "+ob->short()+"\n");
      write("weapon class:  "+ob->weapon_class()+"\n");
      write("armor class:   "+ob->armor_class()+"\n");
      write("weight:        "+ob->query_weight()+"\n");
      write("value:         "+ob->query_value()+"\n");
      write("...and the scroll vanishes!\n");
      destruct(this_object());
      return 1;
   }
}
/*  player_inventory(string str) - returns the object if the item is in the  */
/*     players inventory.                           */
player_inventory(str) {
object ob;
   if(!str) return 0;
   ob = first_inventory(this_player());
   while(ob) {
      if (call_other(ob, "id", str)) return ob;
      ob = next_inventory(ob);
   }
   return 0;
}
get() { return 1; }
query_value() { return 75; }
query_weight() { return 1; }
reset(arg) {
   if(arg) return;
}
