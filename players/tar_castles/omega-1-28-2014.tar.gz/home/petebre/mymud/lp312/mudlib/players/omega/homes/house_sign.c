id(str) {
  return str == "sign" || str == "housing sign";
}
short() {
  return "HOUSING SIGN (posted April 22nd)";
}
long() {
  write(
    "The housing drawing was held April 22nd and twenty-four names were\n"+
    "successfully drawn.  Winners have been notified by mail.\n"+
    "Ten alternate names were also drawn in the event any of the winners\n"+
    "is unable or unqualified to buy a house.  They also have been\n"+
    "notified by mail.  If the housing project goes successfully for\n"+
    "a while, another project will be built.\n"+
    "WINNERS: switch,slime,marduk,solamnus,mercedes,noika,shareena,raun,\n"+
    "         deathshade,pip,xris,natalie,morningstar,emerson,valentine,\n"+
    "         rilrae,daranath,akabar,silver,colorado,lotus,quella,hippo,\n"+
    "         alustryx.\n"+
    "ALTERNATES: dritz,delirium,acura,jenga,kirkion,oink,midnight,nancy,\n"+
    "            grismor,dracula.\n"+
    "Non-winners will be refunded the 10,000 deposit via this sign.\n"+
    "I have to implement the code still and will do it when I have a bit\n"+
    "more time (within a week or two promise). - Omega the Winged One!\n"+
    "Better luck next time!\n"
  );
}
init() {
  add_action("read_sign","read");
}
read_sign(str) {
  if(!id(str)) return 0;
  long();
  return 1;
}
reset(arg) {
  if(arg) return;
}
