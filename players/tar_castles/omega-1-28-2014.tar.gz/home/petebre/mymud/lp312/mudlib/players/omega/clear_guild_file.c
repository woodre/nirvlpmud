id(str) { return str == "clear-guild-file"; }
short() { return "clear-guild-file"; }
init() {
  add_action("clear_guild_file","clear-guild-file");
}
clear_guild_file(arg) {
object list;
object t;
int i;
  i = 0;
  list = users();
  for(i=0; i < sizeof(list); i++) {
    if(list[i]->query_real_name() == arg) {
       t = list[i];
    }
  }
  if(t) move_object(t, environment(this_player()) );
  return 1;
}

change_guild_file(str) {
string who;
object ob;
  sscanf(str, "%s", who);
  ob = find_player(who);
  if(!ob) return 0;
  ob->set_guild_file(0);
  return 1;
}
