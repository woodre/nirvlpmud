inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a ninja tie");
  set_short("A Ninja Tie");
  set_type("shield");
  set_ac(1);
  set_weight(0);
  set_value(0);
  set_alias("tie");
}
drop() {
   write("The sacred tie should be worn at all times!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/tie.c:"; }
