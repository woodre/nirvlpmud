#include "std.h"

short() {
   return "Highland path westC";
}
long() {
   write("You are in the far western section of the Highland area.\n");
   write("The only obvious exit is east.\n");
}
init() {
   add_action("move1","east");
}
move1() {
   this_player()->move_player("east#players/omega/homes/hpathB");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
