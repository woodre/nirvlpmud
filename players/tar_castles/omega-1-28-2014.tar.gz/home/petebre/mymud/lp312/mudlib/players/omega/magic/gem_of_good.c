int counter, weight;
object player;

id(str) {
   if(counter > 0) return str == "humxye";
   return str == "pearl" || str == "white pearl" || str == "gem of good";
}
short() {
   if(counter > 0) return 0;
   return "a white pearl";
}
long() {
   write("It is a pretty white pearl.  It looks flawless.\n");
}
init() {
   add_action("crush_gem","crush");
   add_action("crush_gem","squeeze");
}
crush_gem(str) {
   if(!id(str)) return 0;
   if(counter > 0) return 0;
   if(environment() != this_player()) {
      write("You must get it first.\n");
      return 1;
   }
   player = this_player();
   write("There is a clap of thunder from high above!\n");
   say("You hear a clap of thunder from high above!\n");
   write("The pearl vanishes.\n");
   counter += 1;
   transfer(this_object(),environment(player));
   weight = 0;
   transfer(this_object(),player);
   set_heart_beat(1);
   return 1;
}
heart_beat() {
   if(player->query_al() < -500) {
      write("A voice booms:  YOU ARE TOO FAR ON THE SIDE OF EVIL!\n");
      say("A voice booms:  YOU ARE TOO FAR ON THE SIDE OF EVIL!\n");
      write("You are hit by a lightning bolt!   KRAAACK!\n");
      say(player->query_name()+" is struck by lightning!   KRAAACK!\n");
      player->hit_player(random(50)+25);
      destruct(this_object());
   }
   if(counter > 20) {
      player->add_alignment(2000);
      write("You have an overwhelming urge to do GOOD.\n");
      write("You have become a White Lord!\n");
      destruct(this_object());
   }
   if(counter == 4) say("A warm feeling comes over you.\n");
   else if (counter == 8) write("You think of happy thoughts.\n");
   else if (counter == 12) say("Life is good and it's good to be alive.\n");
   else if (counter == 16) say("You decide to be a nice guy.\n");
   else if (counter == 20) say("You are just brimming with goodness!\n");
   player->add_alignment(300);
   counter += 1;
}
get() {
   if(counter > 0) return 0;
   return 1;
}
drop() {
   if(counter > 0) return 1;
   return 0;
}
query_value() { return 5000; }
query_weight() { return weight; }
reset(arg) {
   if(arg) return;
   counter = 0;
   weight = 1;
}
