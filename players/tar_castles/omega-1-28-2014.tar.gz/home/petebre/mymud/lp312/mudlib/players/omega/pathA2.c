#include "std.h"

THREE_EXIT("players/omega/pathA1", "north",
   "players/omega/pathA3", "south",
   "players/omega/oforest/forestA0", "east",
   "Forest entrance",
   "You are on a dirt path.\n" +
   "To the east you can see a large forest.\n",
   1)
