#include "std.h"

FOUR_EXIT("players/omega/ocity/cpathA2","west",
   "players/omega/ocity/cpathA4","east",
   "players/omega/ocity/clinic","south",
   "players/omega/ocity/hardware","north",
   "City walkway",
   "You are on a wooden walkway in the city of Omega.\n"+
   "To the north is a hardware store.\n"+
   "To the south is a tall ivory tower.\n",
   1)
