inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a ninja shozoku");
set_short("A Ninja Shozoku");
  set_type("armor");
  set_ac(4);
  set_weight(0);
  set_value(0);
  set_alias("shozoku");
}
drop() {
   write("The sacred shozoku should be worn at all times!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/shozoku.c:"; }
