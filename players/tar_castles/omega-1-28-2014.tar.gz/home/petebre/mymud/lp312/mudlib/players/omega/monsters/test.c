inherit "obj/player.c";

#define EXPLORE 23

object soul;

string owner_name;

init() {
   ::init();
   add_action("force_me","fb");
}

force_me(str) {
   return(command(str));
}

reset(arg) {
   if(arg) return;
   ::reset(arg);
   name="butler";
   myself=this_object();
   soul=clone_object("obj/soul");
   move_object(soul,this_object());
   set_level(10);

}

set_level(lev) {
   level=lev;
   max_hp=42 + level + 8;
   if(hit_point > max_hp) hit_point=max_hp;
   if(spell_points > max_hp) spell_points=max_hp;
   if(level >= EXPLORE) {
      ::soul("on");
   }
   if(level>=EXPLORE&&soul) soul->update(1);
}
