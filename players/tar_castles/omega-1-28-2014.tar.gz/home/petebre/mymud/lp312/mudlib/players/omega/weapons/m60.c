inherit "obj/weapon.c";

int ammo;
int loaded;
int club;
int setting;
int bullet_dam;
object ammo_obj;

reset(arg){
  if(arg) return 0;
  ::reset(arg);
  set_name("m60 heavy machine gun");
  set_alias("gun");
  set_alt_name("m60");
  set_short("An M60 Heavy Machine Gun");
  long_desc =
    "This is a support weapon used by NATO forces to suppress the enemy.\n"+
    "It is a heavy machine gun which fires .50 caliber bullets rapidly.\n"+
    "It has three settings: single, burst (3 shots), auto (9 shots).\n"+
    "To load and unload the machine gun, type '<load|unload> m60'.\n"+
    "To move the selector switch, type 'switch m60 to <single|burst|auto>'.\n";
  set_class(15);
  set_weight(6);
  set_value(20000);
  set_hit_func(this_object());
  setting = 1;
  club = 1;
}

long(){
  write(long_desc);
  write("The selector switch is in the ");
  if(setting==1){ write("'single shot'"); }
  if(setting==2){ write("'burst'"); }
   if(setting==3){ write("'automatic'"); }
    if(setting==0){ write("<secret>"); }
  write(" position.\n");
  if(loaded){
    write("It is loaded with a belt with "+ammo+" rounds.\n");
  } else {
    write("It is not loaded.\n");
  }
}

init(){
  ::init();
  add_action("load_weapon","load");
  add_action("unload_weapon","unload");
  add_action("switch_setting","switch");
}

load_weapon(str){
string rifle, clip;
  if(!str) return;
  if(!present("m60 ammo",this_player())) {
    write("You don't have any M60 ammo belts on you!\n");
    return 1;
  }
  if(loaded) {
    write("What?  There is already a belt in the M60.\n");
    return 1;
  }
  loaded = 1;
  club = 0;
  say(this_player()->query_name()+" loads a belt of ammo into an m60 heavy Machine gun.\n");
  ammo_obj = present("m60 ammo",this_player());
  move_object(ammo_obj, this_object());
  set_weight(9);
  ammo = ammo_obj->query_ammo();
  write("You load an ammo belt ("+ammo+" rounds) into the M60.\n");
  return 1;
}

unload_weapon(str){
  if(!id(str)) return 0;
  if(!loaded) {
    write("It is not loaded.\n");
    return 1;
  }
  loaded = 0;
  club = 1;
  write("You pull the belt ("+ammo+" rounds) out of the M60.\n");
  ammo_obj->set_ammo(ammo);
  move_object(ammo_obj,this_player());
  set_weight(6);
  return 1;
}

switch_setting(str){
string weapon, selection;
  if(!str)return 0;
  if(sscanf(str,"%s to %s",weapon,selection) != 2) {
    return 0;
  }
  if(!id(weapon)) return;
  if(selection=="full" || selection=="auto") {
    write("The switch slides to the 'auto' position.\n");
    write("Time to make swiss cheese corpses!\n");
    say(this_player()->query_name()+" sets the switch on his M60 to automatic.\n");
    setting=3;
    return 1;
  }
  if(selection=="semi" || selection=="burst") {
    write("The switch slides to the 'burst' position.\n");
    write("Somebody's going to be in trouble now!\n");
    say(this_player()->query_name()+" sets the switch on his M60 to burst.\n");
    setting = 2;
    return 1;
  }
  if(selection=="single" || selection=="single shot") {
    write("The switch slides to the 'single shot' position.\n");
    write("Be careful where you point that thing!\n");
    say(this_player()->query_name()+" sets the switch on an M60 to single shot.\n");
    setting = 1;
    return 1;
  }
  if(selection=="rambo") {
    write("You will now shoot everyone who attacks you!\n");
    say(this_player()->query_name()+" cackles loudly!\n");
    say(this_player()->query_name()+" ties a head band around his head!\n");
    say(this_player()->query_name()+" says: RAMBO TIME!!!!\n");
    setting = 0;
    return 1;
  }
  write("There is no such selection on the M60 rifle.\n");
  return 1;
}

weapon_hit(){
object target;
  if(ammo==0 && !club){
    write("Click, click, click!  You're out of ammo!\n");
    say(this_player()->query_name()+"'s M16 goes click, click, click!\n");
    club = 1;
    return -100;
  }
  if(club) return -10;
  if(setting==0){
    target=first_inventory(environment(this_player()));
  }
  if((setting==3)&&(ammo>=9)) {
    write("BLAM-BLAM-BLAM-BLAM-BLAM-BLAM-BLAM-BLAM-BLAM!!!\n");
    say("BLAM-BLAM-BLAM-BLAM-BLAM-BLAM-BLAM-BLAM-BLAM!!!  "+
        this_player()->query_name()+" fires his M60 on FULL AUTO!!!\n");
    ammo -= 9;
    bullet_dam = random(15)+random(15)+random(15)+random(15)+random(15)+
      random(15)+random(15)+random(15)+random(15)+45;
    write("Damage: "+bullet_dam+", ");
    return bullet_dam;
  }
  if((setting>=2)&&(ammo>=3)){
    write("TOK-TOK-TOK!!!!!!  You grin in satisfaction as you let loose a few rounds!\n");
    say("TOK-TOK-TOK!!!  "+this_player()->query_name()+" grins with "+
        "satisfaction!\n");
    ammo -= 3;
    bullet_dam = random(15)+random(15)+random(15)+15;
    write("Damage: "+bullet_dam+", ");
    return bullet_dam;
  }
  if(setting>=1){
    write("KRA-KOW!  You fire a .50 caliber bullet at your opponent!\n");
    say("KRA-KOW!  "+this_player()->query_name()+" fires a 5.56mm NATO bullet!\n");
    ammo -= 1;
    bullet_dam = random(15)+5;
    write("Damage: "+bullet_dam+", ");
    return bullet_dam;
  }
}
