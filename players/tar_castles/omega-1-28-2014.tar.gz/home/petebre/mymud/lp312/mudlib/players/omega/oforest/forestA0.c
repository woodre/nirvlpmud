#include "std.h"

THREE_EXIT("players/omega/pathA2", "west",
   "players/omega/oforest/forestB0", "south",
   "players/omega/oforest/forestA1", "east",
   "Forest",
   "A sign reads:  FOREST OF OMEGA.\n" +
   "The trees are not too dense here.\n" +
   "( They are actually pretty smart! )\n" +
   "The forest becomes impassable to the north.\n"+
   "There is a path to the west.\n",
   1)
