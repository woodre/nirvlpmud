inherit "obj/armor";

reset(arg) {
   if(!arg) {
   set_name("wizard diaper");
   set_alias("diaper");
   set_short("A training diaper for wizard babies");
   set_value(0);
   set_weight(0);
   set_type("misc");
   }
}

init() {
   ::init();
   if(this_player()->query_level() < 20) return;
   add_action("dest_diaper","dest");
   add_action("dest_diaper","destroy");
   add_action("cry_baby","clone");
   add_action("cry_baby","home");
   add_action("cry_baby","ls");
   add_action("cry_baby","cd");
   add_action("cry_baby","goto");
   add_action("cry_baby","shout");
   add_action("cry_baby","tell");
   add_action("cry_baby","say");
   add_action("cry_baby","people");
   add_action("cry_baby","fireball");
   add_action("cry_baby","shock");
   add_action("cry_baby","missile");
   add_action("cry_baby","force");
   add_action("cry_baby","emote");
   add_action("cry_baby","stat");
}

dest_diaper(str) {
   if (this_player()->query_name() == "Omega") { return 0; }
   if (str != "diaper") { return 0; }
   write("You try to get rid of the diaper but can't!  WAAHHH!!\n");
   say(this_player()->query_name()+" cries like a baby.  WAAAHHH!!\n");
   return 1;
}

cry_baby() {
   if(this_player()->query_name() == "Omega") { return 0; }
   if(this_player()->query_level() < 20)   { return 0; }
   say(this_player()->query_name()+ "throws a tantrum.\n");
   write("You can't do that!  WAAAAHHHHH!!\n");
   return 1;
}

get() {
   if(this_player()->query_name() == "Omega") { return 1; }
   return 0;
}

drop() {
   if(this_player()->query_name() == "Omega") { return 0; }
   if(this_player()->query_level() < 20) { return 0; }
   wear("diaper");
   return 1;
}

id(str) {
   return ((::id(str)) || str == "ND");
}

query_auto_load() {
   return "players/omega/obj/diaper:";
}

init_arg() { return; }

extra_look() {
   write(this_player()->query_name()+"'s diaper is leaking all over.\n");
}
