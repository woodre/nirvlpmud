inherit "obj/weapon.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a hand axe");
  set_class(8);
  set_weight(1);
  set_value(25);
  set_alt_name("hand axe");
  set_alias("axe");
}
