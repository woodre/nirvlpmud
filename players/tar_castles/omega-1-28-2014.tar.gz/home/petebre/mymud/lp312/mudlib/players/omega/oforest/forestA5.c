#include "std.h"

TWO_EXIT("players/omega/oforest/forestA4", "west",
   "players/omega/oforest/forestB5", "south",
   "Forest",
   "You are in a forest.\n",1)
