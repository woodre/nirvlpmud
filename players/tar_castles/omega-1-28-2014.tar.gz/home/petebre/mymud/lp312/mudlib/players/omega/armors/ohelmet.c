inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("truesight helmet");
  set_short("Truesight helmet of Omega");
  set_long(
    "~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~\n"+
    "This armor is magically enhanced and allows you to\n"+
    "know and see just about everything there is!\n"+
    "'trueinfo <item>'  :  info about an item in your inventory\n"+
    "'truestat <player | monster>'  : stats of a player or monster\n"+
    "                                 in the same room as you\n"+
    "It can only be obtained if Omega grants one to you.\n"+
    "Wear it well... MAY YOU NEVER FALL IN BATTLE!!!!!\n");
  set_type("helmet");
  set_ac(2);
  set_weight(1);
  set_value(2500);
  set_alias("helmet");
}

init() {
  ::init();
  add_action("truewho","truewho");
  add_action("truewhere","truewhere");
  add_action("truelook","truelook");
  add_action("truestat","truestat");
  add_action("trueinfo","trueinfo");
}

trueinfo(arg) {
object ob;
  if(!arg) {
    write("Usage:  'trueinfo <item>'\n");
    return 1;
  }
  ob = find_inventory(arg, this_player());
  if(!ob) {
    write("That is not in your inventory.\n");
    return 1;
  } else {
    write("NAME:          "+ob->short()+"\n");
    write("weapon class:  "+ob->weapon_class()+"\n");
    write("armor class:   "+ob->armor_class()+"\n");
    write("weight:        "+ob->query_weight()+"\n");
    write("value:         "+ob->query_value()+"\n");
    return 1;
  }
}

find_inventory(str, target) {
object ob;
  if(!str) return 0;
  ob = first_inventory(target);
  while(ob) {
    if (call_other(ob, "id", str)) return ob;
    ob = next_inventory(ob);
  }
  return 0;
}

truestat(str) {
object target;
  if(!str) {
    write("Usage:  'truestat <player | monster>'\n");
    return 1;
  }
  target = find_living_inventory(str, environment(this_player()) );
  if(!target) {
    target = find_player(str);
    if(!target) {
      write("No such player on, or monster in this room.\n");
      return 1;
    }
  }
  write("NAME:          "+target->short()+"\n");
  write("hit points:    "+target->query_hp()+"/"+target->query_mhp()+"\n");
  write("spell points:  "+target->query_sp()+"/"+target->query_msp()+"\n");
  write("weapon class:  "+target->query_wc()+"\n");
  write("armor class:   "+target->query_ac()+"\n");
  return 1;
}

find_living_inventory(str, target) {
object ob;
  ob = first_inventory(target);
  while(ob) {
    if(living(ob) && call_other(ob,"id",str) ) return ob;
    ob = next_inventory(ob);
  }
  return 0;
}
