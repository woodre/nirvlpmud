#include "std.h"
#include "living.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object bunny;
object carrot;
int i;

THREE_EXIT("players/omega/oforest/forestA0", "north",
   "players/omega/oforest/forestB1", "east",
   "players/omega/oforest/forestC0", "south",
   "Forest",
   "You are in a forest.\n" +
   "The forest becomes impassable to the west.\n",
   1)

extra_reset() {
   if (!bunny || !living(bunny)) {
      i = 0;
      while (i < (random(10)+4)) {
         i += 1;

         bunny = clone_object("obj/monster");
         call_other(bunny, "set_name", "cute little bunny");
         call_other(bunny, "set_al", 0);
         call_other(bunny, "set_alias", "bunny");
         call_other(bunny, "set_race", "animal");
         call_other(bunny, "set_long",
            "It is the cutest little bunny you have ever seen.\n");
         call_other(bunny, "set_aggressive", 0);
         bunny->set_ac(1);
         bunny->set_level(1);
         call_other(bunny, "set_hp", 20);
         bunny->set_whimpy(1);
  
         move_object(bunny, this_object());

         carrot = clone_object("players/omega/obj/oheal");
         carrot->set_name("carrot");
         carrot->set_short("A fresh carrot");
         carrot->set_long(
         "You see a scrumptious carrot.  Carrots are good to eat.\n"
         );
         carrot->set_value(10);
         carrot->set_amount(5);
         carrot->set_self("You feel healthier!");
         carrot->set_others("eats a carrot and looks healthier!");
         carrot->set_verb("eat");
         carrot->set_weight(1);
         transfer(carrot,bunny);
      }
   }
}
