#include "path"
#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

FOUR_EXIT(PATH+"swampD1", "north",
   PATH+"swampE0", "west",
   PATH+"sdragon_cave", "cave",
   PATH+"swampE2", "east",
   "Cave entrance",
   "A sign reads: 'BEWARE OF THE DRAGON!'\n" +
   "Dead bodies and broken equipment litter this area.\n" +
   "A large cave lies to the south.\n" +
   "There is a trail of blood leading into the cave ...\n",
   0)
