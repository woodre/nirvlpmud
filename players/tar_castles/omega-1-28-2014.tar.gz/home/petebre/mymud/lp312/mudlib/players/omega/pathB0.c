#include "std.h"

TWO_EXIT("players/omega/pathB1", "north",
   "players/omega/pathA0", "south",
   "Northern dirt path",
   "You are on a dirt path on the north side of the kingdom.\n",
   1)
