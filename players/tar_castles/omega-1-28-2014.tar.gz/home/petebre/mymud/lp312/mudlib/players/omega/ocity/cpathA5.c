#include "std.h"

ONE_EXIT("players/omega/ocity/cpathA4","west",
   "Eastern Blockade",
   "The wooden walkway comes to an abrupt halt.\n"+
   "Barricades block any further passage east.\n"+
   "Off to the east you hear the splashing of waves\n"+
   "hitting upon a shore.\n",
   1)
