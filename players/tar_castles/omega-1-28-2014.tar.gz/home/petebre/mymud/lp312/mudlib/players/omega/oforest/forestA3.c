#include "std.h"

ONE_EXIT("players/omega/oforest/forestA4", "east",
   "Forest\n",
   "You are in a forest.\n" +
   "The trees are impassable at this point.\n",
   1)
