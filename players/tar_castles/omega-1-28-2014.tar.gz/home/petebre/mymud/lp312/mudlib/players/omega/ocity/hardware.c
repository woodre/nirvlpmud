#include "std.h"

ONE_EXIT("players/omega/ocity/cpathA3","south",
   "City of Omega: Hardware Store <s>",
   "You are in HALEY'S HARDWARE STORE.\n"+
   "It is not yet open for business.\n",
   1)
