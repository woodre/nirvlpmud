inherit "players/omega/obj/oweapon.c";

#define SHORT_DESC     "A Ninja Katana"

status hidden;

reset(arg) {
  if(arg) return;
  ::reset(arg);
   set_name("a ninja katana");
   set_short(SHORT_DESC);
   set_long("You see a long, black, lethal-looking sword.\n");
  set_class(18);
  set_weight(0);
  set_value(0);
  set_alias("katana");
  set_hit_func(this_object());
}
weapon_hit(attacker) {
int magic;
   magic = random(100);
   if(magic < 30) {
      magic = random(100);
      if(magic < 5) {
         write("Dang!  You've gouged out a pound of flesh!!!\n");
         say(this_player()->query_name()+" gouges out a pound of flesh!!!\n");
         return 36;
      }
      if(magic < 25) {
         write("You rock your opponent senseless.  Damn that hurt!\n");
         say(this_player()->query_name()+" rocks his opponent senseless!\n");
         return 18;
      }
      write("The fighting spirit of your katana appears!\n");
      say("The fighting spirit of "+this_player()->query_name()+
          "'s katana appears!\n");
      return 7;
   }
}
drop(silently) {
   write("The sacred blade should never be dropped!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/katana:"; }
wield() {
   if(hidden) {
      unhide_weapon("katana");
   }
   return(::wield());
}
init() {
  ::init();
   if(environment() != this_player()) return;
  add_action("hide_weapon","sheath");
  add_action("unhide_weapon","unsheath");
}
hide_weapon(str) {
   if(str != "katana") return 0;
   if(hidden) return 0;
   if(wielded) {
      wielded_by->stop_wielding();
      wielded = 0;
      write("You unwield your katana.\n");
   }
   write("You silently sheath your katana, hiding it from view.\n");
   set_short(0);
   hidden = 1;
   return 1;
}
unhide_weapon(str) {
   if(str!="katana") return 0;
   if(!hidden) return 0;
   write("You silently remove your katana from its sheath.\n");
   set_short(SHORT_DESC);
   hidden = 0;
   return 1;
}
