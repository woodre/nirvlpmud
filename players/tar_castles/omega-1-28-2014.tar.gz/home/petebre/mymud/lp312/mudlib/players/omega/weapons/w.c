inherit "obj/weapon.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
   set_name("death blade");
   set_short("Death blade of Omega");
   set_long("_-~****  @==[==============--  ****~-_\n"+
             "You see Omega's legendary Death Blade!\n"+
            "This is a special weapon which can only\n"+
            "be obtained if Omega grants one to you.\n"+
            "MAY YOU NEVER BE DEFEATED IN BATTLE!!!!\n"+
            "");
  set_class(20);
  set_weight(1);
  set_value(25000);
  set_alias("blade");
}
