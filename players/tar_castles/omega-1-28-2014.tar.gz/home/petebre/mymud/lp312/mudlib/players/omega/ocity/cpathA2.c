#include "std.h"

FOUR_EXIT("players/omega/ocity/cpathA1","west",
   "players/omega/ocity/cpathA3","east",
   "players/omega/ocity/weaponry","north",
   "players/omega/ocity/armory","south",
   "City of Omega: Walkway",
   "You are on a wooden walkway in the City of Omega.\n" +
   "There is a weapons shop to the north and an armory to the south.\n"+
   "You see a fountain to the west.\n",
   1)
