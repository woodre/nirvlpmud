inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a ninja hood");
  set_short("A Ninja Hood");
  set_type("helmet");
  set_ac(1);
  set_weight(0);
  set_value(0);
  set_alias("hood");
}
drop() {
   write("The sacred hood should be worn at all times!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/hood.c:"; }
