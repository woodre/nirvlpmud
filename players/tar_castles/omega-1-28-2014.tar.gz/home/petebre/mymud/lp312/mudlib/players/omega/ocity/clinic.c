#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object doctor;
object money;

ONE_EXIT("players/omega/ocity/cpathA3","north",
   "City of Omega: Clinic <n>",
   "You are in the IVORY TOWER HOSPITAL, named so because of its stark\n"+
   "white architecture.  The air smells clean and fresh.\n",
   1)

extra_reset() {
   if (!present("doctor")) {
      doctor = clone_object("players/omega/monsters/doctor");
      transfer(doctor,this_object());
      money = clone_object("obj/money");
      money->set_money(random(300) + 200);
      move_object(money, doctor);
   }
}
