#include "std.h"

ONE_EXIT("players/omega/pathB0", "south",
   "Northern dead end",
   "The world seems to disappear to the north.\n"+
   "(I have plans for this in the future - Omega the Winged One!)\n",
   1)
