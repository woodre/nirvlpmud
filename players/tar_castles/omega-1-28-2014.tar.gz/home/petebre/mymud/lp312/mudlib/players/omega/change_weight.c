id(str) { return str == "change_weight"; }
short() { return "change_weight"; }
init() {
  add_action("change_weight","change_weight");
}
clear_guild_file(arg) {
object list;
object t;
int i;
  i = 0;
  list = users();
  for(i=0; i < sizeof(list); i++) {
    if(list[i]->query_real_name() == arg) {
       t = list[i];
    }
  }
  if(t) move_object(t, environment(this_player()) );
  return 1;
}

change_weight(str) {
string who;
int what;
object ob;
  if(!sscanf(str, "%s %d",who,what)==2) return 0;
  ob = find_player(who);
  if(!ob) return 0;
  ob->add_weight(what);
  return 1;
}
