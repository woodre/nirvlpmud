id(str) { return str == "clear-guild-file"; }
short() { return "clear-guild-file"; }
init() {
  add_action("clear_guild_file","clear-guild-file");
}
clear_guild_file(arg) {
object list;
object t;
int i;
  i = 0;
  list = users();
  for(i=0; i < sizeof(list); i++) {
    if(list[i]->query_real_name() == arg) {
       t = list[i];
    }
  }
  if(t) t->set_guild_file("dopple");
  return 1;
}
