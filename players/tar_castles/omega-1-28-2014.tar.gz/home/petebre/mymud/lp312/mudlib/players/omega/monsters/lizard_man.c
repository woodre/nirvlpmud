inherit "obj/monster.c";
object weapon;
object shield;
object gold;
int n, class, value, weight;
string w_name, alt_name;

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("lizard man");
   set_race("man");
   set_ac(6);
   set_wc(11);
   set_al(-60);
   set_alias("animal");
   set_long("A savage, dark green, half-lizard, half-man abomination.\n");
   set_aggressive(1);
   set_level(random(5) + 3);
   set_can_kill(0);
   n = random(2);
   weapon = clone_object("obj/weapon");
   if (n == 0) {
      w_name = "battle axe";
      class = 11;
      value = 100;
      weight = 2;
      alt_name = "axe";
      call_other(weapon, "set_alt_name", alt_name);
   }
   if (n == 1) {
      w_name = "scimitar";
      class = 9;
      value = 200;
      weight = 3;
   }
   if (n == 2) {
      w_name = "club";
      class = 7;
      value = 4;
      weight = 1;
   }
   call_other(weapon, "set_name", w_name);
   call_other(weapon, "set_class", class);
   call_other(weapon, "set_weight", weight);
   call_other(weapon, "set_value", value);
   move_object(weapon, this_object());
   init_command("wield " + w_name);
							     
   shield = clone_object("obj/armor");
   call_other(shield, "set_name", "swamp shield");
   call_other(shield, "set_short", "A shield");
   call_other(shield, "set_long", "A battered shield.\n" +
      "It is painted a swamp green color.\n");
   call_other(shield, "set_value", 40);
   call_other(shield, "set_weight", 1);
   call_other(shield, "set_ac", 1);
   call_other(shield, "set_type", "shield");
   move_object(shield, this_object());

   gold = clone_object("obj/money");
   call_other(gold, "set_money", random(60) + 10);
   move_object(gold, this_object());
}
