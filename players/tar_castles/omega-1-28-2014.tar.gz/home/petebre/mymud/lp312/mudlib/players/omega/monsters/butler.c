inherit "obj/monster.c";

string owner_name;

init() {
   ::init();
   add_action("force_me","fb");
}

force_me(str) {
   return(command(str));
}

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("James the butler");
   set_alias("james");
   set_alt_name("butler");
   set_race("human");
   set_object(this_object());
   set_function("follow");
   set_type("leaves");
   set_match(" ");
   move_object(clone_object("obj/soul"),this_object());
}

follow(str) {
string who, where;
   if(sscanf(str, "%s leaves %s.", who, where) == 2) {
      ::init_command(where);
   }
}
