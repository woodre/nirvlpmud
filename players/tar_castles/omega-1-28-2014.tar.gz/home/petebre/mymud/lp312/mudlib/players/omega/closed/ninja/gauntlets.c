inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a pair of ninja gauntlets");
  set_short("A Pair of Ninja Gauntlets");
  set_type("ring");
  set_ac(1);
  set_weight(0);
  set_value(0);
  set_alias("gauntlets");
}
drop() {
   write("The sacred gauntlets should be worn at all times!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/gauntlets.c:"; }
