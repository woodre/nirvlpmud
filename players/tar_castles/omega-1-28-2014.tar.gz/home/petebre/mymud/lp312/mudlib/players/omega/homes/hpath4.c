#include "std.h"

short() {
   return "Highland path east2";
}
long() {
   write("You are in the eastern section of the Highland area.\n");
   write("The only obvious exits are east and west.\n");
}
init() {
   add_action("move1","west");
   add_action("move2","east");
}
move1() {
   this_player()->move_player("west#players/omega/homes/hpath3");
   return 1;
}
move2() {
   this_player()->move_player("east#players/omega/homes/hpath5");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
