#include "std.h"

THREE_EXIT("players/omega/entrance", "west",
/*
   "players/omega/pathB0", "north",
*/
   "players/omega/pathA1", "south",
   "players/omega/ocity/gtower0","east",
   "A dirt crossroads",
   "You are at a crossroads.\n" +
   "The CITY OF OMEGA lies to the east.\n",
   1)
