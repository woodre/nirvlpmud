#include "std.h"

THREE_EXIT("players/omega/oforest/forestC4", "north",
   "players/omega/oforest/forestD5", "east",
   "players/omega/oforest/forestD3", "west",
   "Forest",
   "You are in a forest.\n",1)
