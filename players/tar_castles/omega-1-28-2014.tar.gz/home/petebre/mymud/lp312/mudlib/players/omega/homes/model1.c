short() { return "Model house"; }

long() {
   write("You are in one of Highland Homes model houses.\n");
   write("It is an elegant one room house with many windows\n");
   write("to allow plenty of light.  There is currently no\n");
   write("furniture in the house.\n");
   write("The only obvious exit is out.\n");
}

init() {
   add_action("leave_house","out");
}

leave_house() {
   this_player()->move_player("the house#players/omega/homes/hpath1");
   return 1;
}

reset(arg) {
   if(!present("brochure")) {
      object paper;
      paper = clone_object("players/omega/obj/brochure");
      transfer(paper, this_object());
   }
   if(arg) return;
   set_light(1);
}
