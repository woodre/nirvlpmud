#include "std.h"

THREE_EXIT("players/omega/oforest/forestA4", "north",
   "players/omega/oforest/forestB5", "east",
   "players/omega/oforest/forestB3", "west",
   "Forest",
   "You are in a forest.\n",1)
