/*
#include "homes.h"
*/

string external_name, external_alias, external_alt_name;
string external_short_desc; /* an internal one is not needed */
string internal_long_desc, external_long_desc;
string owners_name;
int door_locked, door_open, planted;

get() {
   if(this_player()->query_real_name()==owners_name) return 1;
   write("You try to pick up the house but it refuses to budge!\n");
}

query_weight() { return 0; }

query_value() { return 0; }

id(str) {
   if(!inside_object(this_player())) {
      return str == external_name || str == external_alias ||
         str == external_alt_name;
   }
}

short() {
   return external_short_desc;
}

long(str) {
   if(inside_object(this_player())) {
      write(internal_long_desc);
      write("   The only obvious exit is out.\n");
   } else {
      write(external_long_desc);
   }
   if(door_open) {
      write("The door is open.\n");
   } else {
      write("The door is closed.\n");
   }
}

init() {
   add_action("change_owner","owner");
   add_action("change_owner","chown");
   add_action("close_door","close");
   add_action("open_door","open");
   add_action("lock_door","lock");
   add_action("unlock_door","unlock");
   if(inside_object(this_player())) {
      add_action("leave_house","out");
   } else {
      add_action("enter_house","enter");
   }
/*
   add_action("redecorate","redecorate");
*/
   add_action("give_check","give");
}

reset(arg) {
   if(arg) return 0;
      owners_name = "omega";
      external_name = "a portable house";
      external_alias = "house";
      external_alt_name = "portable house";
      external_short_desc = "A portable house (Omega Corp. (c) )";
      internal_long_desc = "You are in a portable house.\n"+
                           "An important looking sign on the wall.\n"+
                           "There is a lockable door here which leads out.\n";
      external_long_desc =
         "You see a bluish-grey house constructed of some strange material.\n"+
         "There is a door in it's side.\n";
}

change_owner(str) {
   if(!str) {
      write("FORMAT:  'chown <name>'\n");
      return 1;
   }
   if(!inside_object()) {
      write("You can only change owners from within the portable house.\n");
      return 1;
   }
   if(this_player()->query_real_name()!=owners_name) return 0;
   if(!find_player(str)) {
      write(capitalize(str)+" is not on the game.\n");
      return 1;
   }
   owners_name = lower_case(str);
   write("The owner of the portable house is now: "+capitalize(owners_name)+".\n");
   tell_object(find_player(owners_name),"You are now the proud owner of a portable house! (c) Omega Corp.\n");
   return 1;
}

enter_house(str) {
   if(environment()!=environment(this_player())) return 0;
   if(!str) {
      write("enter what?\n");
      return 1;
   }
   if(id(str)) {
      if(!door_open) {
         write("You bump into the closed door.  BONK!\n");
         say(this_player()->query_name()+
             " bumps into the closed door of the portable house.  BONK!\n");
         tell_room(this_object(),"You hear someone bump into the door from the outside.\n");
         return 1;
      }
      say(this_player()->query_name()+" enters the portable house.\n");
      move_object(this_player(),this_object());
      say(this_player()->query_name()+" arrives looking rather confused.\n");
      this_player()->look();
      return 1;
   }
   return 0;
}

leave_house() {
   if(!door_open) {
      write("You bump into the closed door.  BONK!\n");
      say(this_player()->query_name()+" bumps into the closed door of the portable house.  BONK!\n");
      tell_room(environment(),"You hear someone bump into the door from inside the portable house.\n");
      return 1;
   }
   write("You leave the portable house.\n");
   say(this_player()->query_name()+" leaves out.\n");
   move_object(this_player(),environment());
   say(this_player()->query_name()+" arrives from out of the portable house.\n");
   return 1;
}

open_door(str) {
   if(str!="door") return 0;
   if(door_locked) {
      write("You jiggle the door knob but notice that it is locked.\n");
      say(this_player()->query_name()+" tries to open the locked door of the portable house.\n");
      if(inside_object(this_player())) {
         tell_room(environment(),"You hear the doorknob of the portable house jiggle.\n");
      } else {
         tell_room(this_object(),"You hear someone jiggling the door knob from the outside.\n");
      }
      return 1;
   }
   if(door_open) {
      write("The door is already open.\n");
      return 1;
   } else {
      write("You open the door.\n");
      say(this_player()->query_name()+" opens the door of the portable house.\n");
      if(inside_object()) {
         tell_room(environment(),"The door of the portable house opens.\n");
      } else {
         tell_room(this_object(),"The door opens.\n");
      }
      door_open = 1;
      return 1;
   }
}

close_door(str) {
   if(str!="door") return 0;
   if(door_open) {
      write("You close the door.\n");
      say(this_player()->query_name()+" closes the door of the portable house.\n");
      if(inside_object()) {
         tell_room(environment(),"The door of the portable house closes.\n");
      } else {
         tell_room(this_object(),"The door closes.\n");
      }
      door_open = 0;
      return 1;
   } else {
      write("The door is already closed.\n");
      return 1;
   }
}

lock_door(str) {
   if(str!="door") return 0;
   if(inside_object(this_player())) {
      if(door_open) {
         write("The door needs to be closed first.\n");
         return 1;
      }
      if(door_locked) {
         write("The door is already locked.\n");
         return 1;
      } else {
         write("You lock the door.  CLICK.\n");
         say(this_player()->query_name()+" locks the door.  CLICK.\n");
         tell_room(environment(),"Someone locks the door from inside the portable house.  CLICK.\n");
         door_locked = 1;
         return 1;
      }
   } else {
      write("You can't lock it from the outside.\n");
      return 1;
   }
}

unlock_door(str) {
   if(str!="door") return 0;
   if(inside_object(this_player())) {
      if(door_locked) {
         write("You unlock the door.  CLICK.\n");
         say(this_player()->query_name()+" unlocks the door.  CLICK.\n");
         tell_room(environment(),"Someone unlocks the door from inside the portable house.  CLICK.\n");
         door_locked = 0;
         return 1;
      } else {
         write("The door is already unlocked.\n");
         return 1;
      }
   } else {
      write("You can't unlock it from the outside.\n");
      return 1;
   }
}

/*
redecorate(str) {
   if(!str) {
      write("Redecorate which?  (interior or exterior)\n");
      return 1;
   }
   if(str == "interior") {
      input_to(get_new_interior_long_desc);
      write("Enter the new description for the inside of your house.\n");
      write("]");
      return 1;
   }
   if(str == "exterior") {
      return 1;
   }
   return 0;
}
*/

give_check(str) {
string test;
   sscanf(str,"%s to",test);
   if(id(test)) {
      write("You can't give the house to anyone.\n");
      return 1;
   }
}

/* new function */
inside_object(ob) {
   if(!ob) ob = this_player();
   if(environment(this_player()) == this_object()) return 1;
   return 0;
}
