#include "std.h"

ONE_EXIT("players/omega/oforest/forestB2", "south",
   "Forest",
   "You are in a forest.\n" +
   "The forest becomes impassable here.\n",
   1)
