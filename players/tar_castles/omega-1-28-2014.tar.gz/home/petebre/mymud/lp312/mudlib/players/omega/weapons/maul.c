inherit "obj/weapon.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
   set_name("a maul");
  set_class(13);
  set_weight(5);
  set_value(300);
  set_alias("maul");
}
