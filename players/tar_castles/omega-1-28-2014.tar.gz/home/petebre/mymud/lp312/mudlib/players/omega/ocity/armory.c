#include "std.h"

#undef EXTRA_INIT
#define EXTRA_INIT\
    add_action("buy"); add_verb("buy");\
    add_action("list"); add_verb("list");

ONE_EXIT("players/omega/ocity/cpathA2","north",
         "City of Omega: Ariel's Armory",
          "You are in ARIEL'S ARMORY.  You can buy armor here.\n"+
/*
         "A posted sign reads: 'Sorry, closed for repairs.'\n", 1)
*/
         "Commands are: 'buy <item>', 'list',\n", 1)

buy(item) {
    if (!item)
        return 0;
    call_other("players/omega/ocity/armorystore", "fill", 0);
    call_other("players/omega/ocity/armorystore", "buy", item);
    return 1;
}

list(obj) {
    call_other("players/omega/ocity/armorystore", "fill", 0);
    call_other("players/omega/ocity/armorystore", "inventory", obj);
    return 1;
}

find_item_in_player(i)
{
    object ob;

    ob = first_inventory(this_player());
    while(ob) {
        if (call_other(ob, "id", i))
            return ob;
        ob = next_inventory(ob);
    }
    return 0;
}
