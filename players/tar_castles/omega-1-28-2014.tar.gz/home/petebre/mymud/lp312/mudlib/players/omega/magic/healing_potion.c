inherit "players/omega/magic/oheal.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("potion of healing");
  set_alias("potion");
  set_short("Potion of healing");
  set_long("It will heal 25 hit points if you 'drink' it.\n");
  set_weight(0);
  set_value(750);
  set_verb("drink");
  set_amount(25);
  set_self("You feel the strong healing effects of the potion.  Oh yeah...");
  set_others("drinks a potion and looks much healthier.");
}
