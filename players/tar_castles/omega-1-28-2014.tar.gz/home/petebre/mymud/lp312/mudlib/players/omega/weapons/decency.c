inherit "obj/weapon.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a spare weapon of decency");
  set_class(3);
  set_weight(1);
  set_value(10);
  set_alt_name("weapon");
  set_alias("decency");
}

init() {
  ::init();
  add_action("change_name","wname");
}

change_name(str) {
  set_name(str);
  return 1;
}
