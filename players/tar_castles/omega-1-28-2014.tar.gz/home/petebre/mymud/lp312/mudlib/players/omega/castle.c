#define NAME "Omega"
#define DEST "room/sea"
#define LOCKOUTLEV 21

id(str) {
   return str == "kingdom";
}

long() {
    write(
         "\n           ******* ****** ****** ******\n" +
           "           *                          *\n" +
           "           *     KINGDOM OF OMEGA     *\n" +
           "           *                          *\n" +
           "           ******       **       ******\n" +
           "                *      *  *      *\n" +
           "                *      *  *      *\n" +
           "                ******************\n" +
           "Many dangers and adventures await you there ...\n" +
           "(please do not feed the animals - management)\n" +
           "Report any bugs by mail to Omega.\n" +
           "To enter the kingdom, go east.\n");
}

short() {
   return
           "The Kingdom of Omega lies on a shore to the east";
/*
           "Kingdom of " + NAME + " (east)";
*/
}

init() {
    add_action("move1"); add_verb("east");
    add_action("move1"); add_verb("e");
}

security() {
    string pname;
    pname = call_other(this_player(), "query_name");
   if ((pname == "Black list")
      || pname == "D" || pname == "H" || pname == "a" || 
      pname == "b"
   )
   {
   write ("You bounce off an invisible force field!\n");
   write ("A voice says: You are banished from the Kingdom of Omega!!\n");
   say(capitalize(pname) +
      " tries to go east but is stopped in his tracks!\n"+
   "A voice says:  " + this_player()->query_name()  + " has been banished " +
   "from the Kingdom of Omega.\n");
   return 0;
   }
    return 1;
}

move1() {
   int plevel;
   plevel = call_other(this_player(), "query_level");

   if(!security()) return 1;

    if( plevel < LOCKOUTLEV )
   {
   say(this_player()->query_name() + " tries to go into the kingdom but\n");
   say("bounces off an invisible force field!  BOING!\n");
   write("You bounce off an invisible force field!  BOING!\n");
   write("\n");
   write("A mystical voice from nowhere speaks:\n");
   write("The kingdom of Omega is currently closed for upgrading\n");
   write("and improvement.  It will reopen for general admittance\n");
   write("after the renovations are complete (approx. April, '94).\n");
   write("We apologive for any inconveniences this may cause.\n");
   write("Thank you for visiting the kingdom and come again.\n");
   write("*** Omega Corp. ***\n");
   return 1;
   }

   if (plevel > 19 && plevel < 19)
   {
      write ("Lower levels wizards cannot enter this way.\n");
    return 1;
    }
      call_other(this_player(), "move_player",
         "east#players/omega/entrance.c");
      return 1;
}

reset(arg) {
object temp;
    if (arg)
	return;
/*
    if(!find_object("players/omega/oswamp/sdragon_cave")) {
        move_object(this_object(),"players/omega/oswamp/sdragon_cave");
    }
    if(!present("spy", find_object("players/omega/oswamp/sdragon_cave"))) {
       object spy;
       spy = clone_object("players/omega/obj/spy");
       move_object(spy, "players/omega/oswamp/sdragon_cave");
    }
    if(!present("lottery machine", find_object("room/church"))) {
        temp = clone_object("players/omega/homes/lmachine");
        move_object(temp, "room/church");
    }
    if(!present("housing sign", find_object("room/church"))) {
       temp = clone_object("players/omega/homes/house_sign");
       move_object(temp, "room/church");
    }
    if(!present("housing sign2", find_object("room/church"))) {
       temp = clone_object("players/omega/homes/house_sign2");
       move_object(temp, "room/church");
    }
*/
    move_object(this_object(), DEST);
}
is_castle() { return 1;}
