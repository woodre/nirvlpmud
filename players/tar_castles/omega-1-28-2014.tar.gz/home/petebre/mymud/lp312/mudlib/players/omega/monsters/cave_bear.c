inherit "obj/monster.c";

object owner;
string owner_name;

reset(arg) {
   if(!arg) {
   ::reset(arg);
   set_name("cave bear");
   set_alias("bear");
   set_race("animal");
   set_wc(13);
   set_al(60);
   set_short("Grouchy cave bear");
   set_ac(7);
   set_level(9);
   set_long(
   "You have awakened a very grouchy cave bear.\n");
   set_aggressive(0);
   owner_name = "none";
   start_follow("omega");
   }
}

start_follow(o) {
   if(!o) return 0;
    if(!set_owner(o)) return 0;
   set_object(this_object());
   set_function("follow");
   set_type("leaves");
   set_match(" ");
   return 1;
}

follow(str) {
string who, where;
object dest;
   if(sscanf(str, "%s leaves %s.\n", who, where) == 2) {
      if(lower_case(who) == owner_name) {
         say("A cave bear leaves, chasing after "+capitalize(owner_name)+".\n");
         dest = find_player(owner_name);
         if(!dest) destruct(this_object());
         move_object(this_object(),environment(dest));
         say("A cave bear arrives, following "+capitalize(owner_name)+".\n");
      }
   }
}

init() {
  add_action("bear_commands","bear");
  add_action("bear_talk","bearsay");
}

bear_commands(str) {
string who, what;
  if(!str) return;
  if(this_player()->query_real_name() != capitalize(owner_name)) return;
  return(command(str));
}

set_owner(name) {
   if(!name) return 0;
   owner = find_player(name);
   if(!owner) return 0;
   owner_name = lower_case(owner->query_real_name());
   return 1;
}
