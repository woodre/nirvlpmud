int fuel, distance, damage;
string target_name;
object target_obj, target_room;

reset(arg){
  if(arg) return;
  target_name = "Jasper";
  fuel = 5;
  damage = 0;
  distance = 1;
  set_heart_beat(1);
}
id(str){
  return str=="missile";
}
short(){
  return "A cruise missile (targeting "+target_name+")";
}
long(){
  write("You see a self-guiding cruise missile.  It is flying high above\n");
  write("in the sky at at supersonic velocity.  The missile will continue\n");
  write("to track its target until the target is hit, or the missile runs\n");
  write("out of fuel.  This missile is targeted for "+target_name+".\n");
}
heart_beat(){
  target_obj=find_player(lower_case(target_name));
  if(!target_obj){
    /* tell owner of missile that target is missing */
    say("Can't find "+target_name+".\n");
    return 1;
  }
  if(present(target_obj,environment())){
    if(distance==1){
      say(short()+" arcs from out of the sky toward the ground!\n");
      say("Better run for it, before it impacts!\n");
      distance=0;
      return 1;
    }
    if(distance==0){
      say(short()+" impacts the ground and explodes!  KA-BOOM!!!\n"+
          "Everyone in the room is hit by the blast of the explosion!\n");
      hit_room(damage);
      set_heart_beat(0);
      destruct(this_object());
    }
  }
  if(distance==1){
    say(short()+" leaves to chase its target, high in the sky.\n");
  }
  if(distance==0){
    say(short()+" leaves to chase its target, hugging the ground.\n");
  }
  move_object(this_object(),environment(target_obj));
  if(fuel<=0){
    say(short()+" runs out of fuel and crashes harmlessly into the ground.\n");
    destruct(this_object());
  }
  fuel -= 1;
  if(distance==1){
    say(short()+" arrives, high up in the sky.\n");
  }
  if(distance==0){
    say(short()+" arrives, close to the ground.\n");
  }
  return 1;
}
set_target(str){
  target_name=str;
}
hit_room(dam){
object current;
  current=first_inventory(environment());
  while(current){
    if(living(current)){
      if(current==target_obj){
        current->hit_player(dam);
      } else {
        current->hit_player(dam/2);
      }
    }
    current=next_inventory(current);
  }
  return 1;
}
