#include "std.h"

FOUR_EXIT("players/omega/ocity/gtower0","west",
   "players/omega/ocity/cpathA1","east",
   "players/omega/ocity/opub","south",
   "players/omega/ocity/shop1","north",
   "City walkway",
   "You are on a wooden walkway in the City of Omega.\n" +
   "To the west you can see a gate tower, and to the east lies a fountain.\n" +
   "To the north is a shop, and to the south is a pub.\n",
   1)
