inherit "obj/weapon.c";

object target, next_target;
int index, num_targets;

reset(arg){
  if(arg) return;
  ::reset(arg);
  set_name("blade");
  set_short("Blade of Death");
  set_class(1);
  set_weight(0);
  set_hit_func(this_object());
}
weapon_hit(){
  index=0;
  write("Start\n");
  target=first_inventory(environment(this_player()));
  while(target){
    next_target=next_inventory(target);
    if(living(target) && (target->query_attack() == this_player()) ){
      index += 1;
      write("Targeted: "+index+"\n");
      target->hit_player(500);
    }
    target = next_target;
  }
  return 20;
}
