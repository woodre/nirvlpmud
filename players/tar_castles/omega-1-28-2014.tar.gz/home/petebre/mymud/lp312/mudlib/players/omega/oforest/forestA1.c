#include "std.h"
#include "living.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object pixie;

extra_reset() {
/*
   if(!present("pixie")) {
      pixie = clone_object("obj/monster");
      move_object(pixie, this_object());
      pixie->set_name("forest pixie");
      pixie->set_alias("pixie");
      pixie->set_short("A forest pixie");
      pixie->set_long(
"You see a miniature humanoid, about 3 feet tall and dressed in\n"+
"brown garments.  It has pointy ears and a pointy nose and a\n"+
"mischievious look about it.\n"
     );
     pixie->set_wc(5);
      pixie->set_ac(5);
      pixie->set_level(7);
      pixie->set_chat_chance(50);
      pixie->load_chat(
"Pixie says:  Give me 100 coins and I will tell you a secret.\n"
      );
      pixie->load_chat(
"Pixie says:  I know a secret!\n");
      pixie->set_object(this_object());
      pixie->set_function("tell_secret");
      pixie->set_type("gives");
      pixie->set_match("100 coins to Pixie.");
      pixie->set_type("gives");
      pixie->set_match("100 coins to Forest pixie.");
   }
*/
}

tell_secret(str) {
   object giver;
   if(pixie && living(pixie)) {
      string who, rest;
      sscanf(str, "%s %s\n", who, rest);
      giver = present(lower_case(who),environment(this_player()));
      say("Pixie says:  Well "+who+", here's the secret.\n");
      say("Pixie says:  There's a sucker born every minute!\n");
      call_out("dest_money",5,who);
   }
   return 1;
}

dest_money(who) {
   pixie->add_money(-100);
   say("The forest pixie throws the gold in the air and it dissapears!\n");
   say("The forest pixie points and laughs at "+who+"!\n");
   call_out("tell_secret2",5);
   return 1;
}

tell_secret2() {
   say("Pixie says:  But seriously, the secret is ...\n");
   say("Pixie says:  The carrots around here are extra good for you.\n");
   return 1;
}

TWO_EXIT("players/omega/oforest/forestA0", "west",
   "players/omega/oforest/forestB1", "south",
   "Forest",
   "You are in a forest.\n"+
   "The trees become impassable to the north.\n"+
   "A fast flowing river impedes any passage to the east.\n",
   1)
