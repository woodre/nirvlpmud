inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a ninja amulet");
  set_short("A Ninja Amulet");
  set_type("amulet");
  set_ac(1);
  set_weight(0);
  set_value(0);
  set_alias("amulet");
}
drop() {
   write("The sacred amulet should be worn at all times!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/amulet.c:"; }
