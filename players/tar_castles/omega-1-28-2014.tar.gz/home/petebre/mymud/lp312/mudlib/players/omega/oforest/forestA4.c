#include "std.h"

THREE_EXIT("players/omega/oforest/forestB4", "south",
   "players/omega/oforest/forestA5", "east",
   "players/omega/oforest/forestA3", "west",
   "Forest",
   "You are in a forest.\n",1)
