#include "path"
#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

object black_dragon;

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

ONE_EXIT(PATH+"swampE1", "out",
   "Cave",
   "You are in a very large cave.\n" +
   "The stench of rotting flesh invades your nostrils.\n" +
   "You feel very uncomfortable here.\n",
   0)

extra_reset() {
/*
   if (!black_dragon || !living(black_dragon)) {
      black_dragon = clone_object("obj/monster");
      black_dragon->set_name("black dragon");
      black_dragon->set_race("dragon");
      black_dragon->set_long(
     "You see before you a very large, black dragon.\n"+
     "The scaly skin of its body looks as if it could deflect fireballs\n"+
     "without even denting.  When you look into its eyes, you sense its\n"+
     "awesome power and strength.  This dragon looks as if it has been\n"+
     "here for centuries, and by the look of things, it will be here for\n"+
     "centuries more.  It's mouth drips with a drool that scars the stone\n"+
     "below with a hiss.  Go on, make his day ...\n");
      black_dragon->set_ac(25);
      black_dragon->set_wc(40);
      black_dragon->set_level(60);
      black_dragon->set_hp(2000);
      black_dragon->set_ep(35000000);
      black_dragon->set_al(-1000);
      black_dragon->set_whimpy(1);

      black_dragon->set_spell_mess1(
         "Black dragon spits a stream of Hydrochloric acid!!");
      black_dragon->set_spell_mess2(
         "Black Dragon spits a stream of Hydrochloric acid at you!!");
      black_dragon->set_chance(25);
      black_dragon->set_spell_dam(60);

      black_dragon->set_chat_chance(25);
      black_dragon->load_chat(
         "Dragon says: I am too powerful for you, tiny mortal!\n");
      black_dragon->load_chat(
         "Dragon says: You don't have a chance against me!\n");
      black_dragon->load_chat(
         "Dragon laughs at you!\n");
      black_dragon->load_chat(
         "Dragon says: Go on home, wimp!  I hear your mother calling!\n");

      black_dragon->set_a_chat_chance(25);
      black_dragon->load_a_chat(
         "Dragon bellows: I will eat you for breakfast!\n");
      black_dragon->load_a_chat(
         "Dragon shouts: Stay still, puny mortal!\n");
      black_dragon->load_a_chat(
         "Dragon hisses: You will die!\n");
      black_dragon->load_a_chat(
         "Dragon squeals: I love tenderized meat!\n");
      transfer(black_dragon, this_object());
   }
*/
}
