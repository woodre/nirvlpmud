#include "std.h"

#undef EXTRA_INIT
#define EXTRA_INIT extra_init();
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object sword;

TWO_EXIT("players/omega/ocity/cpathA0","east",
   "players/omega/pathA0","west",
   "West guard tower",
   "You are in a tunnel underneath the west guard tower.\n"+
   "The open gate to the west will take you out of the city.\n"+
   "The city's walkway lies to the east.\n"+
   "There is a wooden door in the tunnel.\n",
   1)

extra_init() {
   add_action ("open_door"); add_verb ("open");
}

open_door(str) {
   if (str != "door") return 0;
   write("The door is locked from the inside and there's no keyhole.\n");
   say(this_player()->query_name() + " tries to open the door.\n");
   return 1;
}

extra_reset() {
   if (!present("rusty sword")) {
   sword = clone_object("obj/weapon");
   sword->set_name("rusty sword");
   sword->set_class(8);
   sword->set_value(140);
   sword->set_weight(2);
   sword->set_alias("sword");
   sword->set_short("rusty sword");
   sword->set_long("The sword is a bit rusty, but is still combat worthy.\n");
   move_object(sword, this_object());
   }
}
