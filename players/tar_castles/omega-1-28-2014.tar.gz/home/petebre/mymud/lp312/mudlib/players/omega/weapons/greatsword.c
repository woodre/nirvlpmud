inherit "obj/weapon.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
   set_name("a greatsword");
  set_class(17);
  set_weight(7);
  set_value(640);
  set_alt_name("greatsword");
  set_alias("sword");
}
