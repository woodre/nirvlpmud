inherit "obj/monster.c";

#define DELAY 0

short() { return "A war veteran"; }

long(str) {
   write("You see an aged war veteran sitting at the bar.\n");
   write("He looks like he wants to tell you something.\n");
   write("Why not ask him to tell you a rumor or a story.\n");
}

id(str) {
   return str == name || str == alias || str == "veteran";
}

reset(arg) {
    if (arg)
	return;
    cap_name = "War veteran";
    name = "war veteran";
    alias = "vet";
    level = 10;
    experience = 39000;
    max_hp = 150;
    hit_point = 150;
    weapon_class = 14;
    is_npc = 1;
    alignment = 100;
    enable_commands();
}

tell_rumor() {
int rum;
   say("War veteran says:  Here's something I've heard...\n");
   rum = random(2);
   if(rum == 0) {
   say("The lizard men in the swamp are searching for a legendary axe.\n");
   say("It is known as the 'Battle Axe of Power!'\n");
   say("Maybe you can 'search' for it too.'\n");
   return 1;
   }
   if(rum == 1) {
   say("The 'weeping sword' is very effective against the lizard men.\n");
   say("I believe it is now under the care of the Forest Guardian.\n");
   return 1;
   }
   return 1; 
}

tell_story() {
int sto;
   say("War veteran says:  So it's a story you be wanting eh?  Okay I got one.\n");
   sto = random(1);
   if(sto == 0) {
      say("There was once a great and powerful magician named Halifax!\n");
      say("Stories say that he was killed by a small purple dragon.\n");
      say("The dragon stole some of Halifax's treasure, including the\n");
      say("wondrous gems of Halifax.  It was rumored that Halifax could\n");
      say("unleash the power of the gems just by crushing them in his hands.\n");
   }
   return 1;
}    

catch_tell(str) {
    string who, what,rest;
    if (sscanf(str, "%s tells you:%srumor%s", who , what, rest) == 3 ||
	sscanf(str, "%s says:%srumor%s", who , what, rest) == 3) {
        call_out("tell_rumor",DELAY);
    } else if (sscanf(str, "%s tells you:%sstor%s", who, what, rest) == 3 ||
        sscanf(str, "%s says:%sstor%s",who, what, rest) == 3) {
        call_out("tell_story",DELAY);
    }
}
