#include "std.h"

THREE_EXIT("players/omega/pathA2", "north",
   "players/omega/pathA4", "south",
   "players/omega/oswamp/swampB2", "west",
   "Swamp entrance",
   "You are on a dirt path.\n" +
   "To the west you can see a murky swamp.\n" +
   "Deep guttural sounds eminate from the smelly bog.\n",
   1)
