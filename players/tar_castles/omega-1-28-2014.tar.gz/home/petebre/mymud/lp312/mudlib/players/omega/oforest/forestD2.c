#include "std.h"

TWO_EXIT("players/omega/oforest/forestC2", "north",
   "players/omega/oforest/forestD3", "east",
   "Forest\n",
   "You are in a forest.\n",
   1)
