int ammo;

reset(arg){
  if(arg) return;
  ammo = 150;
}

id(str){
  return str=="ammo" || str=="belt" || str=="m60 ammo" || str=="m60 belt";
}
short(){
  return("A belt of M60 ammo ("+ammo+" rounds)");
}
long(){
  write("This is an ammo belt for an M60 heavy machine gun.\n");
  write("It has "+ammo+" rounds in it.\n");
}
query_weight(){
  return 3;
}
query_value(){
  return 300;
}
get(){
  return 1;
}
query_ammo(){
  return ammo;
}
set_ammo(d){
  if(d<0) d=0;
  ammo = d;
}
