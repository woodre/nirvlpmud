id(str) {
  return str == "sign" || str == "housing sign2";
}
short() {
  return "HOUSING SIGN (posted May 13th)";
}
long() {
  cat("/players/omega/homes/HOUSE_INFO2");
}
init() {
  add_action("read_sign","read");
}
read_sign(str) {
  if(!id(str)) return 0;
  long();
  return 1;
}
reset(arg) {
  if(arg) return;
}
