int ammo;

reset(arg){
  if(arg) return;
  ammo = 36;
}

id(str){
  return str=="ammo" || str=="clip" || str=="m16 ammo" || str=="m16 clip";
}
short(){
  return("A clip of M16 ammo ("+ammo+" rounds)");
}
long(){
  write("This is an ammo clip for an M16 Assault Rifle.\n");
  write("It has "+ammo+" rounds in it.\n");
}
query_weight(){
  return 1;
}
query_value(){
  return 100;
}
get(){
  return 1;
}
query_ammo(){
  return ammo;
}
set_ammo(d){
  if(d<0) d=0;
  ammo = d;
}
