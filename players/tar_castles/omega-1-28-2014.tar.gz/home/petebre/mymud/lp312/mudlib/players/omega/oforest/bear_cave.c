#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object bear;
object money;
status tame_bear;

ONE_EXIT("players/omega/oforest/forestD1", "out",
   "Small cave",
   "You are in a small cave.\n" +
   "The remains of small animals are scattered about.\n" +
   "The smell of rotted fruit and wet animal permeate the cave.\n",1)

extra_reset() {
   if (!present("cave bear")) {
      bear = clone_object("players/omega/monsters/cave_bear");
      bear->set_object(this_object());
      bear->set_function("give_honey");
      bear->set_type("gives");
      bear->set_match("honey to Bear.");
      bear->set_match("honey to Cave bear.");
      tame_bear = 0;
      transfer(bear,this_object());

      money = clone_object("obj/money");
      money->set_money(random(50) + 99);
      move_object(money,bear);
   }
}

give_honey(str) {
object giver;
string who, rest;
   if(present(bear)) {
      sscanf(str,"%s %s", who, rest);
      giver = present(lower_case(who),environment(this_player()));
      say("Grouchy cave bear smiles happily.\n");
      call_out("eat_honey",3,giver);
   }
}

eat_honey(giver) {
string giver_name;
   if(!present(bear)) return 1;
   call_other(bear,"init_command","eat honey");
   if(!tame_bear) {
      bear->set_short("Tame cave bear");
      bear->set_long(
         "You see a tame cave bear.\n"+
         "It's lips are covered with honey.\n");
      if(present(giver,this_object())) {
         tell_object(giver,"You have tamed the grouchy bear!\n");
         tell_object(giver,"You gain some experience!\n");
         giver->add_exp(500);
      }
   }
   giver_name = giver->query_real_name();
   say("Tame cave bear licks "+giver_name+".\n");
   bear->start_follow(giver_name);
   return 1;
}
