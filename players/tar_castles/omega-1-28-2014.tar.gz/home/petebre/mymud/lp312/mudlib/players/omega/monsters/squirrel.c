inherit "obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(!arg) {
   set_name("a bouncy squirrel");
   set_alias("squirrel");
   set_short("A bouncy squirrel");
   set_long(
   "You see a cute little squirrel.  He blinks at you.\n");
   set_ac(4);
   set_wc(2);
   set_level(1);
   set_race("animal");
   set_chat_chance(10);
   load_chat("A squirrel nibbles on a nut.\n");
   load_chat("A squirrel bounces up and down.\n");
   load_chat("A squirrel scurries around.\n");
   load_chat("A squirrel looks around carefully.\n");
   }
}
