#include "path"
#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

object adder, fang;
object corpse;
status found_corpse;

TWO_EXIT(PATH+"swampB0", "south",
   PATH+"swampA1", "east",
   "Swamp",
   "You are in a swamp.\n" +
   "This appears to be the lair of a snake.\n",
   0)

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  if(present("swamp adder")) {
     if(adder->query_attack()) {
        write("Not during combat!\n");
	return 1;
     }	
     if(random(100) < 50) {
        say(this_player()->query_name()+" disturbed the swamp adder!\n");
        write("You disturbed the swamp adder!\n");
        write("The swamp adder attacks you!\n");
	adder->set_aggressive(1);
	transfer(this_player(), this_object());
	return 1;
     }
  }
  if((random(101) < 100) && !found_corpse) {
     write("You found something!\n");
     say(this_player()->query_name()+" searches the area.\n");
     write("A corpse from under the bog has risen to the surface.\n");
     say("A corpse rises to the surface.\n");
     make_corpse();
     found_corpse = 1;
     return 1;
  }
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}
make_corpse() {
int i;
string name;
   corpse = clone_object("obj/corpse");
   i = random(5);
   if (i == 0) name = "william";
   else if (i == 1) name = "richard";
   else if (i == 2) name = "sylvia";
   else if (i == 3) name = "bernard";
   else if (i == 4) name = "cassandra";
   corpse->set_name(name);
   transfer(corpse, this_object());
   make_corpse_treasure();
}
make_corpse_treasure() {
int j;
object item;
   j = random(5);
   if (j == 0) {
      item = clone_object("obj/armor");
      item->set_name("a silver ring");
      item->set_short("A silver ring");
      item->set_long("You see an ornamental ring.\n");
      item->set_ac(0);
      item->set_type("ring");
      item->set_value(150);
      item->set_weight(1);
   } else if (j == 1) {
      item = clone_object("obj/money");
      item->set_money(random(300)+50);
   } else if (j == 2) {
      item = clone_object("players/omega/weapons/scimitar");
   } else if (j == 3) {
      item = clone_object("players/omega/armors/chain_mail");
   } else if (j == 4) {
      item = clone_object("players/omega/magic/identify_scroll");
   }
   move_object(item,corpse);
}      
extra_reset() {
   found_corpse = 0;
   if (!adder || !living(adder)) {
      found_corpse = 0;
      adder = clone_object("players/omega/monsters/swamp_adder");
      adder->set_a_chat_chance(25);
      adder->load_a_chat("Swamp adder hisses loudly!  HISSSSS!\n");
      adder->load_a_chat("Swamp adder wiggles madly!\n");
      transfer(adder, this_object());
   }
}
