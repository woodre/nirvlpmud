get(){
  return 1;
}
query_weight(){
  return 0;
}
query_value(){
  return 0;
}
id(str){
  return str=="orb" || str=="power orb of omega" || str=="orb of omega";
}
short(){
  return("Power Orb of Omega");
}
long(){
  write("???????????????  Power Orb of Omega  ???????????????\n");
  write("You see a glowing ball of energy which pulsates with\n");
  write("a strange bluish light.  Deep within lie the secrets\n");
  write("that few have been able to possess.  Sparks of magic\n");
  write("stray from the orb and dissipate violently near you.\n");
  write("In the globe's center floats the greek letter Omega!\n");
  write("????????????????????????????????????????????????????\n");
  if(this_player()->query_real_name() != "omega"){
  write("Better hope he doesn't catch you with it in your inventory...\n");
  }
}
reset(arg){
}
init(){
  if(environment()!=this_player()) return 1;
  add_action("create_money","cmoney");
  add_action("grant_gift","ogift");
  add_action("change_money","ogold");
  add_action("change_exp","oexp");
  add_action("heal_living","oheal");
  add_action("damage_living","oreduce");
  add_action("freeze_room","freeze_room");
  add_action("orb_help","orb_help");
}
freeze_room(str){  /* this drops a freeze object in the room */
object freeze;
  if(!str){
    write("usage:  freeze_room <on|off>\n");
    return 1;
  }
  if(str=="on"){
    freeze=clone_object("players/omega/closed/foo");
    move_object(freeze,environment(this_player()));
    say("You are suddenly frozen and can't do anything!\n");
    return 1;
  }
  if(str=="off"){
    freeze=present("nothing",environment(this_player()));
    if(!freeze){
      write("There is no freeze object in this room.\n");
      return 1;
    }
    say("You can move again.... Whew!\n");
    destruct(freeze);
    return 1;
  }
  write("usage:  freeze_room <on|off>\n");
  return 1;
}
damage_living(str){   /* this will reduce a living object to 0 hit points */
object target;        /* and reduce its spell points to 0 */
int amount;
  if(!str){ return 0; }
  target = find_living(str);
  if(!target){ return 0; }
  target->add_hit_point(-9999);
  target->add_spell_point( (-1)*target->query_spell_point());
  display_orb_message();
  tell_object(target,"You suddenly feel deathly weak.\n");
  return 1;
}
change_exp(str){   /* this wll change the experience value of a player */
object target;
string tname;
int amount;
  if(!str){ return 0; }
  if(!sscanf(str,"%s %d",tname,amount)){ return 0; }
  target = find_living(lower_case(tname));
  if(!target){ return 0; }
  target->add_exp(amount);
  return 1;
}
heal_living(str){   /* this will heal a living object anywhere */
object target;      /* and recharge its spell points */
  if(!str){ return 0; }
  target = find_living(str);
  if(!target){ return 0; }
  target->add_hit_point(999999);
  target->add_spell_point(999999);
  tell_object(target,"Omega has healed you.\n");
  write("You healed "+capitalize(str)+".\n");
  return 1;
}
grant_gift(str){   /* this clones an object directly onto a player */
object target, gift;
string tname, gname;
  if(!str){ return 0; }
  if(!sscanf(str,"%s %s",tname,gname)){ return 0; }
  target = find_living(lower_case(tname));
  if(!target){ return 0; }
  if(gname=="dblade"){
    gift = clone_object("players/omega/weapons/w.c");
    gift->set_sowner(capitalize(tname));
  }
  if(gname=="splate"){
    gift = clone_object("players/omega/armors/a.c");
    gift->set_aowner(capitalize(tname));
  }
  if(!gift){
    return 0;
  }
  move_object(gift, target);
  tell_object(target,"Omega has given you a present.\n");
  write("Ok.\n");
  return 1;
}
change_money(str){   /* this will change the amount of gold a player has */
object target;
string tname;
int amount;
  if(!str){ return 0; }
  if(!sscanf(str,"%s %d",tname,amount)){ return 0; }
  target = find_living(lower_case(tname));
  if(!target){ return 0; }
  target->add_money(amount);
  return 1;
}
create_money(str){
  object money;
  int amount;

  if( sscanf(str, "%d", amount) != 1 ){
    write("You must specify an integer amount\n");
    return 1;
  }
  display_orb_message();
  money = clone_object("players/omega/obj/omoney");
  money->set_amount(amount);
  transfer( money, environment(this_player()) );
  say("A pile of gold coins suddenly appears before you!\n");
  write("You created a pile of gold coins.\n");
  return 1;
}
display_orb_message(){
  write("You summon the power of the Orb!\n");
   say(capitalize(this_player()->query_name())+" casts a spell with the Orb of Omega!\n");
  return 1;
}
orb_help(){
  write("*== THE LEGENDARY POWER ORB OF OMEGA ==*\n");
  write("cmoney <amount>             :  creates a pile of money\n");
  write("ogift <target> <object>     :  gives a player a gift\n");
  write("                               (dblade,splate)\n");
  write("ogold <target> <amount>     :  change a player's money\n");
  write("oexp <target> <amount>      :  change a player's exp total\n");
  write("oheal <target>              :  restore a living objects points\n");
  write("oreduce <target>            :  reduce a living object to zero\n");
  write("freeze_room <on|off>        :  clone/destroy a freeze object\n");
  write("orb_help                    :  displays this help list\n");
  write("\n");
  return 1;
}
