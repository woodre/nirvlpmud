#include "std.h"

object corpse;
status found_corpse;

short() { return "Swamp"; }
long() {
   write("You are in a swamp.\n");
   write("A towering mountain range blocks your passage to the west and south.\n");   
   write("The only obvious exits are north and east.\n");
}
init() {
   add_action("search","search");
   add_action("move1","north");
   add_action("move2","east");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  if(present("lizard man")) {
      write("The Lizard man stops you from searching!\n");
      return 1;
  }	
  if((random(100) < 100) && !found_corpse) {
     write("You found something!\n");
     say(this_player()->query_name()+" searches the area.\n");
     write("A corpse from under the bog has risen to the surface.\n");
     say("A corpse rises to the surface.\n");
     make_corpse();
     found_corpse = 1;
     return 1;
  }
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}
make_corpse() {
int i;
string name;
   corpse = clone_object("obj/corpse");
   i = random(5);
   if (i == 0) name = "havarough";
   else if (i == 1) name = "leonardi";
   else if (i == 2) name = "manard";
   else if (i == 3) name = "nicoli";
   else if (i == 4) name = "ariole";
   corpse->set_name(name);
   transfer(corpse, this_object());
   make_corpse_treasure();
}
make_corpse_treasure() {
int j;
object item;
   j = 2;
   if (j == 0) {
      item = clone_object("players/omega/armors/plate_mail");
   } else if (j == 1) {
      item = clone_object("obj/money");
      item->set_money(random(30000)+20000);
   } else if (j == 2) {
      item = clone_object("players/omega/weapons/magic_axe");
   }
   move_object(item,corpse);
}      
move1() {
   if(stop_player(75)) return 1;
   this_player()->move_player("north#players/omega/oswamp/swampD0");
   return 1;
}
move2() {
   if(stop_player(75)) return 1;
   this_player()->move_player("east#players/omega/oswamp/swampE1");
   return 1;
}
stop_player(chance) {
   if(this_player()->query_ghost()) return 0;
   if(!present("lizard man")) return 0;
   if(random(100) < chance) {
      write("Lizard man leaps in front of you, blocking your escape!\n");
      return 1;
   }
   write("You manage to escape!\n");
   return 0;
}
reset(arg){
   if (!present("lizard man")) {
   int i;
   object lizard_man;
      while (i < (random(2) + 2)) {
         lizard_man = clone_object("players/omega/monsters/lizard_man");
	 lizard_man->set_a_chat_chance(30);
	 lizard_man->load_a_chat(
	    "Lizard man says: Where can it be?\n");
	 lizard_man->load_a_chat(
	    "Lizard man says: We'll kill you!\n");
	 lizard_man->load_a_chat("Lizard man says: You'll never find it!\n");
	 lizard_man->load_a_chat("Lizard man says: Don't let 'im get away!!\n");
	 move_object(lizard_man, this_object());
	 i += 1;
      }
   }
   found_corpse = 0;
   if(arg) return;
}
