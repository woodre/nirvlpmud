inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a ninja sash");
  set_short("A Ninja Sash");
  set_type("misc");
  set_ac(1);
  set_weight(0);
  set_value(0);
  set_alias("sash");
}
drop() {
   write("The sacred sash should be worn at all times!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/sash.c:"; }
