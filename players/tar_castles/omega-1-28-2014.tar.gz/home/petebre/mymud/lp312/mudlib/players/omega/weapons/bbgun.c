inherit "obj/weapon";

reset(arg) {
   if (!present(arg)) {
   ::reset(arg);
   set_name("pellet gun");
   set_alias("gun");
   set_short("B B gun");
   set_class(5);
   set_weight(6);
   set_value(1200);
   set_read("To my son Johnathon, for his 14 birthday -- Love Dad.\n");
   set_long(
   );
   }
}

extra_init() {
   add_action ("aim"); add_verb("aim");
   add_action ("shoot"); add_verb("shoot");
   add_action ("shoot"); add_verb("fire");
}

aim(str) {
   if (!str) return 0;
   if (!::id(str)) return 0;
   target
