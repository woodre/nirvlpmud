/* house.c
 *   This file is similar to wizards castle.c files in that is only the
 *   entrance to the players home.  It is placed in a room and allows
 *   a player to move to the actual rooms.  This object is player modifible
 *   so a player can change the long_desc and other variables.
 */

/* definitions */
#define FILENAME "players/omega/homes/o/"

/* global identifiers */
string owner_name;          /* owner's name */
string short_desc;          /* the house's short desc is modifiable */
string long_desc;           /* the long desc is modifiable */
int house_id;               /* this number corresponds with the house's array
                             * index in 'house' in high_office.c
                             */
id(str) {
  if(str == "house")
    return 1;
}
short() {
  return short_desc;
}
long() {
  write(long_desc);
}
reset(arg) {
  if(arg) return;
  house_id = -1;
  owner_name = "omega";
  short_desc = "House of "+owner_name;
  long_desc = "You see a house.\n";
  set_light(1);
}
restore_house(d) {
/* externally accesible function to allow the housing office to restore
 * the variables to this object
 */
  house_id = d;
  return restore_object( FILENAME + house_id );
}
save_house() {
/* externally accessible function to allow high_office.c to save this object
 */
  if ( house_id == -1 ) return 0;
  save_object( FILENAME + house_id );
  return 1;
}
set_owner(str) {
  owner_name = str;
  return 1;
}
