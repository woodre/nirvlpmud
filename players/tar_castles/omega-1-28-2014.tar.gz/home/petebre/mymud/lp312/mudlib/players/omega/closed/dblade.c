inherit "obj/weapon.c";

int damage;
object target;
reset(arg){
  if(arg) return;
  ::reset(arg);
  set_name("a sword");
  set_alias("sword");
  set_short("THE sword");
  set_long("You got it.  It's THE sword.\n");
  set_class(7);
  set_weight(1);
  set_value(0);
}

init(){
  ::init();
  add_action("death","kill");
}

death(str){
  if(!str)return;
  target = present(str,environment(this_player()));
  if(!target)return;
  damage = target->query_hp();
  if(!damage)return;
  write("The target had "+damage+" hit points.\n");
  target->hit_player(9999999999);
  return 1;
}
