#include "path"
#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

FOUR_EXIT("players/omega/pathA3", "east",
   PATH+"swampA2", "north",
   PATH+"swampC2", "south",
   PATH+"swampB1", "west",
   "Swamp",
   "A sign reads:  SWAMP OF DESPAIR!\n" +
   "You are in a murky swamp.\n" +
   "Many dangerous creatures inhabit the swamps.\n" +
   "You see a dirt path to the east.\n",
   0)
