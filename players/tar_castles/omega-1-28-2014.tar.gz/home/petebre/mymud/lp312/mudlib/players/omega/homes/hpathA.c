#include "std.h"

short() {
   return "Highland path west";
}
long() {
   write("You are on the west side of the Highland area.\n");
   write("The only obvious exits are east and west.\n");
}
init() {
   add_action("move2","east");
   add_action("move3","west");
}
move2() {
   this_player()->move_player("east#players/omega/homes/hpath2");
   return 1;
}
move3() {
   this_player()->move_player("west#players/omega/homes/hpathB");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
