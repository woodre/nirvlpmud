inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("a pair of ninja tabi");
  set_short("A Pair of Ninja Tabi");
  set_type("boots");
  set_ac(1);
  set_weight(0);
  set_value(0);
  set_alias("tabi");
}
drop() {
   write("The sacred tabi should be worn at all times!\n");
   return 1;
}
query_auto_load() { return "/players/omega/closed/ninja/tabi.c:"; }
