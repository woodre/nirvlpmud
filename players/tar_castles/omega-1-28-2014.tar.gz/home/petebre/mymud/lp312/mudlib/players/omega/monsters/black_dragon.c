inherit "obj/monster.c";

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("black dragon");
   set_race("dragon");
   set_long(
     "You see before you a very large, black dragon.\n"+
     "The scaly skin of its body looks as if it could deflect fireballs\n"+
     "without even denting.  When you look into its eyes, you sense its\n"+
     "awesome power and strength.  This dragon looks as if it has been\n"+
     "here for centuries, and by the look of things, it will be here for\n"+
     "centuries more.  It's mouth drips with a drool that scars the stone\n"+
     "below with a hiss.  Go on, make his day ...\n");

   set_ac(20);
   set_wc(36);
   set_level(23);
   set_hp(600);
   set_al(-1000);
   set_whimpy(1);

   set_spell_mess1("Black Dragon spits a stream of Hydrochloric acid!!");
   set_spell_mess2("Black Dragon spits a stream of Hydrochloric acid at you!!");
   set_chance(25);
   set_spell_dam(60);

   set_chat_chance(25);
   load_chat("Dragon says: I am too powerful for you, tiny mortal!\n");
   load_chat("Dragon says: You don't have a chance against me!\n");
   load_chat("Dragon laughs at you!\n");
   load_chat("Dragon says: Go on home, wimp!  I hear your mother calling!\n");

   set_a_chat_chance(25);
   load_a_chat("Dragon bellows: I will eat you for breakfast!\n");
   load_a_chat("Dragon shouts: Stay still, puny mortal!\n");
   load_a_chat("Dragon hisses: You will die!\n");
   load_a_chat("Dragon squeals: I love tenderized meat!\n");
}
