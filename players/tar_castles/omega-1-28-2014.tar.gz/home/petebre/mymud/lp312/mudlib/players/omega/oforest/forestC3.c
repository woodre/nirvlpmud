#include "std.h"

ONE_EXIT("players/omega/oforest/forestC4", "east",
   "Forest\n",
   "You are in a forest.\n" +
   "This is the Hideout for the bandits which plague unwary travellers.\n" +
   "The forest becomes impassable here.\n",
   1)
