#include "std.h"

THREE_EXIT("players/omega/oforest/forestB1", "north",
/*  "players/omega/oforest/forestC2", "east",  */
   "players/omega/oforest/forestD1", "south",
   "players/omega/oforest/forestC0", "west",
   "Forest",
   "You are in a forest.\n" +
   "To the east you can see a fast flowing river.\n" +
   "There is a bridge which crosses the river.\n" +
   "However the bridge currently is raised, perhaps you should\n" +
   "come back later.\n",
   1)
