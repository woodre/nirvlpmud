inherit "obj/monster.c";

reset(arg) {
   if(!arg) {
   ::reset(arg);
   set_name("young hunter");
   set_alias("hunter");
   set_short("A young hunter");
   set_long("You see a young lad dressed in hunting gear.  He seems to be\n" +
   "peering into the cave intently.\n"
   );
   set_al(100);
   set_race("human");
   set_wc(10);
   set_ac(8);
   set_level(6);
   set_chat_chance(10);
   load_chat(
"Young hunter says:  I think that bear in that thar cave is grouchy.\n");
   load_chat(
"Young hunter says:  I hope bears like honey.\n");
   }
}
