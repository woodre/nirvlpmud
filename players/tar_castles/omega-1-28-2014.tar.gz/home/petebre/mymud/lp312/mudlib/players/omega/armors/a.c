inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("plate mail");
  set_short("Supreme plate mail of Omega");
  set_long("~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~\n"+
           "This armor is magically enhanced\n"+
           "and allows you to see in the dark!\n"+
           "It can only be obtained if Omega\n"+
           "grants one to you.  Wear it well.\n"+
           "MAY YOU NEVER FALL IN BATTLE!!!!!\n"+
           "");
  set_type("armor");
  set_light(1);
  set_ac(5);
  set_weight(1);
  set_value(25000);
  set_alias("plate");
}
