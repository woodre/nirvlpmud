inherit "obj/armor.c";

int charges;

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("winged boots");
  set_short("Winged boots of Omega");
  set_long("~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~\n"+
           "This armor is magically enhanced and allows you to fly around!\n"+
           "To use it just 'flyto <player>'.\n"+
           "It can only be obtained if Omega grants one to you.\n"+
           "Wear it well.  MAY YOU NEVER FALL IN BATTLE!!!!!\n"+
           "");
  set_type("boots");
  set_light(1);
  set_ac(2);
  set_weight(1);
  set_value(2500);
  set_alias("boots");
  charges = 20;
}

init() {
  ::init();
  add_action("fly_around","flyto");
}

fly_around(arg) {
object target;
   if(!arg) return 0;
   target = find_player(arg);
   if(!target) {
      write("Winged boots says:  Sorry, nobody by that name around.\n");
      return 1;
   }
   say(this_player()->query_name()+" spreads his feathered boots and flys into the sky.\n");
   move_object(this_player(), environment(target));
   say(this_player()->query_name()+" swoops in from above and lands on top of you.\n");
   write("Ok.\n");
   return 1;
}
