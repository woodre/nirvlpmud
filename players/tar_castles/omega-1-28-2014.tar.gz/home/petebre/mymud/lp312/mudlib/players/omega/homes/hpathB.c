#include "std.h"

short() {
   return "Highland path westB";
}
long() {
   write("You are in the western section of the Highland area.\n");
   write("The only obvious exits are east and west.\n");
}
init() {
   add_action("move1","east");
   add_action("move2","west");
}
move1() {
   this_player()->move_player("east#players/omega/homes/hpathA");
   return 1;
}
move2() {
   this_player()->move_player("west#players/omega/homes/hpathC");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
