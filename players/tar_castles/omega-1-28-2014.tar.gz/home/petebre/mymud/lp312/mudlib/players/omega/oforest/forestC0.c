#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object bug;

extra_reset() {
   if(!present("mosquito")) {
      starta_bug();
   }
   if(!present("squirrel")) {
      make_squirrels();
   }
}

THREE_EXIT("players/omega/oforest/forestB0", "north",
   "players/omega/oforest/forestC1", "east",
   "players/omega/oforest/forestD0", "south",
   "Forest",
   "You are in a forest.\n"+
   "The trees are impassable to the west.\n",
   1)

starta_bug() {
   bug = clone_object("obj/monster");
   bug->set_name("a mosquito");
   bug->set_alias("mosquito");
   bug->set_race("insect");
   bug->set_short("An annoying mosquito");
   bug->set_long("You see an annoying mosquito.\n");
   bug->set_ac(0);
   bug->set_wc(3);
   bug->set_al(-10);
   bug->set_level(1);
   bug->set_hp(30);
   move_object(bug, this_object());
   bug->set_object(this_object());
   bug->set_function("follow");
   bug->set_type("leaves");
   bug->set_match(" ");
}

follow(str) {
   string who, where;
   if(sscanf(str, "%s leaves %s.\n", who, where) == 2)
   call_other(bug, "init_command", where);
}

make_squirrels() {
int i;
object squirrel, gold;
   i=0;
   while(i<random(5)+4) {
      squirrel = clone_object("players/omega/monsters/squirrel");
      move_object(squirrel, this_object());
      gold = clone_object("obj/money");
      gold->set_money(random(50)+30);
      move_object(gold, squirrel);
      i+=1;
   }
}
