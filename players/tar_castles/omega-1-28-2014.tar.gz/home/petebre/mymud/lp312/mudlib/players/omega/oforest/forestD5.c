#include "std.h"

TWO_EXIT("players/omega/oforest/forestD4", "west",
   "players/omega/oforest/forestC5", "north",
   "Forest",
   "You are in a forest.\n",1)
