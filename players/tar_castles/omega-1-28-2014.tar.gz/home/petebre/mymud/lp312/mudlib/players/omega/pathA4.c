#include "std.h"

TWO_EXIT("players/omega/pathA3", "north",
   "players/omega/pathA5", "south",
   "Flower pathway",
   "You are on a dirt path.\n" +
   "Flowers on each side of the path, fill the air with a wonderful aroma!\n",
   1)
