#define NAME "/players/omega/homes/"
int num_b;  /* number of brochures left */

id(str) {
   return (str == "machine" || str == "lottery machine" || str == "highland homes lottery machine" );
}
short() { return "HIGHLAND HOMES LOTTERY MACHINE"; }
long() {
   write("+|=============================================================|+\n"+
         "ATTENTION:   THE HIGHLAND HOMES PROJECT IS NEARING COMPLETION!!\n"+
         "Since there was such a demand for houses, the only fair thing for\n"+
         "me to do is to hold a lottery to see who is eligible to buy.\n"+
         "You must be level 7 or higher, leave a (refundable) deposit\n"+
         "of 10,000 coins, and only one entry per player!\n"+
         "TO ENTER THE LOTTERY, TYPE 'register' AT THIS LOCATION.\n"+
         "TO GET A BROCHURE WITH INFORMATION, TYPE 'brochure'!\n"+
         "\n"+
         "Entries must be received by April 21st, drawing will be held\n"+
         "on April 22nd and winners will be posted on the bulletin board\n"+
         "at the entrance to the Kingdom of Omega.  You must be 18 years\n"+
         "or older to play.  Employees of Omega Corp. and their immediate\n"+
         "families ineligible.  This offer is void in Alaska *not*.\n"+
         "Signed - Omega the Winged One!\n"+
         "\n"+
         "P.S.  Watch this space for developments including a later\n"+
         "posting of what the houses can do for you!\n"
         );
}
init() {
   add_action("make_brochure", "brochure");
   add_action("register_player", "register");
}
make_brochure() {
object brochure;
   if(!num_b) {
      write("The machine is all out of brochures for today.\n");
      return 1;
   }
   brochure = clone_object( "players/omega/obj/lbrochure" );
   move_object( brochure, this_player() );
   write("You receive a brochure.\n");
   say(this_player()->query_name() + " gets a brochure from the machine.\n");
   num_b -= 1;
   return 1;
}
register_player() {
   if (this_player()->query_level() > 19) {
      write("Silly Wizard, These homes are for players!\n");
      return 1;
   }
   if (this_player()->query_level() < 7) {
      write("Sorry, you must be at least level 10 to enter the lottery.\n");
      return 1;
   }
   if (this_player()->query_money() < 10000) {
      write("Sorry, you need 10000 coins to enter the lottery.\n");
      return 1;
   }
   if( find_name(this_player()->query_real_name() )) {
      write("Players can only enter the lottery once.\n");
      return 1;
   }
   write_file( NAME + "lottery_list", this_player()->query_real_name()+"\n");
   this_player()->add_money(-10000);
   write("You are now entered in the housing lottery.\n");
   write("10000 coins were deducted as a (refundable) deposit.\n");
   write("GOOD LUCK, HOPE YOU WIN!!!\n");
   say(this_player()->query_name() + " just entered the housing lottery.\n");
   return 1;
}
reset(arg) {
  if(arg) return;
  num_b = 50;
}
int find_name (string pname) {
string line;
string fname;
int found;
int i;
   i = 1; found = 0;
   line = read_file( NAME + "lottery_list", i );
   while( line && !found ) {
      sscanf( line, "%s\n", fname );
      if( fname == pname ) found = 1;
      i += 1;
      line = read_file( NAME + "lottery_list", i );
   }
   return found;
}
