inherit "obj/monster.c";

object fang;

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("swamp adder");
   set_short("a huge swamp adder");
   set_al(-50);
   set_alias("adder");
   set_race("animal");
   set_long("A large, deadly, poisonous swamp adder.\n");
   set_aggressive(0);
   set_wc(random(4) + 9);
   set_ac(random(3) + 2);
   set_level(random(3) + 6);
   fang = clone_object("obj/weapon");
   call_other(fang,"set_name","swamp adder fangs");
   call_other(fang,"set_class",11);
   call_other(fang,"set_weight",1);
   call_other(fang,"set_value",350);
   call_other(fang,"set_alias","fangs");
   call_other(fang,"set_alt_name","fang");
   call_other(fang,"set_long",
   "A pair of deadly fangs, probably more deadly though when the\n" +
   "swamp adder was alive though.\n");
   transfer(fang, this_object());
}
