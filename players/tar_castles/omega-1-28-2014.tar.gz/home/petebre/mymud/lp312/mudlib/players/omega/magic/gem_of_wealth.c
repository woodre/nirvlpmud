int counter;

id(str) {
   if(counter == 0) {
      return str == "egg" || str == "golden egg" || str == "gem of wealth";
   }
   return str == "cloud" || str == "golden cloud";
}
short() {
   if(counter == 0) return "a golden egg";
   return "A GOLDEN CLOUD";
}
long() {
   if(counter != 0) {
      write("High above, you see a golden cloud.\n");
      return;
   }
   write("It is a egg made of pure gold!  It must be worth a lot!\n");
}
init() {
   add_action("crush_gem","crush");
   add_action("crush_gem","squeeze");
   add_action("crush_gem","crack");
}
crush_gem(str) {
   if(!id(str)) return;
   if(counter > 0) return 0;
   if(environment() != this_player()) {
      write("You must get it first.\n");
      return 1;
   }
   write("The gold egg emits a flash of gold light!\n");
   say(this_player()->query_name()+
      " suddenly emits a blinding flash of gold light!\n");
   write("The egg dissapears and a golden cloud materializes overhead!\n");
   say("A golden cloud materializes overhead!\n");
   transfer(this_object(), environment(this_player()));
   counter += 1;
   set_heart_beat(1);
   return 1;
}
heart_beat() {
   object money;
   if(counter > 6) {
      set_heart_beat(0);
      say("The coins stop falling and the cloud dissipates.\n");
      destruct(this_object());
   }
   if(random(20) == 0) {
      money = clone_object("obj/money");
      money->set_money(random(2000) + 5);
      move_object(money, environment());
      say("A shower of gold coins fall from the cloud!\n");
      say("Money!\n");
      counter += 1;
   }
}
get() {
   if(counter > 0) return 0;
   return 1;
}
query_value() { return 5000; }
query_weight() { return 1; }
reset(arg) {
   if(arg) return;
   counter = 0;
}
