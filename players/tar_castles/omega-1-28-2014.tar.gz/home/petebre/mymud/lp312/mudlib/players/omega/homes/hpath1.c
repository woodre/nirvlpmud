#include "std.h"

short() {
   return "Highland path";
}
long() {
   write("You are in the Highland Homes area of the city.\n");
   write("All around you see beautiful homes.\n");
   write("There is an open model home to the east.\n");
   write("The Highland real estate office is the the west.\n");
   write("The only obvious exits are north, south, east and west.\n");
}
init() {
   add_action("move1","south");
   add_action("move2","east");
   add_action("move3","west");
   add_action("move4","north");
}
move1() {
   this_player()->move_player("south#players/omega/ocity/cpathZ4");
   return 1;
}
move2() {
   this_player()->move_player("east#players/omega/homes/model1");
   return 1;
}
move3() {
   write("Sorry, the houses are postponed indefinitely.\n");
   return 1;
   this_player()->move_player("west#players/omega/homes/high_office");
   return 1;
}
move4() {
   this_player()->move_player("north#players/omega/homes/hpath2");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
