#include "room.h"

ONE_EXIT("players/omega/workroom","out",
   "Chat room",
   "This is a standard room with no special coding.\n",
   1)
