string name, alias, short_desc, long_desc;
string consume_verb;
string self_desc, others_desc;
int value, weight, amount;

reset(arg)
{
   if(arg) return;
   name = "food"; weight = 1; amount = 5; value = 10;
   short_desc = "food";
   long_desc = "You see food.  It is edible.\n";
   self_desc = "You feel better";
   consume_verb = "eat";
}

set_name(str) { name = str; }

set_alias(str) { alias = str; }

id(str) {
   return str == name || str == alias;
}

set_long(str) { long_desc = str; }

long() { write(long_desc); }

set_short(str) { short_desc = str; }

short() {
   return
   short_desc;
}

set_weight(w) { weight = w; }

query_weight() { return weight; }

set_value(v) { value = v; }

query_value() { return value; }

set_verb(str) { consume_verb  = str; }

init() {
   add_action("consume"); add_verb(consume_verb);
}

set_amount(a) { amount = a; }

set_self(str) { self_desc = str; }

set_others(str) { others_desc = str; }

consume(str) {
   if (!id(str)) return 0;
   if (environment() != this_player()) return 0;
   if (others_desc)
   say(call_other(this_player(),"query_name")+" "+others_desc+"\n");
   call_other(this_player(),"heal_self",amount);
   write(self_desc + "\n");
   destruct(this_object());
   return 1;
}

get() {
   return 1;
}

drop() {
   return 0;
}
