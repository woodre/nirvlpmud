#include "std.h"

short() {
   return "Highland path";
}
long() {
   write("You are on a gravel path.\n");
   write("To the west and east you see rows of houses.\n");
   write("The only obvious exits are south, east and west.\n");
}
init() {
   add_action("move2","south");
   add_action("move3","east");
   add_action("move4","west");
}
move2() {
   this_player()->move_player("south#players/omega/homes/hpath1");
   return 1;
}
move3() {
   this_player()->move_player("east#players/omega/homes/hpath3");
   return 1;
}
move4() {
   this_player()->move_player("west#players/omega/homes/hpathA");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
