reset(arg) {
   if(arg) return;
   set_light(1);
}

short() { return "The prison of Omega"; }

long() {
   write("You are in the prison of Omega.\n");
   write("You see a semi-spacious room which is very clean.\n");
   write("The room is 50' by 50' and contains various furniture.\n");
}

init() {
   if(this_player()->query_real_name() == "omega") { return; }
   add_action("nil","quit");
   add_action("imprison","imprison")
   return 1;
}

nil(str) {
   if(!str) { return 0; }
   if(str == "look" || str == "l") {
      command(this_player(),"look");
      return 1;
   }
   write("What?\n");
   return 1;
}

imprison(name) {
   if(!name) { return 0; }
   if(!find_player(name)) {
      write(capitalize(name)+" cannot be found.\n");
      return 1;
   }
   transfer(find_player(name)), this_object());
   return 1;
}
