#include "std.h"

TWO_EXIT("players/omega/pathA0", "north",
   "players/omega/pathA2", "south",
   "Southern dirt pathway",
   "You are on a dirt pathway on the south side of the kingdom.\n",1)
