#include "std.h"

THREE_EXIT("players/omega/ocity/cpathZ4","north",
   "players/omega/ocity/cpathA5","east",
   "players/omega/ocity/cpathA3","west",
   "City walkway.",
   "You are on a wooden walkway in the city of Omega.\n"+
   "There is a gravel path which leads north.\n",
   1)
