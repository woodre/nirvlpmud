#include "std.h"
#include "living.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object elf;
object money;
object weapon;
object amulet;

TWO_EXIT("players/omega/oforest/forestC0", "north",
   "players/omega/oforest/forestD1", "east",
   "Forest",
   "You are in a forest.\n" +
   "The trees are impassable to the west and south.\n",
   1)

extra_reset () {
   if(!elf || !living(elf)) {
      elf = clone_object("obj/monster");
      call_other(elf,"set_name","forest elf");
      call_other(elf,"set_alias","elf");
      call_other(elf,"set_short","Slender forest elf");
      call_other(elf,"set_long",
      "You see a slender humanoid, whose facial features are very handsome.\n" +
      "The elf has a pleasant smile on his face and seems at peace.\n"
      );
      elf->set_ac(5);
      elf->set_wc(15);
      call_other(elf,"set_level",15);
      elf->set_al(150);
      elf->set_chat_chance(50);
      elf->load_chat("Elf says:  I am the Forest Guardian.\n");
      elf->load_chat("Elf says:  Please do not harm the creatures in this forest.\n");
      elf->load_chat("Elf says:  Give a hoot.  Don't pollute.\n");
      move_object(elf, this_object());

      weapon = clone_object("obj/weapon");
      call_other(weapon,"set_name","wooden sword");
      call_other(weapon,"set_alias","sword");
      call_other(weapon,"set_short","A wooden sword");
      call_other(weapon,"set_long",
         "You see a sword made of an unusually hard wood.  It is very stiff\n"+
         "and sharp, yet the wood feels very soft and soothing to the touch.\n"+
         "There is something engraved on the sword.\n");
      call_other(weapon,"set_read","Engraved on the sword reads:  BEASTMASTER\n");
      call_other(weapon,"set_class",15);
      call_other(weapon,"set_weight",3);
      call_other(weapon,"set_value",2000);
      call_other(weapon,"set_hit_func",this_object());
      call_other(weapon,"set_wield_func",this_object());
      move_object(weapon, elf);
      call_other(elf,"init_command", "wield sword");

      amulet = clone_object("obj/armor");
      amulet->set_name("woodland amulet");
      amulet->set_alias("necklace");
      amulet->set_short("Elven necklace");
      amulet->set_long(
      "You see a beatiful necklace made of gold and platinum and inlaid\n"+
      "with precious stones.  The light glitters off it magically.\n"
      );
      amulet->set_ac(1);
      amulet->set_weight(2);
      amulet->set_value(2200);
      amulet->set_type("amulet");
      transfer(amulet,elf);

      money = clone_object("obj/money");
      call_other(money,"set_money",random(20) + 20);
      move_object(money, elf);
   }
}

weapon_hit(attacker) {
   if(call_other(environment(this_player()), "realm") == "enterprise") {
      write("Your sword whines:  'I hate the Enterprise!'\n");
      write("The wooden sword flies out of your hands!\n");
      transfer(present("wooden sword", this_player()), environment(this_player()));
      return 0;
   }
   if(75 < random(100)) return 0;
   if(call_other(attacker,"id","lizard man")) {
      tell_object(this_player(),"The wooden sword shoots a burst of flame!\n");
      return 15;
   }
   if(call_other(attacker,"id","orc")) {
      tell_object(this_player(),"The wooden sword glows brightly!\n");
      return 15;
   }
   if(call_other(attacker,"id","animal")) {
      tell_object(this_player(),"The wooden sword cuts deeply!\n");
      return 15;
   }
   return 0;
}

wield() {
   tell_object(this_player(),
      "Water drops form on the wooden sword and fall to the floor.\n");
   tell_object(this_player(),
      "It almost looks as if the sword is weeping.\n");
   return 1;
}
