inherit "obj/armor.c";

reset(arg) {
  if(arg) return;
  ::reset(arg);
  set_name("plate mail");
  set_short("A suit of plate mail");
  set_type("armor");
  set_ac(5);
  set_weight(5);
  set_value(1250);
  set_alias("mail");
}
