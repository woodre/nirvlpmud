short() { return "Gravel path"; }
long() {
   write("You are on a gravel path.\n");
   write("To the north you see many beautiful houses.\n");
   write("A fragrant rose garden surrounds the path.\n");
   write("The only obvious exits are north and south.\n");
}
init() {
   add_action("move2", "north");
   add_action("move1", "south");
}
rose(str) {
   return (str == "rose") || (str == "roses") || (str == "flowers")
      || (str == "flower");
}
smell_roses(str) {
   if(!str) { return 0; }
   if(!rose(str)) { return 0; }
   write("The sweet smell of roses fill your nasal passages... Ahh.\n");
   return 1;
}
take_rose(str) {
   if(!str) { return 0; }
   if(!rose(str)) { return 0; }
   write("You pick a rose and hold it delicately.\n");
   write("To your surprise, the rose slowly fades away!\n");
   return 1;
}
move1() {
   call_other(this_player(), "move_player",
      "south#players/omega/ocity/cpathA4");
   return 1;
}
move2() {
   this_player()->move_player("north#players/omega/homes/hpath1");
   return 1;
}
reset(arg) {
   if(arg) return;
   set_light(1);
}
