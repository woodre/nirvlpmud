#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT\
    add_action("ninja_equip"); add_verb("ninja_equip");\
    add_action("ninja_help"); add_verb("ninja_help");

ONE_EXIT("players/omega/ocity/cpathA1", "south",
         "Omega Corporation Offices",
       "You are in the OMEGA CORPORATION OFFICES.\n"+
       "A posted sign reads: 'Sorry, closed for repairs.'\n", 1)
/*
         "Commands are: 'buy item', 'list',\n", 1)
*/

buy(item) {
    if (!item)
        return 0;
    call_other("players/omega/ocity/guildstore", "fill", 0);
    call_other("players/omega/ocity/guildstore", "buy", item);
    return 1;
}

list(obj) {
    call_other("players/omega/ocity/guildstore", "fill", 0);
    call_other("players/omega/ocity/guildstore", "inventory", obj);
    return 1;
}

ninja_equip(str) {
object ob;
   if(!str) {
      write("Usage:  ninja_equip <item>\n");
      write("katana, shozoku, hood, sash, tabi, amulet, gauntlets, or tie\n");
      write("Example:  ninja_equip katana\n");
      return 1;
   }
   if (str == "katana") {
      if (find_item_in_player("a ninja katana")) {
         write("You already have one.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/katana");
      move_object(ob, this_player());
      write("You get a katana.\n");
      return 1;
   }
   if (str == "shozoku") {
      if(find_item_in_player("a ninja shozoku")) {
         write("You already have one.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/shozoku");
      move_object(ob, this_player());
      write("You get a shozoku.\n");
      return 1;
   }
   if (str == "hood") {
      if(find_item_in_player("a ninja hood")) {
         write("You already have one.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/hood");
      move_object(ob, this_player());
      write("You get a hood.\n");
      return 1;
   }
   if (str == "sash") {
      if(find_item_in_player("a ninja sash")) {
         write("You already have one.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/sash");
      move_object(ob, this_player());
      write("You get a sash.\n");
      return 1;
   }
   if (str == "tabi") {
      if(find_item_in_player("a pair of ninja tabi")) {
         write("You already have a pair.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/tabi");
      move_object(ob, this_player());
      write("You get a pair of tabi.\n");
      return 1;
   }
   if (str == "amulet") {
      if(find_item_in_player("a ninja amulet")) {
         write("You already have one.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/amulet");
      move_object(ob, this_player());
      write("You get an amulet.\n");
      return 1;
   }
   if (str == "gauntlets") {
      if(find_item_in_player("a pair of ninja gauntlets")) {
         write("You already have a pair.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/gauntlets");
      move_object(ob, this_player());
      write("You get a pair of gauntlets.\n");
      return 1;
   }
   if (str == "tie") {
      if(find_item_in_player("a ninja tie")) {
         write("You already have one.\n");
         return 1;
      }
      ob = clone_object("players/omega/closed/ninja/tie");
      move_object(ob, this_player());
      write("You get a tie.\n");
      return 1;
   }
   return 0;
}

find_item_in_player(str)
{
    object ob;

    ob = first_inventory(this_player());
    while(ob) {
        if (call_other(ob, "id", str))
            return ob;
        ob = next_inventory(ob);
    }
    return 0;
}
