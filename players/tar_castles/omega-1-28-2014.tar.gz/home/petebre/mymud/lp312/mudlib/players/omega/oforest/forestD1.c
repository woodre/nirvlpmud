#include "std.h"
#include "living.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object hunter;
object honey;

THREE_EXIT("players/omega/oforest/forestC1","north",
   "players/omega/oforest/forestD0","west",
   "players/omega/oforest/bear_cave","cave",
   "Forest",
   "You are in a forest.\n"+
   "A mountain range towers above you to the south.\n"+
   "The forest becomes impassable to the east.\n"+
   "There are tracks around here of what appears to be a bear.\n"+
   "The tracks lead into a cave to the south.\n",
   1)

extra_reset() {
   if(!present("hunter")) {
   hunter = clone_object("obj/monster");
   hunter->set_name("young hunter");
   hunter->set_alias("hunter");
   hunter->set_short("A young hunter");
   hunter->set_long(
      "You see a young lad dressed in hunting gear.\n"+
      "He seems to be peering into the cave intently.\n");
   hunter->set_al(20);
   hunter->set_race("human");
   hunter->set_wc(6);
   hunter->set_ac(1);
   hunter->set_level(6);
   hunter->set_chat_chance(10);
   hunter->load_chat(
      "Young hunter says:  I think that bear in that thar cave is grouchy.\n");
   hunter->load_chat(
      "Young hunter says:  I hope bears like honey.\n");
   transfer(hunter, this_object());

   honey = clone_object("players/omega/obj/oheal");
   honey->set_name("honey");
   honey->set_short("A bit of honey");
   honey->set_long("You see some sweet honey, good enough to eat.\n");
   honey->set_weight(2);
   honey->set_value(30);
   honey->set_amount(8);
   honey->set_verb("eat");
   honey->set_self("The honey melts in your mouth.  Yumm!\n"+
      "You feel better!\n");
   honey->set_others("eats some sweet honey and looks better!");
   transfer(honey, hunter);
   }
}
