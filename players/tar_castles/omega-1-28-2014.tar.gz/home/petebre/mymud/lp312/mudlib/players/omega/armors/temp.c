inherit "obj/monster.c";

string wearer_name;
string type;
int shield_defend;
int value, weight;
int worn, ac;
object worn_by;
object owner_ob;
object next;

reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("dancing shield");
  set_ac_type("shield");
  set_short("Dancing shield of Omega");
  set_long(
    "~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~-_-~\n"+
    "This armor is magically enhanced and will leap from your arm to\n"+
    "defend you when attacked, forcing your attacker to fight it instead!\n"+
/*
    "'defendme'       : toggles the shield defending magic.\n"+
*/
    "'shieldwimpy'    : toggles the shields wimpy.\n"+
    "This item can only be obtained if Omega grants one to you.\n"+
    "Wear it well... MAY YOU NEVER FALL IN BATTLE!!!!!\n");
  set_ac(2);
  set_weight(1);
  set_value(2500);
  set_level(20);
  set_ep(0);
  set_wc(0);
  set_whimpy(1);
  set_object(this_object());
  set_function("defend_wearer");
  set_type("missed");
  set_match(" ");
  set_type("hit");
  set_match(" ");
}

get() {
  if(!owner_ob) return 1;
  if(this_player() != owner_ob) return 0;
  return 1;
}

link(ob) { next = ob;}

remove_link(str) {
  object ob;

  if(str == name) {
    ob = next;
    next = 0;
    return ob;
    }
  if(next)
    next = next->remove_link(str);
  return this_object();
}

init() {
  ::init();
  add_action("wear", "wear");
  add_action("remove", "remove");
  add_action("wimpy_toggle","shieldwimpy");
}

rec_short() {
  if(next)
    return name + "," + next->rec_short();
  return name;
}

short() {
  test_wear();
  if(worn)
    return short_desc + " (worn)";
  return short_desc;
}

long() {
  ::long();
  if(whimpy) {
    write("It is in wimpy mode.\n");
    }
  else {
    write("It is in brave mode.\n");
    }
}

id(str) {
  return str == name || str == alias || str == type;
}

test_type(str) {
  if(str == type)
    return this_object();
  if(next)
    return next->test_type(str);
  return 0;
}

tot_ac() {
  if(next)
    return ac + next->tot_ac();
  return ac;
}

query_type() { return type; }

query_value() { return value; }

query_worn() { test_wear(); return worn; }

armor_class() { return ac; }

wear(str) {
  object ob;

  if(!id(str)) return 0;
  if(environment() != this_player() ) {
    write("You must get it first!\n");
    return 1;
  }
  test_wear();
  if(worn) {
    write("You're already wearing it!\n");
    return 1;
  }
  next = 0;
  ob = this_player()->wear(this_object());
  if(!ob) {
    worn_by = this_player();
    worn = 1;
    owner_ob = this_player();
    return 1;
  }
  write("You already have an armor of class " + type + ".\n");
  write("Worn armor " + ob->short() + ".\n");
  return 1;
}

wimpy_toggle() {
  if(whimpy) {
    write("Okay, the shield will now defend you till it's destroyed!\n");
    whimpy = 0;
    }
  else {
    write("Okay, the shield will now run at 1/5 it's damage capacity.\n");
    whimpy = 1;
    }
  return 1;
}

defend_wearer(str) {
string who, what;
  if(!query_worn()) return;
  if(environment() != this_player() ) return;
  sscanf(str,"%s missed %s.", who, what);
  if(who != environment()->query_name() ) return;
  write("Defender shield of Omega leaps off your arm to defend you!\n");
  move_object(this_object(), environment(this_player()));
  this_player()->query_attack()->attack_object(this_object());
  call_out("go_home",5,owner_ob);
  return 1;
}

go_home(ob) {
  if(ob->query_attack()) {
    call_out("go_home",5,ob);
    return 1;
  }
  say(short()+" returns to "+owner_ob->query_name()+".\n");
  move_object(this_object(), ob);
  say(short()+" has returned.\n");
  ob->init_command("wear shield");
}

run_away() {
  say(short()+" has taken too much damage and flees from battle!\n");
  if(!owner_ob) {
    ::run_away();
    return 1;
  }
  go_home();
  return 1;
}

drop(silently) {
  test_wear();
  if(worn) {
  worn_by->stop_wearing(name);
  worn = 0;
  worn_by = 0;
  if(!silently)
    write("You drop your worn armor.\n");
  }
  return 0;
}

remove(str) {
  if(!id(str)) return 0;
  test_wear();
  if(!worn) {
    return 0;
  }
  worn_by->stop_wearing(name);
  worn_by = 0;
  worn = 0;
  owner_ob = 0;
  return 1;
}

query_weight() { return weight; }

set_value(v) { value = v; }

set_weight(w) { weight = w; }

set_ac(a) { ac = a; armor_class = a*6; }

set_ac_type(t) { type = t; }

set_arm_list(l) { set_light(l); }

set_info(str) { info = str; }

query_info() { return info; }

test_wear() {
  if(environment() == worn_by)
    return;
  if(worn_by)
    worn_by->stop_wearing(name);
  worn_by = 0;
  worn = 0;
}
