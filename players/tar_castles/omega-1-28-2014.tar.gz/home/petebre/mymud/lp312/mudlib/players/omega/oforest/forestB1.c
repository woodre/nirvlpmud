#include "std.h"
#include "living.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

object hoot_owl;
object money;
int i;

THREE_EXIT("players/omega/oforest/forestA1", "north",
   "players/omega/oforest/forestB0", "west",
   "players/omega/oforest/forestC1", "south",
   "Forest",
   "You are in a forest.\n",
   1)

extra_reset() {
   if (!hoot_owl || !living(hoot_owl)) {
      i = 0;
      while (i < (random(10)+4)) {
         i += 1;

         hoot_owl = clone_object("obj/monster");
         call_other(hoot_owl, "set_name", "hooting owl");
         call_other(hoot_owl, "set_short", "A hooting owl");
         call_other(hoot_owl, "set_al", 0);
         call_other(hoot_owl, "set_alias", "owl");
         call_other(hoot_owl, "set_race", "animal");
         call_other(hoot_owl, "set_long",
            "A very elegant hooting owl.  It is clutching some gold.\n");
         call_other(hoot_owl, "set_aggressive", 0);
         call_other(hoot_owl, "set_wc", 3);
         call_other(hoot_owl, "set_ac", 2);
         hoot_owl->set_whimpy(1);
         call_other(hoot_owl, "set_level", 2);
        call_other(hoot_owl, "set_hp", 40);
         call_other(hoot_owl, "set_chat_chance", 10);
         call_other(hoot_owl, "load_chat",
            "Owl says:  Hoooooo ...\n");
         call_other(hoot_owl, "load_chat",
            "Owl says:  Hoo Hoo ...\n");

         call_other(hoot_owl, "set_a_chat_chance", 25);
         call_other(hoot_owl, "load_a_chat",
            "Owl shrieks:  HOOT!!\n");
         call_other(hoot_owl, "load_a_chat",
            "Owl shrieks:  HOOOOOT!!");

         move_object(hoot_owl, this_object());

         money = clone_object("obj/money");
         money->set_money(random(200) + 20);
         move_object(money, hoot_owl);
      }
   }
}
