object war_veteran;

reset(arg) {
   if(!present("sign")) {
      object bar_sign;
      bar_sign = clone_object("players/omega/obj/osign");
      bar_sign->set_name("bar sign");
      bar_sign->set_alias("sign");
      bar_sign->set_short("a bar sign");
      bar_sign->set_long(
      "To help increase sales, the following short cuts are available:\n"+
      "    \"buy beer\"     --> \"bb\"\n"+
      "    \"buy coffee\"   --> \"bc\"\n"+
      "    \"buy special\"  --> \"bs\"\n"+
      "    \"buy fire\"     --> \"bf\"\n"+
      "(Who says you have to have a macro-capable computer?)\n");
       move_object(bar_sign, this_object());
    }
    if (!war_veteran) {
       war_veteran = clone_object("players/omega/monsters/war_veteran");
       transfer(war_veteran, this_object());
    }
    if (arg) return;
    set_light( 1);
}

short() {
    return "BOB's place";
}

init() {
    add_action("move");
    add_verb( "north");
    add_action("order");
    add_verb("order");
    add_action("order");
    add_verb("buy");
    add_action("short_order"); add_xverb("b");
}

move() {
    object ob;

    call_other(this_player(), "move_player",
        "north#players/omega/ocity/cpathA0");
    return 1;
}

long() {
    write("You are in BOB's pub in the city of Omega.\n");
    write("You can order drinks here.\n\n");
    write("     First class beer    :  10 coins\n");
    write("     Cup of coffee       :  20 coins\n");
    write("     Special of the house: 100 coins\n");
    write("     Firebreather        : 230 coins\n\n");
    write("The only obvious exit is to " +  "north" + ".\n");
}

short_order(str) {
string drink_name;
   if(!str) return;
   if (str != "b" && str != "c" && str != "s" && str != "f") return;
   if (str == "b") drink_name = "beer";
   if (str == "c") drink_name = "coffee";
   if (str == "s") drink_name = "special";
   if (str == "f") drink_name = "fire";
   if(!drink_name) return;
   order(drink_name);
   return 1;
}

order(str)
{
    string name, short_desc, mess;
    int value, cost, strength, heal;

    if (!str) {
       write("Order what ?\n");
       return 1;
    }
    if (str == "beer") {
	mess = "That feels good";
	heal = 1;
	value = 10;
	strength = 2;
    }
    else if (str == "special" || str == "special of the house") {
	mess = "A tingling feeling goes through your body";
	heal = 5;
	value = 100;
	strength = 8;
    } else if (str == "firebreather" || str == "fire") {
	mess = "A shock wave runs through your body";
	heal = 10;
	value = 230;
	strength = 12;
    } else if (str == "coffee" || str == "cup of coffee") {
	mess = "You feel somewhat invigorated";
	heal = 0;
	value = 20;
	strength = -2;
    } else {
       write("The bartender says: What do you want?\n");
       return 1;
    }
    if (call_other(this_player(), "query_money", 0) < value) {
        write("That costs " + value + " gold coins, which you don't have.\n");
	return 1;
    }
    if (strength > (call_other(this_player(), "query_level") + 2)) {
	if (strength > (call_other(this_player(), "query_level") + 5)) {
	    /* This drink is *much* too strong for the player */
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and immediately throws it up.\n");
	    write("You order a " + str + ", try to drink it, and throw up.\n");
	} else {
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and spews it all over you!\n");
	    write("You order a " + str + ", try to drink it, and sputter it all over the room!\n");
	}
	call_other(this_player(), "add_money", - value);
	return 1;
    }
    if (!call_other(this_player(), "drink_alcohol", strength)) {
	write("The bartender says: I think you've had enough.\n");
	say(call_other(this_player(), "query_name", 0) + " asks for a " +
		str + " but the bartender refuses.\n");

	return 1;
    }
    write("You pay " + value + " coins for a " + str + ".\n");
    say(call_other(this_player(), "query_name", 0) + " orders a " + str + ".\n");
    call_other(this_player(), "add_money", - value);
    call_other(this_player(), "heal_self", heal);
    write(mess + ".\n");
    return 1;
}
