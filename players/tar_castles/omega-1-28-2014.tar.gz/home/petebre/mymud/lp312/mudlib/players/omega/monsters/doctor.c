inherit "obj/monster";

reset(arg) {
   if(!arg) {
   ::reset(arg);
   set_name("hospital doctor");
   set_alias("doctor");
   set_short("A hospital doctor");
   set_long(
   "You see a young female doctor who looks about in her 20's.\n"+
   "She peers at you over a pair of glasses as if assessing your\n"+
   "physical condition.\n"
   );
   set_ac(5);
   set_wc(9);
   set_level(5);
   set_race("human");
   }
}
