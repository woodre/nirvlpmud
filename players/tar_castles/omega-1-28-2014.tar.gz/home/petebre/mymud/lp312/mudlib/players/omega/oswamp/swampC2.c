short() { return "Swamp"; }
long() {
   write("You are in a swamp.\n");
   write("The swamp becomes impassable to the east.\n");
   write("The only obvious exits are north, south, and west.\n");
}
init() {
   add_action("move1","north");
   add_action("move2","south");
   add_action("move3","west");
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp") return 0;
  if(present("lizard man")) {
     write("The lizard man stops you!\n");
     transfer(this_player(), this_object());
     return 1;
  }
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}
move1() {
   if(stop_player(25)) return 1;
   this_player()->move_player("north#players/omega/oswamp/swampB2");
   return 1;
}
move2() {
   if(stop_player(75)) return 1;
   this_player()->move_player("south#players/omega/oswamp/swampD2");
   return 1;
}
move3() {
   if(stop_player(75)) return 1;
   this_player()->move_player("west#players/omega/oswamp/swampC1");
   return 1;
}
stop_player(chance) {
   if(this_player()->query_ghost()) return 0;
   if(!present("lizard man")) return 0;
   if(random(100) <= chance) {
      write("Lizard man leaps in front of you, blocking your escape!\n");
      return 1;
   }
   write("You manage to escape!\n");
   return 0;
}
reset() {
   if (!present("lizard man")) {
   int i;
   object lizard_man;
      while (i < (random(2) + 2)) {
         lizard_man = clone_object("players/omega/monsters/lizard_man");
         if(i==1) lizard_man->set_move_at_reset(1);
	 lizard_man->set_a_chat_chance(30);
	 lizard_man->load_a_chat("Lizard man says: You'll never find it!\n");
	 lizard_man->load_a_chat("Lizard man says: They musn't find the weapon!\n");
	 lizard_man->load_a_chat("Lizard man says: Stop them from escaping!\n");
	 lizard_man->load_a_chat("Lizard man says: We must get it first!\n");
	 move_object(lizard_man, this_object());
	 i += 1;
      }
   }
}
