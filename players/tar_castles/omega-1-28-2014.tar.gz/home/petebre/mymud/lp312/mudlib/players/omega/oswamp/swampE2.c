#include "path"
#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

object alligator;
object money;

extra_init() {
   add_action("search","search");
}
search(str) {
  if(str && str != "area" && str != "here" && str != "swamp" &&
     str != "room") return 0;
  write("You find nothing of interest.\n");
  say(this_player()->query_name()+" searches the area.\n");
  return 1;
}

TWO_EXIT(PATH+"swampD2", "north",
   PATH+"swampE1", "west",
   "Swamp",
   "You are in a swamp.\n" +
   "A towering mountain range blocks your passage south,\n" +
   "and to the east the muck becomes too deep to cross.\n",
   0)

extra_reset() {
   if (!alligator || !living(alligator)) {

         alligator = clone_object("obj/monster");
         call_other(alligator, "set_name", "a nasty alligator");
         call_other(alligator, "set_al", -50);
         call_other(alligator, "set_alias", "alligator");
         call_other(alligator, "set_race", "animal");
         call_other(alligator, "set_long",
            "A large alligator with LOTS of teeth.\n");
         call_other(alligator, "set_aggressive", 1);
        call_other(alligator, "set_wc", random(10) + 7);
         call_other(alligator, "set_ac", 3);
         call_other(alligator, "set_level", random(2) + 10);
         move_object(alligator, this_object());

         money = clone_object("obj/money");
         money->set_money(random(1000) + 500);
         move_object(money, alligator);
   }
}
