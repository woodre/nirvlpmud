#define MAX_DAM 150
#define MIN_DAM 50
#define MAX_TIME 60
#define MIN_TIME 10

string current_owner, sowner, it, damage, timer;
object obj, owner;
status armed;
int ammo;

set_damage(d) {
int dam;
  if(!d) {
    write("....warhead setting:  "+damage+" points....\n");
    return 1;
  }
  if (sscanf(d,"%d",dam) != 0) {
  if(this_player()->query_real_name() != "omega"){
     if ((dam < MIN_DAM) || (dam > MAX_DAM)) {
       write("....damage setting out of range ....\n");
       return 1;
     }
  }
  damage = dam;
  write("Rocket damage set to "+ dam + ".\n");
  return 1;
  }
return 0;
}

set_timer(t) {
int tim;
  if(!t) {
    write("....rocket speed setting:  "+timer+" seconds....\n");
    return 1;
  }
  if(sscanf(t,"%d",tim) != 0) {
  if(this_player()->query_real_name() != "omega"){
     if((tim < MIN_TIME) || (tim > MAX_TIME)){
       write("....speed setting out of range....\n");
       return 1;
     }
  }
  timer = tim;
  write("Delay timer set to " + tim + " seconds.\n");
  return 1;
  }
return 0;
}
id(str) {
   return (str == "launcher" || str == "m202" || str == "M202" ||
      str == "m202 rocket launcher" || str == "rocket");
}
query_name() { return "rocket launcher"; }
query_weight() { return 10; }
query_value() { return 650000; }
query_damage() { return damage; }
query_ammo() { return ammo; }
short() { return "NATO M202 anti-tank rocket launcher"; }
long() {
  write("You see a NATO M202 anti-tank rocket launcher (by Omega Corp.)\n");
  write("A computer terminal on the launcher displays the following:\n");
  write("****************************************************************\n");
  write("* Standard ammunition:                         4 M202 rockets   *\n");
  write("* MAX/MIN damage levels:             150/50 points of damage   *\n");
  write("* MAX/MIN speed settings:           60/10 second travel time   *\n");
  write("* Instructions:                                                *\n");
  write("*    Display number of rockets left: 'ammo'                    *\n");
  write("*    Display current speed setting:  'speed'                   *\n");
  write("*    Change the speed setting:       'speed <seconds>'         *\n");
  write("*    Display current damage level:   'damage'                  *\n");
  write("*    Change the damage level:        'damage <amount>'         *\n");
  write("*    To arm/disarm the launcher:     '[arm | disarm] m202'     *\n");
  write("*    Launch the rocket by typing:    'launch <name of target>' *\n");
  write("* Missiles can be armed and disarmed in midflight.  This will  *\n");
  write("* affect all in-flight missiles.  Multiple rockets may be      *\n");
  write("* launched at about the same time at different targets.        *\n");
  write("****************************************************************\n");
}

reset(arg) {
  if(arg) return;
  armed = 0;
  damage = 150;
  timer = 10;
  ammo = 4;
  current_owner = "omega";
}

init() {
  add_action("arm_missile"); add_verb("arm");
  add_action("disarm_missile"); add_verb("disarm");
  add_action("shoot_missile"); add_verb("launch");
  add_action("set_damage"); add_verb("damage");
  add_action("set_timer"); add_verb("speed");
  add_action("ammo_left"); add_verb("ammo");
}

get() {
  if (this_player()->query_real_name() == "omega") {
     return 1;
  }
  if (!current_owner) {
     current_owner = this_player()->query_real_name();
     return 1;
  }
  if (this_player()->query_real_name() != current_owner) {
     return 0;
  }
return 1;
}

drop() {
   if (ammo <= -2) {
      write("....rocket launcher out of rockets....\n");
      write("....executing security instruction 15xb-2A....\n");
      write("M202 anti-tank rocket launcher self destructed.\n");
      destruct(this_object());
   }
   current_owner = 0;
   return 0;
}

ammo_left() {
int n;
  n = query_ammo();
  write("....rockets remaining in launcher:  "+n+" M202 rockets's....\n");
  return 1;
}

arm_missile(str) {
   if (!id(str)) return 0;
   if(armed) {
     write("The launcher is already armed.\n");
     return 1;
   }
   armed = 1;
   write("The onboard computer lights up with activity.\n");
   say(this_player()->query_name() + " arms a rocket launcher.\n");
   return 1;
}

disarm_missile(str) {
   if(!id(str)) return 0;
   if (!armed) {
      write("The launcher is already inactive.\n");
      return 1;
   }
   armed = 0;
   write("The onboard computer powers down and shuts off.\n");
   say(this_player()->query_name() +
       " disarms a rocket launcher.\n");
   return 1;
}

shoot_missile(target) {
string tname;
  if(ammo <= 0) {
    write("....out of rockets....\n");
    return 1;
  }
  if(!armed) {
    write("You must arm it first.\n");
    return 1;
  }
  if(!target) {
    write("You must pick a target.\n");
    return 1;
  }
  it = lower_case(target);
  obj = find_living(it);
  owner = this_player();
  sowner = owner->query_name();
  if(!obj) {
    write("Onboard computer cannot find target ... Launch aborted ...\n");
    return 1;
  }
  if((obj->query_level() < 1) || (obj->query_real_name() == "omega")){
     tell_object(owner, "....target illegal....\n");
     tell_object(owner, "....changing target....\n");
     it = this_player()->query_real_name();
     obj = this_player();
  }
  ammo -= 1;
  tname = capitalize(it);
  write("An M202 rocket has been launched ...\n");
  say(this_player()->query_name()+" launches a rocket into the sky.\n");
  write("Target: "+tname+"   Warhead: "+damage+"   Timer: "+timer+"\n");
  tell_room(environment(obj),
     "You hear the roar of a rocket in the distance.\n"+
     "You estimate "+timer+" seconds till its arrival.\n" +
     "It looks like it is heading straight for "+tname+"!!!\n");
  call_out("launch",timer,it);
  return 1;
}

launch(it) {
string tname;
   if(!find_player(it)) {
       tell_object(owner, "....missile failed to reach target....\n");
       tell_object(owner, "....target missing....\n");
       return 1;
   }
   tname = capitalize(it);
  tname = capitalize(obj->query_real_name());
  if(armed) {
     tell_room(environment(obj),
      "BOOM!!! A rocket explodes on "+
     tname+"!!!\n");
     tell_object(owner,
      tname+" was hit by your rocket.\n");
   tell_object(obj,
   "You were hit by "+capitalize(owner->query_real_name())+"!\n");
   obj->add_hit_point((-1) * random(query_damage()) + 5);
   if(obj->query_hp() <= 5) {
     tell_room(environment(obj),
         tname+" was blown to little bitty pieces!!\n");
     tell_object(owner,
         tname+" was blown to bits by your rocket!!\n");
     destruct(obj);
   }
  return 1;
  }
  if(!armed) {
  tell_room(environment(obj),
     "An unarmed rocket crashes next to "+tname+".\n");
  tell_object(owner,
     "Your rocket crashed harmlessly next to "+tname+".\n");
  return 1;
  }
}
