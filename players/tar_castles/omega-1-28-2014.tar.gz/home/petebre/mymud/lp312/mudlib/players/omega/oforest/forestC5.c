#include "std.h"

TWO_EXIT("players/omega/oforest/forestD5", "south",
   "players/omega/oforest/forestB5", "north",
   "Forest",
   "You are in a forest.\n",1)
