#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

int summon;

reset(arg)
{
  if(arg) return;
  set_light(1);

  set_short(HIW+"Shrine Room"+NORM);
  set_long(
  "The walls here are covered with pictures of Chucky the good guy doll\n"+
  "killing various people. There are boxes cluttered around the floor\n"+
  "and stacked in the corner. A huge picture hangs alone on the back wall.\n"+
  "The smaller pictures hang about the other walls.\n");


     items=({
           "pictures","Lots of pictures filled with blood, gore and violent killings of different people",
           "boxes","Many boxes with 'Good Guy Dolls' written on the side of them",
           "picture","A 6 foot tall picture that shows Chucky standing facing you"+
                     " There is a small plaque on the base of the picture",
           "walls","Marble walls with pictures hanging on them",
           "plaque","It reads: If you wish to challenge him, just summon him",
           "floor","A marble floor that is cluttered with boxes",
           "corner","The corner of the room. It has boxes in it.",
           });

  add_exit("/players/syn/shrine/hall1.c","east");
  add_property("NT");
  set_chance(15);
  add_msg("You hear the faint laughter of a small child\n");
  add_msg("The wind blows through your hair\n");
  add_listen("You hear echoing footsteps on the marble floor\n");
  add_smell("You can faintly smell blood, and cotton candy\n");
}
void init() {
  ::init();
  add_action("cmd_summon","summon");
}
cmd_summon(str) {
  if(summon == 0) {
  if(!str || str != "chucky")
    { notify_fail("summon what?\n"); return 0;}
  write("You summon"+RED+" Chucky"+NORM+" the good guy doll.\n");
  if(!present("chucky")) {
     move_object(clone_object("/players/syn/shrine/mobs/chucky.c"),this_object()); }
  write("Chucky enters the room, giggling like a school girl.\n");      
  summon = 1;
  return 1;
}
}
