#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

int W,dam;

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("blade");
set_alias("sword");
set_short(HIK+"A black blade"+NORM);
set_long(
  "A meter length black steel blade, attatched to a black plastic hilt. The\n"+
  "top of the blade has been rounded over. It still has a little dryed blood\n"+ 
  "on the blade.\n");
set_type("sword");
set_class(18);
set_weight(3);
set_value(2000);
set_hit_func(this_object());
message_hit = ({
        BOLD+"speared"+NORM," through the chest",
        BOLD+"sliced"+NORM," across the chest",
        BOLD+"hacked"+NORM," to small pieces ",           
        BOLD+"slash"+NORM," on the back",
        BOLD+"cut"+NORM," on the arm",
        BOLD+"bashed"+NORM," with the hilt of the blade",
        BOLD+"stabbed"+NORM," in the leg"
        });
set_save_flag(1);
}


weapon_hit(attacker) {
W = (15);
switch(W) {
         
         
    case 1:
       say(this_player()->query_name()+ "  .\n"+
           HIR+"    S-------------------L----------A---S-H-E--D\n"+NORM
           +"          across the chest.\n"+
           RED+"Blood "+NORM+"pours from the wound.\n");
       write("You slash deeply, causing"+RED+" blood "+NORM+"to flow. \n");
       return 18;
       break;
  
    case 2:
       say(this_player()->query_name()+" cuts his opponet's throat.\n"+
          RED+"Blood "+NORM+" pours from the wound.\n");
       write("You "+HIR+" S / L / I / C / E "+NORM+" your opponet's throat.\n"+
             "Blood pours from your victims throat.\n"+
             "He tries to scream, but only sprays "+RED+"blood"+NORM+" all over your face.\n");
       return 15;
       break;

    case 3:
       say(this_player()->query_name()+"sticks the blade through his opponet.\n"+NORM);
       write("You "+RED+"sticks"+NORM+" your blade through your victim.\n"+
             RED+"Blood "+NORM+"pours over the hilt of the blade.\n"+
             "You feel the warmth liquid cover your hand. The eyes of your\n"+
             "victim role up into the back of thier head.\n");
       return 13;
       break; 

 

       attacker->heal_self(-dam);
       break;
   }
return;
}
