#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {

object gold;
object ob;
object ob2;
  
  ::reset(arg);
  if(arg) return;

ob = clone_object("/players/syn/shrine/items/mask2.c");
         move_object(ob,this_object());
         command("wear mask",this_object());

ob2 = clone_object("/players/syn/shrine/items/machete.c");
         move_object(ob2,this_object());
         command("wield sword",this_object());

set_name("jason");
set_alias("voorhees");
set_race("human");
set_short("Jason Voorhees");
set_long(
  "He is a HUGE man. He stands about 6ft 10 in tall. He looks\n"+
   "like some kinda monster in the light here. His dark blue,\n"+
   "almost black, jumpsuit is covered in dirt and caked blood.\n"+
   "Jason has killed many around the Crystal Lake area.\n");
 

set_level(24);
set_hp(random(350)+2000);
set_al(-1600);
set_wc(35);
set_ac(25);
set_heal(10,5);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Jason stands ominously.\n");
  load_chat("Jason stares at you intently. Fury burns in his eyes.\n");
set_a_chat_chance(10);
  load_a_chat("Jason rushes into you........\n"+HIR
              +"                  SLAMMING   "+NORM+" you into the wall.\n");
  load_a_chat("Jason swings his machete barly missing your head.\n");
  load_a_chat("Jason brings his machete down into his attacker with a....\n"+
             HIW+"             SICKENING CRUNCH!!!\n"+NORM);

set_chance(13);
set_spell_dam(random(40)+60);

set_spell_mess1(
  "Jason"+RED+" slams"+NORM+" his machete into his attacker.\n");
set_spell_mess2(
 HIK+"Jason "+RED+" slams"+NORM+" his machete into you.\n"+
  "You feel the blade go in, and hit bone with a "+HIW+"crunch.\n"+NORM   
  +"Jason twists the blade, and grinds the metal against bone.\n"+
  "This pain is almost unbearable.\n"+
  "You feel the blade "+RED+"cut"+NORM+" and "+RED+"tear"+NORM+" your flesh as it is removed from your body.\n");

gold = clone_object("obj/money");
gold->set_money(random(3000)+4000); 
move_object(gold,this_object());

}

heart_beat(){
 ::heart_beat();
    if(!random(13) && attacker_ob) big_special();


}

init(){
  ::init();
    add_action("block_dir","west",1);
    }

block_dir(){
  if(present("jason", environment(this_player()))){
  write("Jason is standing in your path.\n");
  say(this_player()->query_name()+" tries to leave, but Jason is in the way.\n");
  return 1; }

}

big_special(){
	if(environment())
	tell_room(environment(),
       HIW+"Jason swings his machette.....\n"+NORM); 

switch(random(3))  {
		
		case 2:
		say(" and"+RED+" ======| slashes|======\n"+
                                        ""+attacker_ob->query_name()+" across the chest.\n",({ attacker_ob }));
		tell_object(attacker_ob,"and "+RED+" ====| slashes |==== "+NORM+"you across the chest.\n");
		attacker_ob->hit_player(25);
		break;
		
		case 1:
		say("and "+attacker_ob->query_name()+" gets "+RED+"stabbed"+NORM+" in the neck.\n",({ attacker_ob}));
		tell_object(attacker_ob,"and "+RED+"stabs"+NORM+" you in the neck.\n");
		attacker_ob->hit_player(20);
		break;
		
		case 0:
		say(" and "+RED+"slashes"+NORM+" "+attacker_ob->query_name()+" across the back.\n",({ attacker_ob}));
		tell_object(attacker_ob,"and "+RED+"slashes"+NORM+" you across the back.\n");
		attacker_ob->hit_player(15);
		break;
  
  }

}


