#include <ansi.h>
inherit  "obj/monster.c";

reset(arg) {
  ::reset(arg);
  if(arg) return;
  move_object(clone_object("/players/syn/wierdville/items/blade.c"));
  init_command("wield sword");
  move_object(clone_object("/players/syn/wierdville/items/blade.c"));
  init_command("offwield", "/players/syn/wierdville/items/blade.c");
  set_name("ninja");
  set_alt_name("solider");
  set_short(HIK+"A black ninja"+NORM+"  "+BOLD+"|"+NORM+""+RED+"dragon clan"+NORM+""+BOLD+"|"+NORM);
  set_long(
"A ninja dressed in a dark black suit. A black scarf covers the lower\n"+
"half of his face. He carries a sword, and a small pouch. The pouch hangs\n"+
"from his waist.\n");
  set_gender("male");
  set_race("human");
  set_level(23);
  set_wc(38);
  set_ac(20);
  set_hp(500+random(200));
  set_al(-500);
  set_assist("/players/syn/ntown/ninja", 20, 3, 1); 
  set_a_chat_chance(15);
   load_a_chat("The ninja flips over your head, and hits his foe in the back.\n");
   load_a_chat("The ninja rolls under your attack, and smashes his foe in the face.\n");
   load_a_chat("The ninja leaps back, and rushes his foe.\n");
   load_a_chat("The ninja leaps high into the air, and brings his blade down on his foe.\n");
  set_chance(10);
  set_spell_mess1(
"                The "+HIK+"ninja"+NORM+" leaps into the air and         \n"+
"            brings his blade down hard into his foe's    \n"+
"           back, spinning around and slashing his neck.  \n"+
"                 Blood squirts everywhere.               \n"
  ); /* 3RD PERSON */
  set_spell_mess2(
"                 The "+HIK+"ninja"+NORM+" leaps into the air and         \n"+
"               brings his blade down hard into your       \n"+
"           back, spinning around and "+BOLD+"slashing"+NORM+" your neck.  \n"+
"                 "+RED+"Blood squirts everywhere.                \n"+NORM

  ); /* 1ST PERSON */
  set_spell_dam(35+random(30));
}
