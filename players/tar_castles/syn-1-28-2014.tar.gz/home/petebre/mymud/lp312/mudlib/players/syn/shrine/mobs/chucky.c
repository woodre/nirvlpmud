#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("chucky");
set_alias("doll");
set_alt_name("guy");
set_race("doll");
set_short(RED+"Chucky"+NORM+" the Good Guy Doll");
set_long(
  "Chucky stands about 1 meter high, and has a smile that looks more evil\n"+
  "than it does friendly. He is wearing a multi-colored stripped shirt with\n"+
  "red overalls, and small black shoes. He doesn't seem friendly.\n");

set_level(18);
set_hp(random(350)+1500);
set_al(-800);
set_hp_bonus(random(200)+100);
set_wc(45);
set_ac(25);
set_heal(25,15);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Chucky says: I need to get into a new body, before I'm stuck forever as a damn DOLL!\n");
  load_chat("Chucky says: Look out Jack.......Chucky's Back!\n");
set_a_chat_chance(15);
  load_a_chat("Chucky screams: F**K YOU, You little bastard!\n");
  load_a_chat("Chucky screams: GIVE ME YOUR BODY!!!\n");

set_chance(13);
set_spell_dam(random(30)+80);

set_spell_mess1(
  RED+"Chucky slashes his opponent with frightful vengeance.\n"+NORM);
set_spell_mess2(
      "Chucky\n"+
      HIR+"/ /  // /S / /L// A/ S/ H/ / E// /S / /\n"+NORM+
      "           you with frightful vengeance.\n");

gold = clone_object("obj/money");
gold->set_money(random(3000)+4000); 
move_object(gold,this_object());

}

init(){
  ::init();
    add_action("block_dir","east",1);
    }

block_dir(){
  if(present("chucky", environment(this_player()))){
  write(HIK+"Chucky screams: You ain't going anywhere!!\n"+NORM);
  say(this_player()->query_name()+" tries to run, but "+RED+"Chucky"+NORM+" jumps in the way.\n");
  return 1; }

} 



