#include "/players/syn/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("boots");
set_alias("leather");
set_short("Leather boots");
set_long(
  "Large boots made from sheep skin. That are quite comfortable.\n"+
  "That are decorated with beads and feathers.\n");

set_ac(1);
set_type("boots");  /* armor,helmet,boots,ring,amulet,shield,misc  */
set_weight(1);
set_value(200);
set_arm_light(0);  /*  makes armor glow if it's > 0  */
}

