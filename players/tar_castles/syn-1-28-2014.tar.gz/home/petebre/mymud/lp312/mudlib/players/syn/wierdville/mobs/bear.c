#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object ob;
  ::reset(arg);
  if(arg) return;

set_name("bear");
set_alias("big");
set_alt_name("grizzly");
set_race("beast");
set_short("A big bear "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "A large brown bear. Razor sharpe claws are extened, and he is standing on his back feet.\
 He stands about 9 feet tall. Blood is oozing from his mouth, nose, and eyes. It slow trickles\
 down into his fur, making it stick together in clumps. You can smell his stinking breathe and\
 it reminds you of rotting flesh.\n"+
 "");

set_level(20);
set_hp(600+random(100));
set_al(-100);
set_wc(31); 
set_ac(17);
call_out("random_move",15);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat(BOLD+"The Bear: ROOOOAAAARRRRSSSS!!!\n"+NORM);
  load_a_chat(BOLD+"The Bear grunts angrily.\n"+NORM); 

ob = clone_object("/players/syn/wierdville/items/bfur.c"); 
move_object(ob,this_object());

set_chance(10);
set_spell_dam(random(25)+50);

set_spell_mess1(
   "The bear falls on top "+this_player()->query_name()+" pinning them to the floor.\n");
set_spell_mess2(
   "The bear falls on top of you, and pins you to the floor.\n"+ 
   "              His "+HIY+"claws"+NORM+" sink into your "+HIR+"flesh"+NORM+" and scrape your "+BOLD+"bones"+NORM+". \n"+
   "                            The pain is unbearable."+HIR+" Blood gushes everywhere.\n"+NORM);


return 0;
}

init(){
  ::init();
    add_action("block_dir","out",1);
    }


block_dir(){
  if(present("bear", environment(this_player()))){
   write(HIY+"The Bear is blocking the way out of the cave.\n"+NORM);
   say(this_player()->query_name()+" tries to run, but the Bear blocks the way.\n");
   return 1; }
}



