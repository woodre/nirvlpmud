#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

int summon;

reset(arg)
{
  if(arg) return;
  set_light(1);

  set_short(BOLD+"Shrine Room"+NORM);
  set_long(
  "This room is completely bare. Nothing lies on the floor, or hangs from\n"+
  "the walls. It is completely painted black. There is but one picture\n"+
  "on the furthest wall from the door.\n");

       items=({
           "picture","A 6 foot tall picture of the "+HIK+"Warlock"+NORM+" standing there."+
                     "There is a small plaque on the base of the painting",
           "plaque","It reads: If you wish to meet him, just summon him",
           "walls","Marble walls that have been painted black",
             });

  add_exit("/players/syn/shrine/hall2.c","west");
  add_property("NT");
  set_chance(15);
  add_msg("You hear echoing footsteps on the marble floor \n");
  add_msg("The wind blows through your hair\n");
  add_listen("You hear chanting in anicent words that sounds far away\n");
  add_smell("You can smell burning sulfur and brimstone\n");
}
void init() {
  ::init();
  add_action("cmd_summon","summon");
}
cmd_summon(str) {
  if(summon == 0) {
  if(!str || str != "warlock")
    { notify_fail("summon what?\n"); return 0;}
  write("You summon the "+HIK+"Warlock\n"+NORM);
  if(!present("warlork")) {
        move_object(clone_object("/players/syn/shrine/mobs/warlock.c"),this_object()); }
  write("The "+HIK+"Warlock"+NORM+" materalize in front of you\n");      
  summon = 1;
  return 1;
}
}
