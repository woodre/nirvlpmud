#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("pinhead");
set_alias("cenobite");
set_race("cenobite");
set_short(HIW+"Pinhead"+NORM);
set_long(
  "He is a CENOBITE. Horribly mutilated by systems of hooks\n"+
   "and pins.  The garment he wears is elaborately constructed\n"+
   "to marry with his flesh, laced through skin in places,\n"+
   "hooked into bone in other places. He has pins driven\n"+
   "into his head at inch intervals. He looks very frightening.\n");
 

set_level(23);
set_hp(random(550)+1500);
set_al(-1600);
set_wc(39);
set_ac(28);
set_heal(15,5);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Pinhead says: The box ... you opened it. We came.\n");
  load_chat("Pinhead says: We are Cenobites.  Explorers in the\n"+
            "further regions of experience. Demons to some.  Angels\n"+
            "to others.\n");
set_a_chat_chance(10);
  load_a_chat("Pinhead says: we will open your throat..\n"+NORM);
  load_a_chat("Pinhead says : ... we'll tear your soul apart ...\n");
  load_a_chat("Pinhead says: You opened the box.  We came. Now\n"+
              "you must come with us, and taste our pleasures.\n");

set_chance(13);
set_spell_dam(random(40)+60);

set_spell_mess1(
  HIK+"      <_----------.\n"+
  "  <_---------      <_---------   \n"+   
  "          <_--------         <_---------\n"+NORM
  +"             Hooks fly out from holes in the wall, and stab Pinhead's attacker.\n");
set_spell_mess2(
      HIK+"      <_----------.\n"+
  "  <_---------      <_---------   \n"+   
  "          <_--------         <_---------\n"+NORM
      +"Hooks fly out from holes in the walls, and stab you.\n"+
  "You feel as if you're being torn apart.\n"+
  "Huge chuncks of your flesh are"+HIR+" RIPPED "+NORM+"from your body.\n");

gold = clone_object("obj/money");
gold->set_money(random(3000)+3000); 
move_object(gold,this_object());

}

heart_beat(){
 ::heart_beat();
    if(!random(13) && attacker_ob) big_special();


}

init(){
  ::init();
    add_action("block_dir","west",1);
    }

block_dir(){
  if(present("pinhead", environment(this_player()))){
  write("Pinhead throws a hook around your leg. Pinhead says: Don't leave us just yet.\n");
  say(this_player()->query_name()+" tries to leave, but Pinhead throws a hook around thier leg.\n");
  return 1; }

}

big_special(){
	if(environment())
	tell_room(environment(),
       HIK+"Pinhead throws his arms out, and tosses a small cube on the ground.\n"+NORM); 

switch(random(3))  {
		
		case 2:
		say("A Cenobite comes out of the cube, and\n"+
                        HIW+"         / B / L / A / S / T/ S/\n"+NORM
                                    +""+attacker_ob->query_name()+" in the head.\n",({ attacker_ob }));
		tell_object(attacker_ob,"A fat, grotesque monster appears in front of you.\n"+
					"He reaches around his back, and pulls a huge sythe out.\n"+
					"He swings it will all his might.\n"+
					"It comes down on your head with a sickening..\n"+
				    HIR+"  C                         \n"+
					"    R                      \n"+
					"      U                    \n"+
					"        N                  \n"+
					"          C               \n"+
					"            H             \n"+NORM
					+"    He jumps back and disappears.\n");
		attacker_ob->hit_player(45);
		break;
		
		case 1:
		say("Pinhead laughs at "+attacker_ob->query_name()+"'s feeble attempt to hit him.\n",({ attacker_ob }));
		tell_object(attacker_ob," A lady Cenobite, steps between you and Pinhead.\n"+
					"She tosses small blades at you that\n"+
					RED+" \\ R**********I*************P // \n"+NORM+
					"            through your body, then fades from view.\n"); 
		attacker_ob->hit_player(30);
		break;
		
		case 0:
		say("Pinhead shows "+attacker_ob->query_name()+"what"+HIW+" suffering and pain"+NORM+" really is.\n",({ attacker_ob }));
		tell_object(attacker_ob,"A torso with no legs appears in front of you.\n"+
					"He pulls out a steel whip and \n"+
					RED+" S     L    A    S   H   E  S  \n"+NORM+
					"         you across the face and chest, before disappearing.\n");
		attacker_ob->hit_player(25);
		break;
  
  }

}


