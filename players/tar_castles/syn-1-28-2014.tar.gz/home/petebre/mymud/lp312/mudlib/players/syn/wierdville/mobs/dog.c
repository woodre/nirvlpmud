#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object ob;
  ::reset(arg);
  if(arg) return;

set_name("dog");
set_alias("rover");
set_alt_name("pack");
set_race("beast");
set_short("A dog "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "This ferious animal is not friendly. It wide, blood shot eyes leak blood\
 from the coners continously. It mouth is open wide looking for its next fresh\
 meal. The blood red teeth are razor sharpe, and looks very dangerous. The fur\
 is raggy and bushy.\n"+
 "");

set_level(18);
set_hp(500);
set_al(-100);
set_wc(26); 
set_ac(15);
call_out("random_move",15);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat(BOLD+"The dog growls.\n"+NORM);
  load_a_chat(BOLD+"The dog barks.\n"+NORM); 

ob = clone_object("/players/syn/wierdville/items/fur.c"); 
move_object(ob,this_object());

set_chance(12);
set_spell_dam(random(25)+30);

set_spell_mess1(
   "The dog leaps into the air and "+HIR+"bites"+NORM+" "+this_player()->query_name()+" in the neck.\n");
set_spell_mess2(
   "The dog runs toward you and "+CYN+"leaps into the air.\n"+NORM+ 
   "              He lands on your chest and "+HIR+"bites"+NORM+" you in the neck.\n"+
   HIR+"                                     Blood flows from your wound.\n"+NORM);


return 0;
}

random_move() {
    int n;
  if(!environment()) return 1;
if(!query_attack()) {
    n = random(8);
    if (n == 0)
        command("west");
    else if (n == 1)
        command("east");
    else if (n == 2)
        command("south");
    else if (n == 3)
        command("north");
    else if (n == 4)
        command("northwest");
    else if (n == 5)
        command("southwest");
    else if (n == 6)
        command("northeast");
    else if (n == 7)
        command("southeast");
}
call_out("random_move",10);
return 1;
}



