#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
object ob;
  ::reset(arg);
  if(arg) return;


ob = clone_object("/players/syn/wierdville/items/bat.c");
move_object(ob,this_object());
command("wield bat",this_object());

set_name("mutant");
set_alias("one");
set_alt_name("mutation");
set_race("human");
set_short("Mutation"+BOLD+" OnE "+NORM+" "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "This hulking beast, was once a man. His face is no more, but you can see a blood eye\
 on the top of his left arm. He is wearing the remains of a white shirt, and his pants\
 are covered in blood, and flesh. It appears as if was a scientist, by his white lab coat,\
 before his transformation into the ugly shell of a man he is. \
");

set_level(22);
set_hp(825);
set_al(-1000);
set_wc(38); 
set_ac(20);
set_aggressive(1);
call_out("random_move",15);
set_a_chat_chance(17);
  load_a_chat("The Mutant growls at you.\n");
  load_a_chat("The Mutant "+HIR+"vomits blood "+NORM+"all over you.\n"); 

gold = clone_object("obj/money");
gold->set_money(3000+random(1500)); 
move_object(gold,this_object());

set_chance(12);
set_spell_dam(random(50)+75);

set_spell_mess1(
     " The"+RED+"   B            \n"+
     "           E         \n"+
     "              A      \n"+ 
     "                 S   \n"+
     "                   T \n"+NORM+
     "                      grabs his foe and"+HIC+"   t h r o w s"+NORM+" them into the wall.\n");
set_spell_mess2(
     " The"+RED+"   B            \n"+
     "           E         \n"+
     "              A      \n"+ 
     "                 S   \n"+
     "                   T \n"+NORM+
     "                      grabs you and   "+HIC+"t h r o w s"+NORM+"  you into the wall!\n");

}

random_move() {
    int n;
  if(!environment()) return 1;
if(!query_attack()) {
    n = random(8);
    if (n == 0)
        command("west");
    else if (n == 1)
        command("east");
    else if (n == 2)
        command("south");
    else if (n == 3)
        command("north");
    else if (n == 4)
        command("northwest");
    else if (n == 5)
        command("southwest");
    else if (n == 6)
        command("northeast");
    else if (n == 7)
        command("southeast");
}
call_out("random_move",10);
return 1;
}




