#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("husband");
set_alias("man");
set_alt_name("joe");
set_race("human");
set_short("Joe "+RED+"("+NORM+"Husband"+RED+")"+NORM);
set_long(
  "A regular joe. He is here with his wife and two children.\n"+
  "They came to spend the day at the Shrine, to look at all the\n"+
  "interesting pictures.\n");

set_level(15);
set_hp(850);
set_al(0);
set_wc(21);
set_ac(10);
set_heal(5,15);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Joe yells: Kids! Don't run too far away.\n");
  load_chat("Joe asks: Where is my wife?\n");
set_a_chat_chance(15);
  load_a_chat("Joe yells: Hurt me! Just don't hurt my children or my wife!\n");

set_chance(10);
set_spell_dam(30);

set_spell_mess1(
  HIY+"Joe runs toward you, swinging his fists wildly!\n"+NORM);
set_spell_mess2(
  HIY+"Joe runs toward his attacker, swinging his fists wildly.\n"+NORM);

gold = clone_object("obj/money");
gold->set_money(1000); 
move_object(gold,this_object());
}

