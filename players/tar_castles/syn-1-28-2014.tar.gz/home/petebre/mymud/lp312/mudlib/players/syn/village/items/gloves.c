#include "/players/syn/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("gloves");
set_alias("leather");
set_short("Leather gloves");
set_long(
  "Leather gloves made from sheep skin. They are dectorated with\n"+
  "beads around the wrist. The finger tips have been cut off.\n");

set_ac(1);
set_type("ring");  /* armor,helmet,boots,ring,amulet,shield,misc  */
set_weight(1);
set_value(200);
set_arm_light(0);  /*  makes armor glow if it's > 0  */
}

