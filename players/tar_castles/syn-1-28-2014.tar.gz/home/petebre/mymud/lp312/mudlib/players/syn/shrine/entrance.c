#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";


reset(arg) {

     set_light(1);
     short_desc = (HIW+"Shrine Entrance"+NORM);
     long_desc = 
"A large hallway with walls made of white marble. It is completely clean \n\
and shiny. There seems to be benches set up to rest on, and many pictures \n\
and plaques that are hung on the wall next to the room openings down  \n\
the rest of the hallway to the north. There are large doors that lead  \n\
back out of the shrine.\n";

      items=({
           "walls","They are white and black marble walls. Pictures hang on them further on.",
	   "benches","Wooden benches put in for people to sit, rest, and enjoy the view.",
	   "pictures","The pictures are hanging outside the rooms further down the hall. You should take a look",
	   "doors","Huge glass, push doors. A sign hangs on one of the doors.",
	   "sign","A large sign. You could read it",
             });
      add_property("NT");   
      add_exit("/players/syn/shrine/hall1.c","north");
      add_exit("/room/mount_pass","out");

}
      init() {
         ::init();
           add_action("listen","listen");
           add_action("search_room","search");
	   add_action("smell","smell");
           add_action("read_sign","read");
             }


      listen()  {
          write("You hear echoing footsteps on the marble floor.\n");
          say (this_player()->query_name() +" listens intently.\n");
          return 1;
              }

      search_room() {
          write("You find nothing.\n");
          say (this_player()->query_name()+" searches the area. \n");
          return 1;
                }

      smell()  {
          write("You smell rotting flesh, and freshly spilt blood high on the air.\n");
          say (this_player()->query_name() +"'s nose sniffs the air.\n");
          return 1;
               }
      read_sign()  {
          write("Players of Nirvana -\n");
          write("  This is my attempt for my area. Please feel free to blame me for\n");
          write("any of the problems that you may encounter here. This is intended to be\n");
          write("a high level area, so players below 19 please beware. This area\n");
          write("will be unfriendly to you, if you do not know what you are doing.\n");
          write("If you have any questions, or notice any problems, please let me know.\n");
          write("\t\t\t\t\t\tThanks,  Syn (aka HeWhoHatesAll) \n");
          say (this_player()->query_name() +" reads the sign.\n");
          return 1;
                }
