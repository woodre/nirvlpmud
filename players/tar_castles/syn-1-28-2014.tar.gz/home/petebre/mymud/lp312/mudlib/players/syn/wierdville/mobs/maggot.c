#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
object ob;
  ::reset(arg);
  if(arg) return;

set_name("maggot");
set_alias("infected");
set_alt_name("thing");
set_race("maggot");
set_short(BOLD+"Maggot"+NORM+" "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
  "A very large maggot, with a circular mouth and tiny white razor sharp teeth.\
   It does not look very friendly at all. It usally sticks around the Mutation's,\
  but can be found in other places with decaying flesh.\n");

set_level(12);
set_hp(850);
set_al(-100);
set_wc(14);
set_ac(8);
set_heal(5,15);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("The Maggot squirms around the room.\n");
  load_chat("The Maggot searches for decaying flesh.\n");
set_a_chat_chance(15);
  load_a_chat("The Maggot leaps through the air to attack you.\n");

set_chance(10);
set_spell_dam(30+random(20));

set_spell_mess1(
  BOLD+" The Maggot rips open your flesh and feed off the blood.\n"+NORM);
set_spell_mess2(
  BOLD+"The Maggot leaps onto his attacker.\n"+NORM);

ob = clone_object("/players/syn/wierdville/items/pod.c"); 
move_object(ob,this_object());
}

