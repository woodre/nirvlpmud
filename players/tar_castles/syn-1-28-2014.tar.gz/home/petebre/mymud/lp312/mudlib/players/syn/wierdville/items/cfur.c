#include "/players/syn/ansi.h"
inherit "obj/treasure";

reset(arg) {
  if(arg) return;
  set_id("fur");
  set_alias("cat fur");
  set_short(HIK+"Cat fur"+NORM);
  set_long(
"A black patch of fur. It has white spots all over it. The head is still connected to\n"+
"it. The fur is caked with blood and mud. It smells of death and decay.\n"+
"You could probably get some money for this thing, from the right person.\n");
  set_weight(2);
  set_value(1500+random(500));
}

init() {
  ::init();
  add_action("cmd_barter","barter");
}

cmd_barter(str) {
  if(id(str)) {
    if(present("John",environment(this_player()))) {
      write("John says: Thank you so much for bringing me this. It will\n"+
            "fetch a fair price. If you find any other furs or feathers, please \n"+
            "bring them to me.\n");
      this_player()->add_money(value);
      this_player()->add_weight(-2);
      destruct(this_object());
      return 1;
    }
  }
  notify_fail("Barter what?\n");
}
