#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

reset(arg) {

         if(!present("sheryl")) {
        move_object(clone_object("/players/syn/shrine/mobs/sheryl.c"),this_object()); }

     set_light(1);
     short_desc = (HIW+"Shrine Hallway"+NORM);
     long_desc = 
"A large hallway with walls made of white marble. It is completely clean \n\
and shiny. There is another picture to the west, with a doorway next to it.  \n\
The hallways extends further to the north. South will lead you back down \n\
the hallway to the exit.\n";

      items=({
           "marble","White marble stone, with black onyx chips in it",
           "walls","They are white and black marble walls. Pictures hang on them",
	   "picture","Picture to the west shows a chainsaw, and a leather-looking mask",
           "doorway"," A doorway with no door. The room beyond is completely black, however",
             });
      add_property("NT");   
          add_exit("/players/syn/shrine/hall5.c","north");
          add_exit("/players/syn/shrine/hall3.c","south");
          add_exit("/players/syn/shrine/lfroom.c","west");
                 
}
      init() {
         ::init();
           add_action("listen","listen");
           add_action("search_room","search");
	   add_action("smell","smell");
             }


      listen()  {
          write("You hear echoing footsteps on the marble floor.\n");
          say (this_player()->query_name() +" listens intently.\n");
          return 1;
              }

      search_room() {
          write("You find nothing.\n");
          say (this_player()->query_name()+" searches the area. \n");
          return 1;
                }

      smell()  {
          write("You smell rotting flesh, and freshly spilt blood high on the air.\n");
          say (this_player()->query_name() +"'s nose sniffs the air.\n");
          return 1;
               }
 


