#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object ob;
object gold;
  ::reset(arg);
  if(arg) return;

ob = clone_object("/players/syn/shrine/items/glove.c");
move_object(ob,this_object());
command("wield glove",this_object());


set_name("freddy");
set_alias("krueger");
set_alt_name("fred");
set_race("human");
set_short(HIK+"Freddy Krueger"+NORM);
set_long(
   "He appears more nightmarishly menacing than ever before.\n"+
   "His red and green sweater is but ancient tatters, barely\n"+ 
   "covering an inhumanly cadaverous form. Twisted burn-scar\n"+
   "flesh is stretched tight over misshapen sinew and gnarled,\n"+
   "elongated bone. His fedora sits slightly crooked, barely\n"+
   "revealing his eyes. A smile streaks across his face.\n");
 
set_level(24);
set_hp(random(650)+1900);
set_al(-1600);
set_wc(55);
set_wc_bonus(6);
set_ac(25);
set_heal(35,10);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Freddy says: ...come out and play... \n");
  load_chat("Freddy scrapes his claw on the wall.\n");
  load_chat("SSSSSSSSCCCCCCCRRRRREEEEEEEEEECCCCCCCCHHHH\n");
  load_chat(" one, two: freddy's coming for you\n"+
            " three, four: you better lock your door\n"+
            " five, six: better grab your crucifix\n"+
            " seven, eight: better stay awake\n"+
            " nine, ten: never sleep again....\n");
set_a_chat_chance(10);
  load_a_chat("Freddy says:"+RED+"  Payback time...\n"+NORM);
  load_a_chat("Freddy says: You're such a momma's boy!\n");
  load_a_chat("Freddy says: Every town has an Elm Street!\n");

set_chance(13);
set_spell_dam(random(40)+70);

set_spell_mess1(
      "Freddy\n"+
  HIW+"======|"+NORM+""+HIR+"    cuts deep   "+NORM+""+HIW+"|======== \n"+NORM   
      +"                          into his opponet stomach.\n");
set_spell_mess2(
      "Freddy\n"+
  HIW+"======|"+NORM+""+HIR+"    cuts deep   "+NORM+""+HIW+"|======== \n"+NORM    
      +"                          into your stomach.\n"+NORM
      +"You feel blood and warm chunks of flesh fall into your hands.\n");



gold = clone_object("obj/money");
gold->set_money(random(2000)+3000); 
move_object(gold,this_object());

}

heart_beat(){
 ::heart_beat();
    if(!random(5) && attacker_ob) big_special();


}

init(){
  ::init();
    add_action("block_dir","east",1);
    }

block_dir(){
  if(present("freddy", environment(this_player()))){
  write(HIK+"Freddy won't allow you to wake up from this nightmare, not just yet.\n"+NORM);
  say(this_player()->query_name()+" tries to leave, but Freddy says:"+RED+" You're not waking up yet.\n");
  return 1; }

}

big_special(){
	if(environment())
	tell_room(environment(),
       HIK+"Freddy melts down into a big puddle of black goo....\n"+NORM); 

switch(random(3))  {
		
		case 2:
		say(" A huge storm of flesh-eating bugs invades\n"+
                                        "the room. They"+HIW+"  S----W-----A-----R-----M\n"+NORM
                                       +""+attacker_ob->query_name()+"'s body eating what they can\n"+
                                        "before reforming into Freddy.\n",({ attacker_ob }));
		tell_object(attacker_ob,"A huge storm of flesh-eating bugs invades the room.\n"+
		      "                                                   \n"+
		      "          They "+HIW+"S--W--A--R--M"+NORM+"over your body, "+RED+"ripping"+NORM+" your flesh from\n"+
		      "                                                   \n"+
		      "                       bone, and spraying your "+RED+"blood"+NORM+" all over the room.\n"); 
		attacker_ob->hit_player(45);
		break;
		
		case 1:
		say("....and forms a Giant Bug and lunges at "+attacker_ob->query_name()+".\n",({ attacker_ob}));
		tell_object(attacker_ob,"...and forms into a Giant Bug.\n"+
		      "The bug "+HIR+"S--L--A--M--S"+NORM+" its body into you.\n"+
		      "Your body slams back into the wall behind you.\n");
		attacker_ob->hit_player(35);
		break;
		
		case 0:
		say("and becomes "+attacker_ob->query_name()+"'s worst nightmare.\n",({ attacker_ob }));
                tell_object(attacker_ob,"and becomes your worst nightmare.\n");
		attacker_ob->hit_player(25);
		break;
  
  }

}


