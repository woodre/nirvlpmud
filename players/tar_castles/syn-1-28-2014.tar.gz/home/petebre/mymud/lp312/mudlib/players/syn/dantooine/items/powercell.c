inherit "obj/treasure";

int bullets;


void reset(int arg) {
  set_id("powercell");
  set_alias("powercell");
  set_short("PowerCell");
  set_long(
"A small box that resembles a battery. It looks like it will fit into a blaster.\n"
  );
  set_weight(1);
  set_value(50);
  bullets=12;
}
int reload() {
  destruct(this_object());
  this_player()->recalc_carry();
  return bullets;
}
