#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("spear");
set_alias("polearm");
set_short("Orcish Spear");
set_long(
  "This long wooden staff has a large sharp arrowhead at the very top. It has\n"+
  "markings in orcish running down the side of the staff's handle. It has two large\n"+
  "pieces of leather wrapped around the handle in two different places. At the very end\n"+
  "of the staff there sits a large spike.\n");

set_type("polearm");  /*  sword/knife/club/axe/bow/polearm  */
set_class(17);
set_weight(2);
set_value(1000);
set_hit_func(this_object());
}

weapon_hit(attacker){
int W;
W = random(19);

if(W>16)  {
  say(""+HIK+""+environment(this_object())->query_name()+"'s spear glows a"+HIB+" dark blue"+NORM+".\n"+
  ""+HIK+"                      as it is thrust forward into its target.\n"+NORM);

  write(""+HIK+"Your spear glows "+HIB+"dark blue"+NORM+""+HIK+" with an ancient power.\n"+
  ""+HIK+"              The spear's blade releases its magic into your target.\n"+NORM);
  return 7;
   }
if(W>9)  {
  say(""+HIK+""+environment(this_object())->query_name()+"'s spear cuts deep into its foe.\n"+NORM+
  ""+HIK+"         The spear glows "+HIB+" dark blue"+NORM+" only for a moment then fades back to silver."+NORM+"\n");

  write(""+HIK+"Your spear pulses with a "+HIB+" dark magic"+NORM+".\n"+
  ""+HIK+"               for a moment then fades back to silver."+NORM+"\n");
  return 3;
   }
return; 
}


