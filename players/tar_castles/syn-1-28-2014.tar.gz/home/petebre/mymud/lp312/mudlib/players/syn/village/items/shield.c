#include "/players/syn/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("shield");
set_alias("steel");
set_short("Steel shield");
set_long(
  "A large round steel shield. It has leather on the back and\n"+
  "a large metal handle.\n");

set_ac(2);
set_type("shield");  /* armor,helmet,boots,ring,amulet,shield,misc  */
set_weight(3);
set_value(500);
set_arm_light(0);  /*  makes armor glow if it's > 0  */
}

