#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("child");
set_alias("girl");
set_alt_name("infected");
set_race("human");
set_short("A small girl "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "A small child, no more than 10 years old, is vomiting blood on her shirt\
 continiously. He small cloths seem to be ripped to shreds, and torn everywhere.\
 You can sense that this is no longer a human child, but a feeding demon bent\
 on destruction and death.\
 ");

set_level(15);
set_hp(200);
set_al(-100);
set_wc(15); 
set_ac(10);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat("The child yells : Mommy! The bad person won't let me eat him!\n");
  load_a_chat("The child yells : STOP HITTING ME, YOU BUTTHOLE!\n"); 

gold = clone_object("obj/money");
gold->set_money(100+random(100)); 
move_object(gold,this_object());

set_chance(12);
set_spell_dam(random(15)+20);

set_spell_mess1(
   "The girl "+RED+"scatches"+NORM+", and "+RED+"bites"+NORM+" at "+this_player()->query_name()+" fiercly!!!\n");
set_spell_mess2(
   "The girl scatches, and bites you, and "+RED+" blood "+NORM+" pours from your wounds.\n");


return 0;
}


