#include "/players/wocket/closed/ansi.h"
inherit "/players/wocket/std/wiztell.c";

reset(arg){
  if(arg) return;
  owner = "syn";
  cap_owner = "Syn";
  color = HIW;
  extra_look = "Syn has more psychological problems than "+HIR+"Albert Fish"+NORM;
}


