#include "/players/syn/ansi.h"
inherit "obj/treasure";

reset(arg) {
  if(arg) return;
  set_id("feather");
  set_alias("bird feather");
  set_short("A bird feather");
  set_long(
"A multiple colored feather that smells like blood, and death.\n"+
"It's base is covered with blood and guts. You don't like having this.\n"+
"You could probably get some money for it, from the right person.\n"+
  );
  set_weight(2);
  set_value(500+random(500));
}

init() {
  ::init();
  add_action("cmd_barter","barter");
}

cmd_barter(str) {
  if(id(str)) {
    if(present("John",environment(this_player()))) {
      write("John says: Thank you so much for bringing me this. It will\n"+
            "fetch a fair price. If you find any other furs or feathers, please \n"+
            "bring them to me.\n");
      this_player()->add_money(value);
      this_player()->add_weight(-2);
      destruct(this_object());
      return 1;
    }
  }
  notify_fail("Barter what?\n");
}
