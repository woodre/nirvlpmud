#include "/players/eurale/closed/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
  ::reset(arg);
  if(arg) return;

set_name("billy");
set_alias("child");
set_alt_name("boy");
set_race("human");
set_short("Billy "+RED+"("+NORM+"Son"+RED+")"+NORM);
set_long(
  "Billy is about 6 years old. He has short brown hair, and is\n"+
  "a very curious kid. He likes jokes and to play around with his\n"+
  "sister. He is in the middle of a game of hide-n-seek now.\n");

set_level(10);
set_hp(250);
set_al(0);
set_wc(10);
set_ac(8);
set_heal(5,10);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Billy says: Have you seen my sister around? I gotta catch her.\n");
  load_chat("Billy says: I wanna be a fireman when I grow up.\n");
set_a_chat_chance(5);
  load_a_chat("Billy yells: Mommy! Daddy!\n");

}


