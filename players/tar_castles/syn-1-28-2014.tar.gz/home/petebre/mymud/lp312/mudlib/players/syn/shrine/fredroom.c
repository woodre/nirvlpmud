#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

int summon;

reset(arg)
{
  if(arg) return;
  set_light(1);

  set_short(BOLD+"Shrine Room"+NORM);
  set_long(
  "The walls are filled with pictures of Freddy Krueger killing different.\n"+
  "people. The floor is metal grating, and steam shoots up from underneath you.\n"+
  "There is one big picture on the back wall. There are smaller pictures\n"+
  "on the other walls.\n");

       items=({
           "pictures","Pictures of Freddy Krueger killing people",
           "picture","A 6 foot tall picture of Freddy standing there, claws extended."+
                     "There is a small plaque on the base of the painting",
           "plaque","It reads: If you wish die, just summon him",
           "walls","Marble walls that have pictures hanging all over them",
           "floor","The floor is covered in metal grating, and steam rushes forward",
           "grating","Steel grating used in industrial construction to support the wieght of the workers",
             });

  add_exit("/players/syn/shrine/hall5.c","east");
  add_property("NT");
  set_chance(15);
  add_msg("You hear echoing footsteps on the marble floor \n");
  add_msg("The wind blows through your hair\n");
  add_listen("Voices from a thousand crying children cloud your mind\n");
  add_smell("You can smell burned flesh, and hair\n");
}
void init() {
  ::init();
  add_action("cmd_summon","summon");
}
cmd_summon(str) {
  if(summon == 0) {
  if(!str || str != "freddy")
    { notify_fail("summon what?\n"); return 0;}
  write("You summon Freddy Krueger.\n"+NORM);
  if(!present("freddy")) {
        move_object(clone_object("/players/syn/shrine/mobs/fred.c"),this_object()); }
  write("Freddy slashes the painting with his glove, and jumps into the room.\n");      
  summon = 1;
  return 1;
}
}
