inherit "room/room";
reset(arg) {
  object monster;
  if(arg) 
    return ;    
  set_light(1); 
  short_desc = "A short path"; 
  long_desc  =
 "The path that runs through this waystation of a spaceport has many potholes.\n"+
 "To the east you can see more buildings and more people wandering about. The\n"+
 "sounds of the city come alive. In the distance you can see a ship arriving in\n"+
 "the dock yards.\n";

}
init() {
         ::init();
           add_action("listen","listen");
           add_action("search_room","search");
	   add_action("smell","smell");
     
      listen()  {
	  write("You hear the roar of engines up ahead, and the faint chatter of people.\n");
	  say (this_player()->query_name()+"listens intently.\n");
          return 1;
               }


      search_room() {
          write("You search the area, but find nothing.\n");
          say (this_player()->query_name()+" searches the area. \n");
          return 1;
                }

      smell()  {
          write("You smell the strong smell of burning fuel mixed with cooking food.\n");
          say (this_player()->query_name() +"'sniffs at the air.\n");
          return 1;
               }

 dest_dir = ({
  "/players/syn/dantooine/dpath1.c", "east",
  "/players/syn/dantooine/entrance.c","north"
  });
  
}
