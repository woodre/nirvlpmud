#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";


reset(arg) {

     set_light(1);
     short_desc = (HIK+"Archway Room"+NORM);
     long_desc = ( 
"A large cave in the side of the mountain. It has a large circle marking on the\n"+
"center of the floor. There is an opening to the north. There are four large circle\n"+
"portals on the sides. Torches line the sides of the walls. There is a large pedestal\n"+
"in the center of the marking, with a book resting on top.\n");
  items=({
    "cave","A large cavern in the side of the mountain",
    "marking","            ____________             \n"+
	      "           /   _______  \             \n"+
              "          /   /   Y   \  \           \n"+
	      "          |   |_______   |          \n"+
              "          |        N  |  |          \n"+
	      "          |   \_______/  |          \n"+
	      "          \              /          \n"+
	      "           \____________/           \n"+
              "                                    \n"+
	      "       Welcome to Syn's Realm",
    "floor","A large rock floor, that has a marking in the middle of it",
    "opening","It looks like two glass doors, that you could possibly 'enter' ",
    "portals","Four large circluar portals that seem to be sealed off",
    "torches","Large torches attached to the walls of the cave",
    "pedestal","A large stone pedestal attatched to the floor",
    "book","A large leather bound book, that appears you can read",
  });
  dest_dir=({
    "/room/mount_pass","out",
  });
}

void init() {
  ::init();


  add_action("enter","enter");
  add_action("read","read");
  add_action("ask","ask");
}

enter()  {
  write("You enter through the glass doors.\n");
  say (this_player()->query_name() +" enters through the glass doors.\n");
  move_object(this_player(),"/players/syn/shrine/entrance.c");
  return 1;
	 }

read()  {
  write("Welcome to the wonderful world of Syn's\n"+
        "This book gives you an idea of some of the stuff that\n"+
	"I have made. To find out about a certain area, just \n"+
	" 'ask (name)' to get that specific information. I hope\n"+
	"you enjoy, and good day.\n"+
	"things you can ask about\n"+
	"//    "+HIW+"Doors"+NORM+" // \n");
  say(this_player()->query_name()+" reads the book on the pedestal.\n");
  return 1;

        }


int ask(string str) {
  if(!str) {
    write("You read more into the book.\n");
    return 1;
  }
  switch(str) {
    case "doors" :
      write(
     HIW+"             Shrine      \n"+NORM+
        " This is the shrine that you can find popular stuff from the \n"+
        "twentieth century. From Horror movies to comic books to \n"+
	"criminals, you can find it all in the shrine.         \n"+
	"						       \n"+
	"Recommended for High Level Players                    \n");
      break;
    case "circle1" :
      write(
        "Its not open yet.\n");
      break;
    case "circle2" : 
      write(
      "Its still sealed, and not open yet\n");
      break;
    case "circle3" : 
      write(
      "Its still sealed and not open yet\n");
      break;
    case "circle4" : 
      write(
        "Not open yet\n");
      break;
    default: write("Read what?\n");
  }
  return 1;
}
