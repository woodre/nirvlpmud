#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("sword");
set_alias("warsword");
set_short("Orcish WarSword");
set_long(
  "This long bladed sword is heavy and decoritive. Markings make thier\n"+
  "way up the metal blade, and dark, multicolored straps wrap around the\n"+
  "hilt. It looks really dangerous.\n");

set_type("sword");  /*  sword/knife/club/axe/bow/polearm  */
set_class(19);
set_weight(4);
set_value(5000);
set_hit_func(this_object());
}

weapon_hit(attacker){
int W;
W = random(19);

if(W>16)  {
  say(""+HIK+""+environment(this_object())->query_name()+"'s sword glows a"+HIB+" dark blue"+NORM+"\n"+
  ""+HIK+"                      as it is thrust forward into its target.."+NORM+"\n"+
  ""+HIK+"                    An explosion of light is seen as the blade connects with its foe.\n");

  write(
  ""+HIK+"Your sword glows "+NORM+""+HIB+"dark blue"+NORM+" "+HIK+"\n"+
  ""+HIK+"             as it is thrust forward into its target.."+NORM+"\n"+
  ""+HIK+"            An explosion of light is seen as the blade connects with its foe."+NORM+"\n");
  return 7;
   }
if(W>13)  {
  say(""+HIK+""+environment(this_object())->query_name()+"'s sword cuts deep into its foe."+NORM+"\n"+
  ""+HIK+"         The sword glows a "+HIB+" dark blue"+NORM+" only for a moment then fades back to silver."+NORM+"\n");

  write(
  ""+HIK+"Your sword pulses with a "+HIB+" dark magic"+NORM+"\n"+
  ""+HIK+"               for a moment then fades back to silver."+NORM+"\n");
  return 3;
   }
if(W>10)  {
  say(""+HIK+""+enviroment(this_object())->query_name()+"'s sword glows a deep dark"+MAG+" purple"+NORM+".\n"+
      "                       The markings on the blade glow brightly. \n");
  
  write(
  ""+HIK+"Your sword glows in a deep dark "+MAG+" purple"+NORM+".\n");
return 1; 
 }
}


