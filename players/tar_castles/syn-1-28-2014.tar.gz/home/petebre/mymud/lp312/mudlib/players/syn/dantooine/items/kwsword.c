#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("blade");
set_alias("war blade");
set_short(RED+"Krath"+NORM+BOLD+" War Blade"+NORM);
set_long(
  "A 1.5 meter length steel blade, attatched to a ornate silver green hilt.\n"+
  "It is used by many Krath as thier weapon of choice. It looks like it would\n"+
  "be usefull in battle. It is said that the wielder of this blade would be\n"+
  "blessed by the gods of the Krath.\n");

set_type("sword");
set_class(18);
set_weight(2);
set_value(2000);
set_hit_func(this_object());
}
 
weapon_hit(attacker){
int W;
W = random(15);
if(W>9)  {
  say(
  HIR+"The anicent gods of the mighty Krath bestow power through the blade.\n"+NORM);

  write(
  BOLD+"You hear voices talking through you, and feel the POWER grow inside you.\n"+NORM);
  return 3;
   }
return;
}

