#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object ob;
  ::reset(arg);
  if(arg) return;

set_name("cat");
set_alias("kitty");
set_alt_name("pack");
set_race("beast");
set_short("A cat "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "This is not your typical housecat. It wide, blood shot eyes leak blood\
 from the coners continously. It mouth is open wide looking for its next fresh\
 meal. The blood red teeth are razor sharpe, and looks very dangerous.\n"+
 "");

set_level(16);
set_hp(300+random(50));
set_al(-100);
set_wc(22); 
set_ac(13);
call_out("random_move",15);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat(BOLD+"The cat hisses.\n"+NORM);
  load_a_chat(BOLD+"The cat : MEEEOUUUEEEHHH!\n"+NORM); 

ob = clone_object("/players/syn/wierdville/items/cfur.c"); 
move_object(ob,this_object());

set_chance(10);
set_spell_dam(random(15)+15);

set_spell_mess1(
   "The cat                       \n"+
   HIR+"           S                  \n"+
   "             C                \n"+
   "               R              \n"+
   "                 A            \n"+
   "                   T          \n"+
   "                     C        \n"+
   "                       H      \n"+
   "                         E    \n"+
   "                           S  \n"+NORM+
   "                                "+this_player()->query_name()+" across the face.\n");
set_spell_mess2(
   "The cat                       \n"+
   HIR+"           S                  \n"+
   "             C                \n"+
   "               R              \n"+
   "                 A            \n"+
   "                   T          \n"+
   "                     C        \n"+
   "                       H      \n"+
   "                         E    \n"+
   "                           S  \n"+NORM+
   "                                you across the face.\n");
  


return 0;
}

random_move() {
    int n;
  if(!environment()) return 1;
if(!query_attack()) {
    n = random(8);
    if (n == 0)
        command("west");
    else if (n == 1)
        command("east");
    else if (n == 2)
        command("south");
    else if (n == 3)
        command("north");
    else if (n == 4)
        command("northwest");
    else if (n == 5)
        command("southwest");
    else if (n == 6)
        command("northeast");
    else if (n == 7)
        command("southeast");
}
call_out("random_move",10);
return 1;
}

