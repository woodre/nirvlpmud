#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

int summon;

reset(arg)
{
  if(arg) return;
  set_light(1);

  set_short(BOLD+"Shrine Room"+NORM);
  set_long(
  "The walls are filled with pictures of different Gremlins killing\n"+
  "people and causing general havoc. Different machine parts lay about \n"+
  "the floor. Clothes and other fabrics lay shredded on the floor.\n"+
  "There is one big picture on the back wall. There are smaller pictures\n"+
  "on the other walls.\n");

       items=({
           "pictures","Pictures of the Gremlins wreaking havoc",
           "picture","A 6 foot tall picture of a Gremlin standing there."+
                     "There is a small plaque on the base of the painting",
           "plaque","It reads: If you wish to meet him, just summon him",
           "walls","Marble walls that have pictures hanging all over them",
           "parts","Pieces of machinery that have been destroyed",
           "clothes","Ripped and torn clothes that are useless",
           "fabrics","Shredded pieces of cloth that have been ripped apart",
             });

  add_exit("/players/syn/shrine/hall2.c","east");
  add_property("NT");
  set_chance(15);
  add_msg("You hear echoing footsteps on the marble floor \n");
  add_msg("The wind blows through your hair\n");
  add_listen("You hear the laughter of some strange creature\n");
  add_smell("You can smell the faint smell of fried chicken\n");
}
void init() {
  ::init();
  add_action("cmd_summon","summon");
}
cmd_summon(str) {
  if(summon == 0) {
  if(!str || str != "gremlin")
    { notify_fail("summon what?\n"); return 0;}
  write("You summon the "+HIG+"Gre"+NORM+""+HIY+"mlin\n"+NORM);
  if(!present("gremlin")) {
        move_object(clone_object("/players/syn/shrine/mobs/gremlin.c"),this_object()); }
  write(HIG+"Grem"+NORM+""+HIY+"lin "+NORM+"rips himself off the painting, and jumps into the room.\n");      
  summon = 1;
  return 1;
}
}
