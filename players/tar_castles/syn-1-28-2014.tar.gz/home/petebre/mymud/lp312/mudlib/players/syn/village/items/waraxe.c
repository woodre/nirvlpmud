#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("axe");
set_alias("hatchet");
set_short("Orcish WarAxe");
set_long(
  "This large double-bladed axe is quite heavy. The blades have been\n"+
  "decorated with various designs and sigils. It has a sharp point at\n"+
  "top of the handle above the blade, and the handle has been wrapped\n"+
  "in leather and is corded. It looks quite deadly.\n");

set_type("axe");  /*  sword/knife/club/axe/bow/polearm  */
set_class(17);
set_weight(3);
set_value(1000);
set_hit_func(this_object());
}

weapon_hit(attacker){
int W;
W = random(19);

if(W>16)  {
  say(""+BOLD+""+BLK+""+environment(this_object())->query_name()+"'s WarAxe becomes ablaze with "+RED+" Flame "+NORM+".\n"+
  "+HIK+"               Fire bursts out from the wound the axe creates."+NORM+"\n");

  write(
  ""+BOLD+""+BLK+"Your WarAxe bursts into"+HIR+" FLAME"+NORM+".\n"+
  ""+HIK+"              Your foe's wound flares up in flame!"+NORM+"\n");
  return 7;
   }
if(W>9)  {
  say(""+HIK+""+environment(this_object())->query_name()+"'s WarAxe pulses with a bright"+RED+" Red Aura "+NORM+".\n"+
  ""+HIK+"         as it strikes at its foe!"+NORM+"\n");

  write(
  ""+HIK+"Your WarAxe pulses with a "+BOLD+""+RED+" Aura "+NORM+".\n"+
  ""+HIK+"                              as you strike your foe!"+NORM+"\n");
  return 3;
   }
return; 
}


