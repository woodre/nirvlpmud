#include <ansi.h>
inherit "obj/armor";

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("vest");
   set_short(GRN+"A Blast Vest"+NORM);
   set_long(
      "Made of a composite material, this armor offers some protection\n"+
      "against melee attacks, blaster shots, and sharpnel. Mostly guards\n"+
      "and Sector Rangers wear these.\n");
   set_ac(3);
   set_type("armor");  
   set_weight(2);
   set_value(1500);
}


do_special(owner) {
  if(!random(15)) {
    tell_object(owner, "Your vest blocks the oncoming attack.\n");
    if(this_player() && this_player()!=owner)
      write(owner->query_name()+"'s vest blocks the attack.\n");
    return 3;
   }
}
