#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("leprechaun");
set_race("creature");
set_short(HIG+"Leprechaun"+NORM);
set_long(
  "A short little man wearing a green suit with gold buckles. His shoes\n"+
  "are polished black, with gold buckles on them. His face is grotesque,\n"+
  "however. His smile is one of most evil thing you have ever seen.\n"+
  "His teeth are rotten and yellow. He looks oddly friendly.\n");

set_level(18);
set_hp(random(400)+1520);
set_al(-800);
set_wc(49);
set_ac(24);
set_heal(10,10);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(10);
  load_chat("Leprechaun rhymes:"+GRN+" Try as they will... try as they might... Who\n"+
  "steals my gold... will not live through the night...\n"+NORM);
  load_chat("Leprechaun says: Ah, the wee people have their magical ways.\n");
  load_chat("Leprechaun says: What do I look like, m'lad? See the hat. The buckles\n"+
  "on my shoes. I'm a Leprechaun. A shoemaker, by trade. And speakin' of shoes..\n"+
  "yours look a mite dirty. They could use a shine.\n"); 


set_a_chat_chance(10);
  load_a_chat("Leprechaun says: Shurr and Begorrah... I feel like I've just been hit by a truck. \n");
  load_a_chat("Leprechaun says: Peek a-boo... I see you!\n");
  load_a_chat("Leprechaun sings: This old Lep, he played one... He played pogo stick\n"+
  "on his lung. With a squish-squash, paddy wack, I just smashed his head... This old\n"+
  "man is surely dead!\n"); 
set_chance(17);
set_spell_dam(random(80)+50);

set_spell_mess1(
   YEL+"o o o oo  ooo o o o o oo o o  oo o o oo o  \n"+
      "o o o  o o o oo  o oo o oo  o o o oo oo   o oo  o\n"+
     " o o oo oo ooo o o o oo o  o oo oo o o o  o oo o o\n"+ 
       " o o o oo o o oo  o o o oo o o o oo oo o o o ooo \n"+NORM
   +"The Leprechaun throws gold coins at his attacker!!!\n");
set_spell_mess2(
   YEL+"o o o o o oo o o o o o  o oo oo o o ooo o o o\n"+
       "o o o o oo o oo o oo o o ooo oo oo oo oo ooo\n"+
      " o o o ooo ooo oo ooo oo oo oo  oooooo   o o ooo\n"+
      " o o o ooo o o o  oo o o oo o o o o oo oo o o o\n"+NORM+
       "The Leprechaun throws gold coins at you!!!\n");

gold = clone_object("obj/money");
gold->set_money(random(2000)+3000); 
move_object(gold,this_object());




}

init(){
  ::init();
    add_action("block_dir","west",1);
    }

block_dir(){
  if(present("leprechaun", environment(this_player()))){
  write("Leprechaun says: No you don't m'lad. You won't be going anywhere.\n");
  say(this_player()->query_name()+" tries to run, but the "+GRN+"Leprechaun"+NORM+" stops him.\n");
  return 1;  }   

}
