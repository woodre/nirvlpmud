			Wierdville, Nirvana.
				copywrite 2004
				Karl Lang (Aka Syn)


	This town is inhabited by infected humans that have turned into
blood oozing monsters. Thier only goal is to fight and attack anything that
smells fresh blood. Every hole in thier entire body seeps blood. They vomit
blood almost continously, and only thirst for more. 

	A small chemical lab was being built by the lake in Wierdville. One of 
the trucks that was carring the virus, was in an accident and it has infected
the town through the air. The scientists in the truck however were infected 
directly with the virus, and 2 of the 4 mutations are able to pass on this
very harmful disease. I hope to make this a extremely rare chance of catching
this disease, but if one does, it will be fatal. The mutations are very strong,
and will be very difficult to kill.

	The Headquarters of BioDerm, the company manufacturing the disease, has
sent in a small squad of robotic investigaters to measure and test all the
findings the town has. They are called Tyrants. There will be 3 of these, and
will be much harder to kill than the mutations. They will have a few pieces of 
really good armor, and maybe a wep or two. These won't be killed very often, 
unless by very high players, or very powerful players.

	Hopefully, I would like to frame some sort of quest in this area. Not 
for quest points per say, but maybe a special wep, or special piece of armor.


Ideas taken from:

Resident Evil 2
28 days later
Silent Hill


If anybody has any ideas or suggestions, please feel free to let me know. If 
anybody would like to contribute anything, again, feel free to let me know.

Thanks

Syn
