#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("ranger");
set_alias("guard");
set_race("human");
set_short(HIG+"Sector"+NORM+HIB+" Ranger"+NORM);
set_long(
"This ranger stands about 6 feet tall, and is very muscular. By looking at him\n"+
"you can tell he is a human, and prepared for battle. You think it might be a\n"+
"good idea to leave him alone.\n"
  );

set_level(26);
set_hp(400+random(200));
set_al(800);
set_wc(30);
set_ac(24);
set_heal(5,5);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Ranger says: Good day, Sir.\n");
  load_chat("Ranger says: Hope your not planning on commiting any crimes here in Dantooine.\n");
  load_chat("Ranger looks you over.\n");
set_a_chat_chance(15);
  load_a_chat("Ranger screams: You won't get away with this!\n");

set_chance(10);
set_spell_dam(100);

set_spell_mess1(
   "The guard and falls back and looks for an opening ...\n"+
                    HIB+"AND LUNGES AT HIS TARGET!\n"+NORM);
set_spell_mess2(
   "The guard rushes you and"+
                  HIY+"      S      L      A      M     S       \n"+NORM+
                                   "    into you!\n");

gold = clone_object("obj/money");
gold->set_money(4000); 
move_object(gold,this_object());



return 0;
}

