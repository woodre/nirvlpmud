#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {

object gold;
object ob;
object ob2;
  
  ::reset(arg);
  if(arg) return;

ob = clone_object("/players/syn/wierdville/items/coat.c");
         move_object(ob,this_object());
         command("wear coat",this_object());

ob2 = clone_object("/players/syn/wierdville/items/scarf.c");
         move_object(ob2,this_object());
         command("wear scarf",this_object());

set_name("tyrant");
set_alias("robot");
set_race("robot");
set_short("Tyrant Model "+BOLD+"23.05"+NORM);
set_long(
  "A very large, humanoid looking robot stands before you. He is wearing a large\n"+
   "thick trenchcoat, and a scarf that wraps around the lower half of his face.\n"+
   "He looks just like he was a person, but has robotic implants and parts.\n"+
   "He face is completely absent of any kind of emotions, feeling or anything else.\n"+
   "You don't think it would be a good idea to fight this machine. He looks very tough.\n"+
   "A mysterious dark purple force seems to flow over the glass of his eyes.\n");
 

set_level(22);
set_hp(random(750)+2000); /* this will be a party kill mob */
set_al(0);
set_wc(35);
set_ac(29);
set_heal(10,5);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("The Tyrant scans the room.\n");
  load_chat("The Tyrant records his visual images in the room.\n");
set_a_chat_chance(10);
  load_a_chat("The Tyrant says: "+BOLD+"Warning. Hostile dectected. Changing to Combat Mode"+NORM+".\n");
  load_a_chat("The Tyrant relentlessly moves forward.\n");
  load_a_chat("The Tyrant scans his foe.\n");

set_chance(13);
set_spell_dam(random(40)+70);

set_spell_mess1(
  "The Tyrant stabs his foe in the chest with his finger.\n"+
  "A "+HIK+"dark"+NORM+""+HIM+" purple"+NORM+" myst flows into thier body. They fall back in pain.\n");

set_spell_mess2(
   "The Tyrant "+HIR+"stabs"+NORM+" you in the chest with his finger.             \n"+
  "A "+HIK+"dark power"+NORM+" flows through your veins.                          \n"+
  "The magical power feels like it is                              \n"+
  HIM+"	         R			                           \n"+
  "			I					   \n"+
  "				P				   \n"+
  "					P			   \n"+		
  "						I		   \n"+									 													
  "				                	G          \n"+NORM+
  "                                                           you to pieces. \n");
  
gold = clone_object("obj/money");
gold->set_money(random(1000)+4000); 
move_object(gold,this_object());

}

monster_died() {
  move_object(clone_object("obj"),
      environment(this_object()));
  tell_room(environment(this_object()),
        "A "+HIK+"dark"+NORM+" "+HIM+"purple myst"+NORM+" flows from the openings in the corpse and disipates into the air. \n");
return 0; 

}


heart_beat(){
 ::heart_beat();
    if(!random(13) && attacker_ob) big_special();


}

init(){
  ::init();
    add_action("block_dir","west",1);
    add_action("block_dir","east",1);
    add_action("block_dir","north",1);
    add_action("block_dir","south",1);
    }

block_dir(){
  if(present("tyrant", environment(this_player()))){
  write("The Tyrant reaches out and grabs you by the neck, and throws you back into the room.\n");
  say(this_player()->query_name()+" flys back across the room, and slams into the wall.\n"+
      "Tyrant says: You may not leave, you have seen too much. \n");
  attacker_ob->hit_player(-10);   /* Hurts player if they wimpy */
  return 1; }

}

big_special(){
	if(environment()) 
        switch(random(3))  {
		
		case 2:
		say("The Tyrant throws both of his hands out in front of him.\n"+ 
                    "A "+HIK+"dark"+NORM+" "+HIM+"purple ball of myst"+NORM+" shoot's out and slams into "+attacker_ob->query_name()+" \n",({ attacker_ob }));
		tell_object(attacker_ob,"The Tyrant throws both of his hands out in front of him, and shoot's a "+HIK+"dark"+NORM+" \n"+
                                        HIM+"        purple ball of myst"+NORM+" into you.\n"+
                                    HIR+"                        You blood feels like its on fire. \n"+NORM); 
		attacker_ob->hit_player(-25);
		break;
		
		case 1:
		say(""+attacker_ob->query_name()+" is covered in a "+HIK+"dark"+NORM+" "+HIM+"purple myst"+NORM+".\n",({ attacker_ob}));
		tell_object(attacker_ob,"A "+HIK+"dark"+NORM+" "+HIM+"purple myst"+NORM+" flows around your body.\n"+
                                        HIC+"You feel frozen to the bone.\n"+NORM+
                                        "It becomes more and more difficult to breathe.\n"+
                                        "                                        \n"+
                                        "                                        \n"+
                                        "You finally start to breathe again.\n");
		attacker_ob->hit_player(-20);
		break;
		
		case 0:
		say("The Tyrant chants a few words as he throws a hard punch. A "+HIK+"dark explosion"+NORM+" erupts as the hit connects."+attacker_ob->query_name()+" \n",({ attacker_ob}));
		tell_object(attacker_ob,"The Tryant punches you in the chest, and a "+HIK+"dark explosion"+NORM+" at the point of impact sends you flying back. \n");
		attacker_ob->hit_player(-15);
		break;
  
  }

}


