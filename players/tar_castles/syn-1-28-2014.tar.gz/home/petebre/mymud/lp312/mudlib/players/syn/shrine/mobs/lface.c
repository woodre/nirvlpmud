#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold; 
object ob;
  ::reset(arg);
  if(arg) return;

       
set_name("leatherface");
set_alias("man");
set_race("human");
set_short("Leatherface");
set_long(
   "Leatherface is large hulking man. He stands about 6ft 3in tall. He must\n"+
   "weigh close to 300lbs. He is wearing a bloody white butcher's coat, black\n"+
   "pants, a white shirt, and thick black boots. He is also wearing a mask that\n"+
   "appears to be leather, but it looks a bit different. All of his teeth are missing.\n"+
   "He appears to need a bath quite badly.\n");
 

set_level(23);
set_hp(random(300)+1800);
set_al(-1600);
set_wc(40);
set_ac(30);
set_heal(5,5);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Leatherface grunts at you.\n");
  load_chat("Leatherface starts REVVING his chainsaw.\n");
set_a_chat_chance(10);
  load_a_chat("Leatherface rushes into you, slamming you hard against the wall.\n");
  load_a_chat("Leatherface\n"+RED
              +" ------| REVVS |---------- \n"+NORM
              +"                 his chainsaw through you.\n");

set_chance(13);
set_spell_dam(random(50)+70);

set_spell_mess1(
      "Leatherface "+RED+"runs "+NORM+" his chainsaw into his attacker.     \n"+
      RED+"            Blood flies from the wound, and splatters on the wall.\n"+NORM);
set_spell_mess2(
      HIK+"Leatherface runs the chainsaw into your stomach.\n"+
          "He REVVS the blade and you feel your insides cut,\n"+   
          "torn, and ripped from inside out.\n"+
          RED+"The chuncks of flesh, bone, blood splatters on the wall behind you.\n"+NORM
          +"The chainsaw is pulled from your gaping wound, with a slooshing sound.\n");



ob = clone_object("/players/syn/shrine/items/chainsaw.c");
         move_object(ob,this_object());
         command("wield chainsaw",this_object());


gold = clone_object("obj/money");
gold->set_money(random(2000)+4000); 
move_object(gold,this_object());

}

heart_beat(){
 ::heart_beat();
    if(!random(18) && attacker_ob) big_special();

}

big_special(){
	if(environment())
	tell_room(environment(),
       HIK+"Leatherface rears back .........\n"+NORM); 

switch(random(2))  {
		
		case 1:
		say(" and \n"+
                                        HIK+"         slams into     \n"+NORM
                                                       +attacker_ob->query_name()+" pining him to the wall.\n",({ attacker_ob }));
		tell_object(attacker_ob," and                              \n"+
					"       "+HIK+"  slams into     \n"+NORM
					+""+attacker_ob->query_name()+" pining you to the room.\n");  
		attacker_ob->hit_player(45);
		break;
		
		case 0:
		say(" .....thrusts the chainsaw into "+attacker_ob->query_name()+", spilling"+RED+" blood "+NORM+"everywhere.\n",({ attacker_ob }));
		tell_object(attacker_ob,"....thrusts the chainsaw into you, spilling "+RED+"blood"+NORM+" everywhere.\n");
		attacker_ob->hit_player(30);
		break;
  
  }

}


