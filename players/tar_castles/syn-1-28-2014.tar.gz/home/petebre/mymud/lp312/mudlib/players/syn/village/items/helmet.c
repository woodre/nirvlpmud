#include "/players/syn/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("helmet");
set_alias("leather");
set_short("Leather helmet");
set_long(
  "A helmet made from sheep leather. Two long straps hang\n"+
  "loosly around your ears. They are decorted with feathers\n"+
  "and glass beads. A large flap folds down over your eyes and\n"+
  "two large holes are cut for your eyes.\n");

set_ac(1);
set_type("helmet");  /* armor,helmet,boots,ring,amulet,shield,misc  */
set_weight(1);
set_value(200);
set_arm_light(0);  /*  makes armor glow if it's > 0  */
}

