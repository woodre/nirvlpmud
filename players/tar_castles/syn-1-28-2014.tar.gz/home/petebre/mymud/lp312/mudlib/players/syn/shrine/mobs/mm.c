#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold; 
object ob;
  ::reset(arg);
  if(arg) return;

       
set_name("myers");
set_alias("michael");
set_race("human");
set_short("Michael Myers");
set_long(
  "Michael is about 6 ft tall. He is a hulking man, wearing a jumpsuit\n"+
   "with a Dickies emblem on the shirt pocket. He has black work boots. He\n"+
   "has on a pale white mask, that has thick, coarse, brown horsehair on the\n"+
   "top. It looks like your traditional halloween mask.\n");
 

set_level(23);
set_hp(random(550)+1900);
set_al(-1600);
set_wc(42);
set_ac(29);
set_heal(25,15);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Michael stands in front of you, staring intently.\n");
  load_chat("Michael says nothing.\n");
set_a_chat_chance(10);
  load_a_chat("Michael strafes to the left..........\n"+
              HIW+"        He LUNGES at his attacker!!!     \n"+NORM);
  load_a_chat("Michael\n"+RED
              +" ------| stabs |---------- \n"+NORM
              +"        his attacker in the chest with his knife.\n");

set_chance(13);
set_spell_dam(random(50)+90);

set_spell_mess1(
  HIR+"     /   /   \n"+
      "    /   /    \n"+   
      "   /   /     \n"+
      "  /   /      \n"+NORM
  +""+RED+"             Michael slashes a gaping hole in his attacker.\n"+NORM);
set_spell_mess2(
      HIR+"          /    / \n"+
          "         /    /  \n"+   
          "        /    /   \n"+
          "       /    /    \n"+
          "      /    /     \n"+NORM
         +""+RED+"      Michael slashes a gaping hole in you.\n"+NORM
  +"You feel blood pour from your wound.\n"+
  "A huge chuck of your flesh is"+HIR+" CUT "+NORM+"from your body.\n");



ob = clone_object("/players/syn/shrine/items/knife.c");
         move_object(ob,this_object());
         command("wield knife",this_object());


gold = clone_object("obj/money");
gold->set_money(random(2000)+3000); 
move_object(gold,this_object());

}

heart_beat(){
 ::heart_beat();
    if(!random(18) && attacker_ob) big_special();


}

init(){
  ::init();
    add_action("block_dir","east",1);
    }

block_dir(){
  if(present("michael", environment(this_player()))){
  write("Michael stands in front of you, blocking your exit.\n"+NORM);
  say(this_player()->query_name()+" tries to leave, but Michael stands in thier way.\n");
  return 1; }

}

big_special(){
	if(environment())
	tell_room(environment(),
       HIK+"Michael rears back .........\n"+NORM); 

switch(random(3))  {
		
		case 1:
		say(" ......and \n"+
                HIW+"         / s / l / a / s/ h / e/ s/     \n"+NORM
                                 +attacker_ob->query_name()+" opening his throat.\n",({ attacker_ob }));
		tell_object(attacker_ob,"....and        \n"+
					"      / s / l / a / s / h / e / s  \n"+
					" 			you across the neck, slicing your throat open.\n");
		attacker_ob->hit_player(40);
		break;
		
		case 0:
		say(" .....and rushes into "+attacker_ob->query_name()+", slaming into his body.\n"+NORM,({ attacker_ob }));
		tell_object(attacker_ob,"... and rushes into you, slamming your body against the wall behind you.\n");
		attacker_ob->hit_player(30);
		break;
		
		
  }

}


