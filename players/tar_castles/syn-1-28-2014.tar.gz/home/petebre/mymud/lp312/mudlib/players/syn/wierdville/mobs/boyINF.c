#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("boy");
set_alias("child");
set_alt_name("infected");
set_race("human");
set_short("A small boy "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "A small boy with a fire truck shirt and ripped blue jeans. His face is covered\
 with blood, and most of his clothes are too. He looks dirty and tired. His eyes\
 are completely blood red. He has a hungry look on his face.\
 ");

set_level(12);
set_hp(180);
set_al(0);
set_wc(16); 
set_ac(9);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat("The boy yells : I smell FLESH!\n");
  load_a_chat("The boy asks : Where's my Mommy and Daddy?\n"); 

gold = clone_object("obj/money");
gold->set_money(300+random(300)); 
move_object(gold,this_object());

set_chance(12);
set_spell_dam(random(10)+10);

set_spell_mess1(
   RED+" /      /        /          /       /       /   \n"+
      " /      /        /          /       /       /    \n"+
     " /      /        /          /       /       /     \n"+ 
     "/      /        /          /       /       /      \n"+NORM
   +"The boy scatches "+this_player()->query_name()+" fiercly!!!\n");
set_spell_mess2(
   RED+"         /     /        /        /       /       / \n"+
       "   /    /     /        /        /       /       /  \n"+
      "   /    /     /        /        /       /       /   \n"+
      "  /    /     /        /        /       /       /    \n"+NORM+
 "The boy scratches you, and "+RED+" blood "+NORM+" pours from your wound.\n"+NORM);


return 0;
}


