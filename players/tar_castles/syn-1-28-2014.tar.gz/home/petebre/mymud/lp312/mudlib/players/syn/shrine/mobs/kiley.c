#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
  ::reset(arg);
  if(arg) return;

set_name("kiley");
set_alias("child");
set_alt_name("girl");
set_race("human");
set_short("Kiley "+RED+"("+NORM+"Daughter"+RED+")"+NORM);
set_long(
  "Kiley is about 12 years old. She has long blonde hair, and\n"+
  "blue eyes. She is always smiling, and in a happy mood. She is\n"+
  "having fun playing hide and go seek with her brother.\n");

set_level(10);
set_hp(450);
set_al(0);
set_wc(15);
set_ac(9);
set_heal(5,10);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Kiley says: Have you seen my brother?\n");
  load_chat("Kiley says: I found you! Hahahaa\n");
set_a_chat_chance(15);
  load_a_chat("Kiley yells: Mommy! Daddy! The Bad person is hitting me!\n");
}

