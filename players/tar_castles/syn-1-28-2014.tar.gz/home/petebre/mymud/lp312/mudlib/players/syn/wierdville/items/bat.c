#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

int W,dam;

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("bat");
set_alias("easton");
set_short(BOLD+"A metal bat"+NORM);
set_long(
  "A metal bat with the words EASTON printed real big. It has a black\n"+
  "rubber grip along the handle, and feels REALLY light. It looks like\n"+
  "it could be really useful for hitting home runs or bashing Zombie's\n"+
  "brains in.\n");
set_type("club");
set_class(18);
set_weight(1);
set_value(1400);
set_hit_func(this_object());
message_hit = ({
        BOLD+"bashed"+NORM," brains in",
        BOLD+"clanked"+NORM," across the face",
        BOLD+"thumped"+NORM," in the head",           
        BOLD+"smacked"+NORM," on the back",
        BOLD+"hit"+NORM," on the arm",
        BOLD+"tapped"+NORM," with the hilt of the bat",
        BOLD+"swung wildly at"+NORM," barely missing"
        });
set_save_flag(1);


return 0;
}

