#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

int W,dam;

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("knife");
set_alias("butchers knife");
set_short(HIW+"A butcher's knife"+NORM);
set_long(
  "A butcher's knife commonly used by chef's and mom's everywhere to cook.\n"+
  "This one has a thick, black plastic hilt, and a thick, wide blade. It was\n"+
  "used by Micheal Myers to murder people in Smith's Groove, IL. on in 1978.\n"+
  "It still has a little dryed blood on the base of the blade.\n");
set_type("knife");
set_class(18);
set_weight(2);
set_value(2000);
set_hit_func(this_object());
set_save_flag(1);
}


weapon_hit(attacker) {
W = random(10);
switch(W) {
         
         
    case 1:
       say(this_player()->query_name()+ " slashes his opponent.\n"+RED
       +" Blood pours from the wound.\n"+NORM);
       write("You slash deeply, causing"+RED+" blood "+NORM+"to flow. \n");
       return 10;
       break;
  
    case 2:
       say(HIK+""+this_player()->query_name()+" cuts his opponet's throat.\n"+NORM);
       write("You "+HIR+" S / L / I / C / E "+NORM+" your opponet's throat.\n");
       return 15;
       break;

    case 3:
       say(this_player()->query_name()+""+RED+" stabs "+NORM+"his victim, and "+RED+"blood flows.\n"+NORM);
       write("You "+RED+"stab"+NORM+" your opponet, opening a gaping wound.\n");
       return 13;
       break; 

 

       attacker->heal_self(-dam);
       break;
   }
return;
}

