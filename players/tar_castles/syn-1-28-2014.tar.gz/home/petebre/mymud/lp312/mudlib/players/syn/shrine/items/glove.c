#include "/players/syn/ansi.h"
inherit "/obj/weapon.c";


int limit = 5;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_id("glove");
   set_alias("knife");
   set_short(HIK+"A finger-bladed glove"+NORM);
   set_long(
  "This is the infamous glove of Freddy Krueger himself.\n"+
  "It is a small brown glove, with four 6in. long blades\n"+
  "from the tips of four of fingers. This glove has \n"+
  "tasted the blood of many victims. It looks quite dangerous.\n");
   set_weight(4);
   set_class(19);
   set_value(2500);
   set_type("staff");
message_hit = ({
        HIR+"slice"+NORM," across the face",
        RED+"stab"+NORM," in the gut",
        RED+"slash"+NORM," across the chest",           
        BOLD+"cut"+NORM," across the back",
        HIY+"shred"+NORM," the skin from bone",
        YEL+"hacked"+NORM," on the leg",
        BOLD+"cut"+NORM," on the hand"
        });
   set_hit_func(this_object());
}
init() {
   ::init();
}
weapon_hit(attacker) {

    status heh;

   if(!heh)
   if(random(100) < 33  && limit > 0) {
   heh = 1;
   this_player()->attack();
   heh = 0;
   limit --;
     return 1;}
  else { 
    limit = 5;
return 3;}
   
 }


