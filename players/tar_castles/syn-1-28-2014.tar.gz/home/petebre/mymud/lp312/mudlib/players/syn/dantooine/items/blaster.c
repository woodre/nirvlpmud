#include <ansi.h>
inherit "obj/weapon";

int ammo;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_name("blaster");
  set_alias("pistol");
  set_short(HIW+"Heavy Blaster Pistol"+NORM);
  set_long(
"A BlasTech DL-44 heavy blaster pistol. It is a variation of the light\n"+
"blaster pistol, but can do more damage. Its slick stock design allows\n"+
"allows for a quicker draw, and is widely excepted as the standard pistol\n"+
"in the glaxay.\n");
  set_class(16);
  set_weight(2);
  set_value(2500);
  ammo=12;
  set_hit_func(this_object());
  message_hit=({
    HIR+"blew"+NORM," away",
    HIB+"blasts"+NORM," in the chest",
    HIW+"shot"+NORM," with expert accuracy",
    HIM+"shot"+NORM," high in the shoulder",
    HIC+"hit"+NORM," in the leg",
    HIG+"winged"+NORM," in the lower leg",
    HIY+"grazed"+NORM," with a glancing shot",
  });
}
int weapon_hit(object attacker)
{
  object clip;
  if(ammo<=0) {
    clip=present("powercell");
    if(!clip) return -3;
    ammo+=(int)clip->reload();
    write("You reload your Blaster.\n");
    return -2;
  }
  if(!random(3)) {
    ammo--;
    write((string)this_player()->query_name()+" fires "+(string)this_player()->query_possessive()+" the blaster!\n");
    return 5;
  }
  return 0;
}
void long(string str) {
  ::long(str);
  write("Ammo: "+ammo+"\n");
}
