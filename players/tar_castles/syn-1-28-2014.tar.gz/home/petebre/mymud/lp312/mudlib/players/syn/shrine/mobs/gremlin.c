#include "/players/syn/ansi.h"
inherit "obj/monster.c";

object gold;
object bah;
int doof;

reset(arg)  {
  ::reset(arg);
  if(arg) return;

set_name("gremlin");
set_race("mogwai");
set_short(HIY+"Grem"+NORM+GRN+"lin"+NORM);
set_long(
  "A short little green creature with faint yellow spots that cover its\n"+
  "body. He has long pointy ears and razor sharp teeth. His eyes are wild\n"+
  "and he looks like he is constantly smiling. He isn't very nice.\n");

set_level(17);
set_hp(random(100)+1020);
set_hp_bonus(100);
set_al(-800);
set_wc(47);
set_ac(21);
set_heal(5,10);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Gremlin runs around the store causing chaos.\n");
  load_chat("Gremlin finds a pack of smokes and a lighter. He fires one up.\n");
  load_chat("Gremlin laughs maniacally.\n"); 


set_a_chat_chance(17);
  load_a_chat("Gremlin ducks and dodges, making you miss.\n");
  load_a_chat("Gremlin jumps around, quickly dodging your attacks.\n"); 
set_chance(12);
set_spell_dam(random(30)+30);

set_spell_mess1(
   RED+" /      /        /          /       /       /   \n"+
      " /      /        /          /       /       /    \n"+
     " /      /        /          /       /       /     \n"+ 
     "/      /        /          /       /       /      \n"+NORM
   +"The Gremlin scatches "+this_player()->query_name()+" fiercly!!!\n");
set_spell_mess2(
   RED+"         /     /        /        /       /       / \n"+
       "   /    /     /        /        /       /       /  \n"+
      "   /    /     /        /        /       /       /   \n"+
      "  /    /     /        /        /       /       /    \n"+NORM+
       HIG+"The gremlin scatches you, and "+RED+" blood "+NORM+HIG+" pours from your wound.\n"+NORM);


gold = clone_object("obj/money");
gold->set_money(3000); 
move_object(gold,this_object());

}


init(){
  ::init();
    add_action("block_dir","east",1);
    }

heart_beat(){
 ::heart_beat();
    if (!random(15) && this_object()->query_hp() < 200 && doof <= 1) copy();
    }

block_dir(){
  if(present("gremlin", environment(this_player()))){
   write("Gremlin jumps in your way so you can't leave.\n");
   say(this_player()->query_name()+" tries to run, but the Gremlin jumps in the way.\n");
   return 1; }
} 

copy(){

   if (doof == 0) {
   bah = clone_object("/players/syn/shrine/mobs/gremlin2.c");
   move_object(bah, environment(this_object()));
   doof = 2;
   return 1; }
}


