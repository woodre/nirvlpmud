#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("man");
set_alias("man");
set_alt_name("infected");
set_race("human");
set_short("A man "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "A tall, muscular man that stands about six foot two inches. He is shirt less\
 and has cuts and wounds all over his body. He is bleeding from every hole in\
 his body. Tears of blood stream down his face. There is some humanity left in\
 those eyes, but he has lost all control over his actions.\
  ");

set_level(17);
set_hp(300+random(100));
set_al(0);
set_wc(24); 
set_ac(14);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat("The man yells : I smell FLESH!\n");
  load_a_chat("The man yells : I will KILL YOU!\n"); 

gold = clone_object("obj/money");
gold->set_money(2000+random(500)); 
move_object(gold,this_object());


return 0;
}


