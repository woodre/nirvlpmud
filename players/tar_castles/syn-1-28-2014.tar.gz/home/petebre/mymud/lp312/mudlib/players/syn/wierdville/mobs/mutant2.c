#include <ansi.h>
inherit "obj/monster.c";


object gold;
object ob;

reset(arg)  {

  ::reset(arg);
  if(arg) return;


ob = clone_object("/players/syn/wierdville/items/blade.c");
move_object(ob,this_object());
command("wield blade",this_object());

set_name("mutant");
set_alias("one");
set_alt_name("mutation");
set_race("human");
set_short("Mutation"+BOLD+" tWo "+NORM+" "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "This hulking beast, was once a man. His face is no more, but you can see a blood eye\
 on the top of his left arm. He is wearing the remains of a white shirt, and his pants\
 are covered in blood, and flesh. It appears as if was a scientist, by his white lab coat,\
 before his transformation into the ugly shell of a man he is. He looks more dangerous than\
 than mutation one.\
");

set_level(23);
set_hp(800+random(300));
set_al(-1000);
set_wc(40);
set_ac(29);
set_wc_bonus(6);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat("The Mutant growls noisly.\n");
  load_a_chat("The Mutant "+HIR+"vomits blood "+NORM+"all over the floor.\n"); 
  load_a_chat("The Mutant dodges the attack.\n");

gold = clone_object("obj/money");
gold->set_money(4000+random(1500)); 
move_object(gold,this_object());

set_chance(12);
set_spell_dam(random(50)+85);

set_spell_mess1(
     " The"+RED+"   B            \n"+
     "           E         \n"+
     "              A      \n"+ 
     "                 S   \n"+
     "                   T \n"+NORM+
     "                      grabs his foe and"+HIC+"   t h r o w s"+NORM+" them across the room.\n");
set_spell_mess2(
     " The"+RED+"   B            \n"+
     "           E         \n"+
     "              A      \n"+ 
     "                 S   \n"+
     "                   T \n"+NORM+
     "                      grabs you and   "+HIC+"t h r o w s"+NORM+"  you into the wall!\n");



}

init(){
  ::init();
    add_action("block_dir","east",1);
    add_action("block_dir","west",1);
    add_action("block_dir","north",1);
    add_action("block_dir","south",1);
    add_action("block_dir","out",1);
    }


block_dir(){
  if(present("mutant", environment(this_player()))){
   write("Mutation "+BOLD+"tWo"+NORM+" moves in your way, blocking your exit.\n");
   say(this_player()->query_name()+" tries to run, but the Mutation "+BOLD+"tWo"+NORM+" blocks the way.\n");
   return 1; }
}

heart_beat(){
 ::heart_beat();
    if(!random(5) && attacker_ob) big_special();
} 


big_special(){
	if(environment()) 
	switch(random(3)) 
	       {
		
		case 2:
		say("The Mutation"+BOLD+" tWo "+NORM+""+RED+" ======| slashes|======\n"+NORM+
                                        ""+attacker_ob->query_name()+" across the chest.\n",({ attacker_ob }));
		tell_object(attacker_ob,"                 The Mutation"+BOLD+" tWo "+NORM+""+RED+" ====| slashes |==== "+NORM+"you across the chest.\n"+
                                        "          "+RED+"Blood"+NORM+" pours from your open wound. The cut is deep.\n");
		attacker_ob->hit_player(-30+random(20));
		break;
		
		case 1:
		say(""+attacker_ob->query_name()+" gets "+RED+"stabbed"+NORM+" in the neck.\n",({ attacker_ob}));
		tell_object(attacker_ob,"                 Mutation"+BOLD+" tWo "+NORM+""+RED+"stabs"+NORM+" you in the neck.\n");
		attacker_ob->hit_player(-20+random(10));
		break;
		
		case 0:
		say("Mutation"+BOLD+" tWo "+NORM+""+RED+"slashes"+NORM+" "+attacker_ob->query_name()+" across the back.\n",({ attacker_ob}));
		tell_object(attacker_ob,"                 Mutation"+BOLD+" tWo "+NORM+""+RED+"slashes"+NORM+" you across the back.\n");
		attacker_ob->hit_player(-15+random(5));
		break;
  
  }

}




