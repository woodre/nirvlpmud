#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

int summon;

reset(arg)
{
  if(arg) return;
  set_light(1);

  set_short(BOLD+"Shrine Room"+NORM);
  set_long(
  "The wall is completely bare. There is only one picture that hangs\n"+
  "on the pitch black walls here. This room leaves little to do.\n");

       items=({
           "picture","A 6 foot tall picture of a shiny metal box standing there."+
                     "There is a small plaque on the base of the painting",
           "plaque","It reads: If you wish to meet him, just summon him",
           "walls","Marble walls that have been painted black. To cover something maybe?",
             });

  add_exit("/players/syn/shrine/hall3.c","west");
  add_property("NT");
  set_chance(15);
  add_msg("You hear echoing footsteps on the marble floor \n");
  add_msg("The wind blows through your hair\n");
  add_listen("You hear a small clicking sound\n");
  add_smell("You can smell rotting flesh coming from somewhere in this room\n");
}
void init() {
  ::init();
  add_action("cmd_summon","summon");
}
cmd_summon(str) {
  if(summon == 0) {
  if(!str || str != "pinhead")
    { notify_fail("summon what?\n"); return 0;}
  write("You summon "+HIK+"Pinhead\n"+NORM);
  if(!present("pinhead")) {
        move_object(clone_object("/players/syn/shrine/mobs/pinhead.c"),this_object()); }
  write(HIK+"Pinhead"+NORM+" materalizes in front of you.\n");      
  summon = 1;
  return 1;
}
}
