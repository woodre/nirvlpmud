#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

reset(arg) {

         if(!present("kiley")) {
        move_object(clone_object("/players/syn/shrine/mobs/kiley.c"),this_object()); }

     set_light(1);
     short_desc = (HIW+"Shrine Hallway"+NORM);
     long_desc = 
"A large hallway with walls made of white marble. It is completely clean \n\
and shiny. There is a picture to the east, with a doorway next to it. \n\
There is another picture to the west, with a doorway next to it.  \n\
The hallways extends further to the north. South will lead you back down \n\
the hallway.\n";

      items=({
           "marble","White marble stone, with black onyx chips in it",
           "walls","They are white and black marble walls. Pictures hang on them.",
	   "picture","Picture to the east shows a pentagram, with an old book on the picture. The"+
                     " picture to the west shows a picture of gremlin on it.",
           "doorway"," A doorway with no door. The room beyond is completely black, however",
           "book","A leather bound book, with a pentagram on the cover",
           "gremlin","A small green and yellow creature with pointy ears. It seems to be grining",
             });
      add_property("NT");   
      add_exit("/players/syn/shrine/hall3.c","north");
      add_exit("/players/syn/shrine/hall1.c","south");
      add_exit("/players/syn/shrine/warroom.c","east");
      add_exit("/players/syn/shrine/gremroom.c","west");
            
}
      init() {
         ::init();
           add_action("listen","listen");
           add_action("search_room","search");
	   add_action("smell","smell");
             }


      listen()  {
          write("You hear echoing footsteps on the marble floor.\n");
          say (this_player()->query_name() +" listens intently.\n");
          return 1;
              }

      search_room() {
          write("You find nothing.\n");
          say (this_player()->query_name()+" searches the area. \n");
          return 1;
                }

      smell()  {
          write("You smell rotting flesh, and freshly spilt blood high on the air.\n");
          say (this_player()->query_name() +"'s nose sniffs the air.\n");
          return 1;
               }
 


