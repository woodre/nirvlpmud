#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("jawa");
set_alias("jawa");
set_race("jawa");
set_short(RED+"Jawa"+NORM);
set_long(
  "A small humanoid creature wearing a brown hooded cloak. Jawa's\n"+
  "are intelligent scavengers of the planet Tantooine. This Jawa\n"+
  "stands no more than 1 meter high, and looks pretty peaceful.\n");
set_level(14);
set_hp(150);
set_al(0);
set_wc(15); 
set_ac(11);
set_heal(2,10);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(12);
  load_chat(HIY+"Jawa says: Ales chewake waanejbe boetik ta ktesa.\n"+NORM);
set_a_chat_chance(15);
  load_a_chat(CYN+"Jawa screams: AAAAhh! Twaskennee, Twaskenee!\n"+NORM);

set_chance(5);
set_spell_dam(10);

set_spell_mess1(
  "Jawa"+HIR+" smashes "+NORM+"him with a rock.\n");
set_spell_mess2(
  "Jawa"+HIR+" smashes "+NORM+"you with a rock.\n");

gold = clone_object("obj/money");
gold->set_money(100); 
move_object(gold,this_object());


return 0; 
}

