#include "/players/syn/ansi.h"
inherit "obj/monster.c";



reset(arg)  {
object ob;
  ::reset(arg);
  if(arg) return;

set_name("wolf"); 
set_alt_name("beast");
set_race("beast");
set_short("A wolf "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "A large gray and white wolf stands in front of you. This viscious animal seems to be\
 bleeding from the eyes and mouth as well. Its razor sharpe teeth are still dangerous\
 as ever though. The things have always been know to hunt in packs, so where there is one\
 there is bound to be more. You should watch yourself when dealing with this wolf.\n"+
 "");

set_level(19);
set_hp(450+random(100));
set_al(-100);
set_wc(28); 
set_ac(16);
call_out("random_move",15);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat(BOLD+"The wolf huffs.\n"+NORM);
  load_a_chat(BOLD+"The wolf stares intently.\n"+NORM);
  load_a_chat(BOLD+"The wolf howls loudly.\n"+NORM); 

ob = clone_object("/players/syn/wierdville/items/wfur.c"); 
move_object(ob,this_object());

set_chance(12);
set_spell_dam(random(25)+20);

set_spell_mess1(
   "The wolf bites down into "+this_player()->query_name()+" flesh, and "+HIR+"blood"+NORM+" splashes everywhere.\n");
set_spell_mess2(
   "The wolf bites down into your flesh, and "+HIR+"r i p s"+NORM+" a chunk from your arm.\n"+ 
   "                       "+HIR+"Blood gushes everywhere"+NORM+".\n");


return 0;
}

random_move() {
    int n;
  if(!environment()) return 1;
if(!query_attack()) {
    n = random(8);
    if (n == 0)
        command("west");
    else if (n == 1)
        command("east");
    else if (n == 2)
        command("south");
    else if (n == 3)
        command("north");
    else if (n == 4)
        command("northwest");
    else if (n == 5)
        command("southwest");
    else if (n == 6)
        command("northeast");
    else if (n == 7)
        command("southeast");
}
call_out("random_move",10);
return 1;
}

heart_beat(){
 ::heart_beat();
    if(!random(13) && attacker_ob) big_special();

    }
big_special(){
        object mon;
	if(environment()) 
        switch(random(3))  {
		
		case 2:
		say("The wolf charges at "+attacker_ob->query_name()+" and leaps into the air\n"+
                    "                                               "+HIR+"ripping chucks of flesh"+NORM+" out.\n",({ attacker_ob }));
		tell_object(attacker_ob,"The wolf sprints at you, and leaps high into the air.\n"+
                                        "        It lands on your chest, and starts "+HIR+"ripping chucks of flesh\n"+NORM+
                                        "                                                                       from your body.\n"); 
		attacker_ob->hit_player(-20);
		break;
		
		case 1:
		say("The wolf bites down hard into "+attacker_ob->query_name()+" skin.\n",({ attacker_ob}));
		tell_object(attacker_ob,"The wolf "+HIK+"bites"+NORM+" down hard into your flesh.\n"+
                                        HIR+"             Warm blood flows around your wound.\n"+NORM+
                                        "                       Blood falls to the ground in large drops.\n");
		attacker_ob->hit_player(-15);
		break;
		
		case 0:
		mon = clone_object("/players/syn/wierdville/mobs/wolf.c");
  		move_object(mon,environment(this_object()));
  		tell_object(attacker_ob,BOLD+"A another wolf arrives to assist.\n"+NORM);
		say(BOLD+"Another wolf arrives to help in the fight!\n"+NORM, attacker_ob);
  		mon->attacked_by(attacker_ob);
		
  
  }

}
