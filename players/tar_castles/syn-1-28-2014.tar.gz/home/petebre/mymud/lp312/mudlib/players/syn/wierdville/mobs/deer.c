#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object ob;
  ::reset(arg);
  if(arg) return;

set_name("deer"); 
set_alt_name("doe");
set_race("beast");
set_short("A deer "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "This once peaceful creature is now a ravenous, bloodthirsty beast. Its wide,\
 blood shot eyes leak blood from the coners continously. It mouth is open wide\
 looking for its next fresh meal. The hoofs are cracked and broken into sharpe\
 points, and look very dangerous. The skin is dirty and caked with blood.\n"+
 "");

set_level(17);
set_hp(400);
set_al(-100);
set_wc(24); 
set_ac(14);
call_out("random_move",15);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat(BOLD+"The deer huffs.\n"+NORM);
  load_a_chat(BOLD+"The deer stares.\n"+NORM); 

ob = clone_object("/players/syn/wierdville/items/dskin.c"); 
move_object(ob,this_object());

set_chance(12);
set_spell_dam(random(25)+20);

set_spell_mess1(
   "The deer rears back and "+HIR+" K I C K S "+NORM+" "+this_player()->query_name()+" in the stomach.\n");
set_spell_mess2(
   "The deer rears his back legs back and "+CYN+"K I C K S"+NORM+" you in the stomach\n"+ 
   "              It feels like your stomache is trying to come up through your throat.\n"+
   "                                     You throw up "+HIR+"blood"+NORM+" everywhere.\n");


return 0;
}

random_move() {
    int n;
  if(!environment()) return 1;
if(!query_attack()) {
    n = random(8);
    if (n == 0)
        command("west");
    else if (n == 1)
        command("east");
    else if (n == 2)
        command("south");
    else if (n == 3)
        command("north");
    else if (n == 4)
        command("northwest");
    else if (n == 5)
        command("southwest");
    else if (n == 6)
        command("northeast");
    else if (n == 7)
        command("southeast");
}
call_out("random_move",10);
return 1;
}



