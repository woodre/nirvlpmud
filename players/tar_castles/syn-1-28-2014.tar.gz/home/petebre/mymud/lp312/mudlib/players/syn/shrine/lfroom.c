#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

int summon;

reset(arg)
{
  if(arg) return;
  set_light(1);

  set_short(BOLD+"Shrine Room"+NORM);
  set_long(
  "The walls are filled with pictures of a white house in Texas.\n"+
  "The floor is covered in dirt, and you see bone fragments laying everwhere. \n"+
  "There is one big picture on the back wall. There are smaller pictures\n"+
  "on the other walls.\n");

       items=({
           "pictures","Pictures of small white house in Texas. Its looks run down",
           "picture","A 6 foot tall picture of Leatherface standing there."+
                     "There is a small plaque on the base of the painting",
           "plaque","It reads: If you wish to be dinner, just summon Leatherface",
           "walls","Marble walls that have pictures hanging all over them",
           "floor","The floor is covered in dirt.",
           "fragments","Pieces of bones lay everywhere on the floor of this room",
             });

  add_exit("/players/syn/shrine/hall4.c","east");
  add_property("NT");
  set_chance(15);
  add_msg("You hear echoing footsteps on the marble floor \n");
  add_msg("The wind blows through your hair\n");
  add_listen("You hear the starting of chainsaw off in the distance\n");
  add_smell("You can smell the thick hearty smell of cooking chili\n");
}
void init() {
  ::init();
  add_action("cmd_summon","summon");
}
cmd_summon(str) {
  if(summon == 0) {
  if(!str || str != "leatherface")
    { notify_fail("summon what?\n"); return 0;}
  write("You summon Leatherface.\n"+NORM);
  if(!present("leatherface")) {
        move_object(clone_object("/players/syn/shrine/mobs/lface.c"),this_object()); }
  write(YEL+"Leatherface "+NORM+"chainsaws through the back of the picture and jumps into the room.\n");      
  summon = 1;
  return 1;
}
}
