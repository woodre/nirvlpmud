#include "/players/syn/ansi.h"
inherit "/obj/armor";

void
set_type(string str)
{
   type = str;
}

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_short(BOLD+"A hockey mask"+NORM);
   set_id("mask");
   set_alias("hockey mask");
   set_type("mask");
   set_ac(1);
   set_long(
      "A battered hockey mask. It looks like it has been around\n"
      +"since the early 70's. It once belonged to Jason Voorhees.\n"
      +"It looks like it would offer great protection.\n");
   set_weight(1);
   set_value(2000+random(300));
}

do_special(owner) {
   tell_object(owner, "Your mask takes the full force of the blow and\n"+
              "            "+BOLD+"/////////"+NORM+""+CYN+" REFLECTS"+NORM+""+BOLD+" /////////"+NORM+"       it.\n");
return random(3);
}

query_save_flag() { return 1; }
