#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

int summon;

reset(arg)
{
  if(arg) return;
  set_light(1);

  set_short(BOLD+"Shrine Room"+NORM);
  set_long(
  "The walls are painted green. This is the room of the Leprechaun.\n"+
  "There are 4-leaf clovers painted on the walls and the ceiling. \n"+
  "There is one big picture on the back wall. There are smaller pictures\n"+
  "on the other walls.\n");

       items=({
           "pictures","Pictures of the Leprechaun killing different people",
           "picture","A 6 foot tall picture of the Leprechaun standing there."+
                     "There is a small plaque on the base of the painting",
           "plaque","It reads: If you wish to meet him, just summon him",
           "walls","Marble walls that has been painted"+HIG+" green"+NORM,
           "clovers",GRN+"4 leaf clovers"+NORM,
           "ceiling","A marble ceiling",
             });

  add_exit("/players/syn/shrine/hall1.c","west");
  add_property("NT");
  set_chance(15);
  add_msg("The wind blows through your hair\n");
  add_msg("Something wispers in your hear: Are you here for me coins, lad?\n");
  add_listen("You hear echoing footsteps on the marble floor\n");
  add_smell("The room smells like a fresh clover patch\n");
}
void init() {
  ::init();
  add_action("cmd_summon","summon");
}
cmd_summon(str) {
  if(summon == 0) {
  if(!str || str != "leprechaun")
    { notify_fail("summon what?\n"); return 0;}
  write("You summon the "+HIG+"Leprechaun\n"+NORM);
  if(!present("leprechaun")) {
        move_object(clone_object("/players/syn/shrine/mobs/lep.c"),this_object()); }
  write(HIG+"Leprechaun "+NORM+"rips himself off the painting, and jumps into the room.\n");      
  summon = 1;
  return 1;
}
}
