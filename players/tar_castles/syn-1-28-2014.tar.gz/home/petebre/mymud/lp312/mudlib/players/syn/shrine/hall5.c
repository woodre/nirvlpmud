#include "/players/syn/ansi.h"
inherit "players/vertebraker/closed/std/room.c";

reset(arg) {

     set_light(1);
     short_desc = (HIW+"Shrine Hallway"+NORM);
     long_desc = 
"A large hallway with walls made of white marble. It is completely clean \n\
and shiny. There is a picture to the east, with a doorway next to it. \n\
There is another picture to the west, with a doorway next to it.  \n\
South will lead you back the entrance room.\n";

      items=({
           "marble","White marble stone, with black onyx chips in it", 
           "walls","They are white and black marble walls. Pictures and hang on them",
	   "picture","Picture to the east shows a picture of a lake with a wooden banner over it. The"+
                     " picture to the west shows a picture of a street with a street sign",
           "doorway"," A doorway with no door. The room beyond is completely black, however",
           "banner"," It reads : Crystal Lake Camp ",
           "sign","It reads :  Elm street",
             });
      add_property("NT");   
          add_exit("/players/syn/shrine/hall4.c","south");
          add_exit("/players/syn/shrine/jroom.c","east");
          add_exit("/players/syn/shrine/fredroom.c","west");
             
}
      init() {
         ::init();
           add_action("listen","listen");
           add_action("search_room","search");
	   add_action("smell","smell");
             }


      listen()  {
          write("You hear echoing footsteps on the marble floor.\n");
          say (this_player()->query_name() +" listens intently.\n");
          return 1;
              }

      search_room() {
          write("You find nothing.\n");
          say (this_player()->query_name()+" searches the area. \n");
          return 1;
                }

      smell()  {
          write("You smell rotting flesh, and freshly spilt blood high on the air.\n");
          say (this_player()->query_name() +"'s nose sniffs the air.\n");
          return 1;
               }
 


