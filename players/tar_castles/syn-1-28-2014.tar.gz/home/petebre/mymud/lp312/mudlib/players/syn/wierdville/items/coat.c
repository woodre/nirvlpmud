#include "/players/syn/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("coat");
set_alias("trench");
set_short(HIK+"A dark trenchcoat"+NORM);
set_long(
  "A long black trenchcoat. It has metal buckles that close the front, and two big\n"+
  "pockets on the sides. It looks like it would provide good protection. It shimmers\n"+
  "a little in the light, and looks almost magical looking.\n");

set_ac(1);
set_type("misc");  /* armor,helmet,boots,ring,amulet,shield,misc  */
set_weight(2);
set_value(1000);
set_arm_light(0);  /*  makes armor glow if it's > 0  */
}

 do_special(owner)

{ 

int t;
object ob;
  t = random(10);
  if (t<3){
 environment()->add_hit_point(random(2));
 tell_room(environment(owner), HIK+""+environment()->query_name()+"'s coat absorbs the attack.\n"+NORM);
return 1;
}
      return 0; 
   }


