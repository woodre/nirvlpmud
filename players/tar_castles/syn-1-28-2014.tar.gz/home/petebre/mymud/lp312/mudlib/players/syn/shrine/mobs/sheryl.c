#include "/players/eurale/closed/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("sheryl");
set_alias("woman");
set_alt_name("girl");
set_race("human");
set_short("Sheryl "+RED+"("+NORM+"Wife"+RED+")"+NORM);
set_long(
  "Sheryl is a sexy lady. She has had 2 kids, but it doesnt\n"+
  "show at all. Her hair is long and blonde, and she has legs\n"+
  "that go all the way up.\n");

set_level(13);
set_hp(650);
set_al(0);
set_wc(20);
set_ac(13);
set_heal(5,10);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Sheryl says: Have you seen my husband around here?\n");
  load_chat("Sheryl says: Have you seen my kids?\n");
set_a_chat_chance(15);
  load_a_chat("Sheryl yells: Joe! Help! Joe!\n");

set_chance(15);
set_spell_dam(15);

set_spell_mess1(
  "Sheryl takes off her shoe, and "+HIW+"THROWS"+NORM+" it at you.\n");
set_spell_mess2(
  "Sheryl takes off her shoe, and "+HIW+"THROWS"+NORM+" it.\n");

gold = clone_object("obj/money");
gold->set_money(600); 
move_object(gold,this_object());
}
