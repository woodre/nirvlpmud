#include "/players/syn/ansi.h"
inherit "obj/weapon.c";

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("warhammer");
set_alias("hammer");
set_short("Orcish WarHammer");
set_long(
  "A large solid iron block it attatched to a large wooden handle. This\n"+
  "mammoth of a weapon is very heavy. Only the most powerful orcs can wield\n"+
  "this weapon. Its handle has carvings in it, and its wrapped in some kind \n"+
  "of leather. \n");

set_type("axe");  /*  sword/knife/club/axe/bow/polearm  */
set_class(17);
set_weight(3);
set_value(1000);
set_hit_func(this_object());
}

weapon_hit(attacker){
int W;
W = random(19);

if(W>16)  {
  say(""+HIK+""+environment(this_object())->query_name()+"'s Warhammer slams thier foe in the chest./n"+
  ""+HIK+"     A large "+NORM+""+RED+"C R U N C H"+NORM+""+HIK+" sounds upon impact."+NORM+"\n");

  write(
  ""+HIK+""You swing your WarHammer as hard as you can and land a blow squarely on the chest of your foe.\n"+NORM+""+
  ""+HIK+"    A large "+NORM+""+RED+"C R U N C H"+NORM+""+HIK+" sounds upon its impact."+NORM+"\n");
  return 7;
   }
if(W>9)  {
  say(""+HIK+""+environment(this_object())->query_name()+"'s WarHammer slams into its foe."+
  ""+HIK+"   Its foe is thrown back and falls to the ground."+NORM+"\n");

  write(
  ""+HIK+"You slam your WarHammer into your foe.\n"+
  ""+HIK+" Your foe is thrown back and falls to the ground.\n");
  return 3;
   }
return; 
}


