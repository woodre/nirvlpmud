#include "/players/syn/ansi.h"
inherit "obj/armor";

reset(arg) {
   set_short(HIK+"A black scarf"+NORM);
   set_save_flag(1);
   set_id("scarf");
   set_alias("black scarf");
   set_type("helmet");
   set_ac(3);
   set_long(
      "A long black scarf that wraps around your head. It seems to provide\n"
      +"good coverage for your head. It seems it would be good to use to avoid\n"
      +"breathing in harmful vapors, or fumes.\n");
   set_weight(1);
   set_value(100+random(30));
}
