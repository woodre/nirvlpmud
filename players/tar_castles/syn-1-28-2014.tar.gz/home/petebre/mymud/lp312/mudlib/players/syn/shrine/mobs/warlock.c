#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("warlock");
set_alias("magician");
set_race("human");
set_short(HIK+"Warlock"+NORM);
set_long(
  "A tall man, with long blonde hair. He is wearing a dark black shirt, and black\n"+
  "pants. He is barefoot, and holding an empty black bag. You can feel the energy\n"+
  "that surrounds this man.\n");

set_level(22);
set_hp(random(550)+1550);
set_al(-1600);
set_wc(38);
set_ac(26);
set_heal(25,5);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("Warlock says: I must find those pages.\n");
  load_chat("The warlock searches around, looking for something.\n");
set_a_chat_chance(10);
  load_a_chat(BLK+"Warlock closes his eyes, and focuses his energy.\n"+NORM);
  load_a_chat("Warlock recites a spell, too inaudible for you to hear it.\n");
  load_a_chat("Warlock opens his eyes and"+HIW+" ENERGY "+NORM+"flows around him\n");

set_chance(13);
set_spell_dam(random(80)+80);

set_spell_mess1(
  HIW+"ENERGY flows around the"+HIK+" Warlock's"+NORM+""+HIW+" attacker.\n"+NORM);
set_spell_mess2(
      HIW+"ENERGY flows around you.\n"+NORM
      +"You feel as if your very "+RED+"soul"+NORM+" is being torn apart.\n"+NORM+
      "You crumple over in"+HIY+" PAIN.\n"+NORM);

gold = clone_object("obj/money");
gold->set_money(random(2000)+4000); 
move_object(gold,this_object());

}

heart_beat(){
 ::heart_beat();
    if(!random(5) && attacker_ob) big_special();


}

init(){
  ::init();
    add_action("block_dir","west",1);
    }

block_dir(){
  if(present("warlock", environment(this_player()))){
  write(HIK+"Warlock "+NORM+"steps in your path, and stares you down.\n"+NORM);
  say(this_player()->query_name()+" tries to leave, but the"+HIK+" Warlock"+NORM+" steps in the path.\n");
  return 1; }

}

big_special(){
	if(environment())
	tell_room(environment(),
       "The Warlock reaches into his bag, and \n"); 

switch(random(3))  {
		
		case 2:
		say(" throws some "+RED+"red"+NORM+" powder in "+attacker_ob->query_name()+"'s face.\n",({ attacker_ob }));
		tell_object(attacker_ob,"                      throws some "+RED+"red"+NORM+" powder in your face.\n"+
					"Your face burns so bad you feel as if your skin is melting off.\n"); 
		attacker_ob->hit_player(30);
		break;
		
		case 1:
		say(" throws some "+BLU+"blue"+NORM+" powder on "+attacker_ob->query_name()+"'s face.\n",({ attacker_ob }));
		tell_object(attacker_ob,"                     throws some "+BLU+"blue"+NORM+" powder in your face.\n"+
					"Your face freezes and it becomes hard for you to move\n"+
					"the rest of your body.\n");
    		attacker_ob->hit_player(25);
		break;
		
		case 0:
		say(" throws some "+YEL+"yellow"+NORM+" powder on "+attacker_ob->query_name()+"'s face.\n", ({ attacker_ob }));
		tell_object(attacker_ob,"                    throws some "+YEL+"yellow"+NORM+" powder in your face.\n"+
					"You feel electricity flow through every inch of your body.\n");
		attacker_ob->hit_player(20);
		break;
  
  }

}


