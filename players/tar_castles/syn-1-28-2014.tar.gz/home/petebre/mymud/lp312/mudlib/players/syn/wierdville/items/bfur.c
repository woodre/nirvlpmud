#include "/players/syn/ansi.h"
inherit "obj/treasure";

reset(arg) {
  if(arg) return;
  set_id("fur");
  set_alias("bear fur");
  set_short(HIY+"Bear fur"+NORM);
  set_long(
"A thick dark brown patch of fur. The fur has sticks and insects crawling all over\n"+
"it. The fur is caked with blood and mud. It smells of death and decay.\n"+
"You could probably get some money for this thing, from the right person.\n");
  set_weight(3);
  set_value(5000+random(500));
}

init() {
  ::init();
  add_action("cmd_barter","barter");
}

cmd_barter(str) {
  if(id(str)) {
    if(present("John",environment(this_player()))) {
      write("John says: WoW! This is excatly what I wanted.\n"+
            "Thank you so much for bringing me this. It will\n"+
            "fetch a fair price. If you find any other furs or feathers, please \n"+
            "bring them to me.\n");
      this_player()->add_money(value);
      this_player()->add_weight(-3);
      destruct(this_object());
      return 1;
    }
  }
  notify_fail("Barter what?\n");
}
