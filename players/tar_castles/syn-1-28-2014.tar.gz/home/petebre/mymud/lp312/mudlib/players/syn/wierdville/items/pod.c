#include <ansi.h>
inherit "/obj/generic_heal.c";

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_name("pod");
  set_short(BOLD+"Maggot's Pod"+NORM);
  set_long("A pod filled with a liquidy ooze.\n"+
           "It looks like a clear jelly type substance.\n"+
           "You might be able to eat it.\n");
  set_type("food");
  set_msg("You pop open the pod and eat the jelly in side.\n"+
          "It tastes like super sweet jelly. It is very good!\n");
  set_msg2(" pops open the pod and puts it into their mouth.\n");
  add_cmd("eat");
  set_heal(50,50);
  set_charges(1); 
  set_soak(10);
  set_stuff(10);
  set_value(0);
}

query_save_flag(){
  return 1;
  }

