#include "/players/syn/ansi.h"
inherit "obj/monster.c";

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("woman");
set_alias("lady");
set_alt_name("infected");
set_race("human");
set_short("A woman "+HIR+"/ "+NORM+""+HIK+"In"+NORM+""+HIR+"FeCt"+NORM+""+HIK+"eD /"+NORM);
set_long(
 "A blonde haired blue eyed woman, with huge breasts. Her white half shirt is covered\
 with blood and flesh. Blood completely covers the lower half of her face and most of\
 her neck. Blood slowly drips from her nose and the corner's of her mouth. Her hair is\
 matted with blood and chucks of flesh.\
 ");

set_level(17);
set_hp(300+random(100));
set_al(0);
set_wc(24); 
set_ac(14);
set_aggressive(1);
set_a_chat_chance(17);
  load_a_chat("The woman yells : I smell FLESH!\n");
  load_a_chat("The woman says : Com'on baby, just one kiss.\n"); 

gold = clone_object("obj/money");
gold->set_money(2000+random(500)); 
move_object(gold,this_object());

set_chance(10);
set_spell_dam(random(30)+40);

set_spell_mess1(
   RED+" /      /        /          /       /        \n"+
      " /      /        /          /       /         \n"+
     " /      /        /          /       /          \n"+ 
     "/      /        /          /       /           \n"+NORM
   +"The woman scatches "+this_player()->query_name()+" fiercly!!!\n");
set_spell_mess2(
   RED+"         /     /        /        /           \n"+
       "   /    /     /        /        /            \n"+
      "   /    /     /        /        /             \n"+
      "  /    /     /        /        /              \n"+NORM+
  "The woman scatches you, and "+RED+" blood "+NORM+" pours from your wound.\n"+NORM);


return 0;
}


