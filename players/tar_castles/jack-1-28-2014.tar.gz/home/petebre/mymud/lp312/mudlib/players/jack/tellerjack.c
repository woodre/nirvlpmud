#include "/players/jack/ansi.h"

id(str)  { return str == "jtell"; }
short() {return "Jack's teller (Floating)";}

drop()   { return 1; }
get()    { return 1;}

init(){
    
    add_action("jtell","jtell");
    add_action("jtelle","jtelle"); 
    add_action("jtelli","jtelli");
}


jtell(str) {
  object player;
  string who;
  string what;
	            
     if(!str) 
            {
             write("Tell what?\n"); 
     return 1;
            }
     if(sscanf(str,"%s %s",who,what)==2)
            {
             player = find_player(who);
     if(!player) 
            {
             write(capitalize(who) + " is not online now.\n"); 
    return 1; 
            }
    if(this_player()->query_invis() > 1) 
            {
	     tell_object(player, HIR+"Jack (invis) "+NORM+""+GRN+"j"+NORM+""+BLU+"o"+NORM+""+YEL+"k"+NORM+""+BLK+"i"+NORM+""+CYN+"n"+NORM+""+WHT+"g"+NORM+""+MAG+"l"+NORM+""+HIG+"y "+NORM+""+HIB+"says to you: "+NORM+what+" \n");
             write(BLK+"You invisibly jtell "+capitalize(who)+NORM+": "+what+"\n");
	     player->add_tellhistory(this_player()->query_real_name()+" tells you: "+what);
/*             add_tellhistory(this_player()->query_real_name()+" tells you: "+what);*/
             return 1; 
            }
    if(this_player()->query_invis() < 1) 
            {
             tell_object(player, HIR+"Jack "+NORM+""+GRN+"j"+NORM+""+BLU+"o"+NORM+""+YEL+"k"+NORM+""+BLK+"i"+NORM+""+CYN+"n"+NORM+""+WHT+"g"+NORM+""+MAG+"l"+NORM+""+HIG+"y "+NORM+""+HIB+"says to you: "+NORM+what+" \n");
	     write(BLK+"You jtell "+capitalize(who)+NORM+": "+what+"\n");
             player->add_tellhistory(this_player()->query_real_name()+" tells you: "+what);
/*	     add_tellhistory(capitalize(this_player())->query_real_name()+" tells you: "+what);*/
    return 1; 
            }
    return 1;
            }
    return 1;
            }

jtelle(str) {
  object player;
  string who;
  string what;
	            
     if(!str) 
            {
             write("Emote to whom?\n"); 
     return 1;
            }
     if(sscanf(str,"%s %s",who,what)==2)
            {
             player = find_player(who);
     if(!player) 
            {
             write(capitalize(who) + " is not online now.\n"); 
    return 1; 
            }
    if(this_player()->query_invis() > 1) 
            {
	     tell_object(player, "Jack (invis) "+what+" \n");
             write("You invisibly jemote to " +capitalize(who)+": "+what+"\n");
             
    return 1; 
            }
    if(this_player()->query_invis() < 1) 
            {
             tell_object(player, "Jack "+what+" \n");
	     write("You jemote to " +capitalize(who)+": "+what+"\n");
    return 1; 
            }
    return 1;
            }
    return 1;
            }

jtelli(str) {
  object player;
  string who;
  string what;
	            
     if(!str) 
            {
             write("Emote to whom?\n"); 
     return 1;
            }
     if(sscanf(str,"%s %s",who,what)==2)
            {
             player = find_player(who);
     if(!player) 
            {
             write(capitalize(who) + " is not online now.\n"); 
    return 1; 
            }
    if(this_player()->query_invis() > 1) 
            {
	     tell_object(player, what+" \n");
             write("You echo to " +capitalize(who)+": "+what+"\n");
             
    return 1; 
            }
    if(this_player()->query_invis() < 1) 
            {
             tell_object(player,what+" \n");
	     write("You echo to " +capitalize(who)+": "+what+"\n");
    return 1; 
            }
    return 1;
            }
    return 1;
            }


