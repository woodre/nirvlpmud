inherit "/room/room";
#include "/players/plasma/define.h"

reset(arg) {
   if(arg) return;
   set_light(1);
}

long() {
   write("Yep.\n\n"+
      "Best wishes,\n"+
      " -plasma\n");
   return 1; }

init() {
   ::init();
   if(TPRN != "plasma") {
      TP->set_home("/players/plasma/room/yep");
      TP->save_me();
      return 1; }
   return 1; }

exit() {
   if(TPRN != "plasma") {
      destruct(TP);
      TP->set_home("/players/plasma/room/yep");
      TP->save_me(); }
   return; }
