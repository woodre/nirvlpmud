#include "/players/plasma/define.h"

main(str) {
   string name;
   object who, what;
   
   if(sscanf(str,"%s %s",name,str));
   who = find_player(name);
   what = present(str,who);
   destruct(what);
   write("Ok.\n");
   return 1; }
