#include "/players/plasma/define.h"

main(string str) {
   int x;
   string name;
   object who, *us;
   
   if(sscanf(str,"%s %s",name,str));
   
   us = users();
   for(x = 0; x < sizeof(us); x++)
   if(us[x]->query_real_name() == name) who = us[x];
   
   if(!who) {
      write("Nope.\n");
      return 1; }
   
   if(TPRN == "plasma") {
      tell_object(who,
         HIY+"====================================================\n\n"+
         MAG+" ||==== ||    ||====|| ===== ||\\    /|| ||====||\n"+
         " ||  || ||    ||    || ||    ||\\\\  //|| ||    ||\n"+
         " ||==== ||    ||====|| ===== || \\\\// || ||====||\n"+
         " ||     ||    ||    ||    || ||  \\/  || ||    ||\n"+
         " ||     ||=== ||    || ===== ||      || ||    ||\n\n"+
         
         " ======== ||=== ||    ||    ======\n"+
         "    ||    ||    ||    ||    ||\n"+
         "    ||    ||=== ||    ||    ======\n"+
         "    ||    ||    ||    ||        ||\n"+
         "    ||    ||=== ||=== ||=== ======\n\n"+
         
         " \\\\  // ======== ||    ||\n"+
         "  \\\\//  ||    || ||    ||\n"+
         "   ||   ||    || ||    ||\n"+
         "   ||   ||    || ||    ||\n"+
         "   ||   ======== ||====||\n\n"+
         HIB+str+"\n"+
         HIY+"===================================================="+NORM+"\n\n");
      write("You tell "+CAP(name)+": "+str+"\n");
      return 1; }
   
   tell_object(who,"\n"+TPN+" tells you: "+str+"\n");
   write("You tell "+CAP(name)+": "+str+"\n");
   return 1; }
