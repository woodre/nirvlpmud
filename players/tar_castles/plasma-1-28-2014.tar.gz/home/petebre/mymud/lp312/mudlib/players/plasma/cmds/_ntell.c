#include "/players/plasma/define.h"

main(string str) {
   int x;
   string name;
   object who, *us;
   
   if(sscanf(str,"%s %s",name,str));
   
   us = users();
   for(x = 0; x < sizeof(us); x++)
   if(us[x]->query_real_name() == name) who = us[x];
   
   if(!who) {
      write("Nope.\n");
      return 1; }
   
   tell_object(who,"\n"+HIR+TPN+" tells you: "+str+"\n"+NORM);
   write(HIR+"You tell "+CAP(name)+": "+str+"\n"+NORM);
   return 1; }
