main(arg) {
   object what;
   string func, str, name;
   int tmp;
   
   if(sscanf(arg,"%s %s %s",name,func,str));
   if(sscanf(str,"%d",tmp));
   what = find_player(name);
   if(!what) what = present(name,this_player());
   if(!what) what = present(name,environment(this_player()));
   if(str == "0") call_other(what,func,0);
   if(!tmp && str && str != "0") call_other(what,func,str);
   if(tmp) call_other(what,func,tmp);
   write("Done.\n");
   return 1; }
