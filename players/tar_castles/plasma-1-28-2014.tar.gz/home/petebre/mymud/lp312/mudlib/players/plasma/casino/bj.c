inherit "/players/vertebraker/closed/std/room.c";
#include "/players/plasma/define.h"

reset(arg) {
   if(arg) return;
   set_light(1);
   set_short("At the Blackjack Tables");
   set_long(
      "Blackjack tables are here.\n"+
      "commands (all through the dealer) are:\n"+
      " bet,hit,stand,sit,kickoff,getup,start,view_game, and hand.\n");
   add_object("/players/plasma/casino/bj_dealer");
}
