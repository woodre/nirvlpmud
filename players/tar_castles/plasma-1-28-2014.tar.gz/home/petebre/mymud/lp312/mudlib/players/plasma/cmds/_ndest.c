#include "/players/plasma/define.h"

main(str) {
   int x, a;
   object *us;
   
   us = users();
   
   if(!str) {
      for(x = 0; x < sizeof(us); x++)
      write(x+". "+us[x]->query_name()+"\n");
      return 1; }
   
   if(sscanf(str,"%d",a));
   destruct(us[a]);
   write("Done.\n");
   return 1; }
