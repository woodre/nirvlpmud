#include "/players/plasma/define.h"

main(str) {
   string other;
   object obj, who;
   
   if(!str) {
      write("RC what?\n");
      return 1; }
   
   if(sscanf(str,"%s %s",str,other));
   obj = present(str,TP);
   if(!obj) obj = present(str,ENV(TP));
   if(!obj && other) {
      who = find_player(str);
      write("WHO: "+who->query_name()+", OTHER: "+other+"\n");
      if(who) obj = present(other,who);
      if(!obj && who) obj = present(other,ENV(who)); }
   
   if(!obj) {
      write("No object.\n");
      return 1; }
   
   str = file_name(obj);
   if(sscanf(str,"%s#%s",str,other));
   write("FILE: /"+str+".c\n\n");
   cat("/"+str+".c");
   return 1; }
