#include "/players/plasma/define.h"
main(string str) {
   string what, where;
   
   if(!str || sscanf(str,"%s %s",str,what) != 2) {
      write("Do what where now?\n");
      return 1; }
   
   where = file_name(ENV(TP));
   move_object(TP,str);
   command(what,TP);
   move_object(TP,where);
   
   return 1; }
