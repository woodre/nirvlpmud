#include "/players/plasma/define.h"
inherit "/players/vertebraker/closed/std/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   set_short("The party room part 2");
   set_long(
      "\nA party room again! Party room part 2!\n");
   add_exit("/room/vill_green","green");
   add_object("/players/hippo/games_bak/fiftyone");
}
