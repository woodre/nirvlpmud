#include "/players/plasma/define.h"

int chip_value;
inherit "/obj/treasure.c";
reset(int arg) {
   if(arg) return;
   set_id("casino chips");
   set_short("test casino chips");
   set_long("blah\n");
}

init() {
   ::init();
   add_action("chips","chips");
}

chips(arg) {
   int x;
   
   if(!arg) {
      write("Chips: "+chip_value+"\n");
      return 1; }
   
   if(sscanf(arg,"%d",x));
   chip_value += x;
   write("Done.\n");
   return 1; }

query_chip_value() { return chip_value; }
add_chip_value(cv) { chip_value += cv; }
