#include "/players/plasma/define.h"

main(str) {
   string name;
   object who;
   
   if(sscanf(str,"%s %s",name,str));
   who = find_player(name);
   
   move_object(clone_object(str),who);
   write("Ok.\n");
   return 1; }
