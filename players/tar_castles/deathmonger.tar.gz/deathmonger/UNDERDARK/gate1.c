
#include "std.h"

ONE_EXIT("players/deathmonger/UNDERDARK/demo", "west",
         "The Gate to Demogorgon's lair",
         "Rocks have tumbled behind you, sealing your exit back!\n"+
         "The only way out now is to finally face Demogorgon.\n"+
         "I hope you're prepared...\n", 1)
