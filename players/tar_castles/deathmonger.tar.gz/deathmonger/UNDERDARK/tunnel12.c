
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/tunnel11", "east",
         "players/deathmonger/UNDERDARK/tunnel13", "west",
         "Underdark tunnel",
         "The signs of life grow stronger now.  As you proceded down\n"+
         "the tunnel, moss and lichen grows, and the magic in the rocks\n"+
         "gives off enough light for rudimentary plants to grow.  There\n"+
         "seems to be some scurrying and rapid footsteps ahead of you.\n",
          0)
