
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/maze/maze1", "south",
         "players/deathmonger/UNDERDARK/maze/maze3", "north",
         "Arrrgh! But fortunately not a maze",
         "Oh, no, you've lost your bearings in this strange tunnel!\n"+
         "But things could be worse...you could be in a maze with a \n"+
         "minotaur in it or something.\n", 0)
