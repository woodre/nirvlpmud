
#include "std.h"

THREE_EXIT("players/deathmonger/UNDERDARK/maze/maze4", "south",
         "players/deathmonger/UNDERDARK/maze/maze8", "east",
         "players/deathmonger/UNDERDARK/maze/maze10", "west",
         "Arrrgh! But fortunately not a maze",
         "Oh, no, you've lost your bearings in this strange tunnel!\n"+
         "But things could be worse...you could be in a maze with a \n"+
         "minotaur in it or something.\n", 0)
