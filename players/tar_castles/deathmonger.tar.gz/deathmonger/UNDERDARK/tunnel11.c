
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/tunnel_corner", "east",
         "players/deathmonger/UNDERDARK/tunnel12", "west",
         "Underdark tunnel",
         "There are footprints covering the foor of this dusty little\n"+
         "tunnel.  Signs of recent travel abound.  There seems to be\n"+
         "something magical about the place, too.\n", 0) 
