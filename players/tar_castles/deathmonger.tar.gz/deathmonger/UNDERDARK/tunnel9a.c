
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/tunnel8a", "north",
         "players/deathmonger/UNDERDARK/tunnel_corner", "south",
         "Underdark tunnel",
         "You appear to be reaching a turning point ahead.  You better\n"+
         "hope you make the right turn...\n", 1)
