
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/tunnel13", "east",
         "players/deathmonger/UNDERDARK/tunnel15", "west",
         "Underdark tunnel",
         "This tunnel seems to have had a lot of activity lately,\n"+
         "judging from the freshness of the tracks left on the floor.\n"+
         "Perhaps you'd better watch your step.\n", 0)
