
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/tunnel14", "east",
         "players/deathmonger/UNDERDARK/maze/entrance", "west",
         "Underdark tunnel",
         "You seem to be coming towards the end of the tunnel.\n"+
         "However, there is blood splattered all over the stones here,\n"+
         "and bones that have been cracked like sticks scattered around\n"+
         "the tunnel floor.\n", 0)
