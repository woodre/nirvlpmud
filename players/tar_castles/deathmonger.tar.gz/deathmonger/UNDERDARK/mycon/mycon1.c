
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/mycon/entrance", "west",
         "players/deathmonger/UNDERDARK/mycon/mycon2", "east",
         "Myconid road",
         "As you stroll through the fungal town you don't ssee anyone\n"+
         "on the streets.  Myconids are a fearful bunch and don't like\n"+
         "to be seen, much less by the likes of you.\n", 1)
