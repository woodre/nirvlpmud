
#include "std.h"

TWO_EXIT("players/deathmonger/UNDERDARK/tunnel7a", "north",
         "players/deathmonger/UNDERDARK/tunnel9a", "south",
         "Underdark tunnel",
         "You continue down the tunnel. Maybe you're lost?  Well, whatever\n"+
         "the case, it's pretty dark here, and smells faintly of rotting\n"+
         "flesh.\n", 0)
