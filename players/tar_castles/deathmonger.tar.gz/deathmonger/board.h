
#define BOARD_DIR "players/deathmonger/"
