
id(str){ return str == "test"; }

init(){
   string blue, frog;
   caller(frog);
}
