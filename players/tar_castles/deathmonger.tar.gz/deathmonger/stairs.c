
id(str){ return str == "stairway"; }
short(){ return "A dark stairway leads down"; }
long(){
    write("The stairway is quite dark.\n");
}

init(){ 
     add_action("down", "down");
}

down(){
    call_other(this_player(), "move_player",
     "down#players/deathmonger/CASTLE/complaint_room");
     return 1;
}

reset(arg){
     if(!arg){
     move_object(this_object(), "room/adv_guild");
     }
}

