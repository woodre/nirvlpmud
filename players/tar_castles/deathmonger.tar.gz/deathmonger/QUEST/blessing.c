
id(str){ return str == "blessing"; }
query_save_flag(){ return 1; }
get(){ return 1; }
