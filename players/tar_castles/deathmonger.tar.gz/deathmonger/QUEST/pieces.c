
id(str){ return str == "pieces"; }
query_save_flag(){ return 1; }
short(){ return "Some pieces of an adamantite statue"; }
long(){
write("You figure out how to assemble them\n");
}
get(){ return 1; }
