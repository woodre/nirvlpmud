
id(str){ return str == "mushroom"; }
query_save_flag(){ return 1; }
short(){ return "A delicate mushroom"; }
get(){ return 1; }
long(){
write("My, this would look mighty fine to a fungi connoisour.\n");
}
