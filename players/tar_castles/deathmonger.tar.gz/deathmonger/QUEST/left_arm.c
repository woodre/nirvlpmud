
id(str){ return str == "arm" || str == "left arm"; }
query_save_flag(){ return 1; }
short(){ return "An adamantite left arm"; }
long(){ write("This appears to have been broken off of a statue.\n"); }
get(){ return 1; }
weight(){ return 1; }
