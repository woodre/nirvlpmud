
id(str){ return str == "head" || str == "adam head"; }
query_save_flag(){ return 1; }
short(){ return "An adamantite head"; }
long(){ 
     write("This looks like it was severed from a statue.\n");
}
weight(){ return 1; }
get(){ return 1; }
