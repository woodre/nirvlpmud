
id(str){ return str == "arm" || str == "right arm"; }
query_save_flag(){ return 1; }
short(){ return "An adamantite right arm"; }
long(){ write("This appears to have been severed off of a statue.\n"); }
get(){ return 1; }
weight(){ return 1; }
