
id(str){ return str == "cross"; }
short(){ return "A holy cross"; }
long(){
    write("This cross could come in useful in the right situation.\n");
}
get(){ return 1; }
drop(){ return 1; }
