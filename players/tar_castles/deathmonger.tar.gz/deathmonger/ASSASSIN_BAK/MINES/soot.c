id(str) { return str == "soot"; }
extra_look() {
     return "is covered in soot from the blast of a land mine";
}

drop() { return 1; }
