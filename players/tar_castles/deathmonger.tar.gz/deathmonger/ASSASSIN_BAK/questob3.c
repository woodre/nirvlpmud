
id(str) {return str == "rusty sword"; }
short() { return "A rusty sword"; }
long(){
     write("A rusty sword, useless to anyone but an assassin.\n");
}
get() { return 1; }
query_weight() { return 2; }
