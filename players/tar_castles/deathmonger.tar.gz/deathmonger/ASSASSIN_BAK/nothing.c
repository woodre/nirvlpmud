
id(str){ return str == "womble"); }

init(){
   int i;
   i=random(1)+2;
   write(i+"\n");
}
