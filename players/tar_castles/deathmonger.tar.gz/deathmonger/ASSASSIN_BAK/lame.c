id(str){ return str == "lame"; }
