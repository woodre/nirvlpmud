
#include "std.h"

object sootmine, shoutmine, 
