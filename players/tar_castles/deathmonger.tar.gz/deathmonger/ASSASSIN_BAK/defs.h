object stalkee, shadow, monshadow, bug, roombug;
int stalk, count, disguised, ok_backstab;
string stalkee_name;

#define notify_fail(A) write(A+"\n"); return 1;

#define APATH "players/deathmonger/ASSASSIN/"
