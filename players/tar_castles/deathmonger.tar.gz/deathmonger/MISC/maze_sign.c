
id(str){ return str == "sign"; }
short(){ return "A sign etched in the rocks"; }
long(){ 
write("This is not a maze, and there are no minotaurs in it.\n");
}

