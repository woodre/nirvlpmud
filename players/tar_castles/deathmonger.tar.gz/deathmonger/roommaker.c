inherit "players/bern/magic/roommaker";
