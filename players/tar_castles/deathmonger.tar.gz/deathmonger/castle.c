#define NAME "Deathmonger"
#define DEST "room/south/sforst5"
/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "castle"; }

short() {
    return "There is a volcanic island far to the north"; }

long() {
    write("You enter a dimesional shift.\n");
}

init() {
    add_action("north"); add_verb("north");
}

north() {
call_other(this_player(), "move_player",
"north#players/deathmonger/entrance");
    return 1;
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), "players/deathmonger/stairs");
/*
    move_object(this_object(), "players/deathmonger/ASSASSIN/booth");
 */
    move_object(this_object(), "players/deathmonger/shop_ent");
/*
    move_object(this_object(), "players/deathmonger/ASSASSIN/cenguild");
*/
    move_object(this_object(), DEST);
}
is_castle() {return 1;}
