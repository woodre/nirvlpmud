
#include "std.h"

TWO_EXIT("players/deathmonger/CASTLE/fortress/tower1", "down",
         "players/deathmonger/CASTLE/fortress/tower_top", "up",
         "Second floor of tower",
         "You stand on the second floor of the tower.  It is quite dark\n"+
         "in here, and from what you can see it is just as well.\n", 0)
