
#include "std.h"

TWO_EXIT("players/deathmonger/CASTLE/fortress/dracolich", "down",
         "players/deathmonger/CASTLE/fortress/tower2", "up",
         "First floor of tower",
         "You stand on the first floor of the tower.  It is quite dark\n"+
         "in here, and from what you can see it is just as well.\n", 0)
