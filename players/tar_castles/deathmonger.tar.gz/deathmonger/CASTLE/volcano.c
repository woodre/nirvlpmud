#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
extraq
q
