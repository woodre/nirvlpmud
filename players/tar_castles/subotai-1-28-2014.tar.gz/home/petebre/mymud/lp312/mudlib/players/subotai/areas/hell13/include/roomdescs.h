get_long(int x){
if(desc[x] == 1){
return
"  Flames flicker in and out on the charred surface of this land. There is\n"+
"no end in sight, just the flickering of the flames and the charred bones of\n"+
"the damned.\n";
}
else if(desc[x] == 2){
return 
"  Flames flicker in and out on the charred surface of this land. There is\n"+
"no end in sight, just the flickering of the flames and the charred bones of\n"+
"the damned. Broken obsidian pillars jut up from the charred landscape.\n";
}
else if(desc[x] == 3){
return
"  Flames flicker in and out on the charred surface of this land. There is\n"+
"no end in sight, just the flickering of the flames and the charred bones of\n"+
"the damned. Obsidian boulders dot the landscape.\n";
}

else if(desc[x] == 4){
return 
"  Flames flicker in and out on the charred surface of this land. There is\n"+
"no end in sight, just the flickering of the flames and the charred bones of\n"+
"the damned. Large pools of some sort of liquid flame in and out.\n";
}

else if(desc[x] == 5){
return 
"  Flames flicker in and out on the charred surface of this land. There is\n"+
"no end in sight, just the flickering of the flame and the charred bones of\n"+
"the damned. An archway carved of obsidian juts up from the charred landscape.\n";
}

else{
return 
"  Flames flicker in and out on the charred surface of this land. There is\n"+
"no end in sight, just the flickering of the flames and the charred bones of\n"+
"the damned.\n";
}

}								 							