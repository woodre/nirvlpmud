#ifndef ESC_H
#define ESC_H

#define esc ""
#define ESC esc

#endif
