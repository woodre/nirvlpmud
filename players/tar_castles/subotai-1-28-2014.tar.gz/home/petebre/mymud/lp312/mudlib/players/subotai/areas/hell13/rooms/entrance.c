#include <ansi.h>
#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
inherit "room/room";


reset(arg) {
   if(arg) return;
   set_light(1);
   
   short_desc = "unknown";
   long_desc =
   "  This is a dark obsidian room. A black fluid filled door stands\n"+
   "along the north wall, and a waivering doorway of light stands to\n"+
   "the south. A book on a pedestal stands in front of the darker\n"+
   "doorway.\n";
   
   
   items = ({
         "fluid",
         "A blackish fluid which has no real substance but is illusion",
         "door",
         "A frame of a doorway made from the surrounding obsidian stone",
         "obsidian",
         "A dark polished rock",
         "doorway",
         "A frame of a doorway made from the surrounding obsidian stone",
         "light",
         "A glimmering field of light that waivers continuously",
         "book",
         "A book in perfect condition. It is made of black leather and the\n"+
         "pages are a white paper. It looks as though you could read it",
         "pedestal",
         "A pedestal made of dark wood. It seems very sturdy",
         });

   
   dest_dir = ({
         "/players/maledicta/castle/rooms/m2.c","south",
         });
   
}

init(){
   ::init();
   add_action("enter_door", "north", 1);
}

enter_door(){
int i;
object test;
   
   test = clone_object("/players/subotai/areas/hell13/rooms/randomhell.c");
   write_file("/players/subotai/areas/log/enter_hell",
                ctime(time())+"  "+HIY+tpn+NORM+
                "    [Level  "+tp->query_level()+"+"+tp->query_extra_level()+"]\n");	
   write(
   "You step into the dark portal....\n");
   say(
   this_player()->query_name()+" steps into a dark portal.\n");      
   test->creation();
   test->renew_room(1);
   move_object(this_player(), test);
   return 1;
 } 
 
 realm(){ return "NT"; }
 
 
