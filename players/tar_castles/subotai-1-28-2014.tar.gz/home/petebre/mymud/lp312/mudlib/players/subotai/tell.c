#include "/players/wocket/closed/ansi.h"
inherit "/players/wocket/std/wiztell.c";

reset(arg){
  if(arg) return;
  owner = "subotai";
  cap_owner = "Subotai";
  color = BOLD;
  extra_look = "Subotai is NOT gay";
}

