#include "/players/subotai/ansi.h"
int room_num;
string room_desc;

int *blocked;
int *desc;
int *encounter;
mixed *items;
#include "/players/subotai/areas/hell13/include/roomdescs.h"

reset(arg){
set_light(1);
enable_commands();	
blocked = allocate(120);
desc = allocate(120);
encounter = allocate(120);	
blocked = ({ });
desc = ({ });
items = ({ });
encounter = ({ });	
room_num = 5; 

items = ({
 "pillars", 
"The broken obsidian pillars dot the landscape.",
 2,
 "boulders"
"Cracked obsidian boulders dot the landscape.",
 3,
 "pools"
"A large dark pools of some viscous liquid.",
 4,
 "archway"
"An obsidian archway with strange symbols carved into it.",
 5,
 "bones",
"The charred remains of unlucky victims.", 
 500,
 "flames"
"The flames flicker in and out, endlessly burning.",
 500,

});


}

short(){
return "the 13 Level of Hell"; }

long(str){
int i;	
if(!str){		
  write(room_desc);
  write("\nObvious Exits are: ");
  if(room_num < 90){
  if(blocked[room_num + 10] > 0){
    write("[north] ");
     }
    }
if(room_num > 10){
  if(blocked[room_num - 10] > 0){
    write("[south] ");
     }
    }
  
  if(room_num != 1 && room_num != 11 && room_num != 21 && room_num != 31 && room_num != 41 &&
     room_num != 51 && room_num != 61 && room_num != 71 && room_num != 81 && room_num != 91){
     if(blocked[room_num - 1] > 0){
     	write("[east] ");
        }
      }
  if(room_num != 10 && room_num != 20 && room_num != 30 && room_num != 40 && room_num != 50 &&
     room_num != 60 && room_num != 70 && room_num != 80 && room_num != 90 && room_num != 100){    	   		  		
     if(blocked[room_num + 1] > 0){
     	write("[west] ");
        }
       }
  if(room_num == 5){
  	write("[leave]");
  	}     
  write("\n");						
  return 1;
   }

 if (!items)
	return;

    i = 0;
    while(i < sizeof(items)) {
	if (items[i] == str && (items[i+2] >= 500 || items[i+2] == desc[room_num])){ 
	    write(items[i+1] + ".\n");
	    return;
	  }
	i += 3;
    }
}





id(string str){
  int i;
    if (!items)
	return;
    while(i < sizeof(items)) {
	if (items[i] == str)
	    return 1;
	i += 3;
    }
    return 0;
}


init(){
add_action("move_north", "north");
add_action("move_south", "south");
add_action("move_east", "east");
add_action("move_west", "west");
add_action("move_leave", "leave");
add_action("map_func", "map");
call_out("room_check", 1);
}


creation(){
int num1, number1;
int num2, number2;
int num3, number3;
num1 = 0;
num2 = 0;
num3 = 0;
/**** create blocked rooms *****/
while(num1 < 120){
   number1 = random(4);
   blocked += ({ number1 });
   num1 ++;
   }
/*******************************/


/* make sure the room you start in isn't blocked */
blocked[5] = 1;
/*************************************************/


/**** create room descs *********/
while(num2 < 120){
   number2 = random(30);
   desc += ({ number2 });
   num2 ++;
   }
/********************************/

/**** Encounters ****************/
while(num3 < 120){
   number3 = random(3);
   encounter += ({ number3 });
   num3 ++;	
   }
/********************************/
encounter[5] = 1;
return 1;
}


room_check(){
int i;
object *inv3;
inv3 = all_inventory(this_object());	
for(i=0; i<sizeof(inv3); i++) {
   if(inv3[i]->is_player()){
   remove_call_out("room_check");	
   call_out("room_check", 180);
   return 1;
   }
  }
call_out("dest_me", 20);
return 1; }	


renew_room(int x){
int inv, i;
while(inv < 2){
object *inv2;
 inv2 = all_inventory(this_object());
  for(i=0; i<sizeof(inv2); i++) {
   if(!inv2[i]->is_player() &&
      !inv2[i]->is_pet() &&
      !inv2[i]->is_mine() &&
      !inv2[i]->query_race("machine")){ destruct(inv2[i]); }
 }
 inv++;
}	
room_desc = get_long(room_num);
if(encounter[room_num] < 1){
if(x < 6){
if(random(100) < 50){		
move_object(clone_object("/players/subotai/areas/hell13/mobs/newbie.c"), this_object());
  }	
move_object(clone_object("/players/subotai/areas/hell13/mobs/newbie.c"), this_object());
 }
else if(x < 12){
if(random(100) < 50){
move_object(clone_object("/players/subotai/areas/hell13/mobs/midlevel.c"), this_object());
  }
move_object(clone_object("/players/subotai/areas/hell13/mobs/midlevel.c"), this_object());  			
 }
else{
if(random(100) < 50){
move_object(clone_object("/players/subotai/areas/hell13/mobs/midlevel.c"), this_object());
  }
move_object(clone_object("/players/subotai/areas/hell13/mobs/midlevel.c"), this_object());  			
 }
}	
return 1;
}

	

/******************* Movement in the cave ********************************/   
move_north(){
if(room_num > 90){
return 0;
}

if(blocked[room_num + 10] <= 0){
return 0;
}
if(present("cave_mob", this_object()) && !this_player()->query_ghost()){
write("The "+present("cave_mob",this_object())->query_name()+" jumps in front of you blocking your path!\n");
return 1;
}	
tell_object(this_player(),
"You walk north.\n");
tell_room(environment(this_player()),
"You follow "+this_player()->query_name()+".\n", ({ this_player() }));
room_num += 10;
renew_room(this_player()->query_level());
encounter[room_num] = 1;
command("look", this_player());
return 1;
}

move_south(){
if(room_num < 11){
return 0;
}

if(blocked[room_num - 10] <= 0){
return 0;
}
if(present("cave_mob", this_object()) && !this_player()->query_ghost()){
write("The "+present("cave_mob",this_object())->query_name()+" jumps in front of you blocking your path!\n");
return 1;
}	

tell_object(this_player(),
"You walk south.\n");
tell_room(environment(this_player()),
"You follow "+this_player()->query_name()+".\n", ({ this_player() }));
room_num -= 10;
renew_room(this_player()->query_level());
encounter[room_num] = 1;
command("look", this_player());
return 1;
}        

move_east(){
if(room_num == 1 || room_num == 11 || room_num == 21 || room_num == 31 || room_num == 41 ||
   room_num == 51 || room_num == 61 || room_num == 71 || room_num == 81 || room_num == 91){
return 0;
}

if(blocked[room_num - 1] <= 0){
return 0;
}
if(present("cave_mob", this_object()) && !this_player()->query_ghost()){
write("The "+present("cave_mob",this_object())->query_name()+" jumps in front of you blocking your path!\n");
return 1;
}	

tell_object(this_player(),
"You walk east.\n");
tell_room(environment(this_player()),
"You follow "+this_player()->query_name()+".\n", ({ this_player() }));
room_num -= 1;
renew_room(this_player()->query_level());
encounter[room_num] = 1;
command("look", this_player());
return 1;
}    

move_west(){
if(room_num == 10 || room_num == 20 || room_num == 30 || room_num == 40 || room_num == 50 ||
   room_num == 60 || room_num == 70 || room_num == 80 || room_num == 90 || room_num == 100){	

return 0;
}

if(blocked[room_num + 1] <= 0){
return 0;
}
if(present("cave_mob", this_object()) && !this_player()->query_ghost()){
write("The "+present("cave_mob",this_object())->query_name()+" jumps in front of you blocking your path!\n");
return 1;
}	

tell_object(this_player(),
"You walk west.\n");
tell_room(environment(this_player()),
"You follow "+this_player()->query_name()+".\n", ({ this_player() }));
room_num += 1;
renew_room(this_player()->query_level());
encounter[room_num] = 1;
command("look", this_player());
return 1;
} 

move_leave(){
if(room_num != 5){
return 0;
}
tell_object(this_player(),
"You leave the caves.\n");
tell_room(environment(this_player()),
this_player()->query_name()+" leaves the caves.\n", ({ this_player() }));
call_out("dest_me", 20);
move_object(this_player(), "/players/maledicta/cave/rooms/entrance.c");
command("look", this_player());
return 1;
}		   
/******************************************************************************/
dest_me(){
destruct(this_object());
return 1;
}	

realm(){   return "NT";   }



map_func(){
int numero;
int uno;
while(numero < 100){
if(uno == 0){
write(
"                          ");
}
uno ++;
	
if(blocked[100 - numero] == 0){
write(""+RED+"#"+NORM+"");
}
if(blocked[100 - numero] >= 1 && (100 - numero) != room_num){
write(""+HIR+"+"+NORM+"");
}
if((100 - numero) == room_num){
write(""+HIY+"U"+NORM+"");
}
if(uno == 10){
write("\n");
uno = 0;
}
numero ++;
}
return 1;
}				
		
catch_tell(string str){
string what;
string what1;
	
tell_room("/players/maledicta/workroom2.c",
str);
}			