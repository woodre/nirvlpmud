inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("steel amulet");
set_ac(1);
set_weight(2);
set_type("amulet");
set_value(100);
set_alias("amulet");
set_short("A Steel Amulet");
set_long("It's solid, it's steel, it's cold.\n");
}
