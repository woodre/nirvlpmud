id(str) { return str == "house" || str == "log house"; }
init() {
add_action("enter","enter");
}
enter(str) {
if (!id(str)) return 0;
write("But if you enter the house, that's tresspassing...\n");
return 1;
/*
this_player()->move_player("into the house#players/bern/newbie/house1");
return 1;
*/
}
short() { return "A small log house"; }
long() { 
write("A small log house, destined to spend its entire life in darkness.\n"
+"Just looking at the house gives you the creeps. The roof is covered\n"
+"with mold, and the logs of which the sides are made of are rotting.\n");
}
