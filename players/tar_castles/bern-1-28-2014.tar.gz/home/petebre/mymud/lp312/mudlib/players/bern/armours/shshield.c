inherit"obj/armor";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("shining shield");
set_alias("shield");
set_short("A Shining Shield");
set_long(
"You can see your reflection within it\n");
set_weight(2);
set_value(500);
set_ac(1);
set_type("shield");
}
