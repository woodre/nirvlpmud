inherit "obj/weapon.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("club");
set_short("Reject's Club");
set_long("This club looks rejected.\n");
set_class(16);
set_value(1250);
set_weight(2);
}
