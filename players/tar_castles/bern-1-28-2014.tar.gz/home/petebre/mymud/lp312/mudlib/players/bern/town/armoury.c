#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
string things;
object ob;
object arthur;

extra_reset(arg) {
   if (!arthur || !living(arthur)) {
      arthur = clone_object("players/bern/monsters/arthur");
      move_object(arthur, this_object());
   }
   if (!things) start_things();
}

extra_init() {
   add_action("list","list");
   add_action("decode","buy");
}

ONE_EXIT("players/bern/town/alley2","east",
   "armoury",
   "An armoury:\n"+
   "Arthur the Blacksmith owns this shop.\n"+
   "You can list what he has for sale, and buy items by number.\n"+
   "A sign here says: DO NOT ATTACK ARTHUR. ARTHUR IS STRONGER!\n", 1)


list() {
   write("\n"+
      "####################################################\n\n"+
      "WEAPONS:\n\n"+
      "1.  Bastard Sword of Dragons        :       10000 gp\n"+
      "2.  Glowing Sword                   :        2400 gp\n"+
      "3.  Halberd                         :        1000 gp\n"+
      "4.  Long Spear                      :         400 gp\n"+
      "\n"+
      "ARMOURS:\n\n"+
      "5.  Suit of Platemail               :        4000 gp\n"+
      "6.  Shining Chainmail               :        2200 gp\n"+
      "7.  Steel Helmet                    :         400 gp\n"+
      "8.  Leather Shield                  :         200 gp\n"+
      "9.  Silver Shield                   :         300 gp\n"+
      "10. Army Boots                      :         600 gp\n"+
      "11. Silver Ring                     :         200 gp\n"+
      "12. Mithril Amulet                  :         700 gp\n"+
      "13. Steel Amulet                    :         200 gp\n"+
      "\n"+
      "####################################################\n");
   write("\nPlease buy items by numbers.\n");
   return 1;
}

start_things() {
   things = allocate(13);
   things[0] = "players/bern/weapons/bastard.c";
   things[1] = "players/bern/weapons/glowsword.c";
   things[2] = "players/bern/weapons/halberd.c";
   things[3] = "players/bern/weapons/spear.c";
   things[4] = "players/bern/armours/platemail.c";
   things[5] = "players/bern/armours/chainmail.c";
   things[6] = "players/bern/armours/helmet.c";
   things[7] = "players/bern/armours/lshield.c";
   things[8] = "players/bern/armours/sshield.c";
   things[9] = "players/bern/armours/boots.c";
   things[10] = "players/bern/armours/sring.c";
   things[11] = "players/bern/armours/mamulet.c";
   things[12] = "players/bern/armours/samulet.c";
}

decode(str) {
   int chosen;
   if (!sscanf(str,"%d",chosen) == 1) {
      write("Please buy items by number.\n");
      return 1;
   }
   chosen += -1;
   ob = clone_object(things[chosen]);
   if (!ob) {
      write("Sorry, we do not sell that.\n");
      return 1;
   }
   can_buy();
   return 1;
}

can_buy() {
   if (!present("arthur")) {
      write("Arthur is not present to serve you.\n");
      return 1;
   }
   if ((2*ob->query_value()) > this_player()->query_money()) {
      write("You don't have enough money.\n");
      return 1;
   }
   if (!this_player()->add_weight(ob->query_weight())) {
      write("You cannot carry that much.\n");
      return 1;
   }
   write("You buy a "+ob->short()+"\n");
   say(this_player()->query_name() + " buys a "+ ob->short() + "\n");
   move_object(ob, this_player());
   this_player()->add_money(-2 * ob->query_value());
   return 1;
}
