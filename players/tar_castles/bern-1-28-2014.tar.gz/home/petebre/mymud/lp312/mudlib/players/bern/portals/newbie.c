id(str) { return str == "rift"; }
init() {
add_action("enter","enter");
}

enter(str) {
if (!id(str)) return;
if (this_player()->query_level()>5 && this_player()->query_level() < 20) {
write("You receive a shock as the rift rejects you.\n"+
	"You have been hurt.\n");
this_player()->hit_player(random(20));
return 1;
}
this_player()->move_player("into the portal#players/bern/newbie/entrance");
return 1;
}
short() { return "A rift in space"; }
long() { 
write("This is the entrance to a realm created for Newbies.\n"+
"This means you should not try to enter if your level is 5 or greater.\n"+
"Enter rift for high adventure!\n");
}
