guild() {
  object env;
  env = environment(this_player());
    if(env->realm()=="NT") {
    write("You cannot teleport from this locus...\n");
    return 1;
  }
  if (!previous_object()->query_tele()) {
    write("You can't quite remember how to do that.\n");
    write("Maybe it'll come back to you later.\n");
    return 1;
  }
  previous_object()->save_env(env);
  write("You fly through the air and land in the cleric's guild.\n");
  this_player()->move_player("to the cleric's guild#/players/bern/guild/adv_guild");
  previous_object()->reset_tele();
  return 1;
}

sp_cost() { return 60; }
query_piety() { return 0; }
