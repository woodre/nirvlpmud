revive() {
  object corpse;
  if (!previous_object()->query_death()) {
    write("You are not feigning death.\n");
    return 1;
  }
  corpse = environment(this_player());
  if (!corpse->id("corpse")) {
    previous_object()->reset_death();
    write("You are not feigning death.\n");
    return 1;
  }
  move_object(this_player(), environment(corpse));
  write("You revive.\n");
say(this_player()->query_name()+" revives from death.\n");
  destruct(corpse);
   previous_object()->reset_death();
  return 1;
}

sp_cost() { return 0; }
query_piety() { return 0; }
