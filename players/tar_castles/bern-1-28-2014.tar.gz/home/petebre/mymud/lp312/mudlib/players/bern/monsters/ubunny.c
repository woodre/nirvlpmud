
inherit"obj/monster";
reset(arg) {
object treasure;
::reset(arg);
if(arg) return;
set_name("ugly bunny");
set_alias("bunny");
set_short("An ugly bunny");
set_long(
"He's kind of scrawny and covered with sores and scabs.\n"
+ "His name is Jeremy.\n");
set_level(4);
set_hp(60);
set_wc(8);
set_ac(4);
set_race("animal");
set_spell_mess2("");
treasure = clone_object("/players/bern/food/carrot");
if(treasure) move_object(treasure,this_object());
}
