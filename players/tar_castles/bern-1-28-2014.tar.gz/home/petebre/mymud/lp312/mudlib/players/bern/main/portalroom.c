

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
if (!present("portal")) {
move_object(clone_object("players/bern/portals/newbie"), this_object());
}
    short_desc = "newbie portal";
    no_castle_flag = 0;
    long_desc = 
        "The surroundings have the sense that great magicks have been cast.\n"
        + "A rift in space has been created. It stands shimmering, waiting for\n"
        + "young adventurers to test their luck.\n";
    dest_dir = 
        ({
        "players/bern/main/hill", "north",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

