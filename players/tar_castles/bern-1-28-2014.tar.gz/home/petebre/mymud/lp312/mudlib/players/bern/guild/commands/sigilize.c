sigilize(i) {
  object monster;
  if (mark) {
    write("You have already sigilized a monster with your mark.\n");
    return 1;
  }
  monster = present(i, environment(this_player()));
  if (!monster) {
    write("That is not here.\n");
    return 1;
  }
  if (!monster->query_npc() || !living(monster)) {
    write("You can't sigilize that!\n");
    return 1;
  }
  mark = clone_object("players/bern/guild/mark");
  mark->set_owner(this_player());
  mark->set_target(monster);
  move_object(mark, environment(monster));
  write("You have set your mark upon "+monster->short()+"\n");
  say(this_player()->query_name()+" puts his mark on "+monster->short()+"\n");
  return 1;
}

sp_cost() { return 0; }
query_piety() { return 0; }
