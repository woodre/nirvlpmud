#include "std.h"
#include "tune.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset(arg);

extra_reset(arg) {
   object ob;
   if (arg)
      return;
   move_object(clone_object("players/bern/guild/board"), this_object());
   start_titles();
}

#undef EXTRA_INIT
#define EXTRA_INIT my_init();

my_init() {
   if(this_player()->query_guild_file() != "players/bern/guild/robes") {
      if(!this_player()->query_ok()) {
         if(!this_player()->query_npc()) {
            write("You do not belong to this guild.\n");
            this_player()->move_player("west#players/asmithrune/rooms/trail");
            return 1;
         }
         add_action("cost_for_level"); add_verb("cost");
         add_action("advance"); add_verb("advance");
         add_action("banish"); add_verb("banish");
         add_action("raise"); add_verb("raise");
         add_action("list_quests"); add_verb("list");
         add_action("robe","robe");
      }
   }
}

ONE_EXIT("players/asmithrune/rooms/trail","west",
   "The cleric's guild",
   "This is the cleric's guild.\n"+
   "You have to come here when you want to advance your level.\n" +
   "You can also buy points for a new level.\n" +
   "Commands: cost, advance [level, str, dex, int, con],\n"+
   "list (number), and robe (to get a new one).\n",
   1)

int next_level;
int valexp;
int next_exp;
int level;
int exp;
string guild_title;
string title;         /* now with arrays. ! */
object player_ob;
string banished_by;

/* called by the fixtitle function */

query_title(ob) {
   int i;
   i = ob->query_level();
   if (i>19) return ob->query_title();
   return guild_title[i-1];
}

robe() {
   object robe;
   if (this_player()->query_guild_file() != "players/bern/guild/robes") {
      write("You do not belong to this guild.\n");
      this_player()->move_player("west#players/asmithrune/rooms/trail");
      return 1;
   }
   robe = present("clericguild", this_player());
   if (!robe) {
      write("You get your new robes.\n");
      move_object(clone_object("players/bern/guild/robes"), this_player());
      return 1;
   }
   destruct(robe);
   move_object(clone_object("players/bern/guild/robes"), this_player());
   write("You get your new robes.\n");
   return 1;
}

/* some minor changes by Iggy. */
/* get level asks get_next_exp() and  get_next_title() */

get_level(str)
{
   level = str;
   
   next_exp   = get_next_exp(level);
   next_level = level + 1 ;
   player_ob = this_player();
   title      = get_new_title(level);
}

/*xxx  return title */
get_new_title(str)
{
   if (!guild_title) start_titles();
   return guild_title[str];
}
start_titles() {
   guild_title = allocate(20);
   guild_title[19] = "the apprentice Wizard";
   guild_title[18] = "the Master Cleric";
   guild_title[17] = "the Adept of Wisdom";
   guild_title[16] = "the Adept of Knowledge";
   guild_title[15] = "the Adept of Light";
   guild_title[14] = "the Seeker of Wisdom";
   guild_title[13] = "the Seeker of Knowledge";
   guild_title[12] = "the Seeker of Light";
   guild_title[11] = "the Acolyte of Wisdom";
   guild_title[10] = "the Acolyte of Knowledge";
   guild_title[9] = "the Acolyte of Light";
   guild_title[8] = "the Initiate of Wisdom";
   guild_title[7] = "the Initiate of Knowledge";
   guild_title[6] = "the Initiate of Light";
   guild_title[5] = "the Prelate";
   guild_title[4] = "the Abbot";
   guild_title[3] = "the Monk";
   guild_title[2] = "the Lowrank Cleric";
   guild_title[1] = "the Beginner Cleric";
   guild_title[0] = "the Neophyte Cleric";
}

int exp_str;

/*  returns the next_exp. */
get_next_exp(str) {
   if(!exp_str){
      exp_str = allocate(20);
      
      exp_str[19]     = 2500000;
      exp_str[18]     =  2000000;
      exp_str[17]     =  1367106;
      exp_str[16]     =  1040028;
      exp_str[15]     =  820028;
      exp_str[14]     =  620026;
      exp_str[13]     =   492294;
      exp_str[12]     =   295592;
      exp_str[11]     =   195591;
      exp_str[10]     =   134998;
      exp_str[9]      =   90000;
      exp_str[8]      =   59995;
      exp_str[7]      =   39993;
      exp_str[6]      =    26662;
      exp_str[5]      =    12812;
      exp_str[4]      =    5885;
      exp_str[3]      =    2332;
      exp_str[2]      =    1771;
      exp_str[1]      =    1014;
      exp_str[0]      =       0;
   }
   return exp_str[str];
}

/*
* This routine is called by monster, to calculate how much they are worth.
* This value should not depend on the tuning.
*/
query_cost(l) {
   player_ob = this_player();
   level = l;
   if (level >= 20)
      return 2000000;
   get_level(level);
   valexp = 18*next_exp/30;
   return valexp;
   /*
   return next_exp;
   */
}

/*
* Special function for other guilds to call. Arguments are current level
* and experience points.
*/
query_cost_for_level(l, e) {
   level = l;
   exp = e;
   get_level();
   if (next_exp <= exp)
      return 0;
   return (next_exp - exp) * 1000 / EXP_COST;
}

cost_for_level() {
   player_ob = this_player();
   level = call_other(player_ob, "query_level", 0);
   if (level >= 20) {
      write("You will have to seek other ways.\n");
      return 1;
   }
   exp = call_other(player_ob, "query_exp", 0);
   get_level(level);
   if (next_exp <= exp) {
      write("It will cost you nothing to be promoted.\n");
      return 1;
   }
   if ((next_exp - exp) > next_exp/10 || (next_exp - exp) > 15000) {
      write("You must be closer to the next level before buying experience.\n");    return 1;
   }
   write("It will cost you "); write((next_exp - exp) * 1000 / EXP_COST);
   write(" gold coins to advance to level "); write(next_level);
   write(".\n");
   return 1;
}

advance() {
   string name_of_player;
   int cost;
   player_ob = this_player();
   name_of_player = call_other(player_ob, "query_name", 0);
   level = call_other(player_ob, "query_level", 0);
   if (level == -1)
      level = 0;
   exp = call_other(player_ob, "query_exp", 0);
   title = call_other(player_ob, "query_title", 0);
   if (level >= 20) {
      write("You are still "); write(title); write("\n");
      return 1;
   }
   get_level(level);
   if (next_level == 20 && call_other("room/quest_room", "count", 0))
      return 1;
   cost = (next_exp - exp) * 1000 / EXP_COST;
   if (next_exp > exp) {
      if (call_other(player_ob, "query_money", 0) < cost) {
         write("You don't have enough gold coins.\n");
         return 1;
       }
      if((next_exp - exp) > next_exp/10 || (next_exp - exp) > 15000) {
         write("You must be closer to the next level before buying experience.\n");
         return 1;
       }
      call_other(player_ob, "add_money", - cost);
   }
   say(call_other(player_ob, "query_name", 0) + " is now level " +
      next_level + ".\n");
   call_other(player_ob, "set_level", next_level);
   call_other(player_ob, "set_title", title);
   if (exp < next_exp)
      call_other(player_ob, "add_exp", next_exp - exp);
   if (next_level < 7) {
      write("You are now " + name_of_player + " " + title +
         " (level " + next_level + ").\n");
      return 1;
   }
   if (next_level < 14) {
      write("Well done, " + name_of_player + " " + title +
         " (level " + next_level + ").\n");
      return 1;
   }
   if (next_level < 20) {
      write("Welcome to your new class, mighty one.\n" +
         "You are now " + title + " (level " + next_level + ").\n");
   }
   if (next_level == 20) {
      write("A new Wizard has been born.\n");
      shout("A new Wizard has been born.\n");
      write("If you want a castle of your own, seek out Leo the archwizard,\n");
      write("and ask him.\n");
      return 1;
   }
   return 1;
}

/*
* Banish a monster name from being used.
*/
banish(who) {
   level = call_other(this_player(), "query_level");
   if (level < 21)
      return 0;
   if (!who) {
      write("Who ?\n");
      return 1;
   }
   if (!call_other(this_player(), "valid_name", who))
      return 1;
   if (restore_object("players/" + who)) {
      write("That name is already used.\n");
      return 1;
   }
   if (restore_object("banish/" + who)) {
      write("That name is already banished.\n");
      return 1;
   }
   banished_by = call_other(this_player(), "query_name");
   title = call_other(this_player(), "query_title");
   if (banished_by == "Someone") {
      write("You must not be invisible!\n");
      return 1;
   }
   save_object("banish/" + who);
   return 1;
}

south() {
   if (call_other(this_player(), "query_level", 0) < 20) {
      write("A strong magic force stops you.\n");
      say(call_other(this_player(), "query_name", 0) +
         " tries to go through the field, but fails.\n");
      return 1;
   }
   write("You wriggle through the force field...\n");
   call_other(this_player(), "move_player", "south#room/adv_inner");
   return 1;
}

list_quests(num)
{
   int qnumber;
   if (num == "all") {
      call_other("room/quest_room", "list_all");
      return 1;
   }
   if (num && (sscanf(num, "%d", qnumber) == 1))
      call_other("room/quest_room", "list", qnumber);
   else
      call_other("room/quest_room", "count", 0);
   return 1;
}

query_drop_castle() {
   return 1;
}
correct_level(player)
{
   level = call_other(player, "query_level", 0);
   exp = call_other(player, "query_exp", 0);
   /* Shouldn't "correct" wizards. */
   if (level >= 20)
      return;
   get_level(level);
   while (exp < next_exp) {
      level -= 1;
      get_level(level);
   }
   if (next_level == 20 && call_other("room/quest_room", "count", 0))
      next_level = 19;
   call_other(player, "set_level", next_level);
   call_other(player, "set_title", title);
}
raise(str) {
   string attrib,raise,thing;
   int new,expcost,current,minexp;
   if (str !="str" && str !="sta" && str != "wil" && str != "mag" && str !="pie"&& str != "ste" && str != "luc" && str != "int")
      {
      write ("Raise what?\n");
      return 1;
   }
   if (call_other(this_player(), "query_level", 0) > 19) {
      write("wizards cannot advance attributes.\n");
      return 1;
   }
   if (str == "str") {
      attrib = "strength";
   }
   if (str == "sta"){
      attrib = "stamina";
   }
   if (str == "wil") attrib = "will_power";
   if (str == "mag") attrib = "magic_aptitude";
   if (str == "pie") attrib = "piety";
   if (str == "ste") attrib = "stealth";
   if (str == "luc") attrib = "luck";
   if (str == "int") attrib = "intelligence";
   raise = "raise_" + attrib;
   current = call_other(this_player(), "query_attrib", str);
   new = current + 1;
   /*
   log_file("ATTRIB", this_player()->query_real_name() + " Raised " + attrib +" from " + current + " to " +
      new + "\n");
   */
   if (current < 12) expcost = -ATTRIB_COST;
   if (current < 16 && current > 11) expcost = -ATTRIB_COST_TWO;
   if (current < 20 && current > 15) expcost = -ATTRIB_COST_THREE;
   if (current > 19) {
      write (attrib + " is at highest possible value.\n");
      return 1;
   }
   minexp = this_player()->query_exp() - get_next_exp(this_player()->query_level()-1);
   if (expcost < -minexp) {
      write ("You don't have enough experience available to raise an attribute.\n");
      return 1;
   }
   call_other(this_player(), raise, 1);
   call_other(this_player(), "add_exp", expcost);
   return 1;
}

realm() { return "NT"; }
