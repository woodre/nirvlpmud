alignment(str) {
  object victim;
  if (!str) {
    write("Your alignment: "+ this_player()->query_alignment() + "\n");
    return 1;
  }
  victim = present(str, environment(this_player()));
  if (!victim) {
    write("That is not here.\n");
    return 1;
  }
  if (!living(victim)) {
    write("You can't do that!\n");
    return 1;
  }
  write(capitalize(str) + "'s alignment: " + victim->query_alignment() + "\n"); 
 return 1;
}

sp_cost() { return 0; }
query_piety() { return 0; }
