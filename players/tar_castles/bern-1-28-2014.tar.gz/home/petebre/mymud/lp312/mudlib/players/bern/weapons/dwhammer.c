inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("hammer");
set_alias("dwarven hammer");
set_short("Dwarven Hammer");
set_value(1500);
set_weight(2);
set_class(15);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100)<50 && attacker->id("dwarf")) {
write("You smash "+attacker->query_name()+" with your Dwarven Hammer!\n");
say(attacker->query_name()+" is smashed by "+this_player()->query_name()+"'s Dwarven Hammer!\n");
return 5;
   }
return 0;
 }
