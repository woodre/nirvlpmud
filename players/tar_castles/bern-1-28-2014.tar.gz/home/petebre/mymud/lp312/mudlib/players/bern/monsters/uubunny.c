
inherit"obj/monster";
reset(arg) {
object treasure;
::reset(arg);
if(arg) return;
set_name("uglier bunny");
set_alias("bunny");
set_short("An even uglier bunny");
set_long(
"Yuck! She's a terror to look at.\n"
+ "We'll just call her Susan.\n");
set_level(5);
set_hp(75);
set_wc(9);
set_ac(5);
set_race("animal");
set_spell_mess2("");
treasure = clone_object("/players/bern/food/carrot");
if(treasure) move_object(treasure,this_object());
}
