inherit "obj/weapon.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("zapper");
set_short("A harry zapper");
set_value(2);
set_class(5);
set_hit_func(this_object());
}

weapon_hit(attacker) {
if (attacker->id("harry")) return 100000;
return 5;
}
