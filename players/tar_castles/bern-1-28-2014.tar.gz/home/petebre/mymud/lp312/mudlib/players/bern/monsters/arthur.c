inherit "obj/monster.c";
reset(arg) {
object money;
::reset(arg);
if (arg) return;
set_name("arthur");
set_alias("blacksmith");
set_level(20);
set_hp(500);
set_ac(17);
set_wc(30);
set_short("Arthur the Blacksmith");
set_long("He towers above you, but Arthur looks friendly enough.\n");
money = clone_object("obj/money.c");
money->set_money(2000);
move_object(money, this_object());
}
