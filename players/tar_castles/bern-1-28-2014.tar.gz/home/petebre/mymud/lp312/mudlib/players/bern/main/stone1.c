

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "cliffs";
    no_castle_flag = 0;
    long_desc = 
        "You venture among these cliffs that seem to sprout from where the forest\n"
        + "used to be. You wonder why there should be cliffs. To the north, you can\n"
        + "see the forest. It seems to stop rather abruptly.\n";
    dest_dir = 
        ({
        "players/bern/main/forest6", "north",
        "players/bern/main/stone3", "west",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

