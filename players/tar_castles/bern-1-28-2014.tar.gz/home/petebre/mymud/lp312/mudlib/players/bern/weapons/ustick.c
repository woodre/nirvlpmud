inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("ugly stick");
set_alias("stick");
set_short("An ugly stick");
set_long(
"It lends new meaning to the expression 'beat that person with an ugly stick'\n");
set_value(50);
set_weight(1);
set_class(11);
}
