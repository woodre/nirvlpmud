inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "forest [w]";
    long_desc =
	"The trees crowd around here allowing you only to go back west.\n";
    dest_dir =
        ({
        "players/bern/main/forest6", "west",
        });
}
