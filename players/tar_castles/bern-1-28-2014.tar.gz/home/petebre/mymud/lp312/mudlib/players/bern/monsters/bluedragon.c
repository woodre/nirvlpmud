
inherit"obj/monster";
reset(arg) {
object money;
object armour;
object treasure;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!a_chat_str) {
a_chat_str = allocate(3);
a_chat_str[0] = "Blue Dragon says: Die puny human!\n";
a_chat_str[1] = "Blue Dragon says: How dare you interrupt my sleep!\n";
a_chat_str[2] = "Blue Dragon says: You wimp.\n";
  }
set_name("blue dragon");
set_alias("dragon");
set_short("Blue Dragon");
set_long(
"He looks upset that you disturbed him\n");
set_level(18);
set_race("dragon");
set_hp(300);
set_al(100);
set_wc(26);
set_ac(15);
set_aggressive(1);
set_chance(10);
set_spell_dam(35);
set_spell_mess1("Blue Dragon breathes a sheet of blue flame");
set_spell_mess2("You are engulfed in a sheet of blue flame");
load_a_chat(10,a_chat_str);
set_random_pick(40);
money = clone_object("obj/money");
money->set_money(700);
move_object(money, this_object());
armour = clone_object("/players/bern/armours/shshield");
if(armour) {
move_object(armour,this_object());
  }
treasure = clone_object("/players/bern/magic/mbag");
if(treasure) move_object(treasure,this_object());
}
