
cure(str) {
  object victim;
  object poison, next;
  string a,b;
  if (!str) victim = this_player();
  else victim = present(str, environment(this_player()));
  poison = first_inventory(victim);
  while (poison) {
    next = next_inventory(poison);
    if (sscanf(file_name(poison),"%spoison%s",a,b) == 2 ||
        poison->id("poison")) {
      destruct(poison);
    }
    poison = next;
  }
  write("You cast a cure spell on "+victim->query_name()+".\n");
  tell_object(victim,
              "You feel a soothing light bathe over you,\n"+
              "removing all traces of poison from your person.\n");
  tell_room(environment(this_player()),this_player()->query_name()+
            " casts a purifying light upon ");
  if (victim == this_player())
      tell_room(environment(this_player()),
                this_player()->query_objective()+"self.\n");
  else tell_room(environment(this_player()),victim->query_name()+".\n");
  return 1;
}

sp_cost() { return 40; }
query_piety() { return 16; }
