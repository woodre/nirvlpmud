
inherit"obj/monster";
reset(arg) {
object money;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(3);
a_chat_str = allocate(3);
chat_str[0] = "Tim picks his nose.\n";
chat_str[1] = "Tim picks your nose.\n";
chat_str[2] = "Tim throws a booger at you!\n";
a_chat_str[0] = "Tim sneezes on you.\n";
a_chat_str[1] = "Tim wipes his butt.\n";
a_chat_str[2] = "Tim belches.\n";
  }
set_name("tim");
set_short("Tim");
set_long(
"He's huge and disgusting.\n"
+ "He has a finger in his nose.\n");
set_level(13);
set_race("human");
set_al(-1000);
set_wc(17);
set_ac(10);
set_hp(195);
set_aggressive(1);
set_chance(10);
set_spell_dam(20);
set_spell_mess1("Tim roars!");
set_spell_mess2("Tim headbutts you.");
load_chat(10,chat_str);
load_a_chat(10,a_chat_str);
set_random_pick(50);
money = clone_object("obj/money");
money->set_money(1000);
move_object(money, this_object());
}
