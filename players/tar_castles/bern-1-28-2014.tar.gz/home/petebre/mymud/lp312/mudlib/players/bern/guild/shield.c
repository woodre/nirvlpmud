inherit "obj/armor.c";
reset(arg) {
  ::reset(arg);
    if (arg) return;
    set_name("cleric shield");
    set_short(this_player()->query_name()+"'s Cleric Shield");
    set_long("The shield more clerics choose.\n");
    set_ac(1);
    set_type("shield");
    set_value(0);
call_out("done",600);
  }

init() {
  ::init();
    add_action("wear","wear");
  }

wear(str) {
  if (!id(str)) return 0;
  if (present("clericguild", this_player())) {
    ::wear();
      return 1;
    }
  write("Only cleric guild members can wear this.\n");
  return 1;
}

drop() {
write("You cannot drop your Cleric Shield.\n");
  return 1;
}


done() {
command("remove shield", this_player());
write("Your Cleric Shield shimmers and fades away.\n");
destruct(this_object());
return 1;
}
