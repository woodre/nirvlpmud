id(str) { return str == "cigar";}
int lit;
reset(arg) {
if (arg) return;
lit = 0;
}
init() {
add_action("lit","light");
add_action("smoke","smoke");
}
lit(str) {
if (!id(str)) return 0;
write("You light the cigar\n");
say(this_player()->query_name()+" lights a cigar.\n");
lit = 1;
call_out("done",600);
return 1;
}
smoke(str) {
if (!id(str)) return 0;
if (!lit) { write("light the cigar first...\n");
return 1;
}
write("You blow a cloud of smoke.\n");
say(this_player()->query_name()+" blows a cloud of smoke\n");
return 1;
}
short() { 
if (!lit) return "A cigar";
return "A cigar (lit)";
}
long() {
write("Try lighting and smoking it.\n"+
"It is to celebrate Kenn and Cutestuff's wedding.\n");
}
get() { return 1; }
drop() { return 0; }
done() {
write("The cigar burns out and disappears.\n");
say(this_player()->query_name()+" finishes his cigar\n");
destruct(this_object());
return 1;
}
