reset(arg) {
move_object("players/bern/guild/robes", environment(find_living("bern")));
}
