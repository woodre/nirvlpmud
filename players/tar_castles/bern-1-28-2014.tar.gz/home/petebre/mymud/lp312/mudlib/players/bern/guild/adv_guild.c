#include "std.h"
#include "tune.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset(arg);

extra_reset(arg) {
   object ob;
   if (arg)
      return;
   move_object(clone_object("players/bern/guild/board"), this_object());
   start_titles();
}

#undef EXTRA_INIT
#define EXTRA_INIT my_init();

my_init() {
   if(this_player()->query_guild_file() != "players/bern/guild/robes") {
      if(!this_player()->query_ok()) {
         if(!this_player()->query_npc()) {
            write("You do not belong to this guild.\n");
            this_player()->move_player("north#players/bern/guild/recruit");
            return 1;
         }
         }}
         add_action("cost_for_level"); add_verb("cost");
         add_action("advance"); add_verb("advance");
         add_action("raise"); add_verb("raise");
         add_action("robe","robe");
}

ONE_EXIT("players/bern/guild/recruit", "north",
   "The cleric's guild",
   "This is the cleric's guild.\n"+
   "You have to come here when you want to advance your level.\n" +
   "You can also buy points for a new level.\n" +
   "Commands: cost, advance, raise <attrib>,\n"+
   "and robe (to get a new one).\n",
   1)

int next_level;
int valexp;
int next_exp;
int level;
int exp;
string guild_title;
string title;         /* now with arrays. ! */
object player_ob;
string banished_by;

/* called by the fixtitle function */

query_title(ob) {
   int i;
   i = ob->query_level();
   if (i>19) return ob->query_title();
   return guild_title[i-1];
}

robe() {
   object robe;
   if (this_player()->query_guild_file() != "players/bern/guild/robes") {
      write("You do not belong to this guild.\n");
      this_player()->move_player("north#players/bern/guild/recruit");
      return 1;
   }
   robe = present("clericguild", this_player());
   if (!robe) {
      write("You get your new robes.\n");
      move_object(clone_object("players/bern/guild/robes"), this_player());
      return 1;
   }
   destruct(robe);
   move_object(clone_object("players/bern/guild/robes"), this_player());
   write("You get your new robes.\n");
   return 1;
}

get_new_title(str)
{
   if (!guild_title) start_titles();
   return guild_title[str];
}
start_titles() {
   guild_title = allocate(20);
   guild_title[19] = "the apprentice Wizard";
   guild_title[18] = "the Master Cleric";
   guild_title[17] = "the Adept of Wisdom";
   guild_title[16] = "the Adept of Knowledge";
   guild_title[15] = "the Adept of Light";
   guild_title[14] = "the Seeker of Wisdom";
   guild_title[13] = "the Seeker of Knowledge";
   guild_title[12] = "the Seeker of Light";
   guild_title[11] = "the Acolyte of Wisdom";
   guild_title[10] = "the Acolyte of Knowledge";
   guild_title[9] = "the Acolyte of Light";
   guild_title[8] = "the Initiate of Wisdom";
   guild_title[7] = "the Initiate of Knowledge";
   guild_title[6] = "the Initiate of Light";
   guild_title[5] = "the Prelate";
   guild_title[4] = "the Abbot";
   guild_title[3] = "the Monk";
   guild_title[2] = "the Lowrank Cleric";
   guild_title[1] = "the Beginner Cleric";
   guild_title[0] = "the Neophyte Cleric";
}

int exp_str;

advance() {
call_other("room/adv_guild","advance",0);
if(this_player()->query_level() < 21)
{
this_player()->set_title(guild_title[this_player()->query_level() - 1]);
write("You are now "+this_player()->short()+"\n");
}
return 1;
}
south() {
   if (call_other(this_player(), "query_level", 0) < 20) {
      write("A strong magic force stops you.\n");
      say(call_other(this_player(), "query_name", 0) +
         " tries to go through the field, but fails.\n");
      return 1;
   }
   write("You wriggle through the force field...\n");
   call_other(this_player(), "move_player", "south#room/adv_inner");
   return 1;
}


query_drop_castle() {
   return 1;
}
correct_level(player)
{
   level = call_other(player, "query_level", 0);
   exp = call_other(player, "query_exp", 0);
   /* Shouldn't "correct" wizards. */
   if (level >= 20)
      return;
   get_level(level);
   while (exp < next_exp) {
      level -= 1;
      get_level(level);
   }
   if (next_level == 20 && call_other("room/quest_room", "count", 0))
      next_level = 19;
   call_other(player, "set_level", next_level);
   call_other(player, "set_title", title);
}
raise(str) {
call_other("room/adv_guild","raise",str);
return 1;
}

realm() { return "NT"; }
cost_for_level() {
call_other("room/adv_guild","cost_for_level",0);
return 1;
}
