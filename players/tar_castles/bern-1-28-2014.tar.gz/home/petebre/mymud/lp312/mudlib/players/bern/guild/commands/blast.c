blast(str) {
  object victim;
  if (!str) victim = this_player()->query_attack();
  else
    victim = present(str, environment(this_player()));
  if (!living(victim) || (!victim->query_npc() && victim->query_pl_k())) {
    write("You cannot attack that!");
    say(this_player()->query_name() + " foolishly tries to attack "+ str+"\n"); 
   return 1;
  }
  this_player()->spell_object(victim, "BLAST spell", random(25)+10, 0);
write(this_player()->query_name()+" BLASTS " + victim->short()+"\n");
say(this_player()->query_name()+" BLASTS " + victim->short()+"\n");
  return 1;
}

sp_cost() { return 24; }
query_piety() { return 15; }
