inherit "obj/monster.c";
string description;
string owner;
reset(arg) {
    if (arg) return;
    move_object(clone_object("obj/soul"), this_object());
    set_level(15);
   this_object()->raise_strength(19);
    set_alias("jr");
    set_al(0);
    set_wc(0);
    set_hp(1);
    set_ep(0);
    set_long("He eyes you suspiciously.\n");
    enable_commands();
    set_heart_beat(1);
  }

set_owner(i) {
  set_name(lower_case(i)+" jr");
  set_short(i+" jr");
  owner = i;
}

heart_beat() {
  object ob;
::heart_beat();
  age += 1;
  ob = find_player(lower_case(owner));
  if (!ob) {
    say("Helper despairs of finding his owner.\n");
    say("Helper says: good bye cruel world!\n");
    destruct(this_object());
    return 1;
  }
  if (!present(ob, environment(this_object()))) {
   tell_room(environment(this_object()),
        short()+" leaves.\n");
    move_object(this_object(), environment(ob));
    tell_room(environment(ob), this_object()->short()+" arrives.\n");
  }
}

pick_up(ob) {
  int weight;
  if (!ob) return 1;
  if (!ob->get()) return 1;
  weight = ob->query_weight();
  if (!add_weight(weight)) return 1;
  move_object(ob, this_object());
  say(short()+" gets "+ob->short()+"\n");
  return 1;
}

drop_all() {
  object item, next;
  int weight;
  item = first_inventory(this_object());
  weight = this_object()->query_weight();
  while(item) {
    next = next_inventory(item);
    if (!item->drop()) {
      move_object(item, environment(this_object()));
      say(short()+" drops "+item->short()+"\n");
    }
    item = next;
  }
  add_weight(-weight);
  return 1;
}

drop_thing(ob) {
  int weight;
  weight = ob->query_weight();
  if (!ob->drop()) {
    move_object(ob, environment(this_object()));
    add_weight(-weight);
    say(short()+" drops "+ob->short()+"\n");
    return 1;
  }
  return 1;
}

drop_money() {
  int amt;
  object coins;
  amt = this_object()->query_money();
  if (!amt) return 1;
  coins = clone_object("obj/money");
  coins->set_money(amt);
  move_object(coins, environment(this_object()));
  say(short()+ " drops "+coins->short()+"\n");
  add_money(-amt);
  return 1;
}


get_all(i) {
  object item, next, container;
  if (i) {
    container = present(i, this_object());
    if (!container) container = present(i, environment(this_object()));
    if (!container) {
      say(short()+" complains that he doesn't have "+i+"\n");
    }
    item = first_inventory(container);
  }
  else item = first_inventory(environment(this_object()));
  while(item) {
    next = next_inventory(item);
    pick_up(item);
    item = next;
  }
  return 1;
}

query_guild() { return "cleric"; }

long() {
  write(short()+"\n"+
        "He eyes you suspiciously.\n");
  if (description) write(description +"\n");
}

describe(i) {
  description = i;
}

add_money(i) { money += i; }

query_save_flag() { return 1; }

query_ok() { return 1; }
