inherit "players/bern/guild/robes";
id(str) { return str == "commands"; }
get() { return 1; }
