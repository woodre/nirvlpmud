shadow(str) {
  object ob;

  ob = find_player(str);
  if(!ob) {
    write("Sulk..\n");
    return 1;
  }
 return efun::shadow(ob,1);
}


query_real_name() {
return "morgoth";
}

short() {
return 0;
}

long() {
return 1;
}

