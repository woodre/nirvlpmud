inherit "room/room";
object ob;
int i;
reset(arg) {
  if (arg) return;
  if (!present("shovel")) {
    for(i=0;i<1;i++) {
      ob = clone_object("players/bern/treasure/shovel");
      move_object(ob, this_object());
    }
  }
  set_light(1);
  short_desc = "stone walls [n,s,w]";
  long_desc = "There are a bunch of holes in the ground here as if\n"+
    "someone were looking for something here.\n";
  dest_dir = ({
    "players/bern/main/stone14","north",
    "players/bern/main/den1","west",
    "players/bern/main/stone16","south",
  });
  items = ({
    "hole","Someone was obviously looking for something here",
    "holes","Someone was obviously looking for something here",
  });
  i = 0;
}

init() {
  ::init();
    add_action("dig","dig");
}
     
dig() {
  if (present("shovel"),this_player() && !i) {
    write("You dig up some coins!\n");
    say(this_player()->query_name()+" digs up some coins!\n");
    ob = clone_object("obj/money");
    ob->set_money(random(150));
    move_object(ob, this_object());
    i = 1;
    return 1;
  }
  write("You dig another hole into the landscape but find nothing.\n");
  say(this_player()->query_name()+" digs a hole.\n");
  return 1;
}

