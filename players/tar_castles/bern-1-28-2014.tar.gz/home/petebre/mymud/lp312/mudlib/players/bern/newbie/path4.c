#define LOAD_CBUNNY move_object(clone_object("/players/bern/monsters/cbunny"),this_object())
#define LOAD_UBUNNY move_object(clone_object("/players/bern/monsters/ubunny"),this_object())

inherit "room/room";

reset(arg) {
while(!present("cute bunny 3")) LOAD_CBUNNY;
while(!present("ugly bunny 3")) LOAD_UBUNNY;
    if (arg) return;

    set_light(1);
short_desc = "A split in the path";
    no_castle_flag = 0;
    long_desc = 
"Here, the path splits into two seperate paths. To your west, the path\n"
+"looks run down and depressing, the earth marred and the creatures\n"
+"hideous. To the south, the path continues in through the beautiful\n"
+"valley.\n";
    dest_dir = 
        ({
        "players/bern/newbie/path3", "north",
        "players/bern/newbie/ugly1", "west",
        "players/bern/newbie/path5", "south",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

