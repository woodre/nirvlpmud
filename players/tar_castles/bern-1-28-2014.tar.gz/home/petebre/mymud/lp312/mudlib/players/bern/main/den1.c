inherit "room/room";
object ob;
int i;
reset(arg) {
  if (arg) return;
  set_light(1);
  short_desc = "blue den [n,e]";
  long_desc = "You have walked into the den of some sort of creature.\n"+
    "You are lucky he is not here right now.\n";
  dest_dir = ({
    "players/bern/main/blue","north",
    "players/bern/main/stone15","east",
  });
  items = ({
    "den","It is a well furnished, comfortable den, with some char marks\n"+
      "on the walls",
  });
}
