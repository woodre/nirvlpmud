

inherit "room/room";
int dug;
object money;

init() {
add_action("dig","dig");
::init();
}

dig() {
if (!present("shovel", this_player())) {
write("You try digging, but find nothing.\n");
say(this_player()->query_name()+ " starts digging randomly.\n");
return 1;
}
if (!dug) {
write("You find some money!\n");
say(this_player()->query_name()+ " digs and finds some money!\n");
dug = 1;
money = clone_object("obj/money");
money->set_money(random(50));
move_object(money, this_object());
return 1;
}
write("You try digging, but find nothing.\n");
say(this_player()->query_name()+ " starts digging randomly.\n");
return 1;
}
reset(arg) {
    if (arg) return;

if (!present("shovel")) {
move_object(clone_object("players/bern/object/shovel"), this_object());
}
dug = 0;
    set_light(1);
    short_desc = "road to Newbie town... shovel";
    no_castle_flag = 0;
    long_desc = 
        "On the road to Newbie town, you see lots of holes everywhere.\n"
        + "You wonder why people have been digging here.\n";
    dest_dir = 
        ({
        "players/bern/newbie/road3", "east",
        "players/bern/newbie/road1", "west",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

