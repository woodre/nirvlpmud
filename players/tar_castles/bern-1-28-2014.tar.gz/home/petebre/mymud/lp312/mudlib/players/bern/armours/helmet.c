inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("helmet");
set_ac(1);
set_weight(1);
set_type("helmet");
set_value(200);
set_alias("steel helmet");
set_short("A steel helmet");
set_long("The helmet looks shiny.\n");
}
