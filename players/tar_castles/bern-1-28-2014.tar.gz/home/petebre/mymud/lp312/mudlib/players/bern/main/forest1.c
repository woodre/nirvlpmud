

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "On the bridge [e,w]";
    no_castle_flag = 0;
    long_desc = 
        "The bridge crosses over what looks to be a dry riverbed below.\n"
        + "You are confused why there should even be a bridge.\n";
    dest_dir = 
        ({
        "players/bern/main/bridge", "west",
        "players/bern/main/forest2", "east",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

