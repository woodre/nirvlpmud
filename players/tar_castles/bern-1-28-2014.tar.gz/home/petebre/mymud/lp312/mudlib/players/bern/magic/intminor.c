#define name "potion"
#define short_desc "A Potion of Minor Healing (intox)"
#define message "You drink a potion of minor healing (intox)"
#define heal 15
#define value 250
#define strength 5

inherit "obj/drink.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_value(name + "#" + short_desc + "#" + message + "#" + heal + "#" +
value + "#" + strength);
}

query_value() { return 250; }
