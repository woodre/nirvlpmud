id(str) { return str == "potion"; }
short() { return "A Potion of Major Healing"; }
long() { write("It looks pretty vile tasting.\n");
return 1;
}
get() { return 1; }
drop() { return 0; }
query_value() { return 3000; }
init() {
add_action("drink","drink");
}

drink() {
say(this_player()->query_name() + " drinks a potion of major healing.\n");
write("You drink a potion of major healing.\n");
this_player()->heal_self(50);
destruct(this_object());
return 1;
}
