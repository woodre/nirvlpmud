
inherit"obj/monster";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("dwarf");
set_alias("small dwarf");
set_short("a small dwarf");
set_level(10);
set_hp(150);
set_wc(14);
set_ac(8);
set_race("dwarf");
set_spell_mess2("");
}
