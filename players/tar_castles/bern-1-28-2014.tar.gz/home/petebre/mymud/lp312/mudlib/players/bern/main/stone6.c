inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "stone walls [n]";
    long_desc = "A stone wall looms in front of you preventing you from\n"+
	"getting any further here.\n";
    dest_dir =
        ({
        "players/bern/main/stone3", "north",
        });
}
