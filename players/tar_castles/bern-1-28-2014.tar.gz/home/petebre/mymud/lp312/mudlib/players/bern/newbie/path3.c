
#define LOAD_BUNNY move_object(clone_object("/players/bern/monsters/cbunny"),this_object())

inherit "room/room";

reset(arg) {
  if(!present("bunny")) LOAD_BUNNY;
  if(!present("bunny 2")) LOAD_BUNNY;
    if (arg) return;

    set_light(1);
    short_desc = "A path through the valley";
    no_castle_flag = 0;
    long_desc = 
"The dirt path you are walking on winds through a valley, filled\n"
+"with short grass and little animals of all kinds. You think you can\n"
+"hear the sound of running water in the distance. To your north, you\n"
+"can see a meadow on a hillside.\n";
    dest_dir = 
        ({
        "players/bern/newbie/path2", "north",
        "players/bern/newbie/path4", "south",
        });

}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

