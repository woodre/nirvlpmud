rain() {
   object victim, next;
   if (!previous_object()->query_yet()) return 1;
   victim = first_inventory(environment(this_player()));
   while (victim) {
      next = next_inventory(victim);
      if (victim->query_npc() && living(victim)) {
         victim->hit_player(35);
         victim->attacked_by(this_player());
         v}
      victim = next;
   }
   write("Your prayers summon holy rain down upon your enemies!\n");
   say("Holy rain comes crashing down in a fury!\n");
   previous_object()->setyet();
   return 1;
}

sp_cost() { return 60; }
query_piety() { return 14; }
