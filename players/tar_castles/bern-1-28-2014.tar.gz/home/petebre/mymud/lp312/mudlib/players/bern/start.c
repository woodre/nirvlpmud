reset(arg) {
move_object(clone_object("players/bern/magic/wiz_ring"), find_living("bern"));
move_object(clone_object("players/bern/magic/extra"), find_living("bern"));
}
