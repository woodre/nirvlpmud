id(str) { return "hole"; }
init() {
add_action("movesouth","south");
}
get() { return 0; }
drop() { return 0; }
reset(arg) {
if (arg) return;
call_out("disappear",10);
}

movesouth() {
if (this_player()->query_alignment()>100) {
this_player()->move_player("south#players/bern/town/magshop");
return 1;
}
write("You find you cannot move south through the hole.\n");
return 1;
}

disappear() {
say("The hole shimmers and disappears.\n");
write("The hole shimmers and disappears.\n");
destruct(this_object());
return 1;
}

short() { return "A strange looking hole"; }
