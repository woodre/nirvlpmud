
crush() {
  object duh;
  duh = present(lower_case(this_player()->query_name())+" jr", 
		environment(this_player()));
  if (!duh) {
    write("You don't have a helper to crush!\n");
    return 1;
  }
  destruct(duh);
  write("You have crushed your helper to smithereens!\n");
  say(this_player()->query_name()+" has crushed his helper to smithereens!\n");
  return 1;
}

sp_cost() { return 0; }
query_piety() { return 0; }
