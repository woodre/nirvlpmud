inherit "obj/weapon.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("sword");
set_alias("bastard sword");
set_short("Bastard Sword of Dragons");
set_alt_name("bastard sword of dragons");
set_long("There is an etching of a dragon on the sword\n"+
"along with some ancient runes.\n");
set_read("The runes seem to say: Kill da Dwagon!\n");
set_class(16);
set_value(5000);
set_weight(3);
set_hit_func(this_object());
}

weapon_hit(attacker) {
if (attacker->id("dragon")) {
write("The Bastard Sword screams in glee!\n");
say(this_player()->query_name() + "'s Bastard Sword screams in glee!\n");
return 19;
}
return 0;
}
