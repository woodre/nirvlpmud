inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("silver ring");
set_ac(1);
set_weight(1);
set_type("ring");
set_value(200);
set_alias("ring");
set_short("A silver ring");
set_long("You see nothing special.\n");
}
