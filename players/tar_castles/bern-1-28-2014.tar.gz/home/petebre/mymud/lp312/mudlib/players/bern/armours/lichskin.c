inherit"obj/armor";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("lich skin");
set_alias("skin");
set_short("Lich Skin");
set_long(
"Kind of a disgusting concept, but it looks wearable.\n");
set_weight(1);
set_value(400);
set_ac(3);
set_type("armour");
}
