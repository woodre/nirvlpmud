inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("silver shield");
set_ac(1);
set_weight(2);
set_type("shield");
set_value(150);
set_alias("shield");
set_short("A silver shield");
set_long("A cunningly wrought silver shield.\n");
}
