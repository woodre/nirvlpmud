emote(str) {
  write("You emote:  "+ this_player()->query_name()+" " + str + "\n");
  say(this_player()->query_name() + " " + str + "\n");
  return 1;
}

sp_cost() { return 0; }
query_piety() { return 0; }
