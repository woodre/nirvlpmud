reset() {
write(find_player("arthur")->query_guild_exp());
}
