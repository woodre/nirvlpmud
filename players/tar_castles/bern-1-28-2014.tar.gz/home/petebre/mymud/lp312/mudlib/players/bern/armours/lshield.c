inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("leather shield");
set_ac(1);
set_weight(1);
set_type("shield");
set_value(100);
set_alias("shield");
set_short("A leather shield");
set_long("A tough, durable shield made of leather.\n");
}
