inherit "obj/weapon.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("sword");
set_alias("glowing sword");
set_short("A glowing sword");
set_class(15);
set_value(1200);
set_weight(2);
set_light(1);
}
