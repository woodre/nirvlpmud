
id(str) { return str == "path"; }
short() { return "A magic path"; }
long() { write("It leads west through the air.\n"); }
init() {
add_action("west","west");
}

get() { return 0; }
drop() { return 0; }

reset(arg) {
if (arg) return;
call_out("destroy",10);
}

west() {
write("A gust of wind picks you up as you step on the path and "+
"transports you.\n");
this_player()->move_player("west#players/bern/portals/entrance");
return 1;
}

destroy() {
tell_room(environment(this_object()), "The path shimmers and disappears.\n");
destruct(this_object());
return 1;
}
