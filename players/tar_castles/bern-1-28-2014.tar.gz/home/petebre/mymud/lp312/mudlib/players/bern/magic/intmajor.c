#define name "potion"
#define short_desc "A Potion of Major Healing (intox)"
#define message "You drink a potion of major healing (intox)"
#define heal 50
#define value 750
#define strength 10

inherit "obj/drink.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_value(name + "#" + short_desc + "#" + message + "#" + heal + "#" +
value + "#" + strength);
}

query_value() { return 750; }
