#define LIMBO "players/bern/train/limbo"
#define NUM 5
int door_open;
string next_station;
string destination;
int i;

id(str) { return str == "train" || str == "mud express" || str == "express"; }

init() {
  add_action("enter","enter");
  add_action("go_out","exit");
add_action("go_out","out");
}

reset(arg) {
  if (arg) return;
  if (!destination) get_destinations();
  i = 0;
  call_out("start_train",1);
}

get_destinations() {
  destination = allocate(NUM);
  destination[0] = "room/station";
  destination[1] = "players/bern/main/hole1";
destination[2] = "players/deathmonger/station";
destination[3] = "players/azane/transit";
destination[4] = "/players/catt/mount/gobpub";
  return 1;
}

start_train() {
  door_open = 1;
  move_object(this_object(), destination[i]);
  tell_room(destination[i], "You hear a rumbling as a train enters the station.\n");
  tell_room(this_object(), "The train arrives at the next stop.\n"+
            "The doors slide open.\n");
tell_room(this_object(), "This stop is "+ destination[i]->short() + "\n");
  call_out("go_limbo", 15);
  return 1;
}

go_limbo() {
  door_open = 0;
  tell_room(destination[i], "The train leaves for the next stop.\n");
  tell_room(this_object(), "The doors close as the train leaves for the next stop.\n");
  i += 1;
  if (i > NUM - 1) i = 0;
  move_object(this_object(), LIMBO);
  call_out("start_train",15);
  return 1;
}

enter(str) {
  if (!id(str) || !door_open) return 0;
  this_player()->move_player("into the train#players/bern/train/train");
  return 1;
}

go_out() {
  if (!door_open) {
    write("The door is closed because the train is between stations.\n");
    return 1;
  }
  this_player()->move_player("out of the train#" + destination[i]);
  return 1;
}

short() {
  return "The Mud Express";
}

long() { write("Nirvana IV's very own train.\n"+
"You can enter or exit the train when the door is open.\n"+
               "The train door is ");
         if (door_open) { write("open.\n");
                          return 1;
                        }
         write("closed.\n");
         return 1;
       }
