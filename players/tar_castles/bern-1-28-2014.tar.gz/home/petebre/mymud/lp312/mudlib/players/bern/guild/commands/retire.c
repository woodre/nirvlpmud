retire() {
  this_player()->set_guild_file();
  this_player()->add_guild_exp(-this_player()->query_guild_exp());
  write("The Cleric guild feels sorry at your departure.\n");
  destruct(this_object());
  return 1;
}

sp_cost() { return 0; }
query_piety() { return 0; }
