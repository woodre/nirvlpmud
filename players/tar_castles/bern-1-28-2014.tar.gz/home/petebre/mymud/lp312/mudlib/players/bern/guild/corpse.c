string name;

id(str) { return str == "corpse" || str == "corpse of "+name; }
set_name(i) { name = i; }
short() {
  if (name) return "Corpse of "+capitalize(name);
  return "Corpse of No one";
}
reset(arg) {
  if (arg) return;
  name = 0;
  enable_commands();
}
long() {
  write("This is the dead body of "+capitalize(name)+".\n");
}
catch_tell(str) {
  if (name)
  tell_object(find_player(lower_case(name)),str+"\n");
}
realm() { return "NT"; }
