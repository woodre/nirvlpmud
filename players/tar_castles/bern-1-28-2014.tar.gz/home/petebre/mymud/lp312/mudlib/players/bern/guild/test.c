reset(arg) {
object robes;
robes = clone_object("players/bern/guild/r");
robes->set_owner(find_player("bern"));
move_object(robes, find_player("bern"));
}
