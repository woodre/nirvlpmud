
inherit"obj/monster";
reset(arg) {
object money;
object weapon;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(3);
a_chat_str = allocate(3);
chat_str[0] = "Jeremy the Idiot says: Welcome to Newbie Town!\n";
chat_str[1] = "Jeremy the Idiot says: Duh.\n";
chat_str[2] = "Jeremy the Idiot drools.\n";
a_chat_str[0] = "Jeremy the Idiot screams in pain!\n";
a_chat_str[1] = "Jeremy the Idiot says: Someone help me!\n";
a_chat_str[2] = "Jeremy the Idiot drools on you.\n";
  }
set_name("idiot");
set_alias("jeremy");
set_short("An utter idiot");
set_long(
"Doesn't he look silly?\n"
+ "His name is Jeremy.\n");
set_level(3);
set_hp(45);
set_race("human");
set_al(10);
set_wc(7);
set_ac(4);
set_spell_mess2("");
load_chat(10,chat_str);
load_a_chat(10,a_chat_str);
set_random_pick(50);
money = clone_object("obj/money");
money->set_money(10);
move_object(money, this_object());
weapon = clone_object("/players/bern/weapons/club");
if(weapon) {
move_object(weapon,this_object());
   }
}
