inherit "obj/monster.c";
reset(arg) {
object club;
::reset(arg);
if (arg) return;
set_name("reject");
set_level(15);
set_short("Reject the Barbarian");
set_long("He's huge. He's mean. He's here.\n");
set_hp(225);
set_wc(20);
set_ac(12);
set_spell_mess1("Reject the Barbarian swings his club in a vicious arc!\n");
set_spell_mess2("Reject the Barbarian slams you in the gut with his club!\n");
set_chance(20);
set_spell_dam(35);
set_heal(10,25);
club = clone_object("players/bern/weapons/rejclub");
move_object(club, this_object());
}
