

inherit "room/room";
init() {
::init();
add_action("bribe","bribe");
add_action("go_east","east");
}
object troll;

reset(arg) {
    if (arg) return;

    if (!present("troll")) 
       move_object(clone_object("players/bern/monsters/troll"), this_object());
    set_light(1);
    short_desc = "One side of the bridge with troll [n,e]";
    no_castle_flag = 0;
    long_desc = 
        "The path ends at a narrow bridge. There is a troll here guarding the bridge\n"
        + "as trolls seem to be fond of doing.\n";
    dest_dir = 
        ({
        "players/bern/main/path5", "north",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

go_east() {
if (!present("troll")) {
this_player()->move_player("east#players/bern/main/forest1");
return 1;
}
write("The troll blocks your way!\n");
return 1;
}

bribe() {
int level;
level = this_player()->query_level();
if (!present("troll")) return 0;
if (this_player()->query_money() < level * 15) {
write("The troll says: Sorry you cannot pass.\n");
return 1;
}
this_player()->add_money(-level * 15);
write("The troll leads you east to the bridge.\n");
this_player()->move_player("east#players/bern/main/forest1");
return 1;
}
