harm(str) {
  object victim;
  if (!str) victim = this_player()->query_attack();
  else
    victim = present(str, environment(this_player()));
  if (!living(victim) || (!victim->query_npc() && victim->query_pl_k())) {
    write("You cannot attack that!\n");
    say(this_player()->query_name() + " foolishly tries to attack "+ str+"\n"); 
   return 1;
  }
  this_player()->spell_object(victim, "harm spell", random(26), 0);
write(this_player()->query_name()+" casts a harm spell at " + victim->short()+"\n");
say(this_player()->query_name()+" casts a harm spell at " + victim->short()+"\n");
  return 1;
}

sp_cost() { return 14; }
query_piety() { return 12; }
