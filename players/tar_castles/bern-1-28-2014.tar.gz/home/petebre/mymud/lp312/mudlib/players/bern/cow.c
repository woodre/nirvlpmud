
inherit"obj/monster";
reset(arg) {
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(1);
a_chat_str = allocate(1);
chat_str[0] = "Cow says: Mooo...\n";
a_chat_str[0] = "Cow bellows: Moooo!\n";
  }
set_name("cow");
set_alias("betsy");
set_short("Cow");
set_long(
"A cow named Betsy\n");
set_level(5);
set_race("human");
set_spell_mess2("");
load_chat(10,chat_str);
load_a_chat(10,a_chat_str);
}
