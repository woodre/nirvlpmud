shield() {
  if (present("clericshield", this_player()) {
    write("You have already summoned a shield.\n");
    return 1;
  }
  write("You summon the shield preferred by more clerics around the world...\n");
  say(this_player()->query_name()+ " creates a shield out of thin air.\n");
  move_object(clone_object("/players/bern/guild/shield"), this_player());
  command("wear shield", this_player());
  return 1;
}

sp_cost() { return 25; }
query_piety() { return 9; }
