inherit "obj/monster.c";
reset(arg) {
object money;
  ::reset(arg);
if (arg) return;
set_name("ug");
set_short("Ug the Warrior");
set_level(16);
set_hp(400);
set_wc(22);
set_ac(13);
money = clone_object("obj/money");
money->set_money(500);
move_object(money, this_object());
move_object(clone_object("players/bern/armours/sring"), this_object());
  }
