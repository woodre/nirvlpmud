inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("army boots");
set_ac(1);
set_weight(2);
set_type("boots");
set_value(300);
set_alias("boots");
set_short("Army Boots");
set_long("Standard Issue Army Boots.\n");
}
