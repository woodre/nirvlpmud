reset(arg) {
  if (arg) return;
  set_light(1);
}

short() { return "Cleric's recruitment office [w]"; }
     
long() {
  write("This is the recruiter's office for the Cleric's Guild.\n"+
	"For more a list of spells for the guild, type 'info'\n"+
	"If you wish to join, simply type 'join' to become a member\n"+
        "of the greatest guild on the mud.\n");
  write("    There is only one obvious exit: west\n");
  if (this_player()->query_guild_file() == "players/bern/guild/robes")
    write("But with your special sight you see another opening to the south.\n");
}
init() {
add_action("info","info");
add_action("west","west");
add_action("south","south");
add_action("join","join");
}

west() {
  this_player()->move_player("west#players/bern/town/magshop");
  return 1;
}

south() {
  if (this_player()->query_guild_file() != "players/bern/guild/robes") return 0;
  this_player()->move_player("to the cleric's guild#players/bern/guild/adv_guild");
  return 1;
}


join() {
  if (this_player()->query_guild_file() == "players/bern/guild/robes") {
    write("You have already joined this guild :)\n");
    return 1;
  }
  if (this_player()->query_guild_exp() == 1234) {
	write("You are not allowed to join this guild.\n");
	return 1;
	}
  if (this_player()->query_guild_exp()) {
    write("You already belong to another guild.\n");
    write("But you are welcome to retire from that guild to join the Clerics.\n");
    return 1;
  }
  if(this_player()->query_level() < 3) {
     write("You must be level 3 to join a guild.\n");
     return 1;
  }
  this_player()->add_guild_exp(1);
  this_player()->set_guild_file("players/bern/guild/robes");
  this_player()->raise_piety(-this_player()->query_attrib("pie"));
   this_player()->raise_piety(8);
  move_object(clone_object("players/bern/guild/robes"), this_player());
  write("Congratulations on joining the Cleric's Guild!\n");
  write("You are given your robes as a symbol of your membership.\n");
  new_shout(this_player()->query_name()+" has just joined the Cleric's Guild.\n");
  return 1;
}


convert() {
int old;
if (this_player()->query_guild_file() == "players/bern/guild/robes") {
    write("You have already joined this guild :)\n");
    return 1;
  }
write("A wise decision!\n");
write("One moment...\n");
old = this_player()->query_guild_exp();
this_player()->add_guild_exp(-old);
join();
return 1;
}

new_shout(str) {  object list;
  object robe;
  int i;
  list = users();
  for(i=0; i<sizeof(list); i++) {
    robe = present("clericguild",list[i]);
    if (robe && !robe->query_block()) {
      tell_object(list[i],str);
    }
  }
return 1;
}
info(str) {
  if (!str) {
    cat("/players/bern/guild/info/general");
    return 1;
  }
  if (file_size("players/bern/guild/info/"+str)) {
    cat("/players/bern/guild/info/"+str);
    return 1;
  }
  write("There is no information on that.\n");
  return 1;
}
