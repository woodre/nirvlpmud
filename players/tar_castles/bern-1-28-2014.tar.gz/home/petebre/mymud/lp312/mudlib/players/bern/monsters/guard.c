inherit "obj/monster.c";
object weapon;
reset(arg) {
::reset(arg);
if (arg) return;
set_name("guard");
set_alias("fred");
set_short("A guard");
set_long("An imposing looking guard. His name is Fred.\n");
set_level(10);
set_hp(150);
set_wc(14);
set_ac(8);
weapon = clone_object("players/bern/weapons/halberd");
move_object(weapon, this_object());
}
