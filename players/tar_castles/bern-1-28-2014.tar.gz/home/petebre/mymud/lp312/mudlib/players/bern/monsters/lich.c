
inherit"obj/monster";
reset(arg) {
object money;
object armour;
::reset(arg);
if(arg) return;
set_name("lich");
set_short("A Lich");
set_long(
"I don't know what one exactly looks like.\n");
set_level(8);
set_race("lich");
set_hp(135);
set_wc(13);
set_ac(7);
set_aggressive(1);
set_spell_mess2("");
money = clone_object("obj/money");
money->set_money(100);
move_object(money, this_object());
armour = clone_object("/players/bern/armours/lichskin");
if(armour) {
move_object(armour,this_object());
command("wear "+armour->query_name());
  }
}
