id(str) { return str == "recycler" || str == "bottle recycler"; }
short() { return "An immovable bottle recycler"; }
long() { write("There is a slot in the side of the recycler\n"+
"that is marked 'insert bottle here'.\n"); }
get() { return 0; }
drop() { return 0; }
init() {
add_action("insert","insert");
}
insert(str) {
object ob;
if (str == "bottle") {
ob = present("bottle",this_player());
if (ob->query_value() == 0) {
write(ob->query_name() + " has no value.\n");
return 1;
}
this_player()->add_weight(-ob->query_weight());
this_player()->add_money(ob->query_value());
write("You get "+ ob->query_value() + " coins.\n"+
"Thank you for recycling.\n");
say(this_player()->query_name() + " recycled a bottle.\n");
destruct(ob);
return 1;
}
return 0;
}
