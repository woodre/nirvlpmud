int value;
short() { return "a temporary object that saves the value: "+value;}
query_auto_load() { return "/players/bern/temp.c:"+value; }
init_arg(a) {
  value = a;
}
reset(arg) {
if (arg) return;
value = 1;
}
init() {
add_action("change","change");
}

change(i) {
value = i;
}
get() { return 1; }
id(str) { return str == "object"; }
drop() { return 1; }
