id(str) { return str == "frisbee" || str == "disc"; }
short() { return "A frisbee"; }
long() { write("Fling at <person>"); }
query_value() { return 1; }
get() { return 1; }
drop() { return 0; }
init() {
add_action("fling","fling");
}
fling(str) {
string who;
object victim;
if (sscanf(str, "at %s", who) == 1) {
victim = find_living(who);
tell_object(victim, "A frisbee comes flying into your grasp!\n");
write("The frisbee sails away to " + who + "\n");
move_object(this_object(), victim);
return 1;
}
write("Fling at whom?\n");
return 1;
}
