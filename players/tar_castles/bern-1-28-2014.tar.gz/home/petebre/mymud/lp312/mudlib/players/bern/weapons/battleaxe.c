inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("battleaxe");
set_alias("axe");
set_short("A Battleaxe");
set_value(1000);
set_weight(2);
set_class(15);
}
