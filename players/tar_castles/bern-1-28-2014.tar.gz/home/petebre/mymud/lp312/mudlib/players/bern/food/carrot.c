inherit "obj/food";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("carrot");
set_short("A carrot");
set_strength(5);
set_value(300);
set_weight(1);
}
