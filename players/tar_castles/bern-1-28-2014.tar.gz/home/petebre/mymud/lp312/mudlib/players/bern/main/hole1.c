

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
short_desc = "A small hole in the ground";
    no_castle_flag = 0;
    long_desc = 
"You are forced to blink due to all the dust and dirt kicked up by your arrival.\n"
+"Looking around, you see a small hole, just barely large enough for\n"
+"someone to stand in. It looks relatively uninhabited, judging by how\n"
+"dry the soil is around you.\n";
    dest_dir = 
        ({
        "players/bern/main/hill", "up",
        });
}

query_light() {
    return 0;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

