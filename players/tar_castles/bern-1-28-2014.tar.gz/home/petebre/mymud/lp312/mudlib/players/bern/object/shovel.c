inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("shovel");
set_alias("long handled shovel");
set_short("A long handled shovel");
set_long(
"It looks like you can dig with it.\n"
+ "Though it has a long handle, you can see right off that\n"
+ "it would not make a good weapon.\n");
set_value(50);
set_weight(1);
}
