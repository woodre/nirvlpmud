death() {
   object corpse;
   if (previous_object()->query_death()) {
    write("You are already feigning death.\n");
    return 1;
  }
  if(this_player()->query_attack()) {
    write("You can't concentrate while being attacked.\nYou fail.\n");
    return 1;
  }
  corpse = clone_object("players/bern/guild/corpse");
  corpse->set_name(this_player()->query_name());
  move_object(corpse, environment(this_player()));
  move_object(this_player(), corpse);
  write("You die.\n");
  tell_room(environment(corpse), this_player()->query_name()+ " dies.\n");
  previous_object()->set_death();
  return 1;
}

sp_cost() { return 0; }
query_piety() { return 0; }
