inherit "obj/weapon.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("halberd");
set_short("A halberd");
set_long("A vicious looking weapon\n");
set_weight(2);
set_class(10);
set_value(500);
set_hit_func(this_object());
}

weapon_hit() {
if (random(100) > 80) {
write("The halberd comes alive in your hands!\n");
return 5;
}
return 0;
}
