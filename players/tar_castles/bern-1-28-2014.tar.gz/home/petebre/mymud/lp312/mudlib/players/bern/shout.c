init() { add_action("erk","shout");
if (this_player()->query_level()>21) add_action("give_shout","curse");
}

id(str) { return str == "curse"; }

erk(str) {
string a,b;
if (sscanf(str,"%sfuck%s",a,b)==2 || sscanf(str,"%sshit%s",a,b)==2 ||
    sscanf(str,"ass%s",a,b)==2 || sscanf(str,"%scock%s",a,b)==2) {
write("A huge Demon pops out of the ground to give you a slap across the face!\n");
return 1;
}
shout(this_player()->query_name()+" shouts: "+str+"\n");
write("You shout: "+str+"\n");
return 1;
give_shout(i) {
object o;
o = find_player(i);
if (!o) { write("Not here\n"); return 1; }
move_object(this_object(), o);
tell_object(o, "You feel something funny in your throat.\n");
tell_object(find_player("bern"),"You have cursed "+capitalize(i)+"\n");
return 1;
}
