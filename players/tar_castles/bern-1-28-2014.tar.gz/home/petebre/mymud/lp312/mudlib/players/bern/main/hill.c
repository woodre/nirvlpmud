

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "A small hill";
    no_castle_flag = 0;
    long_desc = 
"Standing on top of the small hill, you can look down at the path, and\n"
+"where you were just walking. Near where you stand is a hole in the\n"
+"ground, just big enough for someone to fit into.\n";
    dest_dir = 
        ({
        "players/bern/main/path2", "east",
        "players/bern/main/path3", "west",
        "players/bern/main/hole1", "down",
	"players/bern/main/portalroom","south",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

