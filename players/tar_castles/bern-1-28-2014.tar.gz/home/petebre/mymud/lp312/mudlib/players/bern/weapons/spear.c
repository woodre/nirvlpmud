inherit "obj/weapon.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("spear");
set_short("A long spear");
set_long("It looks like it's seen some use.\n");
set_class(9);
set_weight(1);
set_value(200);
}
