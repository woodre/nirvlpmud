#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
string potions;
object ob;

extra_reset() {
if (!potions) start_potions();
}

extra_init() {
add_action("read","read");
add_action("list","list");
add_action("lookat","l");
add_action("lookat","look");
add_action("decode","buy");
}

ONE_EXIT("players/bern/town/road3","east",
        "potion shop",
        "This small shop seems to sell solely potions.\n"+
        "There is a sign on the wall that lists what is sold here.\n", 1)

read(str) {
if (!str == "sign") return 0;
list();
return 1;
}

list() {
write("\n"+
"#####################################################\n\n"+
"Intoxicating Potions:\n\n"+
"1. Potion of Major Healing (intox)     :      1500 gp\n"+
"2. Potion of Minor Healing (intox)     :       500 gp\n"+
"\n"+
"Non-intoxicating Potions:\n\n"+
"3. Potion of Major Healing (non-intox) :      6000 gp\n"+
"4. Potion of Minor Healing (non-intox) :      1500 gp\n"+
"5. Potion of Variable Healing          :       200 gp\n"+
"   (you set it yourself -- non-intox)\n" +
"\n"+
"#####################################################\n");
write("\nPlease buy potions by numbers.\n");
return 1;
}


lookat(str) {
if (str == "at sign") {
write("It says something on it. Maybe you can read the sign.\n");
return 1;
}
return 0;
}

start_potions() {
potions = allocate(5);
potions[0] = "players/bern/magic/intmajor.c";
potions[1] = "players/bern/magic/intminor.c";
potions[2] = "players/bern/magic/major.c";
potions[3] = "players/bern/magic/minor.c";
potions[4] = "players/bern/magic/varpot.c";
}

decode(str) {
int chosen;
if (!sscanf(str,"%d",chosen) == 1) {
write("Please buy potions by number.\n");
return 1;
}
chosen += -1;
ob = clone_object(potions[chosen]);
if (!ob) {
write("Sorry, we do not sell that.\n");
return 1;
}
can_buy();
return 1;
}
  
can_buy() {
if ((2*ob->query_value()) > this_player()->query_money()) {
write("You don't have enough money.\n");
return 1;
}
if (!this_player()->add_weight(ob->query_weight())) {
write("You cannot carry that much.\n");
return 1;
}
write(ob->short()+ " has been prepared for you.\n");
say(this_player()->query_name() + " buys a "+ ob->short() + "\n");
move_object(ob, this_player());
this_player()->add_money(-2 * ob->query_value());
return 1;
}
