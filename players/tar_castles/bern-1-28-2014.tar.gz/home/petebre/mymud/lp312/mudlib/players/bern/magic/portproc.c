id(str) { return str == "processor" || str == "corpse processor"; }
short() { return "A corpse processor"; }
long() { write("There is a huge slot at one end of the processor\n"+
"that is marked 'insert corpse here'.\n"); }
query_weight() { return 2; }
get() { return 1; }
drop() { return 0; }
init() {
add_action("insert","insert");
}
insert(str) {
object ob;
if (str == "corpse") {
ob = present("corpse",this_player());
this_player()->add_weight(-ob->query_weight());
move_object(clone_object("players/bern/food/steak"), environment(this_player()));
write("The corpse processor churns for a bit, then spits out a steak.\n");
say(this_player()->query_name() + " processed a corpse.\n");
destruct(ob);
return 1;
}
return 0;
}

query_value() { return 1000; }
