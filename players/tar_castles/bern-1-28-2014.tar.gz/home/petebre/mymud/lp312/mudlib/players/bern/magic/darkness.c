id(str) { return str == "curse" || str == "curse of darkness"; }
get() { return 1; }
drop() { return 1; }
reset(arg) {
if (arg) return;
set_light(-1);
call_out("time",600);
}

time() {
write("The curse of darkness lifts...\n");
say("A curse of darkness lifts...\n");
destruct(this_object());
return 1;
}
