#define LOAD_UUBUNNY move_object(clone_object("/players/bern/monsters/uubunny"),this_object())

inherit "room/room";

reset(arg) {
  while(!present("bunny 2"))
    LOAD_UUBUNNY;
    if (arg) return;

    set_light(1);
short_desc = "Path through the ugly forest";
    no_castle_flag = 0;
    long_desc = 
"You are no longer able to make out the path, as the mud and dead foliage\n"
+"now cover what little dirt their might have been, and the dim lighting\n"
+"prevents you from finding footprints. A few hidious creatures hop around,\n"
+"and just off the trail is a small house, which appears to be occupied.\n";
    dest_dir = 
        ({
        "players/bern/newbie/ugly2", "east",
        });

  move_object(clone_object("/players/bern/newbie/house"),this_object());
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

