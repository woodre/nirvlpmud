#define path "/players/bern/realm"
inherit "players/bern/room";
reset(arg) {
if (arg) return;
set_light(1);
short_desc = "A path leading deeper into the forest [e,w]";
long_desc = "You are on a path that leads deeper into the forest to the west.\n"+
        "The trees close on both to the north and the south.\n"+
        "You hear the trickling of running water to the west.\n";
dest_dir = ({
        "room/deep_forest1","east",
        path+"path2","west",
        });
}
