short() { return "A blazing ball of light"; }
long() {
write("This light seems bright enough to dispell any darkness.\n");
}
id(str) { return str == "light" || str == "ball" || str == "ball of light"; }
reset(arg) {
if (arg) return;
set_heart_beat(1);
call_out("bye",600);
}

heart_beat() {
int temp;
temp = set_light(0);
if (temp <= 0)
set_light(1-temp);
}

bye() { destruct(this_object()); }
