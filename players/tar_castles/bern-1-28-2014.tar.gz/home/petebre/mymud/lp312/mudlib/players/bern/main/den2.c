

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "den of silver dragon";
    no_castle_flag = 0;
    long_desc = 
        "You find yourself in a Den of some sort.  The furnishings indicate that\n"
        + "this is obviously a dragon's abode, but the dragon does not seem to be\n"
        + "present. You hear some weird sounds coming from the south, and smoke\n"
        + "seems to fill the air. There is another room to the east\n";
    dest_dir = 
        ({
        "players/bern/main/silver", "east",
        "players/bern/main/stone14", "west",
        "players/bern/main/lich", "south",
        });

}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

