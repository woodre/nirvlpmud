

inherit "room/room";


reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "alley2";
    no_castle_flag = 0;
    long_desc = 
        "You reach the end of the alley.\n"
        + "There is an armoury to the west and a new opening to the south.\n";
items = 
({
});
    dest_dir = 
        ({
        "players/bern/town/alley1", "east",
        "players/bern/town/armoury", "west",
	"players/bern/town/magshop","south",
        });
}

