inherit "room/room";
object ob;
int i;
reset(arg) {
  if (arg) return;
  if (!present("dragon")) {
    for(i=0;i<1;i++) {
      ob = clone_object("players/bern/monsters/bluedragon");
      move_object(ob, this_object());
    }
  }
  set_light(1);
  short_desc = "blue dragon [s]";
  long_desc = "This is the bathroom of the creature whose den you were\n"+
    "in. You realize you are probablyl violating that creature's privacy.\n";
  dest_dir = ({
    "players/bern/main/den1","south",
  });
  items = ({
    "bathroom","It is a normal looking bathroom, complete with sink",
    "sink","Well, you know what one looks like",
  });
  i = 0;
}
