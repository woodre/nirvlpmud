reset() {
write(find_player("supa")->query_attrib("pie"));
}
