inherit "room/room";
reset(arg) {
  if (arg) return;
  set_light(1);
  short_desc = "stone walls [n]";
  long_desc = "You come to a solid wall.  There seems to be no way thru it.\n"+
	"This must be a dead end.\n";
  dest_dir = ({
    "players/bern/main/stone15","north",
  });
}
