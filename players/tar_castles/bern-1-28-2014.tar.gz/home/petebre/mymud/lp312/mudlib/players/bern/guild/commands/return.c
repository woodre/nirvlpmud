return() {
  object old_env;
  old_env = previous_object()->query_old_env();
  if (!old_env) {
    write("You have no sense of where you were planning on returning\n");
    return 1;
  }
  if (old_env->realm() == "NT" ||
      environment(this_player())->realm() == "NT") {
    write("You find you cannot complete the teleportation.\n");
    return 1;
  }
  write("You teleport back.\n");
  this_player()->move_player(X#filename(old_env));
  return 1;
}

sp_cost() { return 10; }
query_piety() { return 0; }
