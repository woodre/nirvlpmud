inherit "obj/living.c";
object master;


long() {
    write(short() + ".\n");
}

id(str) { return str == name; }

reset(arg) {
    if (arg)
        return;
    msgout = "leaves";
    msgin = "enters";
    name = "boggle";
    cap_name = "Boggle";
    is_npc = 1;
    level = 10;
    alignment = 0;
    weapon_class = 4;
    max_hp = 1000;
    hit_point = 1000;
    experience = 1;
    enable_commands();
    spell_points = 300;
}

catch_tell(str) {
tell_room("players/bern/camera","->"+str);
        set_heart_beat(1);
        return; }
hearbeat() { age += 1; }
