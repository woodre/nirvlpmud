

inherit "room/room";
object reject;

reset(arg) {
    if (arg) return;
if (!reject || !living(reject)) {
reject = clone_object("players/bern/monsters/reject");
move_object(reject, this_object());
}

    set_light(1);
    short_desc = "forest [n,w]";
    no_castle_flag = 0;
    long_desc = 
        "The trees of the forest here look somewhat gnawed upon. You wonder what\n"
        + "happened to them.\n";
    dest_dir = 
        ({
        "players/bern/main/forest3", "north",
        "players/bern/main/forest5", "west",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

