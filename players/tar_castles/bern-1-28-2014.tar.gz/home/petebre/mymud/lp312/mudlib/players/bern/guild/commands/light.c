light() {
  move_object(clone_object("players/bern/guild/light"), this_player());
  write("You clap your hands and a ball of light forms!\n");
  say(this_player()->query_name()+" summons light!\n");
  return 1;
}

sp_cost() { return 25; }
query_piety() { return 9; }
