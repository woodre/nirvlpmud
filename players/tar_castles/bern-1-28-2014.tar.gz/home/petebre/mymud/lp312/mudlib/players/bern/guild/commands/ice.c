ice(str) {
  object victim;
  if (!str) victim = this_player()->query_attack();
  else
    victim = present(str, environment(this_player()));
  if (!living(victim) || (!victim->query_npc() && victim->query_pl_k())) {
    write("You cannot attack that!\n");
    say(this_player()->query_name() + " foolishly tries to attack "+ str+"\n"); 
   return 1;
  }
  this_player()->spell_object(victim, "ice arrows", random(26)+15, 0);
write(this_player()->query_name()+" fires ice arrows at " + victim->short()+"\n");
say(this_player()->query_name()+" fires ice arrows at " + victim->short()+"\n");
  return 1;
}

sp_cost() { return 30; }
query_piety() { return 17; }
