inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("shortsword of sharpness");
set_alias("shortsword");
set_short("Shortsword of Sharpness");
set_value(3000);
set_weight(1);
set_class(18);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100) < 15) {
write("You deeply wound the "+attacker->query_name()+"\n");
say(this_player()->query_name()+" pierces the "+attacker->query_name()+" with the Shortsword of Sharpness\n");
return 7;
   }
return 0;
 }
