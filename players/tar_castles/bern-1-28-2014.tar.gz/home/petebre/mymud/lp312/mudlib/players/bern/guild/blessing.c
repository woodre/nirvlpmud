id(str) { return str == "blessing"; }
