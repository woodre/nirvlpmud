inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("mithril amulet");
set_ac(1);
set_weight(1);
set_type("amulet");
set_value(350);
set_alias("amulet");
set_short("A Mithril Amulet");
set_long("It has a shimmering aura that comforts you.\n");
}
