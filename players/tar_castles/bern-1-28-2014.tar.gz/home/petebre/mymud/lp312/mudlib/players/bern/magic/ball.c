id(str) { return str == "crystal ball" || str == "ball"; }
short() { return "Crystal Ball"; }
long() { write("A magical device that will let you 'peek' to see how\n"+
               "much damage you have done to a monster.\n"+
               "example: peek ogre\n");
}
get() { return 1; }
drop() { return 0; }
query_value() { return 1250; }

init() {
add_action("peek","peek");
}

peek(i) {
object ob;
int perc;
ob = present(i, environment(this_player()));
if (!ob) return 0;
if (!living(ob)) {
write("Error: cannot peek that.\n");
return 1;
}
perc = ob->query_hp() * 100 / ob->query_mhp();
write(capitalize(i) + " has " + perc + "% of its hitpoints left.\n");
return 1;
}
