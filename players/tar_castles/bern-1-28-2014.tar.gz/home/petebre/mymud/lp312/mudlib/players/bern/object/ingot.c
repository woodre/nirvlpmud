inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("silver ingot");
set_alias("ingot");
set_short("A silver ingot");
set_long(
"It's huge and valuable looking.\n");
set_value(750);
set_weight(1);
}
