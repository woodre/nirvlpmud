id(str) { return str == "glasses" || str == "glasses of true sight"; }
short() { return "Glasses of True Sight"; }
long() {
write("You can 'see' thru them at various monsters and things.\n");
}

reset(arg) { if (arg) return; }
init() {
add_action("see","see");
}

see(str) {
object ob;
if (!str) { write("See what?\n");
return 1;
}
ob = present(str, environment(this_player()));
if (!ob) ob = present(str, this_player());
write("\n"+
"Name           : " + ob->query_name() + "\n"+
"Level          : " + ob->query_level() + "\n"+
"Armour Class   : " + ob->query_ac() + "\n"+
"Weapon Class   : " + ob->query_wc() + "\n"+
"Hit Points     : " + ob->query_hp() + "\n"+
"Money          : " + ob->query_money() + "\n"+
"Alignment      : " + ob->query_alignment() + "\n"+
"AC             : " + ob->armour_class() + "\n"+
"WC             : " + ob->weapon_class() + "\n"+
"Weight         : " + ob->query_weight() + "\n"+
"Value          : " + ob->query_value() + "\n");
return 1;
}


get() { return 1; }
drop() { return 0; }
