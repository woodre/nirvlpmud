inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("club");
set_alias("spiked club");
set_short("A spiked club");
set_long(
"A large club with big pointy spikes sticking from it.\n");
set_value(100);
set_weight(1);
set_class(10);
}
