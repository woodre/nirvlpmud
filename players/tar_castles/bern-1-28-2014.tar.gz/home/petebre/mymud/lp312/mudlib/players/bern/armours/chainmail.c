inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("chainmail");
set_ac(4);
set_weight(2);
set_type("armor");
set_value(1100);
set_alias("shining chainmail");
set_short("Shining Chainmail");
set_long("The chainmail looks decent.\n");
}
