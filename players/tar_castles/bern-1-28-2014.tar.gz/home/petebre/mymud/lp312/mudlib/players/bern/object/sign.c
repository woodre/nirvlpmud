short() { return "A NEW sign is planted here in the ground"; }
id(str) { return str == "sign"; }
long() {
write("A wooden sign sits here which reads: \n");
write("\n");
write("The bridge to the south, which has been out for ages has finally\n"+
	"been repaired! Go see what's new!\n");
write("\n");
}
init() {
add_action("read","read");
}
read(str) {
if (!id(str)) return 0;
long();
return 1;
}
get() { return 0; }
