query_auto_load() { return "players/bern/magic/tag:"; }
string tagback;
id(str) { return str == "tag"; }
init() {
add_action("tag","tag");
}
drop() { return 1; }
get() { return 1; }
short() { return "TAG you're it"; }
long() { write("Now go tag someone else\n"); }
tag(str) {
object victim;
if (!str) {
write("Tag whom?\n");
return 1;
}
if (str == tagback) { write("No tag backs!\n");
return 1;
}
if (str == this_player()->query_real_name()) {
write("You can't tag yourself!\n");
return 1;
}
victim = present(str, environment(this_player()));
if (!victim) {
write("That player is not here.\n");
return 1;
}
write("You tag "+str+"\n");
say(this_player()->query_name() + " tags " + str + "\n");
tagback = this_player()->query_real_name();
move_object(this_object(), victim);
return 1;
}
