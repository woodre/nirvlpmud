
inherit"obj/monster";
reset(arg) {
object treasure;
::reset(arg);
if(arg) return;
set_name("bunny");
set_alias("cute bunny");
set_short("A cute bunny");
set_long(
"He's soft and furry and cute and named Terry\n");
set_level(3);
set_hp(45);
set_ac(7);
set_wc(4);
set_race("animal");
set_spell_mess2("");
treasure = clone_object("/players/bern/food/carrot");
if(treasure) move_object(treasure,this_object());
}
