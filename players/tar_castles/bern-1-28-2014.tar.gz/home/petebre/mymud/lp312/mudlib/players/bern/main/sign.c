

inherit "room/room";
object sign;

init() {
::init();
add_action("search","search");
}

reset(arg) {
    if (arg) return;
if (!present("sign")) move_object(clone_object("players/bern/object/sign"), this_object());

    set_light(1);
    short_desc = "sign";
    no_castle_flag = 0;
    long_desc = 
        "You arrive at an abrupt cliff. Below you can see clouds spiralling.\n"
        + "You have no idea how you got to be so high. It looks like there is a town\n"
        + "to the north. The path continues south.\n";
    dest_dir = 
        ({
        "players/bern/town/entrance", "north",
        "players/bern/main/path4", "east",
        "players/bern/main/path5", "south",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/


search() {
if (random(100) > 50) {
say("A path momentarily appears through the air.\n");
write("A path momentarily appears through the air.\n");
move_object(clone_object("players/bern/magic/path"), this_object());
return 1;
}
write("You see a glimmer of something, but then it's gone.\n");
return 1;
}

