inherit "obj/armor.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("platemail");
set_ac(4);
set_weight(4);
set_type("armor");
set_value(2000);
set_alias("suit");
set_short("A Suit of Platemail");
set_long("The platemail looks tough.\n");
}
