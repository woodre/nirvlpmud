inherit "obj/weapon.c";
reset(arg) {
::reset(arg);
if (arg) return;
set_name("slayer");
set_short("The slayer");
set_class(20);
set_hit_func(this_object());
}

weapon_hit() {
return 90;
}

drop() { return 1; }
