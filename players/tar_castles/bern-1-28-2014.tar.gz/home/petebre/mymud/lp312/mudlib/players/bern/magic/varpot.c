int healing;
id(str) { return str == "potion"; }

reset(arg) {
if (arg) return;
healing = 0;
}

short() { return "A Potion of Variable Healing"; }

long() { write("It is filled with a green swirling liquid.\n"+
"It's label says: please remember to set the potion to\n"+
"the amount of healing you desire using 'set potion [amount]'.\n"+
" The more you heal, the greater the cost, so be warned.\n");
return 1;
}

get() { return 1; }
drop() { return 0; }
query_value() { return 100; }

init() {
add_action("drink","drink");
add_action("much","set");
}

much(str) {
int i;
if (sscanf(str,"potion %d",i) == 1 || sscanf(str,"%d",i) == 1) {
if (i < 0) {
write("Invalid level of healing.\n");
return 1;
}
healing = i;
write("Healing set for " + i + "\n");
write("This would cost you "+ healing*50+ " coins.\n");
return 1;
}
write("Set healing potion for how much healing?\n");
return 1;
}

drink() {
if (!healing) {
write("Potion not set to any particular value.\n");
return 1;
}
if (this_player()->query_money() < 50 * healing) {
write("You do not have enough money for that much healing\n");
return 1;
}
say(this_player()->query_name() + 
" drinks a Potion of Variable Healing.\n");
write("A small hand reaches out of the bottle as you take a drink.\n"+
"It reaches into your purse and grabs " + 50 *  healing + " coins.\n"+
"You feel much better.\n");
this_player()->add_money(-50 * healing);
this_player()->heal_self(healing);
destruct(this_object());
return 1;
}
