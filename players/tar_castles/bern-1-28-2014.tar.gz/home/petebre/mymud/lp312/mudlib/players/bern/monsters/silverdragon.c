
inherit"obj/monster";
reset(arg) {
object money;
object treasure;
::reset(arg);
if(arg) return;
set_name("silver dragon");
set_alias("dragon");
set_short("Silver Dragon");
set_long(
"It looks upset that you disturbed it.\n");
set_level(20);
set_race("dragon");
set_al(500);
set_wc(30);
set_ac(17);
set_aggressive(1);
set_chance(10);
set_spell_dam(25);
set_spell_mess1("Silver bolts come crashing down");
set_spell_mess2("You are pummelled by silver bolts called down from the sky");
set_random_pick(30);
money = clone_object("obj/money");
money->set_money(800);
move_object(money, this_object());
treasure = clone_object("/players/bern/magic/mbag");
if(treasure) move_object(treasure,this_object());
}
