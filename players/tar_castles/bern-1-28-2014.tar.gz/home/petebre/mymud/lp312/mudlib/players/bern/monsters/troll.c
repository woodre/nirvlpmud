inherit "obj/monster.talk.c";
reset(arg) {
object money;
set_name("troll");
set_short("A Troll");
set_level(15);
set_hp(225);
set_wc(20);
set_ac(12);
set_alias("herman");
set_long("A vicious looking troll. His name is Herman.\n"+
	"He guards the bridge against those who would pass.\n"+
	"Perhaps you could 'bribe' your way past.\n");
money = clone_object("obj/money.c");
money->set_money(750);
move_object(money, this_object());
::reset(0);
}
