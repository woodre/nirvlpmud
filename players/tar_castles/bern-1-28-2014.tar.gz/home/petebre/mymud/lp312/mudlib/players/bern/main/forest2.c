

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "Other side of the bridge [w,s]";
    no_castle_flag = 0;
    long_desc = 
        "This is the Other End of the Bridge. The path that led to the bridge seems\n"
        + "to end as the forest closes around. In fact, it looks like the only way you\n"
        + "can move is west, back onto the bridge, or south which takes you into the\n"
        + "forest.\n";
    dest_dir = 
        ({
        "players/bern/main/forest1", "west",
        "players/bern/main/forest3", "south",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

