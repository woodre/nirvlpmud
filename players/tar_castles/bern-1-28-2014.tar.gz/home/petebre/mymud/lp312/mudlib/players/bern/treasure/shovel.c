inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("shovel");
set_alias("long handled shovel");
set_short("A long handled shovel");
set_long(
"It looks like a fairly useful shovel.\n");
set_value(187);
set_weight(1);
}
