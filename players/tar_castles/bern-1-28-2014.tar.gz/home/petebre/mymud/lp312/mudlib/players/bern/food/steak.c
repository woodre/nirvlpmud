id(str) { return str == "steak"; }
init() {
add_action("eat","eat");
}
short() { return "A juicy steak"; }
long() { 
write("The steak looks a little on the rare side and a little processed,\n"+
"but it does look delicious.\n");
}
eat(str) {
if (!id(str)) return 0;
write("You gobble down the steak.\n");
say(this_player()->query_name()+" scarfs down a steak.\n");
this_player()->heal_self(10);
destruct(this_object());
return 1;
}
get() { return 1; }
drop() { return 0; }
