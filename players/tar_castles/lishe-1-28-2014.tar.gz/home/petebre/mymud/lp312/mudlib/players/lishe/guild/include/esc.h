/**
 * esc.c
 *
 */

#define esc ""
#define ESC esc
