short() { return "A small room"; }
long() 
{
  write("This is a very small room. It is bare and has a tatami mat covering\n"+
    "the floor. Wow, it's quiet here.\n"+
    "  There are no obvious exits.\n");
}
