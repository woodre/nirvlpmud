/**
 * entrance.c
 *
 */

inherit "/room/room.c";
#include "include/copyright.h"

void reset(int arg) 
{
   if(arg) return;
   set_light(1);
   
   short_desc = "03h Nexus - Cybernetica";
   long_desc =
   "    Stretched as far as the eye can see are trunks of glittering network\n"+
   "  cables, and a sea of machines and biotechnica carrying along with their jobs.\n"+
   "  It seems to be perpetually night here in Cybernetica, the air is cool and crisp,\n"+
   "  and the breeze carries with it a subtle tick of ozone. No doubt that acrid smell\n"+
   "  exists because of the sheer amount of life all around you.\n";   
  
   items = ({

    "cables",
    "Protected in their see-through cladding of pseudochitin, a faint hum can be felt\n"+
    "the cables as you kneel to the ground and place your hands upon them.\n",

  });
  
  dest_dir = 
  ({
    "/room/void", "out",
  });

  set_no_clean(1);

}

init()
{
   ::init();
}

