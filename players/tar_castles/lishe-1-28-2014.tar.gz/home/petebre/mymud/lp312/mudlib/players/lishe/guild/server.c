/**
 * server.c
 *
 * This is the guild object of the new CN guild.
 * Contents personal copyright Lishe@Nirvana, 2005.
 * Exclusive rights also to Boltar@Nirvana.
 * Reproduction on other muds restricted, under penalty of personal retribution.
 *
 */

#include "include/config.h"
#include "include/definitions.h"
#include "include/ansi.h"

id(str)
{
    return str == "gob";
}


reset(arg)
{

}

extra_reset()
{
}


init()
{

}


short()
{
    "A network server named [cyberdaemon]";
}

long()
{

}

/* eof */
