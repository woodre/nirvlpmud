/**
 * definitions.h
 *
 *
 */