/**
 * copyright.h
 *
 *
 */