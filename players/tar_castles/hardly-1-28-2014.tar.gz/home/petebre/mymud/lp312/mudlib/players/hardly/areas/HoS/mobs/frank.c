/*
 * mob_template.c
 *
 * A template for a mob/npc/monster etc..
 */

inherit "/obj/monster";

void reset(int arg) {
  ::reset(arg);
  if (arg)
    return;
  set_name("Frank");
  set_alias("alias");
  set_alt_name("another alias");
  set_short("Frank the Troll");
  set_long(
"Frank is a Troll.a short fat dumpy one. He hasa bald head with big pointy ears.\n"+
"A full green beard covers his face, some ot this morning breakfast still clings to his beard.\n");
  set_al(0);  /* Alignment */
  set_gender("male");  /* duh, gender if you want it */
  set_race("troll");  /* if you want to set a race */
  set_level(16);      /* The level, this will also set the default wc/ac/exp */
  set_wc(1);  /* If you want to overide the wc/ac/hps/sps you can also */
  set_ac(1);
  set_hp(1);
}
