"Blessed river water" -40 hp/sp heal hitox
"Angry Ox ale" -40 hp/sp heal intox hitox
"Bark root"-50 hp/sp lotox heal
"Pard liver"-detox  (make you gag)
