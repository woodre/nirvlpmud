/*
 * room_template.c
 *
 * A template for creating rooms
 */

inherit "/room/room";

void reset(int arg) {
  ::reset(arg);
  if (arg)
    return;
  set_light(1);  /* set the light level, 1= dark */
  short_desc = "Trailway";
  long_desc =
"Tall wavy grass grows abundantly on rolling hills.A trail winds pass a wooden water trough and hand pump.\n"+
"A low rumbling can be heard far off into the woods.The trail continies on to the west./n"
"Some trees can be seen off in the distance.\n");
  items = ({
    "item1", "This is the description for item1",
    "item2", "This is the description for item2"
  });
  dest_dir = ({
    /* This is where we do the exits, the syntax for creating them
       is  "/pathname/to/the/room", "exit_direction",  */
    "/room/north", "north",
    "/room/portal", "portal",
  });
}
