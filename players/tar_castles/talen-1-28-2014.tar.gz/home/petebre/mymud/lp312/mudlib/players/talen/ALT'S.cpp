Talen's alts:


Budah
Artos
Derian
Levus
Bacchus
Hadus
Tirnok