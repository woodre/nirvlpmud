short() {
      return "Emerson's dungeon";
}
long () {
     write ("You are in a dark dungeon.\n");
   write("There are no exits. \n");
}
reset (arg) {
    if (arg)
    return;
  set_light(1);
}
init(){
  add_action ("quit"); add_xverb("");
}
quit(){
    if (call_other(this_player(); query_level, 0)<21)
{
    long() ;
   write (You can't do that here.\n");
   return 1;
}
return 0 ;
}
