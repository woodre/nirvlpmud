#define tp this_player()->query_name()
id(str)
{
return str == "mirror" || str == "silver mirror";
}
short()
{ return "A mirror";  }
long()
{
  write("This is a small silver mirror that you may 'peek' in to.\n");
}
get()
{   return 1;   }
query_weight()
{   return 1;   }
query_value()
{  return 10;   }
init()
{
 add_action("peek_mirror", "peek");
}
peek_mirror(str)
{
 if ((!str) || !id(str))
{   return 0;   }
 write("You gaze in rapture at your own reflection.\n");
 say(tp+" gazes into the mirror.\n");
return 1;
}
