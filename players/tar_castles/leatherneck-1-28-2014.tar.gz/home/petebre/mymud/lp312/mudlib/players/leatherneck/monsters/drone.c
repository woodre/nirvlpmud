inherit "obj/monster";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Drone");
   set_race("monster");
   set_alias("drone");
   set_short("An Alien Worker Drone");
   set_long("This creature is like nothing youve ever seen.\n" +
            "It's gleaming, smooth, black carpace and blinding\n" +
            "speed give you a foreboding sense of a painful death.\n");
   set_level(16);
   set_hp(200);
   set_al(-250);
   set_wc(19);
   set_ac(7);
   set_chance(20);
   set_spell_dam(50);
   set_spell_mess1("Drone slashes you with its lightning fast tail");
   set_spell_mess2("Drone slashes and smashes you with its claws.");
	set_a_chat_chance(20);
   set_chat_chance(5);
   load_chat("A Drone hisses at you as it approaches you.");
   load_chat("Hsssssssss........What the ....was that?");
}
