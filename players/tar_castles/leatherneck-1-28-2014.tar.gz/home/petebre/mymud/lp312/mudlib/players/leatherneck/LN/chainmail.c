inherit "obj/armor";
reset(arg){
   ::reset(arg);
   set_name("chainmail");
   set_short("Chainmail");
   set_alias("mail");
   set_long("A suit of fine steel chain mail.\n");
   set_ac(4);
   set_weight(4);
   set_value(700);
}
