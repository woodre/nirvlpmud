inherit "obj/monster";
   object gold;

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("stormtrooper");
   set_race("human");
   set_alias("trooper");
   set_short("An Imperial Stormtrooper");
   set_long("This is one of the Empire's elite ground troops.\n" +
           "From the looks of his gleaming white and black armor\n" +
           "and his medium blaster, you see that he means business\n");
   set_level(19);
   set_hp(1);
   set_al(-250);
   set_wc(21);
   set_ac(9);
   set_chance(20);
   set_spell_dam(50);
   set_spell_mess1("Stormtrooper blasts you with a crimson energy bolt");
   set_spell_mess2("Stormtrooper crushes you with an armored fist.");
	set_a_chat_chance(20);
   set_chat_chance(5);
   load_chat("Stormtrooper says: Stop youre under Imperial Arrest\n");
   load_chat("Give up you scum, you cant stand against the Empire\n");
   gold=clone_object("obj/money");
   gold->set_money(random(1200)+75);
   move_object(gold,this_object());
}
