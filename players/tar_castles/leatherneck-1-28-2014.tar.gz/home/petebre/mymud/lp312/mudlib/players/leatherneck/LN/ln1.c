inherit "obj/armor";
reset(arg) {
::reset(arg);
	set_short("Beast hide");
	set_long(  "This is a big thick furry hide.  It seems fairly protective, try it on.\n");
	set_ac(4);
	set_value(4000);
	set_name("hide");
	set_weight(2);
	set_alias("hide");
	set_type("armor");
	}
