inherit"obj/monster";

reset(arg) {
	object gold;
  ::reset(arg);
  if(!arg) {

   set_name("punk");
   set_short("An intoxicated punk");
   set_long("This punk is very drunk and he kind of reminds you of Zeck.\n");
   set_level(4);
   set_hp(60);
   set_wc(8);
   set_ac(4);
	set_chat_chance(5);
load_chat("Punk yells: You're the punk, PUNK!!!\n");
	gold=clone_object("obj/money");
        gold->set_money(random(150));
	move_object(gold,this_object());
   }
}
