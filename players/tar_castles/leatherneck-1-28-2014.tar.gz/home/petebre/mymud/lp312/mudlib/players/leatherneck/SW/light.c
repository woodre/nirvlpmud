inherit "obj/weapon";
int die, attacker, pain;
int x;
reset(arg) {
::reset(arg);
        if(!arg) {
		x = 0;
        set_name("lightsaber");
		set_class(19);
          set_value(35000);
        set_weight(9);
          set_alias("saber");
          set_short("Ancient Lightsaber");
set_long(
"This is the Jedi's greatest hand to hand weapon\n"+
"in fighting the foes of the great Republic.\n"+
"If you feel that your Jedi Powers are sufficient, you may try\n"+
"typing 'field' for some xtra armor....for a while.\n"+
             "MAY THE FORCE BE WITH YOU\n");
set_hit_func(this_object());

}
}
weapon_hit(attacker)
{
   if(random(100) < 85) {
say("This lightsaber blazes with a blue aura that is so fast\n"+
"that all you saw was a blur of slashes.\n");
write("The lightsaber blazes with a blue aura like steel\n"+
"in your hands as if it has a life of its own. You feel\n"+
"humble to be in possession of such awesome power and responsibility.\n");
return 3;
}
}
init() {
	::init();
   add_action("field","field");
}
field() {
	if(x == 100) {
   write("Unfortunately, your force controlling powers\n"+
"arent sufficient to create another field right now.\n");
	return 1;
	}
   write("You begin to concentrate to create a protective blue field\n"+
"around yourself. Master Leatherneck would be proud.\n");
    say(capitalize(this_player()->query_real_name())+" begins to assume\n"+
"a calming trance for a moment. You suddenly see a blue field around\n"+
"the wielder.\n");
	this_player()->set_ac(this_player()->query_ac() + 2);
	x = 100;
   this_player()->set_money(this_player()->query_money() -30000);
	return 1;
}
query_save_flag() { return 1; }
