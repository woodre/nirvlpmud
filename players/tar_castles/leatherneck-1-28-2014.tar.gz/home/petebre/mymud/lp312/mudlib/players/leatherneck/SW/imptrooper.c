inherit "obj/monster";
   object gold;

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("imperial trooper")+
   set_race("human");
   set_alias("trooper");
   set_short("An Imperial Trooper");
set_long("This trooper is the mainstay of the Empire's ground\n" +
         "forces. He serves many roles, but he is a warrior\n" +
         "first and foremost\n");
   set_level(6);
   set_hp(90);
   set_al(-150);
   set_wc(12);
   set_ac(6);
   set_chance(20);
   set_spell_dam(10);
   set_spell_mess1("Youre slammed with a blast from a blaster.");
   set_spell_mess2("Trooper jars you with a blast to the chest");
                  ("to the abdomen\n");
	set_a_chat_chance(20);
   set_chat_chance(5);
   load_chat("Imperial Trooper says: Stop, youre under Imperial Arrest");
   laod_chat(" 'Give up you scum, you cant stand against the Empire' ");
    gold = clone_object("obj/money");
   gold->set_money(random(450)+45);
   move_object(gold,this_object());
}
