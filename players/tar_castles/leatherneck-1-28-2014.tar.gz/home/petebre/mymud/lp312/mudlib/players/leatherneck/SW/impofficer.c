inherit "obj/monster";
   object gold;

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("imperial officer");
   set_race("human");
   set_alias("officer");
   set_short("An Imperial Officer");
   set_long("This officer is one of the many junior officers who\n" +
            "is longing to have a command of his own. It would do\n" +
            "his record some good if he could capture some rebel\n" +
            "scum. Or some space trash, either way, youre toast\n");
   set_level(15);
   set_hp(260);
   set_al(-250);
   set_wc(13);
   set_ac(9);
   set_chance(20);
   set_spell_dam(15);
   set_spell_mess1("Officer fries you with his medium blaster\n");
   set_spell_mess2("Officer smashes youre chest with a blaster bolt\n");
	set_a_chat_chance(20);
   set_chat_chance(5);
   load_chat("Officer says: your choice, come quietly or die like scum\n");
   gold=clone_object("obj/money");
   gold->set_money(random(1200)+100);
   move_object(gold,this_object());
}
