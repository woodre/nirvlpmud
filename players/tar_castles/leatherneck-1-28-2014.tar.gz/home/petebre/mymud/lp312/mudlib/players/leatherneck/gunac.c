inherit "obj/weapon";
int die, attacker, pain;
int x;
reset(arg) {
::reset(arg);
        if(!arg) {
		x = 0;
		set_name("gun");
		set_class(19);
		set_value(7000);
		set_weight(3);
		set_alias("gun");
	set_short("A Six Shooter");
set_long(
"Rolands pistol feels good as you hold it in your hands.  As you \n" +
"spin the bullets in their chamber you have a compelling feeling\n" +
"to squeez off all six into someone's body.\n");
set_hit_func(this_object());
}
}
weapon_hit(attacker)
{
	if(random(100) < 75) {
say(capitalize(this_player()->query_real_name()) + "unloads all six rounds!\n");
write("***BLAM***\n" +
"     ***BLAM***\n" +
"          ***BLAM***\n" +
"               ***BLAM***\n" +
"                    ***BLAM***\n" +
"                         ***BLAM***\n");
return 3;
}
}
init() {
	::init();
	add_action("chant","chant");
}
chant() {
	if(x == 100) {
	write("The gun has used up all of it's power.\n");
	return 1;
	}
	write("You begin the chant and the gun puts a force field over you.\n");
	say(capitalize(this_player()->query_real_name())+" begins to chant wildly.\n");
	this_player()->set_ac(this_player()->query_ac() + 2);
	x = 100;
	return 1;
}
query_save_flag() { return 1; }
