 inherit "obj/weapon.c";
 reset(arg) {
    ::reset();
    if (arg) return;
    set_name("sword");
    set_short("Sword");
    set_long("A sword made from fine steel.\n");
    set_class(12);
    set_weight(3);
    set_value(200);
}
