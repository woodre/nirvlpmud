#define tp this_player()->query_name()
inherit "room/room";
int search_count;
int mcount;
int clone_count;
int t;
object ob;
reset(int arg){
search_count = 1;
if(!present("barfight")) {
 move_object(clone_object("/players/saber/closed/effects/barfight.c"),this_object());
 }
if(!present("sign")) {
move_object(clone_object("/players/saber/closed/food/fightpub.c"),this_object());
}
if(!present("mercenary")) {
move_object(clone_object("/players/saber/closed/monsters/merc.c"),this_object());  }
if(!present("orc")) {
move_object(clone_object("/players/saber/closed/monsters/orc.c"),this_object());  }
if(!present("amazon")) {
move_object(clone_object("/players/saber/closed/monsters/amazon.c"),this_object());  }
if(!present("thief")) {
move_object(clone_object("/players/saber/closed/monsters/thief.c"),this_object());  }
if(!present("barbarian")) {
move_object(clone_object("/players/saber/closed/monsters/barbarian.c"),this_object());  }
 if(!arg){
  set_light(1);
  short_desc="Eternal Bar Fight";
long_desc=
 "You are in the common room of a pub which\n"+
 "has seen much better days. Chairs, tables\n"+
 "and bodies are scattered haphazardly about\n"+
 "the chamber, and the overpowering smell of\n"+
 "alcohol pervades the air.  There is a sign\n"+
 "upon the wall.\n";

items=({
 "portal","A dark stone portal filled with a hazy blue aura",
 "floor","The floor is covered with broken furniture and broken people",
 "chair","A broken chair lying in multiple pieces on the floor",
 "table","A smashed table leaning agaist the wall",
 "pub","The common room of a nameless Inn",
 "chamber","The common room of a nameless Inn",
 "bodies","Many bodies strewn in random places about the room",
 "barmaid","A comely young barmaid serving out drinks to the patrons",
 });

  dest_dir=({
 "/players/saber/closed/tower/tower6.c","portal",
 "/players/saber/closed/tower/tower13+1.c","east",
  "/players/saber/closed/tower/tower13+2","down",
           });
   set_heart_beat(20);
  }   }
init(){
 ::init();
  add_action("search","search");
add_action("east","east");
}

east() {
if (call_other(this_player(), "query_level", 0) < 20) {
 write("There is too much broken furniture in the way.\n");
 say(tp+" tries to move east, but is blocked by the broken furniture.\n");
 return 1;   }
write("You manage to wiggle through the broken furniture...\n");
say(tp+" leaves east.\n");
call_other(this_player(), "move_player", "east#players/saber/closed/tower/tower13+1.c");
 return 1;    }

search() {
if (search_count == 2)
{
search_count = search_count + 1;
 write("You find a small gem on one of the unconscious bodies.\n");
 say(tp+" searches the area.\n");
ob = clone_object("/players/saber/closed/gems/amber.c");
transfer(ob,this_player());
return 1;
}
else
{
search_count = search_count + 1;
write("You don't find anything worth keeping.\n");
say (tp +" searches the area\n");
 return 1;  }
}

heart_beat() {
clone_count = clone_count + 1;
if (clone_count > 20) {
if(!present("mercenary")) {
  object merc;
    merc = clone_object("/players/saber/closed/monsters/merc.c");
      move_object(merc,"/players/saber/closed/tower/tower13+1.c");
}
if(!present("orc")) {
  object orc;
    orc = clone_object("/players/saber/closed/monsters/orc.c");
      move_object(merc,"/players/saber/closed/tower/tower13+1.c");
}
if(!present("amazon")){
  object amazon;
    amazon = clone_object("/players/saber/closed/monsters/amazon.c");
      move_object(amazon,"/players/saber/closed/tower/tower13+1.c");
}
if(!present("thief")) {
  object thief;
    thief = clone_object("/players/saber/closed/monsters/thief.c");
      move_object(thief,"/players/saber/closed/tower/tower13+1.c");
}
if(!present("barbarian")) {
  object barbarian;
    barbarian = clone_object("/players/saber/closed/monsters/barbarian.c");
      move_object(barbarian,"/players/saber/closed/tower/tower13+1.c");
}
mcount = mcount + 1;
clone_count = mcount;
}
}
