inherit "obj/treasure";

reset(arg) {
 if(arg) return;
    set_short("A Platinum Rose");
     set_alias("rose");
     set_long("This beautifully carved rose glistens in the moonlight\n" +
             "and has intricatly enlaid carvings on the petals.\n" +
             "The inscription reads: A Rose for a Flower.\n");
   set_weight(1);
    set_value(750);
}
 id(str) { return str == "rose" || str == "Platinum rose"; }

