inherit "obj/monster";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Queen");
   set_race("monster");
   set_alias("queen");
   set_short("THE Alien Queen");
   set_long("This huge thing dwarfs the drones that are\n" +
            "around this place. She seems to be surrounded by something\n" +
            "like gigantic eggs. Better wipe the sweat off of your brow,\n" +
            "this one is gonna be TOUGH.\n");
   set_level(19);
   set_hp(600);
   set_al(-250);
   set_wc(22);
   set_ac(9);
   set_chance(20);
   set_spell_dam(90);
   set_spell_mess1("The Queen spears you with her blade tail.\n");
   set_spell_mess2("The Queen smashes her claws through your pitiful body.\n");
	set_a_chat_chance(20);
   set_chat_chance(5);
   load_chat("The Queen moans and hisses as she approaches.\n");
   load_chat("Hssssssssssssssss.......What the .... was that?\n");
}
