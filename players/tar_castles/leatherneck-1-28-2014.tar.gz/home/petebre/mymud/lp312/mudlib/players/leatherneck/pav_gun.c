inherit "obj/weapon";
 int i, dmg;
   init() {
  ::init();
  add_action("set_damage", "dmg");
}
reset(arg) {
::reset(arg);
if(arg) return;
       set_alias("gun");
   set_name("a 9mm Beretta");
    set_short("A 9mm Beretta");
   set_long("This is Pavlik's 9mm Beretta and it is one very dangerous\n"+
    "weapon.  The cold steel and blued barrel feel very comfortable.\n");
       set_class(18);
       set_weight(0);
       set_value(4);
set_hit_func(this_object());
}

weapon_hit(attacker) {
  i=random(100);
   if (i>0) {
say("BLAM!!!!\n");
say("BLAM!!!!\n");
say("BLAM!!!!\n");
say(this_player()->query_name()+" pulls the trigger repeatedly and vaporizes the target!!!\n");
write("You point the Beretta at your target and start squeezing off rounds!\n");
write("BLAM!!!\n");
write("BLAM!!!\n");
write("BLAM!!!\n");
write("You grin vicously as you blow holes into your oppenent!\n");
write("The Berreta reports echo across the mud!\n");
 if(this_player()->query_level() > 21) {
return dmg;
     }
  }
return 0;
}
set_damage(str)  {
sscanf(str, "%d", dmg);
write("Damage set to: "+dmg+" HP per hit.\n");
   return 1;
  }
