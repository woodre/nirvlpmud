inherit "obj/weapon";
int die, attacker, pain;
reset(arg) {
::reset(arg);
        if(!arg) {
                set_name("medium  blaster");
                set_class(19);
                set_value(4500);
                set_weight(3);
                set_alias("blaster");
                set_short("Medium Blaster");
set_long("this medium blaster was constructed by the Empire and\n"+
           "used by most Imperial ground forces, including stormtroopers\n");
}
}
