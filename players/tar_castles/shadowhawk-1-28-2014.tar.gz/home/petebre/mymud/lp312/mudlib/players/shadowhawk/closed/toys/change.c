#pragma strict_types
#pragma save_types

object parse_list(object prev, string str);
object find_item(object prev, string str);

string var1, var2, var3;
object store1, store2, store3;

string
query_auto_load() {
  return 0; /* login file works better. */
  return "players/shadowhawk/closed/toys/change:";
}

void
init() {
  if ((string)this_player()->query_real_name() == "shadowhawk") {
    add_action("i_dump", "Dump");
    add_action("i_destruct", "Dest");
    add_action("i_call", "Call");
    add_action("i_tell", "Tell");
    add_action("i_trans", "Trans");
    add_action("i_set", "Set");
    add_action("where_at", "where");
    add_action("long1", "Help");
  }
}

string
query_long() {
  write("How can you look at a change?\n");
}

int
long() {
  write(query_long());
  return 1;
}

static int
i_dump(string str) {
  int tmp;
  string temp;
  object ob;
  string flag, path;

  if (str == 0) {
    write("All variables:\n");
    if (var1) {
      write(var1 + ":\t"); write(store1); write("\n");
    }
    if (var2) {
      write(var2 + ":\t"); write(store2); write("\n");
    }
    if (var3) {
      write(var3 + ":\t"); write(store3); write("\n");
    }
    return 1;
  }
  if (sscanf(str, "%s %s", path, flag) != 2)
    path = str;
  ob = parse_list(0, path);
  if (ob == 0)
    return 0;
  if (!flag) {
    int i;
    ob = first_inventory(ob);
    while(ob) {
      i += 1;
      write(i + ":\t");
      write(ob);
      write("\t" + (string)ob->short() + "\n");
      ob = next_inventory(ob);
    }
    return 1;
  }
  write(ob); write(":\n");
  if ((string)ob->short())
    write((string)ob->short());
  else if ((string)ob->query_real_name())
    write((string)ob->query_real_name());
  else if ((string)ob->query_name())
    write((string)ob->query_name());
  else
    write("(No name)");
  if (living(ob))
    write(" (living)");
  write("\n");
  if (tmp = (int)ob->query_level())
    write("Level:       " + tmp + "\n");
  if ((int)ob->query_npc())
    write("(NPC)\n");
  if (tmp = (int)ob->query_value())
    write("Value:\t" + tmp + "\n");
  if (tmp = (int)ob->query_weight())
    write("Weight:\t" + tmp + "\n");
  if (temp = creator(ob))
    write("Creator:\t" + temp + "\n");
  if ((tmp = (int)ob->query_ac()) || (tmp = (int)ob->armor_class()))
    write("Armor class:    " + tmp + "\n");
  if ((tmp = (int)ob->query_wc()) || (tmp = (int)ob->weapon_class()))
    write("Weapon class:   " + tmp + "\n");
  if (tmp = (int)ob->query_type())
    write("Armor type:     " + tmp + "\n");
  return 1;
}

int
id(string str) {
    return str == "change" || str=="ND";
}

string
query_short() {
  return "";
}

string
short() {
  return "";
}

int
long1() {
  write("Commands available:\n");
  write(" Dump <item>............................Shows contents of <item>\n");
  write(" Dump <item> <flag>.....................Shows values of all\n" +
	"                                        variables in <item>\n");
  write(" Dest <item>\n");
  write(" Call <item> 'function'\n");
  write(" Call <item> 'function' 'argument'\n");
  write(" Tell <item> 'str'\n");
  write(" Trans <item>\n");
  write(" Set <var> <item>\n");
  write("\n");
  write("An item is a list separated by ':'. An item in that list can " +
      "be:\n");
  write(" @name\t.......................Name of a player or monster.\n");
  write(" \"str\"\t.......................Short description of an item.\n");
  write(" /obj\t.......................Name of an object or room.\n");
  write(" $var\t.......................Contents of a variable.\n");
  write(" here\t.......................This room.\n");
  write(" me\t.......................You.\n");
  write(" #num\t.......................Object number 'num'.\n");
  write(" id\t.......................Name of an item.\n");
  write("\n");
  write("Example: take a bag from a player named foul:\n");
  write("Trans @foul:bag\n");
  return 1;
}

int
get() {
  if ((string)this_player()->query_real_name() == "shadowhawk")
    return 1;
  return 0;
}

int
drop() {
  return 1;
}

int
query_value() {
  return 0;
}

static int
i_destruct(string str) {
  object ob;

  ob = parse_list(0, str);
  if (!ob)
    return 0;
  destruct(ob);
  write("Ok.\n");
  return 1;
}

static int
i_call(string str) {
  string with, what, item;
  int iwhat;
  object ob;

  if (!str)
    return 0;
  if (sscanf(str, "%s %s %d", item, with, what) == 3)
    iwhat = 1;
  else if (sscanf(str, "%s %s %s", item, with, what) != 3) {
    if (sscanf(str, "%s %s", item, with) == 2)
      iwhat = 0;
    else
      return 0;
  }
  ob = parse_list(0, item);
  if (!ob)
    return 0;
  write("Got: "); write((mixed)call_other(ob, with, what)); write("\n");
  return 1;
}

static int
i_tell(string str) {
  string item, what;
  object ob;

  if (!str)
    return 0;
  if (sscanf(str, "%s %s", item, what) != 2)
    return 0;
  ob = parse_list(0, item);
  if (!ob)
    return 0;
  if (!living(ob)) {
    write("Not a living object.\n");
    return 1;
  }
  tell_object(ob, (string)this_player()->query_name() +
	      " tells you: " + what + "\n");
  return 1;
}

static int
i_trans(string str) {
  object mark;

  if (!str)
    return 0;
  mark = parse_list(0, str);
  if (!mark)
    return 0;
  if ((int)mark->get())
    move_object(mark, this_player());
  else
    move_object(mark, environment(this_player()));
  write("Ok.\n");
  return 1;
}

static object
find_item(object prev, string str) {
  object ob;
  string temp;
  int tmp;

  if (str == "here")
    return environment(this_player());
  if (str == "me")
    return this_player();
  if (str == "^")
    return environment(prev);
  if (sscanf(str, "@%s", temp) == 1)
    return find_living(temp);
  if (sscanf(str, "/%s", temp) == 1)
    return find_object(temp);
  if (sscanf(str, "$%s", temp) == 1) {
    if (temp == var1)
      return store1;
    if (temp == var2)
      return store2;
    if (temp == var3)
      return store3;
    return 0;
  }
  if (prev == 0)
    prev = environment(this_player());
  if (sscanf(str, "\"%s\"", temp) == 1) {
    ob = first_inventory(prev);
    while(ob && (string)ob->short() != temp) {
      ob = next_inventory(ob);
    }
    return ob;
  }
  if (sscanf(str, "#%d", tmp) == 1) {
    if (prev == 0)
      return 0;
    ob = first_inventory(prev);
    while(tmp > 1) {
      tmp -= 1;
      if (ob == 0)
	return 0;
      ob = next_inventory(ob);
    }
    return ob;
  }
  return present(str, prev);
}

static object
parse_list(object prev, string str) {
  string tmp, rest;

  if (prev == 0)
    prev = environment(this_player());
  while(prev && str) {
    if (sscanf(str, "%s:%s", tmp, rest) == 2) {
      prev = find_item(prev, tmp);
      str = rest;
      write("OBJ(" + file_name(prev) + ")\n");
      continue;
    }
    prev = find_item(prev, str);
    if (objectp(prev))
      write("OBJ(" + file_name(prev) + ")\n");
    break;
  }
  return prev;
}

static int
i_set(string str) {
  object ob;
  string item, var;

  if (!str)
    return 0;
  if (sscanf(str, "%s %s", var, item) != 2)
    return 0;
  ob = parse_list(0, item);
  if (!ob)
    return 0;
  if (var1 == 0 || var1 == var) {
    var1 = var;
    store1 = ob;
    return 1;
  }
  if (var2 == 0 || var2 == var) {
    var2 = var;
    store2 = ob;
    return 1;
  }
  if (var3 == 0 || var3 == var) {
    var3 = var;
    store3 = ob;
    return 1;
  }
  write("Too many variables.\n");
  return 1;
}

int
where_at(string str) {
  object where, ob;
  string who;

  if (sscanf(str, "%s", who) != 1) {
    write("find who?\n");
    return 1;
  }
  if (who == "me") {
    where = environment(this_player());
    if (!where)
      write("No environment!\n");
    else {
      write("You are in " + file_name(where) + "\n");
      write("Short: " + (string)ob->short() + ".\n");
    }
    return 1;
  }
  ob = find_living(who);
  where = environment(ob);
  if (!where) {
    write("No environment!\n");
    return 1;
  }
  write("Environment is " + file_name(where) + "\n");
  write("Short: " + (string)ob->short() + ".\n");
  (void)where->long();
  return 1;
}
