/****************************************************************************\
 * include.h              General Include File                              *
 *                                                                          *
 * This file contains a large number of #defines to make LPC programs       *
 * easier to write and read.  This file is available to anybody for free    *
 * distribution with or without alteration.                                 *
 *                                                                          *
 * Direct any questions or comments to Shadowhawk (yorkjoe@elof.iit.edu)    *
\****************************************************************************/
 
/****************************************************************************\
|* The file mud.h defines which mud this mud is, and also which version     *|
|* it's running.                                                            *|
\****************************************************************************/

#include "mud.h"
 
/****************************************************************************\
 * This section just defines identifiers.                                   *
\****************************************************************************/
 
#define MASTER                    "shadowhawk"
#define CAP_MASTER                "Shadowhawk"
#define ABBREV                    "SH"
 
 
/****************************************************************************\
 * This section defines several directories and file paths.                 *
\****************************************************************************/
 
#define CASTLE_DEST               "/room/alley"
#define DIR_ROOT                  "/players/" + MASTER + "/"
#define DIR_CLOSED                DIR_ROOT + "closed/"
#define DIR_LOG                   DIR_ROOT + "log/"
#define DIR_HORROR  DIR_ROOT + "horror/"
#define DHORROR_ROOMS DIR_HORROR + "rooms/"
#define DHORROR_MONSTERS DIR_HORROR + "monsters/"
#define DHORROR_WEAPONS DIR_HORROR + "weapons/"
 
 
/****************************************************************************\
 * This section defines specific realms for within my "castle".  The        *
 * inclusion of the ABBREV yields unique tags.                              *
\****************************************************************************/
 
#define REALM_HORROR              ABBREV + "#horror"
#define REALM_WORK                realm() { return ABBREV + "#wizard"; }
#define REALM_OF_HORROR           realm() { return REALM_HORROR; }
 
 
/****************************************************************************\
 * This sections defines general files for common objects.                  *
\****************************************************************************/
 
#define STANDARD_MONSTER          "obj/monster"
#define STANDARD_WEAPON           "obj/weapon"
#define STANDARD_ARMOR            "obj/armor"
#define STANDARD_QUEST            "obj/quest.new"
#define STANDARD_CONTAINER        "obj/container"
#define STANDARD_ROOM             "room/room"
 
 
/****************************************************************************\
 * This section contains defines for symbols to increase readability and    *
 * convey more of the purpose of certain code.                              *
\****************************************************************************/
 
#define AND                       &&
#define OR                        ||
#define FAILURE                   0
#define SUCCESS                   1
#define FALSE                     0
#define TRUE                      1
#define NULL                      0
#define NEWLINE                   "\n"
#define MAXINT                    2147483647
#define ARRAY
 
/****************************************************************************\
 * This sections defines many abbreviations for common LPC functions.       *
\****************************************************************************/
 
#define ME                        this_player()
#define THIS                      this_object()
#define PEOPLE                    users()
#define QRN                       query_real_name()
#define QN                        query_name()
#define FI(object)                first_inventory(object)
#define NI                        next_inventory
#define FP(name)                  find_player(name)
#define FL(name)                  find_living(name)
#define FO(filename)              find_object(filename)
#define FS(file)                  file_size(file)
#define FN(object)                file_name(object)
#define MP(dest)                  move_player(dest)
#define CO(file)                  clone_object(file)
#define CAP(string)               capitalize(string)
#define LOWER(string)             lower_case(string)
#define ENV(object)               environment(object)
#define MO(object, dest)          move_object(object, dest)
#define TO(object, string)        tell_object(object, string)
#define TR(where, string)         tell_room(where, string)
#define AA(func, action)          add_action(func, action)
#define AX(func, action)          add_action(func); add_xverb(action)
#define CALL(object, function)    call_other(object, function)
 
 
/****************************************************************************\
 * This section defines "macros", substitutions for larger sections of code.*
\****************************************************************************/
 
#define TPQRN                     ME->QRN
#define TPQL                      ME->query_level()
#define RESET() reset(arg) { if (arg) do_reset(); else create(); } do_reset()
#define QLONG long() { write(query_long()); } query_long
#define QSHORT short() { return query_short(); } query_short
#define CALL_PREV_RESET ::reset(1);
#define CALL_PREV_CREATE ::reset(0);
