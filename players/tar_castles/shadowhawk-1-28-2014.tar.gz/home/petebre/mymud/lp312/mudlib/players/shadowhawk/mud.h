/* Sigh */
#define THIS_MUD "elof.iit.edu 3500"
#define MUD_VERSION "03.00.44"
