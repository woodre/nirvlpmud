/****************************************************************************
 * Credits:                                                                 *
 *                                                                          *
 * Laser cannon loosely based on Omega Corp. IBX Series II missiles (same)  *
 *                                                                          *
 * Current laser (TURBO LASER v1.1) developed and written by Shadowhawk     *
 *                                                                          *
 * Copyright Shadowhawk (Joel York: yorkjoe@elof.iit.edu) 1990, 1991        *
 ****************************************************************************/

/****************************************************************************
 * List of global variables and their uses:                                 *
 *  target............current default target of laser cannon                *
 *  laser_invis.......indicates wether target will be notified of lasering  *
 *  damage............amount a damage done by laser cannon                  *
 ****************************************************************************/

/****************************************************************************
 * List of functions and their uses:                                        *
 ****************************************************************************
 *  TURBO LASER v1.1 functions (all are static):                            *
 *   set_damage.........sets the amount of damage done by TURBO LASER       *
 *   fire_laser.........activates the TURBO LASER                           *
 *   set_laser_invis....determines whether TURBO LASER generated visible    *
 *                      radiation                                           *
 *   set_laser_target...sets default target for TURBO LASER                 *
 ****************************************************************************/

int damage;
object target;
int laser_invis;




/****************************************************************************
 ****************************************************************************
                    BEGIN FUNCTIONS FOR TURBO LASER v1.1
 ****************************************************************************
 ****************************************************************************/

/****************************************************************************
 * Set_damage - sets the amount of damage done by Turbo Laser               *
 ****************************************************************************/

static set_damage(sdam) {
   int dam;

   if (!sdam || sscanf(sdam,"%d",dam)!=1) {
      write("The correct format is \"damage <amount>\".\n");
      return 1;
   }
   damage = dam;
   write("Laser cannon damage set to....." + dam + ".\n");
   return 1;
}

/****************************************************************************
 * Fire_laser - fires the TURBO LASER v1.1 at a specified target, or        *
 *              default target if none specified                            *
 ****************************************************************************/

static fire_laser(str) {
   object current_target;
   string name;

   if (!str && !target) {
      write("No target, default or otherwise, has been specified.\n");
      return 1;
   }
   if (str) {
      current_target = FL(str);
      if (!current_target) {
         write("The creature named " + str + " is not on the game.\n");
         return 1;
      }
   } else if (!target) {
      write("No target, default or otherwise, has been specified.\n");
      return 1;
   } else
      current_target = target;
   if (current_target->QRN)
      name=current_target->QRN;
   else
      name=current_target->short();
   if (laser_invis)
      TO(current_target, "A laser cannon is fired at you!\n");
   current_target->add_hit_point((-1) * damage);
   write(CAP(name) + " has been hit for " + damage + " points.\n");
   if (current_target->query_hp() < 1) {
      destruct(current_target);
      write("And has been devastated!\n");
   }
   return 1;
}   /* End of fire_laser */

/****************************************************************************
 * Set_laser_invis - sets the level of invisibility of the 2nd Generation   *
 *                   Shadowhawk Laser Cannon                                *
 *    set to zero - lasering goes unannounced to target (fun stuff ;)       *
 *    set to one - lasering is announced to target                          *
 ****************************************************************************/

static set_laser_invis(str) {
   int invis_setting;

   if (!str || sscanf(str,"%d", invis_setting) != 1) {
      write("The correct syntax is: radiate <invis>.\n");
      return 1;
   }
   laser_invis = invis_setting;
   write("Visible radiation set to " + laser_invis + ".\n");
   return 1;
}

/****************************************************************************
 * Set_laser_target - sets the default target for the Turbo Laser v1.1      *
 ****************************************************************************/

static set_laser_target(str) {
   object temp_target;

   temp_target = FP(str);
   if (temp_target) {
      target = temp_target;
      write("Default target has been set to the player " +
         target->QRN + ".\n");
      return 1;
   }
   temp_target = FL(str);
   if (temp_target) {
      target = temp_target;
      write("The default target has been set to the creature " +
         target->short() + ".\n");
      return 1;
   }
   write("No living being on the game is going by that name.\n");
   return 1;
}

/****************************************************************************
 ****************************************************************************
                     END OF FUNCTIONS FOR TURBO LASER v1.1
 ****************************************************************************
 ****************************************************************************/
