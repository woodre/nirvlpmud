/****************************************************************************
 * Credits:                                                                 *
 *                                                                          *
 * Shield technology created by Edward (at the defunct elof.iit.edu 2000)   *
 * Idea of alarm borrowed from Prischa (also of elof.iit.edu 2000)          *
 *                                                                          *
 * Copyright Shadowhawk (Joel York: yorkjoe@elof.iit.edu) 1990, 1991        *
 ****************************************************************************/

/****************************************************************************
 * List of global variables and their uses:                                 *
 *  Invite............array which holds invitation list                     *
 *  shield............current shield state                                  *
 *  nInvite...........number of people currently invited                    *
 *  alarm.............invasion alarm: audible == 1, silent == 0             *
 *  Iinvis............determines if the invitating butler is on duty        *
 ****************************************************************************/

/****************************************************************************
 * List of functions and their uses:                                        *
 ****************************************************************************
 *  TURBO SHIELD v2.1 functions (all are static):                           *
 *   Init_shield........adds actions and bounces                            *
 *   invitees...........lists people invited                                *
 *   invite.............puts a person on the invited list                   *
 *   state..............writes the shield state                             *
 *   alarm..............sets the alarm level                                *
 *   setshield..........sets the shield state                               *
 *   enforce............kicks out all people when shield level changes      *
 *   uninvite...........removes a person from invited list and kick him out *
 *   clear..............clears out the entire workroom                      *
 *   bounce.............the actual bouncer function                         *
 *   invited............checks to see if a person is on the invited list    *
 *   butler.............brings the inviting butler on or off duty           *
 ****************************************************************************/

string Invite;
int shield, nInvite, alarm, Iinvis;




/****************************************************************************
 ****************************************************************************
                    BEGIN FUNCTIONS FOR TURBO SHIELD v2.1
 ****************************************************************************
 ****************************************************************************/


/****************************************************************************\
|* Init_toolkit - bounces people out if they are not supposed to be here.   *|
|*                Will also add actions for itself eventually.              *|
\****************************************************************************/

static /* VOID */
_init_shield() {
   if (shield AND !invited(ME->QRN))
      bounce(ME);
   else if (alarm)
      tell_room(this_object(), capitalize(this_player()->query_real_name()) +
         " is here!\n");
}

/****************************************************************************
 * invitees - writes out list of people who have been invited               *
 ****************************************************************************/

static
invitees() {
   int counter;

   if (nInvite < 1) {
      write("No one is invited right now.\n");
      return 1;
   }
   counter = nInvite;
   write("The people you have invited:\n");
   while (counter > 0) {
      write("   " + CAP(Invite[counter]) + "\n");
      counter -= 1;
   }
   state();
   write("\n");
   return 1;
}

/****************************************************************************
 * invite - puts a person on the invited list and if the invis flag is set, *
 *          they are told                                                   *
 ****************************************************************************/

static invite(str) {
   if (!str) {
      write("The proper format for invite is \"invite <name>\".\n");
      return 1;
   }
   if (invited(str)) {
      write("That person has already been invited!\n");
      return 1;
   }
   if (nInvite < 1) {
      nInvite = 0;
      Invite = allocate(20);
   }
   nInvite += 1;
   Invite[nInvite] = str;
   if (Iinvis && FP(str)) {
      object ob;
      ob = FP(str);
      TO(ob, "Shadowhawk's butler appears next to you.\n");
      TO(ob, "He hands you an invitation ingraved in silver to " +
         "Shadowhawk's workroom.\n");
      TO(ob, "The butler disappears before you can say a word.\n");
      write("That person has been handed an invitation.\n");
   }
   write(CAP(str) + " has been put on the invitees list.\n");
   return 1;
}

/****************************************************************************
 * state - writes out the current shield setting                            *
 ****************************************************************************/

static state() {
   write("The current shield state is " + shield + ".\n");
   return 1;
}

/****************************************************************************
 * Alarm - to set alarm state...                                            *
 *  If set to any positive number - Shadowhawk is alerted to any attempted  *
 *     intrusions of uninvited folk, guests are announced to the workroom   *
 *  If set to zero - Shadowhawk is not notified                             *
 ****************************************************************************/

static alarm(str) {
   if (sscanf(str, "%d", alarm) != 1) {
      write("You must enter one digit!");
      return 1;
   }
   write("   Alarm state set to....." + alarm + ".\n");
   return 1;
}

/****************************************************************************
 * Setshield - to set shield state number                                   *
 *    set to zero - No active shielding                                     *
 *    set to one - only invited people allowed...with exiting priveleges    *
 *    set to two - only invited people allowed...no default exits           *
 *    set to greater than two - only Shadowhawk is allowed                  *
 ****************************************************************************/

static setshield(str) {
   object test;
   int shieldch;

   if (!str) {
      write("USAGE:   shield <state> where state can be a digit between 0 " +
         "and 3,\n         or a symbolic state.\n");
      return SUCCESS;
   }
   if (str == "off")
      str = "0";
   if (str == "full")
      str = "3";
   if (str == "on") {
      write("Assuming \"on\" means minimal strength shield.\n");
      str = "1";
   }
   if (str == "noexit")
      str = "2";
   if (sscanf(str, "%d", shieldch) != 1) {
      write("You must give the shield state as a number!\n");
      return 1;
   }
   write("Shield state " + shieldch + " being initiated.\n");
   if (shieldch < 1) {
      shield = 0;
      write("Shields down to no energy.\n");
   } else
      enforce(shieldch);
   return 1;
}

/****************************************************************************
 * Enforce - advances sequentially through inventory of workroom, and       *
 *           calls bounce with each object (except Shadowhawk) as parameter *
 ****************************************************************************/

static enforce(num) {
   object idiot,inven;

   if (num)
      shield = num;
   inven = FI(THIS);
   while (inven) {
      idiot = next_inventory(inven);
      if (inven && inven->QRN != MASTER)
         bounce(inven);
      inven = idiot;
   }
   state();
   return 1;
}

/****************************************************************************
 * Uninvite - remove a person from the invitees list and pass them to       *
 *            bounce if they are still here                                 *
 ****************************************************************************/

static uninvite(str) {
   int countdown;

   if (!str || !invited(str)) {
      write("That person hasn't been invited!\n");
      return 1;
   }
   countdown=nInvite;
   while (Invite[countdown] != str)
      countdown -= 1;
   nInvite -= 1;
   if (countdown == (nInvite + 1))
      Invite[countdown] = 0;
   else {
      while(countdown <= nInvite) {
         Invite[countdown] = Invite[countdown+1];
         countdown += 1;
      }
   }
   if (present(str))
      bounce(FP(str));
   if (nInvite == 0)
      Invite = 0;
   write("Uninvitation complete.\n");
   return 1;
}   /* End of uninvite function */

/****************************************************************************
 * Clear - deletes the entire invitees list and calls enforce to clear the  *
 *         room of any vermin still existing                                *
 ****************************************************************************/

static clear() {
   object current, next;

   nInvite = 0;
   Invite = 0;          /* Clear list and free up memory */
   enforce();
   write("List of invitees is cleared.\n");
   return 1;
}     /* Done with clear function */

/****************************************************************************
 * Bounce - complicated, but is currently heart the Turbo Shield v2.1       *
 *                                                                          *
 * algorithm - if shield is off or passed argument is Shadowhawk, stop      *
 *             if argument is alive and not invited, move them to the       *
 *             church, tell them that they have been ejected, tell the      *
 *             church who came in, and if Shadowhawk is on and the alarm is *
 *             on, tell Shadowhawk, finally log the intrusion.              *
 ****************************************************************************/

static bounce(ob) {
   object master;
   string name;

   name = ob->QRN;
   if ((shield < 1) || name == MASTER || name == "bird")
      return 0;
   if (ENV(ob) != THIS)
      return 0;
   if (!invited(name) && living(ob)) {
      TR("room/church", CAP(name) + " landes hard on " +
         possessive(ob) + " butt!\n");
      MO(ob, "room/church");
      TO(ob, "You have not been invited by master Shadowhawk!\n");
      TO(ob, "You land hard on your butt!\n");
      master = FP(MASTER);
      if (master && (alarm > 0))
         TO(master, CAP(name) +
            " tried to invade your workroom!\n");
      write_file("/players/shadowhawk/log/invaders", CAP(name) +
         " tried to invade Shadowhawk's workroom.\n");
   }
   return 1;
} /* End of bounce function */

/****************************************************************************
 * Invited - searches invitees list to see if argument has been invited     *
 ****************************************************************************/

static invited(str) {
   int indx;

   if ((shield > 2) || (nInvite < 1))
      return 0;
   indx = nInvite;
   while (indx > 0) {
      if (Invite[indx] == str)
         return 1;
      indx -= 1;
   }
   return 0;
}  /* End of invited function */

/****************************************************************************
 * butler - Determines if Shadowhawk's butler will give an invitation to    *
 *          people when they are invited.                                   *
 ****************************************************************************/

butler(arg) {
   int butler_invis;

   if (!arg) {
      write("USAGE: butler <invis>\n");
      return SUCCESS;
   }
   if (arg == "on")
      arg = "1";
   if (arg == "off")
      arg = "0";
   if (sscanf(arg, "%d", butler_invis) != 1) {
      write("The proper format for butler is \"butler <invis>\", where " +
         "<invis> is 1 for\nvisible invitation, and 0 otherwise.\n");
      return 1;
   }
   if (butler_invis > 1)
      butler_invis = 1;
   Iinvis = butler_invis;
   write("The butler is ");
   if (Iinvis == 0)
      write("off");
   else
      write("on");
   write(" duty.\n");
   return 1;
}

/****************************************************************************
 ****************************************************************************
                   END OF FUNCTIONS FOR TURBO SHIELD v2.1
 ****************************************************************************
 ****************************************************************************/
