/****************************************************************************\
 * Credits:                                                                 *
 *                                                                          *
 *    Wizard Toolkit v6.1 designed and written by Shadowhawk                *
 *       with functions written by Morgar (from Morgar's Hat)               *
 *    Feather designed and written by Shadowhawk                            *
 *                                                                          *
 * Copyright Shadowhawk (Joel York: yorkjoe@elof.iit.edu) 1990, 1991        *
\****************************************************************************/

/****************************************************************************
 * Functions defined in this object:                                        *
 ****************************************************************************
 *  Statdard object functions:                                              *
 *   Id..........................identifies the object                      *
 *   Short.......................returns the short descrip of the item      *
 *   Long........................writes the long descrip of the object      *
 *   Query_auto_load.............sets the file name for auto-loading        *
 *   Init_arg....................signals acceptance of auto-loading         *
 *   Init........................adds commands and security features        *
 *   Get.........................only Shadowhawk can get it                 *
 *   Drop........................for security, dropping is not allowed      *
 ****************************************************************************/

#include "../../include.h"
#include "toolkit.c"

/****************************************************************************
 ****************************************************************************
                     BEGIN STANDARD OBJECT FUNCTIONS
 ****************************************************************************
 ****************************************************************************/

/****************************************************************************
 * Reset - called at creation time and every reset                          *
 ****************************************************************************/

reset(arg) {
   if (arg) {
      tell_object(find_player("shadowhawk"),
         "Your feather tells you a reset just occurred with argument " +
         arg + ".\n");
      return 1;
   }
   return 1;
}

/****************************************************************************
 * Id - identifies object when needed                                       *
 ****************************************************************************/

id(str) {
   return (str == "feather");
}

/****************************************************************************
 * Short - returns feather if looked at by Shadowhawk, no short otherwise   *
 ****************************************************************************/

short() {
   if (ME == MASTER)
      return "Feather";
   return 0;
}

/****************************************************************************
 * Long - Writes command for help screen if viewer is Shadowhawk, a nice    *
 *        forbidding descrip otherwise                                      *
 ****************************************************************************/

long() {
   if (ME == FP(MASTER)) {
      write("Use 911 to list help screen, Mr. No-Short-Term-Memory.\n");
   } else {
      write("This is Shadowhawk's Feather of Control!\n");
      write("Don't use it if you don't want to be transformed into a bird!\n");
   }
   return 1;
}

/****************************************************************************
 * Query_auto_load - specfies file name to clone for player upon start      *
 ****************************************************************************/

query_auto_load() {
  return 0; /* login file works better. */
   return "players/shadowhawk/closed/toys/test1:";
}

/****************************************************************************
 * Init_arg - useless function which must return 1 for auto_loading to work *
 ****************************************************************************/

init_arg() {       /* Required for autoloading */
   return 1;
}

/****************************************************************************
 * Init - adds commands if holder is Shadowhawk, moves others to church,    *
 *        informs Shadowhawk of intrusion, and logs it.                     *
 ****************************************************************************/

init() {
   string name;

   name = ME->QRN;
   if (name == MASTER)
      init_toolkit();   /* This function (from the toolkit) adds actions */
   else {                     /* Security feature */
      name = CAP(name);
      if (FP(MASTER)) {
         if (ENV(this_object()) != FP(MASTER))
            MO(this_object(), FP(MASTER));
         else {
            MO(ME, "room/church");
            to(FP(MASTER), name +
               " tried to invade your inventory.\n");
            write_file("players/shadowhawk/log/invade.inven",
               name + " was there.\n");
         }
      } else
         destruct(this_object());
   }
}

/****************************************************************************
 * Get - if it's Shadowhawk, he can get it, otherwise no pick up            *
 ****************************************************************************/

get() {
   string name;

   name = ME->QRN;
   if (name == "blastarr" || name == MASTER)
      return 1;
   return 0;
}

/****************************************************************************
 * Drop - For security, the feather cannot be dropped                       *
 ****************************************************************************/

drop() {
   return 1;
}

/****************************************************************************
 ****************************************************************************
                      end STANDARD OBJECT FUNCTIONS
 ****************************************************************************
 ****************************************************************************/
