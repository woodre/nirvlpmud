/****************************************************************************\
 * Credits:                                                                 *
 *                                                                          *
 *    Wizard's Hat Collection v1.1 imported from Morgar's pointy hat        *
 *       Contained Hat Collection is modified by Shadowhawk                 *
 *    Wizard Toolkit v6.1 designed and written by Shadowhawk                *
 *                                                                          *
 * Copyright Shadowhawk (Joel York: yorkjoe@elof.iit.edu) 1990, 1991        *
\****************************************************************************/

/****************************************************************************
 * Variables defined in this object:                                        *
 *  regular, senior, elder, god..for use in New_people function             *
 *  query_list...................array of functions to be queried in        *
 *                               function Total_inven                       *
 *  next.........................allows continuity and screen length        *
 *                               adjustment in Total_inven                  *
 ****************************************************************************/

/****************************************************************************
 * Functions defined in this object(all static):                            *
 ****************************************************************************
 *  Wizard's Hat Collection of functions modified by Shadowhawk:            *
 *   Charm_it....................charms any living creature                 *
 *   Set_charm...................for commanding any charmed creature        *
 *   Remove_charm................free a charmed creature                    *
 *   Stats.......................to check status of a charm                 *
 *   Zap.........................to splat monsters or stupid players        *
 *   Gag_it......................prevent players from shouting              *
 *   Remove_gag..................allow gagged players to shout              *
 ****************************************************************************
 *  Functions of Wizard Toolkit v6.1:                                       *
 *   Feather_help................calls up a help screen                     *
 *   Afar........................dests any monster on the game              *
 *   Loud........................blind shout to the game                    *
 *   Someone.....................tells something to one person              *
 *   Room........................echoes to the environment of holder        *
 *   Move........................moves one object into anothers inventory   *
 *   In..........................moves holder into anothers inventory       *
 *   Leave.......................exits from person's inventory              *
 *   Dupe........................creates a dummy in environment             *
 *   Nullify.....................disable usage of a command                 *
 *   Translate...................trans a person as per the wiz command      *
 *   Superdest...................dests invis wizards                        *
 *   Birdify.....................changes title to "the bird!"               *
 *   New_people..................nicely spaced people list                  *
 *   Transporter.................transports a person to the workroom        *
 *                               (invisibly)                                *
 *   Title.......................changes any player's title                 *
 *   Lwhere......................shows the environment of any player        *
 *   Wizzes......................determines number of wizards on using      *
 *                               users()                                    *
 *   Diaperizing.................gives an xverb diaper to someone           *
 *   Clone_special...............clones Shadowhawk's special items          *
 *   Total_inven.................lists Shadowhawk's complete inventory with *
 *                               useful info on each item                   *
//   For_all.....................does something for everybody in a list   //
***************************************************************************/

#include <security.h>

int regular, senior, elder, god;
/*ARRAY*/ string query_list;
object next;

/****************************************************************************
 ****************************************************************************
              BEGIN Wizard's Hat Collection v1.1SH FUNCTIONS
 ****************************************************************************
 ****************************************************************************/

/****************************************************************************
 * Gag_it - Creates a gag for a player to prevent shouting from anal        *
 *          retentive characters.                                           *
 ****************************************************************************/

static
gag_it(str) {
   object liv, ob;

   liv = FL(str);
   if (!liv) {
      write("Can't find "+str+".\n");
      return 1;
   }
   ob = present("shout_curse", liv);
   if (ob) {
      write(str + " already has a sore throat.\n");
      return 1;
   }
   ob = CO("obj/shout_curse");
   ob->start(liv);
   write("Done.\n");
   return 1;
}

/****************************************************************************
 * Remove_gag - Removes any gag named "shout_curse" on a player.            *
 ****************************************************************************/

static
remove_gag(str) {
   object liv, ob;

   liv = FL(str);
   if (!liv) {
      write("Can't find " + str);
      return 1;
   }
   ob = present("shout_curse", liv);
   if (!ob) {
      write(str + " has no sore throat.\n");
      return 1;
   }
   to(liv, "Your throat feels better now.\n");
   destruct(ob);
   write("Done.\n");
   destruct(ob);
   return 1;
}

/****************************************************************************
 * Charm_it - Moves Morgar's charm object to a player.                      *
 ****************************************************************************/

static
charm_it(str) {
   object liv, ob;

   liv = FL(str);
   if (!liv) {
      write("Can't find " + str + ".\n");
      return 1;
   }
   ob = present("charm", liv);
   if (ob) {
      write(str + " is already charmed.\n");
      return 1;
   }
   ob = CO("players/shadowhawk/objects/toys/follow");
   transfer(ob, liv); /* may want to tell them.  Nahhh. */
   write("Charm done.\n");
   return 1;
}

/****************************************************************************
 * Remove_charm - Removes object called "charm" from a player.              *
 ****************************************************************************/

static
remove_charm(str) {
   object liv, ob;
   liv = FL(str);
   if (!liv) {
      write("Can't find " + str + "\n");
      return 1;
   }
   ob = present("charm", liv);
   if (!ob) {
      write(str + " is not charmed.\n");
      return 1;
   } /* don't tell then, of course */
   transfer(ob, ENV(liv));
   write("Free done.\n");
   destruct(ob);
   return 1;
}

/****************************************************************************
 * Set_charm - Activates a charm object.                                    *
 ****************************************************************************/

static
set_charm(str) {
   object liv, ob, targ;
   string livstr, targstr;

   if (sscanf(str, "%s follow %s", livstr, targstr) != 2) {
      write("Bad syntax.\n");
      return 1;
   }
   liv = FL(livstr);
   if (!liv) {
      write("Can't find " + livstr + "\n");
      return 1;
   }
   targ = FL(targstr);
   if (!targ) {
      write("Can't find " + targstr + "\n");
      return 1;
   }
   ob = present("charm", liv);
   if (!ob) {
      write(str + " is not charmed.\n");
      return 1;
   } /* don't tell them, of course */
   ob->startfollow(targstr);
   write("Command done.\n");
   return 1;
}

/****************************************************************************
 * Stats - Checks to see if a player has an object called "charm".          *
 ****************************************************************************/

static
stats(arg) {
   string name, checkstr;
   object liv, ob;

   name = TPQRN;
   checkstr = "charm";
   if(arg != "charm" && sscanf(arg, "%s %s", checkstr, name)==0) {return 0;}
   if (checkstr != "charm") {return 0;}
   liv = FL(name);
   if (!liv) {
      write("Can't find " + name + ".\n");
      return 1;
   }
   ob = present("charm", liv);
   if (!ob) {
      write(name + " is not charmed.\n");
      return 1;
   } /* don't tell them, of course */
   call_other(ob, "query_stats", 0);
   return 1;
}

/****************************************************************************
 * Zap - Definitively kills any killable object.                            *
 ****************************************************************************/

static
zap(str) {
   object liv, ob;
   liv = FL(str);
   if (!liv) {
      write("Can't find "+str+".\n");
      return 1;
   }
   call_other(liv, "hit_player", 2147483647);
   write("Modified zap done.\n");
   return 1;
}

/****************************************************************************
 ****************************************************************************
              end Wizard's Hat Collection of FUNCTIONS v1.1SH
 ****************************************************************************
 ****************************************************************************/




/****************************************************************************
 ****************************************************************************
                  BEGIN Wizard Toolkit v6.1 FUNCTIONS
 ****************************************************************************
 ****************************************************************************/

/****************************************************************************
 * Init_toolkit - sets up actions to use functions in toolkit               *
 ****************************************************************************/

static
init_toolkit() {
   if (TPQRN == MASTER) {
      /* Wizard Toolkit 2 v5.0 functions: */
      AA("toolkit_help", "911");
      AA("superdest","sdest!");
      AA("translate", "send");
      AA("afar", "afar");
      AX("loud", "=");
      AX("someone", "*");
      AX("room", "[");
      AA("in", "to");
      AA("move", "move");
      AA("dupe", "dupe");
      AA("nullify", "void");
      AA("leave", "leave");
      AA("new_people","o");
      AA("title", "ti");
      AA("transporter", "send");
      AA("diaperizing", "diaper");
      AA("clone_special", "stuff");
      AA("lwhere", "lwhere");
      AA("total_inven", "ii");
      AA("for_all", "forall");
      AA("do_file_size", "filesize");

      /* Wizard's hat Collection v1.1SH functions: */
      AA("stats", "stat");
      AA("zap", "zap");
      AA("remove_gag", "rgag");
      AA("gag_it", "gag");
      AA("set_charm", "command");
      AA("remove_charm", "free");
      AA("charm_it", "charm");
   }
   return 1;
}   /* End Init_toolkit */

/*****************************************************************************
 * Toolkit_help - Writes out all functions in Wizard Toolkit 2 v5.0 and      *
 *                Wizard's Hat collection v1.1SH                             *
 *****************************************************************************/

static
toolkit_help() {
   write("Commands available:\n");
   write("   Charm <creature>...................charm <creature>.\n");
   write("   Command <x> follow <y>.............<x> will follow <y>.\n");
   write("   Free <creature>....................<creature> will be " +
      "uncharmed.\n");
   write("   Stat charm <creature>..............check if <creature> is " +
      "charmed.\n");
   write("   Gag <creature>.....................prevents <creature> from " +
      "shouting.\n");
   write("   Rgag <creature>....................eliminates gag.\n");
   write("   Zap <creature>.....................kills <creature>...fast.\n");
   write("   Afar <creature>....................destructs <creature>.\n");
   write("   =\"string\"..........................shouts \"string\" + <cr>.\n");
   write("   *<player> \"string\".................tells name \"string\" + " +
      "<cr>.\n");
   write("   [\"string\"..........................says \"string\" + <cr>" +
      " in room.\n");
   write("   To <creature>......................moves you into <creature>'s " +
      " inven.\n");
   write("   Leave..............................exits from a person's " +
      "inventory\n");
   write("   Move <creature> into <creature2>...moves creature into " +
      "creature2's inven.\n");
   write("   Send <creature>....................invisibly trans " +
      "<creature>.\n");
   write("   Void \"command\".....................eliminates usage of " +
      "\"command\".\n");
   write("   Drop feather.......................doesn't work.\n");
   write("   Sdest! <level>.....................dest all above invis " +
      "<level>.\n");
   write("   911................................calls this help.\n");
   write("   Ti <name> <title>..................changes <name>'s title to " +
      "<title>.\n");
   write("   Send <name>........................brings <name> here.\n");
   write("   Lwhere <name>......................gives a look at the env of " +
      "<name>.\n");
   write("   Diaper <name>......................puts xverb diaper on " +
      "<name>.\n");
   write("   Stuff..............................clones the STUFF!.\n");
   write("   ii.................................very nice inventory.\n");
   write("   forall <cmd>.......................repeats cmd for each person on.\n");
   write("      <invis>=1 for audible actions <invis>=0 for silent actions\n");
   write("That's all for now, folks.\n");
   return 1;
}

/****************************************************************************
 * Leave - same as wizard power "exit" - movces Shadowhawk to environment   *
 *         of his environment                                               *
 ****************************************************************************/

static
leave() {
   object env, env1;

   env = ENV(ME);
   if (env) {
      env = ENV(env);
      if (env)
         MO(ME, env);
   }
   if (!env)
      write("No suitable exit!\n");
   return 1;
}

/****************************************************************************
 * Dupe - creates an non-living item called Shadowhawk...useful for         *
 *        surviving dest wars                                               *
 ****************************************************************************/

static
dupe() {
   object obb,where;

   obb = CO("players/shadowhawk/objects/dummy");
   where = ENV(ME);
   MO(obb, where);
   return 1;
}

/****************************************************************************
 * Translate - Nice copy of the trans command                               *
 ****************************************************************************/

static
translate(str) {
   object pob;

   pob = FL(str);
   if (pob) {
      object loc, prev_loc;
      prev_loc = ENV(pob);
      loc = ENV(ME);
      TR(loc, CAP(str) + " has arrived.\n");
      MO(pob,loc);
      to(pob, "You are summoned by the mighty Shadowhawk!\n");
      TR(prev_loc, CAP(str) + " just left on an important journey.\n");
      pob->look();
      write("Ok.\n");
   } else
      write(CAP(str) + " was not found!\n");
   return 1;
}

/****************************************************************************
 * Move - Moves one object into the inventory of another.                   *
 ****************************************************************************/

static
move(str) {
   object who,whoto;
   string swho,swhoto;

   if (sscanf(str, "%s into %s", swho, swhoto) != 2) {
      write("The correct syntax is \"move <object1> into <object2>\".\n");
      return 1;
   }
   who = FL(swho);
   if (!who) {
      who = FO(swho);
      if (!who) {
         write(swho + " is not available!\n");
         return 1;
      }
   }
   whoto = FL(swhoto);
   if (!whoto) {
      whoto = FO(swhoto);
      if (!whoto) {
         write(swhoto + " is not available!\n");
         return 1;
      }
   }
   MO(who,whoto);
   write(swho + " has been moved into " + swhoto + ".\n");
   return 1;
}

/****************************************************************************
 * In - Moves Shadowhawk into another player's inventory.                   *
 ****************************************************************************/

static
in(str) {
   object master,who;

   master = ME;
   who = FL(str);
   if (!who || !master) {
      write("Not working!");
      return 1;
   }
   MO(master,who);
   return 1;
}

/****************************************************************************
 * Room - Echoes a string to Shadowhawk's environment                       *
 ****************************************************************************/

static
room(str) {
   str = str+"\n";
   say(str);
   write("You echo: " + str);
   return 1;
}

/****************************************************************************
 * Someone - Echoes a string to a specific person                           *
 ****************************************************************************/

static
someone(str) {
   object who;
   string swho,what;
   if (sscanf(str, "%s %s", swho, what) != 2) {
      write("The correct syntax is \"*<player> <string>\".\n");
      return 1;
   }
   who = FP(swho);
   if (!who) {
      write(swho + " is not on!\n");
      return 1;
   }
   TO(who, what + "\n");
   write("You echo " + what + " to " + swho + ".\n");
   return 1;
}

/****************************************************************************
 * Loud - Echoes a string to all non-earmuffed players.                     *
 ****************************************************************************/

static
loud(str) {
   shout(str + "\n");
   write("You echo to all: " + str + "\n");
   write("Did you claim that shout or do you want to be demoted?\n");
   return 1;
}

/****************************************************************************
 * Afar - A nicely commented remote dest.                                   *
 ****************************************************************************/

static
afar(str) {
   object ob;

   ob = FL(str);
   if (ob) {
      to(ob, "A hawk swoops down and rips your throat out!\n");
      destruct (ob);
   } else {
      write("Not on.\n");
      return 1;
   }
   write("Gone with a bang!\n");
   return 1;
}

/****************************************************************************
 * Nullify - Eliminates usage of one command.                               *
 ****************************************************************************/

static
nullify(str) {
   if (!str) {
      write("Nullify what?\n");
      return 1;
   }
   AA("ignore", str);
   write("Nullfied!\n");
   return 1;
}

/****************************************************************************
 * Ignore - Null function for nullify.                                      *
 ****************************************************************************/

static
ignore() {
   return 1;
}

/****************************************************************************
 * Superdest - function dests any wizard whose invis level is above a       *
 *             point.  Useless on wizzes who don't show up on the users()   *
 *             array.                                                       *
 ****************************************************************************/

static
superdest(sinvis) {
   string userarray;
   int ndx;
   int invis;

   userarray = PEOPLE;
   if (!sinvis || (sscanf(sinvis, "%d", invis) != 1))
      invis = ME->query_invis();
   else
      if (invis < ME->query_invis())
         invis = ME->query_invis();
   ndx=0;
   while (ndx < sizeof(userarray)) {
      if (userarray[ndx]->query_invis() > invis) {
         write("Destruct: " + userarray[ndx]->QRN);
         write("  Invis level: " + userarray[ndx]->query_invis() + "\n");
         destruct(userarray[ndx]);
      } else
         write("Safe: " + userarray[ndx]->QRN + "\n");
      ndx += 1;
   }
   write("Ok.\n");
   userarray = 0;
   return 1;
}

/****************************************************************************
 * New_people - Prints out a nicely spaced list of people regardless of     *
 *              tab spacing.                                                *
 ****************************************************************************/

static
new_people() {
   int total_people;
   string who, name, location, temp, ip_address;
   int level, age, counter, spacing, scounter, iidle, invis;
   string slevel, sage, sidle, sinvis;
   write("Name            Level  Age Invis Idle  Location                IP address\n");
   write("------------------------------------------------------------------------------\n");
   who = users();
   counter = 0;
   while (counter < sizeof(who)) {
      name=who[counter]->query_real_name();
      name=capitalize(name);
      if (in_editor(who[counter]))
         name="->" + name;
      while (strlen(name) < 13)
         name+=" ";
      level=who[counter]->query_level();
      if (level < 0) {
         spacing = -(level);
         slevel = "";
      } else {
         spacing=level;
         slevel=" ";
      }
      scounter=0;
      while (spacing > 9) {
         scounter+=1;
         spacing/=10;
      }
      scounter=6-scounter;
      while (scounter > 0) {
         slevel+=" ";
         scounter-=1;
      }
      age = who[counter]->query_age();
      if (age / 43200 > 99)
         sage = "Old!";
      else if (age / 43200 > 9)
         sage = age / 43200 + " D";
      else if (age / 43200 > 0)
         sage = age / 43200 + "  D";
      else if (age / 1800 > 9)
         sage = age / 1800 + " h";
      else if (age / 1800 > 0)
         sage = age / 1800 + "  h";
      else if (age / 30 > 9)
         sage = age / 30 + " m";
      else
         sage = age / 30 + "  m";
      invis = who[counter]->query_invis();
      spacing = invis;
      scounter = 0;
      while (spacing > 9) {
         scounter++;
         spacing /= 10;
      }
      sinvis = "";
      scounter = 3 - scounter;
      while (scounter > 0) {
         sinvis += " ";
         scounter--;
      }
      iidle=query_idle(who[counter]);
      spacing=iidle;
      sidle=" ";
      scounter=0;
      while (spacing > 9) {
         scounter+=1;
         spacing/=10;
      }
      scounter=3-scounter;
      while (scounter > 0) {
         sidle+=" ";
         scounter-=1;
      }
      if (environment(who[counter])) {
         location=file_name(environment(who[counter]));
         if (sscanf(location, "players/%s", temp))
            location = "~" + temp;
         if (sscanf(location, "room/%s", temp))
            location = "#" + temp;
         if (strlen(location) > 23)
            location = "..." + extract(location, strlen(location) - 20,
               strlen(location));
      }
      else
         location="Nowhere";
      while (strlen(location) < 24)
         location = location + " ";
      ip_address = query_ip_number(who[counter]);
      write(name + slevel + level + "  " + sage + sinvis + invis + sidle +
         iidle + "  " + location + ip_address + "\n");
      counter++;
   }
   write("There are now " + sizeof(who) + " players");
   for (counter = 0, total_people = 0; counter < sizeof(who); counter++)
      if (query_idle(who[counter]) >= 300)
         total_people++;
   if (total_people)
      write(" (" + (sizeof(who) - total_people) + " active)");
   write(". " + query_load_average() + "\n");
   return 1;
}

/****************************************************************************
 * Transporter - simple trans function                                      *
 * UPGRADE POSSIBILTY - make an option to tell the player they are being    *
 *    transported                                                           *
 ****************************************************************************/

static
transporter(str) {
   object thing;

   if (str)
      thing = FP(str);
   if (!thing) {
      return 1;
   }
   MO(thing, THIS);
   write("Coming this way!\n");
   return 1;
}   /* end of Transporter */

/****************************************************************************
 * Title - changes a person's title (use with caution on non-wizzes)        *
 ****************************************************************************/

static
title(str) {
   string name,towhat;

   if (sscanf(str, "%s %s", name, towhat) != 2) {
      write("The format for the the ti command is \"ti <name> <title>\".\n");
      return 1;
   }
   if (!FP(name)) {
      write("Not working!\n");
      return 1;
   }
   FP(name)->set_title(towhat);
   write("Their title has been changed.\n");
   return 1;
}   /* end of title */

/****************************************************************************
 * Lwhere - a simple functions which gives the long descrip of the          *
 *          environment of a player as well as the contents thereof         *
 ****************************************************************************/

static
lwhere(who) {
   object owho, env;   /* object to hold target person */
   object current_ob, next_ob;

   if (!who) {
      write("Usage: lwhere <player name>\n");
      return 1;
   }
   owho = FP(who);
   if (!owho)
      owho = FL(who);
   if (!owho) {
      write("No such living creature.\n");
      return 1;
   }
   env = ENV(owho);
   write("Environment of: " + CAP(who) + ".\n");
   if (!env)
      write("Environment = NULL\n");
   else {
      write(file_name(env) + "\n");
      env->long();
      write("Contents of environment:\n");
      current_ob = FI(env);
      while (current_ob) {
         next_ob = next_inventory(current_ob);
         write(file_name(current_ob) + ": " + current_ob->short() + ".\n");
         current_ob = next_ob;
      }
   }
   return 1;
}   /* end of lwhere */

/****************************************************************************
 * Wizzes - searches through the users array and determines the number of   *
 *          people, wizards, normal wizards, senior wizards, elder wizards, *
 *          and gods currently on                                           *
 ****************************************************************************/

static
wizzes() {
   int number;
   string arr;

   arr = PEOPLE;
   number = sizeof(PEOPLE)-1;
   regular = 0;
   senior = 0;
   elder = 0;
   god = 0;
   while (number >= 0) {
      if (arr[number]->query_level() >= EXPLORE)
         if (arr[number]->query_level() < SENIOR)
         regular +=1;
      else if (arr[number]->query_level() < ELDER)
         senior +=1;
      else if (arr[number]->query_level() < GOD)
         elder +=1;
      else
         god += 1;
      number -=1;
   }
   return (regular + senior + elder + god);
}

/****************************************************************************
 * Diaperizing - clones an xverb diaper and moves it to the argument        *
 ****************************************************************************/

static
diaperizing(str) {
   object diaper_target, diaper;

   if (!(diaper_target = FP(str))) {
      write("No player of that name on.\n");
      return 1;
   }
   diaper=CO("players/shadowhawk/objects/mean");
   MO(diaper, diaper_target);
   write(CAP(diaper_target->short()) + " has been diaperized.\n");
   return 1;
}

/****************************************************************************
 * Clone_special - if non-existant, clones Shadowhawk's special items and   *
 *                 his pet                                                  *
 ****************************************************************************/

static
clone_special() {
   object objects;

   if (!present("feather", ME)) {
      objects = CO("players/shadowhawk/closed/toys/test1");
      MO(objects, ME);
   }
   if (!present("change",ME)) {
      objects = CO("players/shadowhawk/closed/toys/change");
      MO(objects, ME);
   }
   if (!present("nightengale",THIS)) {
      objects = CO("players/shadowhawk/closed/pets/night");
      MO(objects, THIS);
   }
   write("Ok.\n");
   return 1;
}

/****************************************************************************
 * Total_inven - shows Shadowhawk's total inventory invis items and all.    *
 *               Also shows useful statistics.                              *
 ****************************************************************************/

static
total_inven() {
   set_query_list();
   next = FI(ME);
   more_inven();
   return 1;
}

/****************************************************************************
 * More_inven - does all the work for Total_inven                           *
 ****************************************************************************/

static
more_inven(arg) {
   int counter, lines;
   object current;

   if (arg) {
      write("Inventory aborted.\n");
      return 1;
   }
   lines = 0;
   current = next;
   while ((current) AND (lines < 20)) {
      next = next_inventory(current);
      write("Item: " + FN(current));
      if (living(current))
         write(" (LIVING)");
      write("\n");
      lines++;
      for (counter = 0; counter < sizeof(query_list); counter++)
         if (CALL(current, query_list[counter])) {
            write(CAP(query_list[counter]) + ": " + CALL(current,
                query_list[counter]) + "\n");
            lines++;
         }
      current = next;
   }
   if (next) {
      write("More inventory");
      input_to("more_inven");
   }
   else
      write("End inventory\n");
   return 1;
}

/****************************************************************************
 * Set_query_list - sets up array of queries for Total_inven                *
 ****************************************************************************/

static
set_query_list() {
   if (!query_list)
      query_list = ({
         "short", "query_name", "query_real_name", "query_npc", "query_ac",
         "query_wc", "class", "query_weight", "query_value", "query_info",
         "realm", "armour_class", "armor_class", "weapon_class",
         "query_worn"});
   return query_list;
}

/***************************************************************************
//  For_all - will cause user to repeat an action for everybody on the    //
//            game.                                                       //
***************************************************************************/

for_all(str) {
  ARRAY object people;
  int index;

  people = users();
  for (index = 0; index < sizeof(people); index++)
    shout(expand_cmd(str, capitalize(people[index]->query_real_name())));
  write("Ok.\n");
  return 1;
}

/***************************************************************************
//  Expand_cmd - used to expand macros.                                   //
***************************************************************************/

expand_cmd(str, name) {
  int index;

  for (index = 0; index < strlen(str) - 1; index ++) {
    if (str[index] == '%') {
      index++;
      if ((str[index] == 'n') OR (str[index] == 'N'))
        str = extract(str, 0, index - 2) + name + extract(str, index + 1, strlen(str));
    /* Might want to add in stuff like time (%t), date (%d), mud (%m), etc. */
    }
  }
  return str;
}

do_file_size(str) {
  write("The filesize of " + str + " is: " + file_size(str) + ".\n");
  return 1;
}


/****************************************************************************
 ****************************************************************************
                   end OF Wizard Toolkit v6.1 FUNCTIONS
 ****************************************************************************
 ****************************************************************************/
