/*
// This bracelet is based on code developed by Magnum@Nirvana
// Nirvana is located at elof.iit.edu 3500.
// Modified by Shadowhawk the NUISANCE (w/ Magnum's permission) to 
// allow several people to communicate.
*/
#pragma strict_types

inherit "obj/treasure";

string query_long();
string user();
void remove_link(int link_num);
void remove_link_object(object gone);
void validify_links();

/* ARRAY */ object *links;

void
reset(int arg) {
  if (arg)
    return;
  set_id("bracelet");
  set_alias("magnum toy");
  set_short("Friendship Bracelet");
  links = ({ this_object() });
}

void
long() {
  write(query_long());
}

string
query_long() {
  string str;
  int index;

  validify_links();
  str = format("A Friendship Bracelet\n" +
	       "This is a Friendship Bracelet that you can send to your " +
	       "friends.  Just type 'send <name>' to send it to someone " +
	       "and 'msg <messages>' to send your friends a message.");
  switch (sizeof(links)) {
  case 1:
    str += "You don't have any friends! :(\n";
    break;
  case 2:
    str += "Your friend is: " + links[1]->user() + ".\n";
    break;
  case 3:
    str += "Your friends are: " + links[1]->user() + " and " +
      links[2]->user() + ".\n";
    break;
  default:
    str += "Your friends are: ";
    for (index = 1; index < sizeof(links) - 1; index++)
      str += links[index]->user() + ", ";
    str = format(str + "and " + links[index]->user() + ".\n");
  }
  return str;
}

void
init() {
  add_action("send", "send");
  add_action("msg", "msg");
}

int
send(string str) {
  object friend, new;
  string filename;
  int temp, index;
  
  if (!str) {
    write("Send to who?\n");
    return 1;
  }
  if (!(friend = find_player(str))) {
    write("Sorry, but that person is not on.\n");
    return 1;
  }
  validify_links();
  sscanf(file_name(this_object()), "%s#%d", filename, temp);
  new = clone_object(filename);
  move_object(new, friend);
  write("You call a friendship messenger boy to send the bracelet to " +
	capitalize(str)+".\n");
  tell_room(environment(friend),
	    "A friendship messenger boy arrives and gives " + capitalize(str)
	    + " a Friendship Bracelet.\n");
  tell_object(friend, "The messenger boy tells you: " + user() +
	      " asked me to give this to you.\n");
  for (index = sizeof(links) - 1; index >= 0; index--) {
    links[index]->add_link(new);
    new->add_link(links[index]);
  }
  return 1;
}

void
add_link(object new) {
  links += ({ new });
}

int
drop() {
  int index;

  write("As you drop the Friendship Bracelet, its vibrant colors\n"+
	"fade until it is gone.  Too bad you have no more friends.\n");
  say("The bracelet vanishes as " + user() + " drops it.\n");
  for (index = 1; index < sizeof(links); index++)
    links[index]->remove_link_object(this_object());
  destruct(this_object());
  return 1;
}

int
msg(string str) {
  int index;

  if (!str) {
    write("Tell what?\n");
    return 1;
  }
  validify_links();
  str = user() + " tells you: " + str + "\n";
  for (index = 1; index < sizeof(links); index++)
    links[index]->relay_msg(str);
  write("Ok.\n");
  return 1;
}

string
user() {
  return capitalize((string) environment(this_object())->query_real_name());
}

object
user_ob() {
  return environment(this_object());
}

int
relay_msg(string msg) {
  tell_object(user_ob(), msg);
  return 1;
}

void
remove_link(int link_num) {
  links = links[0..(link_num - 1)] + links[(link_num + 1)..sizeof(links)];
}

void
remove_link_object(object gone) {
  int index;
  
  for (index = 1; index < sizeof(links); index++)
    if (links[index] == gone) {
      remove_link(index);
      index = sizeof(links);
    }
}

void
validify_links() {
  int index;

  for (index = 1; index < sizeof(links); index++)
    if (!links[index])
      remove_link(index);
}
