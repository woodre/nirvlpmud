inherit "/players/shadowhawk/closed/workroom";

#include "/obj/clean.c"

dumb_func() {
   return;
}
