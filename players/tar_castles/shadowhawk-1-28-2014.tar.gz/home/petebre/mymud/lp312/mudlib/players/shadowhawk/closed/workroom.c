/****************************************************************************
 * Credits:                                                                 *
 *                                                                          *
 * Current shield (TURBO SHIELD) developed and written by Shadowhawk   *
 * Current laser (TURBO LASER) developed and written by Shadowhawk     *
 * Wizard's Toolkit developed and written by Shadowhawk                *
 *                                                                          *
 * Copyright Shadowhawk (Joel York: yorkjoe@elof.iit.edu) 1990, 1991        *
 ****************************************************************************/

/****************************************************************************
 * List of global variables and their uses:                                 *
 *  walk_vis..........indicates if workroom movement is visible             *
 ****************************************************************************/

/****************************************************************************
 * Basic room functions:                                                    *
 *  reset..............initialize variables                                 *
 *  init...............add commands                                         *
 *  long...............write long description of room                       *
 *  short..............returns a short room identifier                      *
 *  id.................allows for id of the room                            *
 *  get................only Shadowhawk can carry it                         *
 *  m?????.............indicates a movement function                        *
 *  help_room..........writes out list of functions for TURBO SHIELD,       *
 *                     TURBO LASER, and Wizard's Toolkit                    *
 *  move_room..........function that allow for movement of workroom         *
 *  walk_invis.........sets workroom movement visibility (static)           *
 ****************************************************************************
 * Functions used here, but defined elsewhere are no longer listed due to   *
 *    problems with keeping list current.                                   *
 ****************************************************************************/

#include "../include.h"
#include <security.h>
#include "laser.c"
#include "shield.c"
#include "toys/toolkit.c"

REALM_WORK

int walk_vis;

/****************************************************************************
 ****************************************************************************
                         BEGIN BASIC ROOM FUNCTIONS
 ****************************************************************************
 ****************************************************************************/


/****************************************************************************
 * Reset - initializes variables at room creation                           *
 ****************************************************************************/

reset(arg) {
   if (arg)
      return 1;
   shield = 0;             /* Default to shield off */
   set_light(1);           /* Default to light on */
   Invite = 0;             /* Default to no invitees */
   nInvite = 0;
   alarm = 1;              /* Default to alarm on */
   Iinvis = 1;             /* Default TURBO SHIELD to visible invitation */
   damage = MAXINT;        /* Default to maximum damage */
   laser_invis = 1;        /* Default TURBO LASER to visible radiation */
   target = 0;             /* Default to no default target (syntax error?) */
   walk_vis = 1;           /* Default to visible movement */
   enable_commands();      /* Make workroom living */
   set_living_name("workroom");
}

/****************************************************************************
 * Init - adds all actions for exits (for Shadowhawk or others when the     *
 *        shield state is less than 2)                                      *
 *        adds all of Shadowhawk's special functions                        *
 ****************************************************************************/

init() {
   if (((shield < 2) || ME->QRN) && (ENV(ME) == THIS)) {
      AA("mpost","post");
      AA("mboard","board");
      AA("mbird","bird");
      AA("mgiant","giant");
      AA("mchurch","church");
   }
   if (ME->QRN == MASTER) {
      AA("setshield", "shield");
      AA("invite", "invite");
      AA("invitees", "invitees");
      AA("state", "state");
      AA("butler", "butler");
      AA("help_room","whelp");
      AA("uninvite","uninvite");
      AA("clear","clear");
      AA("alarm","alarm");
      AA("set_damage","damage");
      AA("fire_laser","laser");
      AA("set_laser_invis","radiate");
      AA("set_laser_target","target");
      AA("move_room", "walk");
      AA("walk_invis", "winvis");
      AA("peer", "ENV");
      return;
   }
   init_toolkit();
   _init_shield();
}

/****************************************************************************
 * Long - long descrip of workroom                                          *
 *        Two different descrips exist...one for Shadowhawk and one for     *
 *        others. When viewer is Shadowhawk, wizzes is called and results   *
 *        displayed.  For guests, exits only listed if shield state is less *
 *        than 2                                                            *
 ****************************************************************************/

QLONG() {
   string descrip;

   descrip = "\n\n\n\n";
   if (ME->QRN == MASTER) {
      descrip += "The game readouts show the following:\n\n";
      descrip += "  TURBO SHIELD state.........." + shield +
         "   You have invited........" + nInvite + " people.\n";
      if (alarm)
         descrip += "  TURBO SHIELD Alarm state....on  ";
      else
         descrip += "  TURBO SHIELD Alarm state....off ";
      descrip += "TURBO LASER damage......" + damage + "\n";
      if (laser_invis)
         descrip += "  TURBO LASER radiation is........visible\n";
      else
         descrip += "  TURBO LASER radiation is........invisible\n";
      descrip += "     The current default TURBO LASER target is: ";
      if (!target)
         descrip += "NULL\n";
      else if (target->QRN)
         descrip += target->QRN + "\n";
      else
         descrip += target->short() + "\n";
      descrip += "  The invitation butler is ";
      if (!Iinvis)
         descrip += "off";
      else
         descrip += "on";
      descrip += " duty.\n\n";
      if (sizeof(PEOPLE) != 1) {
         descrip += "  There are currently " + sizeof(PEOPLE) +
            " people logged on, " + wizzes() + " of whom are wizard(s).\n";
         if (regular == 1)
            descrip += "  There is 1 regular wizard on.     ";
         else
            descrip += "  There are " + regular + " regular wizards on.   ";
         if (senior == 1)
            descrip += "There is 1 senior wizard on.\n";
         else
            descrip += "There are " + senior + " senior wizards on.\n";
         if (elder == 1)
            descrip += "  There is 1 elder wizard on.       ";
         else
            descrip += "  There are " + elder + " elder wizards on.     ";
         if (god == 1)
            descrip += "There is 1 god on.\n";
         else
            descrip += "There are " + god + " gods on.\n";
      } else
         descrip += "  You are the only person on the game.\n";
      descrip += "\nExits: post, board, church, bird, giant.\n";
      descrip += "      Typing \"whelp\" calls up help list.\n";
      descrip += "\n\n\n\n";
   } else {
      descrip += "\nYou have entered " + CAP_MASTER + "'s workroom.  For " +
         "some strange reason you feel that you do not have the time to " +
         "take a long look around the room.  " +
         "For now, it is sufficient to note that the entire room is " +
         "covered in computer screens, readouts, and keyboards.  One " +
         "wall is a bookshelf holding many computer reference books.  " +
         "Three blank screens on the east wall give you pause as you " +
         "note the label \"TURBO LASER v1.1 Viewports\" beneath them.  ";
      if (present(MASTER)) {
         descrip += "Shadowhawk is sitting in a chair in front of a video " +
            "screen flickering through different views of various parts " +
            "of the mud.  As one showing you standing right behind him " +
            "flickers onto the screen, he turns around and greets you. ";
      } else {
         descrip += "Shadowhawk is not here right now.\n";
         if (invited(ME->QRN))
            descrip += "He'll probably be back any time.";
         else
            descrip += "Are you sure you should be here?";
      }
      if (shield < 2)
         descrip += "\n\nCurrent exits are: Church, post, board, giant and bird.";
      descrip += "\n\n\n\n\n";
   }
  return format(descrip);
}


/****************************************************************************
 * Short - what those fools with brief mode see when they come in           *
 ****************************************************************************/

QSHORT() {
   return "Shadowhawk's magnificient workroom";
}


/****************************************************************************
 * Realm - indicates that this workroom is a wizard room                    *
 ****************************************************************************/

/****************************************************************************
 * Help_room - lists functions made available to shadowhawk by add_actions  *
 ****************************************************************************/

static
help_room() {
   write("The functions available to the master of this place are:\n");
   write("   Whelp............................calls up this help screen.\n");
   write("   Walk <where>.....................makes workroom move to <where>.\n");
   write("   Winvis <invis>...................sets workroom walking visibilty.\n");
   write("   Shield #.........................to activate shield to state #.\n");
   write("   Invite <invis> <name>............to invite <name> <invis> to workroom.\n");
   write("   Univite <name>...................to uninvite and possibly remove <name>.\n");
   write("   Invitees.........................list people who are invited.\n");
   write("   State............................check status of shields.\n");
   write("   Damage <amount>..................set amount of damage done by laser cannons.\n");
   write("   Radiate <invis>..................sets invis setting for Laser Cannon.\n");
   write("   Laser <name>.....................fires laser cannon <invis> at <name>.\n");
   write("   Target <name>....................specifies <name> as default laser target.\n");
   write("      <invis>=1 for audible actions <invis>=0 for silent actions\n");
   write("      Additional functions (from toolkit) listed with command 911\n");
   return 1;
}

/****************************************************************************
 * Id - Identifies the object.                                              *
 ****************************************************************************/

id(str) {
   if (ME->QRN == MASTER)
      return (str == "workroom");
   return 0;
}

/****************************************************************************
 * Get - Determines if an object can be picked up.                          *
 ****************************************************************************/

get() {
   if (ME->QRN != MASTER)
      return 0;
   return 1;
}

/******************   BEGIN PEOPLE MOVEMENT FUNCTIONS   *********************/

static
mpost() {
   ME->MP("post office#room/post");
   return 1;
}

static
mboard() {
   ME->MP("inner guild#room/adv_inner");
   return 1;
}

static
mchurch() {
   ME->MP("church#room/church");
   return 1;
}

static
mgiant() {
   ME->MP("Shadowhawk's realm#" + CASTLE_DEST);
   return 1;
}

/*******************   END PEOPLE MOVEMENT FUNCTIONS   **********************/

/****************************************************************************
 * Move_player - allows movement compatible with players move_player        *
 ****************************************************************************/

move_player(dir_dest) {
   string dir, dest;

   if (!dir_dest || (sscanf(dir_dest, "%s#%s", dir, dest) != 2)) {
      write("Error!  Function was move_player in " + FN(THIS) + ".\n");
      write("Arg was: " + dir_dest + ".\n");
      return 0;
   }
   move_room(dest);
   return 1;
}

/****************************************************************************
 * Move_room - Function that handles workroom movement. (rad, eh?)          *
 ****************************************************************************/

static move_room(dest) {
   string temp;
   object current_ob, next_ob;

   if (sscanf(dest, "#%s", temp) == 1)
      dest = "room/" + temp;
   else if (sscanf(dest, "~%s", temp) == 1)
      dest = "players/" + temp;
   if (walk_vis)
      say("Shadowhawk's workroom grows wings and flies off.\n");
   TR(THIS, "The workroom grows its wings...and takes off!\n");
   MO(THIS, dest);
   if (walk_vis)
      say("Shadowhawk's workroom flies in.\n" +
         "The wings fold up and disappear, camaflauged by the exterior walls.\n");
   if (ENV(THIS)) {
      TR(THIS, "You have landed in " + FN(ENV(THIS)) + ".\n");
      TR(THIS, "You see through the exterior viewport:\n");
      ENV(THIS)->long();
      current_ob = FI(ENV(THIS));
      while (current_ob) {
         next_ob = next_inventory(current_ob);
         TR(THIS, FN(current_ob) + ": " + current_ob->short() + ".\n");
         current_ob = next_ob;
      }

   } else
      write("The exterior viewport shows static.\n");
   return 1;
}

/****************************************************************************
 * Walk_invis - Sets workroom walking visibilty.                            *
 ****************************************************************************/

static
walk_invis(arg) {
   int movement_invis;

   if (!arg || (sscanf(arg, "%d", movement_invis) != 1)) {
      write("The proper format for winvis is \"winvis <invis>\", where " +
         "<invis> is 1 for\nvisible walking, and 0 otherwise.\n");
      return 1;
   }
   if (movement_invis > 1)
      movement_invis = 1;
   walk_vis = movement_invis;
   write("The workroom movement is ");
   if (walk_vis)
      write("visible.\n");
   else
      write("invisible.\n");
   write("Ok.\n");
   return 1;
}

static
peer() {
   object current, next;
   if (ENV(THIS)) {
      write("The viewscreens show:\n");
      write("The environment is: " + FN(ENV(THIS)) + ".\n");
      ENV(THIS)->long();
      current = FI(ENV(THIS));
      while (current) {
         next = next_inventory(current);
         write(FN(current) + current->short() + ".\n");
         current = next;
      }
   } else
      write("The viewscreens show static.\n");
   return 1;
}


/****************************************************************************
 ****************************************************************************
                        END OF BASIC ROOM FUCNTIONS
 ****************************************************************************
 ****************************************************************************/
