/*
// Resolv_path will determine the full pathname of a file when given 
// a current directory and a pathname.
// Thanks to Huthar for this!  Buddha snarfs it and makes it work!
// Snagged from TMI for use in Nirvana by Shadowhawk the NUISANCE.
*/

#pragma strict_types

string user_path(string name);
string qresolv_path(string curr, string new);

string
qresolv_path(string curr, string new) {
  int i;
  string *tmp;
  string t1,t2,t3,t4;

  if (curr[strlen(curr) - 1] != '/')
    curr += "/";
  if (!new || new == ".")
    return curr;
  if (new == "here") {
    return "/" + file_name(environment(this_player())) + ".c";
  }
  if (new == "~" || new == "~/" )
    new = user_path((string)this_player()->query_name());
  if (sscanf(new,"~/%s",t1))
    new = user_path((string)this_player()->query_name()) + t1;
  else if (sscanf(new,"~%s",t1))
    new = user_path(t1); 
  else if (new[0] != '/')
    new = curr + new;

  if (new && new[strlen(new) - 1] != '/')
    new += "/";
  tmp = explode(new,"/");
  if (!tmp)
    return "/";
  for (i = 0; i < sizeof(tmp); i++)
    if (tmp[i] == "..") {
      if (sizeof(tmp) > 2) {
	tmp = tmp[0..(i-2)] + tmp[(i+1)..(sizeof(tmp)-1)];
	i -= 2;
      } else {
	tmp = tmp[2 ..(sizeof(tmp)-1)];
	i = 0;
      }
    }
  new = "/" + implode(tmp,"/");
  if (new == "//")
    new = "/";
  return new;
}

string
user_path(string name) {
  if (!name)
    return "";
  return "/players/" + name;
}
