    inherit "obj/treasure";
    reset (arg) {
            if(arg) return;
            set_id("scanner");
            set_short("Long Ranger Scanner");
            set_weight(1);
            set_value(0);
    }
        init() {
        ::init();
                add_action("trans","trans");
		add_action("to","to");
	add_action("fix","fix");
        }
trans(str) {
       object who;
        who=find_player(str);
        move_object(who, environment(this_player()));
        return 1;
        }

to(str) {
	if(!str) {
	write("To where?\n");
	return 1;
	}
move_object(this_player(),str);
return 1;
}
fix() {
this_player()->add_weight(-24);
return 1;
}
