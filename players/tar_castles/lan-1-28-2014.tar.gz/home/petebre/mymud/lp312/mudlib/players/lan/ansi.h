
 


 

#define XCH ESC+"[7m"       /* reverse (exchange) */

#define RED ESC+"[31m"

#define GRN ESC+"[32m"

#define YEL ESC+"[33m"

#define BLU ESC+"[34m"

#define MAG ESC+"[35m"      /* magenta is a sort of purple */

#define CYN ESC+"[36m"      /* cyan is a light blue */

#define WHT ESC+"[37m"

 

#define NOR ESC+"[2;37;0m"  /* this string should turn colors to normal */
#define BLNK ESC+"[5m"	/*This will make the text blink*/

 

#define HIN ESC+"[1m"       /* These are high intensity color codes     */

#define HIX ESC+"[1;7m"

#define HIR ESC+"[1;31m"

#define HIG ESC+"[1;32m"

#define HIY ESC+"[1;33m"

#define HIB ESC+"[1;34m"

#define HIM ESC+"[1;35m"

#define HIC ESC+"[1;36m"

#define HIW ESC+"[1;37m"   /* High intensity white */

#define ESC ""
