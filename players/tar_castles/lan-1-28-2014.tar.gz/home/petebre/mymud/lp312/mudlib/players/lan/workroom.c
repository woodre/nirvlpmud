inherit "room/room";
reset(arg) {
if(!arg) {
set_light(1);
short_desc="Heh";
long_desc="Heh....*boggle*......grin\n";
dest_dir = ({
	"/room/church.c","church",
	"/room/post.c","post",
	"/room/adv_inner.c","inner",
});
}
}
