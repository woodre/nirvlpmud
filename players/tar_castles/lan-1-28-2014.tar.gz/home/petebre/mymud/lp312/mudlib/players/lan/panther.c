inherit"obj/monster";

object owner;
object fight;
reset(arg) {
::reset(arg);
if (arg) return;
set_name("panther");
set_short("Black Panther");
set_long(
"You see before you a sleek black panther.  It watches everything in the\n"
+"room with wary eyes.  It stops briefly to look at you and turns away\n"
+"realizing that you are not a threat.  You think it may be right.\n");
set_hp(200);
set_ac(15);
set_wc(25);
set_heart_beat(1);
}
        init() {
::init();
                add_action("pet","pet");
        }
pet(str) {
        if(!str) {
                write("Pet what?\n");
                return 1;
        }
if(str =="panther") {
        if(this_player() != owner) {
say("The cat swipes at "+this_player()->query_name()+".\n");
this_player()->reduce_hit_point(random(10));
return 1;
}
say(this_player()->query_name()+" pets the panther.\n");
say("The panther purrs and starts rubbing against "+owner->query_name()+".\n");
return 1;
}
return 0;
}
set_owner(str) {
owner=str;
}
  heart_beat() {
if(owner->query_ghost()) {
        tell_object(owner, 
"Due to your death the panther is released from its service and melts\n"
+"away.\n");
destruct(this_object());
return 1;
}
    if(environment(this_object()) != environment(owner)) {
   say("The panther leaves in search of its master.\n");
   move_object(this_object(), environment(owner));
   say("The panther pads into the room.\n");
}
if(owner->query_attack()) {
object target;
target=owner->query_attacker_ob();
if(target == query_attacker_ob()) return;
say("The panther leaps at its masters foe.\n");
attack_object(target);
return 1;
}
}
