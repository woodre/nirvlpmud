    inherit "obj/treasure";
#include "/players/lan/ansi.h"
    reset (arg) {
            if(arg) return;
            set_id("tester");
            set_short("Ansi Tester");
	set_long("To test whether or not you have ansi type ansi on or ansi off");
            set_weight(1);
            set_value(0);
    }
        init() {
        ::init();
add_action("ansi","ansi");
        }
ansi(str) {
	if(!str) {
write("Please type ansi on to test for ansi.\n");
	return 1;
}
if(str== "on") {

write("This is a brief to test to see whether or not you have ansi\n"+
"capabilities.  If the test below is blinking then you have ansi.\n");
write(
BLNK+"Blinking test"+NOR+".\n");
return 1;
}
write("For now the only argument for ansi is on.\n");
return 1;
}
