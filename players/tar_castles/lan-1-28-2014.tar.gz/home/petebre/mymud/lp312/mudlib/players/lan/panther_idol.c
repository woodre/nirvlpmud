    inherit "obj/treasure";
    reset (arg) {
            if(arg) return;
            set_id("figurine");
set_short("Figurine of a Panther");
            set_weight(1);
            set_value(4000);
set_long(
"This is a figurine portraying a snarling black panther.  It is\n"
+"rumored that with these magical figurines you can summon the\n"
+"figure portrayed.\n");
        }
init() {
        ::init();
        add_action("summon","summon");
        }
summon() {
object pet;
        if(this_player()->query_ghost()) {
write("As a ghost you can't summon the panther.\n");
        return 1;
                }
write(
"You press your forehead against the figurine.  You start to\n"
+"concentrate and are suddenly startled by a loud snarl by your feet\n");
say(this_player()->query_name()+
" presses his head against a figurine and mumbles some words.\n");
pet = clone_object("/players/lan/panther.c");
pet->set_owner(this_player());
move_object(pet, environment(this_player()));
say("A sleek black panther starts to materialize in front of you.\n");
destruct(this_object());
return 1;

}
