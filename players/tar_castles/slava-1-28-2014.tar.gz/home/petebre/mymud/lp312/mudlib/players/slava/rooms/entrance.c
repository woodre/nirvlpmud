inherit "room/room";
object ob;
reset(arg) {
    dest_dir = ({"room/plane6", "exit",
                 "players/slava/rooms/hall2.c","east",
                 "players/slava/rooms/hall1.c","west"});
    short_desc = "Enter of the realy Nirvana's world.";
    set_light (1);
    long_desc = "You are standing in the castle of great wizard Slava.\nIt's the entrance of mistery world of Nirvana.\n";
}
