inherit "room/room";
object ob;
reset(arg) {
         dest_dir = ({"players/slava/rooms/entrance.c", "east",
                  "players/slava/rooms/hall3.c", "west"});


set_light (1);
    long_desc = "Oops you falling down, and first that you can see it's many portraits of Trix and Hurtbrain all over the walls.\n";
}
