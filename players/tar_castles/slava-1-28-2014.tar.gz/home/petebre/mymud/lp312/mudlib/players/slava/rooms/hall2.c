inherit "room/room";
object ob;
reset(arg) {
   dest_dir = ({"players/slava/rooms/entrance.c", "west"});
    short_desc = "2 -nd hall in Undeads castle.";
set_light (1);
     long_desc = "In this room you hearing only screams of Undeads that have been demoted by Beren to the first guild level.They all on their kneels asking Beren to change his mind, but he just says 'Get out, get out...'.\n";
}
