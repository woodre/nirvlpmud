inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {

object gold;
  gold = clone_object("obj/money");
  gold->set_money(random(2000) + 100);
  move_object(gold,this_object());

     set_name("doch");
     set_short("A poor doch");
     set_race( "human");
     set_alias("human");
     set_long("You don't believe ... it's realy him.\n");
     set_level(20);
     set_ac(60 + random(10));
     set_wc(15 + random(3));
     set_hp(1000 + random(20));
     set_al(-500);
     set_aggressive(0);
     set_chat_chance(7);
     set_a_chat_chance(7);
     load_chat("Please don't fuck me.\n");
        load_chat("Doch tell you: get out.\n");
     load_a_chat("Don't fight me please!!!\n");
     load_a_chat("I said you fuck off.\n");
   }
}
