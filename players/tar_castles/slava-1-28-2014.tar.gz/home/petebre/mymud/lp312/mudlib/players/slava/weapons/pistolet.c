/*
 * It's not a good idea to leave untraceable WC 100 weapons in your dir.
 *
 * mizan
 */
inherit "obj/weapon.c";
reset (arg)  {
::reset (arg);
if (arg) return;

set_name ("pistolet");
set_alias ("slava's pistolet");
set_short ("Slava's pistolet");
set_long ("Really GREAT weapon.\nIf anybody found it please return to owner\n");
set_class (100);
set_weight (3);
set_value (650);
}
