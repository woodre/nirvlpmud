inherit "room/room";
reset(arg) {
    if(arg) return;
    set_light(1);
        long_desc = "This is the workroom of Slava.\nAnd you can see many 'Cure' tape all over the room.\nMaybe that room the room of 'Cure' fan?\n";
   short_desc = "'Cure' fan's club";
    dest_dir = ({ "/room/church", "church"});
}
