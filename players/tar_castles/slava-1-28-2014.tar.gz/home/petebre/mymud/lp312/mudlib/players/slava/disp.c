/*
 * try not to make items that hand out money to 'anyone'???
 *
 * mizan
 */
id(str) { return str=="dispenser"; }

reset () {}
short() {
        return "A money dispenser";
}
long() {
write("You can receive money from this dispenser.\n");
}
init() {
        add_action("receive","receive");
}
receive(str) {
        if(str!="money")
        return 0;
         this_player()->add_money(2500);
        say(capitalize(this_player()->query_real_name())+" takes money from dispenser.\n");
       write("You received money from dispenser");
	return 1;
       }
get() { return 0; }
