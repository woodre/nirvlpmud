inherit "room/room";
object ob;
reset(arg) {
         dest_dir = ({"players/slava/rooms/hall1.c", "east"});
         short_desc = "3 -st hall in Undeads castle.";
set_light (1);
     long_desc = "It's lonely and forgoten wizard Dochent.Many years ago he solved all the quests in 16 hours.And after he became wizard he never logged in.\nWho knows, maybe he has another character?\n";
}
