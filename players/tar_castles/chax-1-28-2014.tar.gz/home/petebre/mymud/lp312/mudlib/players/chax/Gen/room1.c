/* Looks like my first attempt at room making.-Chax */

inherit "room/room";

reset(arg){

/*  Connected to the reset(arg) above, don't mess with it just yet.  
    NOT sure how this ties in quite yet-CHAX */

  if (arg) {
    /* Put anything in here that you only do when room is reset */
    return;
  }

  set_light(1);
  short_desc="A plain white room.";
  long_desc=
  "You awaken on a simple cot in a brightly lit room.  It must\n" +
  "be a hospital room from the sterile feel and the antibacterial\n" +
  "scent. As your mind clears and eyes focus, you see a door to \n" +
  "the east.\n";

  items=({
    "cot", "A simple cot with a wool blanket",
    "door", "It is unlocked and slightly ajar. The window is clear\n" +  
		"and   has lettering on it",
    "window", "The window is labeled UGE Ward",
  });

  dest_dir=({
   "/players/chax/Gen/room2.c","east",
  });
}
           
      
room_smell(str) {
  write("The strong scent of antibacterial cleaner is the only smell.\n");
  return 1;
}

room_listen(str) {
  write("A faint electrical buzz is all you hear.\n");
  return 1;
}           
           
room_search(str) {
	write("You'd hate to get sick so you decide not to search.\n");
    return 1;       
}
                
init()  {
 ::init();
  add_action("room_smell","smell");
  add_action("room_listen","listen");
  add_action("room_search","search");
}           
        
