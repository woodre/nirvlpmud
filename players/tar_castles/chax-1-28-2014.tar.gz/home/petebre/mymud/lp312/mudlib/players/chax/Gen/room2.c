/* Looks like my 2nd attempt at room making.-Chax */

inherit "room/room";

reset(arg){

/*  Connected to the reset(arg) above, don't mess with it just yet.  
    NOT sure how this ties in quite yet-CHAX */

  if (arg) {
    return;
  }

  set_light(1);
  short_desc="A corridor.";
  long_desc=
 "The tiled floor is clean and the room is well lit.  The white walls\n" +
 "have seen better days but are still clean.  Posters on the wall are\n" +
 "the only decoration.  You can tell patient rooms are to the north\n" +
 "and south by the little room number signs.\n";
 
  items=({
  "floor", "The tiles are a marble linoleum",
  "walls", "The walls are white but skuffs and small scrapes do show",
  "sign", "These label state patients room and the number",
  "number", "The north is #1119 and the south is #1120-1122",
  "numbers", "The north is #1119 and the south is #1120-1122",
  "poster", "Try looking at 'posters'",
  "posters", "These are motivational posters telling the staff they are the best",       
     });

dest_dir=({
 "/players/chax/Gen/room3.c","north",
 "/players/chax/Gen/room4.c","south",
 "/players/chax/Gen/room5.c","east",
 "/players/chax/Gen/room1.c","west",
           });
        
}
