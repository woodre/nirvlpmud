inherit "/obj/monster";

reset(arg) {
  object dress;

  ::reset(arg);

  if(arg) return;
  set_name("stickwoman");
  set_alias("woman");
  set_short("A poorly drawn stickwoman");
  set_long(
"                _\n" +
"               / \\      This strange drawing vaguely resembles\n" +
"              |^_^|     a stick figure of a woman, although\n" +
"               \\_/      the shape of the head screams alien.\n" +
"              _____     \n" +
"             /\\   /\\    \n" +
"            /  \\ /  \\   \n" +
"           /   / \\   \\  \n" +
"              /   \\     \n" +
"             /_____\\    \n" +
"              |   |     \n" +
"              |   |     \n" +
"              |   |     \n"
  );
  set_gender("female");
  set_race("human");
  set_level(6);
  set_wc(10);
  set_ac(5);
  set_hp(90);
  set_al(0);
  set_chat_chance(1);
  load_chat("The stickwoman waves.\n");
  load_chat("The stickwoman smiles at you.\n");

  dress = clone_object("/obj/armor");
  dress->set_id("dress");
  dress->set_type("armor");
  dress->set_alias("stickdress");
  dress->set_short("Stick dress");
  dress->set_value(250);
  dress->set_weight(2);
  dress->set_ac(2);
  dress->set_long(
"  _____     A stickwoman's dress. It is\n" +
" /\\   /\\    nothing special.\n" +
"/  \\ /  \\   \n" +
"   / \\      \n" +
"  /   \\     \n" +
" /_____\\    \n" 
  );

  move_object(dress,environment(ob));

}
