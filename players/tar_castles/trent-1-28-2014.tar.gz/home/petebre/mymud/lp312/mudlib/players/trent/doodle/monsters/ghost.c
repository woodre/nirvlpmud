#include "/obj/ansi.h"

inherit "/obj/monster";

string ghostColor;
string ghostName;
string scared;

reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("ghost");

  choose_ghost(0);

  set_race("ghost");
  set_level(7);
  set_hp(125);
  set_al(-250);
  set_chat_chance(10);
  set_a_chat_chance(10);
  set_dead_ob(this_object()); /* Specifies what object the monster_died function is in. */
}

monster_died(ob) {
  object corpse;

  /* assume (hope) that this dests the correct corpse */
    corpse = present("corpse",environment(this_object()));
    destruct(corpse);  

  corpse = clone_object("/players/trent/doodle/obj/deadghost.c");
  move_object(corpse,environment(ob));
}

choose_ghost(ghostNum) {
  int intGhostNum;

  intGhostNum = ghostNum;
  if (intGhostNum < 0 || intGhostNum > 3)
    intGhostNum = 0;

  switch(intGhostNum) {
   case 0:
    ghostName = "blinky";
    ghostColor = HIR;
    break;
   case 1:
    ghostName = "inky";
    ghostColor = HIC;
    break;
   case 2:
    ghostName = "pinky";
    ghostColor = HIM;
    break;
   case 3:
    ghostName = "clyde";
    ghostColor = YEL;
    break;
  }

  set_alias(ghostName);
  unscared();

  chat_str = 0;
  chat_nr = 0;
  a_chat_str = 0;
  a_chat_nr = 0;
  
  load_chat(ghostColor + capitalize(ghostName) + NORM + " floats around.\n");
  load_chat(ghostColor + capitalize(ghostName) + NORM + " menaces you.\n");

  load_a_chat(ghostColor + capitalize(ghostName) + NORM + " floats through you. Ouch!\n");
}

unscared() {
  set_wc(9);
  set_ac(6);

  set_short(ghostColor + capitalize(ghostName) + NORM + " the ghost");
  set_long(
ghostColor + "  ____   " + NORM + "This looks vaguely like " + capitalize(ghostName) + ",\n" +
ghostColor + " /    \\  " + NORM + "one of the Pac-Man ghosts.\n" +
ghostColor + "| @ @  | \n" + NORM +
ghostColor + "|      | \n" + NORM +
ghostColor + "|      | \n" + NORM +
ghostColor + "|/\\/\\/\\| \n" + NORM
  );

  scared = 0;
  say(ghostColor + capitalize(ghostName) + NORM + " recovers from its fear\n");
}

scared() {
  set_wc(7);
  set_ac(3);

  set_short(HIB + capitalize(ghostName) + NORM + " the ghost");
  set_long(
HIB + "  ____   " + NORM + "This looks vaguely like " + capitalize(ghostName) + ",\n" +
HIB + " /    \\  " + NORM + "one of the Pac-Man ghosts.\n" +
HIB + "| @ @  | " + ghostColor + capitalize(ghostName) + NORM + " is obviously scared.\n" +
HIB + "|      | \n" + NORM +
HIB + "|      | \n" + NORM +
HIB + "|/\\/\\/\\| \n" + NORM
  );

  scared = 1;
  say(ghostColor + capitalize(ghostName) + NORM + " gets " + HIB + "scared" + NORM + ".\n");
}


heart_beat() {
  int x;
  int nscared;

  ::heart_beat();

  x = random(10);
  if (!scared)
    if (x > 7)
      nscared = 1; /* 20% chance of becoming scared */
    else
      nscared = 0;
  if (scared)
    if (x > 5)
      nscared = 0; /* 60% chance of staying scared */
    else
      nscared = 1;

  if (scared && !nscared) {
    unscared();    
  } else if (!scared &&  nscared) {
    scared();
  }
}
