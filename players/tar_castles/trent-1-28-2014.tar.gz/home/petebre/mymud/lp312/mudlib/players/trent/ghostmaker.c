inherit "/obj/treasure.c";

reset(arg) {
  set_id("maker");
  set_short("ghost maker");

}

init(art) {
  add_action("make_ghosts", "makeghosts");

}

make_ghosts() {
  object ghost;
  ghost = clone_object("/players/trent/doodle/monsters/ghost.c");
  ghost->choose_ghost(0);
  move_object(ghost, environment(this_player()));
  ghost = clone_object("/players/trent/doodle/monsters/ghost.c");
  ghost->choose_ghost(1);
  move_object(ghost, environment(this_player()));
  ghost = clone_object("/players/trent/doodle/monsters/ghost.c");
  ghost->choose_ghost(2);
  move_object(ghost, environment(this_player()));
  ghost = clone_object("/players/trent/doodle/monsters/ghost.c");
  ghost->choose_ghost(3);
  move_object(ghost, environment(this_player()));
}
