#include "/obj/ansi.h"

inherit "/obj/monster";

int happy;

reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("face");

  set_happy();
  set_gender("male");
  set_race("human");
  set_level(6 + random(3));
  set_wc(8 + random(3));
  set_ac(4 + random(3));
  set_hp(80 + random(30));
  set_al(0);
  set_chat_chance(2);
  set_a_chat_chance(10);
  load_chat("The face hovers around.\n");
  load_chat("The face looks straight at you.\n");
  load_a_chat("The face scowls at you.\n");
  set_dead_ob(this_object()); /* Specifies what object the monster_died function is in. */

  happy = 1;
}

monster_died(ob) {
  object shield, corpse;

  /* assume (hope) that this dests the correct corpse */
  corpse = present("corpse",environment(this_object()));
  destruct(corpse);  

  shield = clone_object("/players/trent/doodle/obj/deadface");

  move_object(shield,environment(ob));

}

heart_beat() {
  ::heart_beat(); /* This calls the heart_beat in monster.c to handle attacks. */
  if(attacker_ob && happy) {
      set_angry();
  } else if (!attacker_ob && !happy) {
      set_happy();
  }
}

set_happy() {
  set_long(
YEL + "       |||||||||||   " + NORM + "    This is yet another crude drawing.\n" +
"      /           \\      This guy is just a face floating in\n" +
"     / ___     ___ \\     midair.  He does seem to be in a good\n" +
"    / (_0_)   (_0_) \\    mood at least.\n" +
"   |                 |   \n" +
"    \\       V       /    \n" +
"     \\   \\_____/   /     \n" +
"      \\           /      \n" +
"       \\_________/       \n"
  );

  set_short("A poorly drawn face (happy)");
  happy = 1;
}

set_angry() {
  set_long(
YEL + "       |||||||||||   " + NORM + "    This is yet another crude drawing.\n" +
"      /           \\      This guy is just a face floating in.\n" +
"     / ___     ___ \\     midair.  He seems to be upset.  Why\n" +
"    / (_0_)   (_0_) \\    would anybody want to attack him?\n" +
"   |                 |   \n" +
"    \\       V       /    \n" +
"     \\    _____    /     \n" +
"      \\  /     \\  /      \n" +
"       \\_________/       \n"
  );

  set_short("A poorly drawn face (angry)");
  happy = 0;

}