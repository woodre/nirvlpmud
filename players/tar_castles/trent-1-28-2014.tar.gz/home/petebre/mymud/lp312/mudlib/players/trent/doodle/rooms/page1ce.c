inherit "/room/room.c";

reset(arg) {
  object monster;

  if (arg) return;
  set_light(1);

  short_desc="Edge of page 1";
  long_desc=
"This is yet another area of the first page. You can still\n" +
"see the room you left behind to the east.  The page stretches\n"+
"away from you in all other directions.\n";

  items=({
    "paper","It's ruled yellow paper",
    "page","It's ruled yellow paper",
    "ground","It's ruled yellow paper",
    "room", "It is filled with huge objects. You can 'jump' back to it."
  });
  dest_dir=({
    "/players/trent/doodle/rooms/page1ne.c", "north",
    "/players/trent/doodle/rooms/page1nw.c", "northwest",
    "/players/trent/doodle/rooms/page1cw.c", "west",
    "/players/trent/doodle/rooms/page1sw.c", "southwest",
    "/players/trent/doodle/rooms/page1se.c", "south"
  });
/*  if(!present("stickman")) {
    monster=clone_object("/players/trent/doodle/monsters/stickman.c");
    move_object(monster,this_object());
  }
*/
}

init() {
  ::init();
  add_action("page","page");
  add_action("jump","jump");
}

page() {
  move_object(this_player(), "/players/trent/doodle/rooms/page2ce.c");
  write("You turn the page and crawl under it.\n");
  say(this_player()->query_name() + " crawls under the page.\n");
  command("look", this_player());

  return 1;
}

jump() {
  move_object(this_player(), "/players/trent/house/rooms/livingroom.c");
  write("You see yourself grow back to your original size as you leap from the page.\n");
  say(this_player()->query_name() + " leaps from the page and becomes enormous!\n");
  command("look", this_player());

  return 1;
}

