inherit "/room/room.c";

reset(arg) {
  object monster;

  if (arg) return;
  set_light(1);

  short_desc="Corner of page 2";
  long_desc=
"You stand at the corner of the second page.  Somehow, you are able\n"+
"to stand below the page above without hitting your head.  The pages\n"+
"stretch above and below you the the south and east.  You can\n"+
"climb 'back' to the page above, or you can turn to the next 'page'.\n";

  items=({
    "paper","It's ruled yellow paper",
    "page","It's ruled yellow paper",
    "ground","It's ruled yellow paper"
  });
  dest_dir=({
    "/players/trent/doodle/rooms/page2ne.c", "east",
    "/players/trent/doodle/rooms/page2ce.c", "southeast",
    "/players/trent/doodle/rooms/page2cw.c", "south"
  });
/*  if(!present("stickman")) {
    monster=clone_object("/players/trent/doodle/monsters/stickman.c");
    move_object(monster,this_object());
  }
*/
}

init() {
  ::init();
  add_action("page","page");
  add_action("back","back");
  add_action("jump","jump");
}

page() {
  move_object(this_player(), "/players/trent/doodle/rooms/page3nw.c");
  write("You turn the page and crawl under it.\n");
  say(this_player()->query_name() + " crawls under the page.\n");
  command("look", this_player());

  return 1;
}

back() {
  move_object(this_player(), "/players/trent/doodle/rooms/page1nw.c");
  write("You jump up, grab the page over your head, and pull yourself up onto it.\n");
  say(this_player()->query_name() + " climbs up onto the page over your head.\n");
  command("look", this_player());

  return 1;
}

jump() {
  write("You jump up and bang your head on the paper overhead.\n");
  say(this_player()->query_name() + "'s head bangs agains the paper overhead.\n");

  return 1;
}

