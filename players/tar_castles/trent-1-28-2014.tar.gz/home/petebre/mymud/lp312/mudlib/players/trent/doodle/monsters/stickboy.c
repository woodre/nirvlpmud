inherit "/obj/monster";

reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("stickboy");
  set_alias("boy");
  set_short("A poorly drawn stickboy");
  set_long(
"   _    \n"+
"  (\")   This poor little guy has been separated from his parents.\n"+
"  /|\\   He also seems to have the misfortune of being drawn with\n"+
" / | \\  no neck and a fat flat head.  You should probably put him\n"+
"  / \\   out of his misery.\n"+
" /   \\  \n"+
"/     \\ \n"
  );
  set_gender("male");
  set_race("human");
  set_level(5);
  set_wc(9);
  set_ac(5);
  set_hp(95);
  set_al(0);
  set_chat_chance(2);
  load_chat("The stickboy cries.\n");
  load_chat("The stickboy whines, 'I want my mommy'.\n");
  set_dead_ob(this_object()); /* Specifies what object the monster_died function is in. */
}

monster_died(ob) {
  object head, corpse;

  /* assume (hope) that this dests the correct corpse */
    corpse = present("corpse",environment(this_object()));
    destruct(corpse);  

    corpse = clone_object("/obj/corpse");
    corpse->set_name(name);
    corpse->set_level(level);
    corpse->set_mhp(max_hp);
    corpse->set_ac(armor_class);
    corpse->set_wc(weapon_class);
    corpse->set_long(
" __   ____ This is the corpse of a stickboy. It's missing its head.\n"+
"/____/    \n"+
"\\__  \\____\n"
    );
  move_object(corpse,environment(ob));

  head = clone_object("/obj/armor");
  head->set_id("head");
  head->set_short("Stickboy's head");
  head->set_long("\n _\n(\")  A stickboy's head.  You could probably wear it, but where?.\n");
  head->set_value(250);
  head->set_type("amulet");
  head->set_ac(1);
  head->set_weight(1);

  move_object(head,environment(ob));
  write("With your final strike, you remove the stickboy's head.\n");
  tell_room(environment(),
            this_player()->query_name()+" removes the head of the stickboy.\n",
            ({ this_player() }) /* tp won't see this message */
  );
}
