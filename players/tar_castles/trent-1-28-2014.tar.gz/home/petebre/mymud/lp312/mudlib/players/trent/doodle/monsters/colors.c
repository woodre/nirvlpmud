#include "/obj/ansi.h"

inherit "/obj/monster";

string *someColors;

reset(arg) {

  ::reset(arg);
  if(arg) return;

  someColors = ({getColor()});
  someColors += ({getColor()});
  someColors += ({getColor()});
  someColors += ({getColor()});
  someColors += ({getColor()});

  set_name("colors");

  set_level(7 + random(3));
  set_wc(9 + random(3));
  set_ac(4 + random(4));
  set_hp(90 + random(35));
  set_al(0);
  set_chat_chance(10);
  set_short(someColors[0] + " " + someColors[1] + " " + someColors[2] + " " +
    someColors[3] + " " + someColors[4] + " " + NORM + " (colors)");
  set_long(
someColors[0] + "            " + NORM + " Some fool has taken some markers and drawn several \n"+
someColors[1] + "            " + NORM + " colored lines.  Strangely, it looks like the colors \n"+
someColors[2] + "            " + NORM + " have come to life and are now floating around  as a\n"+
someColors[3] + "            " + NORM + " strange entity.\n"+
someColors[4] + "            " + NORM + "\n"
  );
  load_chat(someColors[0] + "The colors float around.              " + NORM + "\n");
  load_chat(someColors[1] + "The colors seem to be watching you.   " + NORM + "\n");
  load_chat(someColors[2] + "The colors are mildly disturbing.     " + NORM + "\n");
  load_chat(someColors[3] + "The colors float around.              " + NORM + "\n");
  load_chat(someColors[4] + "The colors float around.              " + NORM + "\n");

  set_chance(10);
  set_spell_mess1(someColors[0] + "You are enveloped in " + someColors[1] + "color.\n" + NORM);
  set_spell_mess2(someColors[2] + "The " + someColors[3] + "colors" + someColors[4] + " knock you to the ground.\n" + NORM);
  set_spell_dam(10);

  set_dead_ob(this_object()); }

getColor() {
    int iColor;
    iColor = random(14);
 
    if (iColor < 7) 
      return ESC + "[" + (40 + iColor) + "m";
    else
      return ESC + "[" + (40 + iColor - 7) + ";1m";
}

monster_died(ob) {
  object corpse;
  /* assume (hope) that this dests the correct corpse */
  corpse = present("corpse",environment(this_object()));
  destruct(corpse);  

  corpse = clone_object("/obj/armor.c");
  corpse->set_id("cloak");
  corpse->set_short(someColors[0] + "C" + someColors[1] + "o" + someColors[2] + "l" +  
    someColors[3] + "o" + someColors[4] + "r" + someColors[0] + "f" + someColors[1] + "u" + 
    someColors[2] + "l" + NORM + " cloak");
  corpse->set_type("misc");
  corpse->set_value(250);
  corpse->set_weight(2);
  corpse->set_ac(1);
  corpse->set_long(
"  " + someColors[0] + "     \n" + NORM +
" " + someColors[1] + "       \n" + NORM +
" " + someColors[2] + "       \n" + NORM +
someColors[3] + "         \n" + NORM +
someColors[4] + "         \n" + NORM
);
  move_object(corpse, environment(this_object()));
  tell_room(environment(), 
"The colorful creature falls to the ground, becoming what looks like a piece of cloth.\n"
  );

}

