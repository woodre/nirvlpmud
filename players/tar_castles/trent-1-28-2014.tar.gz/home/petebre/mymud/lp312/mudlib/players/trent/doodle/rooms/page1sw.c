inherit "/room/room.c";

reset(arg) {
  object monster;

  if (arg) return;
  set_light(1);

  short_desc="Corner of page 1";
  long_desc=
"You stand at the corner of the top page of a yellow legal pad.\n"+
"The page extends before you to the north and east.  To the \n"+
"south and west the room were just in. Everything is huge! You\n"+
"could probably 'jump' off the page and go back.  Or, you \n"+
"might turn the 'page'.\n";
  items=({
    "paper","It's ruled yellow paper",
    "page","It's ruled yellow paper",
    "ground","It's ruled yellow paper"
  });
  dest_dir=({
    "/players/trent/doodle/rooms/page1cw.c", "north",
    "/players/trent/doodle/rooms/page1se.c", "east",
    "/players/trent/doodle/rooms/page1ce.c", "northeast"
  });
  if(!present("stickman")) {
    monster=clone_object("/players/trent/doodle/monsters/stickman.c");
    move_object(monster,this_object());
  }
}

init() {
  ::init();
  add_action("page","page");
  add_action("jump","jump");
}

page() {
  move_object(this_player(), "/players/trent/doodle/rooms/page2sw.c");
  write("You turn the page and crawl under it.\n");
  say(this_player()->query_name() + " crawls under the page\n");
  command("look", this_player());

  return 1;
}

jump() {
  move_object(this_player(), "/players/trent/house/rooms/livingroom.c");
  write("You see yourself grow back to your original size as you leap from the page.\n");
  say(this_player()->query_name() + " leaps from the page and becomes enormous!\n");
  command("look", this_player());
  return 1;
}

