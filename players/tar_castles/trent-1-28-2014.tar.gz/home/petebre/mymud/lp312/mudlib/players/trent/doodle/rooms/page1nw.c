inherit "/room/room.c";

reset(arg) {
  object monster;

  if (arg) return;
  set_light(1);

  short_desc="Corner of page 1";
  long_desc=
"This is yet another area of the first page. At the north edge,\n"+
"you see the binding holding the page together.  You can still\n" +
"see the room you left behind to the north and west.  The page\n"+
"stretches away from you to the south and east.  You can still\n"+
"'jump' off the page and go back.  Or, you may turn the 'page'.\n";

  items=({
    "paper","It's ruled yellow paper",
    "page","It's ruled yellow paper",
    "ground","It's ruled yellow paper",
    "room", "It is filled with huge objects. You can 'jump' back to it",
    "binding", "A strip of paper is folded over the sheet.  You have no use for it"
  });
  dest_dir=({
    "/players/trent/doodle/rooms/page1cw.c", "south",
    "/players/trent/doodle/rooms/page1ne.c", "east",
    "/players/trent/doodle/rooms/page1ce.c", "southeast"
  });
/*  if(!present("stickman")) {
    monster=clone_object("/players/trent/doodle/monsters/stickman.c");
    move_object(monster,this_object());
  }
*/}

init() {
  ::init();
  add_action("page","page");
  add_action("jump","jump");
}

page() {
  move_object(this_player(), "/players/trent/doodle/rooms/page2nw.c");
  write("You turn the page and crawl under it.\n");
  say(this_player()->query_name() + " crawls under the page.\n");
  command("look", this_player());

  return 1;
}

jump() {
  move_object(this_player(), "/players/trent/house/rooms/livingroom.c");
  write("You see yourself grow back to your original size as you leap from the page.\n");
  say(this_player()->query_name() + " leaps from the page and becomes enormous!\n");
  command("look", this_player());

  return 1;
}

