inherit "/room/room.c";

reset(arg) {
  object monster;

  if (arg) return;
  set_light(1);

  short_desc="Corner of page 1";
  long_desc=
"You stand at a different corner of the top page of the legal\n"+
"pad. It is much like the first corner. The page extends before\n"+
"you to the north and back to the west.  To the south and east\n"+
"you can still the room were just in. Everything remains huge.\n"+
"You could still 'jump' off the page and go back.  Or, you may\n"+
"turn the 'page'.\n";
  items=({
    "paper","It's ruled yellow paper",
    "page","It's ruled yellow paper",
    "ground","It's ruled yellow paper"
  });
  dest_dir=({
    "/players/trent/doodle/rooms/page1ce.c", "north",
    "/players/trent/doodle/rooms/page1sw.c", "west",
    "/players/trent/doodle/rooms/page1cw.c", "northwest"
  });
  if(!present("stickwoman")) {
    monster=clone_object("/players/trent/doodle/monsters/stickwoman.c");
    move_object(monster,this_object());
  }
}

init() {
  ::init();
  add_action("page","page");
  add_action("jump","jump");
}

page() {
  move_object(this_player(), "/players/trent/doodle/rooms/page2se.c");
  write("You turn the page and crawl under it.\n");
  say(this_player()->query_name() + " crawls under the page\n");
  command("look", this_player());

  return 1;
}

jump() {
  move_object(this_player(), "/players/trent/house/rooms/livingroom.c");
  write("You see yourself grow back to your original size as you leap from the page.\n");
  say(this_player()->query_name() + " leaps from the page and becomes enormous!\n");
  command("look", this_player());

  return 1;
}

