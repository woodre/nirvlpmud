inherit "/room/room.c";

reset(arg) {
  object monster;

  if (arg) return;
  set_light(1);

  short_desc="Edge of page 3";
  long_desc=
"You stand at the edge of the third and final page.  This page is\n"+
"actually the paperboard back of the notebook.  Somehow, you are able\n"+
"to stand below the page above without hitting your head.  The pages\n"+
"stretch above and below you the the north, south, and west.  You can \n"+
"climb 'back' to the page above.\n";

  items=({
    "paper","It's smooth brown paperboard",
    "page","It's smooth brown paperboard",
    "ground","It's smooth brown paperboard",
    "ceiling","It's ruled yellow paper"
  });
  dest_dir=({
    "/players/trent/doodle/rooms/page3ne.c", "north",
    "/players/trent/doodle/rooms/page3nw.c", "northwest",
    "/players/trent/doodle/rooms/page3cw.c", "west",
    "/players/trent/doodle/rooms/page3sw.c", "southwest",
    "/players/trent/doodle/rooms/page3se.c", "south"
  });
/*  if(!present("stickman")) {
    monster=clone_object("/players/trent/doodle/monsters/stickman.c");
    move_object(monster,this_object());
  }
*/}

init() {
  ::init();
  add_action("back","back");
  add_action("jump","jump");
}

back() {
  move_object(this_player(), "/players/trent/doodle/rooms/page2ce.c");
  write("You jump up, grab the page over your head, and pull yourself up onto it.\n");
  say(this_player()->query_name() + " climbs up onto the page over your head.\n");
  command("look", this_player());

  return 1;
}

jump() {
  write("You jump up and bang your head on the paper overhead.\n");
  say(this_player()->query_name() + "'s head bangs agains the paper overhead.\n");

  return 1;
}

