inherit "/obj/monster";

reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("stickman");
  set_alias("man");
  set_short("A poorly drawn stickman");
  set_long(
"                _        This is a crudely drawn stickman,\n" +
"               / \\       clearly the work of a small child.\n" +
"              |`_`|      (Or a wizard with absolutely no\n" +
"               \\_/       artistic abilities).\n" +
"              _____      \n" +
"             /  |  \\     \n" +
"            /   |   \\    \n" +
"           /    |    \\   \n" +
"                |        \n" +
"               / \\       \n" +
"              /   \\      \n" +
"             /     \\     \n" +
"            /       \\    \n"

  );
  set_gender("male");
  set_race("human");
  set_level(6);
  set_wc(10);
  set_ac(5);
  set_hp(100);
  set_al(0);
  set_chat_chance(2);
  load_chat("The stickman looks at you curiously.\n");
  load_chat("The stickman scowls (sort of).\n");
  set_dead_ob(this_object()); /* Specifies what object the monster_died function is in. */
}

monster_died(ob) {
  object leg, corpse;

  /* assume (hope) that this dests the correct corpse */
    corpse = present("corpse",environment(this_object()));
    destruct(corpse);  

    corpse = clone_object("/obj/corpse");
    corpse->set_name(name);
    corpse->set_level(level);
    corpse->set_mhp(max_hp);
    corpse->set_ac(armor_class);
    corpse->set_wc(weapon_class);
    corpse->set_long(
"      _                     This is the corpse of a stickman.\n" +
"     / \\    ____   ______|  It seems to be missing a leg.\n" +
"    |   |__/______/         \n" +
"     \\_/   \\____  \\   \n"
    );
  move_object(corpse,environment(ob));

  leg = clone_object("/obj/weapon");
  leg->set_id("leg");
  leg->set_short("Stickman's leg");
  leg->set_long("\n______| \nA stickman's leg.  it seems rather clublike.\n");
  leg->set_value(250);
  leg->set_type("club");
  leg->set_class(10);
  leg->set_weight(2);

  move_object(leg,environment(ob));
  write("With your final strike, you remove the stickman's leg.\n");
  tell_room(environment(),
            this_player()->query_name()+" removes a leg from the stickman.\n",
            ({ this_player() }) /* tp won't see this message */
  );
}