#include "/players/wocket/closed/ansi.h"
inherit "/players/wocket/std/wiztell.c";

reset(arg){
  if(arg) return;
  owner = "trent";
  cap_owner = "Trent";
  color = HIC;
  extra_look = "Trent is a newbie wiz and should be feared";
}
