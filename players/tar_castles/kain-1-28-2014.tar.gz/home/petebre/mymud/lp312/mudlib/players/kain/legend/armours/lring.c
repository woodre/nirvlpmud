inherit "obj/armor";

reset(arg) {
    ::reset(arg);
    set_name("Ring");
    set_alias("ring");
    set_short("A crystal ring");
    set_long("An absolutely gorgeous ring.  It is solid gold with a a green and\n") +
            ("crystal stone.  This ring is very valuable to her and appears to be\n") +
            ("worn as a challenge for her suitors.\n");
    set_type("ring");
    set_ac(1);
    set_weight(1);
    set_value(1100);
}