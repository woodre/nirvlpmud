inherit "obj/armor";

reset(arg) {
  ::reset(arg);
  set_name("belt");
  set_short("A chastity Belt.DON'T DEST!");
  set_alias("chastity belt");
  set_long(" A chastity belt for adulterous men who cheat on such wonderful\n"+
           "vampire women.\n");

set_ac(0);
set_weight(1);
set_value(0);
}

init() {
   ::init();
       if(call_other(this_player(),"query_real_name",0)=="kain") {
              add_action("cant_cast"); add_xverb("sex");
              add_action("cant_cast"); add_xverb("drop");
  }
  }
cant_cast() {
          write("You can't do that with a chastity belt on....DUH!!!\n");
         return 1;
}

