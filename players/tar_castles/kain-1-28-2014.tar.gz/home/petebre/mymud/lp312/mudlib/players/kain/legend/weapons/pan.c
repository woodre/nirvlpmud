inherit "/obj/weapon.c";
reset(arg) {
	::reset();
	if (arg) return;
	set_name("frying pan");
	set_alias("pan");
	set_alt_name("fryingpan");
	set_short("Frying Pan");
	set_long("A Teflon coated frying pan.\n");
        set_class(10);
        set_weight(2);
	set_value(100);
     }
