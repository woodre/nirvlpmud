inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {
	object ob, ob1;

	ob = clone_object("players/kain/weapons/pan.c");
	move_object(ob,this_object());
        this_object()->init_command("wield pan");
        set_name("Bromtom");
        set_alt_name("bromtom");
	set_alias("elf");
        set_short("Bromtom the elf");
	set_race("elf");
        set_long("Bromtom is a sturdy little elf with white hair.  He appears\n"+            
		    "to be somewhat drunk?!?  He has what looks like a large bulge\n"+
	           "underneathe his hat!\n");
        set_level(9);
        set_ac(7);
        set_wc(13);
        set_hp(135);
        set_al(600);
	 add_money(200);
        set_gender("male");
	set_aggressive(0);
        set_dead_ob(this_object());
        set_chat_chance(15);
	set_a_chat_chance(40);
	load_chat("Bromtom says: Oh....careful now....this is me finest elderberry wine.\n");
	load_a_chat("Bromtom shouts: If your lookin for a fight...you've come to the chap who " +
		      "will oblige ya!\n");
        load_a_chat("Bromtom exclaims: You're the cause of all our sorrows!\n");
        }
    }
monster_died() {
        say("Bromtom says: They killed me.....I'm done for......\n");
	 say("A small bottle falls out of Bromtom's hat.\n");
        ob1 = clone_object("players/kain/heals/elderberry.c");
	 move_object(ob1, enironment(this_object()));
          }
