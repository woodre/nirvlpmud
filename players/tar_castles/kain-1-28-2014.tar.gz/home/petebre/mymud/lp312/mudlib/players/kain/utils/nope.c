/*
 * This object keeps a player from using a specified name
 * in any commands.  You might want to code your own function
 * that clones this object, sets the name and then moves it
 * to the offending player.
 * Example:
 *   shut_up(str) {
 *      object obj;
 *      obj = clone_object("/open/pavlik/nope.c");
 *      obj->set_name(this_player()->query_real_name());
 *      move_object(obj, find_player(str));
 *      return 1;
 *   }
 *
 * Now the player that has the object cannot use your name in
 * any commands.  This means 'tell <name> blah' wont work, and
 * neither will commands like 'gossip i think <name> is a fag'.
 *
 */

string who;

reset(arg) {
  who = "noone";
}

short() { return; }

long() {
  write("nope.\n");
  return;
}

id(str) { return (str == "nope" || str == "noway"); }

set_who(str){ who = str; }
query_who(){ return who; }

init() {
  add_action("nope"); add_xverb("");
}

nope(str) {
  string crap1, crap2;

  /* keep moving to player to keep at top of inventory */
  move_object(this_object(), environment(this_object()));
     who = "kain";
  if(sscanf(str, "%s"+who+"%s", crap1, crap2)==2 ||
     str == who) {
     write("Nope!\n");
     return 1;
  }
}
 
get() { return 1; }
drop(){ return 1; }
query_weight() { return 0; }
query_value() { return 0; }

