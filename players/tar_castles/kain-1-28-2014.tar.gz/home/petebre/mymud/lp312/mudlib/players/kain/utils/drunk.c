#include "/players/sado/inc/std.h"

init()
{
    add_action("dsay","say");
    add_action("dsay"); add_xverb("'");
    add_action("help","help");
    add_action("dgossip","gossip");
    add_action("dgossip","shout");
    add_action("dgossip","junk");
    add_action("dgossip","risque");
    add_action("dgossip","equip");
    if(tp && tp->query_level() >= 20)
	{
	    add_action("dgossip", "wiz");
	    add_action("dgossip", "announce");
	}
    else
	{
	    add_action("check_stumble"); add_xverb("");
	}
    add_action("dtell","tell");
    add_action("d_other","ddo");
}

query_auto_load()
{
    return "/players/sado/shop/drunk.c:";
}

id(str)
{
    return (str == "drunk");
}

drop()
{
    return 1;
}

dgossip(str)
{
    if(str[0]==':') tp->broadcast(str);
    else if(explode(str," ")[0]=="list") tp->broadcast(str);
    else if(explode(str," ")[0]=="off")  tp->remove_channel(query_verb());
    else tp->broadcast(distort(str));
    return 1;
}

dtell(str)
{
    string who;
    string msg;
   
    if(!str || sscanf(str, "%s %s", who, msg) != 2) return 0;
    return tell(who, distort(msg));
}

static tell(who, msg)
{
    object ob;
    string it;
	int level;

    it = lower_case(who);
    ob = find_player(it);
    level = tp->query_level();
    if (!ob) ob = find_living(it);
    if (!ob) {
	write("No player with that name.\n");
	return 1;
    }
    if (interactive(ob)) {
	if (level < ob->query_level() && ob->query_invis() >= 39) {
	    write("No player with that name.\n");
	    return 1;
	}
        if (level < 9999 && in_editor(ob)) {
	    write("That person is editing. Please try again later.\n");
	    return 1;
	}
      if(query_idle(ob) > 120) tell_object(tp, who+" is idle at the moment. You may not get a response right away.\n");
    }
    if(!ob->query_npc() && !interactive(ob)) tell_object(tp, who+" is disconnected.\n");
if (call_other( tp, "query_invis", 0) > 0 && call_other(tp, "query_level", 0) < 999)
  {
  write( "Don't be annoying.  Become visible before you talk to someone!\n" );
  return 1;
  }
msg = format(msg, 60);
    tell_object(ob, capitalize(tpname) + " tells you: " + msg + "\n");
    write("Ok.\n");
    write("You tell "+who+ " " + msg);
    if (level < 20)
	tp->add_spell_point(-1);
    return 1;
}


dsay(str)
{
    say(tpname+" says: "+distort(str)+"\n");
    write("You say: "+distort(str)+"\n");
    return 1;
}

distort(str)
{
    string msg,temp;
    int i;
    msg="";
    for(i=strlen(str)-1; i >= 0; i--)
	{
	    if(tp->query_intoxination() >
	       random(tp->query_level()))
		{
		    if(str[i]=='s') temp="sh";
		    else if(str[i]=='S') temp="Sh";
		    else if(str[i]=='r') temp="rr";
		    else if(str[i]=='R') temp="Rr";
		    else if(str[i]=='l' && str[i-1]=='l') temp="ll";
		    else if(str[i]==' ' && random(4)==1) temp=" (hic) ";
		    else if(str[i]==' ' && random(4)==1) temp=" (burp) ";
		    else if(str[i]=='c' && (str[i+1]=='e' || str[i+1]=='i' || str[i+1]=='y')) temp="sh";
		    else if(str[i]=='C' && (str[i+1]=='e' || str[i+1]=='i' || str[i+1]=='y')) temp="Sh";
		    else if((str[i]=='\'' && str[i+1]=='t') ||
			    (str[i]=='s' && str[i+1]=='s')) temp="";
		    else temp=extract(str,i,i);
		}
	    else temp=extract(str,i,i);
	    msg = temp + msg;
	}
    return msg;
}

d_other(str)
{
    string com,what;
    if(!str)
	{
	    return 0;
	}
    if(sscanf(str,"'%s' %s",com,what)!=2)
	{
	    write("The syntax is: ddo '<command>' <thing to be garbled>\n(The quotes are important, ignore the <>)\n");
	    return 1;
	}
    command(com+" "+distort(what),tp);
    return 1;
}

help(str)
{
    if(!id(str)) return 0;
    cat("/players/sado/shop/drunk_help");
    return 1;
}

random_walk()
{
    string exits;
    int i,j;
    object here;
   
    here=environment(environment());
    exits=here->query_dest_dir();
    i=sizeof(exits)/2;
    j=random(i);
    command(exits[j*2+1], environment());
    tell_object(environment(),"You stumble out of the room in your stupor.\n");
    tell_room(here,environment()->query_name()+" stumbles out of the room to the ");
    tell_room(here,exits[j*2+1]+".\n");
}

check_stumble(str)
{
    if(tp->query_intoxination() >=
       (tp->query_level() * 3) / 4)
	if(random(tp->query_level())==1)
	    {
		write("You try to "+query_verb()+" "+str+" but you're too drunk.\n");
		random_walk();
		return 1;
	    }
    return 0;
}
