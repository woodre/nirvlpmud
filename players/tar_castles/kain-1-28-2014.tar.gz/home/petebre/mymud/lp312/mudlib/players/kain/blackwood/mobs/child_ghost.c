inherit "obj/monster";

void reset(status arg){
    string gender;
    
    ::reset(arg);
         
	if(!arg) {
	    if (random(2)==0) {
	        gender = "male";
	    } else {
	        gender = "female";
	    }
	    
        set_name("ghost");
        set_alt_name("child ghost");
   	    set_alias("child");
        set_short("A child ghost");
	    set_race("deer");
        set_long("A small ghost of a child. The ghost appears to be nothing more than a vapor.\n");
        set_level(3);
        set_ac(4);
        set_wc(7);
        set_hp(random(20)+25);
        set_al(500);
        set_gender(gender);
	    set_aggressive(0);
	    set_wander(1);
	    set_wander_interval(5);
	    set_wander_realm("/players/kain/blackwood/manor");	    
	    set_dead_ob(this_object());
    }
}

int monster_died() { 
    object ob; 
    /* do all the misc crap you wanna do when mob dies, 
    then destroy the corpse with the following lines: */ 
    ob = present("corpse", environment()); 
    destruct(ob); 
    return 1;
}