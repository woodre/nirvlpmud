inherit "/obj/monster";

reset(arg) {
    ::reset(arg);
        if(!arg){
        object ob, ob1;

        ob = clone_object("/players/kain/armours/leathersuit.c");
        move_object(ob, this_object());
        ob1 = clone_object("/players/kain/weapons/dagger.c");
        move_object(ob1, this_object());

        this_object()->init_command("wear suit");
        this_object()->init_command("wield dagger");
                set_name("Gump");
                set_alias("gump");
                set_short("Honeythorne Gump");
                set_race("fairy");
                set_long("Honeythorne Gump is the wisest fairy in the forest.\n"+
                         "He seems to be troubled about the recent events and\n"+
                         "changes that seem to be taking place in the forest.\n");        
                        
                set_level(9);
                set_ac(7);
                set_wc(13);
                set_hp(random(30)+110);
                set_al(800);
                set_gender("male");
                set_aggressive(0);
	         add_money(100);
                set_chat_chance(5);
                set_a_chat_chance(20);
        load_chat("Gump says: Honeythorne Gump...at your service.\n");
        load_a_chat("Gump asks: You think you can upset the order of the universe and not\n"+
                    "pay the price?!?!?!\n");
        }
    }
