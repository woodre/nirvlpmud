inherit"obj/weapon";

#define tpn this_player()->query_name()
#define atn attacker->query_name()

object part;
int index;
string attacker;

reset(arg) {
    ::reset(arg);
    if(arg) return;
    set_name("battleaxe");
    set_alias("axe");
    set_short("The Legendary Battleaxe of Bresine");
    set_long(
        "You see something special in this particular weapon.  A devastatingly\n" +
        "powerful weapon indeed.\n");
    set_value(10);
    set_weight(3);
    set_class(17);
    set_hit_func(this_object());
}

weapon_hit(attacker) {
    int retval;
    
    index = random(100);
    
    switch(index) {
       case 97..99:
            write("You swing with all your might and whack off one of your opponent's arms.\n");
            say(tpn + " whacks off one of " + atn + "'s arms.\n");
            attacker->hit_player(10, "other|kain");
            part = clone_object("players/kain/legend/misc/part");
            part->set_part("arm");
            part->set_name(atn);
            part->set_owner(tpn);
            move_object(part,environment(this_player()));
            retval = 5;
            break;
        case 94..96:
            write("You swing wildly and hack off your opponents leg just below the kneecap.\n");
            say(tpn + " lunges forward and hacks off " + atn + "'s leg in a bloody mess.\n");
            attacker->hit_player(10, "other|kain");
            part = clone_object("players/kain/legend/misc/part");
            part->set_part("leg");
            part->set_name(atn);
            part->set_owner(tpn);
            move_object(part, environment(this_player()));
            retval = 5;
            break;
        case 70:
            if(random(50) < 13){
                write("The axe slips and you deal yourself a devastating blow!\n");
                this_player()->hit_player(50,"other|kain");
                retval = 1;
            } else {
                retval = -6;
            }
            break;   
        case 69:
        case 68:
            if(random(30) > 14){
                write("You remove your opponent's head with a swing of your axe. THWAK!\n");
                say(tpn + " deals " + atn + " a deadly blow.\n");
                attacker->hit_player(100, "other|kain");
                part = clone_object("players/kain/legend/misc/part");
                part->set_part("head");
                part->set_name(atn);
                part->set_owner(tpn);
                move_object(part, environment(this_player()));
            }
            retval = 5;
            break;
        case 40..43:
            write("You swing your axe and slash open your opponents gut.\n");
            write(atn + "'s guts fall out on the ground in a bloody mess.\n");
            attacker->hit_player(10, "other|kain");
            part = clone_object("players/kain/legend/misc/part");
            part->set_part("guts");
            part->set_name(atn);
            part->set_owner(tpn);
            move_object(part, environment(this_player()));
            retval = 5;
            break;                                
        case 30..33:
            write("You swing the axe around, aiming for the head, but only get some ear.\n");
            say(tpn + " misses the head but manages to get a good chunk of ear.\n");
            attacker->hit_player(5, "other|kain");
            retval = 5;
            break;
        case 20..23:
            write("In an excellent show of axemanship, you whack off your opponent's nose.\n");
            say(tpn + " removes " + atn +"'s nose with crushing blow.\n");
            attacker->hit_player(10, "other|kain");
            part = clone_object("players/kain/legend/misc/part");
            part->set_part("nose");
            part->set_name(atn);
            part->set_owner(tpn);
            move_object(part, environment(this_player()));
            retval = 5;
            break;
        case 0..14:
            write("You reduce your opponent to a bloody pulp!\n");
            attacker->hit_player(6, "other|kain");
            retval = 5;
            break;
        default:
            retval = 3;
    }
    return retval;
}
