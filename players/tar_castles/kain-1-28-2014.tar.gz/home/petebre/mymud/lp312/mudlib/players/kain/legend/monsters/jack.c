inherit "/obj/monster";

reset(arg) {
        ::reset(arg);
        if(!arg){
        object ob, ob1;

        ob = clone_object("/players/kain/armours/leathersuit.c");
        move_object(ob, this_object());
        ob1 = clone_object("/players/kain/armours/leatherboots.c");
        move_object(ob1, this_object());

        this_object()->init_command("wear boots");
        this_object()->init_command("wear suit");
                set_name("Jack");
                set_alias("jack");
                set_short("Jack the Forest Child");
                set_race("human");
                set_long("Jack is Forest Child.  Nobody knows the woods\n" +
                         "better than he.  He knows every nook and cranny\n" +
                         "of the forest and is a formidable opponent.\n");
                set_level(10);
                set_ac(8);
                set_wc(14);
                set_hp(random(30)+135);
                set_al(400);
                set_gender("male");
                set_aggressive(0);
                set_chat_chance(5);
                set_a_chat_chance(20);
		  add_money(250);
        load_chat("Jack says: I have something very special to show you.\n");
        load_a_chat("Jack says: Me?  I know nothing of weapons!\n");
        }
    }
