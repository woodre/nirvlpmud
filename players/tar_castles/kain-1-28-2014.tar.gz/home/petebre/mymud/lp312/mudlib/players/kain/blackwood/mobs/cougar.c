inherit "obj/monster";

reset(arg){
    ::reset(arg);
	if(!arg) {
        set_name("deer");
        set_alt_name("large deer");
   	    set_alias("doe");
        set_short("A large deer");
	    set_race("deer");
        set_long("A large deer with a full coat and large antlers.\n");
        set_level(8);
        set_ac(5);
        set_wc(12);
        set_hp(random(20)+100);
        set_al(500);
        set_gender("male");
	    set_aggressive(0);
    }
}