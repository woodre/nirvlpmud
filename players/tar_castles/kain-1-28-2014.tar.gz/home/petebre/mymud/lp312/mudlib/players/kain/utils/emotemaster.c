string capt_name;

id(str) { return str == "emotemaster"; }

static general(self, who, others) {
    object who1, who2;
       capt_name = call_other(this_player(), "query_name");
    if (who==0){
        write(self + ".\n");
        say(capt_name  + others + ".\n");
        return 1;
    }
    who1 = present(who, environment(this_player()));
    if(!who1) {
        who2 = find_player(who);
        write(self + " at " + capitalize(who) + " from afar.\n");
        tell_object(who2, capt_name + others + " at you from afar.\n");
        return 1;
    }
}
 
static specific(self, others, who, target) {
    object who1, who2;
    capt_name = call_other(this_player(), "query_name");
    who1 = present(lower_case(who), environment(this_player()));
    if (who1 && living(who1)) {
        if(who1 == this_player())
        return 0;
    write(self + ".\n");
    tell_object(who1, capt_name + target + ".\n");
    say(capt_name + others + ".\n", who1);
    } else {
       who2 = find_player(lower_case(who));
       if(!who2 || who2 == this_player() || in_editor(who2) || who2->query_invis() >= 20)
           return 0;
       write(self + " from afar.\n");
       tell_object(who2, capt_name + target + " from afar.\n");
    }
    return 1;
}

bleed() {
    return general("You wipe blood from your nose", 0,
                   " wipes a trickle of blood from his nose");
}

blush(str) {
    return general("You lower your head, blushing a deep blood red", str,
                   " lowers his head, blushing a deep blood red");
}

bow(str) {
    if (!str) {
        write("You bow with vampiric grace to your audience.\n");
        say(call_other(this_player(), "query_name", 0) + " bows with vampiric grace.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You bow with vampiric grace to " + str,
                    " bows to " + str + " with vampiric grace", str, 
		      " bows to you with vampiric grace");
}

chuckle(str) {
    if(!str) {
        write("You chuckle vampirically.\n");
        say(call_other(this_player(), "query_name", 0) + " chuckles vampirically.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You chuckle vampirically at " + str, 
                   " checkles vampirically at " + str, str,
                   " chuckles vampirically at you");
}

comfort(str) {
    if (!str)
	return 0;
    str = capitalize(str);
    return specific("You comfort " + str, " comforts " + str + " with his vampire touch",
                    str, " comforts you with his vampire touch");
}

cry(str) {
 return general("You lower your head and a tears of blood drip from your eyes", str,
                   " lowers his head and tears of blood pour from his eyes");  
}

cuddle(str) {
   if (!str)
        return 0;
    str = capitalize(str);
    return specific("You cuddle " + str + " in your vampire arms",
		      " cuddles " + str + " in his vampire arms", str,
                    " cuddles you in his vampire arms");
}

dance(str) {
    if (!str) {
        write("You dance with vampiric grace.\n");
	say(call_other(this_player(), "query_name", 0) + " dances with vampiric grace.\n");
	return 1;
    }
    str = capitalize(str);
    return specific("You sweep " + str + " across the room with vampiric grace",
                    " sweeps " + str + " across the room with vampiric grace", str,
                    " sweeps you across the room with vampiric grace");
}

glare(str) {
    if (!str)
	return 0;
    str = capitalize(str);
    return specific("You glare evilly at " + str + " with your vampire eyes",
                    " glares evilly at " + str + " with his vampire eyes", str,
                    " glares evilly at you with his vampire eyes");
}

grin(str) {
   if(!str) {
        write("You grin evilly exposing your fangs.\n");
        say(call_other(this_player(), "query_name", 0) + " grin evilly exposing his fangs.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You grin evilly at " + str + " exposing your fangs",
                    " grins evilly at " + str + " exposing his fangs", str,
                    " grin evilly at you exposing his fangs");    
}

growl(str) {
    if (!str) {
        write("You growl and gnash your fangs.\n");
	say(call_other(this_player(), "query_name", 0) + " growls and gnashes his fangs.\n");
	return 1;
    }
    str = capitalize(str);
    return specific("You growl and gnash your fangs at " + str,
                    " growls and gnashes his fangs at " + str, str,
                    " growls and gnashes his fangs at you");
}

hold(str) {
    if (!str)
        return 0;
    str = capitalize(str);
    return specific("You hold " + str + " against your vampire body", 
		      " holds " + str + " against his vampire body", str,
                    " holds you against his vampire body");
}

hug(str) {
    if (!str)
	return 0;
    str = capitalize(str);
    return specific("You hug " + str + " with your vampire arms",
                    " hugs " + str + " with his vampire arms", str,
                    " hugs you with his vampire arms");
}

kiss(str) {
    if (!str)
	return 0;
    str = capitalize(str);
    return specific("You bestow kiss on " + str + " with your vampire lips",
                    " bestows a vampire kiss on " + str, str,
                    " bestows you with a vampire kiss");
}

laugh(str) {
   if(!str) {
        write("You laugh vampirically.\n");
        say(call_other(this_player(), "query_name", 0) + " laughs vampirically.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You laugh vampirically at " + str,
                    " laughs vampirically at " + str, str,
                    " laughs vamprically at you");
}

shiver(str) {
    return general("You shiver from fear", str,
                   " shivers from fear");
}

smile(str) {
    if(!str) {
        write("You smile exposing your fangs.\n");
        say(call_other(this_player(), "query_name", 0) + " smiles exposing his fangs.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You smile at " + str + " exposing your fangs",
                    " smiles at " + str + " exposing his fangs", str,
                    " smiles at you exposing his fangs");
}

smirk(str) {
if(!str) {
        write("You smirk exposing your fang.\n");
        say(call_other(this_player(), "query_name", 0) + " smirks exposing a fang.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You smirk at " + str + " exposing a fang",
                    " smirks at " + str + " exposing a fang", str,
                    " smirks at you exposing a fang");

}

snicker(str) {
if(!str) {
        write("You snicker mischeviously.\n");
        say(call_other(this_player(), "query_name", 0) + " snickers mischeviously.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You snicker at " + str + " mischeviously",
                    " snickers at " + str + " mischeviously", str,
                    " snickers at you mischeviously");
}

tackle(str) {
    if (!str)
        return 0;
    str = capitalize(str);
    return specific("You tackle " + str + " to the ground and smother them with kisses",
                    " tackles " + str + " to the ground and smothers them with kiseses", 
		       str, " tackles you and smothers you with kisses");
}

wink(str) {
    if(!str) {
        write("You wink your vampire eye.\n");
        say(call_other(this_player(), "query_name", 0) + " winks his vampire eye suggestively.\n");
        return 1;
    }
    str = capitalize(str);
    return specific("You wink suggestively at " + str + " with your vampire eye",
                    " winks suggestively at " + str + " with his vampire eye", str,
                    " winks at you suggestivly with his vampire eye");
}

yawn(str) {
    return general("You yawn exposing your fangs",str," yawns exposing his fangs");
}
