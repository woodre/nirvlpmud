long() {
    write("A very sharp wolf claw. The magnificent features of the claw\n"+
          "make you think it should be made into jewelery. Perhaps if something\n"+
          "was found to tie this to...it could be made into a fine necklace.\n");
}

short() {
    return "A sharp wolf claw";
}

query_weight() {
    return 1;
}

query_value() {
    return 15;
}

init() {
    add_action("tie"); add_verb("tie");
}

tie() {
    write("To be implemented later.\n");
    return 1;
}



get() {
    return 1;
}

id(str) {
    return str == "claw";
}
