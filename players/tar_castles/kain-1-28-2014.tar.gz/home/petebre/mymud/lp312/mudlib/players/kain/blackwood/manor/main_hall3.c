inherit "room/room";

void reset(status arg) {
    ::reset(arg);
        
	if(arg) return;
	    
    set_light(1);
    short_desc=("Main Hall");
    long_desc=
        "The broad central hallway stretches out before you with its diamond-shaped\n" +
        "white-and-black marble tiles running to the front door. Partially blocking\n" +
        "your view is a spiral stairway. Along the walls is large running mural. The\n" +
        "high ceiling towers overhead. To the west is the butler pantry that leads to\n" +
        "the kitchen and to the east is a bedroom. A door idential the front door is\n" +
        "in front of you but appears to be locked.\n";
    items= ({
        "stairs",
            "The gorgeous stairway with its graceful railing and delicate balusters is one\n" +
            "of the greatest attributes of Blackwood Manor. The stairway runs all the way to\n" +
            "the third floor",
        "stairway",
            "The gorgeous stairway with its graceful railing and delicate balusters is one\n" +
            "of the greatest attributes of Blackwood Manor. The stairway runs all the way to\n" +
            "the third floor",
        "floor",
            "The diamond-shaped white-and-black Italian marble stretches out before you\n" +
            "running to the front door",
        "tiles",
            "The diamond-shaped white-and-black Italian marble stretches out before you\n" +
            "running to the front door",
        "mural",
            "Your eyes move to the running mural on the hallway walls, a sunshine Italian\n" +
            "pastoral giving way to a deep blue sky whose bright color dominates the entire\n" +
            "long space and the hall above",
        "walls",
            "Your eyes move to the running mural on the hallway walls, a sunshine Italian\n" +
            "pastoral giving way to a deep blue sky whose bright color dominates the entire\n" +
            "long space and the hall above",
        "ceiling",
            "Looking up at the high ceiling you notice the handcrafted plaster moldings",
        "moldings",
            "The moldings were hand done by New Orleans craftsmen",
        "door",
            "The front door is idential to the rear door in front of you. This door appears\n" +
            "to be locked",            
    });
    
    dest_dir= ({
        "players/kain/blackwood/manor/butler_pantry.c","west",
        "players/kain/blackwood/manor/queens_bedroom.c","east",
        "players/kain/blackwood/manor/main_hall2.c","south",
    });
}