inherit "/obj/monster";

reset(arg) {
        ::reset(arg);
        if(!arg){

                set_name("Peasant Lady");
                set_alias("lady");
		  set_alt_name("peasant");
                set_short("A Peasant Lady.");
                set_race("human");
                set_long("A poor peasant lady of the forest. She appears to be\n" +
                         "busy cooking and folding her laundry. Unbeknownst to the King,\n" +
                         "she is one of Lilly's best friends.\n");
                set_level(7);
                set_ac(5);
                set_wc(10);
                set_hp(random(30)+75);
                set_al(500);
		  add_money(10);
                set_gender("female");
                set_aggressive(0);
                set_chat_chance(5);
        load_chat("Peasant Lady says: Bloomin fairy's!!\n");
        }
    }
