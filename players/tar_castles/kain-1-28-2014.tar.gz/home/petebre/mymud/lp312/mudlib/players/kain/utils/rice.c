int full;

id(str) {
    if (str == "rice" && full)
	return 1;
    return str == "bag";
}

short() {
    if (full)
	return "A small bag of rice. Syntax: throw rice";
    return "empty rice bag";
}

query_value()
{
    return 0;
}

long() {
    write(short() + ".\n");
}

reset(arg) {
    if (arg)
        return;
    full = 3;
}

throw(str)
{
    if ( !str || str !="rice" ) {
       write("Syntax: throw rice.\n");
       return 1;
    }
    if (!full){
       write("The bag is empty.\n");
	return 1;
    }
    full = full - 1;
    write("You throw a handful of rice at Karelia and Highlander!!\n");
    say(call_other(this_player(), "query_name", 0) +
	" throws a handful of rice at Karelia and Highlander!!\n");
    return 1;
    
}

init() {
    add_action("throw"); add_verb("throw");
}

drop() { destruct(this_object());
         return 1; }

get() {
    return 1;
}

query_weight() {
    return 0;
}
