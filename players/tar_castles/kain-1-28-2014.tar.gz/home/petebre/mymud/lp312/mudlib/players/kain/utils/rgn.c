
init() {
          add_action("ring_them"); add_verb("ringthem");
          add_action("ring"); add_verb("ringme");
   }

id(str) { return str == "ringg"; }
short() {
        return 0;
        }

ring( str ) {
  object ring;
  
  if (!str) {
      write("You must specify a person.\n");
      return 1;
      }
  ring = clone_object("/players/bastion/closed/ring.c");
  call_other( ring,"set_spouse", str);
  move_object( ring, this_player());
  write( "ok.\n");
  return 1;
  }

ring_them( str ) {
    object ring, person;
    string name, who;

    if (!str) {
        write("You must specify a person.\n");
        return 1; 
           }
    if((!sscanf(str,"%s %s",who,name))==2) {
        write("Usage: ringthem <player> <spouse>.\n");
        return 1; }
    if(!find_living(who)) {
       write("I could not find "+who+".\n");
    return 1 ; }
    person = find_living(who) ;
    ring = clone_object("/players/bastion/closed/ring.c");
    call_other( ring, "set_spouse", name );
    move_object( ring, person );
    tell_object(person, "Kain hands you your wedding ring.\n");
    write("Done.\n");
    return 1;
    }
drop() { destruct(this_object());
         return 1; }
get() { return 1; }
