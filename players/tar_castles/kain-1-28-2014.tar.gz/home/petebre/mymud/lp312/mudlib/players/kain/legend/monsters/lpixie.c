inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {

        set_name("pixie");
        set_alt_name("large pixie");
   	 set_alias("fairy");
        set_short("A large pixie");
	 set_race("fairy");
        set_long("A large mischeievous pixie. With an evil look you feel\n" +
                 "that perhaps you should keep an eye on this little one.\n");
        set_level(2);
        set_ac(2);
        set_wc(6);
        set_hp(random(10)+25);
        set_al(100);
        set_gender("male");
	 set_aggressive(0);
        }
    }