inherit "room/room";

#define tp this_player()->query_name()

int current_page;

void init() {
  ::init();
  add_action("read_book", "read");
  add_action("open_book", "open");
  add_action("close_book", "close");
  add_action("sign_book", "sign");
}

void reset(status arg) {
    ::reset(arg);
        
    current_page = 0;
    
	if(arg) return;
	    
    set_light(1);
    short_desc=("Main Hall");
    long_desc=
        "The broad central hallway stretches out before you with its diamond-shaped\n" +
        "white-and-black marble tiles running to the front and rear door. Here you are\n" +
        "standing in the well of the stairway. Along the walls is large running mural.\n" +
        "The high ceiling towers overhead. Against the wall is a small desk with a book\n" +
        "on it.\n";
    items= ({
        "stairs",
            "The gorgeous stairway with its graceful railing and delicate balusters is one\n" +
            "of the greatest attributes of Blackwood Manor. The stairway runs all the way to\n" +
            "the third floor",
        "stairway",
            "The gorgeous stairway with its graceful railing and delicate balusters is one\n" +
            "of the greatest attributes of Blackwood Manor. The stairway runs all the way to\n" +
            "the third floor",
        "floor",
            "The diamond-shaped white-and-black Italian marble stretches out before you\n" +
            "running to the front and rear door",
        "tiles",
            "The diamond-shaped white-and-black Italian marble stretches out before you\n" +
            "running to the front and rear door",
        "mural",
            "Your eyes move to the running mural on the hallway walls, a sunshine Italian\n" +
            "pastoral giving way to a deep blue sky whose bright color dominates the entire\n" +
            "long space and the hall above",
        "walls",
            "Your eyes move to the running mural on the hallway walls, a sunshine Italian\n" +
            "pastoral giving way to a deep blue sky whose bright color dominates the entire\n" +
            "long space and the hall above",
        "ceiling",
            "Looking up at the high ceiling you notice the handcrafted plaster moldings",
        "moldings",
            "The moldings were hand done by New Orleans craftsmen",
        "door",
            "The rear door is idential to the door by which you entered this house",
        "desk",
            "The desk is made of solid oak with a marble tabletop and reflects a mix of\n" +
            "Gothic Revivial and the later Renaissance Revival. The quatrefoil designs\n" +
            "on the table's skirt are typical motif found in Gothic church windows, \n" +
            "while the ball turnings on the legs and the upright bracket moldings just\n" +
            "below the tabletop reflect the Renaissance influence. Sitting on top of the\n" + 
            "desk is old worn guestbook",
        "guestbook",
            "An old worn guestbook with a broken quill pen crushed inside. Perhaps you should\n" +
            "try to read it or sign it",
        "book",
            "An old worn guestbook with a broken quill pen crushed inside. Perhaps you should\n" +
            "try to read it or sign it"                                   
    });
    
    dest_dir= ({
        "players/kain/blackwood/manor/main_hall3.c","north",
        "players/kain/blackwood/manor/main_hall.c","south"
    });
}

status read_book(string arg) {	        
    if (arg != "book" && arg != "guestbook" && arg != "page") {
        notify_fail("What is it you wish to read?\n");
        return 0;
    }
    
    if (current_page == 0) {
	    write("It is closed.\n");
	    return 1;
    } 
        
    cat("/players/kain/blackwood/manor/guestbook");
    say (tp +" reads the guestbook.\n");
    return 1;
}

status open_book(string arg) {
    if (arg != "book" && arg != "guestbook" && arg != "page") {
        notify_fail("What is it you wish to open?\n");
        return 0;
    }
    
    if (current_page > 0) {
	    write("The book is already open at page " + current_page + ".\n");
	    return 1;
    }
    
    current_page = 1;
    write("You open the guestbook.\n");
    say(tp + " opens the guestbook.\n");
    return 1;
}

status close_book(string arg) {
    if (arg != "book" && arg != "guestbook" && arg != "page") {
        notify_fail("What is it you wish to open?\n");
        return 0;
    }
    
    if (current_page == 0) {
	    write("It is already closed.\n");
	    return 1;
    }
    
    current_page = 0;
    write("You close the guestbook.\n");
    say(tp + " closes the guestbook.\n");
    return 1;
}

status sign_book(string arg) {	        
    if (arg != "book" && arg != "guestbook" && arg != "page") {
        notify_fail("What is it you wish to sign?\n");
        return 0;
    }
    
    if (current_page == 0) {
	    write("It is closed.\n");
	    return 1;
    } 
        
    write("You sign the guestbook.\n");
    write_file("/players/kain/blackwood/manor/guestbook", tp + " - " + ctime(time()) + "\n");
    say (tp +" signs the guestbook.\n");
    return 1;
}