inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {

        set_name("rabbit");
        set_alt_name("white rabbit");
   	 set_alias("rabbit");
        set_short("A small white rabbit");
	 set_race("rabbit");
        set_long("A small white rabbit with fluffy fur and floppy ears.\n");
        set_level(2);
        set_ac(3);
        set_wc(6);
        set_hp(random(10)+25);
        set_al(600);
        set_gender("male");
	 set_aggressive(0);
        set_dead_ob(this_object());
        }
    }
monster_died() {
        say("The rabbit rolls over and dies painfully.\n");
          }
