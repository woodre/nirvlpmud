inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg){
	object ob;

        ob = clone_object("players/kain/armours/elfcloak.c");
	move_object(ob,this_object());
        this_object()->init_command("wear cloak");
        set_name("Screwball");
        set_alt_name("screwball");
	set_alias("elf");
        set_short("Screwball the elf");
	set_race("elf");
        set_long("Screwball is a small elf with bright white hair.  His pointed ears\n" +
                 "flicker in all directions.  He doesn't appear to be very dexterous.\n" +
                 "so don't get in his way or you might get hurt!\n");            
        set_level(9);
        set_ac(7);
        set_wc(13);
        set_hp(135);
        set_al(600);
	 add_money(250);
        set_gender("male");
	set_aggressive(0);
        set_chat_chance(15);
	set_a_chat_chance(40);
        load_chat("Screwball says: I sadly fear the worst.\n");
        load_a_chat("Screwball screams: WHY Meeeee?!?!?!?!\n");
        }
    }
