int full;

id(str) {
    if (str == "tea" && full)
	return 1;
    return str == "cup";
}

short() {
    if (full)
	return "A small cup of tea";
    return "An empty cup";
}

query_value()
{
    return 0;
}

long() {
    write(short() + ".\n");
}

reset(arg) {
    if (arg)
        return;
    full = 10;
}

sip(str)
{
    if (str && str != "tea" )
	return 0;
    if (!full){
       write("The cup is empty.\n");
	return 1;
    }
    full = full - 1;
    write("You take a sip of tea.\n");
    say(call_other(this_player(), "query_name", 0) +
	" takes a sip of tea.\n");
    return 1;
}

init() {
    add_action("sip"); add_verb("sip");
}

drop() { destruct(this_object());
         return 1; }

get() {
    return 1;
}

query_weight() {
    return 0;
}
