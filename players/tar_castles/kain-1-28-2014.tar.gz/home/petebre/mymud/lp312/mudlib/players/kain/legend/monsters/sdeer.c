inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {

        set_name("deer");
        set_alt_name("small deer");
   	 set_alias("doe");
        set_short("A small deer");
	 set_race("deer");
        set_long("A small deer with white spots and no antlers.\n");
        set_level(4);
        set_ac(3);
        set_wc(7);
        set_hp(random(10)+55);
        set_al(500);
        set_gender("female");
	 set_aggressive(0);
        }
    }