long() {
    write("You are looking at a beautiful arrangement of flowers.\n" +
	  "They fill the room with their soft fragrance.  You notice\n" +
         "the White lilies intertwined with Queen annes lace, among\n" +
	  "other flowers and baby's breath and green foliage.  A gift\n" +
         "from Kain and Echo to add to the wedding of such lovely people.\n");
         }

short() {
    return "A beautiful arrangement of flowers";
}

query_weight() {
    return 0;
}

query_value() {
    return 0;
}


get() {
    return 0;
}

id(str) {
    return str == "flowers";
}
