inherit "/obj/monster";

reset(arg){
	::reset(arg);
	if(!arg){
	object ob, ob1;

	ob = clone_object("/players/kain/armours/lring.c");
	move_object( ob, this_object());
	ob1 = clone_object("/players/kain/armours/lnecklace.c");
	move_object( ob1, this_object());

        this_object()->init_command("wear necklace");
        this_object()->init_command("wear ring");
		set_name("Lilly");
		set_alias("lilly");
		set_short("The Princess Lilly");
		set_race("human");
		set_long("Lilly is the fairest woman in all the lands.  She is lost\n" +
                         "in thoughts of love of her mate Jack.  She appears to be\n" +
                         "pondering upon a decision.\n");
                set_level(6);
                set_ac(5);
                set_wc(10);
                set_hp(random(10)+85);
		set_al(500);
                set_aggressive(0);
		set_chat_chance(5);
		set_a_chat_chance(20);
	load_chat("Lilly says: This place holds more magic for me than any Palace in the world.\n");
	load_a_chat("Lilly screams: How dare you attack a princess..my Father will hear of this!!\n");
	}
}


