inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A path in the forest.";
   long_desc=
      "A small dirt path leading through the forest.\n"+
      "On either side of the path overgrown ferns sway\n"+
      "at your feet. Above you the canopy of the trees\n"+
      "squeezes out most of the light.\n";
   dest_dir=({
      "/players/kain/workroom.c","north",
      "/players/kain/workroom.c","south",
   });
   items=({
      "path",
         "The path is well worn from many adventurers and\n"+
         "forest children. Upon closer look you can see\n"+
         "animal tracks",
      "ferns",
         "The small green ferns sway at your feet",
      "tracks",
        "The tracks appear to come from an equestrian animal",
      "animal tracks",
        "The tracks appear to come from an equestrian animal",
   });

}