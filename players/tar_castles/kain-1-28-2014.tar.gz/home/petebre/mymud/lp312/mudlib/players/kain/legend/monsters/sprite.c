inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {

        set_name("pixie");
        set_alt_name("small pixie");
   	 set_alias("fairy");
        set_short("A small pixie");
	 set_race("fairy");
        set_long("A small mischeievous pixie. She looks as if she is\n" +
                 "up to something.\n");
        set_level(1);
        set_ac(2);
        set_wc(5);
        set_hp(random(5)+12);
        set_al(100);
        set_gender("female");
	 set_aggressive(0);
        }
    }