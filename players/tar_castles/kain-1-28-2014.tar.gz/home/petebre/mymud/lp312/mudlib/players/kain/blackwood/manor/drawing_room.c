inherit "room/room";

#define tp this_player()->query_name()

void init() {
    ::init();
    
    add_action("play_instrument", "play");
}

void reset(status arg) {
    ::reset(arg);
        
	if(arg) return;
    set_light(1);
    short_desc=("Drawing Room");
    long_desc=
        "The drawing room is filled with old French Rococo style furniture. Directly\n" +
        "in front of you is a golden harp and old Pleyel piano. A large portrait\n" +
        "hangs on the wall behind the piano. Wall-to-wall carpets cover the floor.\n" +
        "Against the far wall is a beautiful fireplace with large antique desk next\n" +
        "to it. Large windows surround the southern and eastern walls. The high\n" +
        "ceiling encloses the room lending to a dreamy sense of the past.\n";
    items= ({
        "portrait",
            "You glance at a huge somber portrait of Manfred Blackwood",
        "furniture",
            "The lighthearted themes and intricate designs of Rococo present themselves\n" +
            "very well on the many pieces in the room",       
        "windows",
            "The windows have three layers of curtaining; wooden Venetian blinds, net\n" +
            "curtains, and curtains under a pelmet all hung on heavy brass poles. The\n" +
            "curtains are tied back with ropes decorated with tassels",
        "ceiling",
            "The ceiling is papered with a relief paper and painted off-white with a\n" +
            "tint of the main colour of the room. The celing is crowned with a very\n" +
            "ornate cornice and rose. Hanging from the ceiling is a beautiful chandelier",
        "chandelier",
            "An elaborate Victorian chandelier, suspended by five metal rods cased in\n" +
            "flute cut glass from a starburst coronet. Ten leaf-cut arms, with cut arms\n" +
            "and drip pans hung with prism drops, rise out of a heavily cut receiver bowl.\n" +
            "In the centre of the chandelier rises a rod supporting two drop hung pans\n" +
            "and a finial",
        "cornice",
            "The cornice and rose are painted several colours to highlight the gilded\n" +
            "moulding",
        "rose",
            "The cornice and rose are painted several colours to highlight the gilded\n" +
            "moulding",
        "walls",
            "The walls are covered with velvet wallpaper heavily patterned in dark greens\n" +
            "and burgundy",
        "harp",
            "The golden harp is a triple harp that features three rows of parallel strings,\n" +
            "two outer rows of diatonic strings, and a center row of chromatic strings. It\n" +
            "looks as if you could play it",
        "piano",
            "The Pleyel piano has a sound acquiring a special satisfying quality, the upper\n" +
            "register bright and silvery, the middle penetrating and intense, the bass clear\n" +
            "and vigorous. It looks as if you could play it",
        "pleyel",
            "The Pleyel piano has a sound acquiring a special satisfying quality, the upper\n" +
            "register bright and silvery, the middle penetrating and intense, the bass clear\n" +
            "and vigorous. It looks as if you could play it",
        "fireplace",
            "The fireplace is beautifully designed with a Gothic arch and timber mantel",
        "carpet",
            "The carpet is an elaborate design with flowers and foliage in light colours",
        "desk",
            "A Lois XV desk with inlaid wood, cabriole legs and ormolu"
    });
        
    dest_dir= ({
        "players/kain/blackwood/manor/main_hall.c","west",
    });
}

status play_instrument(string arg) {
    int retval;
    
    retval = 1;
    
    switch(arg) {
       case "piano":
            write("The striking of the hammers gives a sound that is pure, clear, even, and intense.\n");
            say(tp + " plays the piano.\n");
            break;
        case "harp":
            write("The rippling notes of the harp float up and spiral around the room.\n");
            say(tp + " plays the harp.\n");
            break;
        default:
            notify_fail("What is it you wish to play?\n");
            retval = 0;
    }    
    return retval;
}