inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {

        set_name("rabbit");
        set_alt_name("grey rabbit");
   	 set_alias("rabbit");
        set_short("A large grey rabbit");
	 set_race("rabbit");
        set_long("A small grey rabbit with fluffy fur and large ears.\n");
        set_level(3);
        set_ac(4);
        set_wc(6);
        set_hp(random(10)+45);;
        set_al(100);
        set_gender("male");
	 set_aggressive(0);
        set_dead_ob(this_object());
        }
    }
monster_died() {
        say("The rabbit rolls over and dies painfully.\n");
          }
