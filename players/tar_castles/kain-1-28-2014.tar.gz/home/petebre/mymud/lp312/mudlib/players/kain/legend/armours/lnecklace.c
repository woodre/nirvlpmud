inherit "obj/armor";

reset(arg) {
    ::reset(arg);
    set_name("necklace");
    set_alias("amulet");
    set_short("A gorgeous necklace");
    set_long("This necklace is of astounding beauty.  The intricate workmanship\n") +
            ("alone makes this necklace very valuable.  The man stone irradiate a\n") +
            ("remarkable array of colours.\n");
    set_type("amulet");
    set_ac(1);
    set_weight(1);
    set_value(1000);
}