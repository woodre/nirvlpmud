 id(str) {
        return str == "fixer";
        }
init(){
    add_action("fix");     add_verb("fix");
}
fix(str) {
   object obj;
   obj = find_player(str);
   obj->add_phys_at(3,-89);
   return 1;
}
drop() { destruct(this_object());
        return 1; }
get() { return 1; }
