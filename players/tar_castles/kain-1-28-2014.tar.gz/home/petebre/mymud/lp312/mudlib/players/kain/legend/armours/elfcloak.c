inherit "obj/armor";

reset(arg) {
    ::reset(arg);
    set_name("elfcloak");
    set_alias("cloak");
    set_short("An Elfcloak");
    set_long("This is an elfcloak.  It is made of an unknown material.  It appears\n") +
            ("to be quite sturdy in all respects.\n");
    set_type("armor");
    set_ac(2);
    set_weight(2);
    set_value(75);
}
