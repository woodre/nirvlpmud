inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {

        set_name("wolf");
        set_alt_name("grey wolf");
   	 set_alias("greywolf");
        set_short("A grey wolf");
	 set_race("wolf");
        set_long("A large wolf with a grey coat. This looks like a fierce animal.\n");
        set_level(11);
        set_ac(9);
        set_wc(15);
        set_hp(random(20)+150);
        set_al(-200);
        set_gender("male");
	 set_aggressive(0);
        set_dead_ob(this_object());
        }
    }

monster_died() {
    object ob1;
    int num;
        num = random(100);
        if ( num < 10 ) {
	 tell_room(environment(this_object()),
		    "With a bone crushing blow " + call_other(attacker_ob, "query_name", 0) +
                  " you knock a claw from the wolf!!\n");
        ob1 = clone_object("players/kain/d-misc/claw.c");
	 move_object(ob1, environment(this_object()));
        }
        else
           {
            say("The wolf falls over and dies.\n");
        }
        return 0;
          }
