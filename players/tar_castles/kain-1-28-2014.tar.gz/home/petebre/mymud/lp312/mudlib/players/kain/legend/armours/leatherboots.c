inherit "obj/armor";

reset(arg) {
    ::reset(arg);
    set_name("leatherboots");
    set_alias("boots");
    set_short("Leather Boots");
    set_long("A very thin but remarkably strong pair of leather boots.  It is\n") +
            ("stitched together by hemp and will withstand many miles of wear\n") +
            ("and tear.\n");
    set_type("boots");
    set_ac(1);
    set_weight(1);
    set_value(175);
}
 
