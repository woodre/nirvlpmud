inherit "room/room";

#define tp this_player()->query_name()

status isOpened;

void init() {
    ::init();
        
    add_action("open_door","open");
    add_action("enter_door","enter");
}

void reset(status arg) {
    ::reset(arg);
        
    isOpened = 0;
    
	if(arg){
	    return;
	}
    set_light(1);
    short_desc=("Portico");
    long_desc=
        "As you walk up the six front steps of the two-story columned portico of\n" +
        "Blackwood Manor, you immediately take in the enormous size of the structure.\n"+
        "The entire porch is made of marble and the fluted columns are brilliantly\n" +
        "illuminated to their full height by the countless garden lights. Windows\n"+
        "line the front of the manor and all are aglow from the chandeliers hanging\n" +
        "in the many rooms. The pediment, portico, and columns come together to form\n" +
        "a perfect Greek Revival style. Directly in front of you is a massive solid\n" +
        "oak door. To your rear are the stairs leading down to the yard.\n";
    items= ({
        "columns",
            "The fluted marble columns are set in a Greek Revival style and tower",
        "floor",
            "A gorgeous display of Italian marble and New Orleans craftsmanship",
        "portico",
            "The massive marble portico extends the entire front of the manor",
        "porch",
            "he massive marble portico extends the entire front of the manor",            
        "stairs",
            "The marble stairs lead down to the front yard",                        
        "windows",
            "The long windows are aglow from the large chandeliers hanging in each room",
        "pediment",
            "The pediment is difficult to see from here",
        "door",
            "The front door of the manor is large and heavy and made of solid oak.\n" +
            "It appears to be unlocked",
        "lights",
            "Many garden lights light up various areas of the house and yard"
    });
    
    dest_dir= ({
        "players/kain/blackwood/farm/manor.c","stairs"
    });
}

status open_door(string arg) {
    if (arg != "door") {
        notify_fail("What is it you wish to open?\n");
        return 0;
    }
    
    if (isOpened) {
       write("The door is already opened.  You may 'enter' it.\n");
       return 1;
     }    
    
    isOpened = 1;
    
    write("You reach and open the door. You may 'enter' it.\n");
    say (tp +" opens the door.\n");
    return 1;
}

status enter_door(string arg)
{
  if(!isOpened) {
    write("The door appears to be closed. Perhaps you should try to open it first.\n");
    return 1;
  }
  
  this_player()->move_player("through the door#players/kain/blackwood/manor/main_hall.c");
  return 1;
}