inherit "room/room";

object obj;

reset(arg) {
	if(arg) return;
    set_light(1);
    short_desc=("Quinn's Bedroom");
    long_desc=
        "Quinn's bedroom room.\n";
    items= ({
        "columns",
            "The fluted marble columns are set in a Greek Revival style and tower",
        "floor",
            "A gorgeous display of Italian marble and New Orleans craftsmanship",       
        "windows",
            "The long windows are aglow from the large chandeliers hanging in each room",
        "pediment",
            "The pediment is difficult to see from here",
        "door",
            "The front door of the manor is large and heavy and made of solid oak.\n" +
            "It appears to be unlocked",
        });
dest_dir=
({
"players/kain/blackwood/manor/quinns_room.c","north",
});
}