int count;

status id(string str) {
    return (str == "venom");
}

status drop() {
    return 1;
}

status can_put_and_get() { return 1; }

void set_venom(int arg){
    count = arg;
}

void start_venom(){
    call_out("do_damage",5);   
}

void do_damage() {    
    object ob; 
    
    if (!environment() || !(ob = environment(this_object()))) {
        return;
    } 
    
    tell_object(ob, "The venom courses through your veins.\n");
    ob->hit_player(3, "other|venom");
    count--;
    
    if (ob->query_ghost()) {
     remove_call_out("do_damage");            
     destruct(this_object());
    }
    else if (count < 1){
        tell_object(ob, "The venom wears away.\n");
        destruct(this_object());
    } else {
        call_out("do_damage", 5);
    }
}
