inherit "room/room";

void reset(status arg) {
    ::reset(arg);
        
	if(arg) return;
	    
    set_light(1);
    short_desc=("Dining Room");
    long_desc=
        "The antique crystal chandelier showers a wealth of light on the long table\n" +
        "in the center of the room. Gilded demask chairs surround the table and the\n" +
        "floor is covered with wall-to-wall carpeting. Gilded sideboards are ranged\n" +
        "between the long windows on the far wall. The eastern wall adorns two large\n" +
        "portraits.\n";
    items= ({
        "chandelier",
            "An elaborate Victorian chandelier, suspended by five metal rods cased in\n" +
            "flute cut glass from a starburst coronet. Ten leaf-cut arms, with cut arms\n" +
            "and drip pans hung with prism drops, rise out of a heavily cut receiver bowl.\n" +
            "In the centre of the chandelier rises a rod supporting two drop hung pans\n" +
            "and a finial",
        "carpet",
            "A green and gold wall-to-wall carpet with a gold swirl on the green ground",       
        "sideboards",
            "The gilded sideboards, inset with green malachite, are ranged between the long\n" +
            "windows on the far wall",
        "windows",
            "The windows have three layers of curtaining; wooden Venetian blinds, net\n" +
            "curtains, and curtains under a pelmet all hung on heavy wooden poles. The\n" +
            "curtains are tied back with metal fittings",
        "table",
            "A long table, which could seat some thirty people, was made\n" +
            "especially for this room",
        "chairs",
            "The gilded chairs have recently been re-covered in green satin demask",
        "portraits",
            "Your eyes move first to a huge portrait of Aunt Queen when she was young;\n" +
            "and at another portrait of Virgina Lee Blackwood",
        "aunt queen",
            "You see a smiling girl in a sleeveless white beaded evenging gown that might\n" +
            "have been made yesterday rather than seventy years ago",
        "virgina lee",
            "A murky portrait of a blue eyed, blonde haired woman with an undeniably\n" +
            "pretty face, dressed ornately in the style of the late 1880s"
    });

    dest_dir= ({
        "players/kain/blackwood/manor/main_hall.c","east",
    });
}