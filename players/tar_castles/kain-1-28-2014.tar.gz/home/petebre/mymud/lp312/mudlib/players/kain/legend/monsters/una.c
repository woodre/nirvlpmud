inherit "/obj/monster";

reset(arg) {
        ::reset(arg);
        if(arg) return;
                set_name("Una");
                set_alias("una");
                set_short("Una the Fairy");
                set_race("fairy");
                set_long("Una is a willful sprite.  She holds a secret\n" +
                         "about herself.  She doesn't look like she'd tell\n"+
                         "a soul though.\n");
                set_level(6);
                set_ac(5);
                set_wc(10);
                set_hp(random(30)+70);
                set_al(400);
                set_gender("female");
                set_aggressive(0);
                
	 set_chat_chance(5);
        set_a_chat_chance(20);
        load_chat("Una says: I can be anything you want me to be...even your hearts desire.\n");
        load_a_chat("Una says: You look like mourners at your own funerals.\n");

        set_chance(30);
	 set_spell_dam(6);
	 set_spell_mess1("Una grabs a handful of Fairy Dust and whirls it!!\n");
        set_spell_mess2("Una grabs a handful of Fairy Dust and whirls it at you!\n");       
    }
