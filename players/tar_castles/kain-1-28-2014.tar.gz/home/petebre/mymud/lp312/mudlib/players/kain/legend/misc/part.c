#define DECAY_TIME	100

string name,part;
int decay;
static string shortdesc,longdesc,killer;

init() {
    if(!name)
      set_name("noone");
}

reset(arg) {
    if(arg) return;
    if(!root()) set_heart_beat(1);
}

set_name(n){
    name = n;
    decay = DECAY_TIME;
}

set_part(p) {
    part = p;
}

set_short(arg) { shortdesc = arg; }
set_long(arg) {longdesc = arg; }

set_owner(str) {
   killer = str; 
}

short() {
    if(!name)
        set_name("noone");   
    if(!part)
        set_part("body part");
    if (decay < 20)
	    return "The somewhat decayed " + part + " of " + capitalize(name);
    if(!shortdesc)
        return capitalize(part) + " of " + capitalize(name);
    else 
        return shortdesc;
}

long() {
    if(!name)
        set_name("noone");   
    if(!part)
        set_part("body part");
    if (decay < 20)
        write("This is the somewhat decayed " + part + " of " + capitalize(name) + ".\n"); 
    else if(!longdesc)
        write("This is the " + part + " of " + capitalize(name) + ".\n");
    else 
        write(longdesc +"\n");
}

id(str) {
 if ( ( str == part )||( str == "body part" )||( str == part + " of " + name)||( str == "remains" ) )
   return 1;
 return 0;        
}

heart_beat() {
    decay -= 1;    
    if (decay > 0) return;
    destruct(this_object());
}
get() {
    return 1;
}

query_weight(){ return 1; }
query_name() { return name; }
query_owner(){ return killer; }