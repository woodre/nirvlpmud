inherit "room/room";

void reset(status arg) {
    ::reset(arg);
        
	if(arg) return;
	    
    set_light(1);
    short_desc=("Main Hall");
    long_desc=
        "The broad central hallway stretches out before you with its diamond-shaped\n" +
        "white-and-black marble tiles running to the rear door. Partially blocking\n" +
        "your view is a spiral stairway. Along the walls is large running mural. The\n" +
        "high ceiling towers overhead. To the west is the dining room and to the east\n" +
        "through an arched doorway is a drawing room. The hallway continues north and\n" +
        "the stairs lead up to the second and third floor of the manor house.\n";
    items= ({
        "stairs",
            "The gorgeous stairway with its graceful railing and delicate balusters is one\n" +
            "of the greatest attributes of Blackwood Manor. The stairway runs all the way to\n" +
            "the third floor",
        "stairway",
            "The gorgeous stairway with its graceful railing and delicate balusters is one\n" +
            "of the greatest attributes of Blackwood Manor. The stairway runs all the way to\n" +
            "the third floor",
        "floor",
            "The diamond-shaped white-and-black Italian marble stretches out before you\n" +
            "running to the rear door",
        "tiles",
            "The diamond-shaped white-and-black Italian marble stretches out before you\n" +
            "running to the rear door",
        "mural",
            "Your eyes move to the running mural on the hallway walls, a sunshine Italian\n" +
            "pastoral giving way to a deep blue sky whose bright color dominates the entire\n" +
            "long space and the hall above",
        "walls",
            "Your eyes move to the running mural on the hallway walls, a sunshine Italian\n" +
            "pastoral giving way to a deep blue sky whose bright color dominates the entire\n" +
            "long space and the hall above",
        "ceiling",
            "Looking up at the high ceiling you notice the handcrafted plaster moldings",
        "moldings",
            "The moldings were hand done by New Orleans craftsmen",
        "door",
            "The rear door is idential to the door by which you entered this house",            
    });
    
    dest_dir= ({
        "players/kain/blackwood/manor/main_hall2.c","north",
        "players/kain/blackwood/manor/dining_room.c","west",
        "players/kain/blackwood/manor/drawing_room.c","east",
        "players/kain/blackwood/manor/upper_hall.c","up",
        "players/kain/blackwood/manor/portico.c","door",
    });
}