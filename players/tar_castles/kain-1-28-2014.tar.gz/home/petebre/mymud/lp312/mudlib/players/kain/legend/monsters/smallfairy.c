inherit "obj/monster";

reset(arg){
	::reset(arg);
	if(!arg) {

        set_name("fairy");
        set_alt_name("small fairy");
   	 set_alias("faery");
        set_short("A small fairy");
	 set_race("rabbit");
        set_long("A small fairy with fluttering wings.\n");
        set_level(1);
        set_ac(1);
        set_wc(2);
        set_hp(random(5)+10);
        set_al(600);
        set_gender("female");
	 set_aggressive(0);
        }
    }