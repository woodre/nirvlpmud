#include "/players/kain/ansi.h"

id(str) { return str == "chrys";}

init() {
add_action("chrys", "chrys");
}
drop() { return 1; }
get() { return 1; }

chrys() {
object ob;

ob = present("jara",environment(this_player()));
ob->set_title(HIB+"the Forbidden"+NORM);
write("done\n");
return 1;
}
