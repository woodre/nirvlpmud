#define master "/players/kain/utils/emotemaster.c"

id(str) { return str == "emote_tool" || str == "emoter" || str == "emotertool"; }

short() { return 0;}

long() { 
   write("This is a vampire emoter.\n"+
         "Emotes:\n"+
	  "bleed, blush, bow, chuckle, comfort, cry, cuddle, dance,\n" +
         "glare, grin, growl, hold, hug, kiss, laugh, shiver, smile,\n" +
         "smirk, snicker, tackle, wink, yawn.\n");
}

drop() { destruct(this_object());
        return 1; }
get() { return 1; }

init() {
  if(call_other(this_player(),"query_real_name",0) == "kain")  {
      add_action("bleed");   add_verb("bleed");
      add_action("blush");   add_verb("blush");
      add_action("bow");     add_verb("bow");
      add_action("chuckle"); add_verb("chuckle");
      add_action("comfort"); add_verb("comfort");
      add_action("cry");     add_verb("cry");
      add_action("cuddle");  add_verb("cuddle");
      add_action("dance");   add_verb("dance");
      add_action("glare");   add_verb("glare");
      add_action("grin");    add_verb("grin");
      add_action("growl");   add_verb("growl");
      add_action("hold");    add_verb("hold");
      add_action("hug");     add_verb("hug");
      add_action("kiss");    add_verb("kiss");
      add_action("laugh");   add_verb("laugh");
      add_action("shiver");  add_verb("shiver");
      add_action("smile");   add_verb("smile");
      add_action("smirk");   add_verb("smirk");
      add_action("snicker"); add_verb("snicker");
      add_action("tackle");  add_verb("tackle");
      add_action("wink");    add_verb("wink");
      add_action("yawn");    add_verb("yawn");
  }
}

bleed()      { master->bleed(); return 1; }
blush(str)   { master->blush(str); return 1; }
bow(str)     { master->bow(str); return 1; }
chuckle(str) { master->chuckle(str); return 1;}
comfort(str) { master->comfort(str); return 1; }
cry(str)     { master->cry(str); return 1; }
cuddle(str)  { master->cuddle(str); return 1; }
dance(str)   { master->dance(str); return 1; }
glare(str)   { master->glare(str); return 1; }
grin(str)    { master->grin(str); return 1; }
growl(str)   { master->growl(str); return 1; }
hold(str)    { master->hold(str); return 1; }
hug(str)     { master->hug(str); return 1; }
kiss(str)    { master->kiss(str); return 1; }
laugh(str)   { master->laugh(str); return 1; }
shiver(str)  { master->shiver(str); return 1; }
smile(str)   { master->smile(str); return 1; }
smirk(str)   { master->smirk(str); return 1; }
snicker(str) { master->snicker(str); return 1; }
tackle(str)  { master->tackle(str); return 1; }
wink(str)    { master->wink(str); return 1; }
yawn(str)    { master->yawn(str); return 1; }