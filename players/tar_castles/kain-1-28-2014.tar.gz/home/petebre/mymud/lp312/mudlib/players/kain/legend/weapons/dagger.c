inherit "/obj/weapon.c";
reset(arg) {
	::reset();
	if (arg) return;
	set_name("dagger");
	set_alias("dagger");
	set_short("A Dagger");
	set_long("A small but very sharp dagger.\n");
        set_class(13);
        set_weight(1);
	set_value(100);
     }
