#include "std.h"
inherit "room/room";

string invader;
string invited;
int alarm;
int secure;
int lock;
int lit;
object bed;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="Kain's crypt...";
   long_desc=
       "A very dark and gothic crypt. The walls are stone and covered with a\n"
+      "thick layer of moss and vine. The ceiling is low, curved, and the high\n"
+      "window is narrow with the heavy grid of iron bars. The sweet violet\n"
+      "light of the night pours in revealing a great fireplace cut in the far\n"
+      "wall, the wood ready for the torch, and beside it, beneath the window,\n"
+      "an ancient stone sarcophagus.\n";

   items=({
    "sword",      "It appears part of this was carefully chipped away with great effort",
    "hilt",       "It appears part of this was carefully chipped away with great effort",
    "scabbard",   "It appears part of this was carefully chipped away with great effort",
    "lid",        "Here he lays in tranquillity, his jester's mouth sealed, his eyes staring\n"+
                  "mildly at the ceiling, his hair a neat mane of deeply carved waves and\n"+
                  "ringlets.  Three centuries old is this work of art.  He lay with his hands\n"+
                  "folded on his chest, his garments long robes, and from his sword that had\n"+
                  "been carved into the stone, someone had broken out the hilt and part of\n"+
                  "the scabbard",
     "old man",   "Here he lays in tranquillity, his jester's mouth sealed, his eyes staring\n"+
                  "mildly at the ceiling, his hair a neat mane of deeply carved waves and\n"+
                  "ringlets.  Three centuries old is this work of art.  He lay with his hands\n"+
                  "folded on his chest, his garments long robes, and from his sword that had\n"+
                  "been carved into the stone, someone had broken out the hilt and part of\n"+
                  "the scabbard",
     "effigy",    "Here he lays in tranquillity, his jester's mouth sealed, his eyes staring\n"+
                  "mildly at the ceiling, his hair a neat mane of deeply carved waves and\n"+
                  "ringlets.  Three centuries old is this work of art.  He lay with his hands\n"+
                  "folded on his chest, his garments long robes, and from his sword that had\n"+
                  "been carved into the stone, someone had broken out the hilt and part of\n"+
                  "the scabbard",
     "man",       "Here he lays in tranquillity, his jester's mouth sealed, his eyes staring\n"+
                  "mildly at the ceiling, his hair a neat mane of deeply carved waves and\n"+
                  "ringlets.  Three centuries old is this work of art.  He lay with his hands\n"+
                  "folded on his chest, his garments long robes, and from his sword that had\n"+
                  "been carved into the stone, someone had broken out the hilt and part of\n"+
                  "the scabbard",
  "coffin",       "An effigy of an old man is carved upon its heavy lid",
  "sarcophagus",  "An effigy of an old man is carved upon its heavy lid",
  "moss",         "A tangled mass of black moss intertwined throughout with a hardened vine",
  "vine",         "A tangled mass of brown hardened vine twisting throughout a mass of moss",
  "window",       "A small iron barred window that allows only a minimal amount of light through it",
  "fireplace",    "A large fireplace with blackened logs resting on a small iron stand.\n"+
	          "On the left side is a fire poker and an small pal of crumpled paper.\n"+
	          "To the right, a small pile of logs.  A slight amount of heat eminates out\n"+
                  "of the hearth indicating it's been extinguished recently",

   });
   dest_dir=({
       "room/church","church",
       "room/adv_guild","adv_guild",
    });
}

                

init(){
 ::init();
    if(call_other(this_player(),"query_real_name",0) == "charrise"){
       add_action("fire");      add_verb("firegaze");}
    if(call_other(this_player(),"query_real_name",0) == "kain")  {
       add_action("invite");    add_verb("invite");
       add_action("wizzes");    add_verb("wizzes");
       add_action("force");     add_verb("invite!");
       add_action("alarm");     add_verb("alarm");
       add_action("secure");    add_verb("secure");
       add_action("stat");      add_verb("ck");
       add_action("dest");      add_verb("dest");
       add_action("open");      add_verb("open");
       add_action("escort");    add_verb("escort");
       add_action("close");     add_verb("close");
       add_action("fire");      add_verb("firegaze");
    }
    invader = this_player()->query_real_name();
    if (this_player()->is_invis() > 0 && invader !="kain")  {
       this_player()->force_us("vis");
    }
    if (secure == 0 && invader !=invited && invader !="kain")  {
       say(invader + " has tried to enter this room, but was deflected\n");
       write("You have tried to go where you were not invited!\n");
       write("You are in the void..........\n");
       transfer(this_player(),  "room/void");
       return 1;
    }
    if(secure == 1 && alarm == 0)  {
       say(invader + " has entered this room\n");
       return 1;
    }
    return 1;
}

dest()  {
  if(call_other(this_player(),"query_real_name",0) !="kain")  {
     return 1;  
  }
  return 0;  
}

wizzes() {
   object list;
   int i, level, invis, id_t;

    string name,ed,tab,idle;
    list = users();
     write("Name"+"\t\t"+"Level"+"\t"+"Invis"+"\t"+"Edit"+"\t"+"Idle\n");
   write("============================================\n");
     for(i=0; i <sizeof(list); i++)
     {
       name = capitalize (call_other(list[i], "query_real_name"));
       level = list[i]->query_level();
       invis = list[i]->query_invis();
       if( invis>999) {invis = 999;}        
       ed = " ";
       if (in_editor(list[i])){
       ed= "Ed";
       }   
     id_t = query_idle(list[i]);
     if(id_t/60 > 0 ) {
        if(id_t/60 < 10 )
            idle = id_t/60 + "m ";
        if(id_t/60 > 9 )
           idle = query_idle(list[i])/60 + "m ";
    }
    if(id_t < 10 && id_t && id_t != 0 )
        idle = id_t + "s ";
        if(id_t > 9 && id_t < 60)
           idle = id_t + "s ";
        if(id_t == 0 || !id_t)
           idle = "    ";
      tab = "\t";
     if(strlen(name) < 8) { tab = "\t\t";
     }
    if (level > 19)
   { write(name+tab+level+"\t"+invis+"\t"+ed+"\t"+idle+"\n"); }
   }
   return 1;
}

is_castle() {
return 1;
}

exit() {
  if(alarm == 0)  {
  invader = this_player()->query_real_name();
  say(invader + " has exited this room.\n");
  return 1;
  }
  return 1;
}

invite(str)  {
  if(!str)  {
     invited = "";
     return 1;
  }
  invited = str;
  write(invited + " is invited into the room\n");
  return 1;
}

force(str)  {
  object person;

  if(!str)  {
    write("you must specifiy a person to summon.\n");
    return 1;
  }
  person = find_player(str);
  if (!person)
    person = find_living(str);
  if (!person)  {
    write(str + " is not playing now.\n");
    return 1;
  }
  invited =str;
  tell_object(person,"You have been summoned by Kain to his crypt...\n");
  transfer(person,this_object());
  write(str + " has arrived via your command\n");
  return 1;
}

escort(str)  {
  object person;

  if(!str)  {
    write("you must specifiy a person to escort.\n");
    return 1;
  }
  person = find_player(str);
  if (!person)
    person = find_living(str);
  if (!person)  {
    write(str + " is not playing now.\n");
    return 1;
  }
  invited =str;
  tell_room(environment(person), "Kain steps out from the shadows.\n"+
                                 "Kain bows with vampiric grace.\n"+
                                 "Kain takes " + capitalize(str) +
                                 " by the arm and escorts her into the shadows.\n");
  transfer(person,this_object());
  tell_object(person,"You have been escorted by Kain to his crypt...\n");
    write(str + " has arrived via your command\n");
  return 1;
}

alarm()  {
  if(alarm == 0)  {
    alarm = 1;
    write("Alarm off\n");
  return 1;
  }
  alarm = 0;
  write("Alarm on\n");
  return 1;
}

fire() {
   if(lit == 0) {
   lit = 1;
   write("You gaze intently into the fireplace causing a spark to ignite.\n");
   say(capitalize(this_player()->query_name()) + " gazes intently into the fireplace..." +
                  "a spark ignites...\n");
   return 1;
   }
   lit = 0;
   write("You gaze intently into the smoldering fire...the flames intensify into a sultry blaze....\n");
   say(capitalize(this_player()->query_name()) + " gazes intently into the " +
                  "smoldering fire...the flames intensify into a sultry blaze....\n");
   return 1;
}


secure()  {
  if(secure == 1)  {
    secure = 0;
    write("Secure on\n");
    return 1;
  }
  secure = 1;
  write("Secure off\n");
  return 1;
}

stat(str)  {
  if(!str || str != "room")
    return 0;
  if(alarm == 0)
    write("Alarm on.\n");
  else
    write("Alarm off.\n");
  if(secure == 0)
    write("Room secured.\n");
  else
    write("Room open.\n");
  if(invited == "" || invited == 0)
    write("Nobody is invited into the room.\n");
  else
    write(invited + " is invited into the room.\n");
  return 1;
}

