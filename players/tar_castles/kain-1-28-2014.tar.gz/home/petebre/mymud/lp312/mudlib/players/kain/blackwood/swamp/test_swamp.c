inherit "room/room";

#define tp this_player()->query_name()

void init() {       
    int index;
    object venom;

    ::init();    

    index = random(2);
    if (index == 1){
        write("A very large venomous snake bites you and then slithers away!\n");
        say(tp + " is bitten by a large venomous snake! The snake slithers away.\n");
        venom = clone_object("players/kain/blackwood/misc/venom.c"); 
        move_object(venom,this_player()); 
        venom->set_venom(10);
        venom->start_venom();        
    }      
}
    
void reset(string arg) {    
    ::reset(arg);
    
	if(arg) {
        return;
	}
	
    set_light(1);
    short_desc=("Swamp");
    long_desc=
        "A dangerous swamp\n";
    items= ({
        "columns",
            "The fluted marble columns are set in a Greek Revival style and tower",
        "floor",
            "A gorgeous display of Italian marble and New Orleans craftsmanship",
        "portico",
            "The massive marble portico extends the entire front of the manor",
        "porch",
            "he massive marble portico extends the entire front of the manor",            
        "stairs",
            "The marble stairs lead down to the front yard",                        
        "windows",
            "The long windows are aglow from the large chandeliers hanging in each room",
        "pediment",
            "The pediment is difficult to see from here",
        "door",
            "The front door of the manor is large and heavy and made of solid oak.\n" +
            "It appears to be unlocked",
        "lights",
            "Many garden lights light up various areas of the house and yard"
        });
    dest_dir=
    ({
    "players/kain/blackwood/swamp/test2.c","east"
    });
}