inherit "obj/treasure";

reset(arg) {
 if(arg) return;
   set_short("A Mozart record");
    set_alias("record");
    set_long("This is a record of the Boston Symphany playing Mozart\n");
   set_weight(1);
    set_value(750);
}
 id(str) { return str == "record" || str == "ESP record"; }

