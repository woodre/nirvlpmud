inherit "room/room";
object obj;
reset(arg) {
	if(arg) return;
set_light(1);
short_desc=("Wiccan Hovel");
long_desc=
"As you walk into the hovel the aroma of fresh herbs and incense overwhelms\n"+
"you. Books line the shelves against the north wall. Against the eastern\n"+
"wall is what appears to be an altar of some sorts. Above the altar is\n"+
"something enscribed on a very old piece of cloth. A fire gently warms a\n"+
"a small cauldron. Hanging above the fireplace and cauldron is a pentacle.\n"+
"Burning candles are all that lights the room creating dancing figures on\n"+
"the surrounding walls.\n";
items=
({
"pentacle",
         "A circular disk which has a Pentagram engraved upon its surface.\n"+
         "It's a very decorative item which appears to have been put to much\n"+
         "use",
"altar",
         "The altar is round in design and appears to be a focal point of\n"+
         "worship and ritual. As you gaze over the altar certain items catch\n"+
         "your eye: candles, a chalice, some small idols, a small censor, and\n"+
		 "an ancient athame",
"candles",
         "The candles appear to be used for the purpose of spells and rituals.\n"+
         "The different colours have different properties of magick. Here you\n"+
         "notice black, grey, purple, and white candles",
"chalice",
         "An empty ritual cup made of stone",
"idols",
         "Small statues depicting the God and Goddess",
"censor",
         "A small container made of clay. It is used to ignite and burn incense\n"+
         "for rituals or spells",
"athame",
         "The athame is a ritual knife that is used to absorb and direct\n"+
         "energy. It is double edged with a black handle and is fairly dull\n"+
         "due to the fact that it is not used for physical cutting. The athame\n"+
		 "is never to be used as a weapon...and could possibly have negative\n"+
	     "effects if done so",
"cloth",
         "The cloth has been darkened with age and appears to be from ancient\n"+
         "times. Written upon the cloth are ancient runes and their symbols\n"+
         "The following runes appear on the cloth:\n"+
		 "		FEHU			URUZ			THURISAZ\n"+
		 "		ANSUZ			RAIDO			KANO\n"+
		 "		GEBO			WUNJO			HAGALAZ\n"+
		 "		NAUTHIZ			ISA			JERA\n"+
		 "		EIHWAZ			PERTH			ALGIZ\n"+
		 "		SOWOLU			TEIWAZ			BERKANA\n"+
		 "		EHWAZ			MANNAZ			LAGUZ\n"+
		 "		INGUZ			DAGAZ			OTHILA",
"cauldron",
         "The cauldron is used for mixing of herbs for healing or spells",
"books",
         "A book shelf lined with many ancient books of spells and rituals",
"shelves",
         "A book shelf lined with many ancient books of spells and rituals",
});
dest_dir=
({
"players/kain/d-places/.c","out",
});
}