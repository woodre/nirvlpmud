inherit "room/room";

object monster;

void reset(status arg) {
    ::reset(arg);

    if (arg == 1) {
        if (!monster) { 
            monster = clone_object("/players/kain/blackwood/mobs/child_ghost.c"); 
            move_object(monster, this_object()); 
        }
        return;
	}    
          	
	set_no_clean(1);
    set_light(1);
    short_desc=("The Upper Hall");
    long_desc=
         "The upper hall has 3 doors on the east wall, and, due to the staircase\n" +
        "rising against the west wall, only two on that side. The first door on\n" +
        "the west is a bedroom that is two rooms deep, and the last door on the\n" +
        "west leads to a bedroom on the rear of the house. Two of the three\n" +
        "bedrooms on the east side appear to be uninhabited right now. The third\n" +
        "bedroom appears to be occupied. The hallway is lit by gasoliers, with\n" +
        "brass arms and cut crystal cups for their bulbs. Marble mantlepieces run\n" +
        "along either side of the hall and gilded mirrors and portraits are seen\n" +
        "wherever one turns.\n";
    items= ({
        "gasoliers",
            "The gasoliers, with brass arms and cut crystal cups for their bulbs, are\n" +
            "more ordinary yet more atmospheric than the sumptuous crystal chandeliers\n" +
            "of the first floor",
        "mantlepieces",
            "Each marble mantlepiece-one snow white and the other of black and gold-has\n" +
            "its distinct detail",       
        "mantlepiece",
            "Each marble mantlepiece-one snow white and the other of black and gold-has\n" +
            "its distinct detail",       
        "mirrors",
            "Huge gilded mirrors are hung along the hallway",
        "portraits",
            "Huge proud portraits of ancestors-William and his wife, pretty Grace;\n" +
            "Gravier and his wife, Blessed Alice; and Thomas and his wife, Sweetheart",
    });

    dest_dir= ({
        "players/kain/blackwood/manor/main_hall.c","down",
        "players/kain/blackwood/manor/attic.c","up",
        "players/kain/blackwood/manor/upper_hall2.c","north",
        "players/kain/blackwood/manor/brittanys_room.c","east",
        "players/kain/blackwood/manor/upper_hall3.c","south",
        "players/kain/blackwood/manor/quinns_room.c","west"
    });
    
    monster = clone_object("/players/kain/blackwood/mobs/child_ghost.c"); 
    move_object(monster, this_object()); 
}