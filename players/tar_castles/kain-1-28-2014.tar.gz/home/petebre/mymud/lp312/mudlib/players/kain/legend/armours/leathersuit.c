inherit "obj/armor";

reset(arg) {
    ::reset(arg);
    set_name("leathersuit");
    set_alias("suit");
    set_short("A leather suit");
    set_long("A very thin but remarkably strong leather suit.  It is\n") +
            ("stitched together by hemp and will withstand many blows.\n");
    set_type("armor");
    set_ac(3);
    set_weight(3);
    set_value(110);
}
