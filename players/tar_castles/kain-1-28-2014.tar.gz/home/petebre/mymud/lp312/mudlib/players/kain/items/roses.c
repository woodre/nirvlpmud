long() {
    write("A gorgeous boquet of a dozen long stem red roses.\n");
}

short() {
    return "A dozen long stem red roses";
}

query_weight() {
    return 1;
}

query_value() {
    return 1;
}

init() {
    add_action("smell"); add_verb("smell roses");
    add_action("smell"); add_verb("smell");
add_action("smell"); add_verb("smell flowers");
}

smell() {
    write("A beautiful smelling aroma takes over your senses.\n");
    return 1;
}



get() {
    return 1;
}

id(str) {
    return str == "roses";
}
