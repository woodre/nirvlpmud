inherit "obj/armor";

reset(arg) {
    ::reset(arg);
    set_name("hide");
    set_alias("deerhide");
    set_short("A deer hide");
    set_long("A thick fury leather deer hide. This was clearly made by\n") +
            ("a very honourable hunter. This is to be worn with pride.\n");
    set_type("armor");
    set_ac(2);
    set_weight(2);
    set_value(random(10)+45);
}
