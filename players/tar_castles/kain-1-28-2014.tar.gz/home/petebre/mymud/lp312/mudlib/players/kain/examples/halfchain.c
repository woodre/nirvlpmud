inherit "obj/armor";
reset(arg){
   ::reset(arg);
   set_name("half chain");
   set_short("A suit of half chain");
   set_alias("chain");
   set_long("A suit of fine steel half chain.\n");
   set_ac(3);
   set_weight(3);
   set_value(300);
}
