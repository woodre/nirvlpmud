#define NQC room

inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="An enchanted land.";
   long_desc=
      "You are standing on a ledge looking over a vast and beautiful\n"+
      "landscape.  Roses...tinted with the slightest hints of peach\n"+
      "spread to the left and to the right.  Weeping willows sagging with\n"+
      "their charming sorrows, covered with spanish moss, encircle you\n"+
      "giving a feeling of comfort.  At your feet is a small mushroom\n"+
      "patch.  The sun is just setting giving off a breathtaking pink,\n"+
      "purple, and red sky...the colours intertwining.  Butterflies\n"+
      "dance from flower to flower spreading their seeds of life.  \n"+
      "Looking over the ledge you see a pool of sparkling green water\n"+
      "without a ripple to be had.  Surrounding the pool is layer of \n"+
      "yellow and white lillies...dragonflies hovering and darting\n"+
      "about.  A truly magical place...created with love.\n";
   dest_dir=({
      "/players/kain/workroom.c","back",
   });
   items=({
      "roses",
         "These roses spread as far as the eye can see.  The aroma\n"+
         "is overwhelmingly beautiful.  The flowers are tinted with\n"+
         "the perfect shades of the palest peach",
      "mushrooms",
         "A small mushroom patch.  Each is a bright orange with small\n"+
         "yellow and red spots.  A feeling of magic comes over you as\n"+
         "you gaze upon this small but mystique garden",
      "willows",
         "The willows with their sadness and sorrows weep amongst \n"+
         "themselves.  Each branch hung in perfect harmony.  A \n"+
         "truly enchanting scene",
       "pool",
         "The pool is as still as the night and green as emeralds.\n"+
         "Surrounding the pool is a layer of lillies floating with a \n"+
         "innocence unheard of",
       "butterflies",
         "Dancing about from flower to flower is wide vareity and\n"+
         "sizes of butterflies.  In their purity...they are unhindered \n"+
         "with the knowlege of knowing nothing would harm them here",
       "dragonflies",
         "Dragonflies hover and dart about in a playful manor",
       
   });
}

realms() { return "NT"; }

init() {
   ::init();
   this_player()->set_spell_block(1);
}

exit() {
   this_player()->set_spell_block(0);
}

