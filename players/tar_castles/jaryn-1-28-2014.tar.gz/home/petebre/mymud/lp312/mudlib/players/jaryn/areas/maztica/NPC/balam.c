
#include "/players/jaryn/closed/define.h"
inherit "/players/vertebraker/closed/std/monster.c";

id(str) { return str == "balam" || str == "envoy"; }
reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;
set_name("uzdrek");
set_race("human");
MOCO("/players/forbin/hyperion/keats/ARM/uzdrek_robe.c"),TO);
init_command("wear robe");
set_short("Uzdrek, Outfitter Extraordinaire");
set_long("  Uzdrek is a scraggy old man, his mop of hair and long beard\n"+ 
         "grizzled from age.  He wears a dusty, old robe - a clear mark of\n"+ 
         "his ancestry on the planet of Qom-Riyadh.  After the riots and\n"+ 
         "fall of the New Prophet, Uzdrek left the reality of his youth in\n"+ 
         "search of a place more immune to the war and fanaticism of his\n"+ 
         "homeworld.  With limitless knowledge of the lands of Hyperion\n"+ 
         "and the outdoors in general he can help to prepare oneself for\n"+ 
         "any expedition.  You may 'ask' him for information.  He has also\n"+
         "been known to trade for certain items.\n");
set_level(17);
set_hp(450);
set_al(250);
set_wc(24);
set_ac(14);
set_aggro(0, 0, 0);
set_dead_ob(this_object());
set_chat_chance(15);
  load_chat("Uzdrek exclaims, \"Welcome to Wildeland Outfitters!\"\n");
  load_chat("Uzdrek asks, \"May I help you?\"\n");
  load_chat("Uzdrek asks, \"If you'd but ask, I've many things to tell.\"\n");
  load_chat("Uzdrek shuffles about the store straightening and replacing items.\n");
set_a_chat_chance(15);
  load_a_chat("Help! Crooks!\n");
  load_a_chat("Somone call the Defense Force.  HURRY!\n");
gold = clone_object("obj/money");
gold->set_money(random(100));
move_object(gold,this_object());
}
init()
  {
  add_action("what_i_can_tell_you_about","ask");
  add_action("give_specific_info","inquire");
  }
what_i_can_tell_you_about(arg)
  {
  if(!arg || arg == "uzdrek")
    {
    write("  After rubbing his chin for a moment, Uzdrek whispers in a \n"+
          "gravelly voice:                                             \n"+
          "    \"Well, I know much about this planet and the           \n"+
          "     greater world in general - but I will stick            \n"+
          "     to explaining "+HIW+"Hyperion"+NORM+".  I can tell you many           \n"+
          "     things about our planet.  I know some of the           \n"+
          "     history of "+HIW+"Keats"+NORM+", much about the deadly "+HIW+"Flame          \n"+
          "     Forest"+NORM+", the "+HIW+"Sea of Grass"+NORM+", the "+HIW+"Bridle Range"+NORM+",            \n"+
          "     the "+HIW+"City of Poets"+NORM+", "+HIW+"Chronos Keep"+NORM+", and a bit             \n"+
          "     about the forboding "+HIW+"Time Tombs"+NORM+".  The most              \n"+
          "     important topic I can discuss is the "+HIR+"Shrike"+NORM+".           \n"+
          "     If you are curious, just 'inquire of' a topic          \n"+
          "     and I will tell you what I can.\""+NORM+"                      \n");
      return 1;
    }
  }
give_specific_info(arg)
  {
  if(!arg) return info_hyperion();
  if(arg == "hyperion" || arg == "of hyperion") return info_hyperion();
  if(arg == "keats" || arg == "of keats") return info_keats();
  if(arg == "forest" || arg == "of forest" || arg == "flame forest" || arg == "of flame forest") return info_flameforest();
  if(arg == "grass" || arg == "sea of grass" || arg == "of grass" || arg == "of sea of grass") return info_seaofgrass();
  if(arg == "range" || arg == "bridle range" || arg == "of range" || arg == "of bridle range") return info_bridlerange();
  if(arg == "city" || arg == "city of poets" || arg == "of city" || arg == "of city of poets" || arg == "of poets") return info_cityofpoets();
  if(arg == "keep" || arg == "chronos keep" || arg == "of keep" || arg == "of chronos keep") return info_chronoskeep();
  if(arg == "tombs" || arg == "time tombs" || arg == "of tombs" || arg == "of time tombs") return info_timetombs();
  if(arg == "shrike" || arg == "the shrike" || arg == "of shrike" || arg == "of the shrike") return info_shrike();
  else write("I don't know anything about that.\n");
    return 1;
  }
info_hyperion()
  {
  write("  Uzdrek smiles, and says:                                  \n"+
        "    \"Ahh...Hyperion.  A really lovely planet - don't you   \n"+
        "    think?  Far in the outback of the solar system, it      \n"+
        "    was largely unexplored and uninhabited until the time   \n"+
        "    of the large Hawking-drive seedships.\"                 \n"+
        "                                                            \n"+
        "    \"The first settlers of the planet noticed many strange \n"+
        "    and dangerous areas.  It is best to let common sense    \n"+
        "    and caution be your guide while you visit.\"            \n");
    return 1;
  }
info_keats()
  {
  write("  Uzdrek smiles, and says:                                 \n"+
        "     \"Ahh...Keats.  What a grand city is was and still is   \n"+
        "     for the most part.  Sad King Billy, his royal high-   \n"+
        "     ness, founded the city several decades after his      \n"+
        "     failed attempt to create a city of artisans far to    \n"+
        "     the north.\"                                            \n"+
        "                                                           \n"+
        "     \"You can find many helpful people in town, so look     \n"+
        "     around - perhaps you will learn more.\"                 \n");  
    return 1;
  }
info_flameforest()
  {
  write("  A stark look comes over Uzdrek and he whispers:           \n"+                      
        "     \"The flame forest is a very dangerous place to tread.   \n"+
        "     At times, great electrical storms rage there - due     \n"+
        "     to the forests of Tesla trees there.  The forest lies  \n"+
        "     scorched and barren most of the time due to this -     \n"+
        "     although there are many species that thrive there.\"     \n"+
        "                                                            \n"+
        "     \"It is the wrong time of year to travel there - the     \n"+
        "     storms are at a peak now.  Perhaps later in the year,  \n"+
        "     if you find the right guide, someone will take you     \n"+
        "     there.\"                                                 \n");
    return 1;
  }
info_seaofgrass()
  {
  write("  Uzdrek looks you over and exclaims:                     \n"+            
        "     \"You don't look big enough for that tale yet!  I will \n"+
        "     not tell you things that might lead to your death.\"   \n");
    return 1;
  }
info_bridlerange()
  {
  write("  Uzdrek looks you over and exclaims:                     \n"+            
        "     \"You don't look big enough for that tale yet!  I will \n"+
        "     not tell you things that might lead to your death.\"   \n");
    return 1;
  }
info_cityofpoets()
  {
  write("  Uzdrek smiles, and says:                                  \n"+
        "   "+HIW+"\"Ahh...the City of Poets.  It was to be the 'original'  \n"+
        "     site for Keats - took Sad King Billy's android         \n"+
        "     laborers a solid 9 years or more of work to build.     \n"+
        "     I've never been there myself, but it's rumored to      \n"+
        "     have magnificent white spires and a glorious           \n"+
        "     architecture.  Legend has it that it is now inhabited  \n"+ 
        "     by headless ghosts and other creatures of the night!   \n"+
        "     I'd dare not to go.\"                                   \n"+
        "                                                            \n"+
        "    \"It is far to the north - over the Bridle Range, and    \n"+
        "     the time of year is wrong for a trip there.\""+NORM+"          \n");
    return 1;
  }
info_chronoskeep()
  {
  write("  Uzdrek looks you over and exclaims:                     \n"+            
        "     \"You don't look big enough for that tale yet!  I will \n"+
        "     not tell you things that might lead to your death.\"   \n");
    return 1;
  }
info_timetombs()
  {
  write("  Uzdrek looks you over and exclaims:                     \n"+            
        "     \"You don't look big enough for that tale yet!  I will \n"+
        "     not tell you things that might lead to your death.\"   \n");
    return 1;
  }
info_shrike()
  {
  write("  Uzdrek, with an almost frightened look, speaks:            \n"+                 
        "     \"That creature is the machination of the great evil.     \n"+
        "     Every year, a group of pilgrims sponsored by the        \n"+
        "     Church of the Final Atonement (the Shrike Church)       \n"+
        "     travel beyond the Sea of Grass and Bridle range, past   \n"+
        "     Chronos Keep and the City of Poets - to the Time Tombs. \n"+
        "     None have ever returned.\"                                \n"+
        "                                                             \n"+
        "     \"It has been said that it can bend time with its will,   \n"+
        "     and that it impales anyone it finds upon a metal tree   \n"+
        "     of thorns.\"                                              \n"+
        "                                                             \n"+
        "     \"Forged of quicksilver itself - the only sign of life    \n"+
        "     within the creature is said to be the two glowing eyes.\" \n"+
        "                                                             \n"+
        "     \"It used to be teathered to tombs by a powerful field.   \n"+
        "     Since the Time Tombs have begun opening, and the field  \n"+
        "     has weakened - the Shrike's range has increased.\"        \n"+
        "                                                             \n"+
        "     \"I WOULD AVOID THE SHRIKE AT ALL COSTS!\"                  \n");
    return 1;
  }
monster_died() 
{
  tell_room(environment(this_object()), "\nWith his dying breath, Uzdrek gasps, \"Why have you done this?\"\n\n");
return 0; }
