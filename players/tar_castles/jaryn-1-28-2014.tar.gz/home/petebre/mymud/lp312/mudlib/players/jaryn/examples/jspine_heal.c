#include "/players/forbin/define.h"
inherit "/obj/generic_heal.c";

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_name("barb");
  add_alias("goo");
  set_short(""+GRN+"-=-=-="+NORM+""+HIW+"a Spine barb"+NORM+""+GRN+"=-=-="+NORM+"");
  set_long("A sharp barb broken off from a "+GRN+"juvenile.\n"+
           "Spine"+GRN+" from the looks of it.  It has a sticky\n"+
           "goo inside that you could 'suck' out.\n");
  set_type("drink");
  set_msg(
          "You put your mouth around the open end of the barb\n"+
          "and suck the goo out.  YUCK!  It has a bitter taste\n"+
          "to it, but you feel a little better.\n");
  set_msg2(" sucks the Spine barb dry.\n");
  add_cmd("suck");
  set_heal(20,20);
  set_charges(1);
  set_soak(25);
  set_stuff(25);
  set_intox(25);
  set_value(250);
}
  get() 
  {
    if(this_player() && (query_verb() == "get" || query_verb() == "take"))
    {
      this_player()->hit_player(random(15));
      write("You prick your finger on the "+GRN+"barb"+NORM+" - OUCH!.\n");
      return 1;
    }
   return ::get();
}

query_save_flag(){
  return 1;
  }
