/*     Jaryn's teller Device				*/
/*     /players/jaryn/closed/jtell.c			*/
/*									*/
/*     Created by:   Jaryn					*/
/*     Create date:  aug2003.17				*/
/*     Last mod:	   aug2003.17				*/

/*     Taken and modified with permission from		*/
/*     Forbin's wiztell.					*/

#include "/players/jaryn/closed/define.h"

id(str) { return str == "teller" || str == "jtell" || str == "collar"; }

extra_look() { write(RED+"Bloody"+NORM+" bite marks of "+HIK+"-=Jaryn=-"+NORM+"\n"); }

short() { write(HIK+"Sp"+HIW+"ik"+HIK+"ed Sl"+HIW+"av"+HIK+"e Co"+HIW+"ll"+HIK+"ar"+NORM+" (worn)\n"); }

long() { 
    write("This marks you as a servant of Jaryn. You may use this\n"+
       "to communicate telepathically with him if he is around.\n"+
       "Use 'jtt' to talk with him.\n");}

init() {
  add_action("cmd_st", "jtt");
}

drop(){
  write("No drop!\n");
  return 1; 
}

cmd_st(str) {
  object sob;
  string what;
  sob = find_player("jaryn");
  if(!sob) 
    {
      notify_fail(""+HIR+"Jaryn is not logged on."+NORM+"\n"+NORM);
      return 0; 
    }
  if(in_editor(sob)) {
    notify_fail(""+HIW+"Jaryn is busy.\nTry again later."+NORM+"\n");
    return 0; 
  }
   write(""+HIK+"You commune with Jaryn: "+HIW+str+NORM+"\n");
   what = ""+HIK+"<<<< ["+HIW+this_player()->query_name()+NORM+HIK+"] >>>> "+HIW+str+HIK+""+NORM;
  tell_object(sob,what+"\n");
  return 1; 
}



