inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(1);

short_desc = "Outskirts of Barovia";
long_desc =
"  This is an old dirt road that runs through the borough of Barovia.\n"+
"Ramshackle buildings are sparcely scattered among the remains of this\n"+
"once proud town. There is a stillness that permeates the air owing to\n"+
"the darkness that enshrouds the area. Faint lights seems to come from\n"+
"a northernly direction, whereas to the south the road seems to disappear\n"+
"into the blackness. \n";

items = ({
"dirt","It is very old and seemingly not much trodden",
"road","Large animal tracks abound in the coarse dirt",
"borough","Dilapidated buildings showing the wear of ages",
"buildings","Rundown and falling appart",
"darkness","The sky is in a state of permanent midnight",
"blackness","It seem to be almost tangible",
});

dest_dir = ({
"players/jaryn/workroom","out",
});

}

init() {
  ::init();
  add_action("Listen_here","listen");
}

Listen_here(str) {
 if(!str || str != "stillness") {notify_fail("You listen to the wind "+
 "but hear nothing of importance.\n");
 return 0; }
 if(str=="stillness") { write("You listen to the stillness in the air and become "+
 "aware of a growing power radiating through the area.\n");
 return 1; }
}
