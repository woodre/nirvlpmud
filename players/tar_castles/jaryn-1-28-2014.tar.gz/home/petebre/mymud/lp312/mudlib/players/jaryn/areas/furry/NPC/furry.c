#include "/players/jaryn/closed/define.h"
inherit "obj/monster.c";
#define ETO environment(this_object())

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("Furry");
set_alias("cat");
set_alt_name("furry");
set_short(YEL+"A Furry"+NORM);
set_long(
  "This beast looks almost catlike. Its fur is long and feels like silk.\n"+
  "Its small, pointy ears and long tail resemble that of a cat, and that is where\n"+
  "the semblance ends. Long fangs protrude from its gapping maw like those of a\n"+
  "sabertooth tiger. Slanted eyes emit a sickly green glow. Three inch claws\n"+
  "dig into the dirt like a hot knife through butter. Its makes a loud howling\n"+
  "sound as it leaps toward you!\n");

set_race("cat");
set_level(14+random(4));
set_hp(250+random(250));
set_al(-500);
set_wc(25+random(10));
set_ac(7+random(5));
set_heal(5,1);
set_aggressive(1);

set_chat_chance(10);
  load_chat("The "+YEL+"furry"+NORM+" glares at you with unnatural "+HIG+"eyes"+NORM+". \n");
set_a_chat_chance(25);
  load_a_chat("The "+YEL+"furry"+NORM+" howls as it attacks viciously. \n");

set_chance(25);
set_spell_dam(25+random(25));
set_spell_mess1(
  "The "+YEL+"furry"+NORM+" jumps on its attacker's chest!\n"+
  "The "+YEL+"furry"+NORM+" sinks "+HIW+"fangs"+NORM+" into its attacker's throat!\n"+
  "                      "+RED+"B L O O D         G U S H E S"+NORM+"\n");
set_spell_mess2(
  "The "+YEL+"furry"+NORM+" jumps on your chest!\n"+
  "The "+YEL+"furry"+NORM+" sinks "+HIW+"fangs"+NORM+" into your throat!\n"+ 
  "                      "+RED+"B L O O D         G U S H E S"+NORM+"\n");

set_chance(10);
set_spell_dam(10+random(15));
set_spell_mess1(
  "Razor sharp "+HIW+"claws"+NORM+" swipe at its attacker's abdomen!\n"+
  "The "+YEL+"furry"+HIR+" RIPS OUT"+NORM+" a hunk of its attacker's "+HIY+"flesh"+NORM+" \n");
set_spell_mess2(
  "Razor sharp "+HIW+"claws"+NORM+" swipe at your abdomen!\n"+
  "The "+YEL+"furry"+HIR+" RIPS OUT"+NORM+" a hunk of your "+HIY+"flesh"+NORM+" \n");
}

monster_died() {
move_object(clone_object("/players/eurale/area/OBJ/item.c"),ETO);
tell_room(ETO,"msg\n");
return 0; }
