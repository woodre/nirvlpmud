#include "/players/jaryn/defs.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "Castle Foyer";
long_desc =
  "  Once this great entrance hall must have been splendorous, but now it\n"+
  "is nothing more than stone and rubble. Twin staircases glide down from\n"+
  "the second floor and a large fireplace spans the western wall. Decayed\n"+
  "remains of banners and tapestrys sway in a light wind comming through\n"+
  "dozens of cracks in the stone walls. Rooms lead further into the ruins\n"+
  "to the north and east. The moaning sounds louder here.\n";

items = ({
  "hall","Once able to hold hundreds of people, now holds only bits of stone",
  "stone","Pieces of the walls and ceiling that have crumbled with time",
  "rubble","Broken chairs and pieces of furniture crushed under stone",
  "staircases","Mahogony banisters with polished stone steps, now rotten and crumbling",
  "fireplace","Taking up the whole eastern wall, it seems to have not been lit in ages",
  "banners","Decayed fabric, the faded emblems cannot be read",
  "tapestrys","Scenes of vicious battles and tranquil forest settings, now torn and faded",
  "cracks","Weather worn holes in the castle walls",
  "walls","In serious need of repair, it is frightening to know they still stand",
});

dest_dir = ({
  "players/jaryn/areas/forlorn/f3a.c","north",
  "players/jaryn/areas/forlorn/f3b.c","east",
});

}

init() {
  ::init();
  add_action("Search_here","search");
  add_action("Listen_here","listen");
}

Search_here(str) {
if(!str) { write("Search what?\n"); return 1; }
if(str != "fireplace") {
  write("You search the "+str+" but find nothing special.\n");
  return 1; }
if(str == "fireplace") {
  write("You search the fireplace and feel a TERRIBLE pain!\n");
  TP->add_spell_point(-3);
  TP->add_hit_point(-random(5));
  TP->heal_self(-random(7));
  return 1; }
}

Listen_here(str) {
if(!str || str != "moaning") {notify_fail("You listen to the wind "+
"but hear nothing of importance.\n");
return 0; }
if(str=="moaning") { write("You hear horrible sounds comming from the second floor.\n");
return 1; }
}
