#include "/players/jaryn/closed/define.h"
inherit "obj/monster.c";
#define ETO environment(this_object())

reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("testmob");
set_alias("tester");
set_alt_name("testermob");
set_short("A Testmob ");
set_long(
  "desc \n");

set_race("creature");
set_level(20);
set_hp(2000);
set_al(0);
set_wc(10);
set_ac(40);
set_heal(5,1);
set_aggressive(0);
set_dead_ob(this_object());

set_chat_chance(15);
  load_chat("not fighting \n");
set_a_chat_chance(15);
  load_a_chat("attack chat \n");

set_chance(10);
set_spell_dam(30);
set_spell_mess1(
  "others \n");
set_spell_mess2(
  "figher \n");

}

monster_died() {
return 0; }
