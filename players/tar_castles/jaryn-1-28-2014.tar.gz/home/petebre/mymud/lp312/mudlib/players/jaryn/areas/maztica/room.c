#include "/players/jaryn/closed/define.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(1);

short_desc = "Furry";
long_desc =
  "Long description.\n";

items = ({
  "item","Item description",
});

dest_dir = ({
  "players/jaryn/areas/furry/rm","north",
  "players/jaryn/areas/furry/rm","south",
  "players/jaryn/areas/furry/rm","east",
  "players/jaryn/areas/furry/rm","west",
});

}

init() {
  ::init();
  add_action("Search","search");
  add_action("Listen","listen");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing of importance.\n");
  return 1; }

Listen(str) {
if(!str) { write("Listen to what?\n"); return 1; }
  write("You listen to the "+str+" but hear nothing of importance.\n");
  return 1; }
