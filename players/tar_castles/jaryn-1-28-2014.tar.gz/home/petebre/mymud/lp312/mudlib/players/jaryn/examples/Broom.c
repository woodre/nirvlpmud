#include "/players/linus/def.h"  /* This basically provides for short-cuts in the code.  I set up my 
own.  Some people do their own definitions in each file. see below for an example */
/* #define TP this_player() */
inherit "/room/room.c"; /* This is the basic template of the room.  You can look at
the full room version by 'more /room/room.c' */
reset(arg) { /* This resets the room at whatever intervals the game dictates */
    { 
     if(!find_living("Linus_owns_this_tigger")) {
      MO(CO("/players/linus/Newbie/NPC/Tigger.c"),TO);
    }
/* This checks to see if my Tigger mob is in the game (he wanders), and if not, it'll clone a new one to this room */
      set_light(1); /* Sets light level.  1 == lit, 0 == dark */
 /* short_desc is what you see in brief mode...or in 'who2' */
     short_desc = GRN+"The hundred acre wood"+NORM;
 /* long_desc is what you see when you 'look' in a room */
     long_desc = GRN+
  "Tall trees stretch to the sky in all directions, standing on a\n"+
  "carpet of green grass.  A small dirt footpath meanders around the\n"+
  "trees.  A small walkway can be seen leading to a small door, which\n"+
  "is in a large maple tree.  A small roof stretches out to cover the\n"+
  "doorway, and a pair of mailboxes stand to the side of the walkway.\n"+
  "The names 'Kanga' and 'Roo' are scribbled onto the sides of them.\n"+NORM;

/* items are the individual descrips of what you can look at within a room */
    items = ({
         "tree","A large maple tree",
         "trees","Mostly oak trees, but there are others growing here too",
         "grass","Tall green grass",
         "mailboxes","Small wooden mailboxes.  The names Kanga and Roo are written on the sides",
         "boxes","Small wooden mailboxes.  The names Kanga and Roo are written on the sides",
         "mailbox","A small wooden mailbox with a name scribbled on the side",
         "footpath","Brown dirt where grass will no longer grow",
         "path","Brown dirt where grass will no longer grow",
         "walkway","Hard packed dirt where grass no longer grows",
         "way","Hard packed dirt where grass no longer grows",
         "roof","A small shingled roof that protects the doorway",
         "doorway","A small wood-framed doorway that houses a small wooden door",
         "door","A small door that is made from wood.  You could probably 'enter' the 'house' through this door"  }); 
 /* dest_dir are the exits */
 /* as you can see I have "NEWB+"n4.c"  in my def.h I have #define NEWB /players/linus/Newbie/ defined as a shortcut */
    dest_dir = ({
         NEWB+"n2.c","south",
         NEWB+"n4.c","north"
          });
}
}
/* This sets up for add_action use */
/* add_actions are things you can do that aren't obvious in the room i.e. read/enter/listen etc */
init() {
 ::init();
 add_action("enter_house","enter");
 add_action("Listen","listen");
 add_action("read_stuff","read");
 /* note that there are two different definitions.  The first one the game uses, the 2nd is what the player types.  They can be the same, I just like to do different ones to be safe */
}
 /* Below is the defined actions.  This is for entering the house.  The 'if' compares the 'str' you give
i.e. 'enter house'.  the ! is no.  So if(!str) == if(no str)  the || is 'or' and != is not equal so it
is checking 2 things.  if no string given, or string is not 'house' then it'll return 'Enter what?'
FAIL is notify_fail.  return 0; means that if there's another add_action in the room for enter it'll check it too.  the 2nd if statement is for 'enter house'.  If so, it moves the player to the specified path.  'into the house is what is displayed to the room i.e. Jaryn leaves into the house is what I'd see.  And it moves you 
to the room. */
enter_house(string str){
   if(!str || str!="house") { FAIL("Enter what?\n"); return 0; }
   if(str=="house"){
  write("You open the door and enter the house.\n");
  TP->move_player("into the house#"+NEWB+"n3a.c");
 return 1;
}
}
Listen() {
 write("The chirping songs of birds from within the forest can be heard.\n");
 return 1;
}
read_stuff(string str) {
 if(!str || str!="mailboxes" && str!="mailbox" && str!="boxes" && str!="box") { FAIL("Read what?\n"); return 0; }
 if(str=="mailboxes" || str=="mailbox" || str=="boxes" || str=="box") {
     write("The mailboxes read: Kanga and Roo.\n");
     return 1;
}
}
