#include "/players/linus/def.h"
#define ENVQN environment()->query_name()
#define ENVQP environment()->query_possessive()
inherit "/obj/treasure.c";
reset (arg) {
      set_id("Lring");
      set_weight(1);
}
extra_look() {
 if(ENV()==TP)
 write("You have a small"+YEL+" gold ring "+NORM+"in your left eyebrow.\n");
 else
 write(ENVQN+" has a small"+YEL+" gold ring "+NORM+"in "+ENVQP+" left eyebrow.\n"); }
drop(){
  return 1;
}
query_auto_load() { return "players/linus/stuff/ring.c:"; }
