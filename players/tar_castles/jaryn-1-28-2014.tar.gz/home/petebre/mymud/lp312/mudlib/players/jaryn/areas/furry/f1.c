#include "/players/jaryn/closed/define.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(1);

short_desc = GRN+"Dalyan Forest"+NORM;
long_desc =
  GRN+"    Dusk sweeps its dying light over the old trees. Leaves cover the cold\n"+
  "earth like a glove. The ground seems soft and slightly moist as if a light\n"+
  "rain had come and gone swiftly. A road leads east and west along the tree\n"+
  "line. An abandoned house sits silently to the south.\n"+NORM;

items = ({
  "dusk","A mosaic of purple, pink, yellow and orange peaking faintly through the clouds",
  "light","A brilliant mosaic of colors that gleam through the trees",
  "trees","Lush and full of life, are these oak, pine and maple trees",
  "leaves","Still green and healthy, the leaves are soft underfoot",
  "earth","Soft and moist, it is also cool and wet to the touch",
  "ground","The dirt is wet and almost muddy",
  "rain","Cold and fresh drops are still falling from the nearby trees",
  "road","A muddy dirt road heading through the village of Dalyan",
  "house","Hard to see from here, it seems to be deserted"
});

dest_dir = ({
  "players/jaryn/areas/furry/rm","north",
  "players/jaryn/areas/furry/f2.c","south",
  "players/jaryn/areas/furry/rm","east",
  "players/jaryn/areas/furry/rm","west",
});

}

init() {
  ::init();
  add_action("Search","search");
  add_action("Listen","listen");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing of importance.\n");
  return 1; }

Listen(str) {
if(!str) { write("Listen to what?\n"); return 1; }
  write("You listen to the "+str+" but hear nothing of importance.\n");
  return 1; }
