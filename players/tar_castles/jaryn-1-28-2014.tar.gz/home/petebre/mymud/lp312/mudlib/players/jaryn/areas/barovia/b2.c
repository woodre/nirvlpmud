#include "/players/jaryn/defs.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(1);

short_desc = "Barovia Village Square";
long_desc =
  "  Barovia's town square seems little more than the center of a small\n"+
  "rundown shanty town. It seems a good wind might blow it all away at\n"+
  "a moments notice. Boards cover the few windows among the shacks, as if\n"+
  "trying to keep someone or something out. Directly to the west, a larger\n"+
  "building sits among the hovels. It looks to be an Inn of some sort. To the\n"+
  "east across the dirt road lies another distinct building from which hangs a\n"+
  "small sign. The old dirt road continues on in a north/south direction.\n";

items = ({
  "item","Item description",
});

dest_dir = ({
  "players/jaryn/areas/barovia/rm","north",
  "players/jaryn/areas/barovia/rm","south",
  "players/jaryn/areas/barovia/rm","east",
  "players/jaryn/areas/barovia/rm","west",
});

}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing of importance.\n");
  return 1; }
