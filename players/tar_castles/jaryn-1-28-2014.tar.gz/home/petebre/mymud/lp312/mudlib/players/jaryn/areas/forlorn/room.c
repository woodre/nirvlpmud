#include "/players/jaryn/defs.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(1);

short_desc = "Barovia";
long_desc =
  "Long description.\n";

items = ({
  "item","Item description",
});

dest_dir = ({
  "players/jaryn/areas/barovia/rm","north",
  "players/jaryn/areas/barovia/rm","south",
  "players/jaryn/areas/barovia/rm","east",
  "players/jaryn/areas/barovia/rm","west",
});

}

init() {
  ::init();
  add_action("Search","search");
  add_action("Listen_here","listen");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing of importance.\n");
  return 1; }

Listen_here(str) {
if(!str || str != "stillness") {notify_fail("You listen to the wind "+
"but hear nothing of importance.\n");
return 0; }
if(str=="stillness") { write("You listen to the stillness in the air and become "+
"aware of a growing power radiating through the area.\n");
return 1; }
}
