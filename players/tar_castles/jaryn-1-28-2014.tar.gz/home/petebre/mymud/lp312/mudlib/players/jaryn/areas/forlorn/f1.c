#include "/players/jaryn/defs.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "Forlorn Ruins";
long_desc =
  "  Dark forest surrounds this lowland area. The ruins of an old castle\n"+
  "extend from the ground like a lone skeletal hand. Wind blows strongly\n"+
  "through the twisting remains and a moaning sound can be faintly heard.\n"+
  "Darkness rules the sky while an eerie mist creeps through the ruins to\n"+
  "enclose the area making the visibility of the outer area impossible. A\n"+
  "wall of the mist extends to the south as if inviting entrance.\n";

items = ({
  "forest","The trees here are a twisted shell of thier former glory",
  "area","Flat and muddy with no sign of life anywhere",
  "ruins","Ancient and crumbling, it could fall at any moment",
  "castle","Once a great landmark, this castle is nothing but twisted ruins now",
  "sky","It is in a state of permanent midnight",
  "mist","It flows over everything as if alive and seeking nourishment",
  "wall","A wall of eerie mist, it looks like you can pass through it",
});

dest_dir = ({
});

}

init() {
  ::init();
  add_action("Search","search");
  add_action("Listen_here","listen");
  add_action("Enter_ruins","enter");
  add_action("Pass_through_mist","pass");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing of importance.\n");
  return 1; }

Listen_here(str) {
if(!str || str != "moaning") {notify_fail("You listen to the wind "+
  "but hear nothing of importance.\n");
return 0; }
if(str=="moaning") { write("You hear the sound of a soul in great suffering.\n");
return 1; }
}

Enter_ruins(str) {
if(!str || str != "ruins") {notify_fail("Enter what??\n");
return 0; }
if(str=="ruins") { write("You cautiously enter the ruins.\n");
this_player()->move_player("into the ruins#/players/jaryn/areas/forlorn/f2.c");
return 1; }
}

Pass_through_mist(str) {
if(!str || str != "through mist") {notify_fail("Pass through what??\n");
return 0; }
if (str=="through mist") { write("You pass through the eerie mist.\n");
this_player()->move_player("into the mist#/players/jaryn/areas/mist1.c");
return 1; }
}
