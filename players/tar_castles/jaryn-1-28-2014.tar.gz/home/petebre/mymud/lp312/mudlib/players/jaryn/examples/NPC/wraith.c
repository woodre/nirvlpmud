/*  Forbin | Create date:  apr2002.30 | Last mod:  may2002.24  */

#include "/players/forbin/define.h"
#define ROOT "/players/forbin/hyperion/flame_forest/"
inherit "/players/vertebraker/closed/std/monster.c";

id(str) { return str == "wraith" || str == "thermal wraith"; }
reset(arg)
{
  object gold;
  ::reset(arg);
  if(arg) return;
  set_name("Thermal Wraith");
  set_race("creature");
  set_short(""+HIR+"Thermal "+HIW+"Wraith"+NORM+"");
  set_long("  Similar in appearance to a ferret, yet colossal in size,\n"+
           "thermal wraiths have been hunted to near extinction.  The\n"+
           "wraith is 4 feet high standing on all fours, and almost 10\n"+
           "feet high when balancing on its hind legs.  Large paws end\n"+
           "with black talons, and its jaws are filled with many bone-\n"+
           "crushing teeth.  Milky-white fur is covered with bright red\n"+
           "stripes in a tiger-like pattern.  This well-insulating fur\n"+
           "is highly sought-after and treasured by many.\n");
  set_level(20);
  set_hp(500+random(250));
  set_al(random(2001)-1000);
  set_wc(40);
  set_wc_bonus(10); /* SEE CALCULATIONS BENEATH HEARTBEAT-SPELL SWITCH BELOW */
  set_ac(15);
  set_dead_ob(this_object());
  set_chat_chance(5);
    load_chat("The thermal wraith stalks about the area.\n");
    load_chat("The thermal wraith makes a quibbiling sound.\n");
    load_chat("Standing on its hind legs, the thermal wraith growls at you.\n");
  set_a_chat_chance(15);
    load_a_chat("With quick reflexes, the thermal wraith darts away from your attack.\n");
    load_a_chat("The thermal wraith strikes at you with its sharp talons.\n");
  set_armor_params("other|fire", 15, 70, "fire_defend");
  /* 15 points of ac, 70% resistance to other|fire, calls the func 'fire_defend' */
}

heart_beat()
{
  int i;
  ::heart_beat();
  if(attacker_ob)
  {
    i = random(30);
    switch(i)
    {
      case 0..4: RAKE(); break;
      case 5: BURN(); break; 
      case 6..29: return 0; break;
    }
  }
}
/* WC_bonus & AC_bonus CALCULATIONS BELOW
 *
 * RAKE():  WC_bonus =  32.5 avg. dam. ->  32.5/(100/16.7) = 5.43*1.25 (other|fire) =  6.78 R= 7
 * BURN():  WC_bonus =  67.5 avg. dam. ->  67.5/(100/3.33) = 2.25*1.25 (other|fire) =  2.80 R= 3
 *            TOTAL WC_bonus = 10
 */ 

RAKE()
{
  if((attacker_ob) && (attacker_ob->query_ghost())) return;
  if(ENV(attacker_ob) != ENVTO) return;
  tell_room(ENVTO, "With astonishing quickness, the thermal wraith\n"+
                   "bounds across the room and                    \n"+
                   "                                              \n", ({ attacker_ob }));
  tell_room(ENVTO, "      "+RED+"/ / / / RAKES / / / /"+NORM+"            \n"+
                   "                                              \n"+
                   "                   "+AON+" with razor-sharp talons.\n", ({ attacker_ob }));
  tell_object(attacker_ob, "With astonishing quickness, the thermal wraith\n"+
                           "bounds across the room and                    \n"+
                           "                                                          \n"+ 
                           "     "+RED+"/ / / / RAKES / / / /"+NORM+"            \n"+
                           "                                                          \n"+
                           "                  you with razor-sharp talons.\n");
  attacker_ob->hit_player(15+random(36), "other|fire");
}

BURN()
{
  if((attacker_ob) && (attacker_ob->query_ghost())) return;
  if(ENV(attacker_ob) != ENVTO) return;
  tell_room(ENVTO, "The wraith belches "+HIR+"FLAMES"+NORM+" on "+AON+" - skin "+HIW+"BLISTERS"+NORM+"!!!\n", ({ attacker_ob }));
  tell_object(attacker_ob, "The wraith belches "+HIR+"FLAMES"+NORM+" on you - skin "+HIW+"BLISTERS"+NORM+"!!!\n");  
  attacker_ob->hit_player(40+random(56), "other|fire");
}

int fire_defend()
{
  if(!random(4))
  {
    tell_room(environment(), "The thermal wraiths's fur protects it from the fire!\n");
      return 1501; /* 15= resistance percentage, 01= class protection */
  }
}

monster_died() 
{
  object corpse;
  corpse = present("corpse", ENVTO); 
  tell_room(ENVTO, "The thermal wraith crumples into a smouldering heap.\n");	
  MOCO(ROOT+"OBJ/wraith_pelt.c"), ENVTO);
  if(!random(3)) { MOCO(ROOT+"OBJ/bone_shard.c"), ENVTO); }
  /* PELT VALUED @ 2000+random(2001) coins - AVERAGE OF 4000 - LOWER TO THE 5000 LIMIT */
  /* SHARD OF BONE VALUED @ 900 coins */
  if(corpse) destruct(corpse);
    return 1; 
}

