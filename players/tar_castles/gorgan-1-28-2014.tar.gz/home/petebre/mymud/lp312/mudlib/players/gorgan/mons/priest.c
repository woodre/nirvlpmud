
inherit"obj/monster";
reset(arg) {
string chat_str;
::reset(arg);
if(arg) return;
set_name("priest");
set_short("An evil priest");
set_long(
"This is a very evil man who killed the old priest and now he practices\n"
+ "his own religion.  Karne himself comes to him to share in his practices.\n"
+ "He specializes in sacrifices and you are first on his list.\n");
set_level(21);
set_race("human");
set_hp(600);
set_al(-1000);
set_wc(35);
set_ac(30);
set_aggressive(1);
set_chat_chance(20);
load_chat("An evil priest exclaims:  You are going to die here!\n");
load_chat("An evil priest hisses:  I will sacrifice you to Lucifer himself.\n");
}
