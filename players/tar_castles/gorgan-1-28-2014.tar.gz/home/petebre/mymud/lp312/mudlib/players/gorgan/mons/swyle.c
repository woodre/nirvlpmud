inherit"obj/monster";

reset(arg) {
	object plate;
  ::reset(arg);
  if(!arg) {

   set_name("swyle");
	set_short("Swyle");
	set_long("   This is Kwam's brother Swyle he has long brown hair with a blood\n"+
		"red tatoo of a snake on his cheek.  His plate seems to have been\n"+
		"bathed in blood.  You think twice about saying anything to him.\n");
   set_level(20);
   set_hp(500);
   set_wc(30);
   set_ac(17);
	set_aggressive(0);
	set_chance(30);
	set_spell_dam(15);
	set_spell_mess1("You are crushed.");
	plate=clone_object("players/gorgan/armor/plate.c");
	move_object(plate, this_object());
   }
}
