#define NAME "Gorgan"
#define DEST "room/sunalley1"
/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "castle"; }

short() {
    return "Castle of " + NAME;
}

long() {
    write("This is the " + short() + ".\n");
    write(NAME + " is a HERO, and his castle kicks ass\n");
    write("just the same. So get the hell in there.\n");
}

init() {
    add_action("enter"); add_verb("enter");
}

enter(str) {
  if(str == "castle") {
  this_player()->move_player("into the castle#players/gorgan/enter.c");
    return 1;
    }
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
}
is_castle(){return 1;}
