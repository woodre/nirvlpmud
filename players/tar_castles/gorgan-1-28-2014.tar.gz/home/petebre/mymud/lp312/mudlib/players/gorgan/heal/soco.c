#include "std.h"
int drinks, price;

id(str) { return str == "comfort"; }

reset(arg) {
	if (!arg) drinks = 10;
	price = drinks * 250;
}

long() {
	write("A bottle of Southern Comfort with "+drinks+" drinks left.\n");
}

short() {
     return "A bottle of Southern Comfort";
}

query_value()
{
    return price;
}

init() {
    add_action("use"); add_verb("drink");
}

use(arg){
object tp;
tp = this_player();
if(!arg || arg != "comfort"){
	return 0;
} else {
if(!tp->drink_alcohol(14)){
	return 1;
}else{
	if(arg == "comfort"){
drinks=drinks - 1;
this_player()->add_spell_point(50);
	write("The comfort glides down the back of your throat.  There are "+drinks+" drinks left.\n");
	say(capitalize(tp->query_name()) + " chugs down some comfort.\n");
if(drinks == 0){
	destruct(this_object());
	this_player()->heal_self(50);
	write("The comfort is all gone.\nYou aren't as comfortable as before.\n");
		}
return 1;
		}
	}
}
}

get() {
    return 1;
}

query_weight() {
    return 2;
}
