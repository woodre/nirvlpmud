inherit "obj/armor";
reset(arg) {
::reset(arg);
	set_short("Blood plate");
	set_long("  This plate looks very durable but is covered with blood. If you're not afraid of a little blood wear it.\n");
	set_ac(4);
	set_value(5000);
	set_name("plate");
	set_weight(3);
	set_alias("plate");
	set_type("armor");
	}
