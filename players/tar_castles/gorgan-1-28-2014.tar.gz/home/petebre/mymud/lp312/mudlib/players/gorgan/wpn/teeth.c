inherit"obj/weapon";
int hp;
object env;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("teeth");
   set_short("Sharp teeth");
   set_long(
      "These are some very sharp teeth taken from a corpse of a\n"
      + "wild dog in Joris.  Damn, they hurt just holding them.\n");
   set_value(1000);
   set_weight(2);
   set_class(15);
}
player_stuff() {
   if(env->is_player()){
      if(env->query_hp() >50)  env->add_hit_point(-25);
      call_out("player_stuff",20);
	  say("Ouch!\n");
	 return 1;
   }
}
init(){
   ::init();
   env=environment(this_object());
   if(env->is_player()) call_out("player_stuff",20);
   else remove_call_out("player_stuff");
}
