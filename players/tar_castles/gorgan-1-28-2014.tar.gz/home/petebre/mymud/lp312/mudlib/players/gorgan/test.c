me() { return this_player(); }
RN() { return capitalize(me()->query_real_name()); }
rn() { return me()->query_real_name(); }
get() { return 1; }
id(str) { return str=="pentagram"||str=="pent"||str=="pent-nec"; }
short() { return "Pentagram"; }
long() {
  write("\tThis is the 'Necromancer' symbol.\n"+
  "Use 'com' to get a list of commands.\n");
}
init() {
  add_action("pent","pent");
  add_action("ncw","ncw");
  add_action("nt","nt");
  add_action("nce","nce");
  add_action("drop","drop");
  add_action("com","com");
}
drop(str) {
  if(str=="pent"||str=="pentagram")
    {  write("Pentagram -- That would not be a good idea.\n");
    return 1; }
  return 1;
}
com(str) {
  if(str) return;
  cat("/players/gorgan/pent.com");
  return 1;
}
nt(str) {
  object us;
  int x;
  if(!str) return;
  us=users();
  for(x=0;x<sizeof(us); x++) {
    if(present("pent-nec",us[x]))
      tell_object(us[x],"{[ "+RN()+" ]} "+str+"\n");
  }
  return 1;
}
nce(str) {
  object us;
  int x;
  if(!str) return;
  us=users();
  for(x=0;x<sizeof(us);x++) {
    if(present("pent-nec",us[x]))
      tell_object(us[x],"->> "+RN()+" "+str+"\n");
  }
  return 1;
}
ncw(str) {
  object us;
  int x;
  if(str) return;
  write("Name------------Location--------------------------------------\n");
  us=users();
  for(x=0;x<sizeof(us);x++) {
      write(capitalize(us[x]->query_real_name()));
      if(strlen(us[x]->query_real_name())>7)
        write("\t"); else write("\t\t");
      write(environment(us[x])->short());
      write("\n");
  }
  return 1;
}
pent(str) {
  if(!str) return;
  if(!find_living(str)) {
    write("Pentagram: I could not find '"+str+"'\n");
    return 1;
  }
  move_object(clone_object("/players/gorgan/pent"),find_living(str));
  tell_object(find_living(str),RN()+" has just given you a Pentagram.\n");
  write("Done.\n");
  return 1;
}
