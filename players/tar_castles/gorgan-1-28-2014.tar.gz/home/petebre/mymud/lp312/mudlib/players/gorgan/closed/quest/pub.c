#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
object rogue;
extra_reset() {
	rogue=clone_object("/players/gorgan/mons/rogue.c");
	move_object(rogue, this_object());
}
ONE_EXIT("/players/gorgan/closed/quest/roomB.c","north",
	"An old pub",
	"  This is an old ran down pub.  There is nothing of any value here anymore.\n"+
	"Some theives and others still come here on occassion.\n",
   1)
