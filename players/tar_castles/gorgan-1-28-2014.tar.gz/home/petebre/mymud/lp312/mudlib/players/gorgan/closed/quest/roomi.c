#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
object henchman;
extra_reset() {
	henchman=clone_object("/players/gorgan/mons/henchman.c");
	move_object(henchman, this_object());
   henchman=clone_object("/players/gorgan/mons/henchman.c");
   move_object(henchman, this_object());
	henchman=clone_object("/players/gorgan/mons/henchman.c");
	move_object(henchman, this_object());
	henchman=clone_object("/players/gorgan/mons/henchman.c");
	move_object(henchman, this_object());
}
TWO_EXIT("/players/gorgan/closed/quest/rooma.c","north",
	"/players/gorgan/closed/quest/roomj.c","south",
	"A barren area",
	"   This used to be farming land when Joran still lived.  Now it is\n"+
	"just barren land because Karne has taken over.\n",
   1)

init() {
	::init();
	add_action("north","north");
	add_action("south","south");
	}
south() {
	if((this_player()->query_level() <20) && (present("henchman", this_object()))) {
	write("An Evil henchman trips your foolish ass!\n");
	return 1;
}
	this_player()->move_player("south#/players/gorgan/closed/quest/roomj.c");
	return 1;
}
north() {
	if((this_player()->query_level() <20) && (present("henchman", this_object()))) {
	write("An Evil henchman trips your foolish ass!\n");
	return 1;
}
	this_player()->move_player("north#/players/gorgan/closed/quest/rooma.c");
	return 1;
}
