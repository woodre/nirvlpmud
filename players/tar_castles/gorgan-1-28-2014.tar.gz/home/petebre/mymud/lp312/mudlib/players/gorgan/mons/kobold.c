inherit "obj/monster";

reset(arg){
   object gold,armor,weapon;
   ::reset(arg);
   if(arg) return;
   set_name("kobold");
   set_race("kobold");
   set_alias("kobold");
   set_short("Kobold Leader");
   set_long("This kobold looks a little taller than the rest.\n"+
      "He seems to be chanting some words to the other kobolds.\n";
   set_level(14);
   set_hp(180);
   set_al(-1000);
   set_wc(14);
   set_ac(6);
   set_chance(40);
   set_spell_dam(15);
   set_spell_mess1("The kobold leader shocks his opponent with a lingering touch.\n");
   set_spell_mess2("You are shocked by the kobold leader's hands!\n");
   set_chat_chance(2);
   load_chat("Kobold says: Gousard ack tu marpwll treasure!\n");
   load_chat("Kobold says: Ot dok harpulick dun Beholder agordiot!\n");
   gold=clone_object("obj/money");
   gold->set_money(random(100)+200);
   move_object(gold,this_object());
   weapon=clone_object("/players/lucifer/monster/weapon/short");
   move_object(weapon,this_object());
   armor=clone_object("/players/lucifer/monster/weapon/leather");
   move_object(armor,this_object());
}
