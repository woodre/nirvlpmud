#include "room.h"
FOUR_EXIT("/players/gorgan/closed/quest/roomb.c","north",
	"/players/gorgan/closed/quest/rooma.c","south",
	"/players/gorgan/room/room1.c","east",
	"/players/gorgan/closed/quest/rooma.c","west",
   "A barren area",
	"   This used to be farming land when Joran still lived.  Now it is\n"+
	"just barren land because Karne has taken over.\n",
   1)
