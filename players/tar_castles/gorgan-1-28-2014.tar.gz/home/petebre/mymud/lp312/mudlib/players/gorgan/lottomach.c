inherit "obj/treasure";
reset(arg) {
	if(arg) return;
			set_short("An INSTANT Lottery Machine");
			set_alias("machine");
		set_long("This is Nirvana's INSTANT Lottery machine!\n"+
		"To buy a ticket just type 'buy ticket'.  Each ticket costs 100 gold coins.\n"+
		"You can win up to 60000 gold coins INSTANTLY!!\n");
}
init() {
        ::init();
	add_action("get","get");
	add_action("get","take");
	add_action("do_buy","buy");
}
get(str) {
       if(!str || str !="machine") return;
		write("This is WAY to heavy for a little sissy like you.\n");
			return 1; }
do_buy(str) {
	if(!str || str !="ticket") return;
		if(this_player()->query_money() < 100) {
			write("You can not afford it!\n");
			return 1;
		}
		else {
		this_player()->add_money(-100);
		transfer(clone_object("/players/gorgan/lotto.c"),this_player());
		write("You bought an INSTANT Lotto Ticket for 100 gold coins.\n");
		say(call_other(this_player(), "query_name", 0) + " buys an INSTANT Lottery Ticket!\n");
		return 1;
	}
}
