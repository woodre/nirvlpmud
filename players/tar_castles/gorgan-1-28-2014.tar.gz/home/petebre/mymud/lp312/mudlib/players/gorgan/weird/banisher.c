string bb;
short() {return "The banishment object";}
init() {
     add_action("banish","banish");
   }
long() {
   write ("Use 'banish name'\n");
   }
banish(who) {
int level;
    level = call_other(this_player(), "query_level");
    if (level < 21)
	return 0;
    if (!who) {
	write("Who ?\n");
	return 1;
    }
    if (!call_other(this_player(), "valid_name", who))
	return 1;
    if (restore_object("players/" + who)) {
	write("That name is already used.\n");
	return 1;
    }
    if (restore_object("banish/" + who)) {
	write("That name is already banished.\n");
	return 1;
    }
    bb = call_other(this_player(), "query_name");
    if (bb == "Someone") {
	write("You must not be invisible!\n");
	return 1;
    }
    save_object("banish/" + who);
    return 1;
}

get() {
   write("You now have the banishment object\n");
   return 1;
    }
id(str) {
   return str=="banishment" || str == "object";
    }
