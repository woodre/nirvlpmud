string owner, on_off;
string attname;
object user;
short(){return owner + "'s Hp monitor";}
id(str){return str == "monitor";}
	long(){
		write("A hit point monitor.\n"+
			"Type: monitor on, to turn it on.\n"+
			"Type: monitor off, to turn it off.\n"+
		"Type: con, to tell you your current condition when monitor is off.\n");
}
init(){
	if(environment()==this_player()){
	user = environment(this_object());
	owner = capitalize(user->query_real_name());
	}else{
	user = 0;
	owner = "Nobody";
	}
	add_action("ifon","monitor");
	add_action("condition","con");
}
get(){return 1;}
drop(){return 0;}
query_value(){return 100;}
query_weight(){return 0;}
create(){
	user = 0;
	owner = "Nobody";
}
moncon(){
object user, at;
int z, hp, mhp, sp, msp, i, s, t;
user=environment(this_object());
at = user->query_attack();
hp = user->query_hp();
mhp = user->query_mhp();
sp = user->query_sp();
msp = user->query_msp();
i = user->query_intoxination();
s = user->query_stuffed();
t = user->query_soaked();
z = 3;
if(!at){z=9;}
	tell_object(user,"HP:["+hp+"/"+mhp+"]  SP:["+sp+"/"+msp+"]  ");
	if(i > 0){ tell_object(user,"I:["+i+"]  "); }
	if(s > 0){ tell_object(user,"S:["+s+"]  "); }
	if(t > 0){ tell_object(user,"T:["+t+"]  "); }
	attacker_stuff();
	tell_object(user,"\n");
	call_out("moncon",z);
	return 1;
	}

ifon(str){
	if(str == "on"){
	call_out("moncon",1);
	write("Monitor is turned on.\n");
	return 1;
	}
	if(str == "off"){
	remove_call_out("moncon");
	write("Monitor is turned off.\n");
	return 1;
	}
return 1;
}

condition(){

tell_object(user,
	"Hp:["+user->query_hp()+"/"+user->query_mhp()+"]  " +
	"Sp:["+user->query_sp()+"/"+user->query_msp()+"]  " +
	"I:["+user->query_intoxination()+"]  " +
	"S:["+user->query_stuffed()+"]  " +
	"T:["+user->query_soaked()+"]  "
		);
	attacker_stuff();
	write("\n");
	return 1;
}
attacker_stuff(){
object att;
string anm;
int ahp, amhp;
att = user->query_attack();
if(att != 0){
anm = att->query_name();
ahp = att->query_hp();
amhp = att->query_mhp();
tell_object(user,"vs. "+anm+": "+ahp+"/"+amhp);
}
}
