inherit "obj/treasure";

reset(arg) {
 if(arg) return;
   set_short("An evil skull");
    set_alias("skull");
	set_long("This is a very evil looking humanoid skull.  It's empty eye sockets seem\nto stare at you.\nYou sense evil all around you.\n");
   set_weight(1);
}
 id(str) { return str == "skull" || str == "evil skull"; }

drop() { return 1; }
