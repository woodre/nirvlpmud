inherit "obj/armor";
reset(arg) {
::reset(arg);
	set_short("Fuzzy red cloak");
	set_long("  This is the fuzzy red cloak of Gorgan. It may be too big, but it should fit.\n");
	set_ac(3);
	set_value(12000);
	set_name("cloak");
	set_alias("cloak");
	set_type("armor");
	}
