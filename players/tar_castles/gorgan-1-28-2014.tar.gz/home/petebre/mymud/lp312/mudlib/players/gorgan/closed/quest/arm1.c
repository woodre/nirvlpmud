inherit "obj/treasure";

reset(arg) {
 if(arg) return;
   set_short("A skeleton arm");
    set_alias("arm");
	set_long("This is a skeleton arm.  It looks like its been here a very long time.\nYou wonder who it belonged to.\n");
   set_weight(1);
}
 id(str) { return str == "arm" || str == "skeleton arm"; }

drop() { return 1; }
