#include "room.h"
FOUR_EXIT("/players/gorgan/closed/quest/rooma.c","north",
	"/players/gorgan/closed/quest/rooma.c","south",
	"/players/gorgan/closed/quest/rooma.c","east",
	"/players/gorgan/closed/quest/roomd.c","west",
   "A barren area",
	"   This used to be farming land when Joran still lived.  Now it is\n"+
	"just barren land because Karne has taken over.\n",
   1)
