inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("liquid");
set_short("A bottle of a black liquid");
set_long(
"This is a bottle of a disgusting looking black liquid.\nYou wonder what it does?\n");
set_value(1000);
set_weight(2);
}
init() {
	::init();
	add_action("drink","drink");
}
drink(str) {
   int al, a, lev;
	if(!str || str !="liquid") return;
	if(this_player()->query_level()>29){
	notify_fail("You can't drink this.\n");
	return 0; }
   al = this_player()->query_alignment();
   lev = this_player()->query_level();
   al -= al*2/(30-lev);
   a = -1000 - al;
	write("You guzzle down a disgusting black liquid.\nIt tastes like shit.\nYou feel evil as fuck!\n");
	say(capitalize(this_player()->query_name())+" drinks a bottle of Black liquid.\n");
   this_player()->add_alignment(a);
	destruct(this_object());
	return 1;
}
