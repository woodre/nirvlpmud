inherit "obj/monster";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Cupid");
   set_race("angel");
   set_alias("cupid");
	set_short("An angelic Cupid");
	set_long("This is a cherubic infant with a bow and arrow in hand.\nHe is aiming your way.  Look out or you might fall in love today.\nYou sad sap.\nBoy does he look goofy?\n");
   set_level(1);
   set_hp(100);
   set_wc(1);
   set_ac(20);
	set_whimpy();
	set_a_chat_chance(30);
   set_chat_chance(35);
	load_chat("You feel a sharp arrow poke you in the ASS!\nOUCH!!!\nYou feel love surround your soul, but damn you wanna kill that little brat.\n");
	load_chat("Cupid kicks you.   OUCH!!\n");
	load_a_chat("Cupid flies circles around you.\n");
}
heart_beat() {
int v,x,y,z;
	::heart_beat();
	x=random(100);
	v=random(100);
	y=random(100);
	z=random(100);
	if(x < 75) {
	command("north",this_player());
	return 1;
	}
	if(y < 75) {
	command("south",this_player());
	return 1;
	}
	if(v < 75) {
	command("east",this_player());
	return 1;
	}
	if(z < 75) {
	command("west",this_player());
	return 1;
	}
}
