inherit "room/room";
object invis;
init() {
	::init();
	this_player()->set_fight_area();
}
reset(arg) {
invis=clone_object("players/dragnar/rooms/gate.c");
move_object(invis, this_object());
	if(arg) return;
set_light(1);
short_desc=("Gate to town");
long_desc=
	"As you continue closer towards the forest you notice what once\n" +
"used to be a gate closing off a broken up pavement road.  The longer\n" +
"you are here the more you wonder what happened to this land.\n",
items=
({"gate","It looks like you may be able to lift it",
});
dest_dir=
({
"players/dragnar/rooms/arena.c","south",
"players/dragnar/rooms/room3.c","north",
});
}
