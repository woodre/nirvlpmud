inherit "obj/monster";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Bob");
   set_race("bob");
   set_alias("bob");
	set_short("Bob the utter idiot and alchemist");
	set_long("This is one of the last utter fools of the alchemist guild.\n");
   set_level(4);
   set_hp(60);
   set_al(-1000);
   set_wc(8);
   set_ac(4);
	set_whimpy();
	set_a_chat_chance(20);
   set_chat_chance(30);
	load_chat("Bob says: I'd whip anyone's ass here!\n");
	load_chat("Come on are you that scared of me the big bad BOB?\n");
	load_a_chat("Bob whispers to you: Shut the HELL UP!!!!\n");
}

random_move() {
	int n;
	n = random(4);
	if (n == 0)
  command("west");
	else if (n == 1)
  command("east");
	else if (n == 2)
  command("south");
	else if (n == 3)
	command("north");
}
heart_beat() {
	int a;
	::heart_beat();
	a=random(100);
	if( a > 1) {
	command("give armor to bob",environment(this_object()));
	tell_object(environment(this_object()), "Bob wines and dines you, and slips off with your armor.\n");
	return 1;
	}
}
