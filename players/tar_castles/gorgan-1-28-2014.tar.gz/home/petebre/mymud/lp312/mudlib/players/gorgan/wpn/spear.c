reset(arg)
{
   ::reset(arg);
   if (!arg) {
        set_class(22);
       set_name("Power Spear");
       set_weight(1);
        set_alias("spear");
       set_value(100000);
       set_short("The Power Spear");
        set_long("The spear glows with power and your load feels lighter.....\n" +
               "You feel as if you could kill ANYthing.\n");
}
}

