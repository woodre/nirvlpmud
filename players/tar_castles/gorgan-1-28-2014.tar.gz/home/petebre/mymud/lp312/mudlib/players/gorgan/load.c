inherit "obj/treasure";

reset(arg) {
 if(arg) return;
   set_short("A load lifter");
    set_alias("lifter");
	set_long("A transparent cloudy blob that seems to resist gravity.\n");
   set_weight(-6);
    set_value(450);
}
 id(str) { return str == "lifter" || str == "A load lifter"; }

