short() { return 0; }
long() { return 0; }
id(str) { return 0; }

init() {
	add_action("swing","swing");
	}
swing(str) {
if(!str || str !="vine") {
	write("Swing on what?\n");
	return 1;
}
else if(str == "vine") {
	object user;
	user=this_player();
	tell_object(user, "WHOA!!!!!!!!!!!!!\n\n\n\n\n\n\n\n\nSPLAT!!!!\n\n\n\n\nOUCH!!\n\n\n");
	this_player()->move_player("via secret exit#players/gorgan/closed/quest/tree.c");
	return 1;
}
	}
