int Time;
string Name;
id(str) { return str=="alarm"; }
get() { Name=this_player()->query_real_name(); return 1; }
short() { return "Alarm clock"; }
long() {
  write("It's an alarm clock.  The commands are:\n"+
  "\talarmset time    where time is an amount of minutes before it goes off\n"+
  "\talarmoff         this turns the alarm off\n");
  return 1;
}
init() {
  add_action("alarmoff","alarmoff");
  add_action("alarmset","alarmset");
}
reset(arg) {
  if(arg) return;
  Time=0;
  set_heart_beat(1);
}
heart_beat() {
  if(time()>Time&&Time!=0)
    tell_object(find_living(Name),"BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP BEEP\n");
  tell_object(find_living(Name),Time+"\t"+time()+"\n");
}
alarmoff(str) {
  Time=0;
  write("You turn the alarm off.\n");
  return 1;
}
alarmset(str) {
  Time=intp(time()+(intp(str)*60);
  write("You have just set the alarm ("+str+" minutes).\n");
  return 1;
}
