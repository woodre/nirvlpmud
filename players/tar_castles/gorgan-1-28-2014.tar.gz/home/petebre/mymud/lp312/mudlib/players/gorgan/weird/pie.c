get() { return 1; }

short() { return "An aerodynamic pie"; }

id(str) { return str=="pie"; }

long() { write("This is a pie.  Sure looks like it can fly well.\n"); }

init() {
  add_action("throw","throw");
}

throw(str) {
  object who;
  if(!find_living(str)) {
    write("I can't find that person.\n"); return 1; }
  tell_object(find_living(str),"You see an object fly in from an unknown origin.  With unerring accuracy,\na pie smacks you in the face!\n");
  if(this_player()->query_real_name()=="zek")
    destruct(this_object());
  write("You throw the pie, and it hits your target in the face!\n");
  return 1;
}
