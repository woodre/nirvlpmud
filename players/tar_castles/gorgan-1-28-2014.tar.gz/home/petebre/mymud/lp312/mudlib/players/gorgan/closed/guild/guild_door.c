get(){ return 0; }
id(str){ return str == "door"; }
short(){ return "A stone vault door"; }
long(){write("This is a very large ancient stone door.\nIt keeps the living outside this ancient crypt.\nThere are some ancient words inscribed on it.\nPlease 'read inscription'.\n"); }
init() {
   add_action("read","read");
   add_action("open","open");
}
read(str){
   if(!str || str != "inscription") return;
   else {
      write("	'Oh, you that came from the depths of the earth\n"+
         "	venerate the name of the Unnameable\n"+
         "	follow the path He traced\n"+
         "	drink at the stream of His power\n"+
         "	make His breed greater\n"+
         "	the time of your reward will come\n"+
         "	He will triumph and reshape the world\n"+
         "	and it will be His and our temple.'\n");
      return 1;
   }
}
open(str){
   if(!str || str != "door") return;
      else {
         write("This door is always open for you mighty one.\nIt is only sealed for the living.\n");
         return 1;
      }
   }
