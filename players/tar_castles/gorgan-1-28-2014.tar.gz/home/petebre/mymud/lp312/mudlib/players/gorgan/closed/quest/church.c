#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
int x;
object priest, rat, water;
extra_reset() {
	priest=clone_object("/players/gorgan/mons/priest.c");
	move_object(priest, this_object());
}
ONE_EXIT("/players/gorgan/closed/quest/roomC.c","north",
	"An old church",
	"   This the old church of Joris.  The floor and walls are covered\n"+
	"with blood.  On the west wall there is a very old organ and\n"+
	"a table.  The table is extremely blood stained.  There is also a\n"+
	"very evil looking priest standing in the corner.\n",
   1)
init() {
	::init();
	add_action("look","look");
	add_action("look","l");
	add_action("get","get");
	add_action("get","take");
}
look(str) {
	if(!str || str !="at organ") return;
	else {
		write("This is a very old organ but it is still in pretty good shape for\n"+
		"its age.  There appears to be something stuck in one of its\n"+
		"pipes.\n");
		return 1;
	}
}
get(str) {
	if(!str || str !="all from pipe") return;
	if(x==1) {
		write("You find a bottle of Holy water.\n");
		water=clone_object("/players/gorgan/closed/quest/water.c");
		move_object(water, this_object());
		x=2;
		return 1;
	}
	if(x<1) {
		write("A large rat jumps out at you!\n");
		rat=clone_object("/players/gorgan/mons/rat.c");
		move_object(rat, this_object());
		x=1;
		return 1;
	}
	if(x>1) {
		write("The pipe is no longer clogged.\n");
		return 1;
	}
}
