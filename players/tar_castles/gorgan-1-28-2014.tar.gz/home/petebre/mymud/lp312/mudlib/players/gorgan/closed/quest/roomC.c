#include "room.h"
FOUR_EXIT("/players/gorgan/closed/quest/roomB.c","west",
	"/players/gorgan/closed/quest/roomD.c","east",
	"/players/gorgan/closed/quest/shop.c","north",
	"/players/gorgan/closed/quest/church.c","south",
   "A deserted road",
	"   You are on an old desterted town road.  To the east and west the road\n"+
	"continues.  To the north you see the old town shop.\n",
   1)
