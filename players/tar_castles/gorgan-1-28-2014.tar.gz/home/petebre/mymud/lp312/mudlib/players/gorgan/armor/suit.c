inherit "obj/armor";
reset(arg) {
::reset(arg);
	set_short("Bud suit");
	set_long("  This is a blue suit with a red cape. On the front of it in big bold letters is reads 'BUDMAN'.\n");
	set_ac(3);
	set_value(10000);
	set_name("suit");
	set_alias("suit");
	set_type("armor");
	}
