inherit"room/room";

reset(arg) {

if(!arg) {
	set_light(1);
	short_desc="Enterance";
	long_desc=
"    This place gives you the chills because the smell of rotting\n"+
"flesh and blood in the air.  You can hardly make out anything in\n"+
"your path because it is so dark.  There appears to be some sort\n"+
"of light source to the north.  You can barely make out an\n"+
"enterance to a cave to the north.  It may not be safe to\n"+
"continue on in this realm.  Very high level and equiped\n"+
"characters only!\n";
dest_dir = ({
	"room/sunalley1.c","out",
	"players/gorgan/room/room1.c","north",
/* yanked out because all the items in the heal shop were illegall,
   and multiple use heals (esp. chips were storable */
/*
	"players/gorgan/shop.c","shop",
 */
	});
	}
	}

init() {
	::init();
	add_action("north","north");

	}

north() {
	if(this_player()->query_level()<15) {
		write("Gorgan appears suddenly, and grabs you by the throat.\n"+
		"'What are you stupid?  Levels OVER 15 please.'\n"+
		"Gorgan then returns to his fridge for another beer.\n");
		return 1;
	this_player()->move_player("north#players/gorgan/midrm/room1.c");
	}
}
