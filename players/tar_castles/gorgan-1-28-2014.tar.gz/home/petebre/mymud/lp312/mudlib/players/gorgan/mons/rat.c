inherit"obj/monster";

reset(arg) {
  ::reset(arg);
  if(!arg) {

   set_name("rat");
   set_short("A large rat");
   set_long("It is big fat, hairy, and mean.\n");
	set_aggressive(1);
   set_level(8);
   set_hp(120);
   set_wc(12);
   set_ac(7);
   }
}
