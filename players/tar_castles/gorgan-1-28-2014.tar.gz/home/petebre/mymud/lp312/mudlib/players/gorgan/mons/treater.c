inherit "obj/monster";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Treater");
   set_race("treater");
   set_alias("treater");
	set_short("A trick or treater");
	set_long("This little guy is looking every where for candy.\nWhat a dumb costume?\n");
   set_level(1);
   set_hp(100);
   set_wc(1);
   set_ac(20);
	set_whimpy();
	set_a_chat_chance(30);
   set_chat_chance(35);
	load_chat("A trick or treater begs for some candy.\n");
	load_chat("A trick or treater says: Give me your bag of candy too!\n");
	load_a_chat("You'll never get my candy!!!!\n");
}
heart_beat() {
int v,x,y,z;
	::heart_beat();
	x=random(100);
	v=random(100);
	y=random(100);
	z=random(100);
	if(x < 65) {
	command("north",this_player());
	return 1;
	}
	if(y < 65) {
	command("south",this_player());
	return 1;
	}
	if(v < 65) {
	command("east",this_player());
	return 1;
	}
	if(z < 65) {
	command("west",this_player());
	return 1;
	}
}
