valid_enter(obj){
   if(!obj || !objectp(obj)) return 0;
   else if(!living(obj)) return 1;
   if(first_inventory(obj)->is_player()) obj = first_inventory(obj);
   if(!obj->is_player()) return 1;
   else if(present("soul_undead",obj)) return 1;
   else return 0;
}

