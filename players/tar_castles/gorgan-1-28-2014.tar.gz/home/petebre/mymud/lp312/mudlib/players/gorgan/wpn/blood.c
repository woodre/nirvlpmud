inherit "obj/weapon";

reset(arg) {
  if(!arg) {

    set_id("bloodsword");
    set_alias("sword");
    set_short("The blood sword");
    set_long("The Blood sword.\n"+
             "This sword is perfect for drawing 'first blood'\n"+
             "on your victims.\n");
    set_class(18);
    set_value(5500);
    set_weight(8);
    set_hit_func(this_object());
}
}
weapon_hit(attacker) {
   if(attacker->query_npc()) {
   if(attacker->query_level()<15) {
    call_other(this_object(), "set_class", 10);
    call_other(this_player(), "set_wc", 10);
    return 1;
   }
  }
    call_other(this_object(), "set_class", 18);
    call_other(this_player(), "set_wc", 18);
  write("You grin as you slice "+attacker->query_real_name()+"'s throat.\n");
  tell_object(attacker, capitalize(this_player()->query_real_name())+
      "slices your throat with the bloodsword.\n");
say(capitalize(this_player()->query_real_name())+" slices his enemy's throat.\n");
/*   before this next line was attakcer->hit_player(random(100))
     I have hopefully fixed it so that it doesn't cause instant
     death.
*/
attacker->hit_player(random(100));
  attacker->hit_player(random(30));
  return 1;
}
