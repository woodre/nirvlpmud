#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
object dog;
extra_reset() {
	dog=clone_object("/players/gorgan/mons/dog.c");
	move_object(dog, this_object());
	dog=clone_object("/players/gorgan/mons/dog.c");
	move_object(dog, this_object());
}
THREE_EXIT("/players/gorgan/closed/quest/roomA.c","west",
	"/players/gorgan/closed/quest/roomC.c","east",
	"/players/gorgan/closed/quest/pub.c","south",
   "A deserted road",
	"   You are on an old desterted town road.  To the east and west the road\n"+
	"continues.  To the south you see the old town pub.\n",
   1)

init() {
	::init();
	add_action("south","south");
	add_action("east","east");
	add_action("west","west");
	}
south() {
	if((this_player()->query_level() <20) && (present("dog", this_object()))) {
	write("You try to leave but a wild dog drags you back in by your ankle.\n");
	return 1;
}
this_player()->move_player("south#/players/gorgan/closed/quest/pub.c");
	return 1;
}
west() {
	if((this_player()->query_level() <20) && (present("dog", this_object()))) {
	write("You try to leave but a wild dog drags you back in by your ankle.\n");
	return 1;
}
this_player()->move_player("west#/players/gorgan/closed/quest/roomA.c");
	return 1;
}
east() {
	if((this_player()->query_level() <20) && (present("dog", this_object()))) {
	write("You try to leave but a wild dog drags you back in by your ankle.\n");
	return 1;
}
this_player()->move_player("east#/players/gorgan/closed/quest/roomC.c");
	return 1;
}
