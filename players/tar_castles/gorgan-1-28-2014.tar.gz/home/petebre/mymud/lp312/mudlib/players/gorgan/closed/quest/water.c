inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("water");
set_short("A bottle of Holy water");
set_long(
"This is a bottle of the purest Holy water in the land.\nUse it wisely.\n");
set_value(1000);
set_weight(2);
}
init() {
	::init();
	add_action("drink","drink");
}
drink(str) {
   int al, a, lev;
	if(!str || str !="water") return;
   al = this_player()->query_alignment();
   lev = this_player()->query_level();
   al -= al*2/(30-lev);
   a = 1000 - al;
	write("You drink a bottle of Holy water.\nYou feel angelic.\n");
	say(capitalize(this_player()->query_name())+" drinks a bottle of Holy water.\n");
   this_player()->add_alignment(a);
	destruct(this_object());
	return 1;
}
