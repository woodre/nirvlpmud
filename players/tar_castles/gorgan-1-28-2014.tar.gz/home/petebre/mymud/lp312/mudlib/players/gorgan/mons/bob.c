inherit "obj/monster";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Bob");
   set_race("bob");
   set_alias("bob");
	set_short("Bob the utter idiot and alchemist");
	set_long("This is one of the last utter fools of the alchemist guild.\n");
   set_level(4);
   set_hp(60);
   set_al(-1000);
   set_wc(8);
   set_ac(4);
	set_whimpy();
	set_a_chat_chance(20);
   set_chat_chance(30);
	load_chat("Bob says: I'd whip anyone's ass here!\n");
	load_chat("Come on are you that scared of me the big bad BOB?\n");
	load_a_chat("Bob whispers to you: Shut the HELL UP!!!!\n");
}
heart_beat() {
	object att;
int v,x,y,z,a;
	::heart_beat();
	att=(this_player()->query_attack());
	x=random(100);
	v=random(100);
	y=random(100);
	z=random(100);
	a=random(100);
	if(x < 65) {
	command("north",this_player());
	return 1;
	}
	if(y < 65) {
	command("south",this_player());
	return 1;
	}
	if(v < 65) {
	command("east",this_player());
	return 1;
	}
	if(z < 65) {
	command("west",this_player());
	return 1;
	}
	if( a > 1) {
	command("give armor to bob",att);
	tell_object(att,"Bob wines and dines you, and slips off with your armor.\n");
	return 1;
	}
}
