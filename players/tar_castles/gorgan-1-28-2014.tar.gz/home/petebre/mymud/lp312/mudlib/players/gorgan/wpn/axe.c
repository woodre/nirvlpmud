inherit "obj/weapon";
int die, attacker, pain;
reset(arg) {
::reset(arg);
        if(!arg) {
                set_name("axe");
                set_class(18);
                set_value(100000);
                set_weight(5);
                set_alias("axe");
                set_short("Power Axe");
set_long("This axe looks very powerful.\n");
set_hit_func(this_object());
}
}
weapon_hit(attacker)
  {
if(random(100) < 30) return 7;
{
write("The Axe rips into the monster.\n");
say("The Axe cuts into the monster\n");
}
}
