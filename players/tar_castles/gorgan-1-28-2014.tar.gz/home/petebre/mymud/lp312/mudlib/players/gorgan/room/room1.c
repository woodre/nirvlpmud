#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
int x;
init() {
	::init();
   add_action("look","look");
   add_action("forge","forge");
	add_action("north","north");
	add_action("look","l");
}
object beast1, quest_sign;
extra_reset() {
   if(!present("beast")) {
      beast1=clone_object("/players/gorgan/mons/beast1.c");
      move_object(beast1, this_object());
   }
	if(!present("sign")) {
	  quest_sign=clone_object("/players/gorgan/weird/quest_sign.c");
	  move_object(quest_sign, this_object());
	}
}
TWO_EXIT("/players/gorgan/enter.c","south",
	"/players/gorgan/room/room2.c","north",
   "Beast's Lair",
   "    A blazing fire is lit in the enterance of the cave.\n"+
   "Standing over the fire is the legendary Beast, with sword\n"+
   "in hand.  He glares at you as if he can sense your cowardice.\n"+
   "You're probably better off leaving this place before it is\n"+
   "too late.\n",
   1)
look(str) {
   if(!str || str !="at fire") return;
   else{
      write("This is a blazing fire that has been burning for many years.\n"+
         "Legend has it that by sticking a weapon in the fire it will harden\n"+
	   "the blade.  Type 'forge'.\n");
      return 1;
   }
}
forge() {
	if(x > 0) {
	write("The fire isn't hot enough anymore.\n");
	return 1;
	}
	this_player()->set_wc(this_player()->query_wc() + 1);
	x=1;
	write(  "You use the fire to harden your weapon.\n");
	return 1;
}
north() {
	if((this_player()->query_level() <20) && (present("beast", this_object()))) {
	write("Beast blocks your path.\n");
	return 1;
}
this_player()->move_player("north#/players/gorgan/room/room2.c");
	return 1;
}
