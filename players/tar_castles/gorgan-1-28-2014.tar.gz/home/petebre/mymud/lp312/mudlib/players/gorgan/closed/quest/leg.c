inherit "obj/treasure";

reset(arg) {
 if(arg) return;
   set_short("A skeleton leg");
    set_alias("leg");
	set_long("This is a skeleton leg.  It looks like its been here a very long time.\nYou wonder who it belonged to.\n");
   set_weight(1);
}
 id(str) { return str == "leg" || str == "skeleton leg"; }

drop() { return 1; }
