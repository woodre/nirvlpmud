#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
object vine;
extra_reset() {
	vine=clone_object("/players/gorgan/closed/quest/vine.c");
	move_object(vine, this_object());
}
ONE_EXIT("/players/gorgan/closed/quest/forest1.c","down",
   "A deserted road",
	"   You are at the top of a huge tropical tree.  There are many thin\n"+
	"vines hanging all around.  There is one rather large vine hanging in\n"+
	"front of you.  It is very quiet up here.  You can see a deserted\n"+
	"town to the west, endless tropical forest to the east, and the\n"+
	"ground below.\n",
   1)
init() {
	::init();
	add_action("look","look");
	add_action("look","l");
}
look(str) {
		if(!str || str !="at vine");
	else {
		write("This is a thick vine, maybe you could swing on it.\n");
		return 1;
	}
}
