inherit"obj/weapon";
int hp;
object env;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("teeth");
   set_short("Sharp teeth");
   set_long(
      "These are some very sharp teeth taken from a corpse of a\n"
      + "wild dog in Joris.  Damn, they hurt just holding them.\n");
   set_value(1000);
   set_weight(2);
   set_class(15);
}
player_stuff() {
		int x;
		x=random(3);
   if(env->is_player()){
      if(env->query_hp() >50)  env->add_hit_point(-10+random(-15));
/*
	if(x<2) { write("blah\n"); }
	if(x<3 && x>1) { say("ouch\n"); }
	if(x<4 && x>2) { say("hehe\n"); }
*/
say("		OUCH!!!!!!!!\n");
		call_out("player_stuff",50+random(100));
	 return 1;
   }
}
init(){
   ::init();
   env=environment(this_object());
   if(env->is_player()) call_out("player_stuff",20);
   else remove_call_out("player_stuff");
}
