#include "room.h"
TWO_EXIT("/players/gorgan/closed/quest/tree2.c","up",
	"/players/gorgan/closed/quest/forest3.c","east",
   "A deserted road",
	"   You are standing at the enterance of very large pine forest.\n"+
	"There are so many pine trees, that they forbid you passage in some\n"+
	"directions.  There is a very large tree blocking your passage to the\n"+
	"south.\n",
   1)
