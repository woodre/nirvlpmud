#include "std.h"
int locked;
/*  Refers the program to a "std.h" file, a basic room set up   */

reset(arg){
     if(!arg){
     locked=0;
     set_light(1);
     }
}
/*  Sets what the room will do at reset(In this case, make it a lighted room)  )*/

init(){
/*  A very important basic function.  All of the actions that this room
does are put in this function.  */

  if(this_player()->query_real_name()!="gorgan"&&locked==1) {
    write("This room has been locked.\n");
    move_object(this_player(),"/room/church");
    return 1; }
  add_action("lock","lock");
  add_action("unlock","unlock");
     add_action("exit_shop","shop");
/*   This links a command (In this case, an exit) with a function.  When
you type "shop", the room goes to the init() function, looks for "shop",
and then goes to the function which is defined later in the program.
*/
     add_action("exit_church","church");
}
/*    You can add more exits and functions later by adding an add_action()
line in the init() function and defining the function later.
*/

exit_shop(){
     call_other(this_player(), "move_player",
       "shop#room/shop");
     return 1;
}

exit_church(){
     call_other(this_player(), "move_player",
       "church#room/church");
     return 1;
}


/*  Above, we see the init() functions defined.    */
short(){ return "Milwaukee's Best Brewery(Gorg's workroom)"; }

/*   You can change it     */
long(){
	write("  Gorgan's personal Beast brewery.\n");
     write("There are two obvious exits: shop and church\n");
}
/*    I'm sure you'll want to change that    */

lock() {
  if(this_player()->query_real_name()=="gorgan") {
    write("The room is locked.\n");
    locked=1;
    return 1; }
  return 0;
}

unlock() {
  if(this_player()->query_real_name()=="gorgan") {
    write("The room is unlocked.\n");
    locked=0; return 1; }
  return 0;
}
