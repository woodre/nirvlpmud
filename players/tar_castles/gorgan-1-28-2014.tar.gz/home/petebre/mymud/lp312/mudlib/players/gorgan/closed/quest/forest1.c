#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
object climb;
extra_reset() {
	climb=clone_object("/players/gorgan/closed/quest/climb.c");
	move_object(climb, this_object());
}
TWO_EXIT("/players/gorgan/closed/quest/roomC.c","west",
	"/players/gorgan/closed/quest/forest1.c","east",
   "A deserted road",
	"   You are standing at the enterance of very large pine forest.\n"+
	"There are so many pine trees, that they forbid you passage in some\n"+
	"directions.  There is a very large tree blocking your passage to the\n"+
	"south.\n",
   1)
init() {
	::init();
	add_action("look","look");
	add_action("look","l");
}
look(str) {
	if(!str || str !="at tree");
	else {
		write("This is a very large pine tree.\nMaybe you could climb it?\n");
		return 1;
	}
}
