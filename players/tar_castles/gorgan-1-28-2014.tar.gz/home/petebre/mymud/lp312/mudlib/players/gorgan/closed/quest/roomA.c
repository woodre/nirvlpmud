#include "room.h"
TWO_EXIT("/players/gorgan/room/room1.c","west",
	"/players/gorgan/closed/quest/roomB.c","east",
   "A deserted road",
	"   You are walking down an old deserted town road.  These roads used to be\n"+
	"crowded during the day when farmers were in town to go shopping or to relax\n"+
	"at a local pub.  People will not come here any longer because it isn't\n"+
	"safe.  There are many of Karne's followers who still wander around here.\n"+
	"Also, there are many evil creatures that live in the buildings\n"+
	"for shelter.\n",
   1)
