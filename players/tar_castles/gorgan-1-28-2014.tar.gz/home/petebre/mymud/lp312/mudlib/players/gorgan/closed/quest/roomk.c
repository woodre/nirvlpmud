inherit "room/room";
object arm;
reset(arg) {
  if(!arg) {
	arm=clone_object("/players/gorgan/closed/quest/arm.c");
	move_object(arm,this_object());
	set_light(1);
	short_desc="A barren area";
	long_desc =
	"   This used to be farming land when Joran still lived.  Now it is\n"+
	"just barren land because Karne has taken over.\n";
dest_dir = ({
	"/players/gorgan/closed/quest/roomi.c","north",
	"/players/gorgan/closed/quest/roomh.c","west",
	});
}
}
