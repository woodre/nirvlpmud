#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
int x;
init(){
	::init();
	add_action("dig","dig");
}
object rogue, leg;
extra_reset() {
	rogue=clone_object("/players/gorgan/mons/rogue.c");
	move_object(rogue, this_object());
	rogue=clone_object("/players/gorgan/mons/rogue.c");
	move_object(rogue, this_object());
}
ONE_EXIT("/players/gorgan/closed/quest/roomC.c","south",
	"An old shop",
	"   This is the old town shop of Joris.  It is pretty run down now.  There\n"+
	"are shelves, cubboards, and counters on the east and west walls.  You\n"+
	"are standing on a strange dirt floor.  There are two of Karne's henchman\n"+
	"resting in the corner. \n",
   1)
dig() {
  if(x>0) {
	write("You find nothing.\n");
	return 1;
	}
	leg=clone_object("/players/gorgan/closed/quest/leg.c");
	move_object(leg, this_object());
	x=1;
	write("You uncover what appears to be a leg.\n");
	return 1;
}
