is_undead_morph(){ return 1; }
