id(str) { return str == "coins"; }
short() { return "10000 gold coins"; }
long() { write(short() +"\n"); }
init(){ add_action("get","get");}
get(arg){
	if(arg=="all" || arg=="coins"){
	   if(random(100)<50){
         this_player()->add_money(-10000);
	write("10000 gold coins. Ok.\n");
         destruct(this_object());
      } else {
         this_player()->add_money(10000);
	write("10000 gold coins. Ok.\n");
         destruct(this_object());
      }
   }
   return 1;
}
