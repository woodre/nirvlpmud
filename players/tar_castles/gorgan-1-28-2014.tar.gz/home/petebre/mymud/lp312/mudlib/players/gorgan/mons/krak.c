inherit "obj/monster";
object attacker;
string attacker_name;
int var,x,tent;
reset(arg){
   object gold,tentacle;
   ::reset(arg);
   if(arg) return;
   set_name("kraken tentacle");
   tent=4;
   set_race("monster");
   set_alias("kraken");
   set_short("A many armed kraken");
   set_long("I hope you are strong! This giant sea creature\nhas tentacles that can grab and hold you!\nIt now has " + tent + " such tentacles.\n");
   set_level(45);
   set_hp(3000);
   set_al(-700);
   set_wc(14);
   set_ac(11);
   set_aggressive(1);
   gold=clone_object("obj/money");
   gold->set_money(3500);
   move_object(gold,this_object());
   tentacle=clone_object("players/ladyfinger/obj/tentacle");
   move_object(tentacle,this_object());
   tentacle=clone_object("players/ladyfinger/obj/tentacle");
   move_object(tentacle,this_object());
   tentacle=clone_object("players/ladyfinger/obj/tentacle");
   move_object(tentacle,this_object());
   tentacle=clone_object("players/ladyfinger/obj/tentacle");
   move_object(tentacle,this_object());
   set_heart_beat(1);
}
refresh_desc(){
   set_long("I hope you are strong! This giant sea creature\nhas tentacles that can grab and hold you!\nIt now has " + tent + " such tentacles.\n");
   return;
}
heart_beat(){
   int health;
   object room;
   room=environment(this_object());
   attacker=this_object()->query_attack();
   health=this_object()->query_hp();
   if(health > 2200){
      tent=4;
      refresh_desc();
   }
   if(health < 400){
      tent=1;
      refresh_desc();
   }
   if(health < 2201 && health > 1000){
      tent=3;
      refresh_desc();
   }
   if(health < 1001 && health > 399){
      tent=2;
      refresh_desc();
   }
   if(tent == 1){
      ::heart_beat();
   }
   if(tent == 2){
      ::heart_beat();
      ::heart_beat();
   }
   if(tent == 3){
      ::heart_beat();
      ::heart_beat();
      ::heart_beat();
   }
   if(tent == 4){
      ::heart_beat();
      ::heart_beat();
      ::heart_beat();
      ::heart_beat();
   }
   x++;
   if(x==15){
      x=0;
      if(attacker){
         attacker_name=attacker->query_real_name();
         if(present(attacker_name,environment(this_object()))){
            
            if(random(3)==2){
               
               attacker->hit_player(random(25));
               tell_room(room,"The kraken has grabbed someone!\n");
               move_object(attacker,"/players/ladyfinger/room/drow/arms");
               command("look",attacker);
               return 1;
            }
            return 1; 
         }
         return 1;
      }
      return 1;
   }
   return 1;
}
