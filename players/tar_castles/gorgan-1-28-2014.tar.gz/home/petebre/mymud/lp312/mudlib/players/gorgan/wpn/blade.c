inherit "obj/weapon";
int die, attacker, pain;
reset(arg) {
::reset(arg);
        if(!arg) {
                set_name("blade");
                set_class(15);
                set_value(450);
                set_weight(4);
                set_alias("sword");
                set_short("A dull blade");
set_long("This metal blade seems a little dull, but it should do the job pretty well.\n");
set_hit_func(this_object());
}
}
weapon_hit(attacker)
  {
if (random(100) < 20) return -10;
}
