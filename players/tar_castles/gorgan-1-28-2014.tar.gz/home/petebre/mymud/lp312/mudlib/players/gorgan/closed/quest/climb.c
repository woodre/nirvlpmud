short() { return 0; }
long() { return 0; }
id(str) { return 0; }

init() {
	add_action("climb","climb");
	}
climb(str) {
if(!str || str !="tree") {
	write("Climb  what?\n");
	return 1;
}
else if(str == "tree") {
	object user;
	user=this_player();
	tell_object(user, "You climb the tree slowly.\n\n");
	tell_object(user, "\n");
	this_player()->move_player("via secret exit#players/gorgan/closed/quest/tree.c");
	return 1;
}
	}
