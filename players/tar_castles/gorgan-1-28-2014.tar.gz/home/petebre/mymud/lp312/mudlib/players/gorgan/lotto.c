inherit "obj/treasure";
reset(arg) {
	if(arg) return;
			set_short("An INSTANT Lottery Ticket");
			set_alias("ticket");
		set_long("An Instant Lottery Ticket.\n"+
		"To play just type 'scratch off'.  You could win a ton of\n"+
		"gold coins INSTANTLY!\n"+
			"(Or you could lose)\n");
}
init() {
        ::init();
	add_action("scratch","scratch");
}
scratch(str) {
	int x;
		if(!str || str !="off") return;
		write("You scratch off your INSTANT Lottery Ticket!\n");
		say("You hear the scratching of a Lotto ticket nearby.\n");
	x=random(10000);
	if(x<5) {
		write("You win 60000 gold coins!!!\n");
		this_player()->add_money(60000);
	}
  else if(x>8000) {
            write("You win 100 gold coins!!!\n");
            this_player()->add_money(100);
    }
    else if(x<15 && x>5) {
            write("You win 30000 gold coins!!!\n");
             this_player()->add_money(30000);
     }
	else if(x<1000 && x>15) {
		write("You win 200 gold coins!!!\n");
		this_player()->add_money(200);
	}
	else {
		write("Better luck next time.\n");
	}
		destruct(this_object());
		write("The ticket disappears from your FAT little greedy hands.\n");
		return 1;
}
