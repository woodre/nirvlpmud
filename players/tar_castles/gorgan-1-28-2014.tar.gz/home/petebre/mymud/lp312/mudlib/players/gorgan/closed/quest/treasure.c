string name, alias, alt_name, short, long;
int weight, value, get, drop;
string read, info;
set_name(nm){ name = nm; }
set_alias(al){ alias = al; }
set_alt_name(alt){ alt_name = alt; }
set_short(sh){ short = sh; }
set_long(l){ long = l; }
set_get(g){ get = g; }
set_drop(d){ drop = d; }
set_weight(w){ weight = w; }
set_value(v){ value = v; }
set_read(re){ read = re; }
set_info(in){ info = in; }
reset(arg){
   if(!arg && !get) get = 1;
   if(!name) name = "Treasure";
   if(!alias) alias = short;
   if(!alt_name) alt_name = alias;
}
id(str){ return str == name || str == alias || str == alt_name; }
get(){ return get; }
drop(){ return drop; }
short(){ if(!short) return name;  return short; }
long(){
   if(!long) write(short+".\n");
   else write(long);
}
query_weight(){ return weight; }
query_value(){ return value; }
query_name(){ return name; }
query_alias(){ return alias; }
query_alt_name(){ return alt_name; }
query_info(){ return info; }
query_read(str){
   if(!id(str) || !read) return 0;
   write(read);
   return 1;
}
init(){
   if(read) add_action("query_read","read");
}
