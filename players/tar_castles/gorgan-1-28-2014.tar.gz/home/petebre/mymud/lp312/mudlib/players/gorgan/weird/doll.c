
inherit "obj/weapon";
reset(arg) {
        if(!arg) {
 set_name("doll");
set_class(13);
set_value(500);
set_weight(1);
set_short("A blow up doll");
 set_long("A blow up doll made for sex and fighting.\n"+
"To have sex with the doll type 'sex doll'.\n"+
"To fondle the doll type 'fondle doll'.\n"+
"To show everyone your doll type 'show doll'.\n");
   }
}


init() {
::init();
   add_action("sex_with_doll","sex");
 add_action("show_doll_others","show");
 add_action("fondle_doll","fondle");
add_action("show_butt_player","butt");
   }

sex_with_doll(str) {
   if(!str) return 0;
   if(str!="doll") return 0;
write("You really fuck the shit out of that doll.\n");
write("The doll moans with passion.\n");
say( capitalize(this_player()->query_name()) + " has sex with a doll."+
"\n");
return 1;
}
show_doll_others(str) {
if(!str) return 0;
if(str!="doll") return 0;
 write("You show everyone your doll.\n");
 say(capitalize(this_player()->query_name()) +" shows you a sex doll."+
"\nYou fall down laughing.\n");
return 1;
}
fondle_doll(str) {
 if(!str) return 0;
if(str!="doll") return 0;
write("You fondle the dolls private parts.\n");
say(capitalize(this_player()->query_name()) +" fondles a doll.\n");
return 1;
}
show_butt_player(str) {
if(!str)return 0;
if(str!="doll") return 0;
write("The doll rips down its pants and moons everyone.\n");
say(capitalize(this_player()->query_name()) +" has the sex doll moon you.\n");
return 1;
}
