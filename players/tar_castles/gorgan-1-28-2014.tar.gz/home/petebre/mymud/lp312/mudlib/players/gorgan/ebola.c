inherit "obj/treasure";
object env;
int x;
reset(arg) {
   if(arg) return;
       set_alias("ebolla");
       set_long("A disgusting worm virus.\n"+
                "This shit is nasty as fuck!\n");
}
player_stuff() {
    if(env->is_player()){
    if(env->query_hp() >50)  env->add_hit_point(-25);
    call_out("player_stuff",20);
       x=random(10);
       if(x==1) {
            write("Your flesh begins to feel like mush.\n");
		say("this guys skin looks shitty.\n");
/*
            say(call_other(this_player, "query_name", 0) "'s skin looks like a pulpy mush!\n");
*/
       if(x==2) {
            write("Your bowels open at the spincter and vent blood\n");
	    say("You hear a lound sound from "call_other(this_player, "query_name", 0) "'s bowels.\n");
	}
       if(x==3) {
	     write("Ohh Shit!\n");		
        }
    return 1;
   }
}
init(){
   ::init();
   env=environment(this_object());
   if(env->is_player()) call_out("player_stuff",20);
   else remove_call_out("player_stuff");
}
