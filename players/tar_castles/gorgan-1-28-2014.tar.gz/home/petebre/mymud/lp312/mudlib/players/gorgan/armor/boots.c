inherit "obj/armor";
reset(arg) {
::reset(arg);
	set_short("Leather boots");
	set_long("This is a pair of brown leather boots.  They are very worn but\n"+
	"they look comfortable.\n");
	set_ac(-1);
	set_value(1000);
	set_weight(1);
	set_name("boots");
	set_alias("boots");
	set_type("boots");
	}
