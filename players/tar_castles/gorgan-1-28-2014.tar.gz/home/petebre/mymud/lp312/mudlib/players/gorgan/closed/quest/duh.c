short() { return 0; }
long() { return 0; }
id(str) { return 0; }

init() {
	add_action("swing","swing");
	}
swing(str) {
if(!str || str !="vine") {
	write("Swing on what?\n");
	return 1;
}
else if(str == "vine") {
	object user;
	user=this_player();
	tell_object(user, "As you lift the gate you stumble over some rubble\n" +
"from the road.  As you look back at where you were standing you\n" +
"realize the road used to be there too but was just wiped away...\n");
	tell_object(user, "\n");
	this_player()->move_player("via secret exit#players/gorgan/closed/quest/tree.c");
	return 1;
}
	}
