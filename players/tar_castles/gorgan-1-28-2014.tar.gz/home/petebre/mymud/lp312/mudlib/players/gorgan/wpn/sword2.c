inherit"obj/weapon";
	query_save_flag() { return 1;}
reset(arg) {
::reset(arg);
if(arg) return;
set_name("sword");
set_short("Sword of Annihilation");
set_long(
"This a very powerful sword.  This sword was forged by Karne, an evil\n"
+ "human with incredible powers.  He used this sword to defeat the immortal \n"
+ "Joran.  You have never weilded a weapon of such power.  You feel\n"
+ "incredibly strong as you slice the sword through the air.\n");
set_value(20000);
set_weight(3);
set_class(21);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100)<30 && attacker->query_race() == "all") {
write("You slice "+attacker->query_name()+"'s stomach open."+"\n"+"Guts fall all over the floor.\n");
say(this_player()->query_name()+" swings his sword with such fury.\n");
return 10;
   }
 }
