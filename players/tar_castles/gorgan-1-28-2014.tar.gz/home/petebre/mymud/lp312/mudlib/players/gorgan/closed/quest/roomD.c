#include "room.h"
TWO_EXIT("/players/gorgan/closed/quest/roomC.c","west",
	"/players/gorgan/closed/quest/forest1.c","east",
   "A deserted road",
	"  You are on and old town road.  To the north and south you see\n"+
	"deserted old houses in shambles.  The road conitinues to the west.\n"+
	"To the east there is a forest.\n",
   1)
