inherit "room/room";
reset(arg){
   if(arg) return;
        set_light(1);
        short_desc = "Kwam's shop";
     long_desc =
"This is the local blood bank. They sell bags of blood as healing\n"+
"elements. To buy something type buy <number>. The types of blood\n"+
"available are:\n";
      dest_dir = 
({
	"/players/gorgan/closed/quest/roomi.c",climb,
	  "/players/gorgan/enter.c","out",
      });
}
init() {
	::init();
	add_action("climb","climb");
}
climb(str) {
	if(!str || str !="tree");
	this_player()->move_player("climb#/players/gorgan/closed/quest/roomi.c");
	return 1;
}
