#include "room.h"
object swyle;
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

extra_reset() {
  if(!present("swyle")) {
      swyle=clone_object("/players/gorgan/mons/swyle.c");
      move_object(swyle, this_object());
    }
  }

TWO_EXIT("/players/gorgan/shop.c","west",
	"players/gorgan/shopext/room2.c","east",
         "Store Room",
		"   As you come through the lighted doorway you enter an old store room.\n"+
		"There are dusty bare shelves all along the walls.  It doesn't look like items   have been stored back here in ages.\n",
         1)
