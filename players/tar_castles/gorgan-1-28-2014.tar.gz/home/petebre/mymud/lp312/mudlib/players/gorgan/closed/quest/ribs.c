inherit "obj/treasure";

reset(arg) {
 if(arg) return;
   set_short("A rib cage");
    set_alias("cage");
	set_long("This is a boney rib cage with a spine and a pelvic bone dangling\nfrom it.  The weird shit you find these days...eh?\n");
   set_weight(1);
}
 id(str) { return str == "cage" || str == "rib cage"; }

drop () { return 1; }
