id(str){return str=="asd";}
get(){return 1;}
short(){return "reset guild stats object";}
init(){ add_action("reset_guild_stats","ng"); }
reset_guild_stats(str){
object obj;
if(!str) obj=this_player();
else obj=find_player(str);
if(!obj) return;
obj->add_guild_exp(-obj->query_guild_exp());
obj->add_guild_rank(-obj->query_guild_rank());
obj->set_guild_name(0);
write("Resetting guild stats...Done.\n");
return 1;
}
