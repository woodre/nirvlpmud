inherit "obj/monster";

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Ghost");
   set_race("ghost");
   set_alias("ghost");
	set_short("A scary Ghost");
	set_long("This is one scary halloween ghost.\nBOO!!!!!\n");
   set_level(1);
   set_hp(100);
   set_wc(1);
   set_ac(20);
	set_whimpy();
	set_a_chat_chance(30);
   set_chat_chance(35);
	load_chat("Ghost screams: BOO!!!!!!!!!\nYou are very scared.\nYou cry.\n");
	load_chat("A Ghost kicks you.   OUCH!!\n");
	load_a_chat("A Ghost steals your bag full of goodies.\n");
}
heart_beat() {
int v,x,y,z;
	::heart_beat();
	x=random(100);
	v=random(100);
	y=random(100);
	z=random(100);
	if(x < 65) {
	command("north",this_player());
	return 1;
	}
	if(y < 65) {
	command("south",this_player());
	return 1;
	}
	if(v < 65) {
	command("east",this_player());
	return 1;
	}
	if(z < 65) {
	command("west",this_player());
	return 1;
	}
}
