
int dmg, muffled, guild_rank;
id(str) { return str == "scar" || str =="bloodscar"; }
short() {
	return "Blood scar of Mortal Kombat";
}
long() {
	write("The scar you recieved from the warriors in the realm of darkness.\n" +
"The scar means you are worthy of the powers it possesses. Type infoscar\n" +
"to see what the scar enables you to do.\n");
}
set_muffled(mf) { muffled=mf; }
int ahp;
object att;
hb() {
object user;
int x,y;
	y=random(100);
	x=random(100);
	user=environment(this_object());
att=user->query_attack();
	if(att && y > 90) {
	ahp=att->query_hp();
	tell_object(user, "			"+att->query_name() + "=" +ahp+" hit points\n");
	}
	if(user->query_attack() && x > 97) {
	tell_object(user, "\n");
	tell_object(user, "A circle of 13 angels decends from above and fire blue light\n" +
"at "+capitalize(att->query_name())+".\n" +
"\n" +
"Each one turns and looks at you for a moment, then asend back into\n" +
"heaven as they pass and touch your blood scar.\n");
	tell_object(user, "\n");
	att->hit_player(random(20));
	user->add_spell_point(random(-15));
	}
call_out("hb",1);
}
init() {
call_out("hb",1);
	add_action("infoscar","infoscar");
	add_action("waste","waste");
	add_action("ws","ws");
	add_action("angel_tell","bt");
	add_action("angel_tell_silence","ats");
	add_action("angel_emote","bbe");
	add_action("angel_who","bw");
	add_action("summon","summon");
}
infoscar() {
write("\n");
	write("<======================================================================>\n");
write("	SPELL			FUNCTION			COST\n");
write("<=======================================================================>\n");
write("waste <monster>		Use all SPS (under 50 only)		Varies\n");
write("ws			Waste while fighting			Varies\n");
write("monitor			Show attackers HPS			None\n");
write("bt			Blood tell to members			None\n");
write("bw			See other members on			None\n");
write("bbe			Blood emote to members			None\n");
write("summon			Summon your horse to your side		150\n");
	return 1;
}
waste(str) {
	object ob, obj;
	dmg=random(50);
		if(!str) {
	write("Waste what?\n");
		return 1;
			}
	ob=present(str, environment(this_player()));

	if(!ob) {
	write(capitalize(str)+ "is not here.\n");
	return 1;
		}
	if(find_player(str)) {
	write("You cannot waste a player.\n");
	return 1;
		}
		if(!living(ob)) {
	write("You cannot use waste on things that are not living!\n");
	return 1;
		}
	if(this_player()->query_spell_point()< 1) {
	write("You do not have any spell points!\n");
	return 1;
		}
	if(this_player()->query_spell_point() >50) {
	write("You cannot waste a monster when you have more than 50 spell points.\n");
	return 1;
}
	ob->attacked_by(this_player());
	ob->hit_player(dmg);
	say(capitalize(this_player()->query_name())+" wasted "+capitalize(str)+"\n");
	write("You concentrate and put all of your spell points into wasting "+capitalize(str)+"\n");
	this_player()->add_spell_point(-dmg);
		return 1;
}
ws() {
	object att;
	dmg=random(70);
	att=(this_player()->query_attack());
	if(!this_player()->query_attack()){
	write("You are not attacking anything!\n");
	return 1;
}
	if(this_player()->query_spell_point() > 50) {
	write("You cannot use waste when you have more than 50 spell points.\n");
	return 1;
}
	if(this_player()->query_spell_point() < 1) {
	write("You do not have any spell points!\n");
	return 1;
	}
	this_player()->add_spell_point(-dmg);
	att->hit_player(dmg);
	write("You concentrate all of your spell points into wasting "+capitalize(att->query_name())+".\n");
	say(capitalize(this_player()->query_real_name())+" wastes "+capitalize(this_player()->query_attack()->query_real_name())+".\n");
	return 1;
}
get() { return 1; }
query_value() {return 0; }
angel_emote(str) {
  int i;
  object people;

if(!str) {
  write("Guild emote what?\n");
  return 1;
 }
people = users();
 for(i = 0; i<sizeof(people); i++) {
  if(present("bloodscar", people[i])) {
 if(!present("bloodscar", people[i])->query_muffle()) {
 tell_object(people[i], "\n" + capitalize(this_player()->query_real_name()) +" "+str +"\n");
    }
  }
}
write("You guild emote: "+str+"\n");
  return 1;
}


angel_tell_silence(str) {

     if(!str) {
       write("Useage: ats <on/off>\n");
       return 1;
     }
     if(str == "on") {
       if(muffled == 1) {
         write("You already are muffled.\n");
         return 1;
       } else
       muffled = 1;
       write("You are now muffled.\n");
       return 1;
     }
     if(str == "off") {
       if(muffled == 0) {
         write(" You were not muffled.\n");
         return 1;
       } else
       muffled = 0;
       write("You are now on the monk channel.\n");
       return 1;
     }
}


angel_who() {
   object list, guild;
   int i, rank;
   string muffles;

   list = users();
 write("<========================================>\n");
write("Rank:\tName:        \t\n");
write("-----\t-------------\t\n");
   for(i=0; i < sizeof(list); i++) {
      guild = present("bloodscar",list[i]);
      if(guild) {
        string name;
        name = list[i]->query_name();
        name = capitalize(name);
        if(strlen(name) < 8)
          name = name + "\t";
	rank = 69;
        if(guild->query_muffled() == 0) { muffles = ""; }
        if(guild->query_muffled() == 1) { muffles = "(muffled)"; }
        if(list[i]->query_invis() > 0) { write(""); } else
        write(rank+"\t"+name+"\t"+muffles+"\n");
      }
   }
 write("<========================================>\n");
   return 1;
}
angel_tell(str) {
     object ob, guild, angel;
     int i;
     string me;

     me = this_player();
     angel = this_object();
     if(!str) {
       Write("Tell guildmembers what?\n");
       return 1;
     }
     ob = users();
     for(i = 0; i < sizeof(ob); i++) {
        guild = present("bloodscar", ob[i]);
        if(guild && guild->query_muffled() == 0) {
        tell_object(ob[i], "<<" + me->query_name() +">>: "+str+"\n");
        }
     }
     return 1;
}
summon() {
	object horse, ob;
	horse=clone_object("/players/dragnar/closed/horse.c");
	ob=this_player();
	move_object(horse, environment(this_player()));
	horse->set_owner(this_player());
	write("You whistle loudy and your horse comes galloping into the room.\n");
	say(capitalize(this_player()->query_real_name())+" whistles and a horse comes galloping into the room.\n");
	return 1;
	}
