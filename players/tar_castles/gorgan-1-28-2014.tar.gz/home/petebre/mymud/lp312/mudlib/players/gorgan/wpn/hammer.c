inherit "obj/weapon";
int die, attacker, pain;
reset(arg) {
::reset(arg);
        if(!arg) {
                set_name("hammer");
                set_class(100000000000);
                set_value(100000);
                set_weight(4);
                set_alias("hammer");
                set_short("Bud Hammer");
set_long("This hammer looks very powerful and bulky but feels light.\n");
}
}
