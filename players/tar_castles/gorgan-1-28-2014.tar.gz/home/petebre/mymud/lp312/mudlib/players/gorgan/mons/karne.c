inherit "obj/monster.talk";
reset(arg) {
   object weapon;
   object treasure;
   ::reset(arg);
   if(arg) return;
   set_name("karne");
   set_short("Karne the Deadly.");
   set_long(
      "weird\n");
   set_level(35);
   set_race("human");
   set_hp(1250);
   set_al(-1000);
   set_wc(55);
   set_ac(40);
   set_aggressive(1);
   set_chance(3);
   set_spell_dam(1000);
   set_spell_mess1("weird");
   set_spell_mess2("weirder");
	weapon = clone_object("/players/gorgan/wpn/sword2.c");
   if(weapon) {
      move_object(weapon,this_object());
   }
	treasure = clone_object("/players/gorgan/closed/quest/skull1.c");
   if(treasure) move_object(treasure,this_object());
}
