inherit"obj/monster";

reset(arg) {
	object gold, hammer;
  ::reset(arg);
  if(!arg) {

   set_name("budman");
   set_short("Budman");
   set_long("Budweiser ain't bad unless compared to beast.\n");
   set_level(20);
   set_hp(600);
   set_wc(30);
   set_ac(17);
	set_aggressive(1);
	hammer=clone_object("players/gorgan/wpn/hammer.c");
	move_object(hammer, this_object());
	gold=clone_object("obj/money");
	gold->set_money(2000);
	move_object(gold,this_object());
   }
}
