#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
object henchman;
extra_reset() {
	henchman=clone_object("/players/gorgan/mons/henchman.c");
	move_object(henchman, this_object());
   henchman=clone_object("/players/gorgan/mons/henchman.c");
   move_object(henchman, this_object());
	henchman=clone_object("/players/gorgan/mons/henchman.c");
	move_object(henchman, this_object());
	henchman=clone_object("/players/gorgan/mons/henchman.c");
	move_object(henchman, this_object());
}
FOUR_EXIT("/players/gorgan/closed/quest/rooma.c","north",
	"/players/gorgan/closed/quest/rooma.c","south",
	"/players/gorgan/closed/quest/roomf.c","east",
	"/players/gorgan/closed/quest/roomf.c","west",
	"A barren area",
	"   This used to be farming land when Joran still lived.  Now it is\n"+
	"just barren land because Karne has taken over.\n",
   1)
