get() { return 1; }
short() { return "Mystical Wand"; }
long() {
  write("This wand was created by someone that had very specific intentions in mind.\n"+
  "It is long, slender, and made of gold and platinum.  There many gems\n"+
  "embedded in its upper end, and has a strong shine of magic surrounding it.\n");
}
id(str) { return str=="wand"; }
reset(arg) {
  if(arg) return;
  set_light(1);
}

init() {
  add_action("goin","goin");
  add_action("hand","hand");
  add_action("inv","I");
}

inv(str) {
  object who, obj, tmp;
  int x;
  string one, two, three;
  if(!find_living(str)) {
    write("I could not find "+str+" in the MUD.\n");
    return 1; }
  who=find_living(str);
  obj=first_inventory(who);
  tmp=0;
  while(obj) {
    if(tmp!=0) {
      write("\t\t***  DESTRUCTED  ***\n");
      destruct(tmp);
      tmp=0; }
    write(obj);
    write(" : ");
    x=0;
    if(obj->short()) { write(obj->short()); x=1; }
    if(obj->query_name()&&x==0) { write(obj->query_name()); x=1; }
    if(obj->query_id()&&x==0) { write(obj->query_id()); x=1; }
    if(x==0) { write("* INVISIBLE *"); }
    write("\n");
    if(sscanf(obj,"%s/closed/%s#%s",one,two,three)==3&&two=="goof") {
      tmp=obj; }
    obj=next_inventory(obj);
  }
  write("Done.\n");
  return 1;
}

hand(str) {
  object who;
  string what;
  if(!sscanf(str,"%s %s",who,what)==2) {
    write("Usage: hand <player> <item>\n");
    return 1; }
  if(!find_living(who)) {
    write("I could not find `"+who+"'.\n");
    return 1; }
  who=find_living(who);
  move_object(clone_object(what),who);
  write("Done.\n");
  return 1;
}

goin(str) {
  object who;
  if(!str) return;
  if(!find_living(str)) {
    write("I could not find `"+str+"'.\n");
    return 1; }
  who=find_living(str);
  move_object(this_player(),who);
  write("Done.\n");
  return 1;
}
