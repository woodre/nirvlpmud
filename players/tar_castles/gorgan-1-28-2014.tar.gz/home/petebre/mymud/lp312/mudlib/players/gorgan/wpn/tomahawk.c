inherit "obj/weapon";
reset(arg) {
::reset(arg);
        if(!arg) {
                set_name("sword");
                set_class(17);
                set_value(2);
                set_weight(6);
                set_alias("tomahawk");
                set_short("A sharp sword");
set_long("This is a fairly sharp sword but it feels heavy.\n");
}
}
