inherit"obj/monster";

reset(arg) {
		object teeth;
  ::reset(arg);
  if(!arg) {

   set_name("dog");
   set_short("A wild dog");
	set_long("This is one of many animals that still live here starving to death.\nIt might be a good idea to go back to where you have come from.\n");
   set_level(17);
   set_hp(425);
   set_wc(25);
   set_ac(14);
	set_al(-1000);
	teeth=clone_object("/players/gorgan/wpn/teeth.c");
	move_object(teeth, this_object());
	set_aggressive(1);
	set_chat_chance(5);
load_chat("A wild dog snarls at you!\n");
load_chat("A wild dog growls.\n");
	set_chance(20);
set_spell_dam(15);
set_spell_mess2("A wild dog shreaks a horrible growl!\nYou cover your ears.\nA wild dog's teeth grasp your groin!\nYou scream in pain!\n");
set_spell_mess1("A wild dog shreaks a horrible growl!\n");
   }
}
