inherit "obj/armor";
reset(arg) {
::reset(arg);
	set_short("A golden ring");
	set_long("  A shiny gold ring. It looks very expensive, but it might be useful.\n");
	set_ac(3);
	set_value(4000);
	set_name("ring");
	set_alias("ring");
	set_type("ring");
	}
