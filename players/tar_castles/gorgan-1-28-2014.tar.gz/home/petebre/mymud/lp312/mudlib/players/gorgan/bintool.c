#include "/players/mathiast/bin/cmd_hook.c"
id(str){
   return str == "bintool" || str == "Mathiast's bintool" ;
}
get(){ return 1; }
drop(){ return 1; }
init(){
   add_action("cmd_hook"); add_xverb("");
}
short(){ return "Bintool (test)"; }
