#include <ansi.h>
get(){ return 0; }
id(str){ return str == "sign"; }
short(){ return "A " + BLINK + "Strange" + WHT + NONE + " sign"; }
long(){ write("Please read sign.\n"); }
init(){add_action("read","read"); }
read(str){
if(!str || str != "sign") return;
else {
	write(
	"This is the enterance to what used to be Joris, a peaceful village, with\n"+
	"many friendly citizens waiting to greet all visitors.  It is now deserted\n"+
	"because of the fall of the immortal Joran.  Joran was a very kind ruler\n"+
	"who always gave his citizens everything they needed, until he was defeated \n"+
	"by Karne and his evil henchman Beast.  Joran rests in another world waiting\n"+
	"for someone to place his scattered limbs near one another and undo all that\n"+
	"Karne has done.\n"+
	"Are you the one who can save Joris?\n");
return 1;
}
}
