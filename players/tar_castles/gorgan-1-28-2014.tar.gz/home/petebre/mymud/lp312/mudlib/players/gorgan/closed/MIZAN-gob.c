#define GUILD_ID "Mizan-guild-object"
#define GUILD_NAME "polymorph"
#define GUILDFILE "/players/mizan/closed/poly/gob.c"
#define MASTER_R "/players/mizan/closed/poly/PDM.c"
#define SAVE_PATH "players/mizan/closed/poly/players/"
#define CHARGE_MAX 2300

/* toggles */
int invis_tl;
int muffle_tl;
int ansi_tl;
int monitor_tl;
int drain_tl;
int eval_tl;
int news_tl;
int spellbooks_tl;

/* set variables */
int monitor_interval;
int screen_height;
string curr_morph;
string saved_pretitle;
string saved_title;
string main_stats;

int news_index;

string panic_key;
string superstat_key;
string nickname;

/* others */

static int charge_power;
static string comm_prefix;
static string self_file;
string new_hd;
string new_body;

id(str) { return str == GUILD_ID || str == "lump" || str == "clay"; }

short() {
  if(invis_tl && this_player()) {
    if(this_player()->query_guild_name() == GUILD_NAME ||
    this_player()->query_level() > 20) return "A lump of magical clay (invis)";
    else return 0;
  }
  return "A lump of magical clay";
}

long() {
  write("This appears to be just any old lump of clay but it has many\n"+
  "powers and abilities, the most important of them keeping the matrix\n"+
  "of your being- which frees you to polymorph into different shapes.\n"+
  "It pulsates with a strangely powerful yet pleasant feeling.\n\n"+
  "Type 'guild help' for a list of info and abilities.\n");
  if(charge_power) write("There are [" + charge_power + "] charges accumulated in the clay's matrix.\n");
}

get() { return 1; }
drop() { return 1; }

query_ansi() { return ansi_tl; }
query_drain() { return drain_tl; }
query_eval() { return eval_tl; }
query_invis() { return invis_tl; }
query_monitor() { return monitor_tl; }
query_muffle() { return muffle_tl; }
query_news_announce() { return news_tl; }

query_spellbooks() { return spellbooks_tl; }

query_main_stats() { return main_stats; }
query_charge() {
  if(charge_power < 0) charge_power = 0;
  return charge_power;
}
query_morph_comm() { return comm_prefix; }
query_current_morph() { return curr_morph; }
query_pretitle() { return saved_pretitle; }
query_title() { return saved_title; }

query_nickname() { return nickname; }
query_panic_key() { return panic_key; }
query_superstat_key() { return superstat_key; }
query_screen_height() { return screen_height; }
query_monitor_interval() { return monitor_interval; }
query_news_index() { return news_index; }

set_current_morph(str) { curr_morph = str; }
set_morph_comm(str) { comm_prefix = str; }
set_pretitle(str) { saved_pretitle = str; }
set_title(str) { saved_title = str; }

set_nickname(str) { nickname = str; }
set_panic_key(str) { panic_key = str; }
set_superstat_key(str) { superstat_key = str; }
set_screen_height(str) { screen_height = str; }
set_monitor_interval(str) { monitor_interval = str; }
set_news_index(str) { news_index = str; }

set_main_stats(str) { main_stats = str; }

reset(arg) {
  self_file = this_player()->query_real_name();
  if(!restore_object(SAVE_PATH + self_file)) destruct(this_object());
  if(!monitor_interval) monitor_interval = 3;
  if(!screen_height) screen_height = 23;
  if(!arg) {
    MASTER_R->entrance();
    MASTER_R->undo_polymorph("silent");
  }
}

init() {
  object ob;
  ob = present(GUILD_ID, environment(this_object()));
  if(ob && ob != this_object()) destruct(this_object());
  add_action("guild_function","guild");
  add_action("locker_function","locker");
  add_action("polymorph_function","polymorph");
  add_action("set_function","set");
  add_action("info_function","info");
  add_action("toggle_function","toggle");

  add_action("guild_tell","vibe");
  add_action("superwho","superwho");
  add_action("regain_corpse","regain");
  add_action("regain_corpse","rc");
  add_action("charge_clay","charge");
  add_action("atomize_object","atomize");
  add_action("survey_area","survey");
  add_action("helpme","helpme");
  add_action("ether","ether");
  add_action("revert","revert");

  add_action("do_score","score");
  add_action("do_score","sc");
  add_action("do_quit","quit");
  add_action("b_pretitle","pretitle");
  add_action("mod_say","say");
  add_action("mod_emote","emote");

  add_action("news_post","Np");
  add_action("news_read","Nr");
  add_action("news_delete","Nd");
  add_action("news_headers","Nh");
  add_action("news_grouplist","Nl");
  add_action("news_next_group","Nn");

  if(panic_key) add_action("flee",panic_key);
  if(superstat_key) add_action("superstat",superstat_key);
}

add_charge(arg) {
  charge_power = charge_power + arg;
  if(charge_power > CHARGE_MAX) {
    charge_power = CHARGE_MAX;
    write("Charges have been maximized at [" + charge_power + "].\n");
  }
}

monitor_display() {
  if(!ansi_tl) MASTER_R->superstat(environment(this_object()));
  else MASTER_R->monitor_display_ansi(environment(this_object()),screen_height);
  call_out("monitor_display", monitor_interval);
}

toggle_ansi() { ansi_tl = !ansi_tl; }
toggle_eval() { eval_tl = !eval_tl; }
toggle_drain() { drain_tl = !drain_tl; }
toggle_invis() { invis_tl = !invis_tl; }
toggle_muffle() { muffle_tl = !muffle_tl; }
toggle_news_announce() { news_tl = !news_tl; }

toggle_spellbooks() { spellbooks_tl = !spellbooks_tl; }

toggle_monitor() {
  if(monitor_tl) {
    monitor_tl=0;
    remove_call_out("monitor_display");
  } else {
    monitor_tl=1;
    call_out("monitor_display", monitor_interval);
  }
}

do_score() { return MASTER_R->do_score(); }
do_quit() { 
  if(curr_morph != "none") 
  MASTER_R->undo_polymorph();
  this_player()->do_quit();
}

b_pretitle(str) { write("Use 'set pretitle <arg>'.\n"); return 1; }
mod_say(str) { return MASTER_R->mod_say(str); }
mod_emote(str) { return MASTER_R->mod_emote(str); }

flee() {
  if(this_player()->query_attack()) return this_player()->run_away();
  else return 0;
}

record_attribs() { save_object(SAVE_PATH + self_file); }

polymorph_function(str) { return MASTER_R->polymorph_function(str); }
toggle_function(str) { return MASTER_R->toggle_function(str); }
set_function(str) { return MASTER_R->set_function(str); }
info_function(str) { return MASTER_R->info_function(str); }
guild_function(str) { return MASTER_R->guild_function(str); }

guild_tell(str) { return MASTER_R->guild_tell(str); }
superstat() { MASTER_R->superstat(); return 1; }
superwho(str) { return MASTER_R->superwho(str); }

regain_corpse() { return MASTER_R->regain_corpse(); }
charge_clay(arg) { return MASTER_R->charge_clay(arg); }
atomize_object(str) { return MASTER_R->atomize_object(str); }
survey_area() { return MASTER_R->survey_area(); }

helpme() { return MASTER_R->helpme(); }
ether(str) { return MASTER_R->ether(str); }
revert() {
  if(curr_morph == "none") {
    write("You are not polymorphed as anything.\n");
    return 1;
  } else return MASTER_R->undo_polymorph();
}

/* news stuff */

news_read(str) { return MASTER_R->news_read(str); }
news_delete(str) { return MASTER_R->news_delete(str); }
news_headers() { return MASTER_R->news_headers(); }
news_grouplist() { return MASTER_R->news_grouplist(); }
news_next_group() { return MASTER_R->news_next_group(); }

news_post(str) {
  if(!MASTER_R->news_post_check(str)) return 1;
  input_to("get_body");
  new_hd = str;
  new_body = "";
  return 1;
}

get_body(str) {
  if(str == "**") {
    MASTER_R->news_feed(new_hd,new_body);
    new_body = 0;
    new_hd = 0;
    return 1;
  }
  if(str == "~q") {
    write(">> Aborted.\n");
    new_body = 0;
    new_hd = 0;
    return 1;
  }
  new_body = new_body + str + "\n";
  write(">>");
  input_to("get_body");
}

