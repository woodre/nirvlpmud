inherit "obj/monster";

reset(arg){
   object gold,armor,weapon;
   ::reset(arg);
   if(arg) return;
   set_name("Gay");
   set_race("child");
   set_alias("gay");
   set_short("Gay, henchman of Gaudyflesh");
   set_long("Gay appears to be quite confused without gaudyflesh\n"+
      "to tell him what to do..maybe you should KILL him and put\n"+
      "him out of his misery.\n");
   set_level(5);
   set_hp(75);
   set_al(-1000);
   set_wc(9);
   set_ac(5);
   set_chance(20);
   set_spell_dam(10);
   set_spell_mess1("Gay starts kicking and screaming and just annoying you.");
   set_spell_mess2("Gay throws a temper tantrum.");
   set_chat_chance(20);
load_chat("Gay whines: Waaaaaaa my wussy hurtz!\n");
load_chat("Gay screams: Gaudyflesh i can't live without you!!\n");
   gold=clone_object("obj/money");
   gold->set_money(random(100)+150);
   move_object(gold,this_object());
}
