#include <ansi.h>
get(){ return 0; }
id(str){ return str == "sign"; }
short(){ return "An " + BLINK + "UNDEAD" + NONE + " sign"; }
long(){ write("Please read sign.\n"); }
init(){add_action("read","read"); }
read(str){
if(!str || str != "sign") return;
else {
	write("To join the guild type 'join'.\nTo advance just type 'advance' when you have enough EXTRA experience points.\nLevel	Amount\n1	     0\n2	  5000\n3	 10000\n4	 20000\n5	 40000\n6	 80000\n7	160000\n");
return 1;
}
}
