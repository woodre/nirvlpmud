inherit "obj/armor";
reset(arg) {
   ::reset(arg);
   set_short("Brown glass shield");
	set_long("  This is a brown transparent glass shield.  It seems very durable.\nThis is no ordinary shield though, it has the power to register\nan attackers' hit points.  Just type 'start' when you are in battle.\n");
   set_ac(1);
   set_value(10000);
   set_weight(1);
   set_name("shield");
   set_alias("shield");
   set_type("shield");
}
/*
init(){
   add_action("start","start");
}
*/
attacker_stuff(){
   object user, attacker;
   int hp, hp2, hp3;
   string name;
   user=environment(this_object());
   attacker=user->query_attack();
   if(attacker){
      hp=attacker->query_hp();
	   hp2=attacker->query_max_hp();
	   hp3=hp*100/hp2;
      name=attacker->query_name();
	tell_object(user,name+" has "+hp3+" % energy left.\n");
      call_out("attacker_stuff",1);
      call_out("cost",6);
   }
}
cost(){ environment(this_object())->add_spell_point(-1); }
start(){ if(this_player()->query_attack()) call_out("attacker_stuff",1);
   return 1;
}
