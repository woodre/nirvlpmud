inherit "room/room";
int x;
reset(arg){
   if(arg) return;
        set_light(1);
        short_desc = "A small shop";
     long_desc =
"  This is a small shop of some different items that maybe useful in\n"+
"all your journies.  To buy an iten just type buy <number>.  The items\n"+
"available here are:\n"+
"                                                                   \n"+
"      1  Mil's Best Case               :   20000 coins\n"+
"      2  Malt Liquor      	       :   8000 coins\n"+
"      3  Load Lifter         	       :   500 coins                         \n"+
"      4  A Pouch of Holding            :   1000 coins                         \n"+
"      5  Red Hot Chips		       :   6500 coins\n"+
"      6  A sharp sword		       :   3000 coins\n"+
"								\n";
      dest_dir = 
({
	  "/players/gorgan/enter.c","out",
      });
}
init()
{
::init();
add_action("do_buy", "buy");
}
do_buy(str)
{
string i;
int cost;
object ob;
if(str=="2")
{
i="/players/gorgan/heal/soco.c";
cost=8000;
}
if(str=="1")
{
i="/players/gorgan/heal/case.c";
cost=20000;
}
if(str=="5")
{
i="/players/gorgan/heal/chips.c";
cost=6500;
}
if(str=="3")
{
i="/players/gorgan/load.c";
cost=500;
}
if(str=="4")
{
i="/players/gorgan/heal/pouch.c";
cost=1000;
}
if(str=="6")
{
i="/players/gorgan/heal/sword.c";
cost=3000;
}
if(!cost && !i)
{
write("YOU TYPE LIKE SHIT ASSHOLE!!!!\nTry again.\n");
return 1;
}
if(this_player()->query_money() < cost)
{
write("You poor little bastard!!\n");
return 1;
}
ob=clone_object(i);
if(transfer(ob, this_player()))
{
write("You cant carry it!\n");
destruct(ob);
return 1;
}
this_player()->add_money(-cost);
write("You bought "+ob->short()+" for "+cost+" coins.\n");
return 1;
}
