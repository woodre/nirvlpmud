id(str) { return str == "soap"; }
short() { return "A bar of soap"; }
long() { write("This is a bar of soap.\n"+
  "It has replaced something that was found to be illegal in the game.\n");
}
get() { return 1; }
