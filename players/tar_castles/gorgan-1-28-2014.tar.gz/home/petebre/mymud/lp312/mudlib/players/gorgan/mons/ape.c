inherit"obj/monster";

reset(arg) {
  ::reset(arg);
  if(!arg) {

   set_name("ape");
   set_short("A hairy Ape");
   set_long("It is big fat,hairy, and mean.\n");
   set_level(5);
   set_hp(320);
   set_wc(10);
   set_ac(5);
   }
}
