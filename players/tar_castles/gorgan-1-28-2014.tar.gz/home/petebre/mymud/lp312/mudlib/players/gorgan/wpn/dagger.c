inherit "obj/weapon";
int die, attacker, pain, dmg;
reset(arg) {
::reset(arg);
        if(!arg) {
                set_name("dagger");
                set_class(18);
                set_value(8000);
                set_weight(10);
                set_alias("dagger");
                set_short("A cursed Dagger");
set_long("This is a gold bladded dagger made for\nthroat slitting");
set_hit_func(this_object());
}
}
weapon_hit(attacker)
{
int dmg;
dmg = this_player()->query_intoxination();
if (random(40) < dmg) return dmg/2;
attacker->hit_player(dmg);
return 1;
}
