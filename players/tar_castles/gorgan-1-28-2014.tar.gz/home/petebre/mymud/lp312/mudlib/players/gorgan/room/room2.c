#include "room.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
object skull;
extra_reset() {
	if(!present("skull")) {
	skull=clone_object("/players/gorgan/closed/quest/skull.c");
	move_object(skull, this_object());
	}
}
ONE_EXIT("/players/gorgan/room/room1.c","south",
   "Beast's Lair",
	"   You are now inside the cave.  This is where the beast lives.\n"+
	"There are human bones laying all over the cave floor.  There is a\n"+
	"putrid stench of rotting flesh.  It makes you feel sick to your\n"+
	"stomach.\n",
   1)
