inherit "obj/weapon";
reset(arg) {
::reset(arg);
        if(!arg) {
                set_name("sword");
                set_class(18);
                set_value(8000);
                set_weight(10);
                set_alias("sword");
                set_short("Drunken Sword");
set_long("There appears to be three blades on this sword but at second glance you realize there is only one.\n");
}
}
