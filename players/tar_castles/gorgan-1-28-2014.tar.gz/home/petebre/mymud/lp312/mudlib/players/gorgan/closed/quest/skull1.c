inherit "obj/treasure";

reset(arg) {
 if(arg) return;
   set_short("A skull");
    set_alias("skull");
	set_long("This is a humanoid skull.  You can tell it has been here for awhile because\nthere are no traces of any flesh on it.\n");
   set_weight(1);
}
	id(str) { return str == "skull"; }

drop() { return 1; }
