inherit "/obj/monster.talk";

int x;
reset(arg) {
	object armor,sword,shield;
  ::reset(arg);
  if(!arg) {

   set_name("beast");
   set_short("Beast, holder of the drunken sword");
	set_long("This is Karne's most powerful henchman.  The Beast stares at you as you\napproach.  It holds what appears to be a triple bladed sword.  The Beast\nlooks very powerful and has been known to kill players in no more then four\nrounds of combat.\nYou have been warned!\n");
   set_level(30);
   set_hp(1000);
   set_wc(50);
	set_aggressive(0);
   set_ac(30);
	set_chance(70);
	set_spell_dam(100);
	set_spell_mess1("Beast's sword splits in three and kicks ass  :)\n");
	set_spell_mess2("Beast's sword splits in three.\nBeast hits you hard.\nBeast hits you very hard.\nBeast hits you with a bone crushing sound.\n");
	armor=clone_object("players/gorgan/armor/hide.c");
	move_object(armor, this_object());
	shield=clone_object("players/gorgan/armor/shield.c");
	move_object(shield, this_object());
	sword=clone_object("players/gorgan/wpn/sword.c");
	move_object(sword, this_object());
  set_heart_beat(1);
   }
}

heart_beat() {
	object att;
	::heart_beat();
	att=this_object()->query_attack();
    x = random(100);
      if(x > 65) {
   this_object()->heal_self(50);
	say("The beast grows and you feel weaker.\n");
      }
	if(att->query_hp() < 50) {
	att->hit_player(200);
	shout("The Beast rips off "+capitalize(att->query_real_name())+"'s head and drains the blood.\n");
	}
}
