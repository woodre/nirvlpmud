#include "room.h"
object beast1;
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();

extra_reset() {
  if(!present("beast")) {
      beast1=clone_object("/players/gorgan/mons/beast1.c");
      move_object(beast1, this_object());
    }
  }

ONE_EXIT("/players/gorgan/shopext/room1.c","west",
         "BEAST!",
		"  This room is dark and dismal.  There is nothing of interest here except the\n"+
		"hairy beast crunched over in the corner.  He doesn't look happy to see you.\n",
         1)
