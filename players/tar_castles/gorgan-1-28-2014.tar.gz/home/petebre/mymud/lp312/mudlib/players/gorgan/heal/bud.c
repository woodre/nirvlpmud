inherit "obj/monster";
   object gold;

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Monster");
   set_race("Monster");
   set_alias("monster");
   set_short("A small can of bud");
   set_long("A stupid can of beer, kill it!");
   set_level(20);
   set_hp(5);
   set_al(-1000);
   set_wc(5);
   set_ac(2);
   set_chance(5);
   gold = clone_object("obj/money");
  gold->set_money(random(10000)+15000);
  move_object(gold,this_object());
}
