inherit"obj/monster";

reset(arg) {
	object ring, axe, boots;
  ::reset(arg);
  if(!arg) {

   set_name("kwam");
   set_short("Kwam, an old shop keeper");
	set_long("This is an old man but he looks very tough.\n");
   set_level(20);
   set_hp(750);
   set_wc(30);
   set_ac(18);
	set_aggressive(0);
	set_chance(30);
	set_spell_dam(35);
	set_spell_mess1("Blah!");
	set_spell_mess2("OUCH!");
	ring=clone_object("players/gorgan/armor/ring.c");
	move_object(ring,this_object());
	axe=clone_object("players/gorgan/wpn/axe.c");
	move_object(axe, this_object());
	boots=clone_object("players/gorgan/armor/boots.c");
	move_object(boots, this_object());
   }
}
