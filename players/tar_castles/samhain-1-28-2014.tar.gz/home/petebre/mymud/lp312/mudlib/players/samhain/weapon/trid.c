inherit "obj/weapon.c";
reset(arg){::reset();
     if(arg) return;
     set_name("trident");
     set_alias("trident");
set_short("Trident of Ablating");
set_long("You see before you an extremely light, but well \n"+
"smited Trident.  It seems to glow in the dark, and it also seems to \n"+
"give you a feeling of confidence....\n");
     set_class(19);
     set_weight(1);
     set_value(100000);
     set_hit_func(this_object());
  }
int weapon_hit(object attacker){
  if (random(100) < 15) {
write ("The Entire rooms turns an eerie bright red for a split-second....\n");
say (this_player()->query_name()+" radiates a blue aura for a split-second\n");
return (random(50));
  }
}
