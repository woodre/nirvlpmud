 inherit "obj/weapon.c";
 reset(arg) {
    ::reset();
    if (arg) return;
set_alias("maul");
set_short("Rawhead's Crushing Maul");
set_long(""+
"You see before you an extremely heavy, extremely durable, and \n"+
"extremely used war hammer.  The handle of the hammer appears to \n"+
"be made out of human skin over iron.  The hammer itself appears \n"+
"seems to be made out of some unmalleable alien alloy...Such a \n"+
"weapon would make any warrior a force to be reckoned with....\n");
set_class(16);
set_weight(3);
set_value(15000);
set_heart_beat(1);
set_hit_func(this_object());
}
weapon_hit(attacker){
this_player()->attack();
return 1;
}
