inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Elric's Lair";
long_desc =""+
"You enter the famed lair of Elric of Melnibonea.  He doesn't appear \n"+
"too intimidating or frightening.  However, he also doesn't seem to pay \n"+
"you very much respect.  His lair is adorned with a crystal chalice and\n"+
"several opulent black onyx and white ivory pillars.  The floor is covered\n"+
"with several layers of saber rugs and the walls are adorned with mink\n"+
"tapestries....  I don't think he will let you walk away with any of this\n"+
"without a fight however...\n";
dest_dir = (({
"/players/samhain/rooms/mlair","north",
"/players/samhain/rooms/etrea","east",
"/players/samhain/rooms/drago","southeast",
"/players/samhain/rooms/alair","south",
}));
items = (({
}));
}
enc() {
if (!present("elric")){
move_object(clone_object("/players/samhain/monster/elric.c"),this_object());
}
}
init (){::init();
add_action("east","east");
}
east(){
if(!present("elric")){
write("You have located Elric's treasure room!!!\n");
move_object(this_player(), "/players/samhain/rooms/etrea");
return 1;}
else{
write("Elric stands in your way!!!\n");
move_object(this_player(), "/players/samhain/rooms/elair");
return 1;}
}
