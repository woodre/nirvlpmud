inherit "obj/monster";
object gold;
reset(arg){
  ::reset(arg);
  if (arg) return;
set_name("Grundig");
set_race("grundig");
set_alias("grundig");
set_short("Grundig");
set_long("Grundig is a smelly ogre! \n");
set_ep(100000000);
set_level(80);
set_hp(1);
set_al(-1000);
set_wc(0);
set_ac(0);
set_aggressive(0);
  gold = clone_object ("obj/money");
     gold->set_money((80000));
     move_object(gold,this_object());
}
