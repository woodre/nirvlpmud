init() {
add_action("me","me");
}
id() {return "blah";}
me(){
  this_player()->set_extra_level(10000);
  write("done/n");
 return 1;
}
