inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Dungeon of Camelot";
long_desc =""+
"YEEEEEEEEEEEEEEEEEEEEEEEEOOOOOOWWWWWWWWWWWWWWW!!!!!!!!!\n"+
"DOWN...........                                        \n"+
"               DOWN............                        \n"+
"                               DOWN....................\n"+
"You hit the moist ground like a grungy sack of rice, as you look around, \n"+
"You realize that you have fallen into a dungeon and are in big, big trouble, \n"+
"You notice that the room is very dim and that there are a lot of shadows \n"+
"moving around......\n";
dest_dir = (({
"/players/samhain/rooms/cdun2.c","south",
}));
items = (({
}));
}
enc(){
if (!present("moor")){
move_object(clone_object("/players/samhain/monster/moor"),this_object());
move_object(clone_object("/players/samhain/monster/moor"),this_object());
move_object(clone_object("/players/samhain/monster/moor"),this_object());
move_object(clone_object("/players/samhain/monster/moor"),this_object());
move_object(clone_object("/players/samhain/monster/moor"),this_object());
move_object(clone_object("/players/samhain/monster/moor"),this_object());
}
}
