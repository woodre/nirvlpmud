inherit "obj/monster";
object gold;
reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("Zombie");
   set_race("zombie");
   set_alias("zombie");
set_short("Flesh-Eating Zombie");
set_long("You see before a massive 6 foot zombie with sinewous tendons \n"+
"and rage in its cold, dead eyes.  It appears to be looking at you like \n"+
"you're it's next meal....\n");
   set_level(20);
   set_hp(350);
   set_al(-1000);
   set_wc(22);
set_aggressive(1);
   set_ac(10);
   set_chance(30);
	set_can_kill(1);
   set_spell_dam(20);
set_spell_mess1("Zombie viciously tears into flesh.\n");
set_spell_mess2("You feel a burning sensation as the Zombie \n" +
"rips into your flesh.............OUCH!!!!!!\n");
gold = clone_object ("obj/money");
   gold->set_money(random(1000)+100);
	move_object(gold,this_object());
}
heart_beat() {
	object att;
int v,x,y,z;
	::heart_beat();
att = (this_player()->query_attack());
	x=random(100);
	v=random(100);
	y=random(100);
	z=random(100);
	if(x < 50) {
	command("north",this_player());
	return 1;
	}
	if(y < 50) {
	command("south",this_player());
	return 1;
	}
	if(v < 50) {
	command("east",this_player());
	return 1;
	}
	if(z < 50) {
	command("west",this_player());
	return 1;
	}
	}
