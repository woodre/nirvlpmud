inherit "obj/monster";
 
int x;
reset(arg){
   object gold,armor,weapon;
   ::reset(arg);
   if(arg) return;
	if(!arg) x = 0;
   set_name("budsen");
   set_race("human");
   set_alias("officer");
   set_ep(100000);
   set_short("Officer Walter Budsen");
   set_long("\n"+
"  You look at Officer Walter Budsen, he is one of the people convicted\n"+
"in the slaying of Malice Green.  He doesn't look like he wants any of\n"+
"your crap right now.\n");   
   set_level(17);
   set_hp(200+ random(400));
   set_al(-100);
   set_wc(25);
   set_ac(15);
   set_chance(15);
   set_spell_dam(11);
   set_spell_mess1("Budsen blows chunks out of your with his pistol.\n");
   set_spell_mess2("Budsen knocks you to your knees with a chop to your neck.\n");
   set_chat_chance(2);
   load_chat("Budsen says: Hey Larry, that was one fun night wasn't it?\n");
   load_chat("Budsen says: Here Larry, catch!\n");
   load_chat("Budsen throws Malice Green's head across the room.\n");
   gold=clone_object("obj/money");
   gold->set_money(random(500)+500);
   move_object(gold,this_object());
   move_object(clone_object("players/pathfinder/detroit/weapons/9mm"), this_object());
   move_object(clone_object("players/pathfinder/detroit/weapons/clipb"), this_object());
   move_object(clone_object("players/pathfinder/detroit/weapons/clipb"), this_object());
}
   
heart_beat(){
	object copper, att;
	att=(this_object()->query_attack());
	if((this_object()->query_attack()) && (random(20) > 1)){
	copper=clone_object("/players/pathfinder/detroit/monsters/police");
	move_object(copper, this_object());
	write("Budsen called for backup, and here they are now!\n");
	x = x + 1;
	}
	if(x > 8){
	tell_object(att, "The cops overpower you and throw you in jail!\n");
	move_object(att, "/players/dragnar/rooms/entrance.c");
	command("look", att);
	destruct(this_object());
	}
}

