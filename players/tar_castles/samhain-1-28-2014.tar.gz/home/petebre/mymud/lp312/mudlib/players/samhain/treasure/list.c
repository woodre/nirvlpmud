inherit "obj/treasure";
reset(int arg){
 set_id("list");
 set_short("Drug Machine List");
 set_long(
"This is the list of drugs available in the machine.\n"+
"Button        What         Cost\n"+
"-------------------------------\n"+
"   0       this list        0  \n"+
"Thank you for supporting Samhain Drugs Unlimited.\n");
set_weight(0);
set_value(0);
}
