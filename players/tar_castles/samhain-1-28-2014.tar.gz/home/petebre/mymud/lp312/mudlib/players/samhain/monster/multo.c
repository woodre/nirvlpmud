/*Simple example of call_out()*/

id(str) { return str == "callout"; }
short() { return "callout"; }
long() {
    write("To use the call_out() function, type 'callout' \n");
    return 1;
    }
get() { return 1; }
drop() { return 1; }
query_weight() { return 0; }

init() {
  add_action("c_out","callout");
}

c_out() {
  write("You activated the call out.\n");
call_out("stuff",10);
return 1;
}

stuff() {
  say("The call out is now being called.\n");
return 1;
}
