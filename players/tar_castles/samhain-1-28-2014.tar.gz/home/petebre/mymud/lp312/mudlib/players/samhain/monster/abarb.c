inherit "obj/monster";
object gold,weapon;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("barbarian");
set_alias("barbarian");
set_short("Barbarian of Arioch");
set_long(
"You see before you a 6 foot tall barbarian who looks very \n"+
"intimidating, very tough, very scary......and he smells!!!!\n");
set_level(15);
set_hp(400);
set_al(220);
set_wc(15);
set_ac(8);
 gold = clone_object("obj/money");
  gold -> set_money(700);
  move_object(gold,this_object());
weapon = clone_object("/players/samhain/weapon/spear.c");
move_object(weapon,this_object());
}
