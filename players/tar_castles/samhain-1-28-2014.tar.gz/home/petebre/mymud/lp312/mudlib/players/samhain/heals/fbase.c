inherit "obj/treasure";
reset (arg){
if (arg) return;
set_id("ASTR");
set_short("");
set_long(""+
);
set_value(#);
set_weight(#);
}
init(){::init();
add_action("axt","axt");
}
axt(arg){
if(arg!="A$"){
notify_fail("\n");}
write("");
say (this_player()->query_name()+"\n");
this_player()->heal_self(#);
destruct(this_object());
return 1;
}
