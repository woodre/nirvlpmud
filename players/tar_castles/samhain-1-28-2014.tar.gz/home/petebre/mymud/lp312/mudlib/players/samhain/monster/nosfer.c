inherit "obj/monster";
object gold,fangs;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("Nosferatu");
set_race("nosferatu");
set_alias("nosferatu");
set_short("Nosferatu");
set_long("Standing before you is a 7-foot tall, pale skinned, \n"+
"bald-headed vampire who is looking upon you as if you were lunch.\n"+
"His eyes seem to hypnotize you as he inches closer and closer...\n");
set_level(40);
set_al(-950);
set_wc(35);
set_ac(22);
set_hp(500);
set_chance(30);
	set_can_kill(1);
set_aggressive(1);
set_spell_dam(20);
	set_spell_mess1("Nosferatu lunges forward at his target.\n");
	set_spell_mess2("You feel very weak as Nosferatu bites your juglar.\n");
 gold = clone_object("obj/money");
  gold -> set_money(random(1000));
  move_object(gold,this_object());
fangs = clone_object("/players/samhain/weapon/fangs.c");
move_object(fangs,this_object());
}
