inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Melnibonean Path";
long_desc =""+
"You cross a gentle stream and come upon a path that leads to \n"+
"your east.  The path looks gravely and the sky appears to turn red \n"+
"further along that way.  There is also a whirpool that is hovering \n"+ 
"where the gentle stream was...\n";
dest_dir = (({
"/players/samhain/rooms/mel2.c","east",
"/players/samhain/rooms/rrlair.c","whirpool",
"/players/samhain/rooms/ment.c","west",
}));
items = (({
}));
}
