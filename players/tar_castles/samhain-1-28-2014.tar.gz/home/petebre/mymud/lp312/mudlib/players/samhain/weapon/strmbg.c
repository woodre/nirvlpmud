inherit "obj/weapon.c";
reset(arg){::reset();
     if(arg) return;
     set_name("Stormbringer");
     set_alias("stormbringer");
     set_short("Stormbringer");
     set_long("You see before you an extremely heavy ebony blade.\n"+
     "It seems to talk to you as you wield it in your hands.  Maybe\n"+
     "you should leave it well enough alone...\n");
     set_class(19);
set_save_flag(0);
     set_weight(4);
     set_value(100000);
     set_hit_func(this_object());
  }
int weapon_hit(object attacker){
  if (random(100) < 30) {
     write ("Stormbringer sings it's Song Of Death!!!\n");
     say (this_player()->query_name()+" is imbued with Elric's Spirit!\n");
return (random(5)+5);
  }
}
