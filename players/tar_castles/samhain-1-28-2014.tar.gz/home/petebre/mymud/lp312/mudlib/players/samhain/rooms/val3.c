inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Valley in Dragon Peaks";
long_desc =""+
"You have stepped into a seclude glen. Here you see many beautiful trees\n"+
"and plants. They seem to almost be alive\n";
dest_dir = (({
"/players/samhain/rooms/val1","northeast",
"/players/samhain/rooms/val4","east",
}));
items = (({
"trees","Towering oak trees shade the glen",
"plants","More snapdragons fill the glen",
}));
}
enc(){
 if(!present("snapdragon")){
move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
}
}
