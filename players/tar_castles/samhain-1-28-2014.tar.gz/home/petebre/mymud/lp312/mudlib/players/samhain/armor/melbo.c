inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return
set_name("Melnibonean Bracer");
set_alias("bracer");
set_short("Melnibonean Bracer");
set_long("This is the sturdy leather bracer worn by the powerful warrior-mage\n"+
"Elric.  If it is in your possession, you must be tough, because he is bound\n"+
"to wear this bracer as protection until his death!!!\n");
set_value (9000);
set_weight (1);
set_ac (2);
set_type ("misc");
}
