inherit "obj/monster";
object gold;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("Native Shaman");
set_alias("shaman");
set_short("Native Shaman");
set_long(
"This man is painted like the others, but he is adorned with feathers and\n"+
"scales of some large animal. He is chanting furiously at you.\n");
set_level(4);
set_al(-50);
set_wc(8);
set_ac(3);
 gold = clone_object("obj/money");
  gold -> set_money(100);
  move_object(gold,this_object());

}
