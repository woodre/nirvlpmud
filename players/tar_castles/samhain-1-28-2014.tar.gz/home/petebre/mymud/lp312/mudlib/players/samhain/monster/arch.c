inherit "obj/monster";
object gold,weapon;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("archer");
set_alias("archer");
set_short("Archer of Marduk");
set_long(
"Standing before you is a slender, 5 foot tall elven archer who \n"+
"seems to ........BE TAKING AIM AT YOU!!!!!\n");
set_level(18);
set_hp(375);
set_al(-250);
set_wc(18);
set_ac(10);
set_aggressive(1);
 gold = clone_object("obj/money");
gold -> set_money(1000);
  move_object(gold,this_object());
weapon = clone_object("/players/samhain/weapon/bow.c");
move_object(weapon,this_object());
}
