inherit "obj/treasure";
reset(int arg){
 set_id("machine");
 set_short("Drug Dispensing Machine");
 set_long(
"This machine is here to cater to all your drug needs. There is a row of\n"+
"buttons on the machine. Push the buttons to get the drugs. Button 0 will\n"+
"give you a list of the drugs.\n");
set_weight(1000000);
set_value(0);
}
get(){return 1;}
init(){::init();
 add_action("push","push");
 }
push(str){
 if(str=="0"){
  write("The machine spits out a list for you.\n");
  move_object(clone_object("/players/samhain/treasure/list"), this_player());
  }
 else{
  write("Push a number man!\n");
  }
  return 1;
  }
