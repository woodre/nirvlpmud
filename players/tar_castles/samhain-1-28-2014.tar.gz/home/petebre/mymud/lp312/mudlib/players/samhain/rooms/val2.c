inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Valley in Dragon Peaks";
long_desc =""+
"Moving farther into the valley you now see that the flying shapes are huge\n"+
"Dragonflies. They flit around in the are gracefully. They truely are a \n"+
"sight to see.\n";
dest_dir = (({
"/players/samhain/rooms/val1","northwest",
"/players/samhain/rooms/val4","west",
}));
items = (({
}));
}
enc(){
 if(!present("dragonfly")){
  move_object(clone_object("/players/samhain/monster/dfly"),this_object());
  move_object(clone_object("/players/samhain/monster/dfly"),this_object());
  move_object(clone_object("/players/samhain/monster/dfly"),this_object());
  move_object(clone_object("/players/samhain/monster/dfly"),this_object());
  move_object(clone_object("/players/samhain/monster/dfly"),this_object());
}
}
