inherit "obj/monster";
object gold,weapon,ring,misc,helmet;
reset(arg){
  ::reset(arg);
  if (arg) return;
set_name("Elric");
set_race("elric");
set_alias("elric");
set_short("Elric of Melnibonea");
set_long("you see before you a 7 foot tall lanky albino with piercing red \n"+
"eyes.  He is wearing what appear to be mages robes but has a combat bracer \n"+
"as well.  He is wielding a vicious ebony sword that seems to chill you.. \n"+
"However, despite his somewhat intimidating view, you think to yourself 'C'mon \n"+
"how tough can this guy be???????\n");
set_level(30);
set_hp(1300);
set_al(1000);
set_ac(15);
set_wc(30);
set_chance(30);
    set_aggressive(1);
    set_can_kill(1);
set_spell_dam(25);
   set_spell_mess1("Elric casts a bolt of energy!!!\n");
   set_spell_mess2("YOUR SKIN BEGINS TO MELT AWAY....\n"+
            "YOU CAN SEE YOUR BONES!!!!!!!!\n");
set_a_chat_chance(20);
   set_chat_chance(20);
      load_chat("Elric says:  NONE SHALL DEFEAT ME!!!!!!!!\n");
    load_a_chat("Elric sneers:  I AM ONE OF THE FALTINE!!!\n"+
                "BEHOLD ME AND TREMBLE YOU WORM!!!!!!!\n");
gold = clone_object("obj/money");
     gold->set_money(random(10000)+1000);
     move_object(gold,this_object());
  weapon = clone_object("/players/samhain/weapon/strmbg.c");
  move_object (weapon,this_object());
ring = clone_object("/players/samhain/armor/dearg.c");
  move_object (ring,this_object());
  misc = clone_object("/players/samhain/armor/melbo.c");
  move_object (misc,this_object());
  helmet = clone_object ("/players/samhain/armor/melhl.c");
  move_object (helmet,this_object());
}
