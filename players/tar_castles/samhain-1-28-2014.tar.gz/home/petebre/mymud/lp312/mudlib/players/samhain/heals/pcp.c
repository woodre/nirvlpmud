inherit "obj/treasure";
reset (arg){
if (arg) return;
set_id("pcp");
set_short("Hit of PCP");
set_alias("pcp");
set_long(""+
"A small hit of PCP for your enjoyment and better health.\n"+
"Maybe you can `pop' it...\n"
);
set_value(20);
set_weight(1);
}
init(){::init();
add_action("pop","pop");
}
pop(arg){
if(arg!="pcp"){
notify_fail("Try `popping' the PCP...\n");}
write("The sky turns pretty colors a few seconds after you pop \n"+
"the hit of PCP....  My how good you feel as your mind turns to mush...\n");
say (this_player()->query_name()+" appears to fall into a trance...\n");
this_player()->heal_self(random(10)+30);
destruct(this_object());
return 1;
}
