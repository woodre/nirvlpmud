inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
   set_name("maul");
   set_alias("maul");
set_short("Maul of Diacrinolaas");
   set_long("You see before you an extremely heavy hammer made from \nsome kind of alien alloy.  It seems to glow with power and appears to be a very capable weapon.  The \ngripseems to conform to your hand as if it were made for your use alone.\n");
   set_class(18);
   set_weight(4);
   set_value(10000);
   set_hit_func(this_object());
}
weapon_hit(attacker){
   string what,how;
   int align,dam;
   align=attacker->query_alignment();
   if(random(this_player()->query_level()+this_player()->query_wc())>random(attacker->query_ac()+attacker->query_level()/2)){
      dam=random(this_player()->query_wc());
      if(dam>20){
         what="bashed";
      how="'s skull in visciously.";
      }
      if(dam<20){
         what="crushes";
        how=" soundly.";
      }
      if(dam<10){
         what="thumps";
         how=" solidly.";
      }
      if(dam<5){
         what="hit";
         how=".";
      }
      if(dam<3){
         what="tapped";
         how=".";
      }
      if(dam==1){
         what="nudged";
         how=" in the stomach.";
      }
      if(dam==0){
         what="missed";
         how=".";
      }
      write("You "+what+ " "+ capitalize(attacker->query_real_name())+how+"\n");
      say(capitalize(this_player()->query_real_name())+ " "+what+" "+capitalize(attacker->query_real_name())+ how+ "\n");
   }
   if(random(10)<3){
      if(align<0){
          say(capitalize(this_player()->query_real_name())+"'s maul of power crushes its evil opponent.\n\n");
          write("Your maul feels good as you level your opponent's cranium.\n\n");
         attacker->heal_self(-random(10));
      }
      else{
          say(capitalize(this_player()->query_real_name())+"'s maul of power fizzles out at it attacks.\n\n");
          write("Your maul suddenly feels heavy!!!!\n\n");
         attacker->heal_self(-random(3));
      }
   }
   if(random(6)==3){
      if(align>-1){
         say(capitalize(this_player()->query_real_name())+"'s Maul of power bashes its benevolent opponent's head.\n\n");
          write("You Maul of Power knocks the brains out of you nice guy opponent.\n\n");
         attacker->heal_self(-random(15));
      }
      else{
         say(capitalize(this_player()->query_real_name())+"'s Maul of Power fails to fully penetrate its opponent.\n\n");
         write("Your Maul of Power fails to fully penetrate your opponent.\n\n");
         attacker->heal_self(-random(3));
      }
   }
}
