inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
   set_name("fangs");
   set_alias("fangs");
set_short("Fangs of Nosferatu");
set_long("These are fangs that were pried out of the dead mouth of \n"+
"the legendary vampyre Nosferatu.  These fangs seem to fit quite well \n"+
"in your own mouth and appears to be a useful weapon.\n");
   set_class(18);
set_save_flag(0);
   set_weight(4);
   set_value(10000);
   set_hit_func(this_object());
}
weapon_hit(attacker){
   string what,how;
   int align,dam;
   align=attacker->query_alignment();
   if(random(this_player()->query_level()+this_player()->query_wc())>random(attacker->query_ac()+attacker->query_level()/2)){
      dam=random(this_player()->query_wc());
      if(dam>20){
         what="lacerates";
how="'s neck visciously.";
      }
      if(dam<20){
         what="tears into";
        how=".";
      }
      if(dam<10){
         what="bites";
         how=" hard.";
      }
      if(dam<5){
         what="bites";
         how=".";
      }
      if(dam<3){
         what="nibbles";
         how=".";
      }
      if(dam==1){
         what="licks";
how=".";
      }
      if(dam==0){
         what="missed";
         how=".";
      }
      write("You "+what+ " "+ capitalize(attacker->query_real_name())+how+"\n");
      say(capitalize(this_player()->query_real_name())+ " "+what+" "+capitalize(attacker->query_real_name())+ how+ "\n");
   }
   if(random(6)<3){
      if(align<0){
     say(capitalize(this_player()->query_real_name())+"'s fangs lash out to attack its opponent.\n");
     write("Your fangs feel sexually arousing as you dig into your opponents' soft flesh......\n");
         attacker->heal_self(-random(10));
      }
      else{
     say(capitalize(this_player()->query_real_name())+" seems to have some lifeforce drained out of their body.\n");
     write("You feel very light-headed and weak.....\n");
         attacker->heal_self(-random(3));
      }
   }
   if(random(6)==3){
      if(align>-1){
     say(capitalize(this_player()->query_real_name())+" lunges forward and digs into their opponent's juglar!!!!\n");
     write("Your fangs hit the Juglar Vein of your opponent and you begin to drink its blood.\n");
         attacker->heal_self(-random(20));
heal_self((random(14))/2);
      }
      else{
     say(capitalize(this_player()->query_real_name())+" lunges forward only to miss their opponent.\n");
     write("You almost break your fangs by missing your opponent and taking a bite out of the floor.\n");
         attacker->heal_self(-random(3));
      }
   }
}
