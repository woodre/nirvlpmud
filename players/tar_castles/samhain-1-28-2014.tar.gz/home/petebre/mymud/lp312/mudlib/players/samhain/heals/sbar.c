inherit "obj/treasure.c";
int swigs, price;
reset (arg) {
set_id("bar");
swigs = 10;
price = swigs * 560;
}
long(){
write("This is a Smart Bar filled with Jungle Juice and Lotus.\n"+
    "You have "+swigs+" swigs left in the bar.\n");
}
short(){ return "Smart Bar";}
query_value()
{ return price; }
init(){::init();
add_action("drink","drink");
}
drink(arg){
if(arg!="bar"){
notify_fail("Try to `drink bar'\n");
return 0;
}
swigs = swigs - 1;
if (random(100) < 10)
{
this_player()->heal_self(-90);
write("Didn't your mother tell you not to do drugs....\n");
return 1;
}
this_player()->heal_self(40);
write("You begin to feel a oneness with the universe.....\n");
say (this_player()->query_name() +" starts ranting like an idiot.\n");
this_player()->drink_alcohol(5);
if (swigs == 0){
destruct(this_object());
write("You polish off the last swig and ditch the empty bar...\n");}
return 1;}
get(){
return 1;
}
query_weight(){
return 1;
}
