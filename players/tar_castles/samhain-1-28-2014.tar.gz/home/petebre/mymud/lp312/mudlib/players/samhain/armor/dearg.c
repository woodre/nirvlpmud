inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name ("ring");
set_alias ("ring");
set_short ("Ring of Myrkoon");
set_long ("This is the Ring worn by Elric as a trophy given to him by his\n"+
     "father.  Legend states it bestowed Elric with wondrous protection from \n"+
     "all attacks based on malice.  You begin to wonder what would it do for\n"+
     "you???\n");
set_value (1250);
set_weight (1);
set_ac (-5);
set_type ("ring");
}
