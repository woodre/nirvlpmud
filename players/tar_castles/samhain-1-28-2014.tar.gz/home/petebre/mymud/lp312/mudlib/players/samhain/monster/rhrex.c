inherit "obj/monster";
object gold, armor, weapon;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("rex");
set_alias("rex");
set_short("Rawhead Rex");
set_long(
"Standing before you is a 10 foot tall half-humanoid/half- \n"+
"Tyrannosaurus Rex.  It looks at you through its blood-red eyes \n"+
"as if you're its next meal.  Rawhead is wearing some flimsy pieces \n"+
"of dried, leathered, skin for armor and looks extremely \n"+
"powerful as you begin to recognize some of the corpses hanging \n"+
"from the roof as once-powerful warriors that you KNEW!!!\n");
set_level(30);
set_hp(1150);
set_al(-1000);
set_wc(27);
set_ac(14);
set_aggressive(1);
set_can_kill(1);
set_chance(30);
set_spell_dam(50);
set_spell_mess1("Rawhead mauls forward viciously!!!!\n");
set_spell_mess2("Rawhead rips into your soft flesh!!!!\n");
gold = clone_object ("obj/money");
  gold -> set_money(random(200));
  move_object(gold,this_object());
armor = clone_object("/players/samhain/armor/lskin.c");
move_object(armor,this_object());
weapon = clone_object("/players/samhain/weapon/maul.c");
move_object(weapon,this_object());
}
