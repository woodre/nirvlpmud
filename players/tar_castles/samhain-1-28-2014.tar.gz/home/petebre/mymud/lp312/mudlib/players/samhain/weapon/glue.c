int w;
int v;
 inherit "obj/weapon.c";
 reset(arg) {
    ::reset();
    if (arg) return;
   set_name("glue");
   set_short("a strong, 1 second glue");
set_long("This is a glue that could make the opponent's arms\n"+
"stick together, so you can hurt him an extra time before\n"+
"he can hurt you.  you'll really like that...\n");
set_class(18);
set_weight(2);
set_value(1500);
set_hit_func(this_object());
}
weapon_hit(attacker){
w=random(3);
if (w>1) {
this_player()->attack();
write("Your glue has made the arms of that awful creature stick together\n"+
"You can hit him a few other times extra!!!!\n");
return 1;
}
v=random(10);
   if(v>6) {
write(".....and another time......\n");
this_player()->attack();
    return;
return 1;
}
}
