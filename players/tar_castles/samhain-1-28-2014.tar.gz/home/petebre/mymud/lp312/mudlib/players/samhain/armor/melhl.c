inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name ("helmet");
set_alias ("helmet");
set_short ("Helmet of Arioch");
set_long ("This is the Helmet worn by Elric as a trophy he earned by \n"+
     "defeating the evil warrior-mage Arioch.  This Helmet enabled Elric \n"+
     "to see more than any other man could see...  Of course he was an \n"+
     "albino, whereas you have normal vison; what would it do for you??\n");
set_value (100000);
set_arm_light(1);
set_weight (3);
set_ac (3);
set_type ("helmet");
}
