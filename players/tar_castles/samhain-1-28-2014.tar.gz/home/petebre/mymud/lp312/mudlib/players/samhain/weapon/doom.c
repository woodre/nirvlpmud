inherit "obj/weapon.c";
reset(arg) {
  ::reset();
  if (arg) return;
set_name("doom");
set_alias("doom");
set_short("Doom");
set_long(
"This is a concentrated piece of Doom. You feel the destructive power\n"+
"radiate thru you!\n");
set_class(10);
set_weight(1);
set_value(0);
}
