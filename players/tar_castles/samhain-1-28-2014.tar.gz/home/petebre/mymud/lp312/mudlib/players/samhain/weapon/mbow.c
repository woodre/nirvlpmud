inherit "obj/weapon.c";
reset(arg){::reset();
 if (arg) return;
set_name("bow");
set_alias("bow");
set_short("Moor Bow");
set_long(
"A long thin slender bow...\n");
set_class(15);
set_weight(3);
set_value(2000);
set_hit_func(this_object());
}
