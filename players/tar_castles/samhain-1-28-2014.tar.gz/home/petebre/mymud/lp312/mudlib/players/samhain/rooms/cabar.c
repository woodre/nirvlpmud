inherit "room/room";
reset(arg){
if (!arg) {
	set_light(1);
short_desc = "Thianamun's Psycho-Deli";
long_desc="You enter a dreary shop where Thianamun the Psychadelic \n"+
"Alchemist sells his fine narctotic products.  You see an array of bongs \n"+
"along with several joints, syringes, and things you have never seen \n"+
"before in your life...\n"+
"                                                                    \n"+
"Thianamun has set up these prices for his available narcotics:    \n"+
"Joint     ...............................................   50 coins\n"+
"PCP       ...............................................  500 coins\n"+
"Smart Bar ............................................... 5000 coins\n"+
"Yesca Bong...............................................10000 coins\n"+
"Bag of Manzanilla(sober)................................. 5000 coins\n"+
"                                                                       \n"+
"Remember.....these are drugs and Thianamun does not guarantee no ill \n"+
"side effects or freedom from possible addiction, but these cases are \n"+
"few and far apart....\n";
dest_dir = ({
"/players/samhain/rooms/cam2.c","west",
	});
}
}
init() {
	::init();
   add_action("buy","buy");
	}
buy(str){
object item;
string name;
int value, cost;
if (str == "joint" || str == "Yesca Joint"){
   name = str;
   item = clone_object("/players/samhain/heals/joint.c");
value = 50;
}
else if (str == "PCP" || str == "Hit of PCP"){
   name = str;
   item = clone_object("/players/samhain/heals/pcp.c");
value = 500;
}
else if (str == "bar" || str == "Smart Bar"){
   name = str;
   item = clone_object("/players/samhain/heals/sbar.c");
value = 5000;
}
else if (str == "bag" || str == "Bag of Manzanilla"){
   name = str;
   item = clone_object("/players/samhain/heals/manz.c");
value = 5000;
}
else if (str == "bong" || str == "Yesca Bong"){
   name = str;
   item = clone_object("/players/samhain/heals/bong.c");
value = 10000;
}
else {write("Thianamun whispers to you: WE AIN'T GOT THAT FOOL!!!\n"); return 1;}
if (call_other(this_player(), "query_money", 0) < value) {
	write("That costs " + value + " gold coins, which you don't have.\n");
	destruct(item); return 1;
	}

if (!call_other(this_player(), "add_weight", 1)){
	write("You can't carry that much!\n"); 
	destruct(item); return 1;
	}
move_object(item,this_player());
call_other(this_player(), "add_money", - value);
write("You get a " +name+ " and you feel " +value+ " gold coins are taken away from you by Thianamun.\n");
say(call_other(this_player(), "query_name", 0)+" buys a " +name+ " off of Thianamun.\n");
return 1;
}
