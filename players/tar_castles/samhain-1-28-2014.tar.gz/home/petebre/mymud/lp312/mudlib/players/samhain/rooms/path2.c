inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Path on Dragon Peak";;
long_desc =""+
"You are now about one fourth of the way up the moutain. Even from here your\n"+
"view of the land is spectacluar. As you stop to take in the view you notice\n"+
"a cave hidden behind some rocks.\n"+
"However the rubble in front of it is blocking anything from getting in.\n";
dest_dir = (({
"/players/samhain/rooms/path1","down",
"/players/samhain/rooms/path3","up",
}));
items = (({
}));
}
