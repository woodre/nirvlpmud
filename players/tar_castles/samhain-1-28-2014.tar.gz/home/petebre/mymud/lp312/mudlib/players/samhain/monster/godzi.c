inherit "obj/monster";
object gold,scale;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("Godzilla");
set_alias("godzilla");
set_short("Godzilla");
set_long(
"You see standing before you the aftermath of nuclear bomb explosions in \n"+
"Japan.  The mighty titan Godzilla has awakened from his slumber and this \n"+
"ridiculously powerful firebreathing lizard is pissed!!!!\n");
set_level(80);
set_al(-1000);
set_wc(50);
set_ac(18);
set_hp(800);
set_chance(80);
set_can_kill(1);
set_aggressive(0);
set_spell_dam(45);
set_spell_mess1("OH NO!!!! THERE GOES TOKYO!!!! GODZILLA JUST UNLEASHED A BOLT OF FIRE!!!\n");
set_spell_mess2("OUCH!!! THAT ONE WAS A TOOTH RATTLER!!!!! Your kids will be feeling that one!\n");
set_a_chat_chance(35);
set_chat_chance(30);
load_chat("Godzilla says: I'm so big, I'm so mean--I can eat a football team!!\n");
load_a_chat("Godzilla says: I swallow girls and little boys--for desert I eat their toys!!\n");
 gold = clone_object("obj/money");
  gold -> set_money(random(3000)+10);
  move_object(gold,this_object());
scale = clone_object("players/samhain/armor/gscale.c");
move_object(scale,this_object());

}
