inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc ="Road to Dragon Peak*";
long_desc =""+
"You find youself on a packed dirt road winding its way to a solitary mountain\n"+
"off in the distance. As you get closer you realize that it isn't just one\n"+
"mountain, but an entire chain of mountains with one towering\n"+
"above all the others. You can also make out tiny figures flying around\n"+
"the peaks.\n";
dest_dir = (({
"/room/ruin","south",
"/players/samhain/rooms/road2","north",
}));
items = (({
}));
}
