inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Base of Dragon Peak";
long_desc =""+
"You have reached the base of the great moutain. It towers nearly ten miles\n"+
"over you and still part of it is lost in the clouds. You can now clearly\n"+
"see the dragons flying around the upper reaches of the mountain. Their\n"+
"beauty fills you with awe and at the same time you fear their awesome\n"+
"power. You notice narrow path leading into the mountains. It looks\n"+
"overgrown and unused.\n";
dest_dir = (({
"/players/samhain/rooms/road1","south",
"/players/samhain/rooms/path1","up",
}));
items = (({
}));
}
