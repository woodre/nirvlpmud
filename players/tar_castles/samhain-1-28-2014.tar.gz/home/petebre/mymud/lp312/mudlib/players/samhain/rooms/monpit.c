inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Downtown Tokyo.....IN CAMELOT????";
long_desc =""+
"The Moors probably stayed away because of the Monorails.  Or maybe it was \n"+
"the massive buildings that are burned to a crisp?  Or maybe \n"+
"it was the multitude of charred and crushed corpses scattered along \n"+
"the streets?  Nah.....none of those reasons but.................... \n"+
"                                                                    \n"+
"                                                                          \n"+
" \n"+
" \n"+
" MAYBE IT WAS....HOLY SH*T......IT IS....GODZILLLLLLLLAAAAAA!!!!!!!!!\n";
dest_dir = (({
"/players/samhain/rooms/ccas8.c","flee",
"/players/samhain/rooms/cdun3.c","north",
}));
items = (({
}));
}
enc() {
if (!present("godzilla")){
move_object(clone_object("/players/samhain/monster/godzi.c"),this_object());
}}
