inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Melnibonean Hall";
long_desc =""+
"You enter a lavish hallway that is further adorned with opulent \n"+
"furnishings and luxurious treasures.  The walls are filled with \n"+
"intricately woven tapestries and the floors have plush, thick, purple \n"+
"carpeting.  However, like the hallway before, these barbarians \n"+
"do not want you here...\n";
dest_dir = (({
"/players/samhain/rooms/hal10","west",
"/players/samhain/rooms/hal11","southwest",
"/players/samhain/rooms/alair","east",
}));
items = (({
}));
}
enc() {
if (!present("barbarian")){
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
}}
