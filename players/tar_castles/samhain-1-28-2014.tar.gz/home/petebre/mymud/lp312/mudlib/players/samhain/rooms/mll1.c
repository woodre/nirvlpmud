inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Melnibonean Path";
long_desc =""+
"You walk further along the path in the dense everglades just \n"+
"outside of Camelot.  There is a crude wooden sign placed next \n"+
"to the path possibly describing what lies ahead...\n";
dest_dir = (({
"/players/samhain/rooms/mel1.c","east",
"/players/samhain/rooms/cam6.c","north",
}));
items = (({
"sign","Abandon hope all ye who enter here....\n"+
"Lying before you is Melnibonea' where Elric reigns supreme \n"+
"and Strangers are not welcome...\n",
}));
}
