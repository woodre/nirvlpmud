inherit "obj/weapon.c";
reset(arg){::reset();
     if(arg) return;
     set_name("Excalibur");
set_alias("excalibur");
     set_short("Excalibur");
set_long("The famed blade of King Arthur seems to quiver in your \n"+
"hands as if it is trying to determine your worthiness.  The hilt of \n"+
"the sword glistens with an almost heavenly light.....\n");
     set_class(19);
     set_weight(4);
set_save_flag(0);
     set_value(100000);
     set_hit_func(this_object());
  }
int weapon_hit(object attacker){
  if (random(100) < 25) {
write ("The Saints of Heaven roar in Godly VENGENCE!!!!!\n");
say (this_player()->query_name()+" strikes forth with the Strength of GOD!!!!\n");
return (random(30)+2);
  }
}
