inherit "obj/monster";
object gold;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("Dragonfly");
set_alias("dragonfly");
set_short("A large Dragonfly");
set_long(
"Hovering in the air before you is a giant dragonfly. Its gossamer wings flit\n"+
"so rapidly that they are only a blur of white. This dragonfly is the largest\n"+
"that you have ever seen. It is nearly 3 feet long.\n");
set_level(1);
set_hp(50);
set_al(0);
set_wc(5);
set_ac(2);
 gold = clone_object("obj/money");
  gold -> set_money(25);
  move_object(gold,this_object());

}
