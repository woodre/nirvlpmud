inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Valley in Dragon Peaks";
long_desc =""+
"The valley begins to widen here giving you some room to breath. However you\n"+
"have just stumbled into a primitive village. The natives don't appear to be\n"+
"at home right now. Maybe that is for the best. You can here drums echoing\n"+
"up the valley from the south...\n";
dest_dir = (({
"/players/samhain/rooms/val5","north",
"/players/samhain/rooms/val7","south",
}));
items = (({
"village","It is made of small thatch huts. The stream runs thru the center",
"stream","It is flowing very fast. The natives have built a bridge over it",
"bridge","It was built by the natives to cross the river",
}));
}
