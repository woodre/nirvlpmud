inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name("Leathered Skin");
set_alias("skin");
set_short("Leathered Skin");
set_long(
"This is a tapestry of woven human skin that rawhead uses to \n"+
"wrap himself up in to keep warm.  However, it looks sturdy enough \n"+
"to serve as decent armor from physical attacks...\n");
set_type("armor");
set_ac(2);
set_weight(1);
set_value(2000);
}
