inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Elric's Treasure Room";
long_desc =""+
"This is the famed Treasure room of Elric.  To have come this far you must \n"+
"be a noble warrior indeed...  As you look around you see many choice items \n"+
"to take but the one that sticks out most is the suit of platemail hanging \n"+
"in the center of the room.\n";
dest_dir = (({
"/players/samhain/rooms/elair","west",
}));
items = (({
"platemail","Golden platemail formerly worn by Elric.  Since his fateful curse\n"+
"of being forced to wear his bracer, he has preserved this magical armor until\n"+
"the day comes when he can wear it again and lead the world out of Armageddon!\n",
}));
}
enc() {
if (!present("platemail")){
move_object(clone_object("/players/samhain/armor/elplate.c"),this_object());
}}
