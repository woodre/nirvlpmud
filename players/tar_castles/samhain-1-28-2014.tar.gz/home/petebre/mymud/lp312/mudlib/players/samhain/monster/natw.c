inherit "obj/monster";
object gold;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("Native Warrior");
set_alias("warrior");
set_short("Native Warrior");
set_long(
"The man standing before you is painted with white to look like a skeleton.\n"+
"He stands nearly seven feet tall and is very imposing.\n");
set_level(2);
set_al(25);
set_wc(8);
set_ac(4);
 gold = clone_object("obj/money");
  gold -> set_money(50);
  move_object(gold,this_object());

}
