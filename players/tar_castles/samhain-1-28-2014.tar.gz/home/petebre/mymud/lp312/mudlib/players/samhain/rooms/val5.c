inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Valley in Dragon Peaks";
long_desc =""+
"You follow the stream deeper into the valley. The walls seem to be closing\n"+
"in on you making this area seem dark and gloomy. You begin to feel as if\n"+
"you are being watched. Maybe your mind is just playing tricks on you.\n";
dest_dir = (({
"/players/samhain/rooms/val4","north",
"/players/samhain/rooms/val6","south",
}));
items = (({
"stream","The stream is getting deeper and faster",
}));
}
