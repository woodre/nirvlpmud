inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name("Dragon Plate");
set_alias("plate");
set_short("Dragon Plate");
set_long(
"This magnificent suit of plate mail has been made from the scales of a great\n"+
"dragon. It is far more durable than any known metal.\n");
set_type("armor");
set_ac(5);
set_weight(3);
set_value(10000);
}
