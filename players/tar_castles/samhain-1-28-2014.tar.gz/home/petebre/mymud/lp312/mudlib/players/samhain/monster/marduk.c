inherit "obj/monster";
object gold,weapon,ring,misc,shield;
reset(arg){
  ::reset(arg);
  if (arg) return;
set_name("Marduk");
set_race("marduk");
set_alias("marduk");
set_short("Lord Marduk of Barbylonia");
set_long("Marduk is a 7 foot tall red-skinned, heavily armored, and \n"+
"extremely spazzed out Barbylonian.  He intends to overthrow Elric's rule over \n"+
"Melnibonea and usurp his power to vanquish Ulemthor and Arioch.\n"+
"However he seems quite suspicious of you and thinks that you \n"+
"will betray his ambush to Elric....\n");
set_level(25);
set_hp(1000);
set_al(1000);
set_ac(13);
set_wc(27);
set_chance(20);
    set_aggressive(1);
    set_can_kill(1);
set_spell_dam(15);
set_spell_mess1("Marduk lurches forth with his Trident!!!\n");
set_spell_mess2("YOU FEEL A PAINFUL BURNING SENSATION AS \n"+
"MARDUK IMPALES YOU WITH HIS TRIDENT!!!!!!\n");
set_a_chat_chance(40);
   set_chat_chance(40);
load_chat("Marduk growls:  I WILL HAVE ELRIC'S HEAD!!!!!!\n");
load_a_chat("Marduk grins evily at your petty attacks.\n");
gold = clone_object("obj/money");
gold->set_money(random(1000)+200);
     move_object(gold,this_object());
  weapon = clone_object("/players/samhain/weapon/trid.c");
  move_object (weapon,this_object());
ring = clone_object("/players/samhain/armor/mrg.c");
  move_object (ring,this_object());
  misc = clone_object("/players/samhain/armor/shea.c");
  move_object (misc,this_object());
  shield = clone_object ("/players/samhain/armor/viso.c");
  move_object (shield,this_object());
}
