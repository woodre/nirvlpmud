inherit "obj/treasure";
reset(int arg){
 set_id("tome");
 set_short("Tome set in Human skin");
set_long("A repulsive, but intricately bound book written in blood\n"+
"on human skin entitled `Estne Necronomiconus Paulis'.  The book \n"+
"radiates an extremely evil aura...\n");
 set_weight(1);
 set_value(1500);
}
get(){
 return 1;
}
init(){
 ::init();
  add_action("read1","read");
}
read1(str){
 if(str=="book" || str=="tome"){
  write("You open up the book and try to read the cover page but you\n" +
"instead feel very light-headed and weak....\n");
  return 1;
 }
 write("What are you trying to read\n\n");
return 1;
}
