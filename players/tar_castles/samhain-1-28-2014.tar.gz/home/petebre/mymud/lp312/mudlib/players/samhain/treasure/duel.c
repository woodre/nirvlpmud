inherit "obj/treasure";
reset(int arg){
 set_id("badge");
 set_short("Duelling Badge");
 set_long(
"This badge signifies your worthiness to DUEL the ogre Grundig when you\n"+
"should feel the urge to kick his ass!\n");
 set_weight(1);
 set_value(0);
}
drop(){return 1;}
query_auto_load(){return "/players/samhain/treasure/duel:";}
init(){::init();
 add_action("duel","duel");
 add_action("ditch","ditch");
 }
duel(){
    move_object(clone_object("/players/samhain/monster/grundig"),this_player());
     command("drop grundig", this_player());
    write("You summon that piece of shit Grundig!\n");
    return 1;
   }

ditch(){
destruct(this_object());
return 1;
}
