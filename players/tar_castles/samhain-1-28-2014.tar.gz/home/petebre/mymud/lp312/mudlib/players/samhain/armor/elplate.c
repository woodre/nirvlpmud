inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name("Golden Armor of Elric");
set_alias("armor");
set_short("Golden Armor of Elric");
set_long(
"This beautifully crafted suit of armor was hand-made by the greatest \n"+
"Faltine Dwarven smiths ever to exist.  The armor is extremely light and it \n"+
"seems to radiate a magical aura.  It was said that this armor protected Elric \n"+
"from all forms of physical and magical harm.\n");
set_type("armor");
set_ac(6);
set_weight(5);
set_value(100000);
}
