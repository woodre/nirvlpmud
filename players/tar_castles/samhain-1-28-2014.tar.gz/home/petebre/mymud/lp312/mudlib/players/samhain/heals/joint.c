inherit "obj/treasure";
reset (arg){
if (arg) return;
set_id("joint");
set_short("Yesca Joint");
set_long(""+
"You hold in your hands a very thick joint made from fresh hemp \n"+
"and yesca.  Try to `smoke joint' for a buzz..\n");
set_value(1);
set_weight(1);
}
init(){::init();
add_action("smoke","smoke");
}
smoke(arg){
if(arg!="joint"){
notify_fail("Try to `smoke joint' /n");
}
write("Amazing how much better things look through clouded eyes...\n");
say (this_player()->query_name()+" appears to look spaced out..\n");
this_player()->heal_self(25);
destruct(this_object());
return 1;
}
