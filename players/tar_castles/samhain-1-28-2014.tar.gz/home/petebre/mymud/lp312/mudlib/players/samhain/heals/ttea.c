inherit "obj/treasure.c";
int swigs, price;
reset (arg) {
set_id("tea");
swigs = 10;
price = swigs * 560;
}
long(){
write("This is Smart Tea filled with Jungle Juice and Lotus.\n"+
    "You have "+swigs+" swigs left in the bar.\n");
}
short(){ return "Smart Tea";}
query_value()
{ return price; }
init(){::init();
add_action("drink","drink");
}
drink(arg){
if(arg!="tea"){
notify_fail("Try to `drink tea'\n");
return 0;
}
swigs = swigs - 1;
this_player()->heal_self(40);
write("You begin to feel a oneness with the universe.....\n");
say (this_player()->query_name() +" starts drinking like a noble.\n");
if (swigs == 0){
destruct(this_object());
write("You polish off the last swig and ditch the empty bar...\n");}
return 1;}
get(){
return 1;
}
query_weight(){
return 1;
}
