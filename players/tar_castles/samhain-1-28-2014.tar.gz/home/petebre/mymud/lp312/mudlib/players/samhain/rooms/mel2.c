inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Melnibonean Path";
long_desc =""+
"The gravely path hurts your feet as you walk along it \n"+
"while noticing the opulent countryside and lavish grasslands. \n"+
"You swear that you see dragons flying overhead in the pale crinsom \n"+
"sky but you decide that it is more important to notice what's in \n"+
"front of you.  The path directly to your east seems to be the entrance \n"+
"to some strange new world...\n";
dest_dir = (({
"/players/samhain/rooms/mlb3.c","east",
"/players/samhain/rooms/mel1.c","west",
}));
items = (({
}));
}
