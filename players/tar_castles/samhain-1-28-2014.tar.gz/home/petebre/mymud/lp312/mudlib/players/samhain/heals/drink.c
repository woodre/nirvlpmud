inherit "obj/drink";
reset(arg){
   ::reset(arg);
   if(arg) return;
   set_value("bubbles#Some bubbles of the 7-up#You drink some 7-up bubbles#30#300#10");
}
