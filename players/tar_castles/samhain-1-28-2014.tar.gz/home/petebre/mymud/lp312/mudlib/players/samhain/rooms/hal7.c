inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Melnibonea";
long_desc =""+
"You enter the mythical realm of Melnibonea....It is rummored that \n"+
"the revered warrior Elric roams here.  The area seems misty and cold \n"+
"but you are driven to press on.  Elric's sword is rumored to be the \n"+
"most powerful ever made.  However, these archers of Marduk will try to \n"+
"prevent you from reaching him.\n";
dest_dir = (({
"/players/samhain/rooms/hal6","north",
"/players/samhain/rooms/hal1","west",
}));
items = (({
}));
}
enc() {
if (!present("archer")){
move_object(clone_object("/players/samhain/monster/arch.c"),this_object());
move_object(clone_object("/players/samhain/monster/arch.c"),this_object());
move_object(clone_object("/players/samhain/monster/arch.c"),this_object());
move_object(clone_object("/players/samhain/monster/arch.c"),this_object());
move_object(clone_object("/players/samhain/monster/arch.c"),this_object());
}}
