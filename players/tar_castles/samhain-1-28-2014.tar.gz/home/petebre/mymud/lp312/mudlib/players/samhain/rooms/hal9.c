inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Melnibonean Crypt";
long_desc =""+
"You seem to have entered a strange an bizarre place.  There are \n"+
"tombstones and open graves everywhere.  You begin to wonder if those \n"+
"graves are freshly disinterred or if this is some long forgotten \n"+
"crypt for the dead of Melnibonea.....\n";
dest_dir = (({
"/players/samhain/rooms/hal8","tomb",
}));
items = (({
"tomb","looks pretty dark in there....\n",
"tombstone","It reads ULEMTHOR LIVES!!!!!!!\n",
}));
}
enc() {
if (!present("barbarian")){
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
}
}
