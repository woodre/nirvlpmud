inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Tomb of Ulemthor";
long_desc =""+
"A cold shiver runs up your spine as you look at all of the crypts and tombs \n"+
"in this dusty, hoary old room.  You notice something moving in the shadows \n"+
"that seems to be inching closer and closer to you...  YOUR WORST FEARS ARE \n"+
"REALIZED AS YOU CLEARLY SEE IT'S ULEMTHOR THE ZOMBIE LORD!!!!!!!\n";
dest_dir = (({
"/players/samhain/rooms/elair","northwest",
"players/samhain/rooms/hal15","west",
}));
items = (({
}));
}
enc() {
if (!present("ulemthor")){
move_object(clone_object("/players/samhain/monster/ulem.c"),this_object());
}
}
