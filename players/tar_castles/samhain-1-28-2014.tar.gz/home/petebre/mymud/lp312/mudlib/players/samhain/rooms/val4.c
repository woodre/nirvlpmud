inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Valley in Dragon Peaks";
long_desc =""+
"Bubbling out of the ground here is a crystal clear spring. The cool water\n"+
"looks very refreshing. In the spring you can see some fish swimming around.\n"+
"A small stream from the spring leads south from here.\n";
dest_dir = (({
"/players/samhain/rooms/val2","east",
"/players/samhain/rooms/val3","west",
"/players/samhain/rooms/val5","south",
}));
items = (({
"spring","It looks cool and refreshing. Why not take a drink",
"stream","A clear, babbling stream that flow south of here..",
"fish","Great big rainbow trout",
}));
}
init(){::init();
 add_action("drink","drink");
 }
drink(){
 write("You take a long drink from the spring.\n");
 write("Ahh. That hit the spot.\n");
 this_player()->heal_self(1);
 return 1;
 }
