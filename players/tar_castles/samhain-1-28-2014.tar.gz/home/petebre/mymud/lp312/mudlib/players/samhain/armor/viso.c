inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name ("shield");
set_alias ("shield");
set_short ("Shield of Impenetrable Might");
set_long ("This is the shield that is used by Marduk to ward off \n"+
"all forms of physical harm.  However it looks extremely heavy...\n");
set_value (4000);
set_weight (4);
set_ac (3);
set_type ("shield");
}
