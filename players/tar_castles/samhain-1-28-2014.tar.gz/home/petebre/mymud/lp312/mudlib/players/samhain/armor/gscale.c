inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name("Scales of Godzilla");
set_alias("scales");
set_short("Scales of Godzilla");
set_long(
"You see before you the massive scales of Godzilla.  They've withstood\n"+
"attacks for millenia.  Maybe they can serve as some sort of armor for you...\n");
set_type("armor");
set_ac(3);
set_weight(3);
set_value(10000);
}
