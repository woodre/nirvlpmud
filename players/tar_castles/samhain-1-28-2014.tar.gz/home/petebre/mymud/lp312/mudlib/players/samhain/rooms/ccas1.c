inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Camelot";
long_desc =""+
"You are in the famed Castle of Camelot.  In here you will find \n"+
"the legendary figure of King Arthur and Excalibur.  You will also find \n"+
"Knights of varying strength and quality to confront you since \n"+
"you are, in fact, an intruder here.  Venture forth at your own risk...\n";
dest_dir = (({
"/players/samhain/rooms/ccas2.c","northwest",
"/players/samhain/rooms/ccas3.c","west",
"/players/samhain/rooms/ccas4.c","southwest",
"/players/samhain/rooms/cdun1.c","south",
"/players/samhain/rooms/cam3.c","east",
}));
items = (({
}));
}
