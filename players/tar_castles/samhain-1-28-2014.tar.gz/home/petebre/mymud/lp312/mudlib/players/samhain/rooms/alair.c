inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Arioch's Hedonism";
long_desc =""+
"WHAM!!!!!!!!!!!!!!!!!!!!!!!!!CRASHHHHHHHHH!!!!!!!!!BOOOOOOOOOMMMMMMMMM!!!!!\n"+
"                                                                          \n"+
"..............as you wake up bleary eyed and groggy you wonder `WHAT THE \n"+
"HELL WAS THAT????'  And who stands before you, no one but the epitome of \n"+
"barbarism himself....ARIOCH THE CRUSHER!!!!!!\n";
dest_dir = (({
"/players/samhain/rooms/elair","north",
"/players/samhain/rooms/hal16","west",
}));
items = (({
}));
}
enc() {
if (!present("arioch")){
move_object(clone_object("/players/samhain/monster/arioch"),this_object());
}
}
