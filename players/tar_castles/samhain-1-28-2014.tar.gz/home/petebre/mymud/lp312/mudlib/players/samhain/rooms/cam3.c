inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Path of Camelot";
long_desc =""+
"The lavish trees seem to emit a regal splendor as the sunlight ebbs \n"+
"through the thick leaves above.  You swear you smell Frankinscence \n"+
"and Myrhh as you see the Mythical Questing Beast galavanting through \n"+
"the shadows....\n";
dest_dir = (({
"/players/samhain/rooms/cam4.c","south",
"/players/samhain/rooms/cam2.c","north",
"/players/samhain/rooms/ccas1.c","west",
}));
items = (({
}));
}
