inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name("Belt of Warding");
set_alias("belt");
set_short("Belt of Warding");
set_long("This thick and very heavy leather belt was used by the \n"+
"would-be usurper Marduk for protection.  Would-be usurper is the \n"+
"proper title because the only way for you to get this powerful \n"+
"belt would be to kill Marduk.\n");
set_value (18000);
set_weight (2);
set_ac (3);
set_type ("misc");
}
