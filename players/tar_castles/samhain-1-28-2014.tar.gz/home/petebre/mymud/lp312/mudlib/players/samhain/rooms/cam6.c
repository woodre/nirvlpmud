inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Path of Camelot";
long_desc =""+
"You walk along the soft paved road as you notice all of the \n"+
"beautiful foliage.  You can only think to yourself that this \n"+
"was indeed a beatiful place.  The path continues along to the \n"+
"south which shows an end to the forest.  Back north returns \n"+
"you to Camelot...\n";
dest_dir = (({
"/players/samhain/rooms/mll1.c","south",
"/players/samhain/rooms/cam5.c","north",
}));
items = (({
}));
}
