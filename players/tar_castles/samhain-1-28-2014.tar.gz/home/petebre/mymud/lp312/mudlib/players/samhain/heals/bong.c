inherit "obj/treasure.c";
int hits, price;
reset (arg) {
set_id("bong");
hits = (5 + random(5));
price = hits * 560;
}
long(){
write("This is an articulately detailed bong that has enough \n"+
"Yesca and Orgullo De Michuoacan for "+hits+" more mind-whopping \n"+
"tongue-drying hits....\n");
}
short(){ return "Yesca Bong";}
query_value()
{ return price; }
init(){::init();
add_action("smoke","smoke");
}
smoke(arg){
if(arg!="bong"){
notify_fail("Try to `smoke  bong'\n");
return 0;
}
hits = hits - 1;
if (random(100) < 10)
{
this_player()->heal_self(-100);
write("Death comes up from below and smiles at you greedily......\n");
if (hits == 0){
destruct(this_object());
write("You toke up the last hit and the bong turns to dust...\n");}
return 1;
}
this_player()->heal_self(125);
write("As you inhale the bong deeply you feel every iota of power within \n"+
"the multiverse, the cosmos and all that other jazz....\n");
say (this_player()->query_name() +" takes a hit from the bong and \n"+
"stares stupidly out into space as if seeing something you can't...\n");
if (hits == 0){
destruct(this_object());
write("You toke up the last hit and the bong turns to dust...\n");}
return 1;}
get(){
return 1;
}
query_weight(){
return 1;
}
