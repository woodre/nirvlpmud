inherit "obj/armor.c";
reset(arg){::reset();
if (arg) return;
set_name ("ring");
set_alias ("ring");
set_short ("Ring of Marduk");
set_long("This ring feels very powerful in your hands. \n"+
"It seems to radiate a green aura and the light glistens from it brilliantly \n"+
"as your inner confidence begins to grow.  You think you are unstoppable \n"+
"with this ring. \n");
set_value (20000);
set_arm_light(1);
set_weight (1);
set_ac (2);
set_type ("ring");
}
