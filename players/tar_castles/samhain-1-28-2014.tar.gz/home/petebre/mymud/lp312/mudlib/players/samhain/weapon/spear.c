inherit "obj/weapon.c";
reset(arg) {
    ::reset();
    if (arg) return;
    set_name("spear");
    set_alias("spear");
set_short("A large wrought metal spear");
set_long("A large wrought metal spear that is usually favored by the \n"+
"burly barbarians of Arioch The Crusher.\n");
    set_class(16);
    set_weight(4);
    set_value(4500);
    set_hit_func(this_object());
