inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Valley in Dragon Peaks";
long_desc =""+
"You start descending from the mountail path into a beautiful valley. Here\n"+
"you see all manner of flora including some of the largest snapdragons you\n"+
"have ever seen. In the distance you can see many multi-colored objects\n"+
"flying around.\n";
dest_dir = (({
"/players/samhain/rooms/path1","up",
"/players/samhain/rooms/val2","southeast",
"/players/samhain/rooms/val3","southwest",
}));
items = (({
"flora","The most beautiful flowers you have ever seen",
"snapdragons","They almost look alive",
}));
}
enc(){
if(!present("snapdragon")){
 move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
 move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
 move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
 move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
 move_object(clone_object("/players/samhain/monster/sdrag"),this_object());
}
}
