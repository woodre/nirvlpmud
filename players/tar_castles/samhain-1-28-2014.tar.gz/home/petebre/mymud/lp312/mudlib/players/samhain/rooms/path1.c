inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Path on Dragon Peak";;
long_desc =""+
"You begin to climb the path which winds steadily higher and higher. After\n"+
"a while you begin to grow weary and stop to rest. Here you see a small side\n"+
"path leading down to a valley. The main path continues upwards onto the \n"+
"mountain.\n";
dest_dir = (({
"/players/samhain/rooms/road2","down",
"/players/samhain/rooms/path2","up",
"/players/samhain/rooms/val1","east",
}));
items = (({
}));
}

init(){::init();
 add_action("east","east");
}
east(){
  if(this_player()->query_level() < 6){
   write("You make your way down the path.\n");
   return 1;}
  else{
    write("You are too Big and Powerful to go down there!\n");
   move_object(this_player(), "/players/samhain/rooms/path1");
   return 1;
   }
 }
