inherit "obj/monster";
object gold, weapon;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("arioch");
set_alias("arioch");
set_short("Arioch the Crusher");
set_long(
"You see before you an 8 foot tall barbarian who has a funny smile \n"+
"because he is missing some teeth.  He is a sweaty, hairy, tall, and \n"+
"overall just plain repulsive.  However he is also muscle-bound and \n"+
"heavily scarred letting you know that he is no stranger to combat..\n");
set_level(35);
set_hp(1200);
set_al(-400);
set_wc(25);
set_ac(10);
set_aggressive(0);
set_chance(15);
set_can_kill(1);
set_spell_dam(25);
set_spell_mess1("Arioch lunges forward to attack!!!\n");
set_spell_mess2("Arioch tackles you to the ground.....HARD!!!\n");
gold = clone_object ("obj/money");
  gold -> set_money(3000);
  move_object(gold,this_object());
weapon = clone_object("/players/samhain/weapon/imace.c");
move_object(weapon,this_object());

}
