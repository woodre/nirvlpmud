inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Marduk's Abode";
long_desc =""+
"You have entered the personal abode of Marduk the Enforcer.  He is plotting the\n"+
"overthrow of Elric's rule to attain Stormbringer's brute power for himself. \n"+
"You have caught him planning a surprise ambush on Elric and he is not pleased.\n";
dest_dir = (({
"/players/samhain/rooms/elair","south",
"/players/samhain/rooms/hal12","west",
}));
items = (({
}));
}
enc() {
if (!present("marduk")){
move_object(clone_object("/players/samhain/monster/marduk"),this_object());
}}
