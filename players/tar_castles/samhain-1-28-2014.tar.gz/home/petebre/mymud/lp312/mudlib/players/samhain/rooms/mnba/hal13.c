inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(0);
short_desc = "Melnibonean Crypt";
long_desc =""+
"The ground makes a nauseating crunchy sound as you enter the room \n"+
"and you feel like vomiting when you see that you are walking on \n"+
"the partially consumed remains of some of Melnibonea's past warriors.\n"+
"Maybe the Zombies in this room can shed some light on their affinity \n"+
"for putrid, maggot ridden flesh...\n";
dest_dir = (({
"/players/samhain/rooms/hal15","east",
}));
items = (({
}));
}
enc() {
if (!present("zombie")){
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
}
}
