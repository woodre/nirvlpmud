inherit "obj/monster";
object gold;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("Snapdragon");
set_alias("snapdragon");
set_short("A large snapdragon");
set_long(
"Looking at the plant you would swear that it was alive. It stands nearly\n"+
"six feet tall and is beautifully colored orange and red. Is it drooling?\n"+
"You had better watch your back!\n");
set_level(1);
set_al(-50);
 gold = clone_object("obj/money");
  gold -> set_money(50);
  move_object(gold,this_object());

}
