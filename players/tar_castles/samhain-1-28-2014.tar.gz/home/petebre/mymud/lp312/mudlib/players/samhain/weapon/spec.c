#include "/players/hippo/bs.h"
int w;
int v;
 inherit "obj/weapon.c";
 reset(arg) {
    ::reset();
    if (arg) return;
   set_name("glue");
   set_short("a strong, 1 second glue");
   set_long("This is a glue that could make the opponent's arms"+BS+
       "stick together, so you can hurt him an extra time before"+BS+
        "he can hurt you... this is something you must like... "+BS);
set_class(18);
set_weight(2);
set_value(1500);
set_hit_func(this_object());
}
weapon_hit(attacker){
w=random(3);
if (w>1) {
set_hit_func(this_object());
}
v=random(10);
   if(v>6) {
set_hit_func(this_object());
return;
}
}
