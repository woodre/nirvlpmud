inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Dungeon of Camelot";
long_desc =""+
"This third room of the dungeon reveals even more Moors that are held prisoner. \n"+
"They looked pissed off and also a little scared if that's possible. \n"+
"You begin to wonder why they seem to stay away from the room to the \n"+
"south........\n";
dest_dir = (({
"/players/samhain/rooms/cdun2.c","north",
"/players/samhain/rooms/monpit.c","south",
}));
items = (({
}));
}
enc(){
if (!present("moor")){
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
}}
