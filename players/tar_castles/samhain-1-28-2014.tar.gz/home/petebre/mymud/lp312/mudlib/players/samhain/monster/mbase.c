inherit "obj/monster";
object gold;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("x");
set_alias("x");
set_short("x");
set_long(
set_level(#);
set_al(#);
set_wc(#);
set_ac(#);
 gold = clone_object("obj/money");
  gold -> set_money(#);
  move_object(gold,this_object());

}
