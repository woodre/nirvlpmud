inherit "obj/monster";
reset(arg){
   object gold,weapon,armor;
   ::reset(arg);
   if(arg) return;
   set_name("rawhead rex");
   set_race("rex");
   set_alias("rex");
   set_short("Rawhead Rex");
set_long("Standing before you is a large 8 foot half-human, half-Tyrannosaurus \n"+
"Rex.  He is wielding a club and is wearing old brown leather armor.  This\n"+
"formidable foe seems to be grinning at you.  He is probably grinning \n"+
"becuase he is wearing a necklace made of the skulls of some of the \n"+
"greatest warriors of Nirvanna...\n");
   set_level(25);
   set_hp(900);
   set_al(-1000);
   set_wc(34);
   set_ac(19);
   gold=clone_object("obj/money");
   gold->set_money(random(20)+300);
   move_object(gold,this_object());
   weapon=clone_object("/players/samhain/weapon/maul.c");
   move_object(weapon,this_object());
armor=clone_object("/players/samhain/armor/lskin.c");
move_object(armor,this_object());
   enable_commands();
   set_heart_beat(1);
   set_chance(60);
   set_spell_dam(10+random(30));
set_spell_mess1("Rawhead bashes with his club!!!");
set_spell_mess2("Rawhead crushes you with a brutal swing of his club!!!");
}
heart_beat(){
   int dam;
   object attacker,room;
   string attacker_name;
   ::heart_beat();
   room=environment(this_object());
   attacker=this_object()->query_attack();
   if(attacker){
      if(living(attacker)){
         attacker_name=attacker->query_real_name();
         if(present(attacker_name,environment(this_object()))){
            if(attacker->query_ghost() != 1){
               if(1 == random(5)){
                  tell_room(room,"Rawhead Rex smashed "+capitalize(attacker_name)+" with a bone crushing sound.\n");
                  dam=(20+random(10));
                  attacker->hit_player(dam);
               }
               else {
                  tell_room(room,"Rawhead Rex missed "+capitalize(attacker_name)+".\n");
               }
            }
            if(attacker->query_ghost() != 1){
               if(1 == random(5)){
                  tell_room(room,"Rawhead Rex smashed "+capitalize(attacker_name)+" with a bone crushing sound.\n");
                  dam=(20+random(10));
                  attacker->hit_player(dam);
               }
               else {
                  tell_room(room,"Rawhead Rex missed "+capitalize(attacker_name)+".\n");
               }
            }
            if(attacker->query_ghost() != 1){
               if(1 == random(5)){
                  tell_room(room,"Rawhead Rex smashed "+capitalize(attacker_name)+" with a bone crushing sound.\n");
                  dam=(20+random(10));
                  attacker->hit_player(dam);
               }
               else {
                  tell_room(room,"Rawhead Rex missed "+capitalize(attacker_name)+".\n");
               }
            }
            if(attacker->query_ghost() != 1){
               if(1 == random(5)){
                  tell_room(room,"Rawhead Rex smashed "+capitalize(attacker_name)+" with a bone crushing sound.\n");
                  dam=(20+random(10));
                  attacker->hit_player(dam);
               }
               else {
                  tell_room(room,"Rawhead Rex missed "+capitalize(attacker_name)+".\n");
               }
            }
            if(attacker->query_ghost() != 1){
              if(1 == random(5)){
                  tell_room(room,"Rawhead Rex smashed "+capitalize(attacker_name)+" with a bone crushing sound.\n");
                  dam=random(10);
                  attacker->hit_player(dam);
               }
               else {
                  tell_room(room,"Rawhead Rex missed "+capitalize(attacker_name)+".\n");
               }
            }
         }
      }
   }
}
