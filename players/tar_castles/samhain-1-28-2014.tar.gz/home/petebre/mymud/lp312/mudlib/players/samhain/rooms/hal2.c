inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Subterranean Cavern of Melnibonea";
long_desc =""+
"YEEEEEEEEEEEEEEEEEEEEEEEEOOOOOOWWWWWWWWWWWWWWW!!!!!!!!!\n"+
"DOWN...........                                        \n"+
"               DOWN............                        \n"+
"                               DOWN....................\n"+
"You hit the moist ground like a grungy sack of rice, as you look around, \n"+
"You notice that the room is very dim and that there are a lot of shadows \n"+
"moving around......You can continue down this dark cavern or you can try to \n"+
"climb back up the way you fell.\n";
dest_dir = (({
"/players/samhain/rooms/mlb3","climb",
"/players/samhain/rooms/hal8","east",
}));
items = (({
}));
}
