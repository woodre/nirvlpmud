inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Dragon Peak";
long_desc =""+
"You are standing atop a moutain gazing out over the horizon. Majestic peaks\n"+
"stretch out before you and dragons fly through the air above. Behind you is\n"+
"Samhain's throne. It is a massive work, carved from a single piece of black\n"+
"marble to look like a dragon's maw.\n";
dest_dir = (({
"/room/church","church",
"/players/samhain/guild/gmain","guild",
"/room/post","post",
}));
items = (({
}));
}
