inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Dungeon of Camelot";
long_desc =""+
"This second room of the dungeon reveals more Moors that are held prisoner. \n"+
"However, the extent of their imprisonment is just banishment in this \n"+
"dungeon.  They were left here to starve to death and see you as a very \n"+
"delectable and palatable meal.....\n";
dest_dir = (({
"/players/samhain/rooms/cdun1.c","north",
"/players/samhain/rooms/cdun3.c","south",
}));
items = (({
}));
}
enc(){
if (!present("moor")){
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
move_object(clone_object("/players/samhain/monster/moor.c"),this_object());
}}
