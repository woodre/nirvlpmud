inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Abode of Rex";
long_desc =""+
"As you enter the whirlpool you come across a dark, damp, earthy room \n"+
"with several decapitated corpses hanging by their heels....\n"+
"You stand in utter disgust as you wonder what could have \n"+
"done all of this you hear some rustling from behind the hanging \n"+
"cadavers.  You shudder when you see it is the mythical demon \n"+
"Rawhead Rex!!!!!!\n"+
"You can either run back through the whirlpool where you came in \n"+
"or you can flee into Rawhead's maze but you won't know where you'll \n"+
"end up....or you can try to defeat Rawhead and save the world\n";
dest_dir = (({
"/players/samhain/rooms/mel1.c","whirlpool",
"/players/samhain/rooms/hal8.c","flee",
}));
items = (({
}));
}
enc() {
if (!present("rex")){
move_object(clone_object("/players/samhain/monster/rhrex.c"),this_object());
}}
