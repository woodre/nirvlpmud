inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Entrance to Melnibonea";
long_desc =""+
"You see before you three paths leading into the mythical land of \n"+
"Melnibonea.  Each path is said to lead to the treasure-ladden lair \n"+
"of the Warrior-Mage Elric.  The path to your northeast is misty and \n"+
"smoky.  The path directly to your east is dark and menacing.  While \n"+
"the path to you southeast seems to smell of fine wine and song while \n"+
"there appears to be an appartition to the north(wonder what's inthere\n"+
"Last option.... you could chicken out and go back west to where \n"+
"you came from.\n";
dest_dir = (({
"/players/samhain/rooms/hal1","northeast",
"/players/samhain/rooms/mel2","west",
"/players/samhain/rooms/hal2","east",
"/players/samhain/rooms/hal3","southeast",
"/players/samhain/rooms/melbar","north",
}));
items = (({
}));
}
