inherit "obj/monster";
object gold, book;
reset(arg){
 ::reset(arg);
 if (arg) return;
set_name("ulemthor");
set_alias("ulemthor");
set_short("ULEMTHOR THE ZOMBIE LORD");
set_long(
"Ulemthor is a 10 foot tall undead hill giant who has usurped the \n"+
"rule of the zombies from Araxus.  He has long since disposed of the\n"+
" rotted corpse and has now set his sights on ruling Melnibonea by \n"+
"killing Elric and Marduk and using their undead bodies to get rid of \n"+
"Arioch and finally ruling Melnibonea to start his undead world venture.\n");
set_level(30);
set_hp(900);
set_al(-1000);
set_wc(25);
set_ac(9);
set_chance(40);
set_aggressive(1);
set_can_kill(1);
set_spell_dam(35);
set_spell_mess1("A black cloud of death fills the room!!!\n");
set_spell_mess2("Ulemthor envelops you in a black cloud of death!!!\n");
set_chat_chance(30);
load_chat("Ulemthor grunts: YOU WILL BECOME MY UNDEAD SERVANTS!!!\n");
 gold = clone_object("obj/money");
  gold -> set_money(7000);
  move_object(gold,this_object());
book = clone_object("/players/samhain/treasure/ubook.c");
move_object (book,this_object());

}
