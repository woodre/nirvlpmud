inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Melnibonean Crypt";
long_desc =""+
"YEEEEEEEEEEEEEEEEEEEEEEEEOOOOOOWWWWWWWWWWWWWWW!!!!!!!!!\n"+
"DOWN...........                                        \n"+
"               DOWN............                        \n"+
"                               DOWN....................\n"+
"DOWN.......................                         \n"+
"DOWN YOU GO into the seemingly bottomless pit.......\n"+
"You hit the soft, again crunchy ground with a nerve wrenching \n"+
"thud.  As you look around you make out a stiff climb back to where \n"+
"you were, and a misty, intimidating cavern in front of you....\n";
dest_dir = (({
"/players/samhain/rooms/hal13","climb",
"/players/samhain/rooms/drago","cavern",
}));
items = (({
}));
}
enc() {
if (!present("zombie")){
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
move_object(clone_object("/players/samhain/monster/zombie"),this_object());
}
}
