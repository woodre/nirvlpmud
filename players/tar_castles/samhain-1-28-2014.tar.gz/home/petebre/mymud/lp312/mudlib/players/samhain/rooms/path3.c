inherit "room/room";
reset(arg){
if (arg) return;
set_light(1);
short_desc = "Plateau on Dragon Peak";;
long_desc =""+
"Huffing and puffing you reach a wide plateau on the path. Here is a small\n"+
"spring and a few trees. This looks like a perfect place to rest since the\n"+
"seems to end here. Overhead you can see dragon dancing in the air. They\n"+
"don't seem to notice you, and you relax a little.\n";
dest_dir = (({
"/players/samhain/rooms/path2","down",
}));
items = (({
"spring","The water looks perfect to drink or for a swim",
}));
}
