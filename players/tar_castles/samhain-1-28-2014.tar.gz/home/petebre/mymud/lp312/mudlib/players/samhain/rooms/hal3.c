inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Melnibonean Hedonism";
long_desc =""+
"You enter a room with silk tapestries hanging from the ceiling \n"+
"which cover the opulent marble columns lining the wall.  In the center \n"+
"of the room is a large table with all sorts of fine food and even \n"+
"better wine.  However, I don't think the barbarians that are in here \n"+
"will be nice enough to share some of it with you. \n";
dest_dir = (({
"/players/samhain/rooms/mlb3","northwest",
"/players/samhain/rooms/hal4","south",
"/players/samhain/rooms/hal9","east",
}));
items = (({
}));
}
enc() {
if (!present("barbarian")){
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
move_object(clone_object("/players/samhain/monster/abarb.c"),this_object());
}
}
