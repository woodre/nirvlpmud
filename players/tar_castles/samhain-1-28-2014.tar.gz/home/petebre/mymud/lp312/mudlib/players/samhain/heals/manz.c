inherit "obj/treasure.c";
int drags, price;
reset (arg) {
set_id("manzanilla");
set_alias("bag");
drags = 10;
price = drags * 300;
}
long(){
write("This is a bag filled with Manzanilla herbs for a \n"+
"sobering effect.  You have enough Manzanilla herb for "+drags+" more \n"+
"sobering invigorations...Try to 'drag bag'....\n");
}
short(){return "Bag of Manzanilla";}
query_value()
{ return price; }
init(){::init();
add_action("drag","drag");
}
drag(arg){
if(arg!="bag"){
notify_fail("Try to 'drag bag'\n");
return 0;
}
drags = drags - 1;
write("You see pretty lights for a bit and then feel better...\n");
say (this_player()->query_name() +" snorts up some herbs.\n");
this_player()->drink_alcohol(-7);
if (drags == 0){
destruct(this_object());
write("You find that the manzanilla is no longer effective so \n"+
"you toss the bag away...\n");}
return 1;}
get(){
return 1;
}
query_weight(){
return 2;
}
