inherit "room/room";
reset(arg){
enc();
if (arg) return;
set_light(1);
short_desc = "Valley in Dragon Peaks";
long_desc =""+
"You follow the stream out of the village down to the edge of the valley.\n"+
"Here the natives have gathered for some sort of ceremony. You see them\n"+
"dancing around a huge bonfire. When they notice you the females run off\n"+
"in fear while the men draw weapons. You see what looks like a shaman throw\n"+
"a woman over the edge of the waterfall where the valley ends.\n";
dest_dir = (({
"/players/samhain/rooms/val6","north",
}));
items = (({
"waterfall","It looks like it's a long way down. Maybe you could dive down there ",
}));
}
enc(){
 if(!present("warrior")){
  move_object(clone_object("/players/samhain/monster/natw"),this_object());
  move_object(clone_object("/players/samhain/monster/natw"),this_object());
  move_object(clone_object("/players/samhain/monster/natw"),this_object());
  move_object(clone_object("/players/samhain/monster/natw"),this_object());
  }
 if(!present("shaman")){
  move_object(clone_object("/players/samhain/monster/nats"),this_object());
  }
}
