inherit	"room/room";

reset(arg) { 
 if(!present("**")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Tomb of TEMPTATION with Pillars of Dreams.";
  long_desc = 
   "   You have jumped onto the next pillar and it rumbles and shakes with\n"+
   "your weight atop it, you had better move faster or mail your will soon.\n"+
   "\n"+
   "  The laughing increases with your every step and you begin to sweat\n"+
   "more and more as you see your life flash before you in a whirl.\n";
  dest_dir = ({"players/azane/tomb4.c", "north",
               "players/azane/tomb5.c", "northeast",
               "players/azane/tomb1.c", "west",
               "players/azane/tomb2.c", "east"});
  }
}
