inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Phoenix Claws");
set_alias("claws");
set_short("Phoenix Claws");
set_long(
"   They are the claws from a phoenix, once thought extinct.\n");
set_value(500);
set_weight(2);
set_class(7);
}
