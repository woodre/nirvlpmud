inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("sword");
set_alias("sword");
set_short("sword");
set_value(1);
set_weight(0);
set_class(1000);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100)<100 && attacker->query_race() == "all") {
write(attacker->query_name()+" is slammed by your sword.\n");
say(attacker->query_name()+" is slammed by "+this_player()->query_name()+"'s sword.\n");
return 10;
   }
return 0;
 }
