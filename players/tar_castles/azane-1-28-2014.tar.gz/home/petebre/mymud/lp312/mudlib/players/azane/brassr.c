inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Brass Ring");
set_alias("ring");
set_short("Brass Ring");
set_long(
"   This here is one hell of a ring! As you look at it you become \n"
+ "mesmorized into a dream state, you see yourself singing on stage\n"
+ "with the group BLACK SHEEP. \n"
+ "\n"
+ "You sing: Yeh O.P.P.\n"
+ "          you know me.........\n");
set_value(100);
set_weight(2);
set_class(7);
}
