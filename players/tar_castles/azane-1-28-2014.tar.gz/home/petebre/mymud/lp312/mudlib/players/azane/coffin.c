inherit	"room/room";

reset(arg) { 
 if(!present("Stone")) {
   move_object(clone_object("players/azane/stone.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Sarcophagus of TEMPTATION.";
  long_desc = 
   "   Within this Sarcophagus you now lie, statues of creatures are on\n"+
   "each of it's corners. As you had entered it their gaze moved with your \n"+
   "movements and now watch you as you search the coffin. They make no \n"+
   "movement toward you, but it becomes unnerving all the same. The interior \n"+
   "of the coffin is of the same material as the walls back at the entrance\n"+
   "to the archway and also pulsate as it feeds on your energy, the energy \n"+
   "of fear. A small stone is beside you, and appears not worthy of your\n"+
   "time to look at it, it is of no great worth unless you collect stones.\n";
  dest_dir = ({"players/azane/coffin2.c", "take"});
  }
}
