

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "A Club with sounds of music inside.";
    no_castle_flag = 0;
    long_desc = 
        "   You've entered an abandoned clubhouse that was at one time used\n"
        + "by people here on the beach, but Club Med has taken away all the\n"
        + "business and they had to close it down. As you look around the room\n"
        + "you can feel a breeze coming from the south wall, and you can hear\n"
        + "a distinctive sound of music coming from behind it. Stepping closer\n"
        + "you notice a trap door outlined on the floor, that from a distance\n"
        + "you would not have noticed.....\n";
    dest_dir = 
        ({
        "players/azane/path2.c", "north",
        "players/azane/transit.c", "trapdoor",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

