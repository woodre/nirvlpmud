inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Within forest of Island";
  long_desc = 
   "  Within the trees and bushes of the Island twigs snap under your weight\n"+
   "and animals scurry into deeper regions of the island, a cave lies to the \n"+
   "north that would have been hidden if not for your keen eye-sight. To \n"+
"the east lies the volcanoe and it's strange flying creatures of such size\n"+
   "to send shivers down your spine, to the northeast a well worn path leads\n"+
   "deep into the island and  to the southeast another path goes off on it's\n"+
   "very own tangent.\n";
  dest_dir = ({"players/azane/cave1.c", "north",
               "players/azane/pathc.c", "northeast",
               "players/azane/pathb.c", "east",
               "players/azane/islandbeach2.c","west",
               "players/azane/patha.c", "southeast"});
  }
}
