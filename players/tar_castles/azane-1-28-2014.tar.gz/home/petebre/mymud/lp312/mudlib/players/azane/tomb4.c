inherit	"room/room";

reset(arg) { 
 if(!present("Marble Pillar")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Pillar of Tomb.";
  long_desc = 
   "  You have jumped onto the next pillar and it rumbles and shakes under\n"+
   "your very weight, but you are able to stabilize yourself.\n"+
   "\n"+
   "   The laughing rings in your ears as it is much louder now, you begin\n"+
   "to sweat more and more with each heartbeat and you see your life flash\n"+
   "before you and you wish now that you had used the washroom before coming\n"+
   "in.\n";
  dest_dir = ({"players/azane/tomb7.c", "north",
               "players/azane/tomb5.c", "east",
               "players/azane/tomb1.c", "west",
               "players/azane/tomb3.c", "south",
               "players/azane/tomb2.c", "southeast"});
  }
}
