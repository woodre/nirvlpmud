inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Baracas Island.....Brotherhood hideaway.";
  long_desc = 
   "   Close to the beach head you spot many footprints in the sand, mostly\n"+
"of animals but a few appear to be human. Smoke billows from the islands\n"+
"volcanoe to the east as it rises forming a huge cloud of ash while \n"+
   "a great winged beast soars into the air above it screeching out a cry\n"+
   "of anguish or of superiority.\n";
  dest_dir = ({"players/azane/islandbeach.c", "west",
               "players/azane/islandbeach3.c", "east"});
  }
}
