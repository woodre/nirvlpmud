

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "A Westward pathway to whoknows where.";
    no_castle_flag = 0;
    long_desc = 
        "   This path seems to lead westward into the forest, towards the north\n"
        + "you can make out the image of what appears to be a monestary that has\n"
        + "long since been abandoned by the brotherhood.\n";
    dest_dir = 
        ({
        "players/azane/path4.c", "northwest",
        "players/azane/path2.c", "east",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

