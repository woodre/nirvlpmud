
inherit"obj/monster";
reset(arg) {
object money;
object weapon;
string chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(1);
chat_str[0] = "Captain we have a security breach! Enemy within.\n";
  }
set_name("Navigation Officer");
set_alias("officer");
set_short("Navigation Officer");
set_long(
"    The navigation officer for this ship and about one of the only men\n"
+ "who knows how to control all of it's functions without a nuclear meltdown\n"
+ "\n"
+ "occuring.\n");
set_level(5);
set_race("human");
set_hp(50);
set_wc(5);
set_ac(5);
set_spell_mess2("");
load_chat(20,chat_str);
set_random_pick(10);
money = clone_object("obj/money");
money->set_money(5);
move_object(money, this_object());
weapon = clone_object("/players/azane/gunn.c");
if(weapon) {
move_object(weapon,this_object());
command("wield "+weapon->query_name());
   }
}
