inherit	"room/room";

reset(arg) { 
 if(!present("driftwood")) {
   move_object(clone_object("players/azane/driftwood.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Beach shoreline";
  long_desc = 
   "   Ahhhhhh..........More sand, more sea, more pebbles?\n"+
   "\n"+
   "It seems that this area of the beach has many pebbles buried below the\n"+
   "sand, your feet seem to want to kick you in the butt for walking such a \n"+
   "distance when you could have been swimming or playing volleyball with\n"+
   "the girls, or even trying to get a tan.\n";
  dest_dir = ({"players/azane/beach2.c", "north"});
  }
}
