inherit	"room/room";

reset(arg) { 
 if(!present("Sword of Skelos")) {
   move_object(clone_object("players/azane/skelosword.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Energy Void";
  long_desc = 
   "   All is darkness within space, time does not exist here.\n"+
   "\n"+
   "Your body floats freely and you are awed by the beauty as you look\n"+
   "down upon the world, a shooting star passes by your head and falls\n"+
   "toward the planet below. No one can harm you here, you are with \n"+
   "the Gods of the Heavens. Floating near you is a gleaming object\n"+
   "encrusted lightly in a mist of colours, it comes closer to you and\n"+
   "you reach out to grab it. Why is it out here in space, why are\n"+
   "you? You have forgotten everything that you hold dear to you and of\n"+
   "the adventures you have been on, if you 'concentrate' maybe you \n"+
   "can remember why you came here.\n";
  }
}
init()
{
add_action("concentrate"); add_verb ("concentrate");
}
concentrate()
{
call_other(this_player(),"move_player","concentrate#players/azane/monestary");
return 1;
}
