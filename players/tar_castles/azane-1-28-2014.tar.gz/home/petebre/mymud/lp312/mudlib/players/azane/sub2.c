inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(0);
  short_desc = "Metal rung ladder in darkened tunnel.";
  long_desc = 
   "   You appear to be halfway down (or up philosophically speaking) on a \n"+
   "metal ladder made of separate rungs. Below you the voice's are loud and\n"+
   "angry sounding as the action seems to get more heated and frenzied. You \n"+
   "can make out the shapes of humans scurrying around.\n";
  dest_dir = ({"players/azane/sub1.c", "up",
               "players/azane/sub3.c", "down"});
  }
}
