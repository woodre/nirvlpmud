inherit	"room/room";

reset(arg) { 
 if(!present("Skeleton")) {
   move_object(clone_object("players/azane/crypt.c"), this_object());
 }
  if(!arg) {
  set_light(0);
  short_desc = "Burial area of dead.";
  long_desc = 
   "   You go forth into the narrow passage way, head bowed with your eyes\n"+
   "quickly taking in your surroundings with each step you move. To each side\n"+
   "of you are burial areas that once contained being's more ancient than\n"+
   "the earth itself, all that is left of them now is dust and ashes, their\n"+
   "shrouds baring just the weight of bones. The remains have been undisturbed\n"+
   "for eons, until now......\n";
  dest_dir = ({"players/azane/crypt2.c", "north",
               "players/azane/temptation.c", "south"});
  }
}
