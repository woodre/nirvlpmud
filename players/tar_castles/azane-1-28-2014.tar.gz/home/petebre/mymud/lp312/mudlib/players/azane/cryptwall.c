inherit	"room/room";

reset(arg) { 
 if(!present("Green Slime")) {
   move_object(clone_object("players/azane/slime.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = " Northern end of cavern near wall.";
  long_desc = 
   "  Finally you have reach the end of your tiresome journey.\n"+
   "\n"+
   "  You stand almost face to face with the wall, and the slime that\n"+
   "covers it. As you stand there examining the wall you shudder as you\n"+
   "believe that the wall had moved ever so slightly toward you, are\n"+
   "you just tired or could it be true?  Beneath the slime cracks of\n"+
   "light pierce out between layers of stone, with your strength you \n"+
   "could try to 'smash' the wall in upon itself.\n";
  }
}
init()
 {
 add_action ("south"); add_verb ("south");
 add_action ("smash"); add_verb ("smash");
 add_action ("northwest"); add_verb ("northwest");
  }
     
south()
{
call_other(this_player(), "move_player", "south#players/azane/crypt3");
return 1;
}
smash()
{
call_other(this_player(), "move_player", "smash#players/azane/tomb2");
return 1;
}
northwest()
{
call_other(this_player(), "move_player","northwest#players/azane/tomb");
return 1;
}
