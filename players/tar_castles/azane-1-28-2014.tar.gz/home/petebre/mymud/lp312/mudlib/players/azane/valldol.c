

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "Entrance to Valley of the Dolls.";
    no_castle_flag = 0;
    long_desc = 
        "   Before you lies the expansion of the valley, a narrow path leads\n"
        + "travelers from one end of the valley to the other. You gaze upon\n"
        + "the surrounding landscape searching for any ambush that might occur, as\n"
        + "you look you see many figures hovering in the air.\n"
        + "\n"
        + "   Could this be some fairy convention that you weren't told about, or\n"
        + "is it Peter Pan's hideout? \n";
    dest_dir = 
        ({
        "players/azane/archway.c", "north",
        "players/azane/valldol2.c", "south",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

