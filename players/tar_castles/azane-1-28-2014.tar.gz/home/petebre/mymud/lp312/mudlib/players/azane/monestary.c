inherit	"room/room";

reset(arg) { 
 if(!present("Francescan Monk")) {
   move_object(clone_object("players/azane/Monk.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "  Entrance to Monestary of Sadeness";
  long_desc = 
   "You shout: I am here to seek Guidance!\n"+
   "\n"+
   "  Upon the steps of the monestary you stand, vigilante and in awe\n"+
   "of this magnificant structure. Tears of joy enter your eyes as you\n"+
   "have realized your discovery, many years have past since you last heard\n"+
   "of this place and it's treasure that many have called 'TEMPTATION'.\n"+
   "In front of you the broken doorway stands open with no one to stop\n"+
   "you in your quest, years of decay should make it easy for you to find\n"+
   "the treasure.\n";
  dest_dir = ({"players/azane/monestary2.c", "north",
               "players/azane/path5.c", "south"});
  }
}
