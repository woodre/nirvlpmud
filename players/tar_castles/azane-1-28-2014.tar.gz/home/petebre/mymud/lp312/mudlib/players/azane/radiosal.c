
inherit"obj/monster";
reset(arg) {
object money;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(2);
a_chat_str = allocate(1);
chat_str[0] = "Captain, Captain........I just received this important message!\n";
chat_str[1] = "HEY!!! Your not the Captain......What are you doing here?\n";
a_chat_str[0] = "HELP! HELP! HELP!  There's a spy aboard!\n";
  }
set_name("Radio Operator");
set_alias("operator");
set_short("Radio Operator");
set_long(
"The radio operator for this vessle sitting at his desk decipering \n"
+ "what seems to be a top secret message, he gets up to go see the captain\n"
+ "while you are looking at him.\n");
set_level(5);
set_race("human");
set_hp(50);
set_al(-20);
set_wc(5);
set_ac(5);
set_spell_mess2("");
load_chat(20,chat_str);
load_a_chat(20,a_chat_str);
set_random_pick(10);
money = clone_object("obj/money");
money->set_money(10);
move_object(money, this_object());
}
