inherit	"room/room";

reset(arg) { 
 if(!present("Beach Nymph")) {
   move_object(clone_object("players/azane/nymph.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Pebble Beach";
  long_desc = 
   "     The sand parts under the weight of your feet, and the calm sounds\n"+
   "of the sea echo up and down the sands like whispers in the wind. To the \n"+
   "north you can see bodies unadorned with clothing playing beach volleyball\n"+
   "and swimming into the sea. Southwards you see endless dunes of white sand\n"+
   "and driftwood lining the shores with the occassional crab rolling coconuts\n"+
   "up the beach. The sea continues in an endless stretch out to the east as\n"+
   "Dolphins jump in and out of the water playfully.\n";
  dest_dir = ({"players/azane/beach.c", "west",
               "players/azane/beach4.c", "north",
               "players/azane/beach3.c", "east",
               "players/azane/beach6.c", "south"});
  }
}
