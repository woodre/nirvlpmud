inherit"obj/treasure";
reset(arg) {
   if(arg) return;
   set_id("A SIGN");
   set_alias("sign");
   set_short("a sign");
   set_long(
      "   AZANE'S NOW OPEN, SOUTHWEST OF ULTRAMAGNUS'S.\n"
      + "READ ALL, SOME HINT'S ARE WITHIN TEXT, AS ARE DESCRIPTIONS.\n"
      + "IF YOU FIND TYPO'S MAIL ME OR ANY PROBLEM WITH IT.\n"
+ "BEWARE NOT EVERYTHING 'LOOKS EASY', TEMPTATION VERY HARD!!.\n"
   + "ALSO ANY SUGGESTIONS TO MAKE IT BETTER OR BETTER TO YOU.\n");
set_value(0);
set_weight(6);
}
