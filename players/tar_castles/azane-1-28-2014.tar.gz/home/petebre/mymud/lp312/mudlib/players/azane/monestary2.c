inherit	"room/room";

reset(arg) { 
  if(!arg) {
set_light(0);
  short_desc = "The Darkened entrance to the Monestary.";
  long_desc = 
   "   You have entered within the sanctuary of the monestary, the walls\n"+
   "within the entrance are darked with years of grime and dust. From here\n"+
   "you can see within, in the center of the building lies a fallen pillar\n"+
   "that had toppled during the last earthquake. In each corner of the \n"+
   "building are a set of stairways that lead up to a small seating area \n"+
   "used by the monks to pray and concentrate, you notice a glimmer from\n"+
   "these area's. At the center of this great building the rays of light\n"+
   "shine down directly to the center where the pillar has fallen, you notice\n"+
   "that the pillar has cracked the floor revealing a hole.\n";
  dest_dir = ({"players/azane/monestary3.c", "north",
               "players/azane/monestary.c", "south"});
  }
}
