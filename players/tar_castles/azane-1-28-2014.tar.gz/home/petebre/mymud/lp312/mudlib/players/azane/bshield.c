inherit"obj/armor";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Shield of Bones");
set_alias("shield");
set_short("Shield of Bones");
set_long(
"   It is a shield made out of bones in a criss-cross pattern,\n"
+ "and covered in human skin.....\n");
set_weight(2);
set_value(300);
set_ac(1);
set_type("shield");
}
