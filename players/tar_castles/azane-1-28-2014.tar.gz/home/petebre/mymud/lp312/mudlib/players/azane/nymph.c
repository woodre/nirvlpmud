
inherit"obj/monster";
reset(arg) {
object money;
object weapon;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(2);
a_chat_str = allocate(2);
chat_str[0] = "Come to me my love and I will warm your soul.\n";
chat_str[1] = "Do you not find me attractive?\n";
a_chat_str[0] = "Please do not hurt me, I love you...\n";
a_chat_str[1] = "Come, I need your life force.\n";
  }
set_name("female");
set_alias("female");
set_short("A female worshipping the SUN GODS");
set_long(
"   She is a most beautiful and erotic creature of the seas, she\n"
+ "wears no clothing because she is at one with nature. Her body is \n"
+ "perfectly proportioned, with lips as red as a petal on a rose and\n"
+ "just as soft, her hair flows with abandoned freedom in the wind, and \n"
+ "when you look into her eyes you are cast into an enchantment spell. Her\n"
+ "breasts are ample and have a distinctive bounce all there own as if \n"
+ "they are trying to say something to you........\n");
set_level(11);
set_race("Sylph");
set_hp(250);
set_al(-2);
set_wc(10);
set_ac(10);
set_chance(85);
set_spell_dam(31);
set_spell_mess1("As she kisses you, your very being is sucked out of you.");
set_spell_mess2("Her kisses drain the very life out of you...");
load_chat(25,chat_str);
load_a_chat(30,a_chat_str);
set_ep(6390);
set_whimpy(20);
set_random_pick(15);
money = clone_object("obj/money");
money->set_money(50);
move_object(money, this_object());
weapon = clone_object("/players/azane/hair.c");
if(weapon) {
move_object(weapon,this_object());
command("wield "+weapon->query_name());
   }
}
