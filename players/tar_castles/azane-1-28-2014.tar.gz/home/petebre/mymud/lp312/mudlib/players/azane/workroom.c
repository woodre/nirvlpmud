

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "workroom";
    no_castle_flag = 0;
    long_desc = 
        "               W E L C O M E   T O   T H E   B E A U T I F U L\n"
        + "                             I S L A N D   O F\n"
        + "                           B  A  R  B  A  D  O  S\n"
        + "\n"
        + "     As you look around you notice the figure of Azane lounging down on\n"
        + "the beach sipping on a Pina Colada, and basking in the warm rays of the\n"
        + "sun. Strewn around him are the tanning bodies of Hugh Hefner's PLAYMATES,\n"
        + "delicately wrapped in thin bathing suits and glistening with oil. As your\n"
        + "eyes focus back on Azane you notice a smile begin to form on his lips as\n"
        + "he turns toward you.........\n"
        + "\n"
        + "   You hear him shout.... Come mon, join me in a drink with these lovely\n"
        + "beauties.\n"
        + "\n"
        + "   As you walk toward him, you can hear the Island's music drift around\n"
        + "you mixing with the sweet scents of exotic Island perfume's. As you walk \n"
        + "toward the beach you can see tha waves gently carressing the sands and\n"
        + "your mind begins to whirl as if this was all just a dream.....\n";
    dest_dir = 
        ({
        "/room/ruin", "up",
        "/players/morgar/wizworld/courtyard", "down",
        "/room/shop", "north",
        "/players/blackadder/hideaway", "south",
        "/room/sea", "east",
        "/room/church", "west",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

