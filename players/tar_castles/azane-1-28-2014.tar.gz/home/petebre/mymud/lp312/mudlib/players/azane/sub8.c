inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(0);
  short_desc = "Stairway leading out and down in the Sub";
  long_desc = 
   "  Clutching onto metal rungs your hands grow numb with pain as\n"+
   "an electrical shock goes through your arms. It seems that you are not\n"+
   "wearing the protective clothing issued to all seamen.\n";
  dest_dir = ({"players/azane/sub9.c", "up",
               "players/azane/sub7.c", "down"});
  }
}
