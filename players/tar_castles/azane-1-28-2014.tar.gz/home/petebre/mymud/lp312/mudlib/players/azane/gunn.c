inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("9mm gunn");
set_alias("gun");
set_short("9mm gun");
set_long(
" It appears to be a 9mm gun that has a full clip load.\n");
set_value(100);
set_weight(1);
set_class(6);
}
