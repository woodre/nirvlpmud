inherit"obj/armor";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Emerald Armour");
set_alias("armor");
set_short("Emerald Armour");
set_long(
"   An armor made from Emeralds and other gems that adorn it. It looks\n"
+ "heavy but is not because of a spell that was cast on it by the Wizard\n"
+ "AZANE. It may even have untold of powers, but these are beyond your\n"
+ "understanding for now........\n"
+ "\n");
set_weight(2);
set_value(14098);
set_ac(4);
set_type("armor");
}
