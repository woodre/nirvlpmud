inherit	"room/room";

reset(arg) { 
 if(!present("Marble Pillar")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "ON TOP OF OLE' PILLAR, ALL COVERED WITH SWEAT?";
  long_desc = 
   "   You have jumped onto the next pillar and it rumbles and shakes with \n"+
   "your weight atop it, you had better move faster or mail your will soon.\n"+
   "\n"+
   "The laughing increases with your every step and you begin to sweat\n"+
   "more and more as you see your life flash before you, not very pretty\n"+
   "huh!\n";
  dest_dir = ({"players/azane/tomb1.c", "north",
               "players/azane/tomb5.c", "northwest",
               "players/azane/tomb2.c", "west",
               "players/azane/tomb3.c", "east"});
  }
}
