inherit	"room/room";

reset(arg) { 
 if(!present("A Vine")) {
   move_object(clone_object("players/azane/Vine.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "A very rough feeling vine.";
  long_desc = 
   "  You are transversing down a very long and thick vine, as your hands\n"+
   "run along it you notice that it is rough and scaley to the touch. And\n"+
   "as you look down you can see the swimsuit models stare at you with \n"+
   "admiration, or is it stupidity?\n";
  dest_dir = ({"players/azane/path2.c", "up",
               "players/azane/lvine2.c", "down"});
  }
}
