
inherit"obj/monster";
reset(arg) {
object money;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(2);
a_chat_str = allocate(1);
chat_str[0] = "DON'T stand there like idiots, get him!!!!\n";
chat_str[1] = "You will not leave alive my friend.\n";
a_chat_str[0] = "God I hate you pussy Americans!\n";
  }
set_name("Captain Roshorski");
set_alias("captain");
set_short("Captain Vladamir Roshorski");
set_long(
"    He stands just over 6ft tall and of a massive build, truly this \n"
+ "Russian is no whimp. His gaze is stern as he starts to turn in your \n"
+ "direction and lunges at you.\n");
set_level(8);
set_race("human");
set_hp(90);
set_wc(8);
set_ac(8);
set_aggressive(1);
set_chance(15);
set_spell_dam(10);
set_spell_mess1("The Captain lunge's at your companion with a furry.");
set_spell_mess2("The captains fist connects with your face with a crunch.");
load_chat(20,chat_str);
load_a_chat(20,a_chat_str);
set_random_pick(90);
money = clone_object("obj/money");
money->set_money(25);
move_object(money, this_object());
}
