
inherit"obj/monster";
reset(arg) {
object weapon;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(1);
a_chat_str = allocate(1);
chat_str[0] = "I have arisen from my sleep, I am not very happy.\n";
a_chat_str[0] = "Your blood will boil with every strike, pain will engulf you.\n";
  }
set_name("Phoenix");
set_alias("phoenix");
set_short("Phoenix Bird");
set_long(
"    From the erupting fires of the volcanoe's rose this magnificant\n"
+ "bird, it is now alone after awakening from it's sleep. Your eyes\n"
+ "seem to burn as you look at the bird, an aurora of flames engulf this\n"
+ "creature as it watches you........\n");
set_level(14);
set_race("Phoenix Bird");
set_hp(225);
set_wc(9);
set_ac(10);
set_aggressive(1);
set_chance(90);
set_spell_dam(21);
set_spell_mess1("The Phoenix roars with anger, as it's eyes burn into you.");
set_spell_mess2("It's claws are sharp and very lethal.");
load_chat(100,chat_str);
load_a_chat(100,a_chat_str);
weapon = clone_object("/players/azane/claws.c");
if(weapon) {
move_object(weapon,this_object());
command("wield "+weapon->query_name());
   }
}
