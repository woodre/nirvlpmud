inherit	"room/room";

reset(arg) { 
 if(!present("sailor")) {
   move_object(clone_object("players/azane/sailor.c"), this_object());
 }
 if(!present("Captain")) {
   move_object(clone_object("players/azane/captain.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Command Center";
  long_desc = 
   "             Command Center: RUSSIAN NUCLEAR SUBMARINE #1672\n"+
   "\n"+
   "    The command center of the Russian nuclear submarine Chernobol, captain\n"+
   "Vladamir Roshorski at it's helm could navigate her anywhere blindfolded.\n"+
   "The navigation equiptment is located here as well as sonar and radar, the \n"+
   "sailors rapidly talk to each other in russian conveying vital information\n"+
   "for the continuous running of this vessel and it's catapillar engines which\n"+
   "make it virtually undetectable.\n";
  dest_dir = ({"players/azane/sub2.c", "up",
               "players/azane/sub4.c", "south"});
  }
}
