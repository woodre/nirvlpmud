inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("Diamond Heart");
set_alias("heart");
set_short("Diamond Heart");
set_long(
"   The heart and the very soul of the Crystal Warrior, it is made\n"
+ "entirely of diamonds and other rare jewels. Careful not to drop it\n"
+ "for to do so is to release another Crystal Warrior upon you.....\n");
set_value(500);
set_weight(2);
}
