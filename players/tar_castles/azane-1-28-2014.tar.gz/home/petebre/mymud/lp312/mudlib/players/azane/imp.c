object who;
int asked;

init () {
     if(living(environment(this_object()))) who=environment(this_object());
       add_action("ask_imp", "ask");
       add_action("stop_imp","quiet");
       add_action("destroy_imp", "poke");
}


id(str) { return str == "imp"; }


short() {
       return "A small imp";
}

long() {
     write("The imp winks at you and says: If your ever in a fight and you\n");
     write("         need to know how many hit points or spell points you \n");
     write("         have, just ASK me...I'll let you know how healthy you\n");
     write("         are every couple of seconds.  When you want me to stop\n");
     write("         just QUIET me.\n");
     write("         If you ever want me to leave forever, just POKE me!\n");
}

reset(arg) {
if(!arg) {write("\n\nThe imp says: The RED LION BROTHERHOOD welcome's you!\n"); }
     return 1;
}
drop() { return 1; }

query_auto_load() {
     return "players/azane/imp:" + "     "; }

query_value() { return 25; }

query_weight() { return 0; }

get() { return 1; }

ask_imp(str) {
     if(!id(str)) { return 0; }
     say("A small imp begins to whisper something to ");
     say(this_player()->query_name()+".\n");
     who = this_player();
     call_out("ask", 2, who);
     return 1;
}

ask(who) {
     tell_object(who, "The imp whispers to you: You have "+who->query_hp());
     tell_object(who," hit points and "+who->query_spell_point());
     tell_object(who," spell points.\n");
     call_out("ask", 2, who);
     return 1;
}

stop_imp() {
   remove_call_out("ask");
   say("A small imp dances on "+who->query_name()+"'s shoulder!\n");
   write("The imp dances on your shoulder!\n");
   return 1;
 }

destroy_imp(str) {
     if(!id(str)) { return; }
     if(id(str)) { write("The imp frowns and disappears in a puff of smoke!\n")
;
                   say(this_player()->query_name()+" pokes the imp.\n");
                   say("The imp frowns and disappears in a puff of smoke!\n");
                   destruct(this_object());
  return 1;
         }
}
