inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Crew quarters";
  long_desc = 
   "                        Room 3: CREW QUARTERS\n"+
   "\n"+
   "   In this hallway the crew quarters are located to the left and \n"+
   "right of you, they are empty right now as everyone is at their stations.\n"+
   "You look in them and see nothing special or of interest. From here\n"+
   "you can go to the radio room in area 'room 2' or into the weapons and\n"+
   "ammunition area in 'room 4'.\n";
 dest_dir = ({"players/azane/sub6.c","south",
              "players/azane/sub4.c","north"});
  }
}
