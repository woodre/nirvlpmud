inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("stone");
set_alias("stone");
set_short("stone");
set_long(
"   As you look at the stone it pulsates and draws your attention\n"
+ "towards it, it's magic begins to grow. It just lies there and it \n"
+ "rematerializes before your eyes into a gold statuette of a man.\n"
+ "  That man is AZANE, one of the truly great wizards, it was put \n"
+ "here by him for the one who is brave and smart. He is the only\n"
+ "one to discover the secrets of this ancient race of beings.\n");
set_value(1000);
set_weight(6);
}
