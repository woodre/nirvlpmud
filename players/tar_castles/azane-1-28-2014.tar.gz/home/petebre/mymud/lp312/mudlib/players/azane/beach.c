inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Sandy white Beach";
  long_desc = 
   "   Your feet seem to enjoy the warmth of this sandy white beach, and\n"+
"you let out a small unnoticeable sigh as you soak in the sun and almost \n"+
"lose yourself as your mind floats away from your body. Here you think\n"+
"is Eden, as God must have surely created this place in it's image.\n"+
"To the east is the 'Sea of Tranquility', it is a most wonderful\n"+
   "colour of blue you have ever seen and so very calm and gentle as the\n"+
   "waves lap up onto the beach. You feel like you are melting into the sand\n"+
   "as your tense muscle's now slowly relax.\n";
   dest_dir = ({"players/azane/lvine2.c", "climb",
               "players/azane/beach2.c", "east"});
  }
}
