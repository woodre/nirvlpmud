

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "Clearing of Solitude.";
    no_castle_flag = 0;
    long_desc = 
        "  Admist the forest you stand alone in a clearing, the birds fly and sing\n"
        + "around you without fear. Your 'spirits' begin to pick up as you begin to\n"
        + "feel more content with yourself and others. You begin to whistle a merry\n"
        + "tune to yourself and wave at the monk far ahead of you, MONK? what monk!\n";
    dest_dir = 
        ({
        "players/azane/path5.c", "north",
        "players/azane/path3.c", "southeast",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

