inherit	"room/room";

reset(arg) { 
 if(!present("Disc")) {
   move_object(clone_object("players/azane/disc.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Hovering above water";
  long_desc = 
   "   Your mind has been symbiotically linked with the disc as soon as\n"+
   "you tried to use it, hovering over the sea you skim across it not even\n"+
   "blinking as you move swiftly over the waves. You find yourself lucky \n"+
   "that you decided to take it as these waters are shark infested, you may\n"+
   "have parished without anyone knowing. From this point you can take the\n"+
   "disc to the mainland or to the island with little time lost.\n";
  dest_dir = ({"players/azane/dive3.c", "island",
               "players/azane/dive1.c", "mainland"});
  }
}
