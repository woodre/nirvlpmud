inherit "/obj/heal.c";
