int blocked;

id(str) { return str == "shield"; }

reset(arg) {
    if (!arg) blocked = 0;
    return;
}

init() { if(check_ok()) add_action("block","block"); }

block() {
    if (blocked) {
        blocked = 0;
        write("OK - block disabled.\n");
    }
    else {
        blocked = 1;
        write("OK - block enabled.\n");
    }
    return 1;
}

check_ok() {
    object man;

    if(!blocked) return 1;
    man = first_inventory(environment(this_object()));
    while(man) {
        if(man->query_invis()) {
            man->vis();
        }
        if (living(man) && !man->id("azane")) {
            tell_object(man,"Don't you think you should knock before you enter?\n");
            move_object(man,"room/church");
            return;
        }
        man = next_inventory(man);
    }
return 1;
}

    

