inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Leg Bone");
set_alias("bone");
set_short("Sharpened Leg Bone");
set_long(
" It is merely a leg bone that has been sharpened from the rats\n"
+ "knawing on it so much, otherwise it is not special.\n");
set_value(175);
set_weight(0);
set_class(5);
}
