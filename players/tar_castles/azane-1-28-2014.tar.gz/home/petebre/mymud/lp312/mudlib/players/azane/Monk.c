
inherit"obj/monster";
reset(arg) {
object weapon;
object treasure;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(1);
a_chat_str = allocate(1);
chat_str[0] = "Do not let Temptation lead you astray!\n";
a_chat_str[0] = "Do not let Temptation lead you astray!\n";
  }
set_name("Francescan Monk");
set_alias("monk");
set_short("Francescan Monk");
set_long(
"   A simple monk from the Monestary of Sadeness, he carries with him\n"
+ "the Cross of Pentance. The monks use these crosses when the travel from\n"
+ "village to village to help convert others to their faith. The crosses\n"
+ "are also use by the monks to bash themselves on the head when they have\n"
+ "impur thoughts in their minds. As you look closer you see that this monk\n"
+ "has quite the large bump on the noggin, as well as a smile.\n");
set_level(7);
set_race("human");
set_hp(150);
set_wc(7);
set_ac(7);
set_chance(66);
set_spell_dam(12);
set_spell_mess1("The monk raises his arms and mumbles something.");
set_spell_mess2("The monk casts a spell of Stupidity at you.");
load_chat(100,chat_str);
load_a_chat(100,a_chat_str);
set_random_pick(75);
weapon = clone_object("/players/azane/rope.c");
if(weapon) {
move_object(weapon,this_object());
   }
treasure = clone_object("/players/azane/crossb.c");
if(treasure) move_object(treasure,this_object());
}
