inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("Marble Pillar");
set_alias("pillar");
set_short("Marble Pillar");
set_long(
"   You look down at the pillar and it shakes with your movement, be careful\n"
+ "not to fall into the pit. It is not supported by anything that you can see, \n"
+ "but it is quite dark all around these pillars. You think for a moment\n"
+ "that you hear laughing echoing around the room, maybe it comes from the dark\n"
+ "figure.........maybe not.\n");
set_value(0);
set_weight(6);
}
