inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Cross of the Brotherhood");
set_alias("cross");
set_short("Cross of the Brotherhood");
set_long(
"   It is a cross used by the monks when they travel to villages nearby,\n"
+ "they use them for prair's and occasionally bang their heads with them in\n"
+ "pentance for impure thoughts.\n");
set_value(50);
set_weight(1);
set_class(6);
}
