inherit	"room/room";

reset(arg) { 
 if(!present("plaque")) {
   move_object(clone_object("players/azane/plaque.c"), this_object());
 }
  if(!arg) {
  set_light(0);
  short_desc = "    You are below the monestary in a maze of catacombs, to the north";
  long_desc = 
   "   You are below the monestary in a maze of catacombs, to the north\n"+
   "you can smell the pervasive stench of death and decay. At the end of the\n"+
   "corridor to the north the fungus covering the wall has a luminous\n"+
   "glow to it, it pulsates as you come closer to it and you can hear\n"+
   "the sound of your heartbeat boom with every step closer. On each\n"+
   "side of this corridor are recesses with corpses wrapped in shrouds. This\n"+
   "is the burial place of the founders of the monestary, beings who long\n"+
   "ago constructed this building but were burried beneath it in the first\n"+
   "earthquake to hit this continent many centuries ago. YOU are the first\n"+
   "to uncover it as it was long since forgotten.\n";
  dest_dir = ({"players/azane/monestary4.c", "up",
               "players/azane/crypt1.c", "north"});
  }
}
