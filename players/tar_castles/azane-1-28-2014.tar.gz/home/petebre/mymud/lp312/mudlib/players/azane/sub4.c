inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Entrance to Radio Room";
  long_desc = 
   "                      Room 2: RADIO ROOM TO EAST\n"+
   "\n"+
   "     This hallway is deserted accept for yourself and the ghosts that\n"+
   "haunt you throughout your existence. To the 'east' is the radio room,\n"+
   "there are two hatch's here also that lead to 'room 1' and 'room 3'. \n"+
   "\n"+
   " BE ON GUARD!\n";
  dest_dir = ({"players/azane/radroom.c", "east",
               "players/azane/sub3.c", "north",
               "players/azane/sub5.c", "south"});
  }
}
