#include "std.h"
int door_is_open, door_is_locked;
object knight, armor1, weapon, key, money;
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
extra_reset() {
   door_is_open = 0; door_is_locked = 1;
   if (!knight || !living(knight)) {
      knight = clone_object("obj/monster.talk");
      call_other(knight,"set_name","sailor");
      call_other(knight,"set_short","A sailor on guard duty.");
      call_other(knight,"set_long",
         "The sailor has been given guard duty for the night, but he is\n"+
"very alert and ready. He stands at his post diligantly.\n");
      call_other(knight,"set_level",19);
      call_other(knight,"set_ep",500000);
      call_other(knight,"set_hp",1000);
      call_other(knight,"set_ac",17);
      move_object(knight,this_object());
      money = clone_object("obj/money");
      call_other(money,"set_money",random(1000)+500);
      move_object(money,knight);
      call_other(knight,"set_chat_chance",20);
      call_other(knight,"set_a_chat_chance",33);
      call_other(knight,"load_chat","sailor says: Halt!\n");
      call_other(knight,"load_chat","sailor says: You are in a restricted area.\n");
      call_other(knight,"load_chat","sailor laughs at you puny americans.\n");
      call_other(knight,"load_chat","sailor says: Maybe a BIG american bribe I go sleep.\n");
      call_other(knight,"load_chat","sailor says: I will sound alarm if you do not vacate this area.\n");
      call_other(knight,"load_chat","sailor says: Now I will KILL you!!\n");
      call_other(knight,"load_chat","sailor looks at you and smirks.\n");
      call_other(knight,"load_chat","sailor flex's his Russian biceps and begins a pose down.\n");
      weapon = clone_object("obj/weapon");
      call_other(weapon,"set_name","dagger");
      call_other(weapon,"set_short","Standard issue Dagger");
      call_other(weapon,"set_alias","dagger");
      call_other(weapon,"set_long",
          "A standard issue dagger of the Russian navy, but this one appears\n"+
"to be made of better metal and seems to pulsate with a life force of it's\n"+
"own.\n");
      call_other(weapon,"set_class",18);
      call_other(weapon,"set_value",2500);
      call_other(weapon,"set_weight",3);
      transfer(weapon,knight);
      call_other(knight,"init_command","wield dagger");
      armor1 = clone_object("obj/armor");
      call_other(armor1,"set_name","uniform");
      call_other(armor1,"set_short","Russian Sailor's Uniform");
      call_other(armor1,"set_long","Specially made uniform from the KGB.\n");
call_other(armor1, "set_value", 2000);
      call_other(armor1,"set_ac",4);
      call_other(armor1,"set_type","armor");
      call_other(weapon,"set_weight",3);
      transfer(armor1,knight);
      call_other(knight,"init_command","wear uniform");
      call_other(knight,"set_ac",17);
      key = clone_object("obj/treasure");
      call_other(key, "set_id","computer key");
       call_other(key, "set_alias", "computer key");
       call_other(key, "set_short", "A computerized key");
      call_other(key, "set_value", 10);
      call_other(key, "set_weight", 1);
      transfer(key, knight);
   }
}

#undef EXTRA_LONG
#define EXTRA_LONG\
if (str =="door") {\
   if (door_is_open) {\
      write("The door is open.\n");\
      return;\
   }\
   write("The door is closed.\n");\
   return;\
}
#undef EXTRA_INIT
#define EXTRA_INIT\
add_action("open"); add_verb("open");\
add_action("unlock"); add_verb("unlock");\
add_action("west"); add_verb("west");\
add_action("telekenetics");   add_verb("telekenetics");\
add_action("search"); add_verb("search");

ONE_EXIT("/players/azane/sub6","east",
   "The armory",
   "This is where the subs weapons and ammunitions are stored and guarded\n"
+"at all times. A weapons vault has been built into this sub for extended\n"
+"missions during war time, some highly top secret things are suppose to be\n"
+"stored here. The vault is made of high impact Titanium and is rigged with\n"
+"and sensitive alarm system and wized for auto-destruct in the event of a\n"
+"crisis of breach of security by an unknown foe. To the west is the vault.\n",1)

id(str) {
return str ==  "door";
}
open(str) {
if (str && str !="door")
      return 0;
   if (door_is_open)
      return 0;
   if (door_is_locked) {
      write("The door is locked.\n");
      return 1;
   }
   door_is_open = 1;
   write("Ok.\n");
   say(call_other(this_player(), "query_name") + " opened the door.\n");
   return 1;
}
unlock(str) {
if (str && str !="door")
      return 0;
   if (door_is_open || !door_is_locked)
      return 0;
if (!present("computer key", this_player())) {
if (present("computer key",this_player()))
         write("You don't have the right key.\n");
      else
         write("You need a key.\n");
      return 1;
   }
   door_is_locked = 0;
   write("ok.\n");
   say(call_other(this_player(), "query_name") + " unlocked the door.\n");
   return 1;
}
west() {
   if (!door_is_open) {
      write("The door is closed.\n");
      return 1;
   }
   if (knight && present(knight, this_object())) {
      write("The sailor bars the way to the vault door.\n");
 say("Sailor says: You are a spy, I must not let you pass.\n");
write("Sailor says: I challenge you American capitalistic pig!!\n");
      return 1;
   }
call_other(this_player(), "move_player", "west#/players/azane/armory1");
   return 1;
}
telekenetics() {
   write("The door is more than it seems!\n");
   write("It's inherint magik resists your mental powers!\n");
   return 1;
}
search() {
   write("Nothing unusual found here.\n");
   return 1;
}
query_door() {
   return !door_is_open;
}
open_door_inside() {
   door_is_locked = 0;
   door_is_open = 1;
}
query_drop_castle() {
   return 1;
}
