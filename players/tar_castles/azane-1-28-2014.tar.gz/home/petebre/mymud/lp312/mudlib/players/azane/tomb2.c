inherit	"room/room";

reset(arg) { 
 if(!present("Marble Pillar")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = " Tomb of TEMPTATION with pillars of destiny.";
  long_desc = 
   "   You have entered the tomb of 'TEMPTATION' and so far have survived\n"+
   "all of the tests, darkness is below you as you finally realize that you\n"+
   "are standing atop a pillar that appears to be supported by NOTHING!!!!!\n"+
   " There are nine other pillars within the chamber, two pillars ahead\n"+
   "of you is a dark figure wrapped in a long flowing cloak as black as night \n"+
   "itself. Behind him is an unopened sarcophagus adorned with statues on\n"+
   "each corner looking in each direction, including at you.\n"+
   "\n"+
   "BEWARE! That you do not fall into the pit of 'LOST DREAMS'\n";
  dest_dir = ({"players/azane/cryptwall.c", "south",
               "players/azane/tomb1.c", "east",
               "players/azane/tomb5.c", "north",
               "players/azane/tomb3.c", "west",
               "players/azane/tomb4.c", "nw",
               "players/azane/tomb6.c", "ne"});
  }
}
