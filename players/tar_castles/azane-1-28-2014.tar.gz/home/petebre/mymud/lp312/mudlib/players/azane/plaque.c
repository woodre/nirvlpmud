inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("Plaque");
set_alias("plaque");
set_short("Plaque");
set_long(
"  Many centuries ago we the people of the planet Razamond, came to this\n"
+ "planet in search of peace. We were met with hatred and disgust because\n"
+ "of our appearance and philosopies, in the year 1281 A.D. we \n"
+ "built this temple for our Gods. In the years that had followed it's\n"
+ "construction our people were hunted and killed off, this cavern became\n"
+ "our sanctuary after the first great earthquake and subsequently our tomb.\n"
+ "\n"
+ "                                        TEMPTATION (1293 A.D.)\n");
set_value(0);
set_weight(6);
}
