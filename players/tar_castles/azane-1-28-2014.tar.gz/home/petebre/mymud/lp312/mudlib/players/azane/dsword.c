inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Diamond Broadsword");
set_alias("broadsword");
set_short("Diamond Broadsword");
set_long(
 "The light of the suns rays strike it, giving it a life of it's own.\n"
+ "Someday it's true owner will come for it, to reclaim what was once \n"
+ "stolen from him by another......\n"
+ "\n"
+ "Pray that it will not be in your possession then.\n");
set_value(21450);
set_weight(2);
set_class(20);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100) < 25) {
write(""+this_player()->query_name()+" use this weapon wisely, many have lost thier lives for it.\n");
say("As the sword lands, sparks light up the sky.......\n");
return 2;
   }
return 0;
 }
