
inherit"obj/monster";
reset(arg) {
object money;
object armour;
object weapon;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(2);
a_chat_str = allocate(1);
chat_str[0] = "Leave this place, it is not for the living.\n";
chat_str[1] = "We will attack if you do not leave.\n";
a_chat_str[0] = "There are many more of us my friend.\n";
  }
set_name("skeleton");
set_alias("skeleton");
set_short("Crypt Skeleton");
set_long(
"   This is a skeleton that guards the crypts under the church, he seems\n"
+ "to be very decade. But he is not alone down here, there are others\n"
+ "and creatures yet known to the world above that guard the Tale's of the\n"
+ "Crypt......\n");
set_level(5);
set_race("skeleton");
set_hp(100);
set_al(-1);
set_wc(4);
set_ac(3);
set_aggressive(0);
set_spell_mess2("");
load_chat(86,chat_str);
load_a_chat(86,a_chat_str);
set_random_pick(25);
money = clone_object("obj/money");
money->set_money(10);
move_object(money, this_object());
armour = clone_object("/players/azane/bshield.c");
if(armour) {
move_object(armour,this_object());
command("wear "+armour->query_name());
  }
weapon = clone_object("/players/azane/bone.c");
if(weapon) {
move_object(weapon,this_object());
command("wield "+weapon->query_name());
   }
}
