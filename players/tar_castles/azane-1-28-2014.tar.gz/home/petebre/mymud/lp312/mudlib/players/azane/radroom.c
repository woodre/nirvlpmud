inherit	"room/room";

reset(arg) { 
 if(!present("Radio Operator")) {
   move_object(clone_object("players/azane/radiosal.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Radio Room";
  long_desc = 
   "                Radio Room: AUTHORIZED PERSONNEL ONLY\n"+
   "\n"+
   "    A sailor sits attentively at his station taking in any message's or\n"+
   "listening to other radio wave's to pick up enemy signals. He seems\n"+
   "excited about something as he gets up and smile's at you.............\n";
  dest_dir = ({"players/azane/sub4.c", "west"});
  }
}
