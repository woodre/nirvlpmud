inherit	"room/room";

reset(arg) { 
 if(!present("Vine")) {
   move_object(clone_object("players/azane/Vine.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "The top of the cliff over looking the beach";
  long_desc = 
   "   You have traveled farther south along the path on top of the cliff\n"+
   "that over looks the beach. To the east you notice a long vine hanging \n"+
   "down from the tree nearby, it may be able to hold your weight but look\n"+
   "at it first just in case.\n"+
   "   As you gaze upon the white sands and take in the beautiful smell of \n"+
   "the ocean, your eyes begin to adjust more sharply as you notice the\n"+
   "SPORTS ILLUSTRATED SWIMSUIT MODELS lying down on the beach. Your mind\n"+
   "must be playing tricks on you as they wave at you and smile, trying to \n"+
   "entice you to a day of pleasure? The ocean does look very tranquil\n"+
   "and serene, and you do need a rest to continue on with your journey.\n";
  dest_dir = ({"players/azane/club.c", "south",
               "players/azane/path.c", "north",
               "players/azane/path3.c", "west",
               "players/azane/lvine.c", "down"});
  }
}
