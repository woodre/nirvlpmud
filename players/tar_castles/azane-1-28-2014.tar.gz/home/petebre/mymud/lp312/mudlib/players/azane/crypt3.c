inherit	"room/room";

reset(arg) { 
 if(!present("skeleton")) {
   move_object(clone_object("players/azane/crypt.c"), this_object());
 }
  if(!arg) {
  set_light(0);
  short_desc = "Narrow corridor to entrance to TOMB.";
  long_desc = 
   "   It has taken you some time to advance this far, pray it will\n"+
   "be worth it in the end. Hours have passed since you last saw the light\n"+
   "of the day, darkness has long since crept up on you in these\n"+
   "catacombs along with a dark forboding feeling. You are now at the end \n"+
   "of the tunnel and stand close, so close to the wall that glows ever so\n"+
   "bright. Your curiousity gets the better of you as you want to advance\n"+
   "farther, but for now you look around to find any secret passages or\n"+
   "traps meant for tomb robbers or theives.\n";
  dest_dir = ({"players/azane/cryptwall.c", "north",
               "players/azane/crypt2.c", "south"});
  }
}
