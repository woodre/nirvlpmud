#include "std.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
extra_reset()
{
object doll;
int n,i,class,value,weight;
i = 0;
if(!present("doll")){
while (i<10){
i += 1;
doll = clone_object("obj/monster.talk");
call_other(doll, "set_name", "Tracy Lords inflatable doll");
call_other(doll, "set_alias", "doll");
call_other(doll, "set_race", "The Rubber One's");
call_other(doll, "set_level", random(2) + 1);
call_other(doll, "set_hp", 30);
call_other(doll, "set_ep", 100);
call_other(doll, "set_al", 40);
call_other(doll, "set_short", "Tracy Lords inflatable doll");
call_other(doll, "set_a_chat_chance", 50);
call_other(doll, "laod_a_chat", 
"Tracy says: Please don't puncture me.\n");
call_other(doll, "load_a_chat",
"OOOOOOhhh, I'd like to wrap my lips around you Big Boy.\n");
call_other(doll, "load_a_chat",
"Psssssst, You have punctured poor defenceless Tracy.\n");
call_other(doll, "load_a_chat",
"Tracy says: One step closer and I'll blow you away!\n");
call_other(doll, "load_a_chat",
"OH My! What a BIG weapon you have there.\n");
call_other(doll, "load_a_chat",
"The doll begins to sing: Up Up and away my friends, in my wonderful balloon.\n");
n = random(2);
move_object(doll, this_object());
}
}
}
TWO_EXIT ("players/azane/valldol.c", "north",
          "players/azane/path.c", "south",
" Valley of the Dolls",
"\n"+
"   You are smack, dead, center in 'The Valley of the Dolls', It was\n"+
"created by the Gods of Pun, conceived as a tribute to Deathmonger after\n"+
"he lost The Battle of Insult's with the Wizard Azane. You notice a bead\n"+
"of sweat begin to form on your forehead as the temperature within the\n"+
"valley begins to rise with every passing moment. It would not be healthy\n"+
"to stay for very long.....\n"+
"\n", 1)


