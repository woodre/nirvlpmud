inherit	"room/room";

reset(arg) { 
 if(!present("Boa Constrictor")) {
   move_object(clone_object("players/azane/boa.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Whoa it's not a vine!!";
  long_desc = 
   "   WHOA! It's not a vine, but a boa constrictor.\n"+
   "\n"+
   "   It appears that you have mistaken the Boa for a vine, if you jump \n"+
   "you may be able to safely land on the beach or you can go back up. Your\n"+
   "choice right now.... you can't hang onto the shrubbery much longer!\n";
 dest_dir = ({"players/azane/lvine.c", "climb",
               "players/azane/beach.c", "jump"});
  }
}
