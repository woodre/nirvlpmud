inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Hallway of submarine";
  long_desc = 
"                       Room 4: WEAPONS STORAGE AREA\n"+
"\n"+
   "   You stand in the narrow corridor of the sub with little room for\n"+
   "movement, but enough to walk in. It is barren now with sounds coming\n"+
   "from ahead of you and a low 'snoring' sound to the west, a sign above\n"+
   "the west hatchway tells you that it is the storage area for weapons and\n"+
   "ammunition. Watch yourself,  the floor here is slippery and if you fall\n"+
   "you could alert the captain and crew of your presence.\n";
dest_dir = ({"players/azane/sub5.c","north",
             "players/azane/armory.c","west",
             "players/azane/sub7.c","south"});
  }
}
