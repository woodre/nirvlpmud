inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("Fallen Pillar");
set_alias("pillar");
set_short("Fallen Pillar");
set_long(
"   Fallen and shattered, this pillar once held the massive weight\n"
+ "of this structure but now it lies silent on the floor. It is of carved\n"
+ "marble and other stones that were smoothened over the centuries\n"
+ "by the hands of the monks who rubbed them for good luck.\n");
set_value(10);
set_weight(6);
}
