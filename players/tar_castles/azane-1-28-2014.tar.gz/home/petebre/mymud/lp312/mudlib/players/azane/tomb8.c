#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();

object own;

extra_init() {
   add_action("pay","pay");
   add_action("look","look");
   add_action("enter","enter");
   }
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
  extra_reset() {
     if(!present("keeper")) {
     own=clone_object("obj/monster.c");
       call_other(own,"set_name","keeper");
      call_other(own,"set_alias","temptation's keeper");
       call_other(own,"set_short","Temptation's Keeper");
      call_other(own,"set_long","Keeper of the secret's of Rah Zhan\n");
       call_other(own,"set_ac",19);
       call_other(own,"set_wc",25);
       call_other(own,"set_level",18 + random(2));
       call_other(own,"set_al",-400);
       call_other(own,"set_hp",750 + random(200));
       call_other(own,"set_chat_chance",23);
       call_other(own,"load_chat","Temptation's keeper says: This area is\n" +
"sacred to all, leave before it is too late!\n");
      call_other(own,"load_chat","Keeper whispers to you: Unless you pay\n" +
"me 20000 in coins so I can go to HAWAII.\n");
       move_object(own,this_object());
   }
 }
  TWO_EXIT("players/azane/coffin.c", "enter",
           "players/azane/tomb6.c", "up",

"   You stand amongst the floating pillars of faith.",
"   You have come to the end of a long journey, before you is the keeper\n" +
"of the sacred tomb of Rah Zhan who was in his time one of the greatest\n" +
"necromancers on this continent. His tomb is sealed with the lives of those\n" +
"that helped construct it so that non shall know of it's existance in the\n" +
"kingdoms above. Some even say that within is the answer to the question of life\n" +
"itself. But before you is it's guardian who has stood throughout time\n" +
"watching over it's master so that non shall disturb him until his\n" +
"awakening.\n",1)
 realm(){return "coffin";}
pay(str) {
   if (!own || !living(own)) { return 0; }
   if (!call_other(own, "id", str)) {
      write("A voice BOOMS: NO mortal, within lies a realm beyond yours.\n");
      return 1;
   }
    if (call_other(this_player(), "query_money", 0) < 20000) {
         write("You don't have any money, to pay the keeper with.\n");
         return 1;
     }
   call_other(this_player(),"add_money",-20000);
   write("The hooded figure looks at you and smiles,\n");
   write("his hand out stretches and points a boney finger\n");
   write("towards the entrance.\n");
   write("He says: GO NORTH, BEFORE I CHANGE MY MIND!\n");
add_action("north","north");
call_other(this_player(),"move_player","north#players/azane/coffin.c");
   return 1;
   }
enter() {
if (present("keeper")) {
write("You are not allowed!\n");
return 1;
}
call_other(this_player(),"move_player","north#players/azane/coffin");
 return 1;
 }
look(str) {
 if(str=="at tomb") {
      write("You see before you an immense marble coffin,\n");
      write("however it's keeper seems to block most of your view.\n");
      return 1;
     }
    if(str=="at keeper") {
    write("He is cloaked in black robes and his face covered in\n");
    write("darkness, you can see the outline of his skeleton under\n");
    write("the robes as the light shines though him.\n");
    return 1;
}
return 0;
}
