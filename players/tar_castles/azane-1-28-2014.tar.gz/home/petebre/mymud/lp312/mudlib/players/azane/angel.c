inherit"/obj/monster";

object owner;
string owner_name;
int ear_mode;

reset(arg) {
  if (arg)
    return;
  ::reset();
  set_name("angel");
  set_short("Angel (Azane's friend)");
  set_long("Angel is a tiny, little star - packed with energy.\n"+
	"Picking a fight with it would be the worst move you could make.\n");
  set_level(10);
  set_wc(20);
  set_ac(1000);
  ear_mode = 0;
  owner_name = "azane";
  owner = find_living(owner_name);
  call_out("look_for_owner",10);
}

long(str) {
  ::long(str);
   if (present("azane"))
    write("It's hovering just above and behind Azane's right shoulder.\n");
  else
    write("It was probably sent here by Azane for some reason.\n");
  if ((str == "angel") && (this_player()->query_real_name() == "azane")) {
    write("Commands:\n"+
	"\tsay Angel, go home.\t\tsay Angel, greet <player>.\n"+
	"\tsay Angel, [stay/come].\t\ttell angel [stay/come]\n"+
	"\ttell angel [yes/no/maybe]\t\ttell angel [listen/quiet]\n");
  }
}

greeting(ob) {
  if (present(ob)) {
    say("Angel zooms over to greet "+ob->query_name(),ob);
    if (present("azane"))
	say(" then returns to Azane.\n",ob);
    else
	say(" then resumes its silent hovering.\n",ob);
    tell_object(ob,"Angel flys over to whisper a warm greeting in your ear.\n");
  }
}

catch_tell(str) {
  object ob;
  string answer, extra, who, what;

  if (ear_mode) {
    if (!owner) {
	tell_room(environment(this_object()),
    "Angel vanishes, collapsing in on itself in a blinding flash of light.\n");
	destruct(this_object());
	return 1;
    }
    else
      tell_object(owner, "ANGEL: "+str);
  }

/* Greet new arrivals */

  if (sscanf(str, "%s arrives.", what) == 1) {
    who = lower_case(what);
    ob = find_player(who);
    if (!ob) {
      return;
    } else {
      call_out("greeting",5, ob);
    }
  }

/* Obey tell commands */
  sscanf(str, "Azane tells you: %s\n", what);
  if (what == "no") {
    tell_room(environment(this_object()),
	"Angel flashes wildly in a bright shade of red.\n");
  }
  if (what == "yes") {
    tell_room(environment(this_object()),
	"Angel flashes quickly in a soft, white light.\n");
  }
  if (what == "maybe") {
    tell_room(environment(this_object()), "Angel hovers in the air, silent.\n");
  }
  if (what == "stay") {
    remove_call_out("look_for_owner");
    return 1;
  }
  if (what == "come") {
    remove_call_out("look_for_owner");
    call_out("look_for_owner", 2);
    return 1;
  }
  if (what == "listen") {
    ear_mode = 1;
    tell_object(owner,"Listening mode enabled.\n");
    return 1;
  }
  if (what == "quiet") {
    ear_mode = 0;
    tell_object(owner,"Listening mode disabled.\n");
    return 1;
  }

/* Copy actions and says */
  if (sscanf(str, "Azane %s.\n", what) != 1) return;
  if (what == "left the game") {
    tell_room(environment(this_object()),
    "Angel vanishes, collapsing in on itself in a blinding flash of light.\n");
    destruct(this_object());
  }
  if (what == "says: Angel, go home") {
    tell_room(environment(this_object()),
	"Angel vanishes in a dazzling burst of energy.\n");
    move_object(this_object(),"/players/azane/workroom");
    remove_call_out("look_for_owner");
    call_out("look_for_owner",3600);
    return 1;
  }
  if (what == "says: Angel, stay") {
    tell_room(environment(this_object()),
	"Angel flashes quickly in a soft, white light.\n");
    remove_call_out("look_for_owner");
    return 1;
  }
  if (what == "says: Angel, come") {
    tell_room(environment(this_object()),
	"Angel flashes quickly in a soft, white light.\n");
    call_out("look_for_owner",2);
    return 1;
  }
  if (sscanf(what, "says: Angel, greet %s", who) == 1) {
    who = lower_case(who);
    ob = find_player(who);
    if (!ob) {
      tell_room(environment(this_object()),
	"Angel zips about the room, looking for "+capitalize(who)+".\n");
      return;
    } else {
      call_out("greeting",2, ob);
    }
  }
  if (what == "smiles happily" || what == "falls down laughing" ||
	what == "giggles inanely" || what == "snickers" ||
	what == "chuckles politely") {
    tell_room(environment(this_object()),
	"Angel dances happily around Azane.\n");
  }
  if (what == "grins evilly" || what == "growls") {
    tell_room(environment(this_object()),
	"Angel zips around, looking very aggressive.\n");
  }
  if (what == "frowns" || what == "sighs deeply") {
    tell_room(environment(this_object()),
	"Angel hovers slightly closer to Azane.\n");
  }
  if (what == "starts to think very deeply") {
    tell_room(environment(this_object()),
	"Angel begins to hum.\n");
  }
}

look_for_owner() {
  object ob;

  ob = find_living(owner_name);
  if (!ob) {
    tell_room(environment(),"Angel vanishes in a tiny burst of energy.\n");
    move_object(this_object(),"/players/azane/workroom");
    call_out("look_for_owner",60);
    return;
  }
  if (!present(ob,environment())) {
    tell_room(environment(),"Angel vanishes in a tiny burst of energy.\n");
    tell_room(environment(ob),"Angel bursts into existance!\n");
    move_object(this_object(), environment(ob));
  }
  ob = find_living("harry");
  if (ob) {
    if (present(ob, environment())) {
      tell_room(environment(),"Angel hates Harry to pieces!\n"+
	"A burst of energy erupts from Angel.  Harry is totally destroyed.\n");
      destruct(ob);
    }
  }
  ob = find_living("idiot");
  if (ob) {
    if (present(ob, environment())) {
      tell_room(environment(),"Angel hates the Idiot even more than Harry!\n"+
	"A burst of energy erupts from Angel.  Idiot is totally destroyed.\n");
      destruct(ob);
    }
  }
  call_out("look_for_owner",2);
}

