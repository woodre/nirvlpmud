inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Sword of Skelos");
set_alias("sword");
set_short("Sword of Skelos");
set_long(
"  This was once the sword of a mighty magician who used the sword in\n"
+ "sacrificial offerings, you can still see the crimson stains upon it's\n"
+ "blade. As you look closer you notice intricate carvings of the sword \n"
+ "hovering over a female figure on an alter. Although the sword is incredibly\n"
+ "light, it is also very powerful in the right hands. The hilt is adorned with\n"
+ "emeralds and other precious jewels making it also very valuable to some.....\n"
+ "\n"
+ "But to WHOM?\n"
+ "\n");
set_value(12750);
set_weight(2);
set_class(18);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100) < 75) {
write("The blade lunge's at your enemies heart.\n");
say("The Earth begins to tremble as the sword is wielded....\n");
return 7;
   }
return 0;
 }
