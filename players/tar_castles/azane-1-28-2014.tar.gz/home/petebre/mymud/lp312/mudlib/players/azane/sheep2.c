
inherit"obj/monster";
reset(arg) {
object money;
object weapon;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(4);
a_chat_str = allocate(1);
chat_str[0] = "    Yah O.P.P.,\n";
chat_str[1] = "you know me.\n";
chat_str[2] = "Yah O.P.P.,\n";
chat_str[3] = "you know me.\n";
a_chat_str[0] = "Geez, why you trying to kill me????\n";
  }
set_name("Naughty by Nature");
set_alias("naughty by nature");
set_short("Naughty by Nature");
set_long(
"   This is another member of the group BLACK SHEEP. He looks even\n"
+ "meaner than the other guy, so watch yourself.\n"
+ "   He's dressed like the other guy, and has sunglass's on to\n"
+ "block out the sight of someone who's even uglier than he is.\n");
set_level(13);
set_race("human");
set_hp(200);
set_wc(9);
set_ac(9);
set_aggressive(1);
set_spell_mess2("Hey! Where's the train?");
load_chat(100,chat_str);
load_a_chat(100,a_chat_str);
set_random_pick(40);
money = clone_object("obj/money");
money->set_money(100);
move_object(money, this_object());
weapon = clone_object("/players/azane/chain.c");
if(weapon) {
move_object(weapon,this_object());
command("wield "+weapon->query_name());
   }
}
