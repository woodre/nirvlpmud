inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "LULU'S sandy resort.";
  long_desc = 
   "   You stand on the Island's beach, quietness reigns here as eyes\n"+
   "pierce the darkness of the trees looking towards you. Leaves shuffle\n"+
   "and twigs snap under trodden feet, the sounds increase as they begin to\n"+
   "sound nearer to you. You should decide quick as to your next move.\n";
  dest_dir = ({"players/azane/islandbeach2.c", "east",
               "players/azane/dive3.c", "sea"});
  }
}
