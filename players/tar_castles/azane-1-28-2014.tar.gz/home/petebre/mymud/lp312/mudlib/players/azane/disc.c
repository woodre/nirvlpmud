inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("disc");
set_alias("disc");
set_short("Transparent Disc");
set_long(
"   A transparent disc when over the water, but when you stand upon\n"+
"it you can see colours swirl about under it. It was obviously left\n"+
"here for a purpose or a reason.\n"+
"\n"+
"STICKER: Property of BOND, JAME'S BOND.\n"+
"         Return if found, if not will self-destruct in 5 seconds.\n");
set_value(500);
set_weight(9);
}
