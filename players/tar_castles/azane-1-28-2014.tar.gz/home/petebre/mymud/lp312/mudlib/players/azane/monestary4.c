

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "Hidden entrance to Crypt.";
    no_castle_flag = 0;
    long_desc = 
        "   You have successfully moved the pillar with all of the strength\n"
        + "within yourself, you collapse in exhaustion and decide to rest defore\n"
        + "you continue on. As you rest the hidden door is hit by a falling peice\n"
        + "of stone and breaks into a thousand pieces into a cavern below the floor.\n"
        + "As you gaze into the opening you realize that you may need a torch, to \n"
        + "the north is a small worship area with candles strewn about(hhhmmmm).\n"
        + "You look about you and notice strange reflections on the second floor\n"
        + "alcoves in each corner of the room and wonder if it is just a reflection\n"
        + "of the sun hitting broken glass?\n";
    dest_dir = 
        ({
        "players/azane/temptation.c", "descend",
        "players/azane/alcove.c", "north",
        "players/azane/mone2.c", "northeast",
        "players/azane/mone1.c", "northwest",
        "players/azane/mone4.c", "southeast",
        "players/azane/mone3.c", "southwest",
        "players/azane/monestary2.c", "south",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

