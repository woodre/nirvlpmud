reset(arg)
{
    if (!arg)
	set_light(1);
    extra_reset();
}

extra_reset()
{
    object guardian, weapon;
    int n,i,class,value,weight;
    string w_name,alt_name;

    i = 0;
    if (!present("guardian")) {
        while(i<2) {
	    i += 1;
      guardian = clone_object("obj/monster.talk");
call_other(guardian, "set_name", "Member of the Red Lion Brotherhood");
            call_other(guardian, "set_alias", "guardian");
            call_other(guardian, "set_race", "human");
call_other(guardian,"set_level", 5);
call_other(guardian,"set_hp",70);
            call_other(guardian, "set_al", -100);
call_other(guardian,"set_ep",200);
            call_other(guardian, "set_short", "Guardian");
            call_other(guardian, "set_ac", 5 + random(5));
            call_other(guardian, "set_aggressive", 0);
call_other(guardian,"set_a_chat_chance",30);
            call_other(guardian, "load_a_chat",
"You MUST defeat us both to enter the archway.\n");
            call_other(guardian, "load_a_chat",
"Today is a good day to die my friend...\n");
            call_other(guardian, "load_a_chat",
"The Archway is only for those of Pure mind and soul.\n");
	    weapon = clone_object("obj/weapon");
            n = random(3);
	    if (n == 0) {
                w_name = "Ceremonial Sword";
                class = 10;
                value = 500;
		weight = 1;
                alt_name = "sword";
	    }
	    if (n == 1) {
                w_name = "Sword of Time";
                class = 11;
                alt_name = "sword";
                value = 600;
		weight = 1;
	    }
	    if (n == 2) {
                w_name = "Sword of Space";
                class = 13;
                value = 800;
		weight = 2;
                alt_name = "sword";
	    }
	    call_other(weapon, "set_name", w_name);
	    call_other(weapon, "set_class", class);
	    call_other(weapon, "set_value", value);
	    call_other(weapon, "set_weight", weight);
	    call_other(weapon, "set_alt_name", alt_name);
            transfer(weapon, guardian);
            call_other(guardian, "init_command", "wield "+w_name);
            move_object(guardian, this_object());
	}
    }
}
init()
{
    add_action("south"); add_verb("south");
    add_action("north"); add_verb("north");
}

south()
{
if (present("guardian")) {
       write("You are not worthy of the Brotherhood yet!\n");
       write("To enter the Arch, you must defeat both of us.\n");
	return 1;
    }
    call_other(this_player(), "move_player", "south#players/azane/valldol");
    return 1;
}

north()
{
    call_other(this_player(),"move_player", "north#players/azane/entrance");
    return 1;
}

long()
{
write("   This is the entrance to The Archway of Dreams, it is guarded\n"+
"by two 'pirates' of the Red Lion Brotherhood, to enter you must first\n"+
"defeat them in mortal combat to be worthy enough to enter. The Archway\n"+
"was created by the Wizard Azane, it encompasses the very existence of\n"+
"TIME and SPACE. The Archway is composed from the mists of time and leads\n"+
"you into a world of beauty and danger, so be CAREFULL if you should \n"+
"wish to enter. It is called the Archway of Dreams to many, for it changes\n"+
"reality into fantasy, time is but a mere thought as you go through it as\n"+
"your imagination takes control. REMEMBER this rhyme......\n"+
"  What you think isn't, what is not there may be.\n"+
"  What might seem useless, is not you'll see.\n"+
"  So don't take for granted all that is around,\n"+
"  many wonders can still be found.\n"+
"\n"+
"The ARCHWAY OF DREAMS\n");
}

short() {
    return "THE ARCHWAY OF DREAMS";
}
