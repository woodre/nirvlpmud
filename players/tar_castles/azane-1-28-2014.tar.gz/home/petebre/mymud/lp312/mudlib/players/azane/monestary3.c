inherit	"room/room";

reset(arg) { 
 if(!present("Fallen Pillar")) {
move_object(clone_object("players/azane/pillar.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Center of the monestary .";
  long_desc = 
   "   You stand in the Sanctuary of the monestary, things have been quiet\n"+
   "here since the last earthquake shook it's very foundation and the monks\n"+
   "moved to a safer area. You stand alone in silence as you survey the \n"+
   "ancient building, looking for anything that may be of use or value to \n"+
   "you. It is almost noon here and the suns rays shine through the stain\n"+
   "glass, as your eyes follow it's rays you notice a pattern begin to emerge\n"+
   "on the floor as the rays begin to connect in a pattern. You now concentrate\n"+
   "your gaze towards the center of the hall and onto a fallen pillar that\n"+
   "once held up the massive weight of the second floor which now lies in ruins.\n"+
   "   In each corner of the Great Hall, there is a set of stairs that lead\n"+
   "to a small area where the monks went to concentrate and pray in solitude.\n"+
   "As the sun reaches it's zenith, the pattern emerge's as a multi-colored\n"+
   "circle with a strange symbol within its boundary. At it's zenith, the sun\n"+
   "has triggered a hidden mechanism and thus releasing a hidden doorway that\n"+
   "lies beneath the pillar. Maybe if your strength and determination are\n"+
   "great you can 'move' the pillar and go into the cavern.\n";
  }
}
init()
{
add_action("south"); add_verb("south");
add_action("move"); add_verb("move");
}
south()
{
call_other(this_player(), "move_player", "south#players/azane/monestary2.c");
return 1;
}
move()
{
call_other(this_player(), "move_player", "move#players/azane/monestary4.c");
return 1;
}
