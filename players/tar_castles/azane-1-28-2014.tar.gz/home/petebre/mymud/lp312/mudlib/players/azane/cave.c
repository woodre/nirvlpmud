object newspaper,top_list,imp;

reset(arg) {
    if (!top_list || !present(top_list)) {
	top_list = clone_object("obj/level_list");
	move_object(top_list, this_object());
    }
    if (!newspaper || !present(newspaper)) {
	newspaper = clone_object("obj/newspaper");
	move_object(newspaper, this_object());
    }
    if (arg) return;
    set_light( 1);
}

short() {
    return "The AMAZON CAFE";
}

init() {
    add_action("move");
    add_verb("south");
    add_action("order");
    add_verb("order");
    add_action("order");
    add_verb("buy");
}

move() {
    object ob;

  if(present("dice",this_player())) {
write("The Witch Doctor looks at you and says: I like dice, leave 'em.\n");
     write("Witch doctor chants and stops you from going.\n");
    return 1;
}
  call_other(this_player(),"move_player","south"+"#"+"players/azane/cave2");
    return 1;
}

long() {
write("  You stand admist shrunken heads, potions and animals hung against\n");
write("the cave walls. An eerie cackle bounce's off the walls and rings in\n");
write("your head as you notice the scrawny figure of a witch doctor emerge\n");
write("from a room that you had not noticed there before, he grins as he  \n");
write("looks at you and a tooth of his falls to the ground. He bends over \n");
write("and replaces it back inside of his mouth and smiles a hideous smile\n");
write("at you. A finger points toward the wall where a list of items hangs\n");
write("from a boney hand attached to the east wall.\n\n");
write("*******************************************************************\n");
    write("     Weak potion          :  10 coins\n");
    write("     Jungle water         :  20 coins\n");
    write("     Doctor's special     : 150 coins\n");
    write("Shrunken head potion (SH) : 230 coins\n");
    write("IMP....tells SC & HP      : FREE but still type 'bye imp'\n");
write("*******************************************************************\n");
    write("\n");
    write("Your only way out is to the SOUTH.\n");
}

order(str)
{
    string name, short_desc, mess;
    int value, cost, strength, heal;

    if (!str) {
       write("What you want here?\n");
       return 1;
    }
if (str == "potion" || str == "weak") {
	mess = "That feels good";
	heal = 1;
        value = 10;
	strength = 3;
    }
    else if (str == "special" || str == "doctor's special") {
        mess = "Your body goes numb and you eye's feel like they are boiling";
        heal = 15;
        value = 150;
        strength = 7;
    } else if (str == "shrunken head" || str == "sh") {
        mess = "You swallow it and scream as your throat burns in pain";
	heal = 24;
        value = 230;
        strength = 14;
    } else if (str == "water" || str == "jungle water") {
        mess = "You feel somewhat......SICK as you bend over and hurl.";
	heal = 0;
	value = 20;
	strength = -2;
    } else if (str == "imp") {
      mess = "Welcome to the BROTHERHOOD!";
      imp = clone_object("players/azane/imp.c");
move_object(imp,this_player());
return 1;
      value = 5000;
    } else {
  write("Witch doctor looks puzzled as he dosn't know what you want.\n");
       return 1;
    }
    if (call_other(this_player(), "query_money", 0) < value) {
        write("That costs " + value + " gold coins, which you don't have.\n");
	return 1;
    }
    cost = value;
    if (strength > (call_other(this_player(), "query_level") + 2)) {
	if (strength > (call_other(this_player(), "query_level") + 5)) {
	    /* This drink is *much* too strong for the player */
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and immediately throws it up.\n");
	    write("You order a " + str + ", try to drink it, and throw up.\n");
	} else {
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and spews it all over you!\n");
	    write("You order a " + str + ", try to drink it, and sputter it all over the room!\n");
	}
	call_other(this_player(), "add_money", - cost);
	return 1;
    }
    if (!call_other(this_player(), "drink_alcohol", strength)) {
write("The Witch Doctor says: I give you no more mon, leave now!\n");
	say(call_other(this_player(), "query_name", 0) + " asks for a " +
                str + " but the witch doctor laughs.\n");

	return 1;
    }
    write("You pay " + cost + " coins for a " + str + ".\n");
    say(call_other(this_player(), "query_name", 0) + " orders a " + str + ".\n");
    call_other(this_player(), "add_money", - cost);
    call_other(this_player(), "heal_self", heal);
    write(mess + ".\n");
    return 1;
}
