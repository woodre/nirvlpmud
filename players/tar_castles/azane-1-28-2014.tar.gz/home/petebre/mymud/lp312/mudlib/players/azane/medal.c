inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("Medallion of Hope");
set_alias("medallion");
set_short("Medallion of Hope");
set_long(
"    A Medallion of Hope used in prairs by the monks, it is\n"
+ "made of soft gold and is the only possession allowed by the Father\n"
+ "for the monks to own.\n");
set_value(100);
set_weight(1);
}
