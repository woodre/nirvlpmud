inherit "/obj/weapon.c";
reset (arg){
object sword;
set_name("Demon's sword");
set_alias ("sword");
set_short ("Demon's sword of Justice");
set_long (
    "This sword is from ancient times when the Gods alone walked the Earth.\n"
+"It was forged from molten metal not of this world, and has been lost\n"
+"for centuries..........\n"
+"\n"
+"UNTIL NOW.........");
set_class (24);
set_weight (3);
set_value (1000);
}
