inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("waist rope");
set_alias("rope");
set_short("rope on a robe");
set_long(
"   It is the rope tied around the wiast of the monk to hold together\n"
+ "his robe. Occasionally he uses it to defend himself because it is\n"
+ "very thick.\n");
set_value(10);
set_weight(1);
set_class(4);
}
