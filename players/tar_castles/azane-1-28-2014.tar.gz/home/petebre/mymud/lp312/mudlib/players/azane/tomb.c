

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "Hidden entrance to tomb.";
    no_castle_flag = 0;
    long_desc = 
        "   As you start going northwest, you accidentally step on a loose brick\n"
        + "that moves under your weight. You have tripped a mechanism and you feel\n"
        + "the walls move all around you, you try to jump out of the way but to no\n"
        + "avail and you are closed in on all sides. The floor gives way under your \n"
        + "feet and you slide downward into the darkness, when you finally wake up\n"
        + "you are in a small room with no obvious way out. You look around \n"
        + "yourself and realize that this must have been some secret entrance used\n"
        + "by the priests when this tomb was built. The only noticable thing in \n"
        + "the room is a bronze mask of a face on the wall, you try to take this but \n"
 + "it is secured tightly to the wall. The air seems to be thinning out more\n"
        + "rapidly as you now are gulping for each breath, you put your hand against\n"
        + "the mask and feel it move inward. Maybe if you 'push' the mask in you\n"
        + "will be released before the air is no more.\n";
    dest_dir = 
        ({
        "players/azane/tomb8.c", "push",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

