inherit	"room/room";

reset(arg) { 
 if(!present("Marble Pillar")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Pillars of Tomb.";
  long_desc = 
   "   You are barely able to hold onto the pillar as you have jumped\n"+
   "and missed landing on top of it, below you, you can hear voices going\n"+
   ".....aaahhhhhh. \n"+
   "\n"+
   "   Flames leap up from below as the demons try to grab ahold of your \n"+
   "legs and drag you down to them, you are lucky this time.\n";
  dest_dir = ({"players/azane/tomb7.c", "east",
               "players/azane/tomb5.c", "southwest"});
  }
}
