inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "God don't you wish you had a boat.";
  long_desc = 
   "  You are far out to sea\n"+
   "  You are far out to sea as the god Neptune watch's you from his kingdom\n"+
   "below, Mermaids tug at your clothing inviting you to come with them to\n"+
   "a magical place of peaceful solitude. Your arms tire easily as your mind\n"+
   "battle's with your consciousness to stay awake and not go under to a \n"+
   "watery grave, voice's echo in your ears and playfully whisper taunts at\n"+
   "you.\n";
  dest_dir = ({"players/azane/swim3.c", "breaststroke",
               "players/azane/swim1.c", "backstroke"});
  }
}
