inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "A path leading along walls of ancient stone.";
  long_desc = 
   "    You stand between two towering walls of ancient black stones, they\n"+
   "are of polished black onyx that seem to absorb and pulsate with energy\n"+
   "from whom ever may pass within thier walls. Your mind feels like it is\n"+
   "being drained as your memory fades with every second. Towards the south\n"+
   "you can make out an archway and something that seems to be guarding it.\n"+
"\n"+
   "    Someone tells you......... Venture forth O' Warrior, for fear is your\n"+
"greatest foe, defeat this enemy and thou wilt truly be worthy of the rich's\n"+
"to come.\n";
dest_dir = ({"room/forest11.c","north",
               "players/azane/archway.c", "south"});
  }
}
