inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(0);
  short_desc = "  Dive Tower";
  long_desc = 
   "   Holding onto the metal rungs you notice a faint glow of light below\n"+
   "you and the multi-colored disc above your head. Voices echo up from\n"+
   "below you and shadows float around in a hurried manor, the speech used \n"+
   "is like nothing you have heard before.......\n";
  dest_dir = ({"players/azane/dive1.c", "out",
               "players/azane/sub2.c", "down"});
  }
}
