inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Torpedo room";
  long_desc = 
   "                        ROOM 5: TORPEDO ROOM\n"+
   "\n"+
   "    The torpedo hatch's are empty and left open since the training \n"+
   "mission has not started as yet, sounds echo on the metal walls with each \n"+
   "step and ring out in all directions. You survey the room and see nothing\n"+
"of interest here, the hatchway leads into 'room 4' and a set of rungs goes\n"+
   "up.\n";
dest_dir = ({"players/azane/sub8.c","up",
             "players/azane/sub6.c","north"});
}
}
