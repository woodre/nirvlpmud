inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "WIPE OUT............HA HA HA HA HA";
  long_desc = 
   "   Under you go again and again, a voice echo's in your head..........\n"+
   "........................................................................\n"+
   "WIZARD SAYS: Dorthy, click your heels together 3 times and wish.\n"+
   "\n"+
"   OOOOPS.....Wizard of OZ apologizes to you as he realizes that you are\n"+
"not Dorthy and that he is in the wrong area of Nirvana, 'POOF' he disappears.\n";
  dest_dir = ({"players/azane/cave.c", "swim"});
  }
}
