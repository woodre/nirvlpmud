inherit	"room/room";

reset(arg) { 
 if(!present("sign")) {
   move_object(clone_object("players/azane/sign2.c"), this_object());
 }
 if(!present("Female goddess")) {
   move_object(clone_object("players/azane/nymph.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Beach, envy of Malibu.";
  long_desc = 
   "   You seem to be a daring person to go into the 'nude beach' area, \n"+
   "just hope no one spots you wearing clothing. \n"+
   "\n"+
   " ' YOUR EYES HAVE SEEN THE HEAVENLY BODIES OF THE TANNED GODDESS'S '\n"+
   "\n"+
   "Go, Go and revel in those earthly delights, let wild abandon set\n"+
   "in and frolic among the Gods and Goddess's in their area of the\n"+
   "beach, drink the nectar of the island fruits.\n";
  dest_dir = ({"players/azane/beach5.c", "north",
               "players/azane/beach2.c", "south"});
  }
}
