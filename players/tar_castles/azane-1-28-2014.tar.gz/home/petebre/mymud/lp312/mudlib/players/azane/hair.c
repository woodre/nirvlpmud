inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Hair of Slyph");
set_alias("hair");
set_short("Hair of Slyph");
set_long(
"   These are the long tresses of hair from a woodland nymph, in your\n"
+ "hand they become like a whip, they engulf your victim within it's\n"
+ "strands like a web, strangling the life from your victim.\n");
set_value(200);
set_weight(1);
set_class(6);
set_hit_func(this_object());
}
weapon_hit(attacker) {
if(random(100) < 15) {
write("The long tresses of hair strangle the"+attacker->query_name()+".\n");
say(""+this_player()->query_name()+" is engulfed within the hair and let's out a scream..\n");
return 6;
   }
return 0;
 }
