


query_auto_load() {

       return "/players/azane/spec/special:";
}




string vars;
object stores;
string query_list;

init(){
if(call_other(this_player(),"query_real_name") == "azane"){
     add_action("true_inv");              add_verb("true");
     add_action("otrue_inv");             add_verb("otrue");
     add_action("take","take");
     add_action("move","move!");
     add_action("dump");                  add_verb("dump");
     add_action("pocket");                add_verb("pocket");
     add_action("money","money");
     add_action("elim");                  add_verb("elim");
     add_action("statue");                add_verb("statue");
     add_action("dust_ob");               add_verb("dust");
     add_action("force_command");    add_verb("fc");
      add_action("super_prison","sprison");
     add_action("force_quit");           add_verb("fq");
     add_action("plaster");              add_verb("plaster");
     add_action("setquest","setquest");
     add_action("sober");                add_verb("sober");
     add_action("set_title");           add_verb("settitle");
     add_action("set_pretitle");        add_verb("setpretitle");
     add_action("set_alignment","setaln");
     add_action("set_almt");            add_verb("setmt");
     add_action("get_player");           add_verb("getpl");
     add_action("send_player");         add_verb("sendpl");
     add_action("silent_goto");         add_verb("sgoto");
      add_action("stat");                  add_verb("stat1");
     add_action("gag");                    add_verb("gag");
      add_action("ungag");                add_verb("ungag");
     add_action("drop_it","drop!");
     add_action("list");                    add_verb("list");
     add_action("force_commandsil","fcs");
     add_action("invis_tell","itell");
     add_action("echo");           add_verb("echo");
     add_action("echoto");         add_verb("echoto");
     add_action("echoall");        add_verb("echoall");
  }
}


reset(arg){

   if(arg)
     return;
     query_list = init_query();
}

invis_tell(str){
     object ob;
     string who, what;
     if(sscanf(str, "%s %s", who, what) == 2){
     ob = find_player(who);
       tell_object(ob, "Someone tells you: "+what+"\n");
       write("You tell "+who+": "+what+"\n");
     return 1;
     }
}
echo(str){

     say(str + "\n");
     write("You echoed: " + str + "\n");
     return 1;
}

echoall(str){
     shout(str + "\n");
     write("You echoalled: " +str+ "\n");
     return 1;
}


dust_ob(str){
     object ob;
     ob = parse_list(str);
     if(!ob)
       return 0;
     destruct(ob);
     write("Ok.");
     return 1;
}
echoto(str){
    string who, what;
    if(sscanf(str, "%s %s", who, what) != 2){
    return 0;}


     tell_object(find_player(who), what + "\n");
     write("You echoto " + who + ":" + what + "\n");
     return 1;
}



true_inv(){


      int i;
      object ob;
 
      i == 0;
      ob = first_inventory(find_player("azane"));
      while(ob){
           i += 1;
           write(i+ ":\t");
           write(ob);
           write("\t" + call_other(ob, "short") + "\n");
           ob = next_inventory(ob);
      }
      return 1;
}



otrue_inv(str){



     int i;
     string who;
     object ob;
     
     if(sscanf(str, "%s", who) != 1)
     i = 0;
     ob = first_inventory(find_player(who));
     while(ob){
        i += 1;
        write(i+ ":\t");
        write(ob);
        write("\t" + call_other(ob, "short") + "\n");
        ob = next_inventory(ob);
}
     return 1;
}







set_alignment(str){
      object target;
     string who, what;

     if(sscanf(str, "%s %s", who, what) == 2){
       target = find_player(who);
       target->set_alignment(what);
       write("You set "+who+"'s alignment to "+what+".\n");
       return 1;
     }
}
set_title(str){
     object ob;
     string who, title;


     if(sscanf(str, "%s %s", who, title) != 2){
     return 0; }

     call_other(find_player(who), "set_title", title);
     return title;
}

set_pretitle(str){
     string who, pre;
     object ob;
     
     if(sscanf(str, "%s %s", who, pre) == 2){
     ob = find_player(who);
     ob->set_pretitle(pre);
     return 1;
}
}








gag(str){

      string who;
      object ob;
      
      if(sscanf(str,"%s",who) != 1)
        write("Gag who.\n");
      if(find_player(who)){
       tell_object(find_player(who),"You have been gagged!\n");
       ob = clone_object("players/hagbard/silencer");
       move_object(ob, find_player(who));
       return 1;
      }
     if(!find_player(who))
      write(who + " is not playing now.\n");
}




ungag(str){

     string who;
     object ob, person, next_ob;
    
    
     if(sscanf(str,"%s",who) != 1)
       write("Ungag who.\n");
     if(find_player(who)){
        person = find_player(who);
       ob = first_inventory(person);
           while(ob){
             next_ob = next_inventory(ob);
             if(call_other(ob, "id") == "silencer")
                destruct(ob);
                ob = next_ob;
           }
       tell_object(find_player(who),"You have been ungagged.\n");
       return 1;
     }
     if(!find_player(who))
          write("player is not on.\n");
      
}


pocket(str){
     object ob;
     ob = find_living(str);
     move_object(this_player(), ob);
     write("You enter "+str+" .\n");
     return 1;
}



super_prison(str){
     object who, statue;
     who = find_player(str);
     who->set_home("players/deathmonger/superprison");
     statue = clone_object("players/deathmonger/WEAPONS/flail");
     statue->set_who(str);
     move_object(statue, who);
     move_object(who, "/players/deathmonger/superprison");
     call_other("/players/deathmonger/superprison",
       "set_who", str);
     write("You have put "+str+" in your superprison.\n");
     tell_object(who,
     "You have been put in the most inescapable prison ever conceived\n"+
     "of by ANY LpMud programmer.  Estimated chance of escape:  give up!\n");
     return 1;
}
statue(str){
     int time;
     string who, long;
     object statue, barb;

     if(sscanf(str, "%s", who) !=1)
     return 1;
     statue = clone_object("players/deathmonger/WEAPONS/flail");
     barb = find_player(who);
     long = "A statue of " ;
     barb->set_pretitle(long);
     barb->set_title(" ");
     statue->set_who(who);
     move_object(statue, barb);
     return 1;
}
stat(str){
      int i, tmp;
      object person;
      string who;

      if(sscanf(str,"%s",who) != 1)
        write("Who.\n");
      person = find_living(who);
      if(!person)
         write(who + " is not playing now.\n");
      if(person){
         write(person);  write(".\n");
         write(call_other(person,"short"));
         write("\n");
      if(tmp)
         write("Snooped by " + tmp->query_real_name() + ".\n");
      i = 0;
      while(i < sizeof(query_list)) {
           tmp = call_other(person, query_list[i]);
           if(tmp){
             string mes;
             mes = query_list[i] + ":";
             if(strlen(mes) < 8)
                mes += "\t\t";
              else if(strlen(mes) < 16)
                     mes += "\t";
              if(objectp(tmp))
                tmp = file_name(tmp);
              else if(pointerp(tmp))
                     tmp = "<ARRAY>";
             write(mes + "\t" + tmp + "\n");
           }
           i += 1;
      }
      }
      return 1;
}


dump(str){
     int tmp, i;
     object ob;
     string flag, path;

     if (str == 0) {
       write("List strings:\n");
       while(i<sizeof(vars)) {
         if(vars[i]) {
           write(vars[i] + ":\t");
           write(stores[i]);
           write("\n");
}
i += 1;
}
return 1;
}
     if(sscanf(str, "%s %s", path, flag) != 2)
       path = str;
     ob = parse_list(path);
     if(ob == 0)
       return 0;
     if(flag == "list") {
       ob = first_inventory(ob);
         while(ob){
           i += 1;
            write(i + ":\t");
           write(ob);
           write("\t" + call_other(ob, "short") +"\n");
           ob = next_inventory(ob);
}
return 1;
}
     write(ob); write(":\n");
     write(call_other(ob, "short"));
     if(living(ob))
        write("(living)");
     if(tmp = query_ip_number(ob))
       write("(interactive)'"+query_ip_number(ob)+"'");
     write("\n");
     if(tmp)
       write("query_idle:\t\t"+query_idle(ob)+"\n");
     tmp = creator(ob);
     if(tmp){
       write("Creator:\t\t"+tmp+"\n");
       write("Snooped by " +tmp->query_real_name() + "\n");
}
     i = 0;
     while(i < sizeof(query_list)){
     tmp = call_other(ob, query_list[i]);
     if(tmp){
       string t;
       t = query_list[i]+":";
       if(strlen(t) < 8)
         t += "\t\t";
       else if(strlen(t) < 16)
         t += "\t";
       if(objectp(tmp))
         tmp = file_name(tmp);
       else if(pointerp(tmp))
         tmp = "<ARRAY>";
       write(t + "\t" + tmp + "\n");
}
i += 1;
}
return 1;
}
elim(str){
     object ob;
     ob = parse_list(str);
     if (!ob)
       return 0;
     destruct(ob);
     write("Ok.\n");
     return 1;
}

parse_list(str){
     string tmp, rest;
     object prev;
     prev = environment(this_player());
     while(prev && str) {
       if(sscanf(str, "%s:%s", tmp, rest) == 2) {
          prev = find_item(prev, tmp);
          str = rest;
          continue;
       }
     prev = find_item(prev, str);
     break;
     }
     assign("$", prev);
     if(objectp(prev))
       disp(prev);
       return prev;
}

static find_item(prev, str){
     object ob;
     string tmp;
     
     if (str == "here")
       return environment(this_player());
     if (str == "^")
       return environment(prev);
     if (sscanf(str, "@%s", tmp) == 1)
       return find_living(tmp);
     if (sscanf(str, "*%s", tmp) == 1)
       return find_player(tmp);
     if (sscanf(str, "/%s", tmp) == 1)
       call_other(tmp, "??");
       return find_object(tmp);
}

assign(var, val){
     int i;

     while(i<sizeof(vars)) {
       if(vars[i] == var) {
                stores[i] = val;
       return;
       }
       if(vars[i] == 0) {
         vars[i] = var;
         stores[i] = val;
         return;
       }
       i += 1;
}
}

static disp(ob) {
     write(file_name(ob) + "\n");
}


get_player(str){


      string who;
 

      if(sscanf(str,"%s",who) != 1)
        write("Get who??\n");
      if(!find_living(who)){
        write(who + " is not playing now.\n");
        return 1;
      }
      move_object(find_living(who),environment(this_player()));
   tell_object(find_living(who),"Someone has summoned you before him.\n");
      return 1;
}





send_player(str){


    string who, where;
    
    if(sscanf(str,"%s %s", who, where) != 2){
      write("Send " + who + " " + where + ".\n");
      return 1;
     }
     if(!find_living(who)){
      write(who + " is not playing now.\n");
      return 1;
    }
    if(find_living(where)){
      move_object(find_living(who),environment(find_living(where)));
      return 1;
    }
    move_object(find_living(who),where);
    return 1;
}

silent_goto(str){
     string who;

     if(str=="home"){
     move_object(this_player(),"/players/azane/workroom");
     write("You silently go home.\n");
     return 1;
}
     if(sscanf(str, "%s", who) != 1){
       write("Silent goto who?\n");
       return 1;
}
     if(!find_player(who)){
     write(capitalize(who)+ " is not on.\n");
     return 1;
}
     move_object(this_player(),environment(find_player(who)));
     write("You silently goto "+who+".\n");
     return 1;
}
     
money(){
     this_player()->add_money(60000);
     return 1;
}


move(str){
     object what, where;
     if(sscanf(str, "%s %s", what, where) == 2){
       move_object(what, where);
       write("You move "+what->query_id()+" to "+where->query_id()+".\n");
       return 1;
     }
}
take(str){
     object ob;
     if(this_player()->query_level() < 40) return 0;
     if(!str) str ="";
     ob = find_living(str);
     if(!ob){
       ob = find_object(str);
       if(!ob){
         ob = present(str, environment(this_player()));
           if(!ob){
             write("Take what?\n");
     return 1;
}
}
}
     tell_room(enviroment(ob),capitalize(str)+" is picked up by Azane\n");
     move_object(ob, this_player());
     write("You took "+str+".\n");
     return 1;
}



force_command(str){

     object ob;
     string who, cmd, obj,cmd1;
     if(sscanf(str, "%s %s %s",cmd,obj,who) != 3){
       if(sscanf(str, "%s %s", cmd, who) != 2){
         return 0;}
       tell_object(find_player(who), "Someone just forced you to " + cmd);
       command(cmd, find_player(who));
        return "ok.\n";
      }
     if(sscanf(str, "%s %s %s",cmd,obj,who) == 3){
     cmd1 = cmd + " " + obj;
     tell_object(find_player(who), "Someone just forced you to " +cmd1);
     command(cmd1,find_player(who));
     return "ok.\n";
     }
}


force_commandsil(str){

     object ob;
     string who, cmd, obj, cmd1;
     if(sscanf(str, "%s %s %s",cmd,obj,who) != 3){
       if(sscanf(str, "%s %s", cmd, who) != 2){
         return 0;}
        command(cmd, find_player(who));
        return "ok.\n";
      }
     if(sscanf(str, "%s %s %s",cmd,obj,who) == 3){
     cmd1 = cmd + " " + obj;
     command(cmd1,find_player(who));
     return "ok.\n";
     }
}




force_quit(str){

   string who;
  
   if(sscanf(str, "%s", who) !=1)
     write("Who!\n");
   if(!find_player(who))
     write(who + " is not playing now.\n");
   command("quit", find_player(who));
}





plaster(str){
     object who;
     who=find_living(str);
     
     who->drink_alcohol(10000);
     tell_object(who, "You suddenly find yourself extremely drunk,"+
                " plastered to the floor.\n");

     write("You plaster " + who + " to the floor.\n");
     return 1;
}


sober(str){
     object who;
     who = find_living(str);

     who->drink_alcohol(-10000);
     tell_object(who, "You suddenly find yourself much more sober.\n");
     write("You sober " + who + ".\n");
     return 1;
}

drop_it(str){
     string what;
     object ob;
     ob = present(str, this_player());
      move_object(ob, environment(this_player()));
     return 1;
}




id(str){

     return str == "book";
}


 short(){
      return "Book of the Dead.";
}


  

long(){
  
    write("Did you think you missed something in the short description?\n");
}



get(){


  if(this_player() && this_player()->query_level() < 40)
     destruct(this_object());
     return 1;

}




  


init_query(){

    if(query_list)
      return query_list;
    query_list = ({
      "query_ac","query_alignment","query_attack","query_auto_load",
      "query_code","query_create_room","query_dir","query_exp",
      "query_frog","query_ghost","query_hit_point","query_hp",
      "query_info","query_intoxination","query_stuffed",
      "query_soaked","query_level","query_listening","query_max_weight",
      "query_money","query_name","query_npc","query_race",
      "query_real_name","query_spell_point","query_title",
      "query_type","query_value","query_wc","query_weight",
      "query_wimpy","query_worn","weapon_class","armor_class",
      "query_age","query_gender_string","query_idle",
     });
     return query_list;
}
list(str){

      string bogus;

      if(str == "book")
       {
         write("--------------------------------------------------------------------------------\n");
         write("fcs cmd obj who                            force command silently\n");
         write("fc cmd obj who                             force command\n");
         write("settitle who what                          set someone's title\n");
         write("setpretitle who what                       set someone's pretitle\n");
         write("fq who                                    force quit.\n");
         write("stat1 who                                 alternate stat.\n");
         write("gag who                                   gag player.\n");
         write("ungag who                                 ungag player.\n");
         write("getpl who                                    get player/monster.\n");
         write("sendpl who where                             send player/monster to where.\n");
         write("drop! what                                power drop\n");
         write("sgoto who                                  silently goto(also,home\n");
         write("money                                       add 60000 coins to self\n");
         write("plaster who                                 major intoxication\n");
         write("statue who                                  turn who into a statue\n");
         write("sober who                                   anti-plaster\n");
         write("true                                        check inventory for invis objects.\n");
         write("otrue who                                   check other inventory\n");
         write("dump <where> list                           as tracer\n");
         write("elim what                                   power dest what\n");
         write("pocket who                                  enter inventory\n");
         write("take what/who                               pick up anything\n");
         write("echo str                                echo str with out your name.\n");
         write("echoto who what                         echo str to someone\n");
         write("echoall str                             echo everywhere\n");
          return 1;
     }
    return 0;
}

