inherit	"room/room";

reset(arg) { 
if(!present("Sheep")) {
   move_object(clone_object("players/azane/sheep1.c"), this_object());
 }
 if(!present("Naughty by Nature")) {
   move_object(clone_object("players/azane/sheep2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "New York Transit line.";
  long_desc = 
   "   You are below the clubhouse where somehow the officials of New York\n"+
   "have built a transit line for the people of this area, not many know\n"+
   "of it's existance or it's location. Which makes it an idea place to hold\n"+
   "gatherings without being bothered by the police, especially for rap\n"+
   "groups trying to break into the music business. It seems you have \n"+
   "literally DROPPED in on a rap session, and their fans are not to estatic\n"+
   "about it since you have landed in on the group 'Black Sheep' and on \n"+
   "top of their drummer, killing him in the process. Oh well, have a nice\n"+
   "day......\n";
  dest_dir = ({"players/azane/club.c", "up"});
  }
}
