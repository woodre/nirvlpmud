inherit	"room/room";

reset(arg) { 
 if(!present("Shark!!")) {
   move_object(clone_object("players/azane/shark.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Where's Gilligans Island when you need it?";
  long_desc = 
   "  As your arms swing to and fro you notice fins appear up out of the\n"+
   "water all around you, some are close by as you feel them touch your skin\n"+
   "and others far off but coming closer. They 'LOOK' like dolphins, maybe \n"+
   "you can catch a ride with them when they are closer to you?\n";
  dest_dir = ({"players/azane/swim2.c", "backstroke",
               "players/azane/swim4.c", "breaststroke"});
  }
}
