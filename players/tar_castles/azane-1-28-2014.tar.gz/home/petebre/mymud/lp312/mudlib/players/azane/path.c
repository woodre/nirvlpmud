

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "Deserted beach";
    no_castle_flag = 0;
    long_desc = 
"   You stand at one of the two entrances to the Valley of Dolls and are now\n"
        + "atop a cliff that looks down upon a deserted beach. It looks very inviting\n"
        + "to you, as you have not rested for a bit. But you see no way of getting down\n"
        + "to the beach right here, so you should venture on further to scout a way\n"
        + "down.\n";
    dest_dir = 
        ({
        "players/azane/path2.c", "south",
        "players/azane/valldol2.c", "north",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

