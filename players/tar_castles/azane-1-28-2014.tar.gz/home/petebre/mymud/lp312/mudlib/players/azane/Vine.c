inherit"obj/treasure";
reset(arg) {
if(arg) return;
set_id("A Vine");
set_alias("vine");
set_short("A Vine");
set_long(
"    It 'appears' to be a very sturdy looking vine that hangs down\n"
+ "from the tree branch directly above you. As you look at it you notice\n"
+ "that it is long enough for you to climb down to the beach on, but be \n"
+ "careful that it dosn't break from your wieght.\n");
set_value(0);
set_weight(6);
}
