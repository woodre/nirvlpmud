inherit	"room/room";

reset(arg) { 
 if(!present("Hovering Disc")) {
   move_object(clone_object("players/azane/disc.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Hovering disc over water";
  long_desc = 
"  You hover over the sand and sea near the Island of the Brotherhood on top a\n"+
   "disc that is transparent when it is over water, you look in astonishment\n"+
"as you notice it hovers above the water not touching it.\n"+
"You stand precariously trying to keep balanced as you decide what to\n"+
   "do, should you 'use the disc' or 'get off' the disc?  As you stand there\n"+
   "trying to decide what to do you look around yourself as you can hear\n"+
   "voices, they are not clear but muffled. As you look down at the disc\n"+
   "it swirls soft tones of colours before your eyes, you bend over and reach\n"+
   "towards the disc with your hand and take a piece of your shirt as you\n"+
   "try and 'clean the disc' to get a better look at it.\n";
  }
}
init(str){
add_action("use");add_verb("use");
add_action("clean");add_verb("clean");
add_action("off");add_verb("off");
}
clean(str)
{
if (str=="the disc"|| str=="disc"||str=="surface");
call_other(this_player(),"move_player","clean#players/azane/sub9.c");
return 1;
}
use(str)
{
if (str=="the disc"||str=="disc");
call_other(this_player(),"move_player","use#players/azane/dive2.c");
return 1;
}
off()
{
call_other(this_player(),"move_player","off#players/azane/islandbeach.c");
return 1;
}
