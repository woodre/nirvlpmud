

#include "std.h"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();
string invader;
string invited;
int alarm;
int secure;
int lock;


extra_init()    {
        if(call_other(this_player(), "query_real_name",0) == "azane") {
		add_action("invite"); add_verb("invite");
		add_action("force"); add_verb("invite!");
		add_action("alarm"); add_verb("alarm");
		add_action("secure"); add_verb("secure");
				add_action("lock", "anchor");
		add_action("ring"); add_verb("ring");
		add_action("visit"); add_verb("visit");
		add_action("stat"); add_verb("ck");
		add_action("dest"); add_verb("dest");
		add_action("dest"); add_verb("destroy");
	}

        invader = call_other(this_player(), "query_real_name");
if(call_other(this_player(), "is_invis") == 1 && this_player() != "azane") {
		call_other(this_player(),"command","vis");
	}
if(secure == 0 && invader != invited && invader != "azane" && invader != "orb") {
		say(invader + " has tried to enter this room, but was deflected\n");
		transfer(this_player(), "room/void");
		return 1;
	}
	if(secure == 1 && alarm == 0) {
		invader = call_other(this_player(), "query_real_name");
		say(invader + " has entered this room\n");
		return 1;
	}
	return 1;
}
exit() {
	if(alarm == 0) {
		invader = call_other(this_player(), "query_real_name");
		say(invader + " has exited this room\n");
		return 1;
	}
		if(lock == 0) {
                        transfer(this_player(),"players/azane/workroom");
			return 1;
		}
	return 1;
}

invite(str) {

	if(!str) {
		invited = "";
		return 1;
	}
	invited = str;
	write(invited + " is invited into the room\n");
	return 1;
}

force(str) {
	object person;

	if(!str) {
		write("You must specify a person to summon\n");
		return 1;
	}
	person = find_living(str);
	if(!person) {
		write(str + " is not playing now.\n");
		return 1;
	}
	invited = str;
	transfer(person,this_object());
        write(str + " has arrived to your summons\n");
	return 1;
}

alarm() {
	if(alarm == 0) {
		alarm = 1;
		write("Alarm off\n");
		return 1;
	}
	alarm = 0;
	write("Alarm on\n");
	return 1;
}

secure() {
	if(secure == 1) {
		secure = 0;
		write("Secure on\n");
		return 1;
	}
	secure = 1;
	write("Secure off\n");
	return 1;
}
lock() {
	if(lock == 1) {
		lock = 0;
		write("The anchor is set\n");
		return 1;
	}
	lock = 1;
	write("The anchor has been pulled in\n");
	return 1;
}

ring() {
	object ring;

	ring = clone_object("players/prischa/special/ring");
	transfer(ring, this_player());
	return 1;
}

visit() {
	call_other(this_player(),"move_player","#players/prischa/special/apriz");
	return 1;
}

dest(str) {
	object fool;
	string foolname;
	
	fool = this_player();
	foolname = call_other(fool, "query_real_name");

	if(foolname == "prischa")
		return 0;
	if(str == "prischa" || str == invited) {
		write("It's not nice to destroy the host or his invited guests!\n");
		destruct(fool);
		say(foolname + " tried to destroy " + str + " but was unsuccessful...\n");
		say("          -=> " + foolname + " has been disintigrated\n");
		return 1;
	}
	return 0;
}

stat(str) {
	if(!str || str != "room")
		return 0;
	if(alarm == 0)
		write("Alarm on\n");
	else
		write("Alarm off\n");
	if(secure == 0)
		write("Room secured\n");
	else
		write("Room open\n");
	if(invited == "" || invited == 0)
		write("Nobody is invited into the room\n");
	else
		write(invited + " is invited into the room\n");
	if(lock == 0)
		write("The anchor is set\n");
	else
		write("No anchor set\n");
	return 1;
}

TWO_EXIT("players/prischa/workroom_attic", "up",
        "players/prischa/grounds/cnc", "out",
	   "Sanctuary",
	   "You are in Prischa's sanctuary; a large circular room overlooking\n" +  
	   "an ocean.  There are bay windows all around the room, and a balcony\n" +
	   "all around the outside.  The sliding doors to the balcony are open,\n" +
	   "and you can hear the crash of the surf and feel the warm ocean breeze.\n" +
	   "In the center of the room is a large circular fireplace with a polished\n" +
            "copper hood, and next to it a white bearskin rug.  What small amount of\n" +
            "wall space that isn't window is covered by bookshelves, and the smell of\n" +
            "the leather bindings compete with the smell of salt for dominion\n", 1)


