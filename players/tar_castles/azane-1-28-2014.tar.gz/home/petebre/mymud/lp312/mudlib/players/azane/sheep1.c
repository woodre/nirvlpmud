
inherit"obj/monster";
reset(arg) {
object money;
object weapon;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(4);
a_chat_str = allocate(2);
chat_str[0] = "Engine, Engine number 9,\n";
chat_str[1] = "Going down the New York transit line.\n";
chat_str[2] = "If the train falls off the track,\n";
chat_str[3] = "PICK IT UP! PICK IT UP! PICK IT UP!\n";
a_chat_str[0] = "   Man, you are one ugly motha!!!\n";
a_chat_str[1] = "   What's up with you Homey?\n";
  }
set_name("Black Sheep");
set_alias("sheep");
set_short("BLACK SHEEP");
set_long(
"   This here is just one of the members of the rap group BLACK SHEEP,\n"
+ "he's tougher than you think so watch yourself. He's dressed in black\n"
+ "with a hood over his head and nike sneakers on his feet.\n");
set_level(12);
set_race("human");
set_hp(200);
set_wc(8);
set_ac(8);
set_aggressive(1);
set_spell_mess2("");
load_chat(100,chat_str);
load_a_chat(100,a_chat_str);
set_random_pick(40);
money = clone_object("obj/money");
money->set_money(50);
move_object(money, this_object());
weapon = clone_object("/players/azane/brassr.c");
if(weapon) {
move_object(weapon,this_object());
command("wield "+weapon->query_name());
   }
}
