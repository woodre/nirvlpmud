inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "A Honalulu night in paris at the Amazon Cafe'";
  long_desc = 
   "   You are caught in a strong current that pulls at you, you swim towards\n"+
   "the shore to no avail as your arms weaken and your beath gets longer. Every\n"+
   "now and then you go under as the current gets stronger as you swim up\n"+
   "the mighty Amazon.\n";
  dest_dir = ({"players/azane/river2.c", "swim"});
  }
}
