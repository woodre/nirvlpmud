
inherit"obj/monster";
reset(arg) {
object money;
object armour;
object weapon;
object treasure;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(2);
a_chat_str = allocate(1);
chat_str[0] = "You must fight me and win to pass.\n";
chat_str[1] = "Only one has won, I now serve him.\n";
a_chat_str[0] = "You fight bravely my friend, If you win my soul is yours.\n";
  }
set_name("Crystal Warrior");
set_alias("warrior");
set_short("Crystal Warrior");
set_long(
"   You gaze upon an entity not of this world, a being made entirely of\n"
+ "crystal and jewels. As the suns rays strike the being, it gives off a \n"
+ "felling of warmth as a rainbow of colours appears, blinding you for an\n"
+ "instance, leaving you vanrable and open. He carries in his hand a sword \n"
+ "made of diamonds and wears emerald armour. You know he will not be an easy\n"
+ "foe...................\n");
set_level(19);
set_whimpy(75);
set_race("Crystaline Entity");
set_hp(523);
set_al(50);
set_wc(20);
set_ac(18);
set_chance(65);
set_spell_dam(10);
set_spell_mess1("You are blinded a ray of light.........");
set_spell_mess2("His strength is uncanny, you weaken.....");
load_chat(100,chat_str);
load_a_chat(100,a_chat_str);
set_random_pick(35);
money = clone_object("obj/money");
money->set_money(1090);
move_object(money, this_object());
armour = clone_object("/players/azane/earmour.c");
if(armour) {
move_object(armour,this_object());
command("wear "+armour->query_name());
  }
weapon = clone_object("/players/azane/dsword.c");
if(weapon) {
move_object(weapon,this_object());
command("wield "+weapon->query_name());
   }
treasure = clone_object("/players/azane/heart.c");
if(treasure) move_object(treasure,this_object());
}
