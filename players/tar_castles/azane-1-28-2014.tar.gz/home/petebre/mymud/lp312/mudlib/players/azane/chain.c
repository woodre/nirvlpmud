inherit"obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("gold chain");
set_alias("chain");
set_short("GOLD chain");
set_long(
"   It's quite a heavy looking 'gold' chain, there is some inscriptions\n"
+ "on it saying....... If found please return to the BRONX, care of\n"
+ "New York Projects.\n"
+ "\n"
+ "You sing: Yeh O.P.P.\n"
+ "          you know me.........\n");
set_value(100);
set_weight(1);
set_class(8);
}
