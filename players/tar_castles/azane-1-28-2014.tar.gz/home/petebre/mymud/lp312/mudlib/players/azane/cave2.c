inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Witch Doctor's cave.";
  long_desc = 
   "    The cave's entrance is covered over in vines and moss, smells\n"+
   "eminate from it of potions and brews to heal one's self and sickly\n"+
   "laughs to freeze a person in their tracks. A path leads away to the\n"+
   "south while the entrance is to the north.\n";
  dest_dir = ({"players/azane/cave1.c", "south",
               "players/azane/cave.c", "north"});
  }
}
