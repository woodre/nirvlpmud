inherit "/obj/stone.c";
