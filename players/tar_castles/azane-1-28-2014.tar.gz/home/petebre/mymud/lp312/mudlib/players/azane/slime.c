
inherit"obj/monster";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Slime");
set_alias("slime");
set_short("Slime");
set_long(
"   A green fungus like slime that covers the walls,\n"
+ "it appears to be attracted to you or something that is \n"
+ "in your possession.\n");
set_level(1);
set_race("Greenus Slimus Fungus");
set_hp(10);
set_al(-40);
set_wc(1);
set_ac(1);
set_aggressive(1);
set_chance(20);
set_spell_dam(10);
set_spell_mess1("Your friend screams in pain as an acidic substance eats them away.");
set_spell_mess2("A burning wave of pain hits you.");
}
