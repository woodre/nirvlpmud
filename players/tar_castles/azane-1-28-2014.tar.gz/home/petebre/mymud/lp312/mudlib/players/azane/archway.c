inherit "room/room";
reset(arg)
{
if(!present("archway")) {
move_object(clone_object("players/azane/arch.c"),this_object());
}
     if (!arg) {
	set_light(1);

short_desc = "Entrance to Archway of Dreams";
long_desc =
"     This is the entrance to the Archway of Dreams. The archway\n"+
"was created by the Wizard Azane, it encompasses the very existence of\n"+
"TIME and SPACE. The Archway is composed from the mists of time and leads\n"+
"you into a world of beauty and danger, so be CAREFULL if you should \n"+
"wish to enter. It is called the Archway of Dreams to many, for it changes\n"+
"reality into fantasy, time is but a mere thought as you go through it as\n"+
"your imagination takes control. REMEMBER this rhyme......\n"+
"  What you think isn't, what is not there may be.\n"+
"  What might seem useless, is not you'll see.\n"+
"  So don't take for granted all that is around,\n"+
"  many wonders can still be found.\n"+
"\n"+
"WARNING: Sometimes more than one archway may be present.\n";
dest_dir =({"players/azane/valldol.c","south",
            "players/azane/entrance.c","north"});
}
}
