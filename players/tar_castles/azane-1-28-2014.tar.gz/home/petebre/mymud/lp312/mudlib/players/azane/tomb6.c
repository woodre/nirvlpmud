inherit	"room/room";

reset(arg) { 
 if(!present("Marble Pillar")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Pillar of Tomb.";
  long_desc = 
   "  As you jump onto this pillar you feel it give way underneath you, \n"+
   "your heart jumps into your throat as you now know that fate has finnally\n"+
   "caught up to you. BUT WAIT, the pillar moves slowly down one level\n"+
   "below the other pillars and you see an entrance way appear before \n"+
   "you now. The laughing has stopped and your ears no longer ring with\n"+
   "their annoyance. You have made good progress now, and are worthy of \n"+
   "what shall behold you in it's eyes.\n"+
   "\n"+
   "REMEMBER, do not let 'Temptation' persuade you.\n";
  dest_dir = ({"players/azane/tomb8.c", "enter",
               "players/azane/tomb2.c", "sw"});
  }
}
