
inherit"obj/monster";
reset(arg) {
object money;
object weapon;
string chat_str;
string a_chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(1);
a_chat_str = allocate(2);
chat_str[0] = "You will die at my hands because of the wizard Azane!!!\n";
a_chat_str[0] = "You will Die!!!\n";
a_chat_str[1] = "I will rip your heart from your body as you watch in pain.\n";
  }
set_name("skeleton");
set_alias("Mr.Bones");
set_short("A skeleton that is undead. His goal is to kill you.");
set_long(
"   As you look at the skeleton you notice a bloody, but beating heart\n"
+ "within his ribcage. An evil grins appears on his face as he looks at\n"
+ "you and a shrill scream peirce's from his jaw. He points a bony finger at\n"
+ "you as he looks you up and down. He paces around you as if to attack but\n"
+ "does not....yet! His orbs start to burn a bright red as his anger at once\n"
+ "being a living thing comes back to him.\n");
set_level(18);
set_race("Undead");
set_hp(450);
set_al(2);
set_wc(24);
set_ac(15);
set_aggressive(1);
set_spell_mess2("");
load_chat(100,chat_str);
load_a_chat(100,a_chat_str);
money = clone_object("obj/money");
money->set_money(80);
move_object(money, this_object());
weapon = clone_object("/players/azane/sword.c");
if(weapon) {
move_object(weapon,this_object());
   }
}
