inherit	"room/room";

reset(arg) { 
 if(!present("Marble Pillar")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Pillar of Tomb";
  long_desc = 
   "  You have jumped atop the next pillar and feel it shake violently\n"+
   "beneath you, you stand as still as you can and balance yourself.\n"+
   "\n"+
   "  Below you the laughing is louder and you can hear singing now also,\n"+
   "voices reach out at you telling you to jump into the darkness and \n"+
   "they will catch you, who is they?\n";
  dest_dir = ({"players/azane/tomb3.c", "sw",
               "players/azane/tomb1.c", "se",
               "players/azane/tomb2.c", "south",
               "players/azane/tomb4.c", "west",
               "players/azane/tomb7.c", "nw",
               "players/azane/tomb9.c", "ne"});
  }
}
