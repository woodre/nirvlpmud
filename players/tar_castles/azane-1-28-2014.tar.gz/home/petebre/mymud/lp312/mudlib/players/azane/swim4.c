inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Closer than you think matey.";
  long_desc = 
   "   Close to the mouth of the amazon river, the currents take hold and\n"+
   "thrash you about the waters. To each side of you are shorelines, but \n"+
   "you also notice that lazy alligators bask in the sun on them as they\n"+
   "slowly open their eyes to peer at you with little interest as their\n"+
   "bellies are full.\n";
  dest_dir = ({"players/azane/river.c", "swim",
               "players/azane/swim3.c", "backstroke"});
  }
}
