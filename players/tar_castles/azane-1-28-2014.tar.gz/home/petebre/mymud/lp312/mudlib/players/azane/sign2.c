inherit"obj/treasure";
reset(arg) {
   if(arg) return;
   set_id("A SIGN");
   set_alias("sign");
   set_short("a sign");
   set_long(
"    To the north is the 'nude beach', access is restricted depending\n"
+ "on player level and abilities( i.e. IF YOU CAN HANDLE THE EXCITEMENT.)\n");
set_value(0);
set_weight(6);
}
