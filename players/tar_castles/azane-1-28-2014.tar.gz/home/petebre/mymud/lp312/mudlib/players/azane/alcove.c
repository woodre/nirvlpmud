inherit	"room/room";

reset(arg) { 
 if(!present("Candle")) {
   move_object(clone_object("players/azane/candle.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Small alcove for praying an making offerings.";
  long_desc = 
   "   It is a small alcove just north of the fallen pillar used by others\n"+
   "who come here to light a candle as an offering of hope and faith to\n"+
   "thier God. Before you is a large rack of candles, some are lit and others have\n"+
   "burnt out long ago. The newer ones that are lit make you wonder if there\n"+
   "are others still here hiding in the wings waiting to leap out at you and\n"+
   "slit your throat for all that you carry.\n";
  dest_dir = ({"players/azane/monestary4.c", "south"});
  }
}
