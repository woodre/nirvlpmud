inherit	"room/room";

reset(arg) { 
 if(!present("Medallion")) {
move_object(clone_object("players/azane/medal.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "  Northwest Alcove";
  long_desc = 
   "  You have swiftly lept up the stairs in eager anticipation of \n"+
   "finding something of value. Before you is a small mat where you can\n"+
   "kneel and pray, this area is covered in cobwebs from years of \n"+
   "disuse but something gleams under the dirt of the floor.\n";
  dest_dir = ({"players/azane/monestary4.c", "down"});
  }
}
