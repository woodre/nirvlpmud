inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Standing in the water.";
  long_desc = 
   "  Ahhhhh......The waves wash against your feet gently as you stand half-\n"+
   "way in the water and on the sand, the water gently brushes against them\n"+
   "in slow motion as you wiggle your feet in the wet sand. As you stand\n"+
   "here you can see out across the sea to an 'Island' shrouded in fog and\n"+
   "mist from waves breaking against the shoreline, you think to yourself \n"+
   "of adventure's yet to be undertaken on this shore and on the Island. Far\n"+
   "off you can here tribal drums beating and screams echo off the water\n"+
   "bouncing in all directions making it hard to determine their origin,\n"+
   "and of birds flying near the Islands volcanoe.\n";
  dest_dir = ({"players/azane/beach2.c", "west",
               "players/azane/swim1.c", "swim",
               "players/azane/dive1.c", "dive"});
  }
}
