inherit	"room/room";

reset(arg) { 
 if(!present("Marble Pillar")) {
   move_object(clone_object("players/azane/pillar2.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Pillar of Tomb.";
  long_desc = 
   "   You have jumped atop another pillar and it too shakes beneath\n"+
   "your weight, you had better decide fast at what to do next or you \n"+
   "may need wings to leave this place.\n"+
   "\n"+
   "     The laughing has gained in level and you cover your ears as\n"+
   "the pain increases, the pillar shakes as you fall to your knee's.\n";
  dest_dir = ({"players/azane/tomb9.c", "west",
               "players/azane/tomb7.c", "east",
               "players/azane/tomb4.c", "south",
               "players/azane/tomb5.c", "southeast"});
  }
}
