inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(0);
  short_desc = " Hatch leading into the Nuclear Submarine";
  long_desc = 
   "   Hatch leading into the belly of the sub, below you is a faint glow\n"+
   "of light and whispering voice's.\n";
  dest_dir = ({"players/azane/dive3.c", "out",
               "players/azane/sub8.c", "down"});
  }
}
