inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Restricted area";
  long_desc = 
   "   OOPS.............. It seems that the clanking of your weapon and\n"+
   "armorment have attracted the attention of everyone on the beach. Well,\n"+
   "you were warned about coming into this area with clothing on and there\n"+
   "was a sign posted to warn people. The sun bather's look at you and\n"+
   "chuckle at the sight of such a person that would actually want to wear\n"+
   "clothing on such a HOT and BEAUTIFUL day such as this.\n"+
   "\n"+
   "Beach Patrol says: Sorry, we'll have to escort you off this area.\n"+
"\n"+
"You now stand atop a cliff as the beach patrol waits for you to jump.\n";
  dest_dir = ({"room/sea.c", "jump"});
  }
}
