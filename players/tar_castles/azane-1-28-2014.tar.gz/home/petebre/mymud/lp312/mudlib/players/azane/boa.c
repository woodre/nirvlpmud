
inherit"obj/monster";
reset(arg) {
string chat_str;
::reset(arg);
if(arg) return;
if(!chat_str) {
chat_str = allocate(1);
chat_str[0] = "SSSSSSSSSS.......Lunch!\n";
  }
set_name("Boa Constrictor");
set_alias("boa");
set_short("Boa Constrictor");
set_long(
"    It is a very angry looking Boa, it appears that it dislike's being\n"
+ "mistaken for a vine. If I was you I would gently climb off it or pray\n"
+ "to your gods for help.\n");
set_level(6);
set_race("snake");
set_hp(100);
set_al(-60);
set_ac(8);
set_aggressive(1);
set_spell_mess2("Let me wrap myself around you and help you to the ground.");
load_chat(75,chat_str);
}
