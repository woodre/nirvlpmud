inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Tip toe through the sea shells.";
  long_desc = 
   "   Standing knee deep in the water you look sort of silly with floater's\n"+
   "on your arms, you must realize you cannot drown while standing up. Fish\n"+
   "swim about your feet playfully, probably thanking God that they have no\n"+
   "sense of smell and  birds flutter high above you in the wind. Standing \n"+
   "here you are truly in control of this land and sea, Lorne Greene would \n"+
   "be proud of you.\n";
  dest_dir = ({"players/azane/swim2.c", "swim",
               "players/azane/beach3.c", "shore"});
  }
}
