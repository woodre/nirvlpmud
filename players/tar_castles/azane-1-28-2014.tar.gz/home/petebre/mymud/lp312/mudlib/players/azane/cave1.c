inherit	"room/room";

reset(arg) { 
 if(!present("sign")) {
   move_object(clone_object("players/azane/sign3.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Cave entrance.";
  long_desc = 
   "   From here you can hear noise's from within the cave as you softly\n"+
   "walk this path, a wildboar runs across your path as you jump out of it's\n"+
   "way. The smell is also unbearable and you know that it is from the cave,\n"+
   "you wonder about your thrist and stomach.\n";
  dest_dir = ({"players/azane/islandbeach3.c", "south",
               "players/azane/cave2.c", "north"});
  }
}
