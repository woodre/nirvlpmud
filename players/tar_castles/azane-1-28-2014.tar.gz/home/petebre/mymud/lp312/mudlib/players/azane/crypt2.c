inherit	"room/room";

reset(arg) { 
 if(!present("Skeleton")) {
   move_object(clone_object("players/azane/crypt.c"), this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "Crypt of the dead.";
  long_desc = 
   "   You travel farther north, with each footstep your heart beats\n"+
   "faster and louder, your mind screams with torment and thoughts of pain,\n"+
   "all the energy of these beings racks your body as their energy\n"+
   "flows into you. To the north you see a pulsating green slime that cakes\n"+
   "the walls ahead of you, as you approach it, it glows brighter as if it\n"+
   "felt your prescence within these walls.\n";
  dest_dir = ({"players/azane/crypt3.c", "north",
               "players/azane/crypt1.c", "south"});
  }
}
