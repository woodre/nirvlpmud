#define ATMOS "players/reflex/lib/std/random/atmos"
#define EXITS "players/reflex/lib/std/random/exits"
#define PROPS "players/reflex/lib/std/random/props"
#define SIGNS "players/reflex/lib/std/random/signs"
#define GENERATE "players/reflex/lib/std/random/generate"

#define RROOM "players/reflex/lib/std/random/room"
