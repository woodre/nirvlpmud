#define ATMOS "players/balowski/std/random/atmos"
#define EXITS "players/balowski/std/random/exits"
#define PROPS "players/balowski/std/random/props"
#define SIGNS "players/balowski/std/random/signs"
#define GENERATE "players/balowski/std/random/generate"

#define RROOM "players/balowski/std/random/room"
