inherit "obj/monster";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Cheat");
set_short("A cheat pulveriser");
set_alias("cheat");
set_long("This thug is here to beat the crap out of all\n"+
"you cheating vermin!!!\n");
set_race("human");
set_gender("male");
set_al(0);
set_level(19);
set_wc(28);
set_hp(1000);
set_ac(16);
set_aggressive(0);

 }
