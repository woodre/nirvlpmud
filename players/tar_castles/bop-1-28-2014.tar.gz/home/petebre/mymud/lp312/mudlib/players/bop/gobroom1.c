inherit "room/room";
#define num_goblin 10

object goblin;

reset(arg) {
  if(arg) {
           replace_goblin();
           return;
 }
set_light(1);
short_desc = "Valley";
long_desc = "You are in a basin in the valley. Some creatures\n"+
            "are gathered here, squabbling with each other.\n"+
            "Go on, kill them all.\n";
dest_dir = ({
             "players/bop/newpath2", "south"
 });
goblin = allocate(num_goblin);
replace_goblin();
return;
}

replace_goblin() {
  int i;
  for(i=0;i<num_goblin;i++)
   if(!goblin[i])
   move_object(goblin[i] = clone_object("players/bop/goblin"),this_object());
}
inherit "room/room";
