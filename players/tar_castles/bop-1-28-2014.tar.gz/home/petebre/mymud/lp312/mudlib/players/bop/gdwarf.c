inherit "obj/monster";
object coins;
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Gully dwarf");
set_short("A gully dwarf");
set_alias("dwarf");
set_long("A small and disgusting creature, completely lacking in\n"+
         "intelligence, this `gully dwarf' smells like its been\n"+
         "rolling in a sewer!\n");
set_race("dwarf");
set_gender("female");
set_al(0);
set_level(2);
set_wc(3);
set_hp(20);
set_ac(1);
set_aggressive(0);

coins = clone_object("obj/money");
coins->set_money(50);
move_object(coins,this_object());
 }
