inherit "room/room";
object troll;
reset(arg) {
  if(arg) {
   return;
 }
if(!troll) {
move_object(clone_object("players/bop/troll"),this_object());
}
set_light(1);
short_desc = "cave";
long_desc = "This appears to be the dwelling place of a rather large\n"+
            "creature. Hmm, maybe it wasn't such a good idea to wander\n"+
            "in here after all....\n";
dest_dir = ({
            "players/bop/newpath5", "north"
});
}
