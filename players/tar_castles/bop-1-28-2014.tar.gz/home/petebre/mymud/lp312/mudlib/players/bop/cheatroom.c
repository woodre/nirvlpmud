inherit "room/room";
#define num_cheat 6

object cheat;

reset(arg) {
  if(arg) {
           replace_cheat();
           return;
 }
set_light(1);
short_desc = "Camp";
long_desc = "You are here because you had to try and cheat!\n"+
"well, bad luck, you asked for it.\n";
dest_dir = ({
          "players/bop/entrance", "out"
 });
cheat = allocate(num_cheat);
replace_cheat();
return;
}

realm() { return "NT"; }
replace_cheat() {
  int i;
  for(i=0;i<num_cheat;i++)
   if(!cheat[i])
   move_object(cheat[i] = clone_object("players/bop/cheat"),this_object());
}
init() {
  ::init();
add_action("out", "out");
 }
out() {
if(present("Cheat")) {
write("You don't get away that easily...\n");
return 1;
}
write("You are one lucky cheat\n");
return 0;
 }
