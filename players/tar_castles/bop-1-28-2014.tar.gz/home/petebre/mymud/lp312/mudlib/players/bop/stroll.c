inherit "obj/monster";
object coins;
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Small troll");
set_short("A small troll");
set_alias("troll");
set_long("This is a young troll, and quite attractive by the\n"+
         "standards of it's race. Yyyiiickkk! What an awful \n"+
         "thought. However, the big question is, where the \n"+
         "hell is Poppa Troll????\n");
set_race("troll");
set_gender("neuter");
set_al(0);
set_level(8);
set_wc(8);
set_hp(80);
set_ac(4);
set_aggressive(0);

coins = clone_object("obj/money");
coins->set_money(300);
move_object(coins,this_object());
 }
