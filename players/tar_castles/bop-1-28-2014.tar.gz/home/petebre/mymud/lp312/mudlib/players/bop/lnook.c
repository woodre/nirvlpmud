inherit"room/room";
reset(arg) {
   if(arg) { return; }
set_light(1);
short_desc = "Lover's Lane";
long_desc = "You have reached the end of the local Lover's Lane.\n"+
            "You appear to be in a cosy little nook here, where\n"+
            "you and your loved one can become a little more intimate\n"+
            "with each other. For some more information, type `help nook'.\n";
dest_dir = ({
             "players/bop/llane", "east"
});
}
init() {
  ::init();
add_action("caress", "caress");
add_action("fplay", "fplay");
add_action("finger", "finger");
add_action("suck", "suck");
add_action("lick", "lick");
add_action("screw", "screw");
add_action("chew", "chew");
add_action("spread", "spread");
add_action("doggy", "doggy");
add_action("orgasm", "orgasm");
add_action("help", "help");
