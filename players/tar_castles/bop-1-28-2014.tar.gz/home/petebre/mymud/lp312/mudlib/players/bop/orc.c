inherit "obj/monster";
object coins;
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Orc");
set_short("An orc");
set_alias("orc");
set_long("These critters were born for one purpose. This was\n"+
         "to be big, mean, and ugly. Unfortunately, those who\n"+
         "dreamt up this race forgot about one slight problem.\n"+
         "The problem being an innate stupidity which would amaze\n"+
         "a demented flea!\n");
set_race("orc");
set_gender("male");
set_al(0);
set_level(6);
set_wc(10);
set_hp(90);
set_ac(5);
set_aggressive(0);

coins = clone_object("obj/money");
coins->set_money(150);
move_object(coins,this_object());
 }
