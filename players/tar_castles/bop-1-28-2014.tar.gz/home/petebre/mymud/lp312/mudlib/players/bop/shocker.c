inherit "obj/treasure";

reset(arg)
{
    if (arg) return;
    set_id("shocker");
    set_short("Static's Shocker");
    set_long("One of Static's favorite toys.\n"+
    "To use: 'shock <player>'.\n");
    set_weight(0);
    set_value(1000);
}

init()
{
    add_action("shock", "shock");
}
shock(str)
{
    object friend;
     if (!str) return;
     friend = find_living(lower_case(str));
     if (!friend)
     {
     write ("That person is not on now.\n");
    return 1;
}
tell_object(friend, this_player()->query_name() +
" zaps you with a bolt of Static electricity!\n");
tell_room(environment(friend),
"A bolt of Static Electricity enters the room leaving a pile of ash\n"+
"where " +(str)+
" faced the wrath of "+
this_player()->query_name() +
". They'll not do that again in a hurry!\n");
say(this_player()->query_name() +
" zaps another electroslave with a high powered Static Shock!\n");
write ("You shock "+(str)+".\n");
return 1;
}
