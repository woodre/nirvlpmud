inherit "room/room";
reset(arg) {
  if(arg) {
    return;
}
set_light(1);
short_desc = "Lover's Lane";
long_desc = "This is the local Lover's lane. Not surprisingly, it has\n"+
            "reached a state where the local council have been forced to\n"+
            "try and clear away all the debris. However, provided the council\n"+
            "give permission, it should be re-opened soon.\n";
dest_dir = ({
             "players/bop/entrance", "east"
});
}
