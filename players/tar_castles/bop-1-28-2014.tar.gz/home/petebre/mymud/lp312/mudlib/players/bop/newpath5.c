inherit "room/room";
reset(arg) {
    if(arg) {
      return;
 }
set_light(1);
short_desc = "Pathway";
long_desc = "As you reach the end of the valley, you can see a large\n"+
            "hilltop to your north, and a cave to the south. You\n"+
            "wonder if the cave will reveal the answer to your\n"+
            "puzzlement at finding such sinister creatures in\n"+
            "such a pleasant place.\n";
dest_dir = ({
             "players/bop/newpath4", "west",
             "players/bop/stroom", "north",
             "players/bop/troom", "south"
 });
}
