#define NAME "Bop"
#define DEST "room/jetty"
/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "gap"; }

short() {
return "A gap through a hedge to the south";
}

long() {
write("At present this castle is really only of interest to\n");
write("players of level 7 and under. However, this will soon\n");
write("change, and the Lover's Lane particularly may be of\n");
write("interest to many of you. *Stay Tuned For More*\n");
}

init() {
    add_action("enter"); add_verb("enter");
}

enter(str) {
     if (!id(str)) return;
this_player()->move_player("enter gap#players/bop/entrance");
     return 1;
   }

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
}
