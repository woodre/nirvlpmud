
inherit "room/room";
reset(arg) {
    if(arg) {
            return;
    }
    set_light(1);
short_desc = "Bop's workroom";
long_desc = "This is the most untidy room you have seen in your life!\n"+
            "It is, of course, the room where Bop sits contemplating\n"+
            "life, the universe, and anything else that springs to mind\n"+
            "while he plots even more bizarre ways to make life as a\n"+
            "player more wickedly enjoyable!\n";
   dest_dir = ({
                "room/church", "church",
                "room/post", "post",
                "room/adv_inner", "news",
                "room/shop", "shop",
                "players/bop/entrance", "toddle"
  });
 }
