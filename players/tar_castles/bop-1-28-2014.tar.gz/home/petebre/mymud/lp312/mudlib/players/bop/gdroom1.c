inherit "room/room";
#define num_gdwarf 15

object gdwarf;

reset(arg) {
  if(arg) {
           replace_gdwarf();
           return;
 }
set_light(1);
short_desc = "Hill";
long_desc = "There are a lot of small creatures playing here.\n"+
            "They are small and grimy, and could be mistaken \n"+
        "for children at a distance. Maybe you should join in?\n";
dest_dir = ({
             "players/bop/newpath", "south"
 });
gdwarf = allocate(num_gdwarf);
replace_gdwarf();
return;
}

replace_gdwarf() {
  int i;
  for(i=0;i<num_gdwarf;i++)
   if(!gdwarf[i])
   move_object(gdwarf[i] = clone_object("players/bop/gdwarf"),this_object());
}
inherit "room/room";
