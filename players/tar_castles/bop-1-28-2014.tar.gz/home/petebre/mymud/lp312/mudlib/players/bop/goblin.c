inherit "obj/monster";
object coins;
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Goblin");
set_short("A goblin");
set_alias("goblin");
set_long("A revolting race in general, created by evil mages,\n"+
         "goblins were one of the earliest and weakest of these\n"+
         "creations. This particular specimen does nothing to\n"+
         "improve your opinion of the race.\n");
set_race("goblin");
set_gender("male");
set_al(0);
set_level(4);
set_wc(8);
set_hp(60);
set_ac(4);
set_aggressive(0);

coins = clone_object("obj/money");
coins->set_money(75);
move_object(coins,this_object());
 }
