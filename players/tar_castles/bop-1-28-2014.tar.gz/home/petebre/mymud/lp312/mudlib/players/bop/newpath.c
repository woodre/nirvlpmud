inherit "room/room";
reset(arg) {
    if(arg) {
      return;
 }
set_light(1);
short_desc = "Pathway";
long_desc = "This is a path through a pleasant looking valley.\n"+
             "It looks like all the creatures here are small and\n"+
           "timid. Have fun!\n";
dest_dir = ({
             "players/bop/entrance", "west",
             "players/bop/newpath2", "east",
             "players/bop/gdroom1", "north",
             "players/bop/gdroom2", "south"
 });
}
init() {
  ::init();
add_action("west", "west");
 }
west() {
if(this_player()->query_level() >7) {
write("You were warned you lowlife cheat!\n");
move_object(this_player(),"players/bop/cheatroom");
return 1;
}
write("You leave the peaceful valley, and return to reality.\n");
return 0;
 }
