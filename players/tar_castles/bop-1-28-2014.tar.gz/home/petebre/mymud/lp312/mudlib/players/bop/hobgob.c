inherit "obj/monster";
object coins;
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Hobgoblin");
set_short("A hobgoblin");
set_alias("hobgoblin");
set_long("A revolting race in general, created by evil mages,\n"+
     "hobgoblins were exceptional examples of the prototype\n"+
      "goblins. Then again, you can understand this, as most\n"+
      "people seem to take exception to these vile creatures.\n");
set_race("goblin");
set_gender("male");
set_al(0);
set_level(5);
set_wc(9);
set_hp(75);
set_ac(5);
set_aggressive(0);

coins = clone_object("obj/money");
coins->set_money(100);
move_object(coins,this_object());
 }
