inherit "room/room";
reset(arg) {
    if(arg) {
      return;
 }
set_light(1);
short_desc = "Pathway";
long_desc = "As you continue along the path, you begin to\n"+
            "wonder if coming here was such a good idea after\n"+
            "all. However, the valley still continues onward.\n";
dest_dir = ({
             "players/bop/newpath2", "west",
             "players/bop/newpath4", "east",
             "players/bop/hobroom1", "north",
             "players/bop/hobroom2", "south"
 });
}
