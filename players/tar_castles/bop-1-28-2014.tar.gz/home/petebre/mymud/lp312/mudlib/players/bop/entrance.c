inherit "room/room";
reset(arg) {
  if(arg) {
     return 0;
  }
set_light(1);
short_desc =  "Entrance";
long_desc = "You are in a large field, with paths running\n"+
            "east and west of here. For some strange\n"+
            "reason, some pillock has put a LARGE\n"+
            "SIGN here. Why don't you look at it?\n";
dest_dir = ({
            "room/jetty", "south",
         "players/bop/newpath", "east",
            "players/bop/llane", "west"
  });
items = ({
         "sign", "There is a fun newbie area to your east\n"+
                 "Mugs and losers over level 7 ENTER AT\n"+
                 "YOUR OWN GREAT RISK!!!!!!!\n"+
                 "Lover's lane stretches west, hopefully\n"+
                 "the council will have it cleared while\n"+
               "the weather holds.\n"
});
 }
init() {
  ::init();
add_action("east", "east");
}
status
east() {
 if(this_player()->query_level() >7) {
 write("You miserable lowlife, trying to steal newbie monsters.\n");
 say(this_player()->query_name() +
   " tries to sneak into Newbieland. What a scuzbucket.\n");
   return 1;
}
write("You wander into the valley.\n");
return 0;
 }
