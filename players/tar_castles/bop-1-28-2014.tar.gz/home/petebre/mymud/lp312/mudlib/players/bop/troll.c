inherit "obj/monster";
object coins;
reset(arg) {
::reset(arg);
if(arg) return;
set_name("Troll");
set_short("A troll");
set_alias("troll");
set_long("This monster is a slightly different kettle of fish from\n"+
         "the pathetic orcs, goblins, and gully dwarves it Lords over\n"+
         "as you quickly realize from the size and proportional stench.\n"+
      "You had best kill it quick before you are violently ill!\n");
set_race("troll");
set_gender("neuter");
set_al(0);
set_level(10);
set_wc(14);
set_hp(150);
set_ac(8);
set_aggressive(0);

coins = clone_object("obj/money");
coins->set_money(450);
move_object(coins,this_object());
 }
