inherit "room/room";
reset(arg) {
    if(arg) {
      return;
 }
set_light(1);
short_desc = "Pathway";
long_desc = "As you continue along the path, you begin to\n"+
            "wonder if coming here was such a good idea after\n"+
            "all. However, the valley still continues onward.\n";
dest_dir = ({
             "players/bop/newpath", "west",
             "players/bop/newpath3", "east",
             "players/bop/gobroom1", "north",
             "players/bop/gobroom2", "south"
 });
}
