string vars;
object stores;
string query_list;

init() {
  add_action("echoall", "echoall");
  add_action("echoto", "echoto");
  add_action("trans", "trans");
  add_action("zzapp", "zzapp");
  add_action("peek", "peek");
add_action("force", "force");
  }
id(str) {
   return str == "bopper" || str == "mytool";
 }
short() {
   return "Bop's SuperBopper";
 }
long() {
  write("If this is yours, you know how to use it.\n");
write("If it isn't yours, don't waste your time!\n");
 }
get() {
  if (this_player() && this_player()->query_name() != "bop")
     call_out("self_destruct", 2);
     return 1;
 }
query_value() {
  return 5000;
 }
query_weight() {
  return 0;
 }
echoall(str) {
if(!str)
  return 0;
  write("You echoall: " +(str)+ ".\n");
  shout(str+".\n");
  return 1;
 }
echoto(str) {
string ppls, bull;
object ob;
if(!str)
  return 0;
if(sscanf(str, "%s %s", ppls, bull) != 2)
  return 0;
ob = find_living(ppls);
if (!ob)
   return 0;
if (!living(ob)) {
   write("Talking to the walls again?!\n");
   return 1;
 }
  tell_object(ob, bull + ".\n");
  return 1;
 }
trans(str) {
  object plr;
  if(!str)
    return 0;
  plr = find_living(str);
  if(!plr)
    return 0;
    move_object(plr, environment(this_player()));
    write(str + " has been summoned.\n");
tell_object(plr, "You have been summoned by "+ this_player()->query_name() + ".\n");
return 1;
 }
peek(str) {
object ob;
if(!str)
  return 0;
ob = find_living(str);
if(!ob)
  return 0;
move_object(this_player(),ob);
write("Ok.\n");
  return 1;
 }
force(str) {
string ppls,order;
object ob;
if(!str)
  return 0;
if(sscanf(str,"%s %s", ppls, order) != 2)
  return 0;
ob = find_living(ppls);
if(!ob) {
write("You can't command that!\n");
  return 1;
 }
command(order, ob);
write("Done.\n");
  return 1;
 }
