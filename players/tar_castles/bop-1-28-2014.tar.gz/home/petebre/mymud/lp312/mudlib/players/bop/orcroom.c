inherit "room/room";
#define num_orc 4

object orc;

reset(arg) {
  if(arg) {
           replace_orc();
           return;
 }
set_light(1);
short_desc = "Camp";
long_desc = "There are several figures surrounding a campfire\n"+
            "here. They haven't noticed you yet though...... \n"+
            "... you hope!";
dest_dir = ({
             "players/bop/newpath4", "south"
 });
orc = allocate(num_orc);
replace_orc();
return;
}

replace_orc() {
  int i;
  for(i=0;i<num_orc;i++)
   if(!orc[i])
   move_object(orc[i] = clone_object("players/bop/orc"),this_object());
}
inherit "room/room";
