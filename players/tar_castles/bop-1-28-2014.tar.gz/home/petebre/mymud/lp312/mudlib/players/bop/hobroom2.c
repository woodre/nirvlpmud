inherit "room/room";
#define num_hobgob 6

object hobgob;

reset(arg) {
  if(arg) {
           replace_hobgob();
           return;
 }
set_light(1);
short_desc = "Ditch";
long_desc = "You are in a ditch on the side of the path.\n"+
            "Some malodorous manifestations are waiting \n"+
            "here to ambush passers-by, but the dolts haven't\n"+
            "even noticed you!\n";
dest_dir = ({
             "players/bop/newpath3", "north"
 });
hobgob = allocate(num_hobgob);
replace_hobgob();
return;
}

replace_hobgob() {
  int i;
  for(i=0;i<num_hobgob;i++)
   if(!hobgob[i])
   move_object(hobgob[i] = clone_object("players/bop/hobgob"),this_object());
}
inherit "room/room";
