inherit "room/room";
#define num_stroll 2

object stroll;

reset(arg) {
  if(arg) {
           replace_stroll();
           return;
 }
set_light(1);
short_desc = "Hilltop";
long_desc = "There are two fairly large figures dancing and\n"+
            "giggling on top of this hill. They seem so happy\n"+
            "You just can't resist taking a closer look.\n";
dest_dir = ({
             "players/bop/newpath5", "south"
 });
stroll = allocate(num_stroll);
replace_stroll();
return;
}

replace_stroll() {
  int i;
  for(i=0;i<num_stroll;i++)
   if(!stroll[i])
   move_object(stroll[i] = clone_object("players/bop/stroll"),this_object());
}
inherit "room/room";
