/* Thanks for your help Verte! ... Cobain. */
#include "/players/cobain/std/ansi.h"
#define tpp this_player()->query_possessive()

inherit "/obj/armor";

/* void just declares what is being returned in the func:
            in this case, nothing */
void
reset(int arg) 
{
    if(arg) return;
    ::reset();  /* call the inherited reset() func */
    set_name("opti-shades");
    set_alias("shades");
    set_short("A pair of "+WHT+"Opti"+NORM+"-"+CYN+"Shades"+NORM+" (tm)");
    set_long("\
A pair of dark titanium glasses which eminate a strange reflective\n\
resonance. The front lens swirl with a magnetic orange tint.\n\
These glasses can be worn.\n");
    set_weight(1);
    set_value(0);
    set_type("helmet");
    set_ac(0); /* hmm? */
}

status 
wear(string str)
{
    if(!str || !id(str) || environment() != this_player())    
      return 0;
    if(worn){
      notify_fail("You are already wearing headgear! \n");
      return 0;
    }
  

    ::wear(str);

    if(worn)
    {
      write("\
Your perception sharpens as you slide the Opti-Shades over your eyes.\n\
Slowly, the titanium metal extends in clawlike motion outwards to attach\n\
all the way around your head. \n");
      say((string)this_player()->query_name() + " slides on "+tpp+" Opti-Shades (tm).\n");
    }

    return 1;
}

status
remove(string str)
{
    if(!str || !id(str) || environment() != this_player() || !worn)
      return 0;

    ::remove(str);
    
    if(!worn)
    {
      write("You remove the cool shades.\n");
      say((string)this_player()->query_name() + " removes "+tpp+" Opti-Shades(tm).\n");
    }
    return 1;
}


short()
{
    object e;

    if((e = environment()) && worn_by == e)
      return ((string)worn_by->query_name() + "'s "+WHT+"Opti"+NORM+"-"+CYN+"Shades"+NORM+" tm. (worn)");
    else
      return ::short();
}


/* Other Functions */

init()
{  ::init();
   add_action("look", "look");   
   add_action("exa", "exa");
   add_action("look", "glance");
   add_action("look", "l");
   add_action("i","i");
   add_action("giveit","give");
   add_action("pickup","take");
   add_action("pickup","get");
   add_action("putit","put");
}

exa(string str) 
{  if(worn_by != this_player()) 
      return 0;
    str="at "+str; 
    look(str); 
    return 1;
}

pickup(string str) 
{ 
    if(worn_by != this_player()) 
      return 0;

    set_light(3); this_player()->pick_up(str); set_light(-3); 
    return 1; 
}

look(string str) 
{ 
    if(worn_by != this_player()) 
      return 0;
 /*   if (environment(this_object())->test_dark()) */
/*	write(HIG+"You squint in the darkness to see..\n"+NORM); */

    set_light(3); this_player()->look(str); set_light(-3);
    return 1; 
}

i(){ 
     object ob;

     if(worn_by != this_player())
        return 0;

     ob = first_inventory(this_player());
     while (ob) {
        string str;
        str = call_other(ob, "short");
        if (str) {
            write(str + ".\n");
        }
        ob = next_inventory(ob);
    }
    return 1;
}

giveit(string str){

   if(worn_by != this_player()) 
      return 0;

   set_light(3); this_player()->give_object(str); set_light(-3);
   return 1; 
}

putit(string str){

   if(worn_by != this_player()) 
      return 0;

   set_light(3); this_player()->put(str); set_light(-3);
   return 1; 
}
