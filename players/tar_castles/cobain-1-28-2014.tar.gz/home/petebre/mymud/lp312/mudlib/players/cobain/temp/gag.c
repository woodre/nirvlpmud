#define tp this_player()->query_name()
#define MAX_LIST			20
#define EXPLORE 20

static object it;

inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

   set_id("gag");
   set_short("This Player has been gagged/muffled by Cobain");
   set_long("A big muffle, applied in situations which require silence.\n");
   set_weight(0);
   set_value(1);
}

init()
{  add_action("gag", "say");
   add_action("gag", "gossip");
   add_action("gag", "risque");
   add_action("gag", "star");
   add_action("gag", "'");
}

drop(){return 1;}

gag(str) {

  write("\
You have been gagged by Cobain for reasons which you were prior notified \n\
and warned of. You shall be contacted by a wiz shortly. \n");
    
  return 1;
}
