/*  Crash Test Dummy by Cobain */

#include "/obj/ansi.h"
inherit "/obj/monster.c";

/* Dummy Variables */
int d_hp, d_max_hp;        /* Dummy Hit Points */
int d_lvl;                 /* Dummy Level      */
int d_ac;                  /* Dummy AC         */
string d_race;             /* Dummy Race */

/* Attacker Variables */
int a_wc, a_max_wc;        /* Attacker WC */

/* Fight Variables */
static int dmg, round;
int maxrounds;

reset(arg) {
 ::reset(arg);
   if(arg) return;
   set_name("dummy");
   set_short("A crash test dummy");
   set_race("dummy");

   set_level(20);
   set_hp(1000);
   set_wc(20);
   set_ac(0);
   set_al(0);
}

id(str){ return str == "dummy" || "sven" || "test" ;}

init() {
 ::init();
   add_action("dummy","dummy");
}


/* INTERNAL FUNCTIONS */

heart_beat() {
  ::heart_beat();
}

show_monitor_ac(){ return 1;}
show_monitor_wc(){ return 1;}

dummy() {  return 1;}


reset_values() {
   set_level(20);
   set_hp(1000);
   set_wc(20);
   set_ac(0);
   set_al(0);

   a_wc = 0;
   a_max_wc = 0;

   maxrounds = 500;
   round = 0;
   dmg = 0;

   return 1;
}
