#include "/players/cobain/defines/common.h"
#include "/obj/ansi.h"
inherit "/obj/monster.c";
#define MAX_OBJ_EVAL 8000
int dmg,rounds;

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_level(20);
   set_name("npc");
   set_short("A dmg npc");
   set_long("searchbox\nnamebox \n");
   set_hp(1000);
   set_wc(30);
   set_ac(0);
   set_al(0);
   }

id(str){ return str == "npc"; }

init() {
   ::init();
   add_action("search_box","searchbox");
   add_action("make_box","namebox");
}

string query_boxes(int total_obj, int current_init, int current_max)
{
   string boxlist;
   int inc;
   object ob;

   if(total_obj < MAX_OBJ_EVAL)
      current_max = total_obj;
    else
      current_max = MAX_OBJ_EVAL;


   /* if(ob = find_object("/obj/discon" + "#" + inc))*/
   for(inc = current_init; inc < current_max; inc ++) {
       if(ob = find_object("/obj/discon#"+inc))
      {
        write_file("/players/cobain/log",""+inc+"\n");
        if (ob->query_box_owner() == TPRN)
           return "/"+file_name(ENV(ob));
      }
   }

   if(current_max == total_obj) {
        /* Add more here in final product */
   	write("Finished... \n");
   }

   current_init = current_max;

   if(current_max < total_obj)
    {
      if((total_obj - current_max) <= MAX_OBJ_EVAL)
        current_max = total_obj;
      else
        current_max += MAX_OBJ_EVAL;
    }

    call_out("query_boxes",0,({total_obj, current_init, current_max}));

}

search_box() {
   object ob;
   string discard_me, total_obj;
   string boxlist;

   if(!exists("/obj/discon.c"))
     return (notify_fail("This should not happen. Please inform Cobain if you see this message.\n"), 0);


   /*Get Current Obj Number*/
     total_obj = 0;
     ob = clone_object("/players/cobain/closed/primus/obj/helix.c");
     sscanf(file_name(ob),"%s#%d", discard_me, total_obj);
     destruct(ob);

     write("Working... \n");
     boxlist = query_boxes(total_obj, 0, 0);
     if (boxlist == "")
       write("Your box does not seem to exist on the mud. \n");
     else
       write(boxlist);

   return 1;
}