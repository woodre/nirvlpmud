inherit "room/room.c";

reset(arg){
  if(arg) return;
  set_light(1);
  short_desc="Primus Entrance";

  long_desc=
"  \
This entrance foyer to the city of Primus appears well\n\
worn.  Specks of dust and footprints scatter across the floor,\n\
indicating a general lack of maintenance and cleaning.  An\n\
automatic metallic sliding door opens to the east leading\n\
inside to the city areas.\n";

 items=({
   "door", "An open doorway to the east.",
   "floor","The floor is covered with dust.",
   "dust","Dust left behind from the numerous travelers who have travelled this city.",
   "primus","Primus, a futuristic but unmaintained and broken down city.",
   "footprints","Footprints indicating that Primus has been well travelled."
 });

 /* DESTINATIONS */
 dest_dir=({
    "/players/cobain/primus/rooms/domain.c","east",
    "/players/cobain/workroom.c","cobain",
  });
}

/* GENERAL FUNCTIONS */
cmd_smell(str) {
  write("The smell of adventure looms in the air\n");
  return 1;
}

cmd_listen(str) {
  write("Activity can be heard from the city of Primus\n");
  return 1;
}

cmd_search(str) {
  write("Your search reveals nothing\n");
  return 1;
}

/*ADD ITEMS*/
init() {
  ::init();
  add_action("cmd_search","search");
  add_action("cmd_smell","smell");
  add_action("cmd_listen","listen");
}
