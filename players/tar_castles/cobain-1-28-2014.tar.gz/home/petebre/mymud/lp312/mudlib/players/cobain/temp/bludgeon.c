#include "/players/cobain/std/ansi.h"; 
inherit "obj/weapon.c";

 reset(arg) {
    int i;
    ::reset(arg);
    if (arg) return;
message_hit=({HIR+"*SLAM*"+NORM," with a thud to head",HIR+"smack"+NORM," with a frenzied swing","jab"," hard against the torso","pound"," on the foot","hit","","grazed","","poked"," softly"});

    i = random(4);

    if(i == 0){ cudgel(); }
    if(i == 1){ baton(); }
    if(i == 2){ bat(); }
    if(i == 3){ pipe(); }

    set_class(13);
    set_weight(2);
    set_value(500);
}

short()
{
    object e;

    if((e = environment()) && wielded_by == e)
      return ((string)wielded_by->query_name() + "'s " + query_name() + " (wielded)");
    else
      return ::short();
}

cudgel() {
    set_name("cudgel");
    set_alias("stick");
    set_short("A sturdy cudgel");
    set_long("\
A large sized cudgel used to strike fear into those\n\
who might be unfortunate enough to stand in its' path.\n\
This sturdy weapon can be wielded \n");
    
return 1;
}

baton() {
    set_name("baton");
    set_short("A shiney baton");
    set_long("\
A mid sized, yet shiney black baton often used by the\n\
police from ancient days. This appears to be an antique\n\
replica. However when wielded it can still do some damage.\n");
    
return 1;
}

bat() {
    set_name("baseball bat");
    set_alias("bat");
    set_short("A solid baseball bat");
    set_long("\
A bat which in normal circumstances is used for recreational\n\
purposes. The chips and niches on this bat suggests that it\n\
is often wielded for other tasks such as battery and assault.\n");
    
return 1;
}

pipe() {
    set_name("pipe");
    set_short("A long iron pipe");
    set_long("\
A metal pipe that shows signs of age. Small chipped pieces\n\
appear flakey at points where rust has done its damage.\n\
Some blood stains appear on the pipe suggesting it has been\n\
previously wielded as a weapon.\n");
    
return 1;
}
