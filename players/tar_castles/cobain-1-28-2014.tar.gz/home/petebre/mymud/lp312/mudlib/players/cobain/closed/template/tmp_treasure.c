#include "/players/cobain/closed/std/defines.h"
#include "/players/cobain/std/ansi.h"

inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

   set_id("tag");
   set_short("tag");
   set_long(
   "Cobain's Title maker.\n");
   set_weight(0);
}

init() { 
  ::init(); 
  add_action("title_me", "title_me");   
  add_action("title_me2", "title_me2");   }

title_me()  {
    TP->set_pretitle( "("+WHT+"+"+NORM+") "+HIB+"--{"+NORM+""+WHT );
    TP->set_title(HIB+ "}--"+NORM);
    TP->set_al_title(WHT+"+"+NORM);
    return 1; }

title_me2()  {
    TP->set_pretitle("( "+HIG );
    TP->set_title(BLK);
    TP->set_al_title(NORM);
    return 1; }
