/* Valid Command Syntax:
   1. throw                      - throw current wep at current attacker
   2. throw unsheath             - throw 1st sheathed wep at current attacker
   3. throw <wep>                - throw <wep> at current attacker
   4. throw <npc>                - throw current wep at <npc>
   5. throw <wep> <npc>          - throw <wep> at <npc>
   6. throw unsheath <npc>       - throw 1st sheathed wep at <npc>
   7. throw unsheath <wep>       - throw sheathed <wep> at current attacker
   8. throw unsheath <wep> <npc> - throw sheathed <wep> at <npc>
*/
/* Potential Problems:
  players could just throw sheathed/get sword/sheath sword each round
  other players could easily steal the weapons
  if wep is moved to NPC's inventory then often players will lose thrown weps

  would it be fun to throw/get all every round?  i don't think i want that.
  but how can i avoid that?

 Ideas:
  use spell_object() to limit to 1 per hb and prevent combining of other attacks
  make throwing add 0 activity, and have sheathing cost 1 activity
  (even if it didn't cost 1, if they weren't gaining activity they'd have to
   alternate throwing weapons with using other attacks)
*/

throw_wep(str)
{
  int dmg, cost, activity, weight, odds, good;
  string one, two, three;
  object nmy, wep;

  if(User->query_ghost()) return 0;
  if(!PO->level_check(3)) return 0;

  if(User->query_spell_dam())
  {
    TOU "You are too drained to do this again.\n");
    return 1;
  }

  if(!str)                                                       /**1**/
  {
    if((wep = User->query_weapon()) && (nmy = User->query_attack())){}
  }
  else if(sscanf(str, "%s %s %s", one, two, three) == 3)         /**8**/
  {
    if(one == "unsheath")
    {
      wep = unsheath(two);
      nmy = valid_attack(three);
    }
  }
  else if(sscanf(str, "%s %s", one, two) == 2)                   /**5**/
  {
    if((wep = present(one, environment(PO))) && wep->weapon_class()
      && (nmy = valid_attack(two))){}
    else if(one == "unsheath")
    {
      if((nmy = valid_attack(two)))                              /**6**/
      {
        wep = unsheath("1");
        tell_object(find_player("zeus"), HIG+"five\n"+NORM);
      }
      else if((nmy = User->query_attack()))                      /**7**/
      {
        wep = unsheath(two);
        tell_object(find_player("zeus"), HIG+"six\n"+NORM);
      }
    }
  }
  else if(sscanf(str, "%s", one) == 1)
  {
    if(one == "sheathed")                                        /**2**/
    {
      if((nmy = User->query_attack()))
        wep = unsheath("1");
    }
    else if((wep = present(one, environment(PO))) && wep->weapon_class()) /**3**/
    {
      if((nmy = User->query_attack())){}
      tell_object(find_player("zeus"), HIG+"three\n"+NORM);
    }
    else if((nmy = valid_attack(one)))                           /**4**/
    {
      if((wep = User->query_weapon())){}
    }
  }

  if(!wep)
  {
    TOU "What weapon do you want to throw?\n");
    return 1;
  }
  if(!nmy)
  {
    TOU "What do you want to attack?\n");
    return 1;
  }

  weight = (int)wep->query_weight();
  activity = PO->activity_bonus();
  cost = 30 + (WIS / 10) + weight;
  dmg = (MIT / 10) + (AGL / 20) + (ACC / 10) + r(FAI/4) + 
    r(wep->weapon_class()) + GOD + activity;
  dmg = PO->stance_bonus(dmg);

  if((string)environment(User)->realm() == "NM")
  {
    TOU"Your energy is being drained here.\n");
    return 1;
  }

  if(User->query_sp() < cost)
  {
    TOU "You are too weak to do this now.\n");
    return 1;
  }

  PO->add_activity(1 + (AGL / 33));

  TOU "You throw your "+wep->short()+" at "+nmy->short()+".\n");

  odds = (int)PO->query_glevel() + r(MIT / 10) + r(ACC / 10)
    + r(WIS / 25) + r(FAI / 10) - weight;
  good = r(nmy->query_level()) + r(nmy->query_ac());

  if(odds > good) /* success */
  {
    TOU nmy->short()+" is impaled by your "+wep->short()+"!\n");
    nmy->hit_player(dmg);

  }
  else if(odds > (good / 2)) /* half success */
  {
    TOU nmy->short()+" is hit by your "+wep->short()+"!\n");
    nmy->hit_player(dmg / 2);
  }
  else
    TOU "You miss "+nmy->short()+", your weapon falling to the ground.\n");

  User->spell_object(nmy,"",0,cost,"","","");

  wep->drop(1);
  move_object(wep, environment(User));

  User->recalc_carry();
  return 1;
}

