inherit "room/room.c";

reset(arg){
  if(arg) return;
  set_light(1);
  short_desc="Domain Tunnel";
 
  long_desc=
"  \
   An overpowering well lit tunnel leading to the core center of\n\
Primus. Ambient lights line the ceiling in sequential fashion of\n\
this area.  One can't help but notice large panels of metallic \n\
sheet tiles embracing the walls.  Blue lines of paint streak against\n\
the sides of the passageway in long trails eastward toward the inner\n\
city.  People can be seen scuttling busily towards their destination.\n";

 items=({
   "ceiling", "The top of the tunnel has been constructed to be 100 feet above you",
   "panels","Large metal sheets which form the walls of this tunnel",
   "primus","Primus, a futuristic but unmaintained and broken down city",
   "paint","A form of decoration implemented by the city planners for decorative purposes",
   "people","People scurry past in different directions"
});

 /* DESTINATIONS */ 
 dest_dir=({
    "/players/cobain/primus/","east", 
    "/players/cobain/primus/rooms/primus_entry.c","west", 
  });
}

/* GENERAL FUNCTIONS */
cmd_smell(str) {
  write("You are unable to smell anything out of the ordinary\n");
  return 1;
}

cmd_listen(str) {
  write("Activity can be heard eastwards from the city of Primus\n");
  return 1;
}
 
cmd_search(str) {
  write("Your search reveals nothing\n");
  return 1;
}

/*ADD ITEMS*/
init() {
  ::init();
  add_action("cmd_search","search");
  add_action("cmd_smell","smell");
  add_action("cmd_listen","listen");
  add_action("cmd_east", "east");
}

cmd_east() { write("Test"); ::move("west"); return 1;}