/*1. Add messaging function */

#define TPN this_player()->query_name()
#define TPP this_player()->query_possessive()

#include "/players/cobain/closed/std/ansi.h"

inherit "obj/treasure";
status pagerstatus;
status wizonly;
int beatvalue;
status msgblock;

reset(arg) {
  if(arg) return;
    set_id("cobain_pager");
    set_alias("pager");
    set_short("A small"+WHT+" white pager"+NORM+" (tm)");
    set_weight(1);
    set_value(0);   
}

heart_beat(){
  beatvalue += 1;
  if (beatvalue == 3) {
    beatvalue = 0;
    msgblock = 0;
    set_heart_beat(0);
  }
}

long(){
write("\
A small cube shaped pager attached to a key ring.  The box contains\n\
an LCD display panel to intercept and display messages. Small speaker\n\
holes arranged in a circular fashion leads you to believe the item\n\
is able to emit sounds.\n\n"+"The pager is currently switched "
+WHT + (string)query_textpagerstatus()+NORM+". \n");

  if (wizonly == 1) {
   write("The pager accepts messages from "+WHT+"wizards only"+NORM+". \n");
  }

  write("For usage information: 'pager info'\n");
}


init(){
   ::init();
   add_action("pager", "pager");
   add_action("page", "page");
}


/* Pager Configuration */
pager(str) {

  if (environment() != this_player()) return 0;

  switch(str) {
    case "on": { 
          if (pagerstatus == 0) {
             write("The pager display flashes as it activates.\n");
             say(TPN + "'s pager flashes momentarily. \n");
          }
          pagerstatus = 1;
          break; }

    case "wizonly": { 
          if (wizonly == 0) {
              pager("on");
              wizonly = 1;
              write("Your pager is now activated and only accepts pages from wizards. \n");
          }
          else {  
              wizonly = 0;          
              write("Your pager is now configured to accept pages from all users. \n"); 
          }
          
          break; }

    case "off":{
          if (pagerstatus == 1){
              write("The lighted pager dulls as it deactivates.\n");
              say(TPN + "'s pager light fades away. \n");
          }
          pagerstatus = 0;
          break;}

    case "info": { 
write("Usage instructions: \n\n\
'pager on'                 - Turns the pager on \n\
'pager off'                - Turns the pager off \n\
'pager wizonly'            - Accept wizard pages only [toggle] \n\
'page <user> <message>'    - Pages <user> with <message> \n"); 
break; }

    default: pager("info");
  }

  return 1;
}

/* PAGING FUNCTION */

page(pagestring){
    object ob;
    object obtarget;
    string user;
    string msg;
    string target;
    int e;

    /*SPLITS INPUT INTO USERNAME AND MESSAGE*/
    e = sscanf(pagestring, "%s %s", user, msg);
    if (e != 2) {user = pagestring;}

    /* CHECKS FOR ERROR SITUATIONS */
    if (environment() != this_player()) {
       write("You must pick up the pager if you wish to use it.\n");
       return 1;
    }

    if (pagerstatus == 0) {
       write("Please turn on your pager before attempting to use it.\n");
       return 1;
    }

    if (this_player()->query_ghost()) {
	   write("You cannot page someone as a ghost!\n");
	   return 1;
    }

    if (!pagestring) {
       write("Who do you wish to page?\n"); 
       return 1;
    }

    target = lower_case(user);
    ob = find_player(target);

    if (!ob || ob->query_invis() > this_player()->query_level() || ob->query_tellblock() != 0 ) {
	  write("You receive a message on your pager stating: \n\"No contact could be made with "+capitalize(target)+"\".\n");
      return 1;
    }

    if (ob->query_name() == TPN) {write("It doesn't make sense to page yourself!\n");return 1; }


    /* CHECKS THAT TARGET HAS PAGER */
    obtarget= present("cobain_pager", find_player(target));
    if(obtarget){

      /* CATCHES FOR WIZONLY MESSAGES */
      if (obtarget->query_wizonly() == 1 && ob->query_level() > 19) {
       	  write("You receive a message on your pager stating: \n\"No contact could be made with "+capitalize(target)+"\".\n");
          return 1;
       }
      
      /* CATCHES FOR SPAM */
      if (msgblock == 1) {
         write("Your page has already been transmitted. Please wait "+(3-beatvalue)+" heartbeats before sending another. \n");
         return 1;
      }
      
      /* SENDS MESSAGE */ 
       switch(obtarget->query_pagerstatus()) {
          case 0: write(capitalize(target)+"'s pager is switched off.\n");return 1;
          case 1: {
            if (!msg) {
               tell_object(ob, BEEP +YEL+"<" + TPN + ">" + NORM + " is paging you."  + NORM +"\n");
            }
            else {
               tell_object(ob, BEEP +YEL+"<" + TPN +" pages" + "> " + NORM + "\"" +msg+ "\"\n");
            }

            write("The page has been sent.\n");
            set_heart_beat(1);
            msgblock = 1; /* locks spam*/
            beatvalue = 0;
            return 1;
          }
       }
    }
    else write("Your page is unsuccessful as "+capitalize(target)+" does not possess a pager.\n");

return 1;
}

/*PUBLIC QUERIES*/

status query_pagerstatus() {return pagerstatus;}
string query_textpagerstatus()
{
   if (pagerstatus==1) return "on";
   else return "off";
}
status query_wizonly() {return wizonly;}
