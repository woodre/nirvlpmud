#include "/players/fred/ansi.h";
inherit "/obj/monster.c";
#define tpn this_player()->query_name()

reset(arg) {
  ::reset(arg);
  if(arg) return;

  set_name("spider");
  set_race("creature");
  set_short(" S P I D E R of "+HIB+"ChAoS");
  set_long(
    "  A large mutated taranchula. It has strange markings\n"+
    "on it's back.\n");
  add_money(2000+random(4000));
  set_level(20);
  set_hp(500+random(75));
  set_al(-800);
  set_ac(21+random(4));
  set_wc(32);
  set_aggressive(0);
  set_chance(20);
  set_spell_dam(25);
  set_spell_mess1(
    "The Spider "+BOLD+" S T R I K E S"+NORM+" out at "+tpn+" you with it's\n"+
"Enormous poisen filled   F A N G S!n");
  set_spell_mess2(
    "\n "+HIB+" PAIN"+NORM+" shoots through your body as the poison races\n"+
    "through your veinsn");
}
