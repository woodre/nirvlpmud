/*                                                                    *
 *    File:             /players/sami/area/carnival/room/strong_mans_tent.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/09/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "house of mirrors";
  long_desc =
"  As you step into this room you notice a glimmer in front of you.\n\
You can see the reflection of the light in the many mirrors surrounding you.\n";
  items =
    ({
    "mirror",
    "You are amused as you see yourself, distorted in shape and yet.\n\
   out of the corner of your eye you notice a black mass apparently\n\
   towering over you.\n",
            });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/unknown.c", "east",
   "/players/sami/area/carnival/room/inside_the_chaos.c", "down",
     });
}
