/*                                                                    *
 *    File:             /players/sami/area/carnival/room/chaos_and_ruin.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-3);
  short_desc = "Chaos And Ruin";
  long_desc =
  "There is two torches burning in holders upon the walls of\n"+
  "the tent. Everything seems distorted, almost as if it were\n"+
  "slowly moveing.\n";
  items =
    ({
    "walls",
    "The walls seem to be made of a Translucent goop that you have never.\n\
     before seen.",
     "torch",
     "A set of Large Metalic torches sit on the akward appearing wall\n\
     adjacent to each other. They burn black with a flame never before seen",
});
     dest_dir =
    ({
    "/players/sami/area/carnival/room/path_to_ruin2.c", "exit",
    "/players/sami/area/carnival/room/emperor_of_chaos.c", "east",
    "/players/sami/area/carnival/room/mistress_of_madness.c", "west",
    "/players/sami/area/carnival/room/throne_room.c", "north",
      });
}
