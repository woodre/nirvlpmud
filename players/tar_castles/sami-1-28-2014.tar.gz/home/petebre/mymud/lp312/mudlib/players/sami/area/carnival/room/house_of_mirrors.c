/*                                                                    *
 *    File:             /players/sami/area/carnival/room/house of mirrors.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/09/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "house of mirrors";
  long_desc =
"  As you step into this room you notice a glimmer. \n\
There is a reflection of the light in the many mirrors surrounding\n\
a ominus light protrudeing from the middle of the room \n";
  items =
    ({
    "mirror",
    "You are amused as you see yourself, distorted in shape\n\
    and yet out of the corner of your eye you notice a black mass\n\
apparently towering over you.",
         });
     dest_dir =
    ({
   
     });
}
