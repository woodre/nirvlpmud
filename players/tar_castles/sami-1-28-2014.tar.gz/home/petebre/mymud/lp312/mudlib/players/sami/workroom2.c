#include "/players/mokri/define.h"
inherit "/players/vertebraker/closed/std/room.c";
int shield;
reset(arg) {
set_light(0);
set_short("BIONICS (open)");
set_long("this is a vast room with merely a single Dim light in the middle...\n"+
"it seems to be coming from nowhere...yet somehow there isno apparent source\n"+
"in which this light is radiating\n\t\theh\n\t\tShieldOFF\n");
}
init()
{
object me;
::init();
if(TP->is_player() && shield && TPRN != "sami")
{
me = find_player("sami");
if(me)
tell_object(me,HIG+"["+NORM+"SHIELD"+HIG+"]"+NORM+" " +CAP(TPRN)+" tried to enter your workroom.\n");
destruct(this_player());
if(TP && present(TP,TO))
move_player(TP,"/room/void");
return 1;
}
add_action("shield","shield");
add_action("exec","exec");
}
shield()
{
if(TPRN != "sami") return 0;
if(shield)
{
shield = 0;
set_short("BIONICS (open)");
set_long("this is a vast room merely a single Dim light in the middle...\n"+
"it seems to be comeing from nowhere...yet somehow there is no apparent soource\n"+
"in which this light is radiating\n\t\theh\n\t\tShield OFF\n");
write("Shield off.\n");
return 1;
}
shield = 1;
set_short("BIOICS (closed)");
set_long("this is a vast room merely a single Dim light in the middle...\n"+
"it seems to be comeing from nowhere...yet somehow there is no apparent source\n"+
"in which this light is radiating\n\t\theh\n\t\tShield ON\n");
write("Shield on.\n");
return 1;
}
int exec(string str)
{
string where, funcname, arg;
if(!str) str = "";
if(sscanf(str,"%s %s %s",where,funcname,arg) < 2)
{
write("Syntax: exec what function [arg]\n");
return 1;
}
if(arg)
call_other(where,funcname,arg);
else
call_other(where,funcname);
return 1;
}
