#include "/players/fred/ansi.h";
inherit "/obj/monster.c";
#define tpn this_player()->query_name()

reset(arg) {
  ::reset(arg);
  if(arg) return;
        
  set_name("emperor");
  set_race("imortal");
  set_short("EMPEROR of"+HIB+"ChaoS");
  set_long(
    "  Long"+HIB+" black"+NORM+" hair drapes down to this mans waist. A\n"+
    "long scar runs down the side of his face directly below his eye.\n"+
    "There is a Ensignia of the royal house of Madness upon his chest.\n");
  add_money(2000+random(2000));
  set_level(29);
  set_hp(2000+random(150));
  set_al(-800);
  set_ac(28+random(4));
  set_wc(55);
  set_aggressive(0);
  set_multi_cast(1);
  add_spell("flames_of_eternity",
  ""+HIB+"Blue flames"+NORM+" Erupt and engulf you in a whirlind of FURY!\n",
  "#MN# raises his staff high and summons blue flames from the pillar!\n",
  50,({35,35}),({"other|fire","other|evil"}),1);
   }
