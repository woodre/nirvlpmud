#include "/players/fred/ansi.h";
inherit "/obj/monster.c";
#define tpn this_player()->query_name()

reset(arg) {
  ::reset(arg);
  if(arg) return;

  set_name("girl");
  set_race("human");
  set_short("A Confused girl");
  set_long(
    "  A large man looking for his children\n");
  add_money(500+random(150));
  set_level(5);
  set_hp(100+random(50));
  set_al(-800);
  set_ac(3+random(4));
  set_wc(9);
  set_aggressive(0);
  set_chance(30);
  }
