/*                                                                    *
 *    File:                     /players/sami/area/carnival/room/fire_dancers.c 
  *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/09/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(3);
  short_desc = "Enter the Fire";
  long_desc =
"  The atmosphere abrubtly changes as immages step into this verry bright tent.\n\
there are torches hanging on the walls all over. silloutte figures are dancing\n\
along the walls.\n";
  items =
    ({
    "figures",
    "The figures move quickly to avoid crashing into each\n\
     other. as you peer at them they stop, and stare back.",
    "torches",
    "these are aluminum torches, with long whiskey soaked\n\
    rags draped around the tips of them. They burn brightly",   
      });
         dest_dir =
    ({
    "/players/sami/area/carnival/room/unknown1.c", "west",
   
     });
}
