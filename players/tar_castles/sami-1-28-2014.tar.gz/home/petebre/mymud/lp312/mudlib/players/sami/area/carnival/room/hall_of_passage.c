/*                                                                    *
 *    File:             /players/sami/area/carnival/room/hall_of_passage.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Inside the Chaos";
  long_desc =
  "screams are issuing from above.  There is a outlandishly looking\n"+
  "three story Tilt-A-Whirl here. Lights are all around the room,\n"+
  "flashing, and bells ringing. there is a strange sign posted\n"+
  "to the machine.\n";
  items =
    ({
    "sign",
    "Welcome ladies and gentlemen! you are about to endure,\n\
     sights that only the truely cursed shall ever have to whitness.\n\
     Dont be scared you may enter at your own risk.",
    "lights",
    "You see a brilliant display of flashing bulbs all around you.",
     });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/unknown1.c", "east",
    "/players/sami/area/carnival/room/house_of_horrors.c", "north"
      });
}
