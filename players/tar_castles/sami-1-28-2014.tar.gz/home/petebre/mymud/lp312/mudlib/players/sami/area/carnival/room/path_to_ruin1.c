/*                                                                    *
 *    File:             /players/sami/area/carnival/room/path_to_ruin1.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Path to Ruin";
  long_desc =
  "This is a Dimly lit pathway. The tents fade farther into the\n"+
  "backround. Everything seems to be still.There is no movement in\n"+
  "the surrounding trees. Vaguely, a beatten path can be seen\n"+ 
  "leading to the north, and the south.\n";
  items =
    ({
    "path",
    "Leaves are scatterd all about this long trail. It is beaten and \n\
     worn, as if it has been traveld many times before. ",
    "oak",
    "Many tall oakwood trees stands here. Almost no Light is visible\n\
    through the branches",
     });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/path_to_ruin0", "south",
    "/players/sami/area/carnival/room/path_to_ruin2.c", "north"
      });
}
