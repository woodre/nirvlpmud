/*                                                                    *
 *    File:             /players/sami/area/carnival/room/Throne_room.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Throne Room";
  long_desc =
  "There is a large golden throne in the center of the room.\n"+
  "A red carpet leads up a set of steps leading to the throne.\n"+
  "Torches wind around the walls giveing a ominous view of the\n";
    items =
    ({
    "throne",
    "A large red and gold throne. The legs look as if it was crafted out\n\
     of human remains. Two large skulls rest on the arms of the chair.",
     "carpet",
     "An expensive red silk carpet. You see nothing specail",
          });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/chaos_and_ruin.c", "south",
      });
}
