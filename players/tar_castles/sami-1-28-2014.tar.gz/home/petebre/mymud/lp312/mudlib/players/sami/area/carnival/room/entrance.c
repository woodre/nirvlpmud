/*                                                                    *
 *    File:             /players/sami/area/carnival/room/entrance.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/08/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */

#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Carnival of Carnage";
  long_desc =
"  This is a very large tent with a single admission stand in\n\
the center of the room. The walls are coverd in red and yellow\n\
posters. you can vaguely make out the face of a clown behind the\n\
counter, resembeling that of the posters. To the north you see a\n\
small cloth made door. The only other obvious exit is out.\n";
  items =
    ({
    "poster",
    "This is a average 8x11 poster. You can barely make out a clown's face\n\
     on the dirty surface of the thick glass it is encased in",
    "counter",
    "This is a very old redwood counter. Time has not been nice to the counter,\n\
     chips in the ancient wood along with small termite holes are noticeable",
    "door",
    "You laugh as you notice a raggity make-shift\n\
     door made of red and yellow cloth.",
     });
     dest_dir =
    ({
    });
}