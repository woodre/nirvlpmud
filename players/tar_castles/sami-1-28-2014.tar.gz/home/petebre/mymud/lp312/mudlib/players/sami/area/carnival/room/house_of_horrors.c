/*                                                                    *
 *    File:                     /players/sami/area/carnival/room/house_of_horror
s.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/09/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "house_of_horrors";
  long_desc =
"  The room is very dark and gloomy. there are noticeable patches of discolor\n\
on the walls. distorted shapes appear to lurks in the darkness\n";
  items =
    ({
    "shapes",
    "The figures move quite rapidly to avoid being seen. as you strain\n\
     your eyes you notice that the figures are watching you",
         });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/hall_of_passage.c", "south",
   
     });
}
