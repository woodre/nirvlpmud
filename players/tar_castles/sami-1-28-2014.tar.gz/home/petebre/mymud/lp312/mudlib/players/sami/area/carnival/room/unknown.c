/*                                                                    *
 *    File:             /players/sami/area/carnival/room/unknown1.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/09/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Unknown";
  long_desc =
"  It looks as if you steped into something out of a horror \n\
novel. you can almost taste the blood that is covering the \n\
sidewalks. You get the strange feeling that you have been here \n\
before. There is a pool of blood on the floor to your right.\n";
  items =
    ({
    "pool",
    "This is a pool of red liquid that reminds you of blood. You\n\
     get a uneasy feeling when you stare too long at it",
  "sidewalk",
   "There is a verry thin sidewalk here the cement is cracked and batterd.",
         });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/hall_of_passage.c", "west",
    "/players/sami/area/carnival/room/strong_mans_tent.c", "east",
    "/players/sami/area/carnival/room/unknown2.c", "south",
    "/players/sami/area/carnival/room/path_to_ruin0.c", "north",
   
     });
}
