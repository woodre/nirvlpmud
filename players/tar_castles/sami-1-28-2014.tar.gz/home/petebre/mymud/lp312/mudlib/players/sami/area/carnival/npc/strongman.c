#include "/players/fred/ansi.h";
inherit "/obj/monster.c";
#define tpn this_player()->query_name()

reset(arg) {
  ::reset(arg);
  if(arg) return;
        
  set_name("man");
  set_race("imortal");
  set_short("Strong Man");
  set_long(
    " The gleaming skull of this hairless man is enough to curdle the\n"+
    "stomach of any human. Standing 6 foot tall, and seeming to weigh 300lbs\n"+
    "there is not much this man can not lift it would appear. There is a\n"+
    "small ensignia engraved into the top of his skull.\n");
  add_money(6000+random(1000));
  set_level(31);
  set_hp(1200+random(150));
  set_al(-800);
  set_ac(24+random(4));
  set_wc(35);
  set_aggressive(0);
  set_multi_cast(1);
  add_spell("Supreme_Justice",
  "A large"+HIB+"Blue"+NORM+" shadow clouds your vision as you feel "+HIR+"PAIN"+NORM+"\n",
  "#MN# raises his fist high and"+HIR+"SLAMS"+NORM+" you with incredable speed!\n",
  50,({35,35}),({"other|fire","other|physical"}),1);
   }
