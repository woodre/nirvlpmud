/*                                                                    *
 *    File:             /players/sami/area/carnival/room/emperor_of_chaos.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Isle of Madness";
  long_desc =
  "Everything in this room is made of silver and platinum.\n"+
  "A Silver and black throne sits in the middle of the room.\n"+
  "Blue flames shoot from the fire pit next to the throne.\n";
    items =
    ({
    "throne",
    "A large black and silver throne. This is made out of pure silver\n\
     with onyx plates. Two large skulls rest on the arms of the chair.",
     "flames",
     "A pillar of blue fire.",
     "fire pit",
     "A very large platinum-made fire pit sits here. There seems to be\n\
     blue flames erupting from it. There is nothing inside burning",
          });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/chaos_and_ruin.c", "west",
      });
}
