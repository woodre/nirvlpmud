/*                                                                    *
 *    File:             /players/sami/area/carnival/room/path_to_ruin2.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Path to Ruin";
  long_desc =
  "There is a small clearing here, where the sun has broken\n"+
  "through the thick of the trees, leaveing a ominous aura\n"+
  "around the tent that can be seen directly ahead.\n";
  items =
    ({
    "tent",
    "A large red and white tent stands here. It looks very old and weatherd.\n\
     patches of cloth lay scatterd accross the clearing as if someone or\n\
     something was tearing it apart",
          });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/path_to_ruin1.c", "south",
    "/players/sami/area/carnival/room/chaos_and_ruin.c", "enter tent"
      });
}
init()
{
::init();
add_action("enter","enter");
}
int enter(string str)
{
if(!str || str != "tent")
return 0;
say(this_player()->query_name() + " enters the tent.\n");
move_object(this_player(),"/players/sami/area/carnival/room/chaos_and_ruin.c");
command("look",this_player());
return 1;
}
