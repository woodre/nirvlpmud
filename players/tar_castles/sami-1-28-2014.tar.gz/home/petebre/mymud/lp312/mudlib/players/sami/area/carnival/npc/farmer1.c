#include "/players/fred/ansi.h";
inherit "/obj/monster.c";
#define tpn this_player()->query_name()

reset(arg) {
  ::reset(arg);
  if(arg) return;

  set_name("farmer");
  set_race("human");
  set_short("A angry farmer");
  set_long(
    "  A large muscular farmer wearing a light blue overall.\n");
  add_money(200+random(150));
  set_level(8);
  set_hp(150+random(50));
  set_al(-800);
  set_ac(6+random(4));
  set_wc(14);
  set_aggressive(0);
  set_chance(30);
  }
