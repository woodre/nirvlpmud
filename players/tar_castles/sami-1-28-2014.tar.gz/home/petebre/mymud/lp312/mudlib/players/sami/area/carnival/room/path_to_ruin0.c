/*                                                                    *
 *    File:             /players/sami/area/carnival/room/path_to_ruin0.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Path to Ruin";
  long_desc =
  "This is a Dimly lit pathway. The Oak trees are blocking all\n"+
  "light from penetrateing the forest top. Vaguely, a\n"+
  "beatten path can be seen leading to the north.\n";
  items =
    ({
    "oak",
    "A tall oakwood tree stands here. It seems as if it is in pain, and.\n\
     there is some kind of platform in the higher branches",
     "platform",
     "High in the oak tree, a rickety looking platform rests in the tree\n\
     branches. you may be able to climb to it.",
     });
     dest_dir =
    ({
    "/players/sami/area/carnival/room/unknown.c", "south",
    "/players/sami/area/carnival/room/path_to_ruin1.c", "north"
      });
}
init()
{
::init();
add_action("climb","climb");
}
int climb(string str)
{
if(!str || str != "oak")
return 0;
say(this_player()->query_name() + " climbs the oaktree.\n");
move_object(this_player(),"/players/sami/area/carnival/room/oak_tree");
command("look",this_player());
return 1;
}
