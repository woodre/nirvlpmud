/*                                                                    *
 *    File:             /players/sami/area/carnival/room/inside the chaos.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/09/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-1);
  short_desc = "Inside the Chaos";
  long_desc =
"  You can hear the screams comeing from above you.\n\
There is a large three story Tilt-A-Whirl here. Lights are\n\
all around you, flashing, and bells ringing. there is a\n\
strange sign posted to the machine.\n";
  items =
    ({
    "sign",
    "Welcome ladies and gentlemen! you are about to endure,\n\
     sights that only the truely cursed shall ever have to whitness.\n\
Dont be scared, you may enter at your own risk",
    "lights",
    "You see a brilliant display of flashing bulbs all around you.",
     });
     dest_dir =
     "players/sami/area/carnival/room/strong_mans_tent.c", "up",
    ({
    });
}
