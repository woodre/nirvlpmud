/*                                                                    *
 *    File:             /players/sami/area/carnival/room/mistres of madness.c   *
 *    Function:         room                                          *
 *    Author(s):        Sami@Nirvana                                  *
 *    Copyright:        Copyright (c) 2008 Sami                       *
 *                              All Rights Reserved.                  *
 *    Source:           11/12/08                                      *
 *    Notes:                                                          *
 *                                                                    *
 *                                                                    *
 *    Change History:                                                 *
 */
#include "/sys/lib.h"

#include <ansi.h>

inherit "room/room";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(-3);
  short_desc = "Mistress's Chamber";
  long_desc =
  "A large green ivory throne is sitting in the middle of the\n"+
  "room. there is torches surrounding the throne, casting a purple\n"+
  "aura about the room.\n";
  items =
    ({
    "throne",
    "A large green throne made of ivory and jade",
     "torch",
     "A circle of Large Metalic torches surround the throne. Purple\n\
     flames are protrudeing from the tips",
});
     dest_dir =
    ({
    "/players/sami/area/carnival/room/chaos_and_ruin.c", "east",
      });
}
