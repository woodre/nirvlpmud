#include "/players/fred/ansi.h";
inherit "/obj/monster.c";
#define tpn this_player()->query_name()

reset(arg) {
  ::reset(arg);
  if(arg) return;
	
  set_name("emperoress");
  set_race("imortal");
  set_short(""+HIR+"EMPERORESS"+NORM+" of"+HIB+"ChaoS"+NORM+"");
  set_long(
    "  Long"+HIB+" black"+NORM+" hair drapes down to this womans waist. A\n"+
    "long jewled robe runs down the sleek body of this evil temptress.\n"+
    "There is a Ensignia of the royal house of Madness upon her chest.\n");
  add_money(4000+random(2000));
  set_level(35);
  set_hp(2000+random(150));
  set_al(-800);
  set_ac(22+random(4));
  set_wc(65);
  set_aggressive(0);
  set_multi_cast(1);
  add_spell("flames_of_eternity",
  ""+HIR+"Red"+NORM+" flames Erupt and engulf you in a whirlind of unknown furys!\n",
  "#MN# raises her staff high and summons blue flames from the pillar!\n",
  50,({35,35}),({"other|fire","other|evil"}),1);
   }
