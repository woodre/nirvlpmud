/*
 * This in a weapon example, overloaded with feature-use
 * The text doesn't cover everything, but almost..
 * The wield and unwield commands have enhanced syntax.
 * The weapons support proper saving (saves state) in lockers and hotel,
 *   but if you add variables (e.g. number of charges), you must extend
 *   the locker saving code, before locker saving is legal..
 * 
 * done by Balowski@Nirvana
 */
#include "/players/balowski/lib.h"
inherit WEAPON;

void create() {
    /* create is called _once_ and that is when the object has just */
    /* been created, making it the ideal place to customize the object */
    /* always call the inherited create function first, as it does the */
    /* initializing and setting of defaults */
    ::create();

    /* these functions are inherit from object (see other examples) */
    /* set_name() sets the main identifier for this item */
    set_name("sword");
    set_ids(({ "regular sword", }));
    set_short("Regular sword");
    set_long("This is a regular sword that you need one hand to wield.\n");
    set_value(800);
    set_weight(3);

    /* these are the weapon specific functions */
    /* main weapon category.. "sharp"/"blunt"/"pointed" for starters */
    /* it could be that it should be possible to combine categories, etc */
    set_type("sharp");

    /* the good ole weapon class */
    set_class(16);

    /* the weapon class will fall as the weapon is used.. the wear is */
    /* roughly rounds-of-combat times class, so high class weapons will */
    /* get worn quicker than low class weapons */
    /* this weapon will last around (8000/16) 500 rounds */
    set_durability(8000);

    /* fragility denotes how many times the weapon class can fall */
    /* (see durability) before the weapon breaks */
    set_fragility(3);

    /* this function sets how many times the weapon can be repaired */
    /* sharpening the weapon has a 1/4 chance of using one repair point */
    /* the default is -1, which means forever reparable */
    set_reparable(3);

    /* do this for making special hits. the function named weapon_hit */
    /* (see below) will be called every round of combat */
    set_hit_func(this_object());

    /* this is the number of hands needed to wield the weapon */
    /* players and old-style monsters have 2 hands */
    /* the default is 1 hand, so this call could be omitted in most cases */
    set_hands(1);
}

/* this is the function that will be called because of the set_hit_func() */
/* call. It is called every time the weapon is used to hit something */
/* it should return the bonus (can be negative), or "miss" if the */
/* attack should be a complete failure (any fireball style spells included) */
mixed weapon_hit(object victim) {
    object master;
    
    master = query_wielded_by(); /* the person wielding this weapon */
    /* stop me from hitting any smurfs ;-) */
    if ((string) victim->query_race() == "smurf") {
	tell_object(master, "You cannot harm smurfs with this sword!\n");
	return "miss";
    }

    /* give a little bonus, completely random */
    if (random(100) < 25) {
	tell_object(master, "You score a bonus hit.\n");
	tell_object(victim, master->query_name() +
		    " catches you with your guard down.\n");
	say(master->query_name() + " scores a bonus hit.\n",
	    victim); /* send text to everyone but master and attacker */
	return 2;
    }
}

/* these are special functions that can be "overloaded" if special */
/* behaviour is needed */
/* prevent_wield can block certain creatures from wielding the weapon */
/* it covers wield, ready, and # commands */
int prevent_wield(object who)
{
    if ((int) who->query_alignment() < -40) {
	tell_object(who, "You cannot wield this weapon.\n");
	return 1;
    }
    return ::prevent_wield(who); /* remember to do this! */
}

/* prevent_unwield can be used to block the 'wielder' from unwielding */
/* as old-style weapons forces an unwield when they are wielded, this */
/* is not at all certain to block unwield :( */
int prevent_unwield(int silently)
{
    tell_object(query_wielded_by(), "The sword is cursed!\n");
    return 1;
}
