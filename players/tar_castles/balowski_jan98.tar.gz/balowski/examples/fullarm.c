/*
 * This is an armour example
 * ARMOUR supports multi-types and saving in lockers and hotels
 * It also has prevent wear/remove functionality
 *  [considering special wearing bonuses like luck, protection from fire, etc.]
 * 
 * done by Balowski@Nirvana
 */
#include "/players/balowski/lib.h"
inherit ARMOUR;

void create() {
    /* first the usual setting up */
    ::create();
    set_name("full armour");
    set_ids(({ "armour" }));
    set_short("Complete set of armour");
    set_long("This armour is of types: armor, helmet and amulet.\n");
    set_weight(5);
   
    /* this is the armour specific setting up */
    /* set_type accepts either a string, "shield" for example */
    /* or an array of strings as show below */
    set_type(({ "armor", "helmet", "amulet", }));
    /* set the class of this armour */
    set_ac(6);
    /* size is not commonly used. valid values: "XS" to "XL" (or 1 to 5) */
    set_size("S");
}

/* the prevent_* functions can be overloaded to prevent wear and/or remove */
status prevent_wear(object who) {
    string race;
    race = (string)who->query_race();
    if (race != "dwarf" && race != "human") {
	tell_object(who, "Only dwarves and humans can wear it.\n");
	return 1;
    }
    /* never return 0, always do this! it takes care of basic game rules */
    return ::prevent_wear(who);
}

/* prevent_remove is check when player tries to drop or remove armour */
/* return 1 to prevent him from doing it */
status prevent_remove(int silently) {
    if (!silently) tell_object(query_worn_by(), "The armour sticks!\n");
    return 1;
    /* if we didn't _always_ return 1 (for prevent), we should do: */
    /*return ::prevent_remove(silently);*/
}
