#include "/players/balowski/lib.h"
inherit WEAPON;

void create() {
    ::create();
    set_name("sword");
    set_short("Two-handed sword");
    set_long("This is a huge sword that you need two hands to wield.\n");
    set_hands(2);
    set_class(20);
}
