/*
 * Stupid little example of how to use the generic object
 * Remember: only inherit if object will be common otherwise clone
 */

inherit "players/balowski/std/portheal";

void
reset(int arg)
{
    ::reset(arg);
    set_name("cheese");
    set_short("A piece of emmenthaler");
    set_long("A delicious piece of Swiss cheese.\n");
    set_charge_name("cheese", "sausages");
    set_verb("eat");
/*
    set_container_value(75);
*/
    set_weight(1);      /* weight for container */
    set_charges(5);
    set_satiate(10);
    set_heal(25);       /* set this last and cost is calculated right.. */

/*  the auto generated message works for this one, but won't always..
    set_messages("You eat a sausage.\n", " eats a sausage.\n");
*/
}
