inherit "/players/balowski/std/work/monster";

void create() {
    object weapon;
    
    ::create();
    Hands = ([ "first hand":0, "second hand":0, "third hand":0, "fourth hand":0 ]);
    set_name("giant");
    set_short("Giant");
    set_gender("male");
    set_level(16);
    set_long("This is a four-armed giant. He looks very terrible.\n");
    weapon = (object) "players/balowski/examples/4handed"->load();
    transfer(weapon, this_object());
    command("wield sword");
}
