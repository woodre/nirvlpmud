inherit "obj/weapon";

void reset(int arg) {
    ::reset(arg);
    if (arg) return;
    set_name("sword");
    set_short("Sword");
    set_long("This is a little sword that you need one hand to wield.\n");
    set_class(15);
}
