#include "/players/balowski/lib.h"
inherit WEAPON;

void create() {
    ::create();
    set_name("sword");
    set_short("Four-handed sword");
    set_long("This is a huge sword that you need four hands to wield.\n");
    set_hands(4);
    set_class(30);
    set_weight(5);
}
