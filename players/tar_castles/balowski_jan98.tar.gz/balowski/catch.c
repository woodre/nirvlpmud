2716:
        ob = find_object(file);
        if (!ob)
            continue;
        ob = clone_object(file);
        if (argument)
            call_other(ob, "init_arg", argument);
        move_object(ob, this_object());


2716:
        if (!(ob = find_object(file))) continue;

        err = catch(ob = clone_object(file));
        if (err) {
            log_file("autoload",
                     query_real_name() +
                     ": failed cloning " + file + " and " + argument +
                     "\n*" + err);
            continue;
        }
        if (argument) {
            err = catch(ob->init_arg(argument));
            if (err) {
                destruct(ob);
                log_file("autoload",
                         query_real_name() +
                         ": failed init " + file + " and " + argument +
                         "\n*" + err);
                continue;
            }
        }
        err = catch(move_object(ob, this_object()));
        if (err) {
            destruct(ob);
            log_file("autoload",
                     query_real_name() +
                     ": failed moving " + file + " and " + argument +
                     "\n*" + err);
            continue;
        }
