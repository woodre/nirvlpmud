string set_type(string str);
