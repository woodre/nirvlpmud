/*
 *
 */
#include "/players/balowski/lib.h"
#include "path.h"
inherit ROOM;

void
create()
{
    ::create();
    set_short("A balcony");
    set_long("\
You are on the balcony well above the sparring arena. From here you\n\
will have a splendid view of the fighting below, without getting any\n\
blood on your garments. You can also cheer and yell at the combatants.\n\
A staircase leads back down.\n\
");
    set_exits(([
        "down"      :PATH + "hall",
        ]));
    set_light(1);
}

void
long(string arg)
{
    object room, ob;
    string s;

    ::long(arg);
    if (arg) return;
    if (!(room = find_object(PATH + "arena"))
    ||  !(ob = first_inventory(room)))
        write("The arena is secluded.\n");
    else {
        write("\nIn the arena below you can see:\n");
        for ( ; ob ; ob = next_inventory(ob))
            if (s = (string) ob->short()) write(s + ".\n");

        if (this_player() != first_inventory(this_object())
        ||  next_inventory(this_player()))
            write("\nAlso on the balcony:\n");
    }
}

void
evReceiveMsg(string str)
{
    tell_room(this_object(), "* " + str);
}

void
init()
{
    ::init();
    add_action("cmdCheer", "cheer");
    add_action("cmdYell", "yell");
}

status
cmdCheer(string arg)
{
    object room;

    if (arg) return 0;
    if (!(room = find_object(PATH + "arena"))) {
        write("There is nobody down there.\n");
        return 1;
    }
    write("You cheer enthusiastically.\n");
    say(this_player()->query_name() + " cheers enthusiastically.\n");
        tell_room(room, "From the balcony you hear the wild cheers of " +
                  this_player()->query_name() + ".\n");
    return 1;
}

status
cmdYell(string arg)
{
    object room;

    if (!arg) { notify_fail("Yell what?\n"); return 0;}
    if (!(room = find_object(PATH + "arena"))) {
        write("There is nobody down there.\n");
        return 1;
    }

    write("You yell, \"" + arg + ",\" at the combatants.\n");
    say(this_player()->query_name() + " yells, \"" + arg + ",\" at the combatants.\n");
    tell_room(room, "From the balcony you hear " +
        this_player()->query_name() + "yell, \"" + arg + ".\"\n");
    return 1;
}
