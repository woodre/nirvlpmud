/*
 * This is a sparring arena. You can die without losing experience here
 * It conforms to rules given in /doc/build/RULES/sparing_rooms (file?)
 *   (c) Bal/Ras
 */
#include "/players/balowski/lib.h"
#include "path.h"
inherit ROOM;
status GateClosed;
object Balcony;

void
create()
{
    ::create();
    set_long("\
The air is heavy with the reek of something dreadful, and apparently\n\
long dead. The light brown ground inside the circular arena, which is\n\
somewhere around twenty yard across, is dotted with dried-in pools of\n\
black blood. A portal in the featureless granite walls will lead you\n\
out and nobody is keeping you from leaving.\n");
    set_short("The sparring arena");
    set_exits(([
        "out"       :PATH + "hall",
        ]));
    set_items(([
        ({ "pool", "pools", "blood", }) :
        "The blood of many a fallen warriors tell the tales of great fights,\n" +
        "but fear not for your life, victory belongs to the brave.\n",
        "portal" :
        "The portal is not as elaborately decorated here as it was on the\n" +
        "outside. There is a gate by the portal.\n",
        ]));
    /*set_property("spar area", 1);*/
    set_light(1);
    enable_commands();

    call_other(PATH + "balcony", "???");
    Balcony = find_object(PATH + "balcony");
}

mixed
query_spar_area()
{
    return 1;
}

void
init()
{
    /* a bit of an exception, but probably the best way.. */
    if (this_player()->is_player() &&
        ((int) this_player()->query_pl_k() < 2) &&
        ((int) this_player()->query_level() < 19))
    {
        this_player()->move_player("X#/room/void");
        return;
    }
    ::init();
    add_action("cmdClose", "close");
    add_action("cmdOpen", "open");
}

void
exit(object ob)
{
    if (living(ob)) ob->rm_spar();
    ::exit(ob);
}

void
long(string s)
{
    ::long(s);
    if (!s) write(GateClosed ? "The gate is closed.\n" : "The gate is open.\n");
}

status
cmdClose(string arg)
{
    if (arg != "gate") { notify_fail("Close what?\n"); return 0;}
    if (GateClosed) { write("It is already closed.\n"); return 1;}

    MakeNoise("The gate in the portal to the arena closes.\n", "out");
    write("You close the gate. Nobody will be able to leave out now.\n");
    say(this_player()->query_name() + " closes the gate in the portal.\n",
        this_player());

    GateClosed = 1;
    set_exit("out", 0);
    return 1;
}

status
cmdOpen(string arg)
{
    if (arg != "gate") { notify_fail("Open what?\n"); return 0;}
    if (!GateClosed) { write("It is already open.\n"); return 1;}

    GateClosed = 0;
    set_exit("out", PATH + "hall");

    write("You open the gate.\n");
    say(this_player()->query_name() + " opens the gate in the portal.\n",
        this_player());
    MakeNoise("The gate in the portal opens with a creak.\n", "out");
    return 1;
}

/* Function that returns 1 if it is ok to enter from the outside */
status
QueryOpen()
{
    object ob;

    if (!GateClosed) return 1;
    for (ob = first_inventory(this_object()); ob; ob = next_inventory(ob))
        if (interactive(ob)) break;
    return (!ob);
}

/*
 * the say(s) function also sends s to the room if it is alive
 * this way I can catch things like "Smurf died.\n"
 * assumption is that the messages I need to intercept are say'ed
 */
void catch_tell(string msg)
{
    string who;
    
    if (objectp(Balcony))
        Balcony->evReceiveMsg(msg);
    if (msg && sscanf(msg, "%s died.\n", who))
        call_out("ev_death", 1, who);
}

void ev_death(string who)
{
    object ob, next, corpse, room;

    next = first_inventory(this_object());
    while (ob = next) {
        next = next_inventory(ob);

        if (ob->is_player() && ob->query_ghost()) {
            tell_room(this_object(), "Some mist blows away.\n", ({ ob }));
            tell_object(ob, "\nA sudden gust of wind blows you to a different place.\n\n");
            room = clone_object(PATH + "revive");            
            move_object(ob, room);
            if (corpse = present("corpse of " + ob->query_real_name(),
                                 this_object())) {
                /* make sure the while loop can continue smoothly */
                if (next == corpse)
                    next = next_inventory(corpse);
                move_object(corpse, room);
            }
        }
    }
}
