/*
 *
 */
#include "/players/balowski/lib.h"
#include "path.h"
inherit ROOM;

void
create()
{
    ::create();
    set_long("\
You were killed in the sparring match and have been transported to\n\
a private revival room. Your surroundings are frail and will forever\n\
vanish the moment you leave. A fluctuating yellow light marks the\n\
exit 'out'. Pray to return to your mortal state.\n");
    set_short("The revival room [out]");
    set_property("no teleport", 1);
    set_light(1);
}

mixed
cmd_out(string str)
{
    write("You hear the room implode behind you.\n");
    this_player()->move_player("out#" + PATH + "hall");
    destruct(this_object());
    return 1;
}

void
init()
{
    ::init();
    add_action("cmd_pray", "pray");
    add_action("cmd_out", "out");       /* exception.. */
}

status
cmd_pray(string str)
{
    return (status) this_player()->remove_ghost();
}
