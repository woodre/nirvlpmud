/*
 *
 */
#include "/players/balowski/lib.h"
#include "path.h"
inherit ROOM;

mixed
north(string verb, string arg)
{
    if ((int) this_player()->query_pl_k() < 2) {
        write("You are not yet ready to enter.\n");
        return 1;
    }
    if (call_other(PATH + "arena", "QueryOpen"))
        return (PATH + "arena");

    write("The arena is currently in use and the portal is closed.\n");
    return 1;
}

void
create()
{
    ::create();
    set_short("Entrance to a sparring arena");
    set_long("\
You are at the entrance to the sparring arena. To your north there\n\
is a huge portal in the tall granite wall of the circular arena. Its\n\
archway is lined with rugged skulls and sneering demons. A staircase\n\
on the outside of the arena leads up to a balcony. You notice a pole\n\
that has been hammered into the black barren soil on the right side\n\
of the looming portal. There is a sign mounted on the pole.\n\
A path south leads away from the arena.\n");
    set_sign("sign", PATH + "clue");
    set_exits(([
        "south"     :"/room/vill_green",
        "north"     :this_object(),
        "up"        :PATH + "balcony",
        ]));
    set_items(([
        "portal":"Go north through the portal to enter the combat area.\n",
        "staircase":"The staircase winds up and around the arena.\n",
        "pole":"It is just a wooden pole with a sign mounted on it.\n",
        ]));
    set_light(1);
}
