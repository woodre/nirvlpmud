inherit"obj/treasure";

reset(arg){
   set_id("gypsy_curse");
   set_short();
   set_long();
   set_weight(0);
   set_value(0);
}
drop() {return 1;}
get() {return 1;}
