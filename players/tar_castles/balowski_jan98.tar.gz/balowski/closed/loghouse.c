#include "/players/balowski/lib.h"
inherit ROOM;

void create() {
  object ob;

  ::create();
  set_short("A loghouse");
  set_long("\
You are inside a small loghouse.  The air is dry and warm and smells\n\
pleasantly of the birchwood burning in the fireplace.  Spread out on\n\
the wooden floor lies a thick brown pelt.  There is a single door in\n\
the western wall.\n");
  set_items(([
    "pelt" : "\
The fur of the pelt is long and soft.  This would be an ideal place to\n\
cuddle up on in front of the fireplace.\n",
    "door" : "\
The heavy door fits the doorway perfectly and will keep any cold and\n\
stormy weather out.\n",
  ]));
  set_exits(([
    "out" : "/players/balowski/workroom",
    "west" : "/players/balowski/workroom",
  ]));
  set_light(1);
  ob = clone_object("/players/saber/fur/fireplace");
  move_object(ob, this_object());
  ob = clone_object("/players/saber/fur/bed");
  move_object(ob, this_object());
}
