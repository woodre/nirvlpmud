#define NAME "post_dir/"
inherit "/obj/mail_reader";

read(string arg) {
    loaded = 0;
    is_reading = 1;
    if (!loaded) {
	load_player(arg);
	if (arr_messages == 0) {
	    write("No mail.\n");
	    return 1;
	}
    }
    loop();
    return 1;
}

load_player(string arg) {
    loaded = 1;
    if (!restore_object(NAME + arg) || messages == "" || messages == 0) {
	arr_messages = 0;
	messages = "";
	return;
    }
    arr_messages = explode(messages, "\n**\n");
}
