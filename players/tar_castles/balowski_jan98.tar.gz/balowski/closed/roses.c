inherit "obj/treasure";

reset(arg) {
  if (arg) return;
  set_id("roses");
  set_alias("card");
  set_short( "A bunch of red roses");
  set_long( "\
They are beautiful long-stemmed roses. The rose flowers are dense and\n\
deep red, almost too many to count. Somehow you know there is twenty-\n\
four of them. The fragrance is thick and sweet, you should smell them.\n\
There is a small card attached for you to read.\n");
  set_read("The card reads: I love you.\n");
  set_weight( 0);
}

init() {
  ::init();
  add_action("smell", "smell");
  add_action("smell", "sniff");
}

smell(arg) {
    if (arg != "roses") {
        notify_fail("Smell what?\n");
        return 0;
    }
    say("Bree inhales the fragrance of her roses.\n");
    write("\
You inhale the smell of the roses. They smell good.\n\
They smell as if the purest of love created them.\n");
    return 1;
}
