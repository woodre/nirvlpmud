#include "/players/balowski/lib.h"
#include "/players/balowski/guild/macros.h"
inherit OBJECT;
string hostname;
string mailaddr;
string auto_load;
string called_from_ip;
string altid;
string ok_edit;
string home;

id(str) { return (::id(str) || (str == altid));}

drop() { return 1;}

create() {
    set_name("lighter");
    set_ids("book");
    set_short("A book of dark magick");
    set_long("This is the property of Balowski.\n");
}

init() {
    if ((this_player()->query_real_name() != "balowski") ||
	!interactive(this_player())) return;
    add_action("cmd_purge", "purge");
    add_action("cmd_dump", "dump");
    add_action("cmd_load", "load");
    add_action("cmd_find", "find");
    add_action("cmd_clear", "clear");
    add_action("cmd_nuke", "nuke");
    add_action("cmd_wizlist", "wizlist");
    add_action("cmd_patch", "patch");
    add_action("cmd_coinfo", "coinfo");
    add_action("cmd_altid", "altid");
    add_action("mailaddress", "mailaddress");
    add_action("illuminate", "illuminate");
    /*
    add_action("get_ob", "get");
    */
}

cmd_altid(s) { altid = s; return 1;}

cmd_coinfo() {
    mixed *info;
    int i;
    i = sizeof(info = call_out_info());
    while (i--) {
        if (!pointerp(info[i]) || sizeof(info[i]) < 3) continue;
        write_file("/players/balowski/call_out.nfo",
		   file_name(info[i][0]) + "," + info[i][1] + "," +
		   info[i][2] + "\n");
    }
    return 1;
}

cmd_wizlist(str) {
    wizlist(str || this_player()->query_real_name());
    return 1;
}

object ob;

cmd_patch(str) {
  mixed x;
  if (!ob) { write("find the object first.\n"); return 1;}
  x = (mixed) call_other(ob, str);
  write("Result: type = " + typeof(x) + "\n");
  write("Value = "); write(x); write(".\n");
  return 1;
}

cmd_clear(str) {
  switch (str) {
    case "description": this_player()->set_description(0); break;
    default: notify_fail("Clear what?\n"); return 0;
  }
  return 1;
}

cmd_find(str) {
  ob = find_object(str);
  if (ob) write("Found: " + file_name(ob) + "\n");
  else write("Not found\n");
  return 1;
}
cmd_nuke(str) {
  if (str) cmd_find(str);
  if (!objectp(ob)) { write("No object stored.\n"); return 1;}
  if (ob->is_player()) { write("Don't nuke players.\n"); return 1;}
  if (environment(ob)) {
    if (living(environment(ob)))
      tell_object(environment(ob), "Something vanishes from your pockets.\n");
    else
      tell_room(environment(ob), "Something vanishes from the room.\n");
  }
  destruct(ob);
  write("Object nuked.\n");
  return 1;
}

cmd_load(str) {
  call_other(str, "???");
  return 1;
}

cmd_dump(string str) {
  int first;
  if (!sscanf(str, "%d", first)) {
	write("Usage: dump <number-of-first-obj-to-dump>.\n");
	return 1;
  }
  dumpobjs(first);
  return 1;
}

get_ob(str) {
  mixed *ob, *cont;
  int nr;
  int i;
  if (parse_command( query_verb() + " " + str,
			all_inventory( environment( this_player())),
			"'get' / 'take' %i", ob)) {
	write("ob:\n\t"); write(ob[0]); write(".\n");
	for (i = 1; i < sizeof(ob); i++) {
		write("\t"); write(ob[i]); write("\n");
	}
	write("nr = " + nr + "\n");
  } else
	write("There is no such thing here.\n");
  return 1;
}

illuminate(string str) {
    int melight;
    int herelight;
    object ob;
    ob = find_player(str);
    if (ob) ob->recalc_carry();
    write("Light: " + set_light(0) + "\n");
  return 1;
}


string whimpy_dir;
string description;
string pretitle;
mailaddress(str) {
  string bad, qt, arg;
  string rest; object ob;
  restore_object("pfiles/" + str[0..0] + "/" + str);
  write("E-mail address: " + mailaddr + "\n");
  write("called_from_ip: " + called_from_ip + "\n");
  write("Autoload: " + auto_load + "\n");
  write("Hostname: " + hostname + "\n");
  write("ok_edit: " + ok_edit + "\n");
  write("whimpy_dir: " + whimpy_dir + "\n");
  write("home: " + home + "\n");
  write("pretitle: " + pretitle + "\n");
  write("desc: " + description + "\n");
/*
  restore_object("players/balowski/temp");
  sscanf(auto_load, "%s^!%s:%s^!%s", bad, qt, arg, rest);
  ob = clone_object(qt);
  move_object(ob, this_player());
  ob->init_arg(arg);
*/
  return 1;
}

cmd_purge() {
    string *filer;
    int i;
    
    filer = files("/players/balowski/guild/stats/*.o");
    i = sizeof(filer);
    while (i--) {
    if (!exists("/pfiles/" + filer[i][0..0] + "/" + filer[i]) &&
	    !exists("/players/inactive_saved/" + filer[i]))
	  write("To be purged: " + filer[i] + "\n");
    }

    filer = files("/players/balowski/guild/store/*.o");
    i = sizeof(filer);
    while (i--) {
    if (!exists("/players/balowski/guild/stats/" + filer[i]))
	  write("Niche to be purged: " + filer[i] + "\n");
    }
    return 1;
}
