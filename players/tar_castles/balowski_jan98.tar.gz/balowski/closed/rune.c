#include "/players/llew/closed/ansi.h"
#define LEGAL ({"n","s","e","w","ne","nw","se","sw","u","d","out","leave","exit","enter"})
#define ENV environment()

inherit "obj/treasure";

string commands;

reset(arg) {
   if(arg) return;
   commands=0;
   set_id("rune");
   set_alias("speed");
   set_short(BLU+"Rune"+NORM);
   set_value(0);
   set_weight(0);
   set_long("\n"+
      "The Rune of Speed is commanded by rs <com1>,<com2>,<com3>,etc...\n"+
      "There is no maximum to how many commands may be entered in the\n"+
      "Rune.  Five commands will be carried out, the rest passed to the\n"+
      "next round.  For a list of available commands type rs commands.\n"+
      "To kill your buffer of commands type rs stop.  Unravel the Rune\n"+
      "by typing rs-destroy.\n\n"
   );
   set_dest_flag(1);
}

drop() { return 1; }
get() { return 0; }
query_auto_load() {
   return "/players/llew/misc/rune.c:";
}

init() {
   ::init();
   add_action("rune_speed","rs");
   add_action("trash","rs-destroy");
}

rune_speed(com) {
   if(!com) return 0;
   if(com == "commands") {
      write(HIB+"\nCommands available in the Rune are:\n"+NORM+implode(LEGAL,", ")+"\n\n");
      return 1;
   }
   if(com == "stop") {
      write("The "+HIB+"Rune"+NORM+" flashes.\n");
      commands=0;
      remove_call_out("do_commands");
      return 1;
   }
   if(!commands) do_commands(com);
   else commands=commands+","+com;
   return 1;
}

do_commands(com) {
   int count;
   string do_com,junk;
   count=0;
   if(com) commands=com;
   tell_object(ENV,"The "+HIB+"Rune"+NORM+" glows.\n");
   while(count < 5 && sscanf(commands,"%s,%s",do_com,commands)==2) {
      if(sscanf(do_com,"enter %s",junk) || member_array(do_com,LEGAL) > -1)
         command(do_com,ENV);
      else tell_object(ENV,"Command, "+do_com+", is illegal.  Skipping command.\n");
      count++;
   }
   if(count < 5) {
      if(sscanf(commands,"enter %s",junk) || member_array(commands,LEGAL) > -1)
         command(commands,ENV);
      else tell_object(ENV,"Command, "+do_com+", is illegal.  Skipping command.\n");
      commands=0;
   }
   if(commands=="") commands=0;
   tell_object(ENV,"The "+HIB+"Rune"+NORM+" fades.\n");
   if(commands) call_out("do_commands",3);
}

trash() {
   write("The "+HIB+"Rune"+NORM+" fades to oblivion.\n");
   destruct(this_object());
   return 1;
}
