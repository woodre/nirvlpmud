#include "../lib.h"
inherit ITEM;
static string *list;
string name, hostname, called_from_ip;

void create()
{
        set_name("scanner");
        set_short("An address scanner");
        set_property("prevent drop", "The scanner is glued to your hand.\n");
        list = ({ });
}

void init()
{
        if (this_player() == environment()) {
                add_action("cmdScan", "scan");
                add_action("cmdScansave", "scansave");
        }
}

status cmdScan(string arg)
{
        string *noms;
    string str, nom;
    int i,j;

    i = sizeof(noms = files("/pfiles/" + arg + "/" + "*"));
        while (i--) {
    if (arg[0] != noms[i][0]) continue;
    if (sscanf(noms[i], "%s.o", nom) != 1) continue;
    j++;
    str = "pfiles/" + arg[0..0] + "/" + nom;
    restore_object(str);
                list += ({ name + "," + hostname + "," + called_from_ip });
        }

    write(j + " names scanned in " + arg + ".\n");
        return 1;
}

status cmdScansave(string arg)
{
        string *noms;
        int i;

  i = sizeof(list);
        while (i--) {
                write_file(arg, list[i] + "\n");
        }
    list = ({ });
        return 1;
}
