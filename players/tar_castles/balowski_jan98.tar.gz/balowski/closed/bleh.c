#include "lib.h"
inherit BASE;

void create() {
  shadow(find_object("/players/sado/rooms/prison"), 1);
}
init() {
}
exit() { }
