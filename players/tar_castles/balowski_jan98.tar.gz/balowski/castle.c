void nuke() { destruct(this_object());}

void
reset(int arg)
{
    if (arg)
	return;
    "players/balowski/guild/mark"->xx();
	"players/balowski/guild/obj/allymark"->xx();
  call_other("players/balowski/guild/obj/quick", "");
  call_other("players/balowski/obj/titles", "");
/*
    call_other("players/balowski/obj/eng_ring", "");
  call_other("players/balowski/obj/whistle", "");
*/
  call_other("players/balowski/obj/ctellsay", "");
    call_out("nuke", 1);
}
