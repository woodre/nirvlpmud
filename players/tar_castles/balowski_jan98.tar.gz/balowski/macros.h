#define wizardp(ob) ((int) ob->query_level() > 19)
