#include "/players/balowski/lib.h"
inherit MONSTER;

void create()
{
    ::create();
    set_name("Worm");
    set_short("A large worm");
    set_long("\
This is about the largest earthworm you have ever seen. It is about\n\
half a meter long and has an extraordinary tough hide and a mouth\n\
jumbled with small pointy teeth. Your presence seems to annoy it.\n");
    set_level(8);
    set_al(-50);
    set_aggressive(50);
    set_env("mmsgin", "pops out of the ground");
}
