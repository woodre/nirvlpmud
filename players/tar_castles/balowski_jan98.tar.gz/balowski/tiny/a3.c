#include "/players/balowski/lib.h"
inherit ROOM;

void create()
{
    ::create();
    set_short("limbo");
    set_long("\
You are in oblivion. You have no recollection of who you are or where\n\
you have been. You feel nothing, you sense nothing, yet you know that\n\
you are. And that you can go north, east, south, and west.\n\
");
    set_items(([
	"oblivion":"It is the gooey yellow stuff that permeates everything here.\n",
	"recollection":"What does it mean?\n",
    ]));
    add_smell("default", "It is rather musty here.\n");
    add_sound("default", "It is extremely silent (you cannot hear).\n");
    set_exits(([
	"north": 0,
	"south": "/players/balowski/tiny/b3",
	"east" : 0,
	"west" : "/players/balowski/tiny/a2",
    ]));
    set_light(1);
}
