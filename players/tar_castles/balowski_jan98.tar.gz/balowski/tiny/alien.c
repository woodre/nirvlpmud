#include "/players/balowski/lib.h"
inherit MONSTER;

void create()
{
    ::create();
    set_name("Alien");
    set_short("A harvesting alien");
    set_long("\
Almost perfectly camouflaged in its thick close-fitting suit of a\n\
green fabric, the strange looking being is prowling about the field.\n\
It is humanoid in shape, but deviates in some respects. To each of\n\
its two upper arms, two forearms are attached, and all four three-\n\
fingered hands are being put to good use gathering the crop.\n\
It is carrying a shiny metal container in a leather strap.\n");
    set_level(15);
    set_al(-50);
    set_aggressive(0);
    set_chat_chance(10);
    load_chats(({
	"The alien merrily sings: Grlln imw imw ftkl\n",
	"The alien snaps off a fruit and puts it in its container.\n",
	"The alien blinks its almost transparent eyelids.\n",
    }));
}
