#include "/players/balowski/lib.h"
inherit ROOM;

void create()
{
    ::create();
    set_short("alien fields");
    set_long("\
The black fertile soil lies softly beneath your feet. A recent shower\n\
has made the ground wet and sticky, and the plants seem to like this:\n\
There are small green sprouts coming up in lines straight as arrows.\n\
");
    add_smell("default", "You can clearly smell the good humus.\n");
    set_items(([
	"soil" : "It is black and supposedly very fertile.\n",
	"sprouts" : "They are much too young to tell what they are.\n",
    ]));
    set_exits(([
	"north": "/players/balowski/tiny/b2",
	"south": 0,
	"east" : "/players/balowski/tiny/c3",
	"west" : "/players/balowski/tiny/c1",
    ]));
    set_light(1);
}
