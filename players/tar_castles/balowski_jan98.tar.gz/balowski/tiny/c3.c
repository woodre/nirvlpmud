#include "/players/balowski/lib.h"
inherit ROOM;

void create()
{
    ::create();
    set_short("alien fields");
    set_long("\
The black fertile soil lies softly beneath your feet. Everywhere you\n\
see little green sprouts pushing their way up into the sunlight. The\n\
field stretches west and north.\n\
");
    add_smell("default", "You can clearly smell the good humus.\n");
    set_items(([
	"soil" : "It is black and supposedly very fertile.\n",
	"sprouts" : "You wonder what sort they are.\n",
    ]));
    set_exits(([
	"north": "/players/balowski/tiny/b3",
	"south": 0,
	"east" : 0,
	"west" : "/players/balowski/tiny/c2",
    ]));
    add_monster("/players/balowski/tiny/worm", 5, 1);
    set_monster_frequency(10);
    set_light(1);
}
