#include "/players/balowski/lib.h"
inherit ROOM;

void create()
{
    ::create();
    set_short("alien fields");
    set_long("\
You are on a small rise in the middle of the field. There is a good\n\
view from here. The crop is denser and taller the further north you\n\
go and the opposite is true if you go south. Where you stand the plants\n\
almost reach your waist.\n\
In a depression west from here you can see some sort of machinery.\n\
");
    add_smell("default", "You can clearly smell the good humus.\n");
    set_items(([
	"soil" : "It is black and supposedly very fertile.\n",
	"plants" : "Could it be corn?\n",
    ]));
    set_exits(([
	"north": "/players/balowski/tiny/a2",
	"south": "/players/balowski/tiny/c2",
	"east" : "/players/balowski/tiny/b3",
	"west" : "/players/balowski/tiny/b1",
    ]));
    set_light(1);
}
