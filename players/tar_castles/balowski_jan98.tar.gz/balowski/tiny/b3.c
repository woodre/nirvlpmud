#include "/players/balowski/lib.h"
inherit ROOM;

void create()
{
    ::create();
    set_short("alien fields");
    set_long("\
You are walking along the eastern rim of the field. Fine green plants\n\
have grown waist-high from the black fertile soil. There is a rise in\n\
the terrain to the west.\n\
");
    add_smell("default", "You can clearly smell the good humus.\n");
    set_items(([
	"soil" : "It is black and supposedly very fertile.\n",
	"plants" : "They need to be fully grown before you can identify them.\n",
    ]));
    set_exits(([
	"north": "/players/balowski/tiny/a3",
	"south": "/players/balowski/tiny/c3",
	"east" : 0,
	"west" : "/players/balowski/tiny/b2",
    ]));
    set_light(1);
}
