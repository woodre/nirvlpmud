#include "/players/balowski/lib.h"
inherit ROOM;

void create()
{
    ::create();
    set_short("alien fields");
    set_long("\
You are in a quite large and barren depression on the otherwise fer-\n\
tile field. A large and streamlined machine of sleek metal has been\n\
left here. The earth is scorched in the proximity of the machine.\n");
    add_smell("default", "There is a smell of burning here.\n");
    set_items(([
	"earth" : "\
It is black and crisp as if a jet of fire had hit it.\n\
There are footmarks leading north and away from the machine.\n",
	"machine" : "\
It is the strangest looking contraption you have seen in a long time.\n\
It looks large enough to hold at least one stalwart man, but there is\n\
no visible entrance. The sound it makes when you knock on the hull\n\
clearly indicates that the thing is hollow.\n",
    ]));
    set_exits(([
	"north": "/players/balowski/tiny/a1",
	"south": "/players/balowski/tiny/c1",
	"east" : "/players/balowski/tiny/b2",
	"west" : 0,
    ]));
    set_light(1);
}
