/*
 * Room thingy for 3.1.2-DR, Nirvana
 * Inspired by Foundation/Nightmare..
 */

#include "portable.h"

private string  RoomShort;      /* brief description */
private string  RoomLong;       /* Long description of the room */
private mapping exits;          /* of format direction:file */
private mapping items;          /* lookables */
private mapping props;          /* properties like "mo nagic" :^) */
private int     MaxCastles;     /* allow castle drop? */
private status  NoClean;        /* set to stop self destruct on idle */

void
create()
{
    exits = ([ ]);
    items = ([ ]);
    props = ([ ]);
}

void
reset(int arg)
{
    if (!arg)
	create();
}

status
id(string str)
{
    return (str && stringp(items[str]));
}

string
short()
{
    if (set_light(0))
	return RoomShort;
    return "Dark room";
}

void
long(string str)
{
    if (!set_light(0))
       write("It is dark.\n");
    else
	if (str)
	    write( items[str]);
	else
	    write( RoomLong);
}

status
move(string str)
{
    mixed       exit;

    if (exit = exits[query_verb()]) {
	if (objectp(exit))
	    return (status) call_other(exit, query_verb(), str);
	if (stringp(exit))
	    this_player()->move_player(query_verb() + "#" + exit);
	return 1;
    }
    notify_fail("You cannot go that way.\n");
    return 0;
}

void
init()
{
    int         i;
    mixed       *ks;

    if (props["fight area"])
	this_player()->set_fight_area();

    /* okay, so this isn't pretty.. can't have it all */
    i = sizeof( ks = m_indices(exits));
    while (i--)
	add_action("move", ks[i]);
}

string
realm()
{
    return (props["no teleport"] ? "NT" : 0);
}

/*
 * The long description of the room,
 * The command look should show this
 */
void
set_long(string str)
{
    RoomLong = str;
}

string
query_long()
{
    return RoomLong;
}

/*
 * Room exits, this sucks a little *shrug*
 * Adding and removing exits can be done though, just don't like it
 */
void
set_exits(mapping m)
{
    exits += m;
}

/*
 * Items to look at .. more or less pinched from foundation
 * piffed up a little, but I don't like all these if's and while's
 * Changable on the fly!
 */
void
set_items(mapping m)
{
    int         i, j;
    mixed       *ks;

    i = sizeof( ks = m_indices( m));
    while (i--) {
	if (pointerp( ks[i])) {
	    j = sizeof( ks[i]);
	    while (j--)
		items[ks[i][j]] = m[ks[i]];
	}
	else
	    items[ks[i]] = m[ks[i]];
    }
}

void
add_item(mixed id, string desc)
{
    int         j;

    if (pointerp( id)) {
	j = sizeof( id);
	while (j--)
	    items[id[j]] = desc;
    }
    else
	items[id] = desc;
}

void
remove_item(mixed id)
{
    int         j;

    if (pointerp( id)) {
	j = sizeof( id);
	while (j--)
	    m_delete( items, id[j]);
    }
    else
	m_delete( items, id);
}

/*
 * Special properties of the room
 * For instance set "no magic" to 1
 */
mixed
query_property(string p)
{
    return props[p];
}

void
add_property(string p, mixed v)
{
    props[p] += v;
}

void
set_property(string p, mixed v)
{
    props[p] = v;
}

void
set_properties(mapping m)
{
    props += m;
}

/*
 * The short description of the room should be one line,
 * without newline. It is for players with brief set on
 */
void
set_short(string s)
{
    RoomShort = s;
}

string
query_short()
{
    return RoomShort;
}

/*
 * This determines if wizard can drop castles here
 * default is 0, which means not allowed
 */
void
set_max_castles(int value)
{
    MaxCastles = value;
}

int
query_drop_castle()
{
    return MaxCastles;
}

void
set_no_clean(status stop)
{
    NoClean = stop;
}

/*int*/
clean_up(int refcount)
{
    object ob;

    if (NoClean)
	return 0;       /* never again */
    if (refcount)       /* expected to be zero (no clones) */
	return 1;       /* try later */
    if (sizeof(users() & all_inventory()))
	return 1;
    destruct(this_object());
}
