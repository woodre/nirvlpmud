inherit "obj/monster";

