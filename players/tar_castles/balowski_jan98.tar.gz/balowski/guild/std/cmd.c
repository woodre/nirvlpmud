/*
 * A base object for the command objects
 * Balowski@Nirvana, July '95
 */
#include "/players/balowski/lib.h"
inherit BASE;

/*
 * if refcount > 0 then this is an inherited object
 * and one shouldn't destruct it
 * return non-zero if clean_up should be called later
 */
void
clean_up(int refcount)
{
    if (!refcount)
        destruct(this_object());
}

/*
 * Disallow shadowing (unless priviledged in shadow master)
 */
status
query_prevent_shadow(object shadow)
{
    return 1;
}
