#ifndef _DAEMONS_H_
#define _DAEMONS_H_

#define DIR_GUILD_DAEMONS "/players/balowski/guild/daemons/"

#define HOARDD (DIR_GUILD_DAEMONS + "gold")
#define LOCKERD (DIR_GUILD_DAEMONS + "locker")
#define ACTIOND (DIR_GUILD_DAEMONS + "actions")
#define LOGD (DIR_GUILD_DAEMONS + "logd")
#define SAVEFILED (DIR_GUILD_DAEMONS + "savefile")

#endif
