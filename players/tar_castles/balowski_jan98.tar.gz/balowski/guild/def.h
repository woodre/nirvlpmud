/*
 * Shardak guild (tm) Dragnar/John + Balowski/Rasmus
 * General include file
 */
/* directories */
#define BINDIR "/players/balowski/guild/cmds/"
#define OBJDIR "/players/balowski/guild/obj/"
#define LOGDIR "/players/balowski/guild/log/"
#define HELPDIR "/players/balowski/guild/helpdir/"
#define DAEMONDIR "/players/balowski/guild/daemons/"
#define PATH "players/balowski/guild/room/"
#define ABSPATH "/players/balowski/guild/room/tales/"
#define SAVE_PATH "players/balowski/guild/stats/"
#define STORE_PATH "players/balowski/guild/store/"

/* daemons */
#define CHANNELD "players/balowski/guild/daemons/channel"
#define SHARDAK "players/balowski/guild/room/shardak"

/* objects */
#define GUILDOBJ "players/balowski/guild/mark"
#define AUTOLOAD "players/balowski/guild/mark:0"

/* guild news */
#define NEWS "/players/balowski/guild/news"

/* names */
#define GUILDNAME "shardak"
#define OBJID "shardak_mark"
#define GUILD_ID OBJID

/* special rooms */
#define LOGIN "players/balowski/guild/room/grotto"
#define SHOP "players/balowski/guild/room/shop"
#define DEST "players/dragnar/rooms/arena"
#define RACKS (PATH + "racks")
