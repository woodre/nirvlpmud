/* macros */
#define qhp(OB) ((int) OB->query_hp())
#define qmhp(OB) ((int) OB->query_mhp())
#define uhp qhp(this_player())
#define umhp qmhp(this_player())

#define qsp(OB) ((int) OB->query_sp())
#define qmsp(OB) ((int) OB->query_msp())
#define usp qsp(this_player())
#define umsp qmsp(this_player())

/* wizard invisibility check */
#define inwizible(OB) ((int) OB->query_invis() > 18)
#define wizardp(OB) ((int) OB->query_level() >= 20)
#define capname ((string) this_player()->query_name())

#define needrank(L) \
if (this_player()->query_guild_rank() < L) {\
    notify_fail("Your guild rank is too low.\n");\
    return 0;\
}
#define needtask(T) \
if (!previous_object()->query_solved(T)) {\
    notify_fail("You haven't passed the trial.\n");\
    return 0;\
}
#define needmana(S) \
if (qsp(this_player()) < S) {\
    write("You do not have enough spell points to sacrifice.\n");\
    return 1;\
}
#define nomagic(S) \
if (!environment(this_player())\
||  S <= (int) environment(this_player())->query_property("no magic")) {\
    write("The enchanted surroundings cause your spell to fail.\n");\
    return 1;\
}
#define servant(O) (present("shardak_mark", O))
#define friend(O) (present("shardak_mark", O) || present("allymark", O))
