#define CMD     "/players/balowski/guild/std/cmd"
