/*
 * Shardak guild is (tm) Dragnar/John
 * Change log:
 * 950422 - created
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../def.h"
#include "../daemons.h"
#include "../people.h"
#include "../macros.h"
#include <security.h>
#ifndef __FILE__
#define __FILE__ file_name(this_object())
#endif

inherit ROOM;
static object	Shardak;

void
create()
{
    ::create();
    set_short("The throne room");
    set_long("\
This is the grand throne room. The domed ceiling is barely visible\n\
high up in the dim light. Your footsteps echo loudly on the black\n\
marble tiles as you approach the throne. The three steps leading up\n\
to the throne are covered with the golden hoard belonging to the\n\
dragon-man sitting upon it, Shardak. On each side stands a high-\n\
backed oak chair, upon which sit Shardak's second in command, Dragnar,\n\
and the dark magus, Balowski.\n\
A passage leads west and another one east.\n\
There is a staircase leading down to the senior's room.\n\
A low exit in the southern wall leads back into the tunnel.\n");

    set_exits(([
	"south" : (PATH + "deepdown"), 
	"west" : (PATH + "niches"),
	"east" : this_object(),
	"northwest" : this_object(),
	"northeast" : this_object(),
        "down" : this_object(),
	]));
    set_light(1);
    set_property("fight area", 1);
    set_property("no teleport", 1);

    call_other(PATH + "shardak", "");
    Shardak = find_object(PATH + "shardak");
    move_object(Shardak, this_object());
}

status
down(string arg)
{
   object gob;

   if (arg) return 0;
   if ((gob = present(GUILD_ID, this_player())) &&
       (gob->GuildClass() >= C_BERSERKER))
      return PATH + "seniorroom";
   write("You are not allowed in there.\n");
   return 1;
}

status
east(string arg)
{
    object      gob;            /* guild object */

    if (arg) return 0;
    if ((gob = present(GUILD_ID, this_player())) &&
	((int) gob->GuildClass() >= C_LAW))
      return PATH + "lawroom";

    write("You are not allowed in there.\n");
    return 1;
}
	
/*
 * Two functions called by ROOM
 */
status
northwest(string arg)
{
    if (!arg) {
	if ((int) this_player()->query_level() < 20) {
	    write("You bounce off the force field.\n");
	    say(this_player()->query_name() + " is repelled by the force field.\n");
	}
	else
	    this_player()->move_player("northwest#players/balowski/workroom");
	return 1;
    }
    return 0;
}

status
northeast(string arg)
{
    if (!arg) {
	if (this_player()->query_level() < 20) {
	    write("You bounce off the force field.\n");
	    say(this_player()->query_name() + " is repelled by the force field.\n");
	}
	else
	    this_player()->move_player("northwest#players/dragnar/workroom");
	return 1;
    }
    return 0;
}

/*
 * Two additional actions
 */
void
init()
{
    ::init();
    add_action("page", "worship");
    add_action("abandon", "abandon");

    add_action("cmd_donate", "donate");
    add_action("cmd_borrow", "borrow");
    add_action("cmd_return", "return");
}

status
cmd_donate(string arg)
{
    int amt, gold;
    string str;

    if (!friend(this_player())) return 0;
    if (!arg || !sscanf(arg, "%d", amt) || amt <= 0) {
	notify_fail("Donate how much?\n");
	return 0;
    }
    if ((int)this_player()->query_money() < amt) {
	write("You do not have that many gold coins!\n");
	return 1;
    }
    this_player()->add_money(-amt);
    gold = (int)HOARDD->add_donated(this_player()->query_real_name(), amt);

    if (amt == 1) str = "one gold coin"; else str = amt + " gold coins";
    write("You kneel down and donate " + str + " to Shardak's hoard.\n");
    if (amt != gold) {
	if (gold == 1) str = "one gold coin"; else str = gold + " gold coins";
	write("Your donations have now reached a total of " + str + ".\n");
    }
    say(this_player()->query_name() + " kneels down and donates some gold to Shardak's hoard.\n");
    return 1;
}

status
cmd_borrow(string arg)
{
    int amt, gold;
    string str;

    if (!servant(this_player())) return 0;
    if (!arg || !sscanf(arg, "%d", amt) || amt <= 0) {
	notify_fail("Borrow how much?\n");
	return 0;
    }
    gold = (int)HOARDD->query_hoard();
    if (gold/10 < amt) {
	write("Shardak's hoard is slender. There is not enough gold for you to borrow any.\n");
	return 1;
    }
    gold = (int)HOARDD->query_borrowed(this_player()->query_real_name());
    if (gold + amt > 5000) {
	write("Shardak glares angrily at you. It could be that you have borrowed too much.\n");
	return 1;
    }
    this_player()->add_money(amt);
    gold = (int)HOARDD->add_borrowed(this_player()->query_real_name(), amt);

    if (amt == 1) str = "one gold coin"; else str = amt + " gold coins";
    write("You kneel down and scoop " + str + " into your purse.\n");
    if (gold == 1) str = "one gold coin"; else str = gold + " gold coins";
    write("Nervously you promise soon to return the " + str + " that you owe.\n");
    say(this_player()->query_name() + " borrows a little gold from the hoard with Shardak's permission.\n");
    return 1;
}

status
cmd_return(string arg)
{
    int amt, gold;
    string str;

    if (!servant(this_player())) return 0;
    if (!arg || !sscanf(arg, "%d", amt) || amt <= 0) {
	notify_fail("Return how much?\n");
	return 0;
    }
    if ((int)this_player()->query_money() < amt) {
	write("You do not have that many gold coins!\n");
	return 1;
    }
    this_player()->add_money(-amt);
    gold = (int)HOARDD->add_borrowed(this_player()->query_real_name(), -amt);

    if (amt == 1) str = "one gold coin"; else str = amt + " gold coins";
    write("You kneel down and return " + str + " to Shardak's hoard.\n");
    if (gold == 0) {
	write("You have paid back your loan.\n");
    }
    else {
	if (gold == 1) str = "one gold coin"; else str = gold + " gold coins";
	write("Still you owe " + str + " to Shardak.\n");
    }
    say(this_player()->query_name() + " kneels down and returns some gold to Shardak's hoard.\n");
    return 1;
}

/*
 * see if workroom is loaded, if yes, see if wizard is in there
 */
object
find_balowski()
{
    object      room;

    room = find_object("players/balowski/workroom");
    return (room ? present("balowski", room) : 0);
}

object
find_dragnar()
{
    object      room;

    room = find_object("players/dragnar/workroom");
    return (room ? present("dragnar", room) : 0);
}

/* bloody hell, I can't come up with a proper name ;-) */
string
smurf(string *noms)
{
    if (!pointerp(noms) || !sizeof(noms)) return "";
    if (sizeof(noms) == 1)
      return noms[0] + " is present.\n";
    else if (sizeof(noms) == 2)
      return noms[0] + " and " + noms[1] + " are present.\n";
    else {
	int i;
	string tmp;
	for (tmp = "", i = 0; i < sizeof(noms) - 1; i++)
	  tmp += noms[i] + ", ";
	tmp += "and " + noms[i] + " are present.\n";
	return tmp;
    }
}
/*
 * A little addition to the long desc, dunno if I like it though
 */
void
long(string str)
{
    string	*noms;

    ::long(str);
    if (!str) {
	noms = ({ });
	if (Shardak && present(Shardak, this_object()))
	  noms += ({ "Shardak" });
	if (find_dragnar())
	  noms += ({ "Dragnar" });
	if (find_balowski())
	  noms += ({ "Balowski" });
	write(smurf(noms));
    }
}

/*
 * Page a guild wizard in his workroom if emergency
 * On purpose it doesn't check for in_editor()
 * Remember to kill players who abuse this
 */
status
page(string str)
{
    object      wiz;

    str = lower_case(str);
    if ((str == "balowski" && (wiz = find_balowski()))
    ||  (str == "dragnar" && (wiz = find_dragnar()))) {
	tell_object( wiz, (string) this_player()->query_name());
	tell_object( wiz, " wants your attention in the throne room.\n");
	write( "You worship at ");
	write( capitalize(str));
	write( "'s feet.\n");
	say( this_player()->query_name() + " worships at " +
		capitalize(str) + "'s feet.\n");
	return 1;
    }
    return 0;
}

/*
 * Abandon guild *sniff*
 */
static status
abandon(string str)
{
    if (str != "guild")
	return 0;

    write("\
Shardak hisses at you, \"Be aware of the consequences you must suffer\n\
if you confirm your choice. You will lose all powers given to you by\n\
me. You will lose all guild experience you may have amassed. And as a\n\
little extra penalty I will take your life.\"\n\
Confirm your choice with 'yes' : ");
    input_to("confirm");
    return 1;
}

static void
confirm(string str)
{
    int         exp, gxp, rnk;  /* regular exp, guild exp, guild rank */
    object      gob;            /* guild object */

    if (str != "yes") {
	write("You have chosen wisely.\n");
	return;
    }
    if (!(gob = present(GUILD_ID, this_player()))) {
	write("You are not carrying the mark of Shardak.\n");
	return;
    }

    gxp = (int) this_player()->query_guild_exp();
    rnk = (int) this_player()->query_guild_rank();
    exp = (int) this_player()->query_exp();

    if (!intp(gxp) || !intp(rnk) || !intp(exp)) {
	write("Your organism is broken. Contact an arch wizard.\n");
	return;
    }
    write("Shardak hisses, \"I am afraid this may hurt a little.\"\n");
    this_player()->set_guild_name(0);   /* clear guild name */
    this_player()->add_guild_exp(-gxp); /* clear guild experience */
    this_player()->add_guild_rank(-rnk);/* clear guild rank */
    this_player()->set_home(0);         /* clear alternative login room */
    CHANNELD->deregister(gob);          /* remove from member list */
    destruct(gob);                      /* remove the mark of shardak */
					/* remove the guild file */
    rm("/" + SAVE_PATH + this_player()->query_real_name() + ".o");

    if ((int) this_player()->query_level() >= APPRENTICE) {
	write("Wizard are immortals. Skipping final stage.\n");
	return;
    }
    else {
	/* deduct one sixth experience as prescribed by the guild laws */
	/* Note: It is currently one fourth. */

	/* Grab the gold from the player. Equip still goes to corpse */
	int gold;
	gold = (int) this_player()->query_money();
	HOARDD->add_hoard(gold);
	this_player()->add_money(-gold);
#if 0
	this_player()->add_exp(-exp/4);
	this_player()->second_life();
	gob = clone_object("obj/corpse");
	this_player()->transfer_all_to(gob);
	move_object(gob, this_object());
#else
	this_player()->attacked_by(this_object());
	this_player()->hit_player(10000);/* lose one fourth exp */
/* this is out..
	this_player()->add_exp(exp/12);  /* get the desired one sixth */
#endif
	write("Your ghost drifts back to the church.\n");
	move_object(this_player(), "room/church");
	log_file("GUILD", ctime() + ":\n" +
		capitalize((string) this_player()->query_real_name()) +
		" left the Servants of Shardak. By " + __FILE__ + "\n");
    }
}

/*
 * Makes the orbituary nicer..
 */
string
query_real_name()
{
    return "Shardak";
}
