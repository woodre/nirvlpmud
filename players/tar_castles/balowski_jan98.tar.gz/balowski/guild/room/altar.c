/*
 * Shardak guild is (tm) Dragnar/John
 * Change log:
 * 950422 - created
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../def.h"
#include "../tasks.h"

inherit ROOM;

void
create()
{
    ::create();
    set_short("Altar of Sacrifice");
    set_long("\
Following the eastbound gallery have brought you to a high vaulted\n\
cavern. A twenty foot high ornamented brass statue is fit into a\n\
niche in the rock wall.\n\
There is some strange shifting light in the north wall.\n\
Behind you, a gallery leads west.\n\
");
    set_exits( ([
        "west" : (PATH + "deepdown"),
        "north": "/players/balowski/realm/arena/hall",
    ]) );
    set_light(1);
    set_property("fight area", 1);
    set_property("no teleport", 1);
}

void
reset(int arg)
{
    ::reset(arg);
    if (!present("knight", this_object()))
        move_object(clone_object(OBJDIR + "dummy"), this_object());
    if (!present("priestess", this_object()))
      move_object((object) call_other(PATH + "priestes", "load"),
		  this_object());
}
