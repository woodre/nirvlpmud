/* 
 * Shardak guild - (tm) Dragnar/John
 * Shardak is (c) Balowski/Rasmus, August 4th 1996.
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../def.h"
#include "../tasks.h"

inherit MONSTER;
static object *Intruders, *Victims;

void create()
{
    ::create();
    set_race("demon");
    set_name("Shardak");
    set_short(0);
    set_long("\
Shardak is the harbinger of death.  He is an outcast of the underworld;\n\
sentenced to imprisonment on earth in the form of half man, half dragon.\n\
Dark red scales cover his defined body like a carapace. Three black claws\n\
on each hand provide him with a natural and lethal weapon.\n");
    set_level(25);
    set_ac(20);
    set_wc(45);
    set_hp(3000);
    set_sp(1000);
    set_al(-1000);	/* ultimate evil */
    set_heal(20, 35);
    set_dead_ob(this_object());
    set_env("mmsgout", "disappears behind a sheet of fire");
    set_env("mmsgin", "thunders into the room");
    
    Intruders = ({ });
    Victims = ({ });
}

/* ghosts aren't handled that well by living.c and I have an
 * override in my monster thing.. here's another one
 */
string query_name()
{
    return ghost ? "some mist" /* stops fight */
		 : ::query_name();
}

int monster_died(object me)
{
    string nom;

    tell_room(environment(), "\
Shardak's mutilated corpse falls to the ground, but a shimmering image\n\
remains where he just stood.\n");
    set_short("The spiritual remains of Shardak");
    set_long("\
Shardak has been banished from the realm of the living. This frail mist\n\
is all that is left of the dragon-man, and it is slowly disappearing.\n");

    if (query_attack()) nom = (string) query_attack()->query_name();
    call_other(CHANNELD, "broadcast", nom ?
	       ("Shardak was banished from the living by " + nom + ".\n") :
	       "Shardak was inexplicably banished from the living.\n",
	       0, "{Servants}");

    stop_fight();
    stop_fight();
    call_out("hide_me", 10);
    return 1;	/* no destruct */
}

void
hide_me()
{
    tell_room(environment(), "The spirit of Shardak vanishes into thin air.\n");
    move_object(this_object(), "/players/balowski/workroom");
    add_spell_point(-query_sp()); /* set to 0 */
}

void
revive_me()
{
    set_short(0);
    set_long("\
Shardak is the harbinger of death.  He is an outcast of the underworld;\n\
sentenced to imprisonment on earth in the form of half man, half dragon.\n\
Dark red scales cover his defined body like a carapace. Three black claws\n\
on each hand provide him with a natural and lethal weapon.\n");
    heal_self(10000);
    add_spell_point(-1000);
    
    move_object(this_object(), PATH + "throne");
    tell_room(environment(), "Shardak returns to the realm of the living.\n");
    CHANNELD->broadcast("Shardak speaks: I have returned from banishment.\n",
			0, "{Servants}");
}

void
add_spell_point(int x)
{
    ::add_spell_point(x);
    if (query_ghost() && query_sp() >= 1000) {
	ghost = 0;
	call_out("revive_me", 10);
    }
}

void
add_intruder(object who)
{
    if (member_array(who, Intruders) < 0) {
	call_out("warn_intruder", 5, who);
	Intruders += ({ who });
    }
}

void
warn_intruder(object who)
{
    if (!who) return;
    if (!query_ghost()) {
	tell_object(who, "\n\
You hear a strange voice in your head:  Leave immediately or prepare\n\
to fight for your life.\n\n");
    }
    call_out("add_victim", 10, who);
}

void
add_victim(object who)
{
    Victims += ({ who });
    if (sizeof(Victims) == 1) {
	call_out("prowl", 15 + random(10));
    }
}

int
can_hunt(object who)
{
    /* must be a connected player with an environment */
    if (who && interactive(who) && environment(who)) {
	string fname, rname;

	/* must be inside guild */
	fname = file_name(environment(who));
	if (sscanf(fname, PATH + "%s", rname) == 1 && (rname != "cave")) {
	    return 1;
	}	
    }
    return 0;
}

void
prowl()
{
    if (!(query_ghost() ||
	  (query_attack() && present(query_attack(), environment())))) {
	object *vics;
	int i;

	vics = filter_array(Victims, "can_hunt", this_object());
	if (i = sizeof(vics)) {
	    this_object()->move_player(environment(vics[--i]), "X");
	    this_object()->attacked_by(vics[i]);
	}	  
    }
    call_out("prowl", 15 + random(10));
}
