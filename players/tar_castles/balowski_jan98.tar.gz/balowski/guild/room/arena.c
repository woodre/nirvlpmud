/*
 * Shardak guild is (tm) Dragnar/John
 * Arena sparring room is (c) Balowski/Rasmus
 * Change log:
 * 951217 - created
 */
#pragma strict_types
#include "../def.h"
#include "../std.h"
#define SAVEFILE "players/balowski/guild/room/arena"

inherit ROOM;
static int      Locked;

void
create()
{
    ::create();
    Locked = 0;
    set_short("Arena");
    set_long("The arena.\n");
    set_exits(([ "out" : this_object() ]));
    set_property("spar area", 1);
    set_property("fight area", 1);
    set_light(1);
}

status
out(string arg)
{
    if (Locked)
        write("The room has been locked. You cannot leave.\n");
    else
        this_player()->move_player("out" + "#" + (PATH + "descent"));
    return 1;
}

void
init()
{
    ::init();
    add_action("cmd_challenge", "challenge");
    add_action("cmd_lock", "lock");
    add_action("cmd_unlock", "unlock");
}

status
cmd_challenge(string arg)
{
    object opp, ob;

    if (!arg || !(opp = find_player(arg))) {
        notify_fail("Challenge who?\n");
        return 0;
    }
    return 1;
}

status
cmd_lock(string arg)
{
    if (arg != "room") {
        notify_fail("Lock what?\n");
        return 0;
    }
    Locked = 1;
    say(this_player()->query_name() + " locks the room.\n");
    write("The room has been locked.\n");
    return 1;
}

status
cmd_unlock(string arg)
{
    if (arg != "room") {
        notify_fail("Unlock what?\n");
        return 0;
    }
    Locked = 0;
    say(this_player()->query_name() + " unlocks the room.\n");
    write("The room has been unlocked.\n");
    return 1;
}
