/*
 * Shardak guild - (tm) Dragnar/John
 * Advancement room is (c) Balowski/Rasmus, April 3rd 1995.
 * log:
 * 950415 corrected xp calc in advance() again
 * 950421 use ROOM
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../def.h"
#include "../tasks.h"

inherit ROOM;

void
create ()
{
    ::create();

    set_short("Altar");
    set_long("\
The floor here is a texture of dark brown stone tiles. In the farthest\n\
wall scores of wax candles are burning in the recesses of the rock.\n\
It is rather quiet here, mainly due to the low opening leading into\n\
this natural hollow. In the centre of the room, a great grey slab\n\
resembling an altar is placed.\n\
\tThe exit is east.\n");
    set_items(([ 
	({ "altar", "slab" }):"\
The rough stone altar is littered with runic inscriptions, except for\n\
the blood stained top surface which is blank and smooth.\n",
	({ "floor", "tiles" }):"\
The tiles on the floor are cut from porphyry, stone in hues brown\n\
to dark red born in the volcanoes millions of years ago.\n",
	({ "candles", "recesses" }):"\
Yellow wax candles are guttering in every recess of the wall.\n",
    ]));
    set_exits(([
	"east" : PATH + "grotto",
	]));
    set_light(1);
    set_property("fight area", 1);
    set_property("no teleport", 1);
}

void
reset(int arg)
{
    object          priest;

    ::reset(arg);

    if (!present("priest", this_object())) {
	priest = clone_object(PATH + "priest");
	priest->move_player("in#" + file_name(this_object()));
    }
}

void
init()
{
    ::init();
    add_action("trials", "trials");
    add_action("hint", "hint");
    add_action("advance", "advance", 3);
    add_action("title", "title");
}

status
trials()
{
    object          guild;
    int             solved;

    guild = present(GUILD_ID, this_player());
    if (guild) {
	write("Unsolved tasks:\n");
	if ((int) guild->query_solved(CORPSE_TASK) == 0)
	    write("A fresh corpse for the Priest.\n");

	if ((int) guild->query_solved(TELEPORT_TASK) == 0)
	    write("Provide teleportation for the Merchant.\n");

	if ((int) guild->query_solved(AVENGER_TASK) == 0)
	    write("Retrieve the Holy Avenger.\n");

	if ((int) guild->query_solved(DRAGON_TASK) == 0)
	    write("Tame the Dragon Keeper's beast.\n");

	if ((int) guild->query_solved(CHILD_TASK) == 0)
	    write("Sacrifice a child to Shardak.\n");

	if ((int) guild->query_solved(ENEMY_TASK) == 0)
	    write("Assassinate a member of an enemy guild.\n");
    } else
	write("Intruder, Be Gone!\n");
    return 1;
}

status
hint (string str)
{
    int             n;
    if (str && sscanf(str, "%d", n)) {
	if (n >= 1 && n <= 8) {
	    write("\
Find the tutor within the guild domain and say \"What is your task?\"\n");
	    return 1;
	}
    }
    notify_fail("Supply a number between 1 and 8.\n");
    return 0;
}

int
get_next_exp (int level)
{
    /*
     * Progressive experience cost for guild levels (1^2 + 2^2 + 3^2 + ... +
     * (l-1)^2) * 5714.285714 for (i = 1, sum = 0; i < level; sum+= i*i);
     * sum*= 5714.285714;
     */
    switch (level) {
	case 1: return 0;
	case 2: return 5714;
	case 3: return 28571;
	case 4: return 80000;
	case 5: return 171428;
	case 6: return 314285;
	case 7: return 520000;
	case 8: return 800000;
    }
}

string
get_next_title (int level)
{
    switch (level) {
	case 1: return "the Neophyte";
	case 2: return "the Backstabber";
	case 3: return "the Servant of Evil";
	case 4: return "the Necrolyte";
	case 5: return "the Summoner of Dragons";
	case 6: return "the Head Assassin";
	case 7: return "the Controller of Dragonbreath";
	case 8: return "the Gatekeeper of the Underworld";
	default: return "the Servant of Shardak";
    }
}

status
title (string str)
{
    object titles;

    if (str) return 0;
    if (!present(GUILD_ID, this_player())) {
	write("Intruder, Be Gone!\n");
	return 1;
    }

    str = get_next_title((int) this_player()->query_guild_rank());
    this_player()->set_title(str);
    write("Your rightful title has been restored. You now are:\n");
    write(this_player()->short() + ".\n");
    if (titles = present("titles", this_player()))
      titles->add_title(str);
    return 1;
}

status
advance ()
{
    int             spare,      /* experience not used */
		    needed,     /* spare xp needed for next guild level */
		    level;      /* regular level of player */
    object          guild;      /* guild object */
    string          name, title;

    guild = present(GUILD_ID, this_player());
    if (!guild) {
	write("Intruder, Be Gone!\n");
	return 1;
    }
    if ((int) this_player()->query_guild_rank() >= 8) {
	write("You have already reached the highest possible level.\n");
	return 1;
    }
    /* get the level of the player */
    level = (int) this_player()->query_level();

    /* wizards must find other ways */
    if (level >= 20) {
	write("Players only.\n");
	return 1;
    }

    /* get free amount of exp */
    spare = (int) this_player()->query_exp() -
	    (int) "room/adv_guild"->get_next_exp(level - 1);

    /* get the next guild level of the player */
    level = 1 + (int) this_player()->query_guild_rank();

    /* get experience needed for advancing one guild level */
    needed = get_next_exp(level) -
	     (int) this_player()->query_guild_exp();

    if (spare < needed) {
	/* need more xp */
	write("\
You are not yet ready to be filled with the power of Shardak. You\n\
must amass " + (needed - spare) +
	      " more experience points before you can advance in rank.\n");
    } else {
	object titles;

	/* move reg xp -> guild xp, increase guild rank */
	this_player()->add_exp(-needed);
	this_player()->add_guild_exp(needed);
	this_player()->add_guild_rank(1);

	/* give message to person and all guild members */
	write("\
You place your hands upon the smooth surface of the altar and\n\
whisper the arcane inscription cut in it. There is a crackle of\n\
electricity from your mildly sweating palms as you feel your\n\
experience drain away and wisdom fill your mind in return.\n");
	say(this_player()->query_name() + " places " +
	    possessive(this_player()) +
	    " hands upon the altar and mutters a few words.\n");
	title = get_next_title(level);
	name = (string) this_player()->query_name();
	this_player()->set_title(title);

	CHANNELD->broadcast(name + " has advanced to rank " + level + ".\n",
			    0, "{Servants}");
	CHANNELD->broadcast(name + " is now " + name + " " + title + ".\n",
			    0, "{Servants}");

	if (titles = present("titles", this_player())) {
	    titles->remove_title(get_next_title(level - 1));
	    titles->add_title(title);
	}
    }
    return 1;
}
