/*
 * Shardak guild (tm) Dragnar/John
 * Joining room by Balowski/Rasmus, March 21st 1995
 * Last change April 14th 1995 (give player scar _after_ setting rank)
 * Player will be moved here when joining, Shardak appears and claws a
 * scar into the palm of the player. (clones the guild object)
 * All commands are blocked while being in this room.
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../def.h"
#include "../people.h"

inherit ROOM;

int     counter;                /* heartbeat counter */

void
create()
{
    ::create();
    set_short("Initiation room");
    set_long("The joining room of the guild of Shardak.\n");
    set_property("no teleport", 1);
}

void
init()
{
    ::init();
    if (present(GUILD_ID, this_player()) || next_inventory( this_player())) {
	write( "\
You feel a great pain in your chest.\n\
You lose consciousness for a second.\nYou wake up in the church.\n");
	move_object( this_player(), "room/church");
	say( this_player()->query_name() + " " +
	     this_player()->query_mmsgin() + ".\n");
	return;
    }
    counter= 1;
    set_heart_beat(1);
    add_action("freeze"); add_xverb("");
}

status
freeze()
{
    write( "You are paralyzed.\n");
    return (this_player()->query_level() < 20);
}

void
heart_beat()
{
    string text;
    object who;

    switch (counter) {
	case 5:
	    text=
"The room seems to grow colder and you are filled with a sudden fear.";
	    break;
	case 7:
	    text= "A mist slowly fills the room.";
	    break;
	case 8:
	    text= "The mist swirls around and takes the shape of Shardak.";
	    break;
	case 12:
	    text= "Shardak walks toward you as he stares into your soul.";
	    break;
	case 14:
	    text=
"Cold fingers grasp your wrists as Shardak pulls you close to him.";
	    break;
	case 17:
	    text=
"You feel great pain as Shardak takes a claw and begins to cut a symbol\n\
into the palm of your hand.  Your blood begins to flow onto the floor.";
	    break;
	case 22:
	    text=
"You hand feels on fire as Shardak finishes his work, then lets 3 drops of\n\
your blood fall into the bowl.  He shoves your hand into the bowl of blood.";
	    break;
	case 27:
	    text=
"Shardak sends a message to your mind: The blood of the group now runs in\n\
your veins.  Prove to me your abilities and I will give you great powers.";
	    break;
	case 32:
	    text=
"Shardak touches your hand and the wound closes.  Only the scar remains.";
	    break;
	case 34:
	    text= "The mist envelopes Shardak and he is gone.";
	    break;
    }
    who= first_inventory( this_object());
    if (who && text) {
	tell_object( who, text);
	tell_object( who, "\n\n");
    }

    counter++;
    if (counter > 37) {
	set_heart_beat(0);
	if (who) {
	    object gob;

	    /* reset guild stats, in case some schmuck teleports in */
	    who->add_guild_rank( -((int) who->query_guild_rank()));
	    who->add_guild_exp( -((int) who->query_guild_exp()));

	    /* mark 'who' as being in a guild */
	    who->add_guild_rank(1);
	    who->add_guild_exp(1);

	    /* give 'em a mark */
	    gob = clone_object(GUILDOBJ);
	    gob->GuildClass(C_NOVICE);
	    move_object(gob, who);

	    /* no this_player, 'who' won't feel the move_player */
	    tell_object(who, "You travel back to the cave. A new exit appears.\n");
	    who->move_player("X#" + PATH + "cave");
	}
    }
}
