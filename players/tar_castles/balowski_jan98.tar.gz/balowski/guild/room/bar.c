/*
 * The Bar for the Servants of Shardak and their allies
 * It is a modified /room/pub2.c (it has coffee, beer, special, fb)
 * You can also buy some portable heals here (I grok wrongness)
 */
#include "/players/balowski/lib.h"
#include "../def.h"
inherit ROOM;

void
create()
{
    ::create();
    set_short("Forau's");
    set_long("\
The cave you are in has been fitted out as a bar.\n\
Only the agents of the night may come here to quench their thirst\n\
and regain their health. A charred sign hangs on the wall behind\n\
the bar. The only way out is a passage leading east.\n\
");
    set_items(([
        "sign" : "Flames must have licked this piece of wood many times.\n" +
		 "There is something written on it.\n",
	"bar" : 0,
    ]));
    set_sign("sign", "\
  ~ Drinks served in the bar ~\n\
\n\
  1. Dark brew		 10.-\n\
  2. Gasoline		150.-\n\
  3. Blood of children	230.-\n\
  4. Incinerator	 20.-\n\
\n\
       ~ Bottled drinks ~\n\
\n\
  5. Paranoia	       1750.-\n\
  6. Rage	       1800.-\n\
  7. Insomnia	        600.-\n\
\n\
      ~ Specials orders ~\n\
  8. Malice           10000.-\n\
");

    set_exits((["east" : (PATH + "cave")]));
    set_light(1);
    set_property("fight area", 1);
    set_property("no teleport", 1);
    
    move_object(clone_object(OBJDIR + "dispensr"), this_object());
}

void
reset(int arg)
{
    object      mon;

    ::reset(arg);
    if (!(mon = present("forau", this_object()))) {
        mon = clone_object(MONSTER);
        mon->set_name("Forau");
	mon->set_gender("male");
        mon->set_short("Forau the Bartender");
	mon->set_long("\
Forau is dressed all up in black. His silk shirt glows softly in the dim\n\
light. He is the bartender of this joint and one of Satan's disciples.\n");
        mon->set_level(16);
	mon->set_al(-300); /* infamous, but he doesn't do anything */
	mon->set_chat_chance(3);
	mon->load_chats(({
	    "Forau wipes up some glasses.\n",
	    "With experienced hands Forau concocts a foul smelling drink.\n",
	    "Forau casually remarks, \"Rumour is that Pitsniffer waxed Boltar incognito.\"\n",
	    "Forau leans over and whispers to you, \"Cast darkness in the grotto.\"\n",
	}));
        mon->setCallBack();
        move_object(mon, this_object());
    }
}

void
init()
{
    ::init();
    add_action("cmdBuy", "buy");
}

static object
MakeDrink(string which)
{
    object ob;

    switch (lower_case(which)) {
      case "bottle of paranoia":
	ob = clone_object(PORTHEAL);
	ob->set_name("bottle");
	ob->set_ids(({ "bottle of paranoia", "paranoia", }));
	ob->set_short("A bottle of Paranoia");
	ob->set_long("\
A long necked bottle of clear transparent glass. The fluid within\n\
the bottle is almost colourless, but when you look carefully, you\n\
see glimpses of odd distortions in the fluid--as if the fluid or\n\
something _in_ the fluid is moving about.\n");
	ob->set_charge_name("paranoia", "gulps of Paranoia");
	ob->set_messages("You drink a gulp of Paranoia.\n",
			 " drinks a gulp of Paranoia.\n");
	ob->set_verb("drink");
	ob->set_container_value(0);
	ob->set_weight(1);  /* weight for container */
	ob->set_charges(5);
	ob->set_quench(14);
	ob->set_heal(35);   /* calculates cost.. */
	break;
	
      case "bottle of rage":
	ob = clone_object(PORTHEAL);
	ob->set_name("bottle");
	ob->set_ids(({ "bottle of rage", "rage", }));
	ob->set_short("A bottle of Rage");
	ob->set_long("\
A stout bottle made from dark brown, almost opaque, glass. The label\n\
says \"Rage -- 42 percent proof\". You can almost feel it bubbling\n\
inside the bottle.\n");
	ob->set_charge_name("rage", "gulps of Rage");
	ob->set_messages("You drink a gulp of Rage.\n",
			 " drinks a gulp of Rage.\n");
	ob->set_verb("drink");
	ob->set_container_value(0);
	ob->set_weight(1);  /* weight for container */
	ob->set_charges(5);
	ob->set_intox(15);
	ob->set_heal(35);   /* calculates cost.. */
	break;
	
      case "bottle of insomnia":
	ob = clone_object(PORTHEAL);
	ob->set_name("bottle");
	ob->set_ids(({ "bottle of insomnia", "insomnia", }));
	ob->set_short("A bottle of Insomnia");
	ob->set_long("\
A small ceramic vial with glazed white surface. It is tightly sealed\n\
with a cork. The inscription in black gothic letters says: \"Insomnia --\n\
cures drunkenness and hangovers\".\n");
	ob->set_charge_name("insomnia", "gulps of Insomnia");
	ob->set_messages("You drink a gulp of Insomnia.\n",
			 " drinks a gulp of Insomnia.\n");
	ob->set_verb("drink");
	ob->set_container_value(0);
	ob->set_weight(1);  /* weight for container */
	ob->set_charges(2);
	ob->set_intox(-14);
	ob->set_heal(0);   /* calculates cost.. */
        break;
	
      case "jar of malice":
	ob = clone_object(PORTHEAL);
	ob->set_name("jar");
	ob->set_ids(({ "jar of malice", "malice", }));
	ob->set_short("A jar of malice");
	ob->set_long("\
The dim glass jar is engraved with some strange symbols unknown\n\
to you. It contains a tenuous mist of seasoned malice, which you\n\
can inhale for greater strength.\n");
	ob->set_charge_name("malice", "whiffs of Malice");
	ob->set_messages("\
You inhale the vapours from the jar and feel nigh on invincible.\n",
			 " inhales the vapours from a small jar.\n");
	ob->set_verb("inhale");
	ob->set_container_value(0);
	ob->set_weight(1);	/* weight for container */
	ob->set_charges(1);
	ob->set_intox(-50);
	ob->set_heal(1000);	/* calculates cost.. */
    }
    return ob;
}

status
cmdBuy(string arg)
{
    string mess, str, a_str;
    int heal, value, strength;
    object ob;
    
    if (!present("forau", this_object()))
      return (notify_fail("There is nobody to serve you.\n"), 0);
    if (!arg) return (notify_fail("Forau peers quizzically at you.\n"), 0);
    
    switch (atoi(arg)) {
    case 1:
	str = "Dark brew";
	mess = "You drink the brew. That feels good.\n";
	heal = 1; value = 10; strength = 3;
	break;
    case 2:
	str = "Gasoline";
	mess = "You down the shot and try not to breathe at the candles.\n";
	heal = 10; value = 150; strength = 7;
	break;
    case 3:
	str = "Blood of children";
	mess = "You let the thick red concoction crawl down your throat.\n";
	heal = 25; value = 230; strength = 14;
	break;
    case 4:
	str = "Incinerator";
	mess = "You feel somewhat invigorated.\n";
	heal = 0; value = 20; strength = -2;
	break;
    case 5:
	str = "bottle of Paranoia";
	value = 1750;
	break;
    case 6:
	str = "bottle of Rage";
	value = 1800;
	break;
    case 7:
	str = "bottle of Insomnia";
	value = 600;
	break;
    case 8:
	str = "jar of Malice";
	value = 10000;
	break;
    default:
	write("Forau says, \"What is it that you want, moron?\"\n");
	return 1;
    }
    
    if ((int) this_player()->query_money() < value) {
        write("Forau barks, \"Bugger off, you poor bum.\"\n");
	return 1;
    }
    a_str = indefinite(str);

    if (ob = MakeDrink(str)) {
	if (transfer(ob, this_player())) {
	    write("You cannot carry more.\n");
	    destruct(ob);
	    return 1;
	}
    }
    else {
	if (strength - 2 > (int) this_player()->query_level()) {
	    if (strength - 5 > (int) this_player()->query_level()) {
		/* This drink is *much* too strong for the player */
		say(this_player()->query_name() + " orders " +
		    a_str + ", and immediately throws it up.\n");
		write("You order " + a_str + ", try to drink it, and throw up.\n");
	    } else {
		say(this_player()->query_name() + " orders " +
		    a_str + ", and spews it all over you!\n");
		write("You order " + a_str + ", try to drink it, and sputter it all over the room!\n");
	    }
	    this_player()->add_money(-value);
	    return 1;
	}

	if (!this_player()->drink_alcohol(strength)) {
	    write("Forau says, \"I think you've had enough.\"\n");
	    say(this_player()->query_name() + " asks for " +
		a_str + " but Forau refuses.\n");
	    return 1;
	}
    }
    write("You pay Forau " + value + " gold pieces for the " + str + ".\n");
    say(this_player()->query_name() + " orders " + a_str + ".\n");
    this_player()->add_money(-value);
    this_player()->heal_self(heal);
    if (mess) write(mess);
    return 1;
}
