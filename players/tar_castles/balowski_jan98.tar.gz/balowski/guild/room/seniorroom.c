inherit "room/room";

#include "/players/balowski/guild/people.h"

object board;

reset(arg) {
   if (arg) return;
   set_light(1);
   short_desc = "Senior's Room";
   long_desc = "This is a room where the guild elite can meet to "+
 	       "disscuss guild policy or whatever they want. From "+
               "here, you can take the stairs to the throne room.\n";
   long_desc = format(long_desc,75);
   dest_dir = ({ "players/balowski/guild/room/throne", "up", });
   if (!present("board")) {
      board = clone_object("players/balowski/std/board2");
      board->set_name("seniors");
      board->set_size(50);
     board->set_short("A bulletin board for senior discussion");
      board->set_editors(LAW);

      board->set_long(format("This board is for senior guild members to discuss "+
                             "guild policy and other such things.\n",75));
      move_object(board, this_object());
   }
}

