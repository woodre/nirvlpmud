/*
 * Shardak guild is (tm) Dragnar/John, also Balowski/Rasmus
 * Change log:
 * 950525 - created
 * 951008 - trying to stop the bug that stops heartbeat :-( puzzling
 *          it was a bug in the mudlib..
 */
#pragma strict_types
#include "../def.h"
inherit "obj/monster";

void
reset(int arg)
{
    ::reset(arg);
    if (arg)
	return;
    set_name("wildebeest");
    set_short("Wildebeest, the dragon keeper's champion");
    set_long("\
A set of glowing red eyes meet you in the near dark. The beast\n\
vaguely resembles a human being. Its exaggerated limbs are covered\n\
by iron-grey scales and adorned by talons worthy of a dragon.\n\
Crouched over you, its enormous body seems to fill the whole room.\n\
Saliva drips in excess from finger-long, ivory-white fangs.\n");
    set_level(18);
    set_alias("beast");
    set_race("dragon");         /* of some sort */
    set_hp(666);
    set_al(-500);               /* black knight */
    wield(this_object());       /* a bit dirty, but I get special attacks */
    set_ac(15);
    set_wc(35);
    set_can_kill(1);
    set_dead_ob(this_object());
    set_init_ob(this_object()); /* not necessary on Nirvana */
    set_heal(2, 35);            /* default is rate 2, interval 35 */
    add_attribute("magic", 50); /* magic resistance.. */
}

/*
 * beast killed someone :-[
 */
void
catch_tell(string text)
{
    string who;
    if (stringp(text) && sscanf(text, "You killed %s.\n", who))
	call_out("evict_ghost", 2);
}

void
evict_ghost()
{
    object ob, next;

    /* 
     * do this in 2 loops to let the ghosts see the devouring
     * of their corpses. muahaha
     */

    ob = first_inventory(environment());
    while (ob) {
	next = next_inventory(ob);
	if (ob->id("corpse")) {
	    say("Wildebeest devours a corpse and glows with energy.\n");
	    heal_self((int) ob->heal_value());
	    destruct(ob);
	}
	ob = next;
    }

    ob = first_inventory(environment());
    while (ob) {
	next = next_inventory(ob);
	if (ob->query_ghost()) {
	    tell_object(ob,
		"In your misty form you seep up through the grating.\n");
	    ob->move_player("up#" + PATH + "stable");
	}
	ob = next;
    }
}

/*
 * beast died
 */
int
monster_died(object myself)
{
    say("\
The huge monster staggers and falls to its knees.\n\
With a boom its lifeless body collapses to the ground.\n");

    /*
     * I first tried setting the solved flag here, but saw
     * how wrong things can go if anything fails at this point.
     * Therefore this function is kept as simple as possible
     */

    /*
     * I will be destructed immediately after returning
     * therefore let the room handle the cheering, etc.
     */
    environment()->beast_died(attacker_ob);
    return 0;
}

/*
 * Someone enters
 * Beast will attack at next heartbeat (100% aggressive)
 * but without changing targets
 */
int
monster_init(object myself)
{
    if (this_player())
	attacked_by(this_player());
    return 0;   /* continue init(), returning 1 can result in no hb? */
}

/*
 * special attacks
 */
mixed
hit(object opponent)
{
    if (!objectp(opponent)) {
	say("The beast says, \"Something odd is happening.\"\n");
	return 0;
    }
    switch (random(4)) {
    case 0:
	tell_object(opponent, "Talons cut through armour and flesh.\n");
	return random(10);
    case 1:
	tell_object(opponent,
	"Strangely distracted, the beast misses you by an arms length.\n");
	heal_self(10);
	return "miss";
    case 2:
	tell_object(opponent,
	"The beast exhales a small ball of fire at you.\n");
	return 5 + random(10);
    default:
	return 0;
    }
}
