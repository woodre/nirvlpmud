/*
 * This is the room where the actual growing and brewing of
 * healing items are taking place.
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../def.h"
inherit ROOM;

int             LastGrow;
mapping         Stock;

void
create()
{
    ::create();
    set_no_clean(1);
    set_short("A storage room");
    set_long("Storage room for magic healing.\n");
    set_light(1);
    Stock = ([
        "mushroom" : 3,
        "toadstool" : 4,
        "elixir of life" : 1,
    ]);
    LastGrow = (int) "/room/church"->query_reboot_time();
    if (!LastGrow) LastGrow = time();
}

void
evGrow()
{
    int passed, mush, toad;

    passed = (time() - LastGrow) / 300;
    if (passed < 1) return;

    LastGrow += passed * 300;
    mush = (Stock["mushroom"] += passed - random(passed/3 + 1));
    toad = (Stock["toadstool"] += passed - random(passed/2 + 1));
    if (mush > 5) {
        Stock["basket of mushrooms"] += mush / 5;
        Stock["mushroom"] = mush % 5;
    }
    if (toad > 5) {
        Stock["basket of toadstools"] += toad / 5;
        Stock["toadstool"] = toad % 5;
    }
}

object
clone(string what)
{
    object ob;

    switch (what) {
        case "mushroom":
            ob = clone_object(PORTHEAL);
            ob->set_name("mushroom");
            ob->set_short("A mushroom");
            ob->set_long("\
The yellow mushroom has been neatly prepared and is delicious\n\
looking. It is told to have both healing and satiating effects.\n");
            ob->set_charge_name("mushroom", "mushrooms");
            ob->set_verb("eat");
            ob->set_messages("You eat the mushroom.\n", " eats a mushroom.\n");
            ob->set_weight(1);  /* weight for container */
            ob->set_charges(1);
            ob->set_satiate(14);
            ob->set_heal(32);   /* calculates cost.. */
            break;

        case "toadstool":
            ob = clone_object(PORTHEAL);
            ob->set_name("toadstool");
            ob->set_short("A toadstool");
            ob->set_long("\
The grey toadstool is covered with a thin layer of white mucilage,\n\
giving it a silvery tinge. It is still dirty and not very appertizing.\n\
It is told to have both healing and intoxicating effects.\n");
            ob->set_charge_name("toadstool", "toadstools");
            ob->set_verb("eat");
            ob->set_messages("You eat the toadstool.\n", " eats a toadstool.\n");
            ob->set_weight(1);
            ob->set_charges(1);
            ob->set_intox(11);
            /* dropped from 37 to 35 to comply with new rules */
            ob->set_heal(35);
            break;

        case "basket of mushrooms":
            ob = clone_object(PORTHEAL);
            ob->set_name("basket");
            ob->set_ids(({ "basket of mushrooms", "mushrooms", }));
            ob->set_short("A basket of mushrooms");
            ob->set_long("\
A basket woven from even strands of bark. It is made for carrying\n\
the yellow toadstools that are told to bring you good health.\n");
            ob->set_charge_name("mushroom", "mushrooms");
            ob->set_verb("eat");
            ob->set_container_value(37);
            ob->set_weight(1);  /* weight for container */
            ob->set_charges(5);
            ob->set_satiate(14);
            ob->set_heal(32);   /* calculates cost.. */
            break;

        case "basket of toadstools":
            ob = clone_object(PORTHEAL);
            ob->set_name("basket");
            ob->set_ids(({ "basket of toadstools", "toadstools", }));
            ob->set_short("A basket of toadstools");
            ob->set_long("\
A basket woven from even strands of bark. It is made for carrying\n\
the iron-grey toadstools that are told to have both healing and\n\
intoxicating effects.\n");
            ob->set_charge_name("toadstool", "toadstools");
            ob->set_verb("eat");
            ob->set_container_value(30);
            ob->set_weight(1);
            ob->set_charges(5);
            ob->set_intox(11);
            /* dropped from 37 to 35 to comply with new rules */
            ob->set_heal(35);
            break;

        case "elixir of life":
            ob = clone_object(PORTHEAL);
            ob->set_name("vial");
            ob->set_ids(({ "elixir of life", "vial of elixir", }));
            ob->set_short("A vial of elixir");
            ob->set_long("\
The frail glass vial contains a thick brown liquid. The imp has\n\
successfully extracted some of the healing components from the fungi\n\
and mixed them into this uninviting elixir.\n");
            /* PORTHEAL has some shortcomings here.. */
            ob->set_charge_name("elixir", "drinks of elixir");
            ob->set_messages("You take a gulp of the elixir.\n",
                " takes a gulp of some thick brown elixir.\n");
            ob->set_verb("drink");
            ob->set_container_value(25);
            ob->set_weight(1);
            ob->set_charges(6);
            ob->set_quench(8);
            ob->set_heal(26);
            break;
    }
    return ob;
}

int
priceof(string item)
{
    switch (item) {
        case "mushroom": return 320;
        case "basket of toadstools": return 2304;
        case "toadstool": return 454;
        case "basket of mushrooms": return 1636;
        case "elixir of life": return 2520;
        default: return 10000;
    }
}

int
cmd_list()
{
    string *items;
    int i, x;

    evGrow();
    i = sizeof(items = keys(Stock));
    if (!i) return 0;
    
    while (i--) {
        if (!Stock[items[i]])
            continue;
        else if (!x++)
            write("Price  Stock  Item\n");

        write(pad(priceof(items[i]), -5));
        write("  ");
        write(pad(Stock[items[i]], -5));
        write("  ");
        write(items[i]);
        write("\n");
    }
    return x;
}

int
cmd_buy(string what)
{
    int value;
    object ob;

    evGrow();
    if (!what || !Stock[what])
        return 0;       /* not found */

    value = priceof(what);
    if (value > (int) this_player()->query_money())
        return -2;      /* can't afford */

    if (!(ob = clone(what)))
        return -1;

    if (transfer(ob, this_player())) {
        destruct(ob);
        return -3;      /* can't transfer (carry) */
    }

    value = 2*((int) ob->query_value());
    this_player()->add_money(-value);
    Stock[what] -= 1;
    return value;               /* okay */
}
