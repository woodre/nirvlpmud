/*
 * GT command for the Shardak guild
 * free guild channel tell
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
inherit CMD;

status
main(string str)
{
    string          msg;

    if (!str) {
	notify_fail("Tell the allies what?\n");
	return 0;
    }
    if (previous_object()->Muffled()) {
	notify_fail("You are not listening to the Servants' channel.\n");
	return 0;
    }

    msg = capitalize((string) this_player()->query_real_name()) +
      " speaks: " + str + "\n";
    CHANNELD->broadcast(msg, 0, "[Servants]");
    return 1;
}
