/*
 * DRAGON command for the Shardak guild
 * call your dragon to you, costs nothing
 * by Dragnar and Balowski
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../tasks.h"
#include "../macros.h"
inherit CMD;
#define COST 0

status
main()
{
    object dragon;

    needrank(5)
    needtask(DRAGON_TASK)
    needmana(COST)

    dragon = (object) previous_object()->Dragon();
    if (!objectp(dragon)) {
	write("You do not have a dragon.\n");
	return 1;
    }
    if (present(dragon, environment(this_player()))) {
	write("It is already here.\n");
	return 1;
    }

    tell_room(environment(dragon), "The dragon takes off into the sky.\n");
    write("Your dragon swoops down from the sky.\n");
    say(capname + "'s dragon swoops down from the sky.\n");

    move_object(dragon, environment(this_player()));
    this_player()->add_spell_point(-COST);
    return 1;
}
