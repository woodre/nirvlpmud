/*
 * Tracking (follow) command for the Shardak guild
 * By Balowski & Dragnar at Nirvana, 1995
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
#include <security.h>
inherit CMD;

#define COST 40

status
main(string str)
{
    object          tw,
		    leash;

    needrank(3)

    leash = (object) previous_object()->Track();
    if (!str) {
	if (objectp(leash)) {
	    /* unleash the followed person */
	    write("You are no longer tracking anyone.\n");
	    destruct(leash);
	}
	else
	    write("Who do you wish to begin tracking?\n");
	return 1;
    }
    tw = present(str, environment(this_player()));
    if (!tw) {
	write(capitalize(str) + " is not here.\n");
	return 1;
    }
    if (!living(tw)) {
	write("You can't track something that is not alive.\n");
	return 1;
    }
    if (tw->is_player() && tw->query_level() >= APPRENTICE) {
	write("You can not track a wizard.\n");
	return 1;
    }

    needmana(COST)

    /* make a new leash or reuse the old */
    if (!leash)
	leash = clone_object(OBJDIR + "wisp");

    /* put the leash on the given person */
    leash->setup(tw, this_player());
    move_object(leash, environment(tw));
    previous_object()->Track(leash);

    this_player()->add_spell_point(-COST);
    write("You are now set to track " + capitalize(str) + ".\n");
    tell_object(tw, "You are now being followed by " +
	(str = (string) this_player()->query_name()) + ".\nIssue 'stop " +
	lower_case(str) + "' to make " + objective(this_player()) +
	" cease.\n");
    return 1;
}
