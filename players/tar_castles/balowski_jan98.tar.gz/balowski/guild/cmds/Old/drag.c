/*
 * This program is (c) Dragnar/John & Balowski/Rasmus
 * Drag command by Dragnar for the Shardak guild
 * Change log:
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
#define COST 40

inherit CMD;

status
main(string str)
{
    object      bringobj,
		who,
		leash;

    needrank(5)

    leash = (object) previous_object()->Drag();
    if (!str) {
	/*
	 * Stop dragging somebody, if any
	 */
	if (objectp(leash)) {
	    write("You are no longer dragging anyone.\n");
	    if (who = (object) leash->query_follower())
		tell_object(who, capname + " stopped dragging you.\n");
	    destruct(leash);
	}
	else
	    write("Who do you want to drag?\n");
	return 1;
    }

    /*
     * Only drag one at the time
     */
    if (leash) {
	write("You are already dragging ");
	if (who = (object) leash->query_follower())
	    write(who->query_name());
	write(".\n");
	return 1;
    }

    needmana(COST)
    /*
     * Drag the specified player (no monsters of course)
     */
    who = find_player(str = lower_case(str));
    if (!who || !present(who, environment(this_player()))) {
	write(capitalize(str) + " is not here.\n");
	return 1;
    }

    write("Attempting to drag " + str + ", waiting for acceptance.\n");
    tell_object(who, capname +
	" wishes to drag you.  This will allow you to follow " +
	(string) this_player()->query_objective() +
	".\nType 'accept' to start following, or 'decline' to cancel.\n");

    bringobj = clone_object(OBJDIR + "bringob");
    bringobj->set_bringer(this_player());
    move_object(bringobj, who);

    this_player()->add_spell_point(-COST);
    return 1;
}
