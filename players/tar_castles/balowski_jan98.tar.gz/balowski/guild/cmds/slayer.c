/*
 * SLAYER spell for the Shardak guild
 * by Dragnar, tampered with by Balowski
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../tasks.h"
#include "../macros.h"
#define MAX_POWER 150
inherit CMD;


status
main(string str)
{
    object          slayer;
    int             power;

    needrank(4)
    needtask(AVENGER_TASK)

    if (!str || !sscanf(str, "%d", power)) {
	notify_fail("How strong to you wish your slayer to be?\n");
	return 0;
    }
    if (power > MAX_POWER) {
	write("A Slayer Sword cannot contain that much power!\n");
	return 1;
    }
    if (present("slayer", this_player())) {
	write("Shardak does not allow you to have more than one Slayer Sword.\n");
	return 1;
    }
    needmana(power)

    slayer = clone_object(OBJDIR + "slayer");
    slayer->set_amt(power);
    if (transfer(slayer, this_player())) {
	write("You can't carry any more.\n");
	destruct(slayer);
	return 1;
    }

    write("\
The land parts and a Slayer Sword surges from the ground into your hands.\n");
    say("The land parts and a Slayer Sword surges from the ground into " +
	capname + "'s hands.\n");
    this_player()->add_spell_point(-power);

    return 1;
}
