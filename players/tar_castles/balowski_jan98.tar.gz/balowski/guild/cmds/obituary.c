/*
 * OBITS - show obituary
 */
#pragma strict_types
#include "../std.h"
#include "../people.h"
inherit CMD;

status
main(string arg)
{
    if (arg) return 0;
    if ((int) previous_object()->GuildClass() < C_WARRIOR) return 0;
    write("+---------------------------------------------------------------------------+\n");
    tail("/log/DEATHS");
    write("+---------------------------------------------------------------------------+\n");
    return 1;
}
