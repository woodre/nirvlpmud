/*
 * Shardak guild, (tm) Dragnar/John
 * tag / untag / inventory is (c) Balowski/Rasmus, 950131
 * enhanced inventory command, shows tags too
 */
#pragma strict_types
#include "../std.h"
inherit CMD;

#define query_tag(ob) query_attribute("*", ob)

status
main(string type)
{
    object      ob;
    status      hit;
    string      str;

    if (!type) {
	for (ob = first_inventory(this_player()); ob; ob = next_inventory(ob))
	  if (str = (string) ob->extra_look()) {
	      hit = 1;
	      write(str + ".\n");
	  }

	if (hit) {
	    write("\n");
	    hit = 0;
	}
    }

    for (ob = first_inventory(this_player()); ob; ob = next_inventory(ob))
	/* show if not invis, and if id matches 'type' */
	if (ob->short()	&&
	    (!type || (type == "heals" && ob->is_heal()) || ob->id(type))) {
	    hit = 1;
	    write((query_tag(ob) ? "*" : " "));
	    write(capitalize((string) ob->short()));
	    write(".\n");
	}

    if (!hit)
	write(type ? "You are carrying nothing of that sort..\n"
	           : "You are carrying nothing..\n");
    return 1;
}
