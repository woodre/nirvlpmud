/*
 * QUARTER spell. Cut a corpse to pieces for fun
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../std.h"
inherit CMD;

object MakeHead(string oname, string name)
{
    object ob;
	    
    ob = clone_object(OBJECT);
    ob->set_name("head");
    ob->set_short("the head of " + oname);
    ob->set_long(format(
"This is the maimed head of " + oname + ". The nose is broken and the one "+
"eye has been crushed. But most prominently, the body, to which this head "+
"belongs, is missing.\n" + oname + " was decapitated by " + name + ".\n"));
    ob->set_value(50);
    ob->set_weight(1);
    ob->set_property("bodypart", time());
    return ob;
}

status
main(string arg)
{
    object ob;
    string sh, oname, name;
    
    if (!arg) return (notify_fail("Quarter what?\n"), 0);

    if (!(ob = present(arg, environment(this_player()))) &&
	!(ob = present(arg, this_player())))
    {
	write("You have no such thing.\n");
	return 1;
    }
    
    sh = (string) ob->short();
    if (!(ob->id("corpse") && ob->heal_value() && sh &&
	  (sscanf(ob->short(), "corpse of %s", oname) ||
	   sscanf(ob->short(), "the somewhat decayed remains of %s", oname))))
    {
	write("You cannot quarter that.\n");
	return 1;
    }

    name = (string)this_player()->query_name();
    say(name + " severs the head from the corpse of " + oname + ".\n");
    transfer(MakeHead(oname, name), this_player());
    destruct(ob);
    return 1;
}
