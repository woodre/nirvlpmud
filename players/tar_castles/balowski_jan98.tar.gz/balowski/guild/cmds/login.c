/*
 * Let the player choose where to login (set_home())
 * Remember to set_home(0) if player leaves guild
 */
#pragma strict_types
#include "../def.h"
#include "../std.h"
inherit CMD;

status
main(string str)
{
    if (str == "church") {
	write("You will now enter the game in the church.\n");
	this_player()->set_home(0);
	return 1;
    }
    if (str == "guild") {
	write("You will now enter the game in the guild.\n");
	this_player()->set_home(LOGIN);
	return 1;
    }
    notify_fail("Login where? (church or guild)\n");
    return 0;
}
