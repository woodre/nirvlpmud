/*
 * EQUIL command for Shardak's minion
 * equilibrate hps and sps with random 1/3 loss
 * lose an additional third if transfering sps to hps
 * by Dragnar and Balowski, Nirvana '95
 */
#pragma strict_types
#include "../std.h"
#include "../macros.h"
inherit CMD;
#define GRADE 125

status
main(string str)
{
    int hps, sps, amt, net, skill;
    object dragon;

    if (str)
	return 0;
    needrank(3);

    hps = qhp(this_player());
    sps = qsp(this_player());
    if (hps < 0 || sps < 0) {
	write("You are too askew to equilibrate yourself.\n");
	return 1;
    }
    amt = hps - sps;
    if (amt >= -6 && amt <= 6) {
	write("Your body and mind are already in equilibrium.\n");
	return 1;
    }

    skill = GRADE - (int) previous_object()->QuerySkill("channeling");
    if (hps > sps) {
	amt = amt/2;
	net = amt - skill*random(1 + amt/3)/GRADE;
	write("You channel health into mana: " + amt +
		" hit points become " + net + " spell points.\n");
	this_player()->add_hit_point(-amt);
	this_player()->add_spell_point(net);

				/* have to notify dragon of hp change */
	if (dragon = (object) previous_object()->Dragon())
	    dragon->AdjustOwnerHps(-amt);
    }
    else {
	amt = -amt/2;
	net = amt - skill*(amt/3 + random(1 + amt/3))/GRADE;
	write("You channel mana into health: " + amt +
		" spell points become " + net + " hit points.\n");
	this_player()->add_spell_point(-amt);
	this_player()->add_hit_point(net);
    }
    return 1;
}
