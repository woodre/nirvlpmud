/*
 * Draw power from the pool. (c) Balowski/Rasmus
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
#define POOLD "/players/balowski/guild/daemons/pool"
#define COST 5
inherit CMD;

status
main(string arg)
{
    int need, avail;

    if (arg != "power")
	return 0;
    needrank(10)
    needmana(COST)
    if ((need = umsp - usp) <= 0) {
	write("You are already fully charged.\n");
	return 1;
    }

    if (!(avail = (int) POOLD->query_power())) {
	write("The pool is empty; You receive naught.\n");
	this_player()->add_spell_point(-COST);
	return 1;
    }

    if (need > avail)
	need = avail;
    POOLD->add_power(-need);
    if (need >= avail)
	write("You have drawn the last drop of power out of the pool.\n");

    say("A red light falls upon " + capname + ".\n For an instant " +
	subjective(this_player()) + " trembles and shows the white of "
	+ possessive(this_player()) + " eyes.\n");
    write("A red light falls upon you. The surge of power almost knocks you out.\n");
    this_player()->add_spell_point(need - COST);
    return 1;
}
