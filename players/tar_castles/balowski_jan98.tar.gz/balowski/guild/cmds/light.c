/*
 * LIGHT spell for the Shardak guild
 * by Drag and Bal, '95
 */
#pragma strict_types
#include "../std.h"
#include "../macros.h"
inherit CMD;

#define COST 5

status
main(string arg)
{
    if (arg) return 0;

    needrank(3)
    needmana(COST)

    previous_object()->Light(1);
    write("You raise your hands to the sky and the room is blasted with light.\n");
    say(capname + " raises his hands to the sky and you are blinded by light.\n");
    this_player()->add_spell_point(-COST);
    return 1;
}
