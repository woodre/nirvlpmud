/*
 * SEND command for Shardak's minion
 * Send sps to a friend with random 1/3 loss, 1/2 if target is good
 * by Dragnar and Balowski, Nirvana '95
 */
#pragma strict_types
#include "../def.h"
#include "../std.h"
#include "../macros.h"
inherit CMD;
#define GRADE 140

status
main(string str)
{
    int             amt, net, old, skill;
    string          who;
    object          target;

/*
    needrank(5);
*/

    if (!str || sscanf(str, "%d to %s", amt, who) != 2) {
	notify_fail("Usage: send <amount> to <name>\n");
	return 0;
    }
    if (lower_case(who) != "shardak") needrank(5);
    if (amt < 3) {
	write("Cease abusing your powers before Shardak is angered.\n");
	return 1;
    }
    if (!(target = present(who, environment(this_player()))))
        ;/*target = find_player(who);*/
    if (!target && lower_case(who) == "shardak") {
	target = (object) SHARDAK->load();
    }
    else {
	if (!target || !environment(target) || inwizible(target)) {
	    write("With no receiver, your mana drifts down to Shardak.\n");
	    this_player()->add_spell_point(-amt);
	    SHARDAK->add_spell_point(random(amt >> 1));
	    return 1;
	}
    }
    needmana(amt);

    if (target->is_player() && !friend(target)) {
	write("You cannot send mana to " + target->query_name() + ".\n");
	return 1;
    }
    skill = GRADE - (int) previous_object()->QuerySkill("channeling");
    net = amt - skill*random(1 + amt/3)/GRADE;
    
    /* -sigh- all that infuse stuff.. seq. of calls swapped, etc */
    old = qsp(target);
    target->add_spell_point(net);
    if (old == qsp(target)) {
	write(target->query_name() +
	      " is not capable of receiving the mana at this moment.\n");
	return 1;
    }
    this_player()->add_spell_point(-amt);
    
    write(capitalize(who) + " receives " + net + " spell points.\n");
    if (present(target, environment(this_player())))
	say("A glittering green ray shoots from the palms of " +
	    this_player()->query_name() + " to " + target->query_name() +
	    ".\n");
    else {
	say(this_player()->query_name() + " raises " +
		this_player()->query_possessive() +
	" hands to the sky and a glittering green ray shoots into the air.\n");
	if (environment(target))
	  tell_room(environment(target), "A glittering green ray falls upon " +
		    target->query_name() + ".\n");
    }
    tell_object(target, "You gain " + net + " spell points.\n");
    return 1;
}
