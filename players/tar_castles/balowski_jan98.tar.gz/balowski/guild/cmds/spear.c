/*
 * Spear spell for Shardak guild
 * By Dragnar & Balowski
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
inherit CMD;

#define COST 17
#define DAMAGE random(19) + 8   /* min cost: 8 + 18/2 = 17 */

status
main(string str)
{
    object          ob;
    string          name;
    int             dam;

    needrank(4);
    needmana(COST);

    if (str) {
	ob = present(str, environment(this_player()));
	if (!ob) {
	    write("There is no " + str + " here.\n");
	    return 1;
	}
	if (!living(ob)) {
	    write("Only a foolish warrior would try to kill something that is not alive.\n");
	    return 1;
	}
    }
    else
	ob = (object) this_player()->query_attack();

    if (!ob) {
	write("Who do you want to hurl a spear at?\n");
	return 1;
    }
    if (ob->is_player()) {
	object quick;
	quick = present("quicktyper", this_player());
	if (quick && quick->query_doing()) {
	    write("Shardak does not allow you to use your powers against players.\n");
	    return 1;
	}
    }

    name = (string) ob->query_name();
    dam = DAMAGE;               /* 8 - 25 */
    if (dam > 21) {
	write("You drive a magical spear deep into " + name + ".\n");
	say(capname + " drives a magical spear deep into " + name + ".\n");
    }
    else if (dam > 17) {
	write("With great force you hurl a magical spear at " + name + ".\n");
	say(capname + " hurls a magical spear at " + name + " with great force.\n");
    }
    else {
	write("You hurl a magical spear at " + name + ".\n");
	say(capname + " hurls a magical spear at " + name + ".\n");
    }

    this_player()->spell_object(ob, "spear", dam, COST, "");
    return 1;
}
