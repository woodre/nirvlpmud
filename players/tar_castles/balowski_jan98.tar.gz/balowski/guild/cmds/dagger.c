/*
 * Dagger spell for Shardak guild
 * By Dragnar and Balowski
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
inherit CMD;

#define COST 11
#define DAMAGE random(13) + 5   /* min cost: 5 + 12/2 = 11 */

status
main(string str)
{
    object          ob;
    string          nom;
    int             dam;

    needrank(2);
    needmana(COST);
    if (str) {
	ob = present(str, environment(this_player()));
	if (!ob) {
	    write("There is no " + str + " here.\n");
	    return 1;
	}
	if (!living(ob)) {
	    write("Only a foolish warrior would try to kill something that is not alive.\n");
	    return 1;
	}
    }
    else
	ob = (object) this_player()->query_attack();

    if (!ob) {
	write("Who do you want to throw a dagger at?\n");
	return 1;
    }
    if (ob->is_player()) {
	object quick;
	quick = present("quicktyper", this_player());
	if (quick && quick->query_doing()) {
	    write("Shardak does not allow you to use your powers against players.\n");
	    return 1;
	}
    }

    /*
     * spell_object(who, spellname, damage, cost)
     * it will be cast at next heartbeat. if cost is set to 0,
     * no message is written in heartbeat (rather uncool)
     */

    nom = (string) ob->query_name();
    if ((dam = DAMAGE) > 12) {
	write("Your magical dagger leaves a bloody slit in " + nom + "'s neck.\n");
	say(capname + "'s magical dagger leaves a bloody slit in " + nom + "'s neck.\n");
    }
    else if (dam > 8) {
	write("Your magical dagger stabs " + nom + " in the chest.\n");
	say(capname + " stabs " + nom + " in the chest with a magical dagger.\n");
    }
    else {
	write("You throw a magical dagger at " + nom + ".\n");
	say(capname + " throws a magical dagger at " + nom + ".\n");
    }

    this_player()->spell_object(ob, "dagger", dam, COST, "");
    return 1;
}
