/*
 * WAND spell for the Shardak guild
 * by Drag and Bal '95
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
inherit CMD;

status
main(string str)
{
    int             coinage;
    object          wand;

    needrank(6)

    if (!str || !sscanf(str, "%d", coinage)) {
	notify_fail("How many gold coins to you want to use?\n");
	return 0;
    }
    if (coinage < 1) {
	write("Shardak forbids you to dishonor him by cheating.\n");
	return 1;
    }
    if (coinage > (int) this_player()->query_money()) {
	write("You do not have enough gold coins to sacrifice.\n");
	return 1;
    }

    wand = clone_object(OBJDIR + "wand");
    wand->set_amt(coinage / 10);

    /* make sure that encumberance is adjusted */
    if (transfer(wand, this_player())) {
	write("You can't carry any more.\n");
	destruct(wand);
	return 1;
    }

    write("You summon a Wand of Acid from the depths of hell.\n");
    say(capname + " summons a Wand of Acid from the depths of hell.\n" +
	"You cringe in fear.\n");
    this_player()->add_money(-coinage);
    return 1;
}
