/*
 * TOGGLE command for Shardak's minion
 * move hps to sps or vice versa with random 1/3 loss
 * by Dragnar and Balowski, Nirvana '95
 */
#include "../std.h"
#include "../def.h"
#include "../macros.h"
inherit CMD;

status
main(string str)
{
    int             amt, avail, net;
    string          what;
    object          dragon;

    needrank(3)

    if (!str || sscanf(str, "%d %s", amt, what) != 2 ||
	(what != "hps" && what != "sps")) {
	notify_fail("Usage: toggle <amount> {hps|sps}\n");
	return 0;
    }
    if (amt < 3) {              /* less than 3 gives a 0 loss */
	write("Shardak forbids you to dishonor him by cheating.\n");
	return 1;
    }

    if (what == "sps") {
	if (usp < amt) {
	    write("You don't have enough mana to toggle that much.\n");
	    return 1;
	}
	net = 2*amt/3 - random(1 + amt/3);
	write("You channel mana into health: " + amt +
		" spell points become " + net + " hit points.\n");
	this_player()->add_spell_point(-amt);
	this_player()->add_hit_point(net);
    }

    if (what == "hps") {
	if (uhp <= amt) {
	    write("You are not strong enough to toggle that much.\n");
	    return 1;
	}
	net = amt - random(1 + amt/3);
	write("You channel health into mana: " + amt +
		" hit points become " + net + " spell points.\n");
	this_player()->add_hit_point(-amt);
	this_player()->add_spell_point(net);

				/* have to notify dragon of hp change */
	if (dragon = (object) previous_object()->Dragon())
	    dragon->AdjustOwnerHps(-amt);
    }
    return 1;
}
