/*
 * Dragon breath spell for Shardak guild.
 * Uses the dragon's spell points ("flame") to cast "breath"
 * By Dragnar, modified by Balowski
 */
#pragma strict_types
#include "../std.h"
#include "../macros.h"
inherit CMD;

#define COST 34
#define DAMAGE 17 + random(28)

status
main(string str)
{
    object          ob, dragon;

    needrank(7);
    dragon = (object) previous_object()->Dragon();
    if (!dragon) {
	 notify_fail("You do not have a dragon.\n");
	 return 0;
    }
    if (!present(dragon, environment(this_player()))) {
	notify_fail("Your dragon is not here.\n");
	return 0;
    }
    if (qsp(dragon) < COST) {
	write("Your dragon exhales some sulphurous vapours through its nostrils.\n");
	say(capname + "'s dragon exhales some sulphurous vapours through its nostrils.\n");
	return 1;
    }
    if (str) {
	ob = present(str, environment(this_player()));
	if (!ob) {
	    write("There is no " + str + " here.\n");
	    return 1;
	}
	if (!living(ob)) {
	    write("Only a foolish warrior would try to kill something that is not alive.\n");
	    return 1;
	}
    }
    else
	ob = (object) this_player()->query_attack();

    if (!ob || ob == dragon) {
	write("Who do you want your dragon to breathe fire upon?\n");
	return 1;
    }
    if (ob->is_player()) {
	write("Shardak does not allow you to use your powers against players.\n");
	return 1;
    }
    if (!this_player()->valid_attack(ob)) {
	write("Shardak does not allow it.\n");
	return 1;
    }

    write("Your dragon breathes fire upon " + ob->query_name() + ".\n");
    say(capname + "'s dragon breathes fire upon " + ob->query_name() + ".\n");

    dragon->add_spell_point(-COST);
    if ((object) ob->query_attack() != this_player())
      ob->attacked_by(this_player());
    ob->heal_self(-(DAMAGE));
    return 1;
}
