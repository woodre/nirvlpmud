/*
 * DRAGONSKIN spell for Shardak guild.
 * (c) Balowski/Rasmus 1996
 */
#pragma strict_types
#include "../def.h"
#include "../std.h"
#include "../macros.h"
inherit CMD;

#define COST 21
#define TYPE "misc"

status
main(string str)
{
    object      ob;
    int         ac;

    if (str) return 0;

    needrank(3)
    if (present("dragon skin", this_player())) {
        write("You already have dragon skin.\n");
        return 1;
    }
    ac = ((int) this_player()->query_guild_rank())/3;
    needmana(COST*ac)

#ifdef TYPE
    ob = first_inventory(this_player());
    while (ob) {
        if ((string) ob->query_type() == TYPE && ob->query_worn()) {
            write("You must first remove your " + ob->query_name() + ".\n");
            return 1;
        }
        ob = next_inventory(ob);
    }
#endif

    ob = clone_object(OBJDIR + "dskin");
    ob->set_ac(ac);

    if (transfer(ob, this_player())) {
        write("You are too burdened.\n");
        destruct(ob);
        return 1;
    }
    write("You begin the transformation.\n\
Red scales slowly grow from your skin until your body is fully covered.\n");
    say("Suddenly " + this_player()->query_name() +
        "'s skin begins to change.\nRed scales grow slowly until they cover " +
        possessive(this_player()) + " entire body.\n");
    command("wear dragon skin", this_player());
    this_player()->add_spell_point(-COST*ac);
    return 1;
}
