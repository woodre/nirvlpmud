/*
 * GW command for the Shardak guild
 * free guild who
 * by Drag and Bal
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../people.h"
#include <security.h>
inherit CMD;

status
main(string str)
{
    object          *list, player, guild;
    int             i, level, inv, class;
    string          name;

    level = (int) this_player()->query_level();
    if (str) {
	i = atoi(str);
	if (i < 1 || i > level)
	    return 0;
	level = i;
    }
    i = sizeof(list = (object *) CHANNELD->users("Servants"));

    write("\n\
_____________________________________________________________________________\n\
\n\
NAME:           CLASS:     RANK: MUFFLED: LOCATION:\n\
_____________________________________________________________________________\n\
\n");
    while (i--) {
	if ((guild = list[i]) && (player = environment(guild))) {
	    inv = (int) player->query_invis(level);
	    name = (inv > 0) ? "A shadow" : (string) player->query_name();
	    if (!interactive(player))
		name = "(" + name + ")";
	    if ((int) player->query_pl_k() == 1)
	      name += "*";
	    write(pad(name, 16));

	    class = (int) guild->GuildClass();
	    write(pad(classtostr(class), 13));
	    if (class >= C_NOVICE)
	      write(player->query_guild_rank());
	    else
	      write("--");
	    write((guild->Muffled() ? "\t Yes\t  " : "\t No\t  "));

	    name = 0;
	    if ((inv <= 0) && environment(player))
		name = (level >= WIZARD) ?
			file_name(environment(player)) :
			(string) environment(player)->short();
	    if (!stringp(name))
		name = "Unknown";
	    if (index(name, 27) >= 0) write(name);
	    else write(name[0..34]);
	    write("\n");
	}
    }
    write("_____________________________________________________________________________\n");
    return 1;
}
