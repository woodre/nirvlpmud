/*
 * darken command for the Shardak guild (renew guild object)
 * by Dragnar and Balowski
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
inherit CMD;

status
main()
{
    object      scar,
                drag, track, dragon;    /* old values saved */

    write("You darken your mark of shardak with a knife.\n");

    drag = (object) previous_object()->Drag();
    track = (object) previous_object()->Track();
    dragon = (object) previous_object()->Dragon();
    previous_object()->remove();
    destruct(previous_object());

    scar = clone_object(GUILDOBJ);
    scar->Drag(drag);
    scar->Track(track);
    scar->Dragon(dragon);
    move_object(scar, this_player());

    return 1;
}
