/*
 * DSC command for the Shardak Assassins
 * Dragnar and Balowski, Nirvana '95
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../std.h"
inherit CMD;

status
main(string arg)
{
    object dragon;

    dragon = (object) previous_object()->Dragon();
    if (!dragon) return (notify_fail("You have no dragon.\n"), 0);
    write("[HPS: " + dragon->query_hp() + "] [FLAME: " + dragon->query_sp() + "]\n");
    return 1;
}
