/*
 * 
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "../std.h"
#include "../def.h"
inherit CMD;
inherit COLOUR;

void create()
{
    cmd::create();
    colour::create();
}

status
main(string str)
{
    if (!str) return 0;
    if (str != "list") str = terminal_colour(str, "ansi");
    return (int) this_player()->broadcast(str);
}
