/*
 * IDLE command
 */
#pragma strict_types
#include "../std.h"
inherit CMD;

status
main(string arg)
{
    object who;

    if (!arg) return 0;
    who = find_player(arg);
    if (!who || who->query_invis())
        return (notify_fail("Not found.\n"), 0);
    if (!interactive(who)) {
	write(who->query_name() + " is disconnected.\n");
	return 1;
    }
    write(who->query_name() + " has been idle for " + query_idle(who) +
          " seconds.\n");
    return 1;
}
