/*
 * Worship spell for Shardak guild
 * By Dragnar, for Shardak guild Balowski/Dragnar
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
inherit CMD;

#define COST 10

status
main(string str)
{
    int x;

    needrank(1)
    needmana(COST)

    if (str == "shardak") {
        x = (int) this_player()->query_alignment();
        x = -1000 - x;
	if (x < 0)
        call_other(this_player(), "add_alignment", x);
        write("\
You bend down on one knee and bow your head to Shardak.\n\
You feel the goodness leave your soul.\n");
        say(capname + " bends down on one knee and bows " +
            this_player()->query_possessive() +
            " head.\nThe light grows dim, and the air becomes cold.\n");
        this_player()->add_spell_point(-COST);
        return 1;
    }
}
