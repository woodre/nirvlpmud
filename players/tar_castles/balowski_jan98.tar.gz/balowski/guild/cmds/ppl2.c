/*
 * Enhanced PPL command
 * Balowski@Nirvana '97
 */
#pragma strict_types
#include "../std.h"
inherit CMD;

status main(string arg) {
    int i, no, mylvl, lvl;
    object *list, ob;
    string str, tmp;

    list = users();
    mylvl = (int) this_player()->query_level();
    
    write("   Name:        Level:  Guild:  Gender: Location:\n");
    write("[----------------------------------------------------------------------]\n");
    for (i = 0, no = 0; i < sizeof(list); i++) {
	ob = list[i];
	if (!environment(ob)) continue;
	if (ob->query_invis(mylvl) > 0) continue;
	if ((lvl = (int)ob->query_level()) > 19) continue;
	
	tmp = (string) ob->query_fight_area();
	if (!ob->query_pl_k() && (tmp != file_name(environment(ob)))) continue;

	str = ++no + ". ";
	str += pad((string)ob->query_name(), 16 - strlen(str));

	tmp = "" + lvl;
	if (lvl = (int)ob->query_extra_level()) tmp += "/" + lvl;
	if (ob->query_pl_k()) tmp += "*";
	
	str += pad(tmp, 8);
	str += pad((string) ob->query_guild_name() || "None", 8);
	tmp = (string) ob->query_gender();
	str += (tmp == "male") ? "   M\t"
	  :    (tmp == "female") ? "   F\t" : "   C\t";

	str += (string)environment(ob)->short();
	write(str + "\n");
    }
    write("[----------------------------------------------------------------------]\n");
    return 1;
}
