/*
 * Toggle ANSI colour on/off (free for all)
 * By Dragnar and Balowski
 */
#pragma strict_types
#include "../std.h"
inherit CMD;

status
main()
{
    if (previous_object()->Color(1)) {	/* toggle it */
	write("Guild Color is now ON.\n");
	add_attribute("ansi", 1, this_player());
    }
    else {
	write("Guild Color now set to OFF.\n");
	delete_attribute("ansi", this_player());
    }
    return 1;
}
