/*
 * WASTE_MSG for the Shardak guild
 * Drag and Bal '95
 */
#pragma strict_types
#include "../std.h"
#include "../macros.h"
inherit CMD;

status
main(string str)
{
    string          msg;

    needrank(6)
    if (!str) {
	notify_fail("What do you want your waste message to be?\n");
	return 0;
    }
    str = (string) "players/balowski/guild/daemons/channel"->terminal_colour(str, "ansi");
    str = "NN " + str + "\n";
    msg = strsub(str, ({ "NN", capname, "OO", "<attacker>", }), 0);
    previous_object()->WasteMsg(str);
    write("When you use waste the room will now see:\n");
    write(msg);
    return 1;
}
