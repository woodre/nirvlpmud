/*
 * ALLY command for senior servants and up
 * Balowski@Nirvana, Sept' 95
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../people.h"
inherit CMD;

status
main(string arg)
{
    object who, aob, *list;
    string gname;

    if (previous_object()->GuildClass() < C_LAW)
        return 0;
    if (!arg || !(who = find_player(arg)) || who->query_invis()) {
        notify_fail("Make who an ally?\n");
        return 0;
    }

    gname = (string) who->query_guild_name();
    if (gname == GUILDNAME) {
        write("Your fellow guild members are already your allies.\n");
        return 1;
    }
    if (present("allymark", who)) {
        write("That person is already an ally.\n");
        return 1;
    }
    if (gname == "Knights Templar" || gname == "bard" || gname == "monk") {
        write("You hear Shardak's voice, \"Do not offend me. That is an enemy.\"\n");
        return 1;
    }
    aob = clone_object(OBJDIR + "allymark");
    move_object(aob, who);      /* it is without weight */

    CHANNELD->broadcast(capitalize(arg) + " is now an ally of the Servants.\n",
			0, "[Servants]");
    tell_object(who, "\
You are now an ally of the Servants of Shardak.\n\
Examine the mark you have received for more information.\n");

    write_file(LOGDIR + "allies", ctime() + " : " +
                this_player()->query_real_name() + " made " + arg + " an ally.\n");
    return 1;
}
