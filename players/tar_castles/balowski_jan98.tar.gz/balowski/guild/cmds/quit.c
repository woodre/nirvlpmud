/*
 * QUIT removes registration in channel daemon
 * and saves the guild object.
 */
#pragma strict_types
#include "../def.h"
#include "../std.h"
inherit CMD;

status
main()
{
    if (!((int) this_player()->query_invis()))
      CHANNELD->broadcast(this_player()->query_name() + " leaves the game.\n",
			  0, "{Servants}");

    CHANNELD->deregister(previous_object(), "Servants");
    CHANNELD->deregister(this_player(), ({"[Servants]", "{Servants}",}));
    previous_object()->save_me();
    return 0;
}
