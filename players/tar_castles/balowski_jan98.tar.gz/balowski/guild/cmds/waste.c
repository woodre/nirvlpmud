/*
 * WASTE spell for the Shardak guild
 * by Dragnar, modified by Bal
 */
#pragma strict_types
#include "../std.h"
#include "../macros.h"
inherit CMD;

#define COST 30
#define DAMAGE 16 + random(25)  /* min cost: 16 + 24/2 = 28 */

string  *subs;                  /* array for strsub(). Could allocate */
				/* it on the fly.. hohum */

status
main(string str)
{
    object          ob;
    string          w_msg, output;

    needrank(6);
    needmana(COST);

    w_msg = (string) previous_object()->WasteMsg();
    if (!w_msg)
	w_msg = "NN wastes OO.\n";

    if (str) {
	ob = present(str, environment(this_player()));
	if (!ob) {
	    write("There is no " + str + " here.\n");
	    return 1;
	}
	if (!living(ob)) {
	    write("Only a foolish warrior would try to kill something that is not alive.\n");
	    return 1;
	}
    }
    else
	ob = (object) this_player()->query_attack();

    if (!ob) {
	write("Who do you want to waste?\n");
	return 1;
    }

    if (ob->is_player()) {
	object quick;
	quick = present("quicktyper", this_player());
	if (quick && quick->query_doing()) {
	    write("Shardak does not allow you to use your powers against players.\n");
	    return 1;
	}
    }

    /* prepare for doing a strsub */
    if (!subs)
	subs = ({ "NN", "", "OO", "", });
    subs[1] = (string) this_player()->query_name();
    subs[3] = (string) ob->query_name();

    output = strsub(w_msg, subs, 0);
    tell_room(environment(this_player()), output);

    this_player()->spell_object(ob, "waste", DAMAGE, COST, "");
    return 1;
}
