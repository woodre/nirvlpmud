/*
 * RUN command for the Shardak guild
 * speedster patch
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
inherit CMD;

status
main(string arg)
{
    return (status) call_other(BINDIR + "fly", "run", arg);
}
