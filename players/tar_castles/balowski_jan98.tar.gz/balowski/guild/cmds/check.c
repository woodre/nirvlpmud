/*
 * hmm.. stuff
 */
#pragma strict_types
#include "../std.h"
inherit CMD;

status
main()
{
    write("Trackwho is set to ");
    write(previous_object()->query_track());
    write(".\nDragwho is set to ");
    write(previous_object()->query_drag());
    write(".\n");
    return 1;
}
