/*
 * Patching tool for setting the home of a player
 */
#pragma strict_types
#include <security.h>
#include "../std.h"
inherit CMD;

status
main(string arg)
{
    string      who, locus;
    object      p;

    if ((int) this_player()->query_level() < WIZARD)
	return 0;

    if (!arg || sscanf(arg, "%s %s", who, locus) != 2) {
	notify_fail("Usage: set_home <who> <where>\n");
	return 0;
    }
    p = find_player(who);
    if (!p) {
	write("That person isn't around.\n");
	return 1;
    }
/*
    if (p != this_player() && (int) p->query_level() >= WIZARD) {
	write("Wizards are immune to set_home.\n");
	return 1;
    }
*/
    p->set_home(locus);
    tell_object(p, this_player()->query_name() +
		" casts the spell of tinkering on you.\n");
    write("So be it, master.\n");
    return 1;    
}
