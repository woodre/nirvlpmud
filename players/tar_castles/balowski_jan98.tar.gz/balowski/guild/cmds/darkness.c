/*
 * Darkness spell for the Shardak guild
 * Blocks teleport and some ordinary exits of the room we're in
 */
#pragma strict_types
#include "../std.h"
#include "../def.h"
#include "../macros.h"
#define COST 25

inherit CMD;

status
main()
{
    object          it;

    needrank(6)
    needmana(COST)
    /*
     * only cast darkness if we are in a room-room
     */
    if (!environment(this_player()) ||
	 environment(environment(this_player()))) {
	write("Darkness can not be cast here.\n");
	return 1;
    }
    /*
     * no casting darkness in starting realm
     */
    if (file_name(environment(this_player()))[0..3] == "room") {
	write("Darkness can not be cast here.\n");
	return 1;
    }
    /*
     * check if darkness already exists in the room
     */
    if (environment(this_player())->shardak_darkness(0)) {
	write("Darkness has already been cast here.\n");
	return 1;
    }
    /*
     * cast darkness
     */
    it = clone_object(OBJDIR + "darkness");
    if (it->shardak_darkness(environment(this_player()))) {
	write("\
You spin around beckoning darkness to fall upon the room.\nLight fades.\n");
	say(this_player()->query_name() + " \
spins around beckoning darkness to fall upon the room.\nLight fades.\n");
    }
    else {
	write("The darkness shatters the moment you cast it.\n");
	say(this_player()->query_name() + " fails to cast darkness upon the room.\n");
	destruct(it);
    }

    this_player()->add_spell_point(-COST);
    return 1;
}
