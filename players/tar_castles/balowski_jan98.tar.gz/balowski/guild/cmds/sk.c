/*
 * SC (alternative score) command for the Shardak guild
 * by Drag and Bal
 */
#pragma strict_types
#include "../std.h"
#include "../macros.h"
#include "../people.h"
inherit CMD;

string
degree(int n, int max)
{
    if (!n)
	return("No      ");
    else {
	switch (4*n/max) {
	    case 0: return("Little  ");
	    case 1: return("Some    ");
	    case 2: return("Yes     ");
	    case 3: return("A lot   ");
	    default: return("Very    ");
	}
    }
}

status
main()
{
    string          str;
    int             level, n, max;
    object          ob;

    if (this_player()->query_ghost()) {
	write("You are in an immaterial state with no scores.\n");
	return 1;
    }
    level = (int) this_player()->query_level();
    write("\n[----------------------------------------------------------------------------]\n");

    write(this_player()->short() + "\n");

    this_player()->show_age();
    
    if (this_player()->query_pregnancy())
	write("You are Pregnant.\n");

    if (this_player()->query_invis())
	write("You are Invisible.\n");

    if ((ob = (object) this_player()->query_hunted()) &&
	(str = (string) ob->query_name()))
	write("You are hunted by " + str + ".\n");

    write("\nLevel:      ");
    if (n = (int) this_player()->query_extra_level())
	write(pad(level + "/" + n, 8));
    else
	write(pad(level, 8));

    write("\tGuild Rank:  "); 
    write((int) this_player()->query_guild_rank());

    write("\t\tIntox'd:    ");
    if (n = (int) this_player()->query_intoxination()) {
	n = (level + 4)/n;
	switch (n) {
	    case 0: write("Stupor"); break;
	    case 1: write("Roaring"); break;
	    case 2: write("Somewhat"); break;
	    case 3: write("Quite"); break;
	    default: write("Slightly"); break;
	}
    }
    else write("No");


    write("\nCoins:      "); 
    write(pad((int) this_player()->query_money(), 8));

    write("\tGuild Exp:   "); 
    write(pad((int) this_player()->query_guild_exp(), 8));

    write("\tStuffed:    ");
    write(degree((int) this_player()->query_stuffed(), level*8));


    write("\nExperience: "); 
    write(pad((int) this_player()->query_exp(), 8));

    write("\tGuild Class: ");
    n = (int) previous_object()->GuildClass();
    write(pad(classtostr(n), 10));

    write("\tSoaked:     ");
    write(degree((int) this_player()->query_soaked(), level*8));


    write("\nQuest pts:  "); 
    write(pad((int) this_player()->query_quest_point(), 5));

    if (previous_object()->Color())
	write("\tGuild Color: ON ");
    else
	write("\tGuild Color: OFF");

    n = 0;
    for (ob = first_inventory(this_player()); ob; ob = next_inventory(ob))
	n += (int) ob->query_weight();
    write("\tEncumbered: ");
    write(degree(n, 6 + level + ((int) this_player()->query_attrib("str")/5)));

    write("\n\nHit pts:    " + uhp + "/" + umhp);
    write("\tSpell pts:   " + usp + "/" + umsp);

    write("\n[----------------------------------------------------------------------------]\n");
    return 1;
}
