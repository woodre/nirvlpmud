/*
 * because the Amylaar efuns have consistent names
 * well.. sort of
 */
#define mappingp(m) mapp(m)
#define m_indices(m) keys(m)
#define copy_mapping(m) m
#define m_delete(m,i) deletem(m,i)
