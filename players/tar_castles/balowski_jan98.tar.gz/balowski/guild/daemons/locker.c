/*
 * Shardak guild is (tm) Dragnar/John
 * Change log:
 * 960704 - created
 * 960830 - changed to take who by name and not who the-object as input
 * 	    added some type checks
 */
#pragma strict_types
#include "/players/balowski/lib.h"
#include "/players/balowski/macros.h"
#include "../def.h"
inherit BASE;
inherit CLEANUP;
static string Name;/* name of person who last accessed this daemon */
mixed *Items;

static void
restore(string nom)
{
    if (!stringp(nom))
      Name = Items = 0;
    else if (nom != Name) {
	Name = nom;
	Items = 0;	/* clear the prev person's items */
	restore_object(STORE_PATH + nom);
    }
}

static void
save(string nom)
{
    if (stringp(Name))
      save_object(STORE_PATH + Name);
}

status
store_item(string nom, object what)
{
    string file, sh;
    mixed args;
    int flag;
    
    if (!stringp(nom) || !objectp(what)) return 0;
    /* save flag: 1 = no save, 2 = only hotel save */
    flag = (int) what->query_save_flag();
    if (flag == 1 || flag == 2) return 0;
    /* root objects I just don't save, cuz I clone em later--no risk :^) */
    if (root(what)) return 0;

    sh = (string) what->short();
    file = basename(what);
    args = (mixed) what->locker_arg(1);
    restore(nom);
    
    if (Items)
      Items += ({ sh, file, args, });
    else
      Items = ({ sh, file, args, });
    
    /* save now? */
    save(nom);
    return 1;
}

object
retrieve_item(string nom, string str)
{
    object ob;
    string err;
    int i;
    
    if (!stringp(nom) || !stringp(str)) return 0;
    restore(nom);
    if (!Items || !sizeof(Items)) return 0;
    
    i = atoi(str);
    if (i < 1) return 0;
    i = 3*(i - 1);
    if (i >= sizeof(Items)) return 0;
    
    err = catch(ob = clone_object(Items[i + 1]));
    if (err) {
	if (this_player() && wizardp(this_player()))
	  write(err);
	return 0;
    }
    
    ob->locker_init(Items[i + 2]);
    Items = deletea(Items, i, i + 2);
    save(nom);
    return ob;
}

string
list_items(string nom)
{
    string tmp;
    int i, j, z;
    
    if (!stringp(nom)) return 0;
    restore(nom);
    if (!Items) return 0;/* 3.1.2-DR comp */
    
    z = sizeof(Items);
    for (j = 1, tmp = ""; i < z; i += 3, j++)
      if (Items[i]) tmp += j + ".\t" + Items[i] + ".\n";
    if (tmp == "") return 0;
    return tmp;
}

int
items_stored(string nom)
{
    if (!stringp(nom)) return 0;
    restore(nom);
    if (!Items) return 0;/* 3.1.2-DR comp */
    return sizeof(Items)/3;
}

status
remove_item(string nom, string str)
{
    int i;
    
    if (!stringp(nom) || !stringp(str)) return 0;
    restore(nom);
    if (!Items) return 0;
    
    i = atoi(str);
    if (i < 1) return 0;
    i = 3*(i - 1);
    if (i >= sizeof(Items)) return 0;
    
    Items = deletea(Items, i, i + 2);
    save(nom);
    return 1;
}
