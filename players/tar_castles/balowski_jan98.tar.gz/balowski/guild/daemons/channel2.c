/*
 * Shardak guild - (tm) Dragnar/John
 * Channel daemon is (c) Balowski/Rasmus, April 30th 1995.
 * Change log:
 * Sept 17th:   Now maintaining a list of guild objects
 *              This is more like a guild member daemon now
 */
#pragma strict_types
inherit "/players/balowski/std/colour";

mapping Channels;
#include "/players/dragnar/closed/color.h"

#if 0
//object          *marks;         /* all clones of the guild object */
				/* like MudOS: children(GUILDOBJ); */
#endif
/*----------------------------------------------------------------------*/
/* Description:                                                         */
/*    Called by the driver at creation and every xx minutes             */
/*----------------------------------------------------------------------*/
void
reset(int arg)
{
    if (!arg) {
	Channels = ([ ]);
	colour::create();
    }
}

/*----------------------------------------------------------------------*/
/* Description:                                                         */
/*    Add a new guild object to the marks array                         */
/*----------------------------------------------------------------------*/
void
register(object mark, mixed chan)
{
    object  *marks;
    int     i;

    if (pointerp(chan)) {
	i = sizeof(chan);
	while (i--) register(mark, chan[i]);
	return;
    }
    
    if (!(marks = Channels[chan])) {
	Channels[chan] = ({ mark });
    }
    else {
	/* avoid duplicates and use empty slots */
	if (member_array(mark, marks) < 0) {
	    if ((i = member_array(0, marks)) < 0)
	      Channels[chan] = marks + ({ mark });
	    else
	      marks[i] = mark;
	}
    }
}

/*----------------------------------------------------------------------*/
/* Description:                                                         */
/*    Remove a guild object from the marks array                        */
/*----------------------------------------------------------------------*/
void
deregister(object mark, mixed chan)
{
    object  *marks;
    int i;

    /*
     * To shrink the array or not, that is the question
     * I choose to shrink it, but setting entry to zero could suffice
     */
    if (pointerp(chan)) {
	i = sizeof(chan);
	while (i--) {
	    if (marks = Channels[chan[i]]) {
		Channels[chan[i]] = marks - ({ mark });
	    }
	}
	return;
    }
    if (marks = Channels[chan])
	Channels[chan] = marks - ({ mark });
}

/*----------------------------------------------------------------------*/
/* Description:                                                         */
/*    Export the marks array                                            */
/*----------------------------------------------------------------------*/
object *
users(string chan)
{
    /*
     * Can contain blanks. Could be avoided by using destructor(),
     * but that is specific to the DR driver (I can't use it at home)
     */
    return Channels[chan];
}

/*----------------------------------------------------------------------*/
/* Description:                                                         */
/*    Send a message to all the listeners (people with marks)           */
/* Parameters:                                                          */
/*    msg      : text to be sent. ex: "Smurf goes hop hop hop.\n"       */
/*    priority : not used yet. (for gc channel and overriding muffle)   */
/*----------------------------------------------------------------------*/
void
broadcast(string msg, int priority, string chan)
{
    int i;
    string cmsg, bwmsg;         /* in colour or b/w */
    object *men;

    if (!(men = Channels[chan]))
	return;
    bwmsg = terminal_colour(msg, "unknown");
    cmsg = terminal_colour(msg, "ansi");

    i = sizeof(men);
    if (chan == "Blood") {	/* yet another patchy solution */
	/*
	 * The receive_message() function in the mark sends the message
	 * to bearer of the mark. It also checks for muffled and color
	 */
	while (i--)
	  if (men[i])
	    men[i]->receive_message(priority, bwmsg, cmsg);
    }
    else {
	while (i--)
	  if (men[i])
	    tell_object(men[i], query_attribute("ansi", men[i]) ? cmsg : bwmsg);
    }
}

status
feeling(string arg, string chan, string prefix)
{
    string verb, args;
    object *men;
    int i;

    if (!(men = Channels[chan]))
	return 0;
    if (sscanf(arg, "%s %s", verb, args) <= 1)
      verb = arg;
    i = (int) call_other("players/balowski/daemons/atmos",
			 "do_cmd", verb, args,
			 prefix, Channels[chan]);
    if (!i) notify_fail("Unknown feeling.\n");
    return i;
}

varargs void
message(string prefix, string msg, mixed rec, mixed excl)
{
    if (prefix) msg = prefix + " " + msg;
    if (objectp(rec)) {
	msg = terminal_colour(msg, query_attribute("ansi", rec) ? "ansi"
								: "unknown");
	tell_object(rec, msg);
    }
    else if (pointerp(rec)) {
	int i; string bwmsg;

	if (excl) rec -= excl;
	i = sizeof(rec);
	if (!i) return;
	else if (i == 1) return message(0, msg, rec[0]);

	bwmsg = terminal_colour(msg, "unknown");
	msg = terminal_colour(msg, "ansi");
	while (i--)
	  if (rec[i])
	    tell_object(rec[i], query_attribute("ansi", rec[i]) ? msg : bwmsg);
    }
}
