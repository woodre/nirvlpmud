inherit "obj/armor";
reset(arg){
   ::reset(arg);
    set_short("A Pair of Converse All-Stars");
   set_arm_light(0);
        set_long("A Pair of Black Converse All-Stars\n");
   set_ac(2);
   set_weight(1);
   set_value(500);
   set_alias("shoes");
   set_name("high tops");
   set_type("boots");
}
