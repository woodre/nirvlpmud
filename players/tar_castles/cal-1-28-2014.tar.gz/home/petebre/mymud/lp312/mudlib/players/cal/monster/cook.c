


inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "cook" );
     set_short("The Castle Cook");
	set_long("This is the castle cook. He has been \n"+
                 "cooking for Cal and his followers for\n"+
                 "many many years and he is very good at\n"+
                 " what he does. Maybe if your lucky you\n"+
                 "can get a taste of some of his food..\n");
     set_alias("cook");
     set_level(21);
     set_wc(27);
     set_ac(31);
     set_hp(600);
     set_al(-100);
     set_aggressive(0);
      set_chat_chance(40);
     load_chat("The cook removes his apron as he prepares for a relaxing shower and a nap before dinner...\n");
     load_chat("The Cook says: Hello there, how may I help you?\n");
     load_chat("The cook turns from his meal to look at you.  He says : DOES THIS LOOK LIKE THE KITCHEN?\n");
     load_chat("The cook says: You should taste my Chicken Ala'king, it is simply marvelous.\n");
      money = (300);
   } 
   }
