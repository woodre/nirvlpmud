
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/Entrance", "west",
         "/players/cal/room/HallA2a", "east",
       " Hallway",
"The hallway you are walking down is made like\n"+
"those in the early times, when knights and kings\n"+
"walked the realm.  The castle seems to be in great\n"+
"condition considering its age...You know it has been\n"+
"well kept, even if it hasen't been used much lately..\n",1)

