

inherit "obj/weapon";

int i;

reset(arg) {

::reset(arg);

if(arg) return;

       set_alias("mallet");

       set_name("a large metel mallet");

    set_short("A Large Metal Mallet");

	set_long("This is the mallet used to forge weapons made of steel\n" +

	", you can tell it is strong just by the noise it makes when it\n" +

	"hits the anvil....You can do a lot of damage with this...\n");

       set_class(17);

       set_weight(3);

       set_value(700);

}



