
#include "room.h"

realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA5c.c", "east",
         "/players/cal/room/HallA7c", "west",
       " Hallway",
"As you walk slowly through this Hallway you \n"+
"continuously hear a thumping sound coming from\n"+
" the wall to your north...What ever could make a\n"+
 "sound that loud in a stone wall castle?..Mabey it\n"+
 "is better if you don't find out..\n",1)
