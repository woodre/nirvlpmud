
#include "room.h"

object knight,ob;


THREE_EXIT("/players/cal/room/CtrA6a.c", "east",
       "/players/cal/room/CtrA6.c", "west",
       "/players/cal/room/CtrA4.c","south",
            "A Musty Hallway",
"The prisons of this castle lie to the east, to the west is anouther\n" +
"hallway leading, in what seems to be, a southward direction...\n",1)
