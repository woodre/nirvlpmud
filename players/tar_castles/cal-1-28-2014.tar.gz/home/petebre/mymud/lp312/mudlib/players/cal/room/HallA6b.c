
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA7b.c", "west",
         "/players/cal/room/HallA5b.c", "east",
       " Hallway",
"The Hallway you are in seems to take a turn to the north\n"+
" ahead of you,  It seems to be getting dark as well. Maybe\n"+
"you should get a torch or somehting before you venture further..\n",1)
