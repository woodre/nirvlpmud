
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA7c", "north",
         "/players/cal/room/HallA1b", "east",
       "Hallway",
"You have come to a wierd turn in the castle shape..\n"+
"You wonder why it is here...\n",1)
