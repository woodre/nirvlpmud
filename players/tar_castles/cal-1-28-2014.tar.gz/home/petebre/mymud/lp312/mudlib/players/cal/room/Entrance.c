
#include "room.h"

object guard,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
 if(!guard || (present("guard"))) {
guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());
}
    }
THREE_EXIT("/room/forest9", "south",
         "/players/cal/room/HallA1a", "east",
         "/players/cal/room/HallA1b", "west",
       "Castle Entrance",
"You feel awe at the size of the castle just standing here \n"+
   "in the doorway...Do you really want to go further into ...\n"+
   "this castle...Think about it...\n",1)
