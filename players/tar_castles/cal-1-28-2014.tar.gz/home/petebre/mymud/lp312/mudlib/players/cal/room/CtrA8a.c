#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/Gary.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/weapons/pillow2.c");
move_object(ob1, monster);


}
}

TWO_EXIT("/players/cal/room/CtrA7a.c", "north",
         "/players/cal/room/CtrA9a.c", "south",
       "Gary's Cell",
"Entering this cell you notice the computer on the\n"+
"desk, it is small yet it is connected to nirvana on\n"+
"the vax.  You also notice the bed is made and the room\n"+
"is well kept, be leary of the pillow if you decide to sit..\n",1)



