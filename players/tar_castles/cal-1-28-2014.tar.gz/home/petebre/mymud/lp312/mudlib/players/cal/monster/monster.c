inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "knight" );
     set_short(" Ghost of Knight");
set_long("This is the Ghost of a Knight from battles long past\n"+
"He has seen many battles and has returned to guard this once mighty castle.\n");
     set_alias("knight");
     set_level(15);
     set_ac(25);
     set_wc(35);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
 ob=clone_object("/players/cal/items/treasure.c");
   move_object(ob, this_object());
     money = (2832);
   }
}
