
#include "room.h"

object guard,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
   if(!guard || (present("guard"))) {
guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());
 
guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());
 
 
guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());

guard = clone_object("players/cal/monster/mguard.c");
      transfer(guard, this_object());}
}
   
ONE_EXIT("/players/cal/room/HallA8c.c", "north",
       "Secret Room",
"You feel very fortunate when you found the doorway\n"+
" that led into this room but now you wonder if you\n"+
" should have left it closed...\n",1)
