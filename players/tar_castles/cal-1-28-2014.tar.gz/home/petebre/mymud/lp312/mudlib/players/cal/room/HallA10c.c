
#include "room.h"

object guard,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA9c.c", "east",
         "/players/cal/room/HallA11c", "west",

     "Hallway",
" The hallway comes to an end to the west.  It \n"+
"seems you should turn back and try anouther way\n"+
" to go through the castle...\n",1)

