inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "leo" );
     set_short("Leo");
	set_long("Leo is a prisoner to the castle, if you\n"+
                  "you will find out why...\n");
     set_alias("leo");
     set_level(12);
     set_wc(18);
     set_ac(25);
     set_hp(400);
     set_al(-50);
     set_aggressive(4);
    set_chat_chance(40);
   load_chat("Leo looks up at the picture of the dog and points..\n");
   load_chat("Leo says: You see that, he prayed to it every night, I just couldn't take it..\n");
   load_chat("He sounded like my mom...I couldn't take it, I came to school to get away from her...\n");
   load_chat("Leo says: Don't make me hurt you.\n");
   load_chat("Leo stares dreamily at the picture of his favorite woman 'Black Cat' and dreams of the day the two of them will be together\n");
   load_chat("Leo burps loudly and starts to say F--K You Nate, when he realizes Nate is gone...Suddenly Leo cackles with Glee!!\n");
   load_chat("Leo grabs his red notebook and runs to get on Nirvana so he can code and piss off newbies...\n");

    money = (300);
   } 
   call_out("set_heal",20,35);
   }
