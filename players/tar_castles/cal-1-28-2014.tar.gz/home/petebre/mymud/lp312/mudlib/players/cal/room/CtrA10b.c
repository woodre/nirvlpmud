#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/Ted.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/shower.c");
move_object(ob1, monster);


}
}

TWO_EXIT("/players/cal/room/CtrA9b.c", "north",
         "/players/cal/room/CtrA9a.c", "west",
       "Ted's Cell",
" This cell is very cluttered has a distinctly\n"+
"foriegn smell. You begin to wonder how anyone\n"+
"could stand to live in this environment..\n"+
"Looking around however you see that the man\n"+
"who lives her is a well respected man who just\n"+
"needs to clean it up a bit...\n",1)




