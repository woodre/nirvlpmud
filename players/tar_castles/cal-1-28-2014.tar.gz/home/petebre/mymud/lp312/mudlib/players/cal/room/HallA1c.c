
#include "room.h"

realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA4a", "south",
         "/players/cal/room/HallA2c", "west",
       "Hallway",
"You have rounded anouther corner to find that\n"+
" you can see anouther corner off in the distance\n"+
" to the south..Looking around you see you have no\n"+
" choice but to go forward or head back...Suddenly\n"+
" you hear a scream deep from within the castle..\n"+
"You should really consider going back to the safety\n"+
" of the other castles...\n",1)
