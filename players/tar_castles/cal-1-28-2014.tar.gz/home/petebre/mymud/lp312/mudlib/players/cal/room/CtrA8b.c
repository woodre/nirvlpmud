#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/Sandra.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/weapons/razor.c");
move_object(ob1, monster);


}
}

TWO_EXIT("/players/cal/room/CtrA7b.c", "north",
         "/players/cal/room/CtrA9b.c", "south",
       "Sandra's Cell",
"As you enter this cell you notice it is filled\n"+
"with a large number of beauty items that would\n"+
"be used to make one's self look better..  Whoever\n"+
" they belong to sure looks like they could use it\n"+
"You also notice a razor filled with icky hair setting\n"+
"by the mirror, you wonder what it ws used for...\n",1)


