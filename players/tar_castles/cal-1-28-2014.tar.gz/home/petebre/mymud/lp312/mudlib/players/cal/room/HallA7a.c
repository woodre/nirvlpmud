
#include "room.h"

realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA6a", "west",
         "/players/cal/room/HallA8a", "north",
       " Hallway",
"The Hallway takes a severe turn to the north \n"+
"and you notice that about halfway up you can not\n"+
" see anything because it grows to dark to see...\n",1)
