#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/Grahm.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/shin_guards.c");
move_object(ob1, monster);


}
}

TWO_EXIT("/players/cal/room/CtrA8b.c", "south",
         "/players/cal/room/CtrA6a.c", "west",
       "Grahm's Cell",
"This cell is spacious yet it is very old, you\n"+
"wonder how anyone can live with all the boxes on\n"+
"the floor when there is soo much open space \n"+
"on the closet shelves...\n",1)




