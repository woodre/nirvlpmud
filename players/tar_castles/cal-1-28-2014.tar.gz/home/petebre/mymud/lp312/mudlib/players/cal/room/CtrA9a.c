#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/Pete.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/rags.c");
move_object(ob1, monster);


}
}

TWO_EXIT("/players/cal/room/CtrA8a.c", "north",
         "/players/cal/room/CtrA10b.c", "east",
       "Pete's Cell",
" This cell is filled with books of imagionary war times\n"+
"There are little playing cards with pictures all over\n"+
"the floor and desk.  Looking around you see a large\n"+
"number of pornographic videos lying about, this man had\n"+
" taste...\n",1)



