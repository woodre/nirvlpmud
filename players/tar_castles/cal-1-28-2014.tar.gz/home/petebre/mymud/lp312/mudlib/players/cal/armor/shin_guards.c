
inherit "obj/armor";
reset(arg){
   ::reset(arg);
    set_short("A pair of Soccor Shin Guards");
   set_arm_light(0);
        set_long("A Pair of Nike Shin Guards made for Soccor\n");
   set_ac(1);
   set_weight(1);
   set_value(500);
   set_alias("shin guards");
   set_name("shin guards");
   set_type("boots");
}

