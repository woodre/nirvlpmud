


inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "sandra" );
     set_short("Sandra");
	set_long("Sandra is a prisoner to the castle, if you listen to her whining\n"+
                  "you will find out why...\n");
     set_alias("sandra");
     set_level(12);
     set_wc(18);
     set_ac(25);
     set_hp(400);
     set_al(-50);
     set_aggressive(0);
      set_chat_chance(20);
   load_chat("Sandra whines: But he said I looked like Lorena Bobbit..\n");
   load_chat("Sandra picks up the razor and turns her back to you as she shaves...\n");
   load_chat("It's not my fault..I don't know how the razor got in the bed...\n");
   load_chat("Sandra says: Settle down boys...\n");

     money = (300);
   } 
   }
