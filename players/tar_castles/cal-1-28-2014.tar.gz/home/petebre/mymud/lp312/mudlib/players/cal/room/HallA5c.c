
#include "room.h"

TWO_EXIT("/players/cal/room/HallA4c.c", "east",
       "/players/cal/room/HallA6c.c", "west",
       "Hallway",
"You seem to be at the spot where the noise from the north is at it's loudest point...\n" +
"You could feel the virbrations from the noise if you touch the wall...\n",1)
init() {
    ::init();
add_action("touch","touch");
}
touch(str) {
if(!str) {
     return 0;
}
if(str == "wall") {
    call_other(this_player(),"move_player","search#players/cal/room/CtrA1.c");
return 1;
}
}

#include "room.h"

TWO_EXIT("/players/cal/room/HallA4c.c", "east",
       "/players/cal/room/HallA6c.c", "west",
       "Hallway",
"You seem to be at the spot where the noise from the north is at it's loudest point...\n" +
"You could feel the virbrations from the noise if you touch the wall...\n",1)
init() {
    ::init();
add_action("touch","touch");
}
touch(str) {
if(!str) {
     return 0;
}
if(str == "wall") {
    call_other(this_player(),"move_player","search#players/cal/room/CtrA1.c");
return 1;
}
