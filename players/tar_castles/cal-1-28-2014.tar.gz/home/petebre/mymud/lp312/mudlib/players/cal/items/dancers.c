inherit "obj/treasure";

reset(arg) {
 if(arg) return;
set_short(" An Invitation");
set_alias("invitation");
set_long("This is an invitation to the Ball that is being put on by the Wizard Cal..make sure you have one before you enter the next room.\n");
   set_weight(1);
    set_value(0);
}
 id(str) { return str == "invitation" || str == "Cal's Invitation"; }

