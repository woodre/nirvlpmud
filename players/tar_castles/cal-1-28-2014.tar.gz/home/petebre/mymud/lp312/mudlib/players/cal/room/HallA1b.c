
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/Entrance", "east",
         "/players/cal/room/HallA2b", "west",
       " Hallway",
"This Hallways spreds further out in each direction..\n"+
"You walk slowly looking around carefully for there\n"+
" are many traps and secrets hidden in this castle...\n"+
"Do you think you can find them all??\n",1)

