
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA1a", "west",
         "/players/cal/room/HallA3c", "north",
       " Hallway",
"This Hallways spreds further out in each direction..\n"+
"you walk slowly looking around carefully for there\n"+
" are many traps hidden in this castle...\n"+
"Do you think you can find them all??\n"+
"Maybe you should turn back if you are not sure of yourself.\n",1)

