
inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "gary" );
     set_short("Gary");
	set_long("Gary is a prisoner to the castle, if  you listen to him\n"+
                  "you will find out why...\n");
     set_alias("gary");
     set_level(18);
     set_wc(32);
     set_ac(24);
     set_hp(700);
     set_al(-150);
     set_aggressive(0);
     set_chat_chance(30);
     load_chat("Gary says: Is it my fault  he couldn't breath through the pillow?\n");
     load_chat("Gary squats down slightly, squints his face, and walks down the hallway arms flailing...\n");
     load_chat("Gary says: My computer would be great with a little High Mem...\n");
     load_chat("Gary shouts: 10 inches limp!!!! Then he falls quiet, He knows nothing more needs to be said...\n");
     load_chat("Gary shouts: But It isn't my fault...\n");
     load_chat("Gary points at his bed and says: He sat on my pillow, what did you expect me to do?\n");
     load_chat("Gary warns: I told him over and over again, not to ASS my pillow..\n");
     load_chat("Gary looks at you and says: Don't you dare sit on my pillow!!\n");
     money = (300);
   } 
call_out("set_heal",60,45);
   }
