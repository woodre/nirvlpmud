
#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();
              extra_reset() {

   if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/blacksmith.c");                  			 
     transfer(monster, this_object());
   

monster = clone_object("players/cal/monster/slave.c");
   transfer(monster, this_object());
   ob1 = clone_object("players/cal/armor/rags.c");
   move_object(ob1, monster);

monster = clone_object("players/cal/monster/slave.c");
    transfer(monster, this_object());
    ob1 = clone_object("players/cal/armor/rags.c");
    move_object(ob1, monster);
    }
    }
TWO_EXIT("players/cal/room/CtrA2.c", "south",
          "players/cal/room/CtrA4.c", "north",
          "Blacksmith's Chamber",
   "You Have found the reason for all the pounding.  Before you \n"+
          "stands a large man holding a metal mallet.  He seems to be making \n"+
          "weapons as though a war is coming soon. You hope you can make it out\n"+
          "of the castle before that happens, who knows what would attack such \n"+
          " a large castle....\n",1)
