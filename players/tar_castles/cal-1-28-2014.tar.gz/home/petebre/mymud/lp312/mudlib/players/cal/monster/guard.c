inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
      object ob;
      set_name( "guard" );
      set_short(" A Castle Guard");
      set_long("This is one of the many Guards of this castle...\n" +
	"He has been trained well in order to defend the\n" +
         "castle to the best of his abilities...\n");
      set_alias("guard");
      set_level(18);
      set_ac(20);
      set_wc(35);
      set_hp(500);
      set_al(-500);
      set_aggressive(1);
      ob=clone_object("/players/cal/weapons/crossbow2.c");
      move_object(ob, this_object());
      money = (750);
   }
}
