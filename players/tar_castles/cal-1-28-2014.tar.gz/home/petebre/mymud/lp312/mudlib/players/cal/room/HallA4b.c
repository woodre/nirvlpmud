
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA5b.c", "west",
         "/players/cal/room/HallA9c.c", "north",
       " Hallway",
"You have rounded yet anouther corner in this magnificently\n"+
" old castle..You are amazed at how well preserved this wing\n"+
" of the castle seems to be..You would even assume that there\n"+
" were people living here if you didnt know better...\n",1)

