
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
ONE_EXIT("/players/cal/room/HallA10c.c", "east",
     "Hallway",
"You have reached the end of this hallway..\n"+
" turn back and try anouther way....\n",1)

