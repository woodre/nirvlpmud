#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/Leo.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/rags.c");
move_object(ob1, monster);


}
}

TWO_EXIT("/players/cal/room/CtrA8b.c", "north",
         "/players/cal/room/CtrA10b.c", "south",
       "Leo's Cell",
" This cell has pictures pinned to the walls all over the\n"+
"place.  There is even a picture of a dog over the door with\n"+
"darts stuck in it.  The bed is soft and rolls about but the desk\n"+
"is small. The clutter in the room buries the floor completely\n",1)

