
#include "room.h"

object guard,ob,ob1;

#undef EXTRA_RESET
#define EXTRA_RESET\
        extra_reset();

        extra_reset() {
  if(!guard || (present("guard"))) {
      guard = clone_object("players/cal/monster/guard.c");
         transfer(guard, this_object());
  
      guard = clone_object("players/cal/monster/guard.c");
         transfer(guard, this_object());}
  

      }
TWO_EXIT("/players/cal/room/HallA1c.c", "east",
       "/players/cal/room/HallA3c.c", "west",
       "Hallway",
  " The  Footprints that you followed into this room seem to\n" +
  "dissapear right in the center of this room ...Where could they have gone...\n" +
  "They couldn't have possibly walked through the wall.\n",1)

init() {
    ::init();
add_action("search","search");
}
search(str) {
if(!str) {
     return 0;
}
if(str == "wall") {
    call_other(this_player(),"move_player","search#players/cal/room/HallA3a.c");
return 1;
}
}
