


inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "graham" );
     set_short("Graham");
	set_long("Graham is a prisoner to the castle, if you listen to his tale\n"+
                  "you will find out why...\n");
     set_alias("graham");
     set_level(12);
     set_wc(18);
     set_ac(25);
     set_hp(400);
     set_al(-50);
     set_aggressive(0);
  set_chat_chance(20);
   load_chat("Graham points: Look at all the stuff on the floor...It is all his..\n");
   load_chat("Graham explains: He tripped, realy he did..And then he cut his neck on a box..\n");
   load_chat("Graham looks at you quizzically and says: I told him to clean it up...The knife?...What knife?...I don't know how it got in my hands...\n");

    money = (300);
   } 
   }
