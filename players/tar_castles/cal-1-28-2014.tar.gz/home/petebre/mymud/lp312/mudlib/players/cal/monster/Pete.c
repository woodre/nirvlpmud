


inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "pete" );
     set_short("Pete");
	set_long("Pete is a prisoner to the castle, if you pay attention to him\n"+
                  "you will find out why...\n");
     set_alias("pete");
     set_level(12);
     set_wc(18);
     set_ac(25);
     set_hp(400);
     set_al(-50);
     set_aggressive(0);
 set_chat_chance(20);
   load_chat("Pete says: She just couldn't listen, I told her that seafood soup made me sick..\n");
   load_chat("Pete says: And then, on top of it all, she beat me in Magic again...And she BRAGGED..\n");
   load_chat("Pete says: If you want to watch a movie your gonna have to pay...\n");
   load_chat(" Pete says: You know there are some really good porns out there, and none of them had you in them...\n");

     money = (300);
   } 
   }
