inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "blacksmith" );
     set_short(" A large and strong Blacksmith");
set_long("This is the castles Blacksmith..He makes all\n" +
	"of the weapons for the guards and people of this castle\n" +
	" you can see by his tall figure and enormous build he has \n" +
	"been doing it for a while...mabey you should just leave him be...\n");
     set_alias("blacksmith");
     set_level(30);
     set_ac(25);
     set_wc(40);
     set_hp(1500);
     set_al(-50);
     set_aggressive(0);
   set_chat_chance(40);
 load_chat("The Blacksmith looks up from his work to give you a look of malign evil\n");
   load_chat("The Blacksmith's muscles ripple with each pound of his mallet\n");
   load_chat("The Blacksmith says: Stop staring at me and get the @#%#&*@ to work!!\n");
 load_chat("The Blacksmith says: Bring me that iron ore and make it quick I don't have all ##@*^% day!!\n");
 ob=clone_object("/players/cal/weapons/blacksmith.c");
   move_object(ob, this_object());
     money = (4500);
   }
}
