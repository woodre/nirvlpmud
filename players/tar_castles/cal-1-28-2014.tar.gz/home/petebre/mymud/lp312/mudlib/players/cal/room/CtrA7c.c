
#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();
              extra_reset() {

   if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/maid.c");                  			 
     transfer(monster, this_object());
   
    }
    }
TWO_EXIT("players/cal/room/CtrA8c.c", "south",
          "players/cal/room/CtrA6c.c", "north",
          "Workman's Quarters",
   "You have entered the quarters made for the workers of the castle\n"+
   "These quarters are extravagently decorated for the honorable \n"+
   "workers of the castle.  This room happens to be the room of the\n"+
   "maid.  She cleans and takes care of the castle when it needs to be\n"+
   " as well as preparing for parties and Balls when they are planned...\n",1)
