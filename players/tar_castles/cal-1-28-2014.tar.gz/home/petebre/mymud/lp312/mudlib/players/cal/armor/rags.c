
inherit "obj/armor";
reset(arg){
   ::reset(arg);
    set_short("Some Soiled Rags");
   set_arm_light(0);
        set_long("A Outfit of rags fit for a slave..\n");
   set_ac(2);
   set_weight(1);
   set_value(500);
   set_alias("rags");
   set_name("rags");
   set_type("armor");
}

