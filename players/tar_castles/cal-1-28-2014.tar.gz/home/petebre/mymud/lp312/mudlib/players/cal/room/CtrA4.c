#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/slave.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/rags.c");
move_object(ob1, monster);

monster = clone_object("players/cal/monster/slave.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/rags.c");
move_object(ob1, monster);
}
}

TWO_EXIT("/players/cal/room/CtrA5.c", "north",
         "/players/cal/room/CtrA3.c", "south",
       "A Musty Hallway",
" You were lucky to make it out of that last room alive.\n"+
" However there is a long road ahead of you that you must travel\n"+
"to call yourself a hero - heroin....\n",1)
