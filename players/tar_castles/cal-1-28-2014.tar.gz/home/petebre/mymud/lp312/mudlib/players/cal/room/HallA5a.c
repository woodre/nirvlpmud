
#include "room.h"

realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA4a", "west",
         "/players/cal/room/HallA6a", "east",
       " Hallway",
"You are very brave to have have come this far \n"+
"into the castle maybe you have what it takes to \n"+
"defeat the evil that has overtaken it's depths..\n",1)
