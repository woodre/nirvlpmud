
#include "room.h"

object guard,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
 if(!guard || (present("guard"))) {
guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());

guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());
  
    }
    }
THREE_EXIT("/players/cal/room/HallA2a", "south",
         "/players/cal/room/HallA2c", "east",
         "/players/cal/room/HallA4c", "west",
       "Hallway",
  "You have entered what appears to be anouther Hallway.\n"+
  " There are footprints slightly covered with dust \n"+
  "leading to the east, and to the west the Hall continues\n"+
  " for what looks to be forever...\n",1)
