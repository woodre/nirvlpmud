
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg) ;
set_short ("A White Shower Cap");
     set_long("This is Ted's Shower cap. He wears it when he takes a shower..It is like new.\n");
    set_ac(1);
    set_weight (1) ;
    set_value (150) ;
     set_alias ("showercap");
    set_name ( "Ted's Showercap" ) ;
    set_type ( "helmet" ) ;
  }
