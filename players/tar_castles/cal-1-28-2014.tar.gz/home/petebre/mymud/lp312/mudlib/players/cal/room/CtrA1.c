#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}

TWO_EXIT("/players/cal/room/CtrA2.c", "north",
         "/players/cal/room/HallA5c", "south",
       "Center Room",
     "The wall has moved away to reveal a hidden passage leading toward\n"+
     "the center of the castle. The pounding grows louder to the north\n"+
     "mabey you should turn around now before it finds you....\n",1)
