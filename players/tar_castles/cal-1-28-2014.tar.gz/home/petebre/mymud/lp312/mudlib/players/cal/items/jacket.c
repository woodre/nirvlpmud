inherit "obj/treasure" ;

	query_auto_load(){
		return "/players/cal/armor/jacket.c:";}
       drop() {return 1;}
     get() {return 1;}
reset(arg)
{
     if(arg) return;
    set_short ( "Official Cal Fan Club Jacket" ) ;
	set_long("A jacket with your idol...Cal pictured on it.\n");
    set_weight (0) ;
    set_value (0) ;
    set_alias ( "jacket" ) ;
  }
