
inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
      object ob;
      set_name( "leader" );
      set_short(" LEADER of the Castle Guard");
      set_long("This is the leader of all of the Guards of this castle...\n" +
	"He has been trained well in order to defend the\n" +
         "castle to the best of his abilities...you best not mess with him...\n");
      set_alias("leader");
      set_level(37);
      set_ac(35);
      set_wc(40);
      set_hp(2000);
      set_al(500);
      set_aggressive(0);
      ob=clone_object("/players/cal/weapons/crossbow.c");
      move_object(ob, this_object());
      money = (2000);
      }
    call_out("set_heal",5,5);
      }
