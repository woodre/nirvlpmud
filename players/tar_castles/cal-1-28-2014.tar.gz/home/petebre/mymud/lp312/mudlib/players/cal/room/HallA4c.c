
#include "room.h"

realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA3c.c", "east",
         "/players/cal/room/HallA5c", "west",
       " Hallway",
"As you walk slowly through this Hallway you continuously \n"+
"hear a thumping sound coming from the wall to your \n"+
"northeast...What ever could make a soud that loud in a \n"+
"stone wall castle?..Mabey it is better if you don't find out..\n",1)
