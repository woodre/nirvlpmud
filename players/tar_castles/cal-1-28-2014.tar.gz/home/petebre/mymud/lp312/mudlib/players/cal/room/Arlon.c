


#include "room.h"

string str;
realm() {return "NT";}

  
    
    
TWO_EXIT("/players/cal/workroom.c", "north",
          "players/cal/workroom.c", "south",
          "Village Road",
  	"	The cool summer breeze blows through the window to blow lightly	\n"+
   	"across your face as you look out the window.  From where you stand you \n"+
	"can see the sunsetting over the horizon.  The pinks and reds of the 	\n"+
	"night sky light up your eyes with a new vision of joy and beauty. 	\n"+
	"The stars have begun to form on the outer reaches of the setting sky 	\n"+
	"as they prepare for their night long vigil.  You step from the window 	\n"+
	"and look around the room for the first time.  The basic model of the room \n"+
	"seems to have been done from the early time periods when castles covered \n"+
	"the lands.  The beautiful furniture and tapestries that cover the walls \n"+
	"look to be brand new even though they are hundreds of years old.  To the \n"+
	"far side of the room you see a hand carved oak bed with a full canopy. To\n"+
	"your left you can see the large stone fireplace, the wood is statcked 	\n"+
	"neatly to one side and there are three logs setting in the fireplace 	\n"+
	"awaiting use.  Before the fireplace, on the floor, lies a soft white rug\n"+
	"that loves very soft as though you could fall asleep om it easily\n"+
	"On the mantle above the fireplace you notice are a few items of great	\n"+
	"importance to Cal.  As you examine them more closely you see exactly	 \n"+
	"what they are.  The largest item is a shield hung center above the 	\n"+
	"fireplace with two longswords of incredible beauty crossing behind it	\n"+
	"and passing out on the four sides.  There are two candlestick holders 	\n"+
	"each holding ten candles that are lit and glowing brightly, shining    \n"+
	"softly upon Cal's favorite possession, a picture. If you look closely	\n"+
	"at the picture you might be able to tell who it is inside it.		\n"+
	"	As you continue to look around the room you notice a large	\n"+
	"glass door leading outside onto the balcony.  You seem to feel drawn	\n"+
	"outdoors for some reason.  Once you step outside you realize what it	\n"+
	"was that had drawn you there.  Off on the far end of the balcony you see\n"+
	"a figure of a man.  The stars are out bringht now for the last of the sun\n"+
	"has dissapeared below the horizon. The moon is full and you can make out\n"+
	"the back of Aaron as he hears you step onto the balcony and turns to face\n"+
	"you.  As he turns you see he is dressed completly in black, including the\n"+
	"cape that billows out around his body with a life of its own.  He looks\n"+
	"at you and you see the stars that you had just seen in the sky reflected\n"+
	"in his eyes.  He smiles softly as he reaches out a hand to you and somehow\n"+
	"you feel completely safe.  He steps toward you with that same smile and\n"+
	"takes your hand, squeezing it softly, as he leads you to the balcony's edge\n"+
	"so you may look over.  From where you are you look down and you see the ocean\n"+
	"far below you, well over 100 feet.  You go to say something to Cal and he\n"+
	"places a finger tip softly upon your lips.  He motions you not to say anything	\n"+
	"and as you listen, in the still of the silence between you, you hear the\n"+
	"ocean waves hitting the rocks far below.  Cal turns to you and leans closer,\n"+
	"you can feel his heart beat against your hands as he pulls you to him and he\n"+
	"whispers softly into your ear.  'All this,' Cal says gliding a hand softly over\n"+
	"the house and the horizon around you.'All this is what I give to you, for it is\n"+
	"all I wish for you, to be happy, to be free, to be with me...' Cal's voice fades\n"+
	"out softly to the sounds of the waves hitting the rocks then even they give out to\n"+
	"the sound of your heartbeats as Cal leans forward and kisses you lightly.\n",1)

init(){
    ::init();
	add_action("close","close");
	add_action("look","look");
	add_action("start","start");
	add_action("lay","lay");
	add_action("lip","lip");
	add_action("bed","bed");
	add_action("leave","leave");
	add_action("read","read");
if((this_player()->query_real_name()) == "arlon") {
write("Entrance approved.\n");
return 1;
}
else {
move_object(this_player(),"room/church");
return 1;
}
	}

close(str) {
   if(!str) {
      	return 0;
	}
   if(str == "canopy") {
       write("You pull the drawstrings on the canopy and it falls\n"+
             " around you and your lover...\n");
       say("Cal reaches back and pulls the drawstrings holding the curtains\n"+
           "of the canopy.  The white curtains fall, enclosing the bed.\n"+
           "The soft candle light emitted from around the room places a soft,\n"+
           "romantic glow around you as you drift off together...\n");
	return 1;
	}}
look(str) {
   if(!str) {
      	write("You might want to look at something...To look at the room just type 'l'..\n");
      	return 1;
	}
if(str == "at picture") {
   write("As you gaze into this picture you see a familier face.\n"+
         "Looking more closely you realize that it is a picture\n"+
         "you and Cal on a beautiful day in the park..\n"+
         "Thinking back you can remember the day....It was warm\n"+
	 "and the sun was out bright.  Of all the many things the\n"+
	 "two of you did together that day the one thing you remember\n"+
	 "the most is the afternoon by the lake. You were in his arms\n"+
	 "and he was in yours.  You were together and that is what\n"+
	 "you loved most about that wonderful time.....\n");
	return 1;
	}}
start(str) {
   if(!str) {
	return 0;
	}
   if(str == "fire") {
  	write("You start a fire in the fireplace and the warmth begins \n"+
	"to spred across the room\n");
	say("Cal stands slowly and walks to the fireplace to prepare a fire. As\n"+
	"the fire starts to blaze you feel the warmth chasing the chills from\n"+
	"the room.  After he has finished Cal returns to your side, you can see\n"+
	"in his eyes he is glad he is with you...\n");
	return 1;
	}}
lay(str) {
   if(!str) {
	return 0;
	}
   if(str == "on rug") {
	write("You take her hand and guide her to the rug before \n"+
        "the fireplace as you lay down and wait for her to join you\n");
        say("Cal walks with your hand in his guiding you slowly\n"+
	"over to the fireplace where he slowly lays back onto the\n"+
	"rug beneath you..\n"+
	"Your eyes sparkle in the fire light as you look down\n"+
	"and see Cal looking up at you, his eyes asking you\n"+
        "to join him..\n");
	return 1;
	}}
lip(str) {
   if(!str) {
	return 0;
	}
   if(str == "arlon") {
	write("You take Arlon's lip into your mouth and suck gently\n");
	say("Cal pulls you close...\n"+
	"He presses his lips gently to yours\n"+
	"Cal sucks lightly bringing your lip into his mouth\n"+
	"where he continues to suck on your lip as he toys\n"+
	"with it with his tongue..\n");
	return 1;
        }}
bed(str) {
   if(!str) {
	write("Bed ? Bed what?\n");
	return 1;
        }
   if(str == "cal") {
	write("You lay upon the bed and cover yourself with pillows.\n");
	say("Cal walks slowly over to the bed and climbs on it.\n"+
	"You wonder what he is doing when you suddenly see him dissapear\n"+
	"beneath the many colored pillows that are scattered over the bed.\n"+
	"You wonder where he has gone...\n");
       return 1;
}
   if(str == "arlon") {
	write("You take Arlon and place her on the bed lovingly.\n");
	say("Cal picks you up and slowly carries you to the bed\n"+
	"where he puts you down delicately.  He turns and blows out\n"+
	"some of the candles that are scattered around the room\n"+
	"leaving enough light to light the room, then he comes to you..\n");
	return 1;
}}
leave(str) {
	if(!str) {
		write("Leave?...Must you go?\n");
		return 1;
		}
	if(str == "balcony") {
		write("You take her hand and you guide her inside to the warmth\n"+
		" and seclusion of the indoors.\n");
		say("Cal isses it softly. Then he slowly turns and guides you\n"+
		"inside where the two of you can be together alone for\n"+
		"that is his wish...To be with you..\n");
		return 1;
		}
	if(str == "world") {
		write("You take her into your arms and you leave the world behind\n");
		say("Cal takes you gently into his arms and whispers\n"+
		"to you of his love as the two of you, together, \n"+
		"leave the harshness of the world behind as you share\n"+
		"each others warmth...\n");
		return 1;
	}}
read(str) {
    if(!str) {
	return 0;
	}
    if(str == "cal's poetry") {
	write("You read softly your poetry to Jessica..\n");
	say("Cal pulls you to him softly as he reads you this poem..\n"+
	"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"+
	"In this place where I sit alone I look around at the things in my mind.\n"+
	"Looking there I see you.  Not in body and not in looks,\n"+
	"but the person who you are inside.\n"+
	"The real you, the lady I have grown to know and love\n"+
	"for the traits that I have searched an eternity for.\n"+
	"Then looking at you in body I find that you are attractive,\n"+
	"realizing the full potential of who you are in mind and body combined\n"+
	"I realize that you are a very special person.\n"+
	"May I look back in my mind and see the memories od who you are\n"+
	"and may they be combined with the visions of the future\n"+
	"to guide us to a place where we can live in harmony...\n"+
	"May the things I see in you be see in your eyes when you look at yourself,\n"+
	"for before you can love someone you must love yourself,\n"+
	"I have seen these wualities in you..can you find them in yourself?\n"+
	"May the beauty that you look at everyday become more clear,\n"+
	"for you are a lovely lady and I care for you very much....\n");
	return 1;
	}}

