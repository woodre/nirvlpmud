inherit "obj/treasure" ;

	query_auto_load(){
		return "/players/cal/armor/lunchbox.c:";}
       drop() {return 1;}
     get() {return 1;}
reset(arg)
{
     if(arg) return;
   set_short( " The Official Pavlik Lunchbox");
   set_long("This is a lunchbox with a picture of Pavlik on it...You cherish it more then anything...\n");
    set_weight (0) ;
    set_value (0) ;
    set_alias ( "lunchbox" ) ;
  }
