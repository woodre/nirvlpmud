
query_auto_load() {return"players/cal/items/Darnell.c:";}
   drop() {return 1;}
   get() {return 1;}

reset(arg) {
 if(arg) return;
set_short("A Tape of Music");
set_alias("tape");
set_long("This is a Tape made for Darnell with songs on it from someone who loves her.\n");
   set_weight(1);
    set_value(750);
}

init() {
     add_action("play","play");
}

play() {
write("Angel Eyes plays to you softly as you listen to the tape.\n" +
     "Girl your looking fine tonight...\n" +
       "And every guy has got you in his sight...\n" +
       "What your doing with a clown like me..\n" +
       "Is surely one of lifes little misterys.\n" +
       "\n" +
       "So tonight I lie...Stars above...\n" +
       "How did I ever win your love?\n" +
       "What did I do...What did I say...\n" +
       "To turn your Angel Eyes my way??...\n" +
       "\n" +
       "Well I'm the guy who never learned to dance..\n" +
       "Never even got one second glance...\n" +
       "Across a crowded room was close enough...\n" +
       "I could love but I could never touch..\n" +
       "\n" +
       "So tonight I lie...Stars above...\n" +
       "How did I ever win your love?\n" +
       "What did I do...What did I say...\n" +
       "To turn your Angel Eyes my way?...\n" +
       "\n" +
  "Don't anyone wake me..if it's just a dream...\n" +
  "Cause she is the best thing ..to ever happen to me..\n" +
       "All you fellows..You can look all you like..\n" +
       "But this girl you see..Is leaving here ..\n" +
       "With me tonight...\n" +
     "\n" +
       "There's just one more thing that I need to know.\n" +
       "If this is love why does it scare me so?\n" +
       "Must be something only you can see..\n" +
       "Cause girl I feel it when you look at me..\n" +
         "\n" +
       "So tonight I lie...Stars above..\n" +
       "How did I ever win your love?..\n" +
       "What did I do...What did I say?..\n" +
       "To turn your Angel Eyes my way......\n" +
       "                    I love you,\n" +
       "                       Aaron...\n");

       return 1;
}

 id(str) { return str == "tape" || str == "play"; }

