inherit "obj/treasure";

query_auto_load() {return"/players/cal/items/Chrysallis.c:";}
	get() {return 1;}
     drop() {return 1;}

reset(arg) {
 if(arg) return;
set_short("A Badge of Honor");
set_alias("badge");
set_long("This is a very nice badge that states to all that I Cal hearby name Chrysallis as the best hugger on the mud!!!\n");
   set_weight(0);
    set_value(0);
}
 id(str) { return str == "badge" || str == "Chrysallis's Badge"; }

