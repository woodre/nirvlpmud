#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/slave.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/rags.c");
move_object(ob1, monster);

monster = clone_object("players/cal/monster/slave.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/rags.c");
move_object(ob1, monster);
}
}

TWO_EXIT("/players/cal/room/CtrA3.c", "north",
         "/players/cal/room/CtrA1.c", "south",
       "A Musty Hallway",
" As you enter this hallway from the south, and approach the pounding noise, you smell a strong oder of urine and bile.\n",1)
