inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "dancer" );
     set_short(" A Ballroom Dancer");
	set_long("This is a finely dressed person who has come to \n" +
	"the castle to enjoy the Ball that is being put on here by Cal\n" +
	"These are fine young men and women who only want to have a good time\n");
     set_alias("dancer");
     set_level(12);
     set_ac(20);
     set_wc(25);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
 ob=clone_object("/players/cal/items/dancers.c");
   move_object(ob, this_object());
     money = (1500);
   }
}
