#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/Aaron.c");
      transfer(monster, this_object());
ob1 = clone_object("players/cal/armor/rags.c");
move_object(ob1, monster);


}
}

TWO_EXIT("/players/cal/room/CtrA6a.c", "north",
         "/players/cal/room/CtrA8a.c", "south",
       "Aaron's Cell",
"This is a brightly lit cell that seems to have been\n"+
"reciently renovated.  You notice somehting peculiar\n"+
"as you look more closely..There are three phones. \n"+
"what could someone in prison ever need with three?\n"+
"Bet you would hate to see the phone bill....\n",1)


