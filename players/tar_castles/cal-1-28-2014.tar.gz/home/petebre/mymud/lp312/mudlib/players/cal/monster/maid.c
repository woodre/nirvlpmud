


inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "maid" );
     set_short("The Castle Maid");
	set_long("This is the maid to the castle..She looks very attractive\n"+
                " in her little black and white maid-outfit..It seems to be\n"+
                 "cut even lower in the front exposing more then what you have\n"+
                 " seen before and the skirt seems to be a lot shorter then you remember....\n");
     set_alias("maid");
     set_level(16);
     set_wc(24);
     set_ac(31);
     set_hp(530);
     set_al(-100);
     set_aggressive(0);
      set_chat_chance(40);
     load_chat("The maid bends down to pick something up..Your eyes seem to follow her as you try to look down her dress...You are a bad person...\n");
     load_chat("The maid looks up at you and says  ' Can I be of service to you in any way? ' then she smiles as she turns and you see her skirt lift up slightly in the back...\n");
      money = (300);
   } 
   }
