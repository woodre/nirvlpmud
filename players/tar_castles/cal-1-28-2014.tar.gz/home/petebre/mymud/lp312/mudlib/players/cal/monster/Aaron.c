


inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "aaron" );
     set_short("Aaron");
	set_long("Aaron is a prisoner to the castle, if you\n"+
                  "you will find out why...\n");
     set_alias("aaron");
     set_level(13);
     set_wc(21);
     set_ac(23);
     set_hp(600);
     set_al(-100);
     set_aggressive(0);
     set_chat_chance(25);
   load_chat("Aaron says: I didn't mean to hurt him...\n");
   load_chat("Aaron says: He tried to turn off my phone....\n");
   load_chat("Aaron whispers to you: How was I supposed to know he would break his neck when he fell from the pole after I shot him?\n");
   load_chat("Aaron says: Do me a favor....Smile...:) \n");
   load_chat("Aaron runs to the phone as it rings, picks it up and then jumps in a chair, once he's on the phone he's there for a while\n");
   load_chat("Aaron says: Im glad I own stock in the phone company....I make back almost a 100th of what I spend..\n");

   money = (600);
   } 
     call_out("set_heal",30,20);
}
