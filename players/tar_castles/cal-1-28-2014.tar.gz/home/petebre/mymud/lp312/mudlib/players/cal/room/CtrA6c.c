
#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}

TWO_EXIT("players/cal/room/CtrA7c.c", "south",
          "players/cal/room/CtrA5.c", "east",
          "West-Side Prison",
   "You have entered the western end of the prison\n"+
" from here you can go south which leads further into \n"+
"the prison..or you can go back the way you came, which\n"+
"could prove much safer for you....\n",1)
