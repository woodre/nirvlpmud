
inherit "obj/armor";
reset(arg){
   ::reset(arg);
set_short("A Metal Breastplate");
   set_arm_light(0);
        set_long("A metal Breastplate worn by the best of knights.\n");
   set_ac(2);
   set_weight(1);
   set_value(500);
   set_alias("breastplate");
   set_name("breastplate");
   set_type("armor");
}
