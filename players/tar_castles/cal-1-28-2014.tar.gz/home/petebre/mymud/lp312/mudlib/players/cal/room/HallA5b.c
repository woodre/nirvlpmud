
#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA6b.c", "west",
         "/players/cal/room/HallA4b.c", "east",
       " Hallway",
"You are a brave warrior to have come this far into\n"+
" the castle maybe you have what it takes to defeat\n"+
" the evil deep inside of it.....\n",1)
