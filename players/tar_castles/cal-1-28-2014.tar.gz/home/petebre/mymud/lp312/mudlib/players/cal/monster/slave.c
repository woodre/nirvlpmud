inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "slave" );
     set_short(" A Meager Slave");
	set_long("This is a slave to the castle...The long\n" +
	"years in the castle prison have definatley worn on him..\n" +
	" You wonder where he got the 200 coins he is carrying...\n");
     set_alias("slave");
     set_level(10);
     set_wc(15);
     set_hp(250);
     set_al(0);
     set_aggressive(0);
     money = (200);
   }
}
