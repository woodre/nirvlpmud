inherit "obj/treasure";

reset(arg) {
 if(arg) return;
set_short("A Golden Cup");
set_alias("cup");
set_long("This is a Gold Cup fit for a King.\n");
   set_weight(1);
    set_value(750);
}
 id(str) { return str == "cup" || str == "King's Cup"; }

