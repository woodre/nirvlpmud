


inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "ted" );
     set_short("Ted");
	set_long("Ted is a prisoner to the castle, if you care to hear what he has to say\n"+
                  "you will find out why...\n");
     set_alias("ted");
     set_level(12);
     set_wc(18);
     set_ac(25);
     set_hp(400);
     set_al(-50);
     set_aggressive(0);
 set_chat_chance(20);
   load_chat("Ted looks you square in the face and says: What the hell do you want?\n");
   load_chat("Ted tells you: GET THE FUCK OUT!!!\n");
   load_chat("Ted grabs a towel to go take a shower...\n");
   load_chat("Ted says: Hey he looked at me funny...it isn't my fault, I didn't know he was there..\n");
   load_chat("Ted says: My girlfriend did it..She grabed him by the @&$#* and yanked...OOOwww I hate it when she does that..\n");

     money = (300);
   } 
   }
