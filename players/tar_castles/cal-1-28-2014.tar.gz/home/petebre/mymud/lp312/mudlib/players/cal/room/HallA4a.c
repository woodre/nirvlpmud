
#include "room.h"

realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA1c.c", "north",
         "/players/cal/room/HallA5a.c", "east",
       "Hallway",
"You have rounded anouther corner to find that you \n"+
"can see anouther corner off in the distance to the east..\n"+
"Looking around you see you have no choice but to go forward\n"+
" or head back...The Hallways are getting Darker as the sun\n"+
" starts to set on the outside....\n"+
"You should really consider going back to the safety of the \n"+
"other castles...\n",1)
