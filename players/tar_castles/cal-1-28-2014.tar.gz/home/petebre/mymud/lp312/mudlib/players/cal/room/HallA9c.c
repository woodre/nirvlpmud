
#include "room.h"

object guard,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();

    extra_reset() {
  if(!guard || (present("guard"))) {
guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());
 
guard = clone_object("players/cal/monster/guard.c");
      transfer(guard, this_object());
}
    }
THREE_EXIT("/players/cal/room/HallA4b.c", "south",
         "/players/cal/room/HallA8c.c", "east",
         "/players/cal/room/HallA10c.c", "west",
       "Hallway",
"You look to the west and you see the hallway coming \n"+
"to an end. To your east the hallway continues to the\n"+
" east for what seems like forever...You can still \n"+
"turn back....\n",1)
