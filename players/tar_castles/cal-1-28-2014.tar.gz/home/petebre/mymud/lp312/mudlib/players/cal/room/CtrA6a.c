#include "room.h"

object knight,ob,ob1;
realm() {return "NT";}

THREE_EXIT("/players/cal/room/CtrA5.c", "west",
         "/players/cal/room/CtrA7a.c", "south",
         "/players/cal/room/CtrA7b.c", "east",
                     "Dismal Prison",
     "You have entered the dismal prison of this castle.  Maybe\n"+
     "you should rethink your choice of being here before you \n"+
     "become a permanent resident.  Watch out for the guards....\n",1)
