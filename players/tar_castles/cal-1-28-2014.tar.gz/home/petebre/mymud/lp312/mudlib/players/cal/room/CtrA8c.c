
#include "room.h"

object monster,ob,ob1;
realm() {return "NT";}
#undef EXTRA_RESET
#define EXTRA_RESET\
              extra_reset();
              extra_reset() {

   if(!monster || (present("monster"))) {
monster = clone_object("players/cal/monster/cook.c");                  			 
     transfer(monster, this_object());
   
    }
    }
TWO_EXIT("players/cal/room/CtrA9c.c", "south",
          "players/cal/room/CtrA7c.c", "north",
          "Workman's Quarters",
   "You have entered the quarters made for the workers of the castle\n"+
   "These quarters are extravagently decorated for the honorable \n"+
   "workers of the castle.  This room happens to be the room of the\n"+
   "cook. He prepares the food for the people of the castle and any \n"+
   "of the guests that come to the castle.  He has been working all\n"+
   "day preparing for the Ball that is being put on in the upper levels\n"+
   "of the castle...\n",1)
