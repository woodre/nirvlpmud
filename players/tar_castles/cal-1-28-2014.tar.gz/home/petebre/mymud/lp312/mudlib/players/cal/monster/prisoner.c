inherit "/obj/monster";
object ob;

reset(arg) {
   ::reset(arg);
   if (!arg) {
object ob;
     set_name( "prisoner" );
     set_short(" Prisoner to the Castle");
	set_long(" This is a prisoner to the castle of Cal...\n" +
	"He must have done something truly awful to deserve such traeatment..\n" +
	" You know that Cal is not the type of person to imprison someone for long without reason..\n");
     set_alias("prisoner");
     set_level(10);
     set_ac(20);
     set_wc(20);
     set_hp(250);
     set_al(-500);
     set_aggressive(1);
     money = (100);
   }
}
