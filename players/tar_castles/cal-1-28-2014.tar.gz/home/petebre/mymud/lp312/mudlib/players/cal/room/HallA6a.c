
#include "room.h"

realm() {return "NT";}
TWO_EXIT("/players/cal/room/HallA5a", "west",
         "/players/cal/room/HallA7a", "east",
       " Hallway",
"The castle is getting increasingly dark as you\n"+
" walk down this corridoor .  You can't tell due\n"+
" to the lack of windows whether it is the lack of\n"+
" sun or if if it is the atmosphere within the castle\n"+
" but you do know one thing you are going to want\n"+
" a torch soon...\n",1)
