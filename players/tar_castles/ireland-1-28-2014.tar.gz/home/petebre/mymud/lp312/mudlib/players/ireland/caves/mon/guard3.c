inherit "/obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("guard");
   set_short("A security guard");
   set_long(
      "This is the personal security guard of the local drug lord.\n"+
      "It is his duty to keep people who don't have an appointment\n"+
      "from getting into his bosses office.\n");
   set_gender("male");
   set_race("human");
   set_level(15);
   set_hp(250);
   set_wc(20);
   set_ac(12);
   add_money(800);
   set_chat_chance(10);
   set_a_chat_chance(10);
   load_chat("My boss doesn't want any visitors.\n");
   load_a_chat("The guard smashes you in the knee cap.\n");
   set_chance(5);
   set_spell_mess1(
      "The guard kicks his opponent in the stomach!\n"
   );
   set_spell_mess2(
      "The guard kicks you in the stomach!\n"
   );
   set_spell_dam(10);
}

init()
{
   monster::init();
   add_action("north", "north");
}

north()
{
   write("The guard pushes you back\n");
   say("The guard refuses to let anyone pass.\n");
   return 1;
}
