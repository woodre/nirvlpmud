#include "/obj/ansi.h"

inherit "/obj/weapon.c";

reset(arg) {
   ::reset(arg);
   if (arg) return;
   
   set_name("saifullah");
   set_alias("sword");
   set_short("The Sword of "+HIW+"Allah"+NORM+"");
   set_long("   This is the sword of Allah, aslo known as the Saifullah, It is\n" +
      "rumored that this blade was given to Muhammad by Allah himself and\n"+
      "used to defend the Muslim faith from those seeking to destroy it.\n"+
      "This is a very powerful weapon, be weary...\n");
   set_class(21);
   set_weight(9);
   set_value(100000);
   set_hit_func(this_object());
}

weapon_hit(attacker){
   
   int W;
   
   W = random(50);
   
   if(W > 37) {
      say("The Sword of "+HIW+"Allah "+NORM+"glows a bright white and "+HIR+"S M I T E S "+NORM+"its foe!\n");
      
      write("The Sword of "+HIW+"Allah "+NORM+"glows a bright white and "+HIR+"S M I T E S "+NORM+"its foe!\n");
      
      return 10;
      attacker->heal_self(-15);
      attacker->add_sp(-15);
      
   }
   return;
}
