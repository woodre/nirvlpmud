inherit "room/room";

reset(arg){
   if(!present("guard",this_object()))
      move_object(clone_object("/players/ireland/caves/mon/dealer.c"),this_object());
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is a very small room.  The low ceiling and close\n"+
   "walls leaves little room for much else.  The dirt floor\n"+
   "shows little use and the walls are very dirty.\n";
   
   items = ({
         "ceiling","The ceiling is only about 8 feet high",
         "floor","The floor is made of dirt and looks undisturbed",
         "walls","The walls are very dirty" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r11.c","south"});
   set_light(1);
}
