inherit "room/room";

reset(arg){
   if(!present("lord",this_object()))
      move_object(clone_object("/players/ireland/caves/mon/lord.c"),this_object());
   if(arg) return;
   
   short_desc = "The Drug Lord's Office";
   long_desc = "   This is a very well kept office.  There\n"+
   "is a large oak desk in the middle with\n"+
   "a lamp seated on its corner.  There are\n"+
   "paintings on the wall and carpet on\n"+
   "the floor\n";
   items = ({
         "desk","A well crafted oak desk",
         "lamp","a beautiful glass lamp",
         "paintings","Several abstract pictures by different artists",
         "carpet","The Carpet is red shag"});
   
   dest_dir = ({
         "/players/ireland/caves/room/r15.c","south"});
   set_light(1);
}
