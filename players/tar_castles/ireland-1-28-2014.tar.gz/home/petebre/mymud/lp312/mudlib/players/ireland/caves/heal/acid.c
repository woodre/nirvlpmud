#include "/obj/ansi.h"

inherit "/obj/generic_heal.c";

void reset(int arg)
{
   ::reset(arg);
   if(arg) return;
   set_name("acid");
   add_alias("cube");
   add_alias("sugar");
   set_short("A sugar cube laced with "+HIR+"a"+HIG+"c"+HIY+"i"+HIB+"d"+NORM+"");
   set_long(
      "This is a small sugar cube laced with acid.\n"+
      "It may be 'eat'en.\n"
   );
   set_type("hit");
   set_msg("You place the sugar cube under your tongue and let it disolve.\n");
   set_msg2(" eats an "+HIR+"a"+HIG+"c"+HIY+"i"+HIB+"d "+NORM+"laced sugar cube.\n");
   add_cmd("eat");
   add_cmd("snort");
   add_cmd("drop");
   set_heal(20,20);
   set_charges(1);
   set_intox(5);
   set_stuff(10);
   set_soak(10);
   set_value(160);
}
