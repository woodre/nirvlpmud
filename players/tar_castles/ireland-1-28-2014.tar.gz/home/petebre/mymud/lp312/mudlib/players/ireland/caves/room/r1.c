inherit "room/room";

reset(arg){
   if(!present("guard",this_object()))
      move_object(clone_object("/players/ireland/caves/mon/guard1.c"),this_object());
   if(arg) return;
   
   short_desc = "Cave Entrance";
   long_desc = "   This is the entrance to some cave.  There is not much decoration\n"+
   "of any kind here.  The only thing noticable are the torches lining the\n"+
   "walls.  The only way to go seems to be through the door to the north.\n";
   
   items = ({
         "cave","It is too difficult to see much of the cave from here",
         "torches","Several burning torches line the walls",
         "door","The door is really just a hole in the cave wall" });
   dest_dir = ({
         "/players/ireland/caves/room/r2.c","north" });
   set_light(1);
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
write("You search the "+str+" but find nothing special.\n");
say(capitalize(this_player()->query_real_name())+" searches the "+str+
    " and finds nothing special.\n");
return 1; }
