inherit "/obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("dealer");
   set_short("A drug dealer");
   set_long(
      "This is one of the drug lords pushers. His only job is to\n"+
      "push his product onto the local addicts and deliver money\n"+
      "to the lord himself.\n");
   set_race("human");
   set_gender("male");
   set_level(15);
   set_hp(250);
   set_wc(20);
   set_ac(12);
   add_money(800);
   set_chat_chance(10);
   set_a_chat_chance(10);
   load_chat("Why don't you try some of this? It's really good...\n");
   load_a_chat("The pusher kicks you between the legs!\n");
   set_chance(5);
   set_spell_mess1(
      "The guard kicks his opponent in the stomach!\n"
   );
   set_spell_mess2(
      "The pusher bites you in the arm!\n"
   );
   set_spell_dam(10);
   if(!present("acid",this_object()))
      move_object(clone_object("/players/ireland/caves/heal/acid.c"),this_object());
   
   if(!present("coke",this_object()))
      move_object(clone_object("/players/ireland/caves/heal/coke.c"),this_object());
}

