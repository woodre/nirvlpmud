inherit "room/room";

reset(arg){
   if(!present("addict",this_object()))
      move_object(clone_object("/players/ireland/caves/mon/druggie1.c"),this_object());
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is a small room just off of one of the main tunnels\n"+
   "of the cave.  It is not very large.  The ceiling is low, the\n"+
   "floor is dirt and the walls are close together.  There does\n"+
   "not seem to be much use for this place.\n";
   
   items = ({
         "ceiling","The ceiling is only about 9 feet high and dirty",
         "floor","The floor is made of nothing but dirt",
         "walls","The walls are jagged and rough" });
   
   dest_dir = ({ 
         "/players/ireland/caves/room/r6.c","east" });
   set_light(1);
}
