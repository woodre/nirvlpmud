inherit "room/room";

reset(arg){
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "  Here the tunnel comes to and end and two smaller tunnels\n"+
   "split off in seperate directions.  Here the ceiling is just\n"+
   "high enough for people to pass under.  The main tunnel heads\n"+
   "back to the south.\n";
   items = ({
         "tunnel","The tunnel comes to an end here",
         "tunnels","Two smaller tunnels lead east and west from here",
         "ceiling","The ceiling is just high enough for a person to walk upright" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r10.c","east",
         "/players/ireland/caves/room/r11.c","west",
         "/players/ireland/caves/room/r8.c","south" });
   
   set_light(1);
}
