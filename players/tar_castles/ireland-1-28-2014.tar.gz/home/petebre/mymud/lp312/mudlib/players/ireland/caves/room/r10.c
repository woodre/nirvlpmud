inherit "room/room";
reset(arg){
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is the start of a small tunnel.  The ceiling is\n"+
   "just high enough for someone to walk under and the \n"+
   "walls are just wide enough for someone to pass between.\n"+
   "The tunnel continues to the east and the main tunnel\n"+
   "is back to the west.\n";
   
   items = ({
         "tunnel","This is a small tunnel, it is barely big enough to pass through.",
         "walls","The walls are smooth and very narrow" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r12.c","east",
         "/players/ireland/caves/room/r9.c","west" });
   
   set_light(1);
}
