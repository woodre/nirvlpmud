inherit "obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("lord");
   set_short("A drug lord");
   set_long(
      "This guy seems to be the man in charge.  The is wearing a\n"+
      "cheap polyester suit and has his hair slicked back.  His\n"+
      "fingers are covered in cheap jewelry and he has a fake gold\n"+
      "chain around his neck.\n"
   );
   set_gender("male");
   set_race("human");
   set_aggressive(1);
   set_level(19);
   set_wc(28);
   set_ac(16);
   set_hp(450);
   add_money(4000);
   set_chat_chance(10);
   set_a_chat_chance(10);
   load_chat("The drug lord say: What do you want? My drugs and money are all gone!\n");
   load_a_chat("The drug lord says: Leave me alone! I have nothing left! I swear!\n");
   set_chance(20);
   set_spell_mess1(
      "The drug lord whacks his opponent over the head!\n"
   );
   set_spell_mess2(
      "The drug lord whacks you over the head!\n"
   );
   set_spell_dam(25);
   
   
}
