#include "/obj/ansi.h"
inherit "obj/armor";

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("glasses");
   set_alias("sunglasses");
   set_short(""+BOLD+BLK+"Black "+NORM+"Sunglasses");
   set_long(
      "This is a pair of very dark sunglasses.  They look\n"+
      "like the kind a drug dealer would wear.\n"
   );
   set_ac(0);
   set_type("misc");
   set_value(100);
}
