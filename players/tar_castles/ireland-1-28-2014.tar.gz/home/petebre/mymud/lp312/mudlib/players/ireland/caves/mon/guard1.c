inherit "/obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("guard");
   set_short("A scruffy looking guard");
   set_long(
      "This guard is not much of a sight.  He is wearing a dirty\n"+
      "overcoat, some dusty jeans and a white shirt stained with blood.\n"+
      "He does not look too happy with his job but that will\n"+
      "not stop him from doing it.\n"
   );
   set_gender("male");
   set_race("human");
   set_level(15);
   set_hp(250);
   set_wc(20);
   set_ac(12);
   add_money(800);
   set_chat_chance(10);
   set_a_chat_chance(10);
   load_chat("Guard says: Get out of here.\n");
   load_a_chat("The guard throws dirt in your eyes.\n");
   set_chance(5);
   set_spell_mess1(
      "The guard kicks his opponent in the stomach!\n"
   );
   set_spell_mess2(
      "The guard kicks you in the stomach!\n"
   );
   set_spell_dam(10);
}

init()
{
   monster::init();
   add_action("north", "north");
  add_action("Search","search");
}

north()
{
   write("The guard pushes you back\n");
   say("The guard refuses to let anyone pass.\n");
   return 1;
}

Search() {
write("The guard shakes his head and says, 'No searching here.'\n");
return 1; }
