/*     Forbin's Wiztell Device*/
/*     /players/forbin/closed/wiztell.c*/
/**/
/*     Created by:   Forbin*/
/*     Create date:  jan2002.07*/
/*     Last mod:   jan2002.08*/

/*     Taken and modified with permission from*/
   /*     Jaraxle's wiztell.*/

#include "/players/forbin/define.h"

id(str) { return str == "teller" || str == "wiztell" || str == "book"; }

short() { write(""+HIR+"Th"+HIY+"e H"+NORM+""+GRN+"el"+HIB+"pi"+HIC+"ng"+NORM+""+MAG+" Phr"+HIC+"ie"+HIB+"nd"+NORM+""+GRN+"ly"+HIY+" Bo"+HIR+"ok"+NORM+"\n"); }

long() { 
   write("This is the legendary Helping Phriendly Book.  You\n"+
      "may use this to communicate with Forbin if he is\n"+
      "around.  Use 'ftt' to talk with him.\n");}

init() {
   add_action("cmd_st", "ftt");
   add_action("cmd_tell", "tell");
   add_action("cmd_say","say");
   add_action("cmd_say"); add_xverb("'"); 
}

cmd_tell(str) {
   object plyr;
   string myname, who, what;  
   if(!str) { 
      write("Excuse me?\n"); 
      return 1; 
   }
   /* attempt to type fewer letters */
   
   if(sscanf(str,"%s %s",who,what) < 2) 
      {
      write("Tell <who> <what>.\n"); 
      return 1; 
   }
   plyr = find_living(who);
   myname = capitalize(this_player()->query_real_name());
   if(!plyr) { write(capitalize(who)+" is not on now.\n");
      return 1; 
   }
   if(this_player()->query_invis()){
      tell_object(plyr,""+HIW+"["+HIY+"Ireland"+HIW+"] ("+HIK+"invis"+HIW+")"+NORM+"\n"+
         ""+HIY+":// speaks to you: "+HIW+what+NORM+"\n");
      write(""+HIY+"("+HIK+"invis"+HIY+") You speak to "+capitalize(who)+""+HIY+":"+HIW+" "+what+""+NORM+"\n");
      return 1; }
   tell_object(plyr,""+HIW+"["+HIY+"Ireland"+HIW+"]"+NORM+"\n"+
      ""+HIY+":// speaks to you: "+HIW+what+NORM+"\n");
   write(""+HIY+"You speak to "+capitalize(who)+""+HIY+":"+HIW+" "+what+""+NORM+"\n");
   if(plyr->query_level() > this_player()->query_level()) plyr->add_tellhistory("Ireland told you "+what );
   plyr->Replyer("ireland");
   return 1;
}

cmd_say(str) {
   int X, CK, JK, Z;
   
   if(!str) {
      notify_fail("Excuse me?\n");
      return 0; 
   }
   write(""+HIY+"You speak: "+HIW+str+NORM+"\n");
   say(HIY+this_player()->query_name()+" speaks: "+HIW+str+NORM+"\n");
   return 1; 
}


cmd_st(str) {
   object sob;
   string what;
   sob = find_player("ireland");
   if(!sob) 
      {
      notify_fail(""+HIY+"Ireland is not logged on."+NORM+"\n"+NORM);
      return 0; 
   }
   if(in_editor(sob)) {
      notify_fail(""+HIW+"Ireland is busy.\nTry again later."+NORM+"\n");
      return 0; 
   }
   write(""+HIY+"You tell Ireland: "+HIW+str+NORM+"\n");
   what = ""+HIY+":::::::["+HIW+this_player()->query_name()+NORM+HIY+"]:::[ "+HIW+str+HIY+""+NORM;
   tell_object(sob,what+"\n");
   return 1; 
}



