#include "/obj/ansi.h"

inherit "/obj/generic_heal.c";

void reset(int arg)
{
   ::reset(arg);
   if(arg) return;
   set_name("151");
   add_alias("rum");
   set_short("Bacardi "+HIR+"151"+NORM+"");
   set_long("a bottle of 151\n");
   set_type("drink");
   set_msg("You chug from the bottle of "+HIR+"151."+NORM+"");
   set_msg2(" chugs from a bottle of "+HIR+"151"+NORM+"\n");
   add_cmd("drink");
   set_heal(1,1);
   set_charges(10);
   set_intox(3);
   set_value(0);
}
