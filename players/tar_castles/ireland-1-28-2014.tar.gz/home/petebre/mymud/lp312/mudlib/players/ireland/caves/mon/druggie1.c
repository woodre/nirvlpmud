inherit "/obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("addict");
   set_short("A drug addict");
   set_long("This addict is a poor sight,  He spends every single day\n" +
      "of his life searching for money to buy more drugs.\n" +
      "He is now homeless, broke and strung out due to years\n" +
      "of addiction.  He does not have much to lose.\n"
   );
   set_gender("male");
   set_race("human");
   set_level(15);
   set_hp(250);
   set_wc(20);
   set_ac(12);
   set_chat_chance(10);
   load_chat("The addict says: Can you spare a few coins?\n");
   set_chance(5);
   set_spell_mess1(
      "The addict kicks his opponent between the legs!\n"
   );
   set_spell_mess2(
      "The addict kicks you right between the legs!"
   );
   set_spell_dam(5);
   
   if(!present("acid",this_object()))
      move_object(clone_object("/players/ireland/caves/heal/acid.c"),this_object());
}
