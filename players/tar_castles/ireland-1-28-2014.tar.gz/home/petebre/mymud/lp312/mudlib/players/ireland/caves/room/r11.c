inherit "room/room";

reset(arg){
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is be start of a small tunnel.  The tunnel is just\n"+
   "large enough for a person to pass through.  To the north\n"+
   "there is a small room and to the west the tunnel continues on.\n";
   
   items = ({
         "tunnel","The tunnel is barely big enough for to walk through",
         "room","it's not possible to see whats in the room from here" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r13.c","north",
         "/players/ireland/caves/room/r14.c","west",
         "/players/ireland/caves/room/r9.c","east" });
   set_light(1);
}
