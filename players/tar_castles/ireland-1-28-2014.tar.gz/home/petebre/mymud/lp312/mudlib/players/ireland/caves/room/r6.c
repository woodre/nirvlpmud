inherit "room/room";

reset(arg){
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is one of the tunnels leading through the cave.  It\n"+
   "is much smaller then the entrance area.  The tunnel continutes\n"+
   "on to the north.  There is also a small room just west of here.\n";
   
   items = ({
         "room","It is too difficult to see what is in the room from here" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r2.c","south",
         "/players/ireland/caves/room/r7.c","west",
         "/players/ireland/caves/room/r8.c","north" });
   
   set_light(1);
}
