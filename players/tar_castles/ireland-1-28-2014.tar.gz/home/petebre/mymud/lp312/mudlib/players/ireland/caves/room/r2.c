inherit "room/room";

reset(arg){
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   The cave is much bigger then it looked from the outside.  Tunnels\n" +
   "break off in several directions from here.  The ceiling of the cave is about\n"+
   "twenty feet high and the jagged edged walls are lined with torches.  One can\n"+
   "only wonder what type of people are hiding out down here.\n";
   
   items = ({
         "cave","The cave is much larger then it appeared",
         "ceiling","The ceiling is about 20 feet up and looks very smooth",
         "tunnels","The tunnels lead to different parts of the cave",
         "torches","Several torches are mounted onto the jagged walls",
         "walls","The walls of the cave are sharp and jagged" });
   dest_dir = ({
         "/players/ireland/caves/room/r3.c","east",
         "/players/ireland/caves/room/r6.c","north",
         "/players/ireland/caves/room/r1.c","south" });
   set_light(1);
}
