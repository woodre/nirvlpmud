#include "/obj/ansi.h"
inherit "/players/wocket/std/wiztell.c";

reset(arg){
   if(arg) return;
   owner = "ireland";
   cap_owner = "Ireland";
   color = HIW;
   extra_look = "Ireland is a demon made of "+BOLD+BLK+"Shadows"+NORM+"";
}
