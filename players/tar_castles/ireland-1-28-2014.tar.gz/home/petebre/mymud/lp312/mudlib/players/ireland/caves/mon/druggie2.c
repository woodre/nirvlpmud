inherit "/obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("girl");
   set_short("A strung out girl");
   set_long(
      "From the looks of this girl she has been strung\n" +
      "out for a long time.  She spends her days looking\n" +
      "for drugs and whoring herself out for money.  She\n" +
      "does not look to be in the best shape.\n"
   );
   set_gender("female");
   set_race("human");
   set_level(15);
   set_hp(250);
   set_wc(20);
   set_ac(12);
   set_chat_chance(10);
   load_chat("The girl hold her fingers up to her nose and sniffs.\n");
   set_chance(5);
   set_spell_mess1(
      "The girl grabs her opponent's hair and pulls!\n"
   );
   set_spell_mess2(
      "The girl grabs you by the hair and pulls it hard!\n"
   );
   set_spell_dam(5);
   
   if(!present("coke",this_object()))
      move_object(clone_object("/players/ireland/caves/heal/coke.c"),this_object());
}
