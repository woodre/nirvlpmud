inherit "room/room";

reset(arg){
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is a small hallway.  It is very well kept,\n"+
   "unlike the rest of the cave.  Up ahead there seems\n"+
   "to be some sort of office.  Back the other way\n"+
   "is a large opening.\n";
   
   items = ({
         "office","There is no way to tell what type of office it is",
         "opening","An opening that leads to a large room"});
   
   dest_dir = ({
         "/players/ireland/caves/room/r16.c","north",
         "/players/ireland/caves/room/r14.c","south"});
   set_light(1);
}
