inherit "room/room";

reset(arg){
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "  This is one of main tunnels of the cave.  In this\n"+
   "part of the tunnel the ceiling seems to be getting lower\n"+
   "and lower.  It continutes to the north.\n";
   
   items = ({
         "ceiling","The ceiling is only about 8 feet high" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r6.c", "south",
         "/players/ireland/caves/room/r9.c","north" });
   
   set_light(1);
}
