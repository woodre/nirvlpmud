inherit "/obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("baby");
   set_short("A crack baby");
   set_long(
      "This baby looks to be in horrible shape.  He is wearing\n" +
      "nothing but a beat up rag as a diaper.  He is most likely\n" +
      "the son of a crack whore who sold her body for drug money\n"
   );
   set_gender("male");
   set_race("human");
   set_level(5);
   set_hp(75);
   set_wc(9);
   set_ac(5);
   set_chat_chance(10);
   load_chat("The baby screams loudly.\n");
}
