inherit "obj/monster.c";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("guard");
   set_short("A strong guard");
   set_long(
      "This is a very strong looking guard.  His arms\n"+
      "and chest look well built and solid as a rock.\n"+
      "He stands about 6 foot 5 and has a very mean look\n"+
      "on his face.\n"
   );
   set_gender("male");
   set_aggressive(1);
   set_race("human");
   set_level(17);
   set_wc(24);
   set_ac(14);
   set_hp(350);
   add_money(1900);
   set_chat_chance(10);
   set_a_chat_chance(10);
   load_chat("The guard says: Turn around and get out of here, NOW!\n");
   load_a_chat("The guard says: I will teach you for trying to mess with me!\n");
   set_chance(10);
   set_spell_mess1(
      "The guard punches his opponent in the face!\n"
   );
   set_spell_mess2(
      "The guard punches you in the face!\n"
   );
   set_spell_dam(15);
   
   if(!present("glasses",this_object()))
      move_object(clone_object("/players/ireland/caves/arm/sglasses.c"),this_object());
}
