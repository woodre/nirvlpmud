inherit "room/room";

reset(arg){
   if(!present("girl",this_object()))
      move_object(clone_object("/players/ireland/caves/mon/druggie2.c"),this_object());
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   The tunnel comes to an end in this room.  The room\n"+
   "is a circular shape with a low ceiling.  The walls are\n"+
   "a smooth black and the floor is very dirty.  The\n"+
   "tunnel leads back to the west and there is a small alcove\n"+
   "to the north.\n";
   
   items = ({
         "tunnel","The tunnel ends here in this room",
         "room","It is a circular shaped room with a low ceiling",
         "ceiling","The ceiling is about 9 feet high and is smooth",
         "walls","The walls are polished and very smooth",
         "floor","The floor is made of dirt",
         "alcove","The alcove can not be seen into from here" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r5.c","north",
         "/players/ireland/caves/room/r3.c","west" });
   set_light(1);
}
