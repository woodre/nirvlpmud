inherit "room/room";

reset(arg) {
   
   object mon;
   
   if(!arg) {
      
      set_light(1);
short_desc = "Ireland's Basement";
      long_desc=
      "     This is Ireland's fun room.  It is where she comes to\n"+
      "play with and test all the fun things she creates.\n";
      
      dest_dir=({
            "/players/ireland/workroom","workroom"
});
      
      mon = clone_object("/players/ireland/examples/monster.c");
      move_object(mon, this_object());
   }
}
