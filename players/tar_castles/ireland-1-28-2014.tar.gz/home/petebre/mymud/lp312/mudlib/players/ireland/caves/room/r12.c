inherit "room/room";

reset(arg){
   if(!present("guard",this_object()))
      move_object(clone_object("/players/ireland/caves/mon/guard2.c"),this_object());
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   The small tunnel has lead to this room.  It appears to\n"+
   "be some sort of bedroom.  There is a small bed in the middle and\n"+
   "a table sitting next to it.  The only way out is back though\n"+
   "the tunnel.\n";
   
   items = ({
         "tunnel","The small tunnel is the only way out of this room",
         "bed","The bed is small and simple.  It is made for 1 person",
         "table","A small oak table.  There is nothing on it" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r10.c","west"});
   set_light(1);
}
