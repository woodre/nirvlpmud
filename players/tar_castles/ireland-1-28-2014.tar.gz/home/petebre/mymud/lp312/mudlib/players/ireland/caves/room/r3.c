inherit "room/room";

reset(arg) {
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This part of the cave is much smaller.  The ceiling is not\n"+
   "as high and the tunnel is not as wide making the area\n"+
   "very cramped.  The tunnel continutes on to the east.\n";
   
   items = ({
         "cave","This part of the cave is a lot smaller then the main area",
         "ceiling","The ceiling is smooth and only 9 feet high",
         "tunnel","The tunnel is very narrow" });
   dest_dir = ({
         "/players/ireland/caves/room/r4.c","east",
         "/players/ireland/caves/room/r2","west" });
   
   set_light(1);
}
