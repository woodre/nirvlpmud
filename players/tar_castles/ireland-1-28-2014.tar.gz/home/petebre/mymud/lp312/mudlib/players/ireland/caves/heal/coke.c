#include "/obj/ansi.h"

inherit "/obj/generic_heal.c";

void reset(int arg)
{
   ::reset(arg);
   if(arg) return;
   set_name("cocaine");
   add_alias("coke");
   set_short("A small packet of "+HIW+"cocaine"+NORM+"");
   set_long(
      "This is a small plastic bag of cocaine.\n"+
      "It can be 'sniff'ed.\n"
   );
   set_type("hit");
   set_msg("You open the packet and sniff the " +HIW+"cocaine "+NORM+"through your nose.\n");
   set_msg2(" sniffs some "+HIW+"cocaine "+NORM+"through their nose.\n");
   add_cmd("sniff");
   set_heal(20,20);
   set_charges(1);
   set_intox(5);
   set_stuff(10);
   set_soak(10);
   set_value(160);
}
