inherit "/obj/monster.c";

reset(arg) {
   ::reset(arg);
   set_name("test monster");
   set_alt_name("monster");
   set_alias("test");
   set_short("A Test Monster");
   set_long(
      "This monster does not really look like a monster at all.\n"+
      "It looks more like a bum off the streets that was brought\n"+
      "here against its will to have all sorts of tests done to it.\n"
   );
   set_race("monster");
   set_level(20);
   set_ac(14);
   set_wc(35);
   set_al(0);
   set_hp(900);
   add_money(500);
}
