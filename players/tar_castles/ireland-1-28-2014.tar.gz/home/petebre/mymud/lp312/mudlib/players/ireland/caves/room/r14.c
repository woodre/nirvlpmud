inherit "room/room";

reset(arg){
   if(!present("guard",this_object()))
      move_object(clone_object("players/ireland/caves/mon/guard3.c"),this_object());
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is the end of the small tunnel.  It has opened up\n"+
   "into a large room.  There is a large table in the\n"+
   "middle of the room.  This part of the cave seems\n"+
   "a lot cleaner then the other parts.  There is an\n"+
   "opening to the north and the tunnel is to the east.\n";
   
   items = ({
         "tunnel","The tunnel is back to the east",
         "room","This room is large and very clean",
         "table","This large oak table looks like it is used for meetings",
         "opening","The opening looks to lead to another part of the cave",
         "opening","The opening looks to lead to another part of the cave" });
   
   dest_dir = ({
         "/players/ireland/caves/room/r15.c","north",
         "/players/ireland/caves/room/r11.c","east"});
   set_light(1);
}
