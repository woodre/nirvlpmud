inherit "room/room";

reset(arg){
   if(!present("baby",this_object()))
      move_object(clone_object("/players/ireland/caves/mon/baby.c"),this_object());
   if(arg) return;
   
   short_desc = "Drug Caves";
   long_desc = "   This is a small alcove.  It appears to have been changed\n"+
   "into a makeshift bedroom.  In the middle of the room\n"+
   "is what appears to be a makeshift bed for a baby.  Other\n"+
   "then the bed there is nothing here.\n";
   
   items = ({
         "alcove","This is a very tiny room",
         "bed","It is nothing more then a small, very stained mattress" });
   dest_dir = ({
         "/players/ireland/caves/room/r4.c","south" });
   set_light(1);
}
