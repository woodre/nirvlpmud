inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, East Road";
long_desc = "You are upon the inner city's East Road. To the east you see "+
 "the Tavern\n"+
 "where you can order food to fill your stomach. The road continues north\n"+
 "and south.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/e_road1", "north",
 "players/demoder/MIDDLE/tavern", "east",
 "players/demoder/MIDDLE/e_road3", "south" });
}
