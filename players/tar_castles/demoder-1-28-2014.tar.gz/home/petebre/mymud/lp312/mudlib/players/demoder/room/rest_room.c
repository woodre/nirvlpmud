inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="Resting Room";
   long_desc="This is a resting room. You can come here to talk, relax,\n"+
   "wait for hitpoints and spellpoints to regenerate, disconnect, or\n"+
   "just about anything you want. However, you will not be able to start \n"+
   "a fight in this room.\n\n";
   dest_dir=({"players/demoder/room/room7a", "down",
         "room/church", "church"});
   set_heart_beat(1);
}

init() {
   ::init();
   add_action("no_fight", "kill");
   add_action("no_fight", "fireball", 2);
   add_action("no_fight", "shock", 2);
   add_action("no_fight", "missile", 2);
   add_action("no_fight", "fear");
   add_action("no_fight", "harm");
}

no_fight() {
   write("You cannot do that here.\n");
   return 1; }

static heart_beat() {
   object check;
   int amt;
   check=all_inventory(this_object());
   for(amt=0;amt<sizeof(check);amt++) {
      check[amt]->stop_fight();
      return 1; }
}
