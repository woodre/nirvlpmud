inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoder: First Holte - Center Court";
long_desc = "You are in the center of a huge amphitheater. There are \n"+
"concentric circles spreading higher from the floor of the theater.\n"+
"You see many exits.\n\n";
dest_dir = ({"players/demoder/elven/tree1c.c", "west",
"players/demoder/elven/tree1d.c", "east",
"players/demoder/elven/tree1f.c", "north",
"players/demoder/elven/tree1e.c", "south",
"players/demoder/elven/tree1g.c", "northwest",
"players/demoder/elven/tree1h.c", "southeast"});
}
