inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, East Road";
long_desc = "You are upon the inner city's East Road. To the east you see "+
 "the Eastern\n"+
 "Gate. To the west is the east wall and surrounding moat of the castle.\n"+
 "The road continues north and south.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/e_road2", "north",
 "players/demoder/MIDDLE/e_gate", "east",
 "players/demoder/MIDDLE/e_road4", "south" });
}
