#include "std.h"
object pill;
int heal_amount;

#undef EXTRA_INIT
#define EXTRA_INIT\
add_action("buy"); add_verb("buy");\
add_action("purchase"); add_verb("purchase");\
add_action("list"); add_verb("list");

ONE_EXIT("players/demoder/room/room7a", "up",
   "Demoder: Magic Shop",
   "You are in a magic shop. You can buy spells and items here.\n" +
   "Commands are: 'buy item', 'list'.\n"+
   "\nYou can also purchase healing pills here. To do so, type\n"+
   "    'purchase pill of <amount of heal wanted>'\n"+
   "The cost is 60 gold coins per healing point put into the pill.\n\n", 1)

buy(item) {
   if (!item)
      return 0;
   call_other("players/demoder/MIDDLE/magicstore", "fill", 0);
   call_other("players/demoder/MIDDLE/magicstore", "buy", item);
   return 1;
}

list(obj) {
   call_other("players/demoder/MIDDLE/magicstore", "fill", 0);
   call_other("players/demoder/MIDDLE/magicstore", "inventory", obj);
   return 1;
}

find_item_in_player(i)
{
   object ob;
   
   ob = first_inventory(this_player());
   while(ob) {
      if (call_other(ob, "id", i))
         return ob;
      ob = next_inventory(ob);
   }
   return 0;
}

purchase(str) {
   int amt;
   object pill;
   if(!str) {write("Type 'purchase pill of <amount>' to buy a pill.\n"); return 1;}
   if(sscanf(str, "pill of %d", amt) != 1) {
      write("You have to specify the amount.\n"); return 1; }
   if(this_player()->query_money() < amt*60) {
      write("You don't have enough coins.\n"); return 1; }
   pill = clone_object("players/demoder/obj/duh.c");
   pill->set_heal_amount(amt);
   this_player()->add_money(-amt*60);
   write("You purchase a pill of healing for "+amt*60+" coins.\n");
   move_object(pill, this_player());
   return 1;
}
