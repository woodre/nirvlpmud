inherit "room/room";
int ss;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoder: Elven Woods";
   long_desc = "You are deep within a peaceful forest. All around you are "+
   " different\n"+
   "shades of green and brown. It seems that the very forest is an ancient,\n"+
   "living entity. There are some unusually large trees to your east.\n"+
   "The path that you are on continues north and southwest.\n\n";
   dest_dir = ({"players/demoder/elven/woods4", "north",
         "players/demoder/elven/woods6", "southwest"});
}

init() {
   ::init();
   add_action("search", "search");
   add_action("enter", "enter");
}

search(str) {
if(ss == 1) return;
   write("You find an entrance into one of the huge trees!\n\n");
   long_desc = long_desc+
   "You can 'enter' the tree if you so desire.\n\n";
   this_player()->look();
   ss=1;
   return 1; }

enter() {
   if(ss != 1) return;
   else
      this_player()->move_player("into tree#players/demoder/elven/tree1");
   write("You walk into the entrance.\n");
   return 1; }
