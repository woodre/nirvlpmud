inherit "room/room";
int door_is_open, door_is_closed;
string vict_name, dem_name;
int ss;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc  = "Demoder's Study";
   long_desc   = 
   "As you enter upon this room, you immediately notice its bare\n"+
   "furnishings. You can tell that this Demoder character is a guy\n"+
   "of simple tastes. You do see a workstation in the northeast corner\n"+
   "by a window and in the southwest corner is a comfortable-looking\n"+
   "sofa also next to a window. There is a small refrigerator by the\n"+
   "sofa; all sorts of notes seem to be hanging from magnetic clippers\n"+
   "stuck to the refrigerator. \n"+
   "On the wall to the north is a family portrait. On the wall to the\n"+
   "south you notice a painting of a beautiful lady.\n\n";
   
   items = ({ "workstation", "A simple, yet elegant place for Demoder to"+
         " work",
         "east window", "A window that one can look out of to see the sun rise",
         "west window", "A window that one can look out of to see the sun set",
         "sofa", "An old, comfortable looking sofa that can be converted to a"+
         " bed",
         "refrigerator", "A battered refrigerator that has an abundance of notes"+
         " connected"+"\nto its surface. Maybe you can open it",
         "portrait", "A portrait of Demoder's family. You see his three\n"+
         "beautiful younger sisters and an older and a younger brother\n"+
         "gathered around his parents and grandmother",
         "painting", "A stunning painting of a beautiful lady. You wonder\n"+
         "who she could be" });
   
   dest_dir  = ({ "room/church", "church",
         "room/adv_guild", "guild",
         "room/shop", "shop",
         "room/pub2", "pub",
         "players/demoder/test_room", "south",
         "players/demoder/quiet", "north",
         "room/post", "post" });
   door_is_open = 0; door_is_closed = 1;
}

init() {
   ::init();
   add_action("open_door", "open");
   add_action("close_door", "close");
   dem_name = this_player()->query_real_name();
   if(dem_name == "demoder") {
      if(dem_name != "demoder") {
         write("You do not have power here...only Demoder!\n");
         return 1;
      }
      add_action("transport", "port");
      add_action("shields", "shields");
      add_action("field", "field");
      add_action("room_status", "room_stat");
   }
   force_field();
}

open_door(str) {
   vict_name = this_player()->query_real_name();
   if(!str) {
      write("What do you want to open?\n");
      return 1;
   }
   if(str != "frig door") {
      write("Open what?? Try opening the `frig door'. (Dork!)\n");
      return 1;
   }
   if(door_is_open) {
      write("The refrigerator is already open. Please close it. (It stinks.)\n");
      return 1;
   }
   write("You see plenty of beer cans and a half-empty bottle of whiskey.\n"+
      "On the bottom shelf of the refrigerator you notice a pizza box\n"+
      "with pizza crumbs all over it. The smell emenating from the open\n"+
      "refrigerator. It might be better for the air if you closed the\n"+
      "thing.\n");
   say(capitalize(vict_name)+" opens the refrigerator door. The smell coming"+
      "from it is horrible.\n" + "(Sorta like rotten cheeze and beer.)\n",
      this_player());
   door_is_open = 1;
   door_is_closed = 0;
   return 1;
}

close_door(str) {
   vict_name = this_player()->query_real_name();
   if(!str) {
      write("Close what? Yuh eyes?? (Dork!)\n");
      return 1;
   }
   if(str != "frig door") {
      write("Why yuh wanna close that? Try closing the `frig door'.(Dork!)\n");
      return 1;
   }
   if(door_is_closed) {
      write("The refrigerator is already closed. Be thankful.\n");
      return 1;
   }
   write("You close the door and suddenly the air smells fresher.\n"+
      "Congratulate yourself for a prompt response.\n");
   say(capitalize(vict_name)+" closes the refrigerator door. You sigh in"+
      " relief.\n", this_player());
   door_is_closed = 1;
   door_is_open = 0;
   return 1;
}

door() {
   door_is_open = 1;
   door_is_closed = 0;
}

shields(str) {
   if(!str) {
      write("Usage is: 'shields <on>/<off>/<status>'\n");
      return 1; }
   if(ss == 1 && str == "on") {
      write("Shields are already up, Sir.\n\n");
      return 1; }
   else if(ss == 0 && str == "on") {
      write("Shields activated, Sir.\n\n");
      ss = 1;
      return 1; }
   if(ss == 0 && str == "off") {
      write("Shields are already down, Sir.\n\n");
      return 1; }
   else if(ss == 1 && str == "off") {
      write("Shields deactivated, Sir.\n\n");
      ss = 0;
      return 1; }
   else if(str == "status" && ss == 1) {
      write("Shields active, Sir.\n");
      return 1; }
   else if(str == "status" && ss == 0) {
      write("Shields not active, Sir.\n");
      return 1; }
   else {
      write("Usage is: 'shields <on>/<off>/<status>'\n");
      return 1; }
}

room_status() {
write("The status of the room [players/demoder/study.c] :\n");
write("Force Field =>  ");
if(ss == 1) write("on\n");
else if(ss == 0) write("off\n");
return 1;
}
force_field() {
   object master;
         master=find_living(lower_case("demoder"));
   if(ss == 1) {
      if(this_player()->query_real_name() != "demoder") {
         move_object(this_player(), "room/post");
         tell_object(this_player(), "Demoder does not want to be disturbed right now.\n");
         tell_object(this_player(), "If you would like, please mail him a message and he will respond\n"+"as soon as possible. Thank you.\n\n");
         if(!master || !living(master)) {
            return ; }
         tell_object(master, capitalize(this_player()->query_real_name()) +
            " just tried to enter your workroom.\n");
         return 1; }
   }
}

