inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc="Dem: Elven Woods";
long_desc="You are in a dark forest. All around you the trees reach straight"+
" up towards\n"+
"the sky. You notice that it is very peaceful here; you could probably\n"+
"lose yourself in such a place as this. There is a path here going \n"+
"northeast and southwest. There is also an old track leading to the west.\n"+
"The track is overgrown with plants.\n\n";
dest_dir=({"players/demoder/elven/woods3", "northeast",
"players/demoder/elven/woods5", "southwest",
"players/demoder/elven/track1", "west"});
}
