inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are in a long hallway. The hallway continues to the north\n"+
"and south.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway7", "north",
"players/demoder/MIDDLE/castle/hallway11", "south"});
}
