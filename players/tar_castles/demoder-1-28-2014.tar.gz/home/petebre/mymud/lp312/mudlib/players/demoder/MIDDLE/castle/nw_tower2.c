inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Upper Northwest Tower";
long_desc = "You are on the second floor of the northwest tower of the castle.\n"+
"There is an archway to the northwest. Stairs continue to wind their way up\n"+
"and down.\n\n";
dest_dir = ({"players/demoder/MIDDLE/se_arch", "northwest",
"players/demoder/MIDDLE/castle/nw_tower", "down",
"players/demoder/MIDDLE/castle/nw_tower3", "up"});
}
