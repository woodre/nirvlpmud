inherit "room/room";

reset(arg) {
 if(arg) return;
 set_light(1);
 short_desc = "Middle Kingdom, West Road";
 long_desc = "You are on the inner city's West Road. To the north is the "+
 "Northwestern\n"+
 "Square. To the east you see the western part of the castle's moat.\n"+
 "The road continues to the south.\n\n";
 dest_dir = ({ "players/demoder/MIDDLE/nw_square", "north",
 "players/demoder/MIDDLE/w_road4", "south" });
}
