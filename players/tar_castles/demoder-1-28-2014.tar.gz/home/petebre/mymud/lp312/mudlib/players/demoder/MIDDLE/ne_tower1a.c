inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Northeast Tower Room";
long_desc = "You are in a dusty room. There isn't much to see here except\n"+
"lots of dust and cobwebs.\n\n";
dest_dir = ({"players/demoder/MIDDLE/ne_tower", "west"});
}
