inherit "room/room";
object guard, l_guard;
int i, a;

reset(arg) {
   if(arg) return;
   set_light(1);
   a = 0;
   i = 0;
   if(!present("guard")) {
      while(i<3) {
         i += 1;
         guard=clone_object("players/demoder/mon/guard");
         move_object(guard, this_object());
      }
      while(a<2) {
         a += 1;
         l_guard=clone_object("players/demoder/mon/l_guard");
         move_object(l_guard, this_object());
      }
   }
   short_desc = "Middle Kingdom, North Road";
   long_desc = "You are upon the inner city's North Road. To the north you see "+
   "the gates\n"+
   "leading to the Northern Realms. To the south you see the drawbridge \n"+
   "leading into Castle Demoz. The North Road continues to the east and\n"+
   "west.\n\n";
    dest_dir = ({ "room/church", "north",
         "players/demoder/MIDDLE/draw_bridge", "south", 
         "players/demoder/MIDDLE/n_road2", "west",
         "players/demoder/MIDDLE/n_road4", "east" });
}
