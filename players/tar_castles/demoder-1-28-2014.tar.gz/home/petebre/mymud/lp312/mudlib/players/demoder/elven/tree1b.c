inherit "room/room";
object g1, g2, g3;
int ss;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoder: First Holte Tree - Corridor";
   long_desc = "The corridor of the tree ends abruptly to the east ahead, for\n"+
   "you can discern a peculiar light source, brighter than the one illuminating\n"+
   "the corridor, coming from up ahead to the east.\n\n";
   dest_dir = ({"players/demoder/elven/tree1a", "west",
         "players/demoder/elven/tree1c", "east"});
}

