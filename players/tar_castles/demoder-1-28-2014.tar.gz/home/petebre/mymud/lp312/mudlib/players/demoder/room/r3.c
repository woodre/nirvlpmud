inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Test Room 3";
long_desc = "The third testing room.\n\n";
dest_dir = ({"players/demoder/room/r2.c", "south"});
}
