inherit "room/room";
#include <living.h>
object guard;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Test Room 2";
   long_desc = "This is the second testing room.\n\n";
   dest_dir = ({"players/demoder/room/r1.c", "south",
         "players/demoder/room/r3.c", "north"});
   if(!present("ethereal guard")) {
      guard = clone_object("players/demoder/mon/m1.c");
      move_object(guard, this_object());
   }
}

init() {
   ::init();
   add_action("north", "north");
}

catch_tell(str) {
   string who; object corpse;
   if(sscanf(str, "Ethereal %s died.\n", who) == 1) {
      if(who == "guard") {
         if(!present("ethereal guard", this_object())) {
            write("There is a sudden blinding flash of light that causes you to"+
               " cover\n" + "your eyes. As you look around in confusion and"+
               " startlement, your eyes\n" + "begin to focus on a ghostly being.\n\n");
            write("You sigh in exasperation as you realize that the guard you had"+
               " thought\n" + " defeated is somehow miraculously brought back to"+
               " stand before you.\n\n");
            if(present("corpse", this_object())) {
               corpse = present("corpse", this_object());
               destruct(corpse);
               return 1;
            }
            guard = move_object(clone_object("players/demoder/mon/m1.c"), this_object());
            return 1;
         }
      }
   }
}


north() {
   if(present("ethereal guard", this_object())) {
      write("The ethereal guard tells you: You may not proceed.\n\n");
      return 1;
   }
   else {
      this_player()->move_player("north#players/demoder/room/r3.c");
      return 1;
   }
}
