inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoder: Smithy Shop";
   long_desc = "You are in a smithy. You can buy weapons and armor here.\n"+
   "Commands are: 'buy item', 'list', 'list2'.\n"+
   "To the east is the arrow shop.\n\n";
   dest_dir = ({"players/demoder/room/room7a", "southwest",
         "players/demoder/elven/arrow_shop", "east"});
}

init() {
   ::init();
   add_action("buy", "buy");
   add_action("list", "list");
   add_action("list_two", "list2");
   add_action("buy_two", "purchase");
}

buy(item) {
   if (!item)
      return 0;
   call_other("players/demoder/MIDDLE/smithystore", "fill", 0);
   call_other("players/demoder/MIDDLE/smithystore", "buy", item);
   return 1;
}

list(obj) {
   call_other("players/demoder/MIDDLE/smithystore", "fill", 0);
   call_other("players/demoder/MIDDLE/smithystore", "inventory", obj);
   return 1;
}

find_item_in_player(i)
{
   object ob;
   
   ob = first_inventory(this_player());
   while(ob) {
      if (call_other(ob, "id", i))
         return ob;
      ob = next_inventory(ob);
   }
   return 0;
}

list_two() {
   write("The smithy's specialties are listed here:\n");
   write("   1. Longbow                     1500 coins\n");
   write("   2. Longbow +1                  3000 coins\n");
   write("   3. Longbow +2                  6000 coins\n");
   write("   4. Quarrel->30 normal arrows   3500 coins\n");
   write("   5. Quarrel->30 +1 arrows       6500 coins\n");
   write("   6. Quarrel->30 +2 arrows      11000 coins\n");
   write("To purchase these specialties, type:\n");
   write("      'purchase <#>'\n\n");
   return 1; }

buy_two(str) {
   object item;
   int price;
   if(str == "1") {
      item = clone_object("players/demoder/weap/longbow");
      price = 1500;
   }
   else if(str == "2") {
      item = clone_object("players/demoder/weap/longbow1");
      price = 3000;
   }
   else if(str == "3") {
      item = clone_object("players/demoder/weap/longbow2");
      price = 6000;
   }
   else if(str == "4") {
      item = clone_object("players/demoder/armor/quarrel");
      price = 3500;
   }
   if(str == "5") {
      item = clone_object("players/demoder/armor/quarrel1");
      price = 6500;
   }
   if(str == "6") {
      item = clone_ojbect("players/demoder/armor/quarrel2");
      price = 11000;
   }
   if(this_player()->query_money() < price) {
      write("You do not have enough coins!!\n");
      return 1; }
   if(!this_player()->add_weight(item->query_weight())) {
      write("But you can't carry that much!!\n");
      return 1; }
   this_player()->add_money(-price);
   move_object(item, this_player());
   return 1;
}
