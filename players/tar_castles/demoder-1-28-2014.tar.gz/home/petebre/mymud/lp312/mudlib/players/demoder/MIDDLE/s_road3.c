inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, South Road";
long_desc = "You are upon the inner city's South Road. To the south you see "+
 "the Southern\n"+
 "Gate. To the north is the south wall and surrounding moat of the castle.\n"+
 "The road continues east and west.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/s_road4", "west",
 "players/demoder/MIDDLE/s_gate", "south",
 "players/demoder/MIDDLE/s_road2", "east" });
}
