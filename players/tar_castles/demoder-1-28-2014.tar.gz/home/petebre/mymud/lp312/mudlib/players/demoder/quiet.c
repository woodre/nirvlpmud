
inherit "room/room.c";

object dem, vis, obj1;
object master, other_room;
string mast_name;
string location, dem_name, vis_name;
int shields;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoder's Quiet Room";
   long_desc  = "This is Demoder's Quiet Room. He comes here to relax and"+
   " talk to others.\n" + "You notice that there are various objects "+
   "strewn about the room\n" + "in a disorderly fashion. Maybe you could "+
   "clean the place\n" + "up for him. He would be profoundly grateful.\n\n";
   dest_dir = ({ "players/demoder/study", "study",
         "players/demoder/test_room", "north",
         "room/adv_guild", "guild" });
   location = allocate(6);
}

init() {
   ::init();
   add_action("clean_room", "clean");
   add_action("transport", "port");
   dem_name = this_player()->query_real_name();
   if(dem_name == "demoder") {
      if(dem_name != "demoder") {
         write("Only Demoder himself can mess up this room. NAH!\n\n");
         return 1;
      }
      add_action("mess_room", "mess");
      add_action("room_status", "room_stat");
   }
}

clean_room(str) {
   vis_name = this_player()->query_real_name();
   if(!str) {
      write("What do you want to clean? Yuh nose?!?!?\n");
      say(capitalize(vis_name)+" wants to clean his nose. Please excuse him.\n",
         this_player());
      return 1;
   }
   if(str != "room") {
      write("Why yuh wanna clean that?? Try cleaning the `room'.\n");
      return 1;
   }
   write("You clean up Demoder's messy room. You feel proud of yourself\n"+
      "for doing such a good deed.\n\n");
   say(capitalize(vis_name)+" cleans up Demoder's room. Demoder is"+
      " extremely thankful.\n", this_player());
   long_desc = capitalize(vis_name) + " has just cleaned up Demoder's "+
   "messy room. The room seems\n" + "alot cleaner now and even smells better"+
   " than usual. Maybe Demoder should\n" + "start picking up after himself"+
   " after all.\n\n";
   this_player()->look();
   return 1;
}

mess_room() {
   say("Demoder has decided to mess the room up again. All of your\n"+
      "work has been for naught. You sigh in exasperation and give Demoder\n"+
      "a withering look. This only causes him to seem more amused. You\n"+
      "finally throw your hands up in despair. Demoder chuckles.\n\n");
   long_desc = "Once again Demoder has messed up his room. Maybe this time\n"+
   "no one should help him by cleaning it up. That should teach him to be\n"+
   "more considerate, clean, and altogether less lazy. The room is in even\n"+
   "worse conditions than before.\n\n";
   return 1;
}

/* Fixed by Nooneelse. Bow, worship, etc... (me) */
transport(arg) {
   object me;
    int i;
   if(!arg) {
      write("The following locations are open for porting:\n");
      write("location [1]		the village church\n");
      write("location [2]		the village shop\n");
      write("location [3]		the village adventure's guild\n");
      write("location [4]		the wizard's guild\n");
      write("location [5]          the entrance to Demoder's castle\n");
      write("\nTo port, type 'port <#>'\n");
      return 1;
   }
   me = find_player("demoder");
   location[1] = "/room/church";
   location[2] = "/room/shop";
   location[3] = "/room/adv_guild";
   location[4] = "/room/adv_inner";
   location[5] = "/players/demoder/castle";
   sscanf(arg, "%d", i);
   move_object(this_player(), location[i]);
   tell_object(this_player(), "You are now in "+location[i]+".\n");
   return 1;
}
