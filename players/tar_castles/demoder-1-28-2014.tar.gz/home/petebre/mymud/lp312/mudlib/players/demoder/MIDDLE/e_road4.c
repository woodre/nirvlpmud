inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, East Road";
long_desc = "You are upon the inner city's East Road. To the east you see "+
 "the local shop\n"+
 "where you can buy and sell items. The road continues north and south.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/e_road3", "north",
 "players/demoder/MIDDLE/shop", "east",
 "players/demoder/MIDDLE/e_road5", "south" });
}
