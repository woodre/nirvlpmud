inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, West Road";
long_desc = "You are upon the West Road of the inner city. To the west you "+
 "see the western\n"+
 "gate. To the east you see the western wall of the castle and the surrounding\n"+
 "moat. The road continues to the north and south.\n\n";
dest_dir = ({ "room/vill_green", "west",
 "players/demoder/MIDDLE/w_road2", "south",
 "players/demoder/MIDDLE/w_road4", "north" });
}
