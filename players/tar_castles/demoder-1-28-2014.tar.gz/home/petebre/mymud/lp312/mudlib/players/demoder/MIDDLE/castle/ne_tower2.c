inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Upper Northeast Tower";
long_desc = "You are on the second floor of the northeast tower of the castle.\n"+
"There is an archway to the northeast. Stairs continue to wind their way up\n"+
"and down.\n\n";
dest_dir = ({"players/demoder/MIDDLE/sw_arch", "northeast",
"players/demoder/MIDDLE/castle/ne_tower", "down",
"players/demoder/MIDDLE/castle/ne_tower3", "up"});
}
