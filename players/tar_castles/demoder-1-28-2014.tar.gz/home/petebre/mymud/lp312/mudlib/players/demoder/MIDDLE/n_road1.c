inherit "room/room";
object guard;
int i;

reset(arg) {
   if(arg) return;
   set_light(1);
   i = 0;
   if(!present("guard")) {
      while(i<3) {
         i += 1;
         guard=clone_object("players/demoder/mon/guard");
         move_object(guard, this_object());
      }
   }
   short_desc = "Middle Kingdom, North Road";
   long_desc = "You are upon the inner city's North Road. To the south "+
   "you see the\n"+
   "northern part of the moat surrounding the castle. To the west you\n"+
   "see one of the city's Corner Squares. The North Road continues\n"+
   "to the east.\n\n";
   dest_dir = ({ "players/demoder/MIDDLE/nw_square", "west",
         "players/demoder/MIDDLE/n_road2", "east" });
}
