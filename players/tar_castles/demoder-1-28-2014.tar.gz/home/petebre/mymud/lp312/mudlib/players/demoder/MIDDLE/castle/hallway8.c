inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are in a long hallway. The hallway continues to the south\n"+
"and curves eastward to the north.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway6", "north",
"players/demoder/MIDDLE/castle/hallway10", "south"});
}
