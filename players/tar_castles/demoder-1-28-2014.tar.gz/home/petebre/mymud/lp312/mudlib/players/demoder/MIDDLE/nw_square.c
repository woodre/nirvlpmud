inherit "room/room";
object gold, golda, goldb, lady, man, boy;

reset(arg) {
int a;
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, Northwest Square";
long_desc = "You are in the inner city's Northwest Square. You see people "+
 "about enjoying\n"+
 "the nice weather. You notice that the citizens here are a very peaceful\n"+
 "bunch. To the northwest is the entrance to the Northwestern Tower. North\n"+
 "Road is east and West Road is south.\n\n";
dest_dir = ({ "room/storage", "northwest",
 "players/demoder/MIDDLE/n_road1", "east",
 "players/demoder/MIDDLE/w_road5", "south" });
a=0;
if(!present("twin")) {
while(a<2) {
boy=clone_object("obj/monster");
boy->set_name("twin");
boy->set_level(5);
boy->set_alias("boy");
boy->set_race("human");
boy->set_short("A small boy");
boy->set_long("A young boy, out enjoying the scenary with his parents and twin brother.\n");
boy->set_al(75);
boy->set_hp(60);
boy->set_wc(9);
boy->set_ac(5);
gold=clone_object("obj/money");
gold->set_money(random(100)+25);
boy->set_move_at_reset();
move_object(boy, this_object());
move_object(gold, boy);
a+=1;
}
lady=clone_object("obj/monster");
lady->set_name("lady");
lady->set_level(7);
lady->set_short("A beautiful lady");
lady->set_long("A pretty lady, out enjoying the scenary with her husband and twin sons.\n");
lady->set_hp(105);
lady->set_al(105);
lady->set_wc(11);
lady->set_ac(6);
lady->set_move_at_reset();
move_object(lady, this_object());
golda=clone_object("obj/money");
golda->set_money(random(100)+75);
move_object(golda, lady);
man=clone_object("obj/monster");
man->set_name("man");
man->set_level(9);
man->set_short("A handsome man");
man->set_long("A handsome man, out enjoying the scenary with his wife and twin sons.\n");
man->set_hp(135);
man->set_al(400);
man->set_wc(13);
man->set_ac(7);
man->set_move_at_reset();
move_object(man, this_object());
goldb=clone_object("obj/money");
goldb->set_money(random(100)+125);
move_object(goldb, man);
}
}
