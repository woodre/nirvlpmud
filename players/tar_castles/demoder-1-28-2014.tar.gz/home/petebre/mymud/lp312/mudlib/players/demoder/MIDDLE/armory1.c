inherit "room/room";
object stand1, stand2, stand3;

reset(arg) {
 if(arg) return;
 set_light(1);
 if(!present("stand")) {
  stand1=clone_object("players/demoder/obj/stand1");
  move_object(stand1, this_object());
  stand2=clone_object("players/demoder/obj/stand2");
  move_object(stand2, this_object());
  stand3=clone_object("players/demoder/obj/stand3");
  move_object(stand3, this_object());
}
 short_desc = "Dem: MIDDLE Armory One";
 long_desc = "You are in the northern barracks' armory. You see lots of "+
  "war equipment\n"+
  "hung on three big stands. The way out is to the west.\n\n";
 dest_dir = ({ "players/demoder/MIDDLE/barrack1", "west" });
}
