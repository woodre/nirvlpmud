inherit "room/room";

reset(arg) {
 if(arg) return;
 set_light(1);
short_desc = "Middle Kingdom, North Road";
 long_desc = "You are upon the inner city's North Road. To the east is "+
  "the northeastern\n"+
  "Corner Square. The road continues to the west.\n\n";
 dest_dir = ({ "players/demoder/MIDDLE/ne_square", "east",
  "players/demoder/MIDDLE/n_road4", "west" });
}
