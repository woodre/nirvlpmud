inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, South Road";
long_desc = "You are upon the inner city's South Road. To the south you see "+
 "the Fast Food\n"+
 "and Drinks Order-to-go center. The road continues east and west.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/s_road3", "west",
 "players/demoder/MIDDLE/take_out", "south",
 "players/demoder/MIDDLE/s_road1", "east" });
}
