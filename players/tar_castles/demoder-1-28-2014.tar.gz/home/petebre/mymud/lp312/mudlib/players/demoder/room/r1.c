inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Test Room 1";
   long_desc = "This is the first test room.\n\n";
   dest_dir = ({ "players/demoder/room/r2_v2.c", "north"
               });
}
