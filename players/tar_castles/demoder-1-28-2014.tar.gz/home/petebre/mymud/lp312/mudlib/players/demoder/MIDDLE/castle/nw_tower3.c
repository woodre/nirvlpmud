inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Upmost Northwest Tower";
long_desc = "You are at the top of the northwest tower of the castle. \n"+
"From surrounding windows you can look out at the city and the rooftop\n"+
"of the keep itself. There isn't much here; this place seems to be mainly\n"+
"a lookout point. There are stairs leading down.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/nw_tower2", "down"});
}
