inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Northwest Tower";
long_desc = "You are on the first floor of the northwest tower of the castle.\n"+
"There is are stairs leading up and the castle hallway lies to the southeast.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/nw_tower2", "up",
"players/demoder/MIDDLE/castle/hallway6", "southeast"});
}
