inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, South Road";
long_desc = "You are upon the inner city's South Road. To the west you see "+
 "the Southeastern\n"+
 "Square. The road continues west.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/se_square", "east",
 "players/demoder/MIDDLE/s_road2", "west" });
}
