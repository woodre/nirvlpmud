inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, East Road";
long_desc = "You are upon the inner city's East Road. To the south you see "+
 "the Southeastern\n"+
 "Square. The road continues north.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/se_square", "south",
 "players/demoder/MIDDLE/e_road4", "north" });
}
