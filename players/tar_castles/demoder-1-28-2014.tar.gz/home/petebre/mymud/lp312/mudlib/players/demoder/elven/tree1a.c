inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoder: First Holte Tree - Corridor";
long_desc = "You are in what appears to be a corridor of the inside of a huge\n"+
"tree. The light is luminescent, but shallow, as though they glow from \n"+
"within the very structure of the tree itself. The corridor continues\n"+
"to the east and west.\n\n";
dest_dir = ({"players/demoder/elven/tree1", "west",
 "players/demoder/elven/tree1b", "east"});
}
