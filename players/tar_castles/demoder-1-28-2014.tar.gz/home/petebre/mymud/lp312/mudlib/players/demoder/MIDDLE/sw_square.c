inherit "room/room";
object gold, golda, goldb, lady, man, girl;

reset(arg) {
int a;
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, Southwest Square";
long_desc = "You are in the inner city's Southwest Square. You see people "+
 "about enjoying\n"+
 "the nice weather. You notice that the citizens here are a very peaceful\n"+
 "bunch. To the northwest is the entrance to the Southwestern Tower. West\n"+
 "Road is north and South Road is east.\n\n";
dest_dir = ({ "room/vill_track", "southwest",
 "room/shop", "east",
 "players/demoder/MIDDLE/w_road1", "north" });
a=0;
if(!present("twin")) {
while(a<2) {
girl=clone_object("obj/monster");
girl->set_name("twin");
girl->set_level(5);
girl->set_alias("girl");
girl->set_race("human");
girl->set_short("A small girl");
girl->set_long("A young girl, out enjoying the scenary with his parents and twin brother.\n");
girl->set_al(200);
girl->set_hp(75);
girl->set_wc(9);
girl->set_ac(5);
gold=clone_object("obj/money");
gold->set_money(random(100)+25);
girl->set_move_at_reset();
move_object(girl, this_object());
move_object(gold, girl);
a+=1;
}
lady=clone_object("obj/monster");
lady->set_name("lady");
lady->set_level(7);
lady->set_short("A beautiful lady");
lady->set_long("A pretty lady, out enjoying the scenary with her husband and twin daughters.\n");
lady->set_hp(105);
lady->set_al(300);
lady->set_wc(11);
lady->set_ac(6);
lady->set_move_at_reset();
move_object(lady, this_object());
golda=clone_object("obj/money");
golda->set_money(random(100)+75);
move_object(golda, lady);
man=clone_object("obj/monster");
man->set_name("man");
man->set_level(9);
man->set_short("A handsome man");
man->set_long("A handsome man, out enjoying the scenary with his wife and twin daughters.\n");
man->set_hp(135);
man->set_al(400);
man->set_wc(13);
man->set_ac(7);
man->set_move_at_reset();
move_object(man, this_object());
goldb=clone_object("obj/money");
goldb->set_money(random(100)+125);
move_object(goldb, man);
}
}
