inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoder: Testing Room";
long_desc = "Demoder's Testing Room. Nuff said.\n\n";
dest_dir = ({ "players/demoder/study", "north",
"players/demoder/quiet", "south" });
}
