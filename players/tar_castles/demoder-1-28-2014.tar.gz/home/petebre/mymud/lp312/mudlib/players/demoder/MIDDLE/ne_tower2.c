inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz City Northeast Upper Tower";
long_desc = "You are on the second level of the Northeast Tower. Through\n"+
"the window to the north you can see the plains of the countryside \n"+
"spreading out into the horizon. There is a circular stairway leading up \n"+
"and down. There is also an archway to the southwest.\n\n";
dest_dir = ({"players/demoder/MIDDLE/ne_tower", "down",
"players/demoder/MIDDLE/ne_tower3", "up",
"players/demoder/MIDDLE/sw_arch", "southwest"});
}
