inherit "obj/monster";

reset(arg) {
   int items; object armors, weapons;
   ::reset(arg);
   if(arg) return;
   set_name("ethereal guard");
   set_race("etheric");
   set_alias("guard");
   set_short("An ethereal guard");
   set_long("This an ethereal guard. He stands here and blocks your passage "+
      "further into the realm.\n");
   set_hp(random(101)+200);
   set_level(15);
   set_wc(random(7)+14);
   set_ac(random(6)+12);
   items = random(3);
   if(items == 0) return;
   if(items == 1) {
      armors = clone_object("players/demoder/armor/a1.c");
      move_object(armors, this_object());
      weapons = clone_object("players/demoder/weap/w1.c");
      move_object(weapons, this_object());
   }
   if(items == 2) {
      armors = clone_object("players/demoder/armor/a1.c");
      move_object(armors, this_object());
   }
}
