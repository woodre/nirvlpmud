inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Short Archway Leading Southwest";
long_desc = "You are in a short archway leading from the Northeast Tower into\n"+
"the main castle of Demoz. There are huge windows on both sides of the \n"+
"short hallway letting in plenty of light. The Northeast Tower is through \n"+
"the northeast arch.\n\n";
dest_dir = ({"players/demoder/MIDDLE/ne_tower2", "northeast",
"players/demoder/MIDDLE/castle/ne_tower2", "southwest"});
}
