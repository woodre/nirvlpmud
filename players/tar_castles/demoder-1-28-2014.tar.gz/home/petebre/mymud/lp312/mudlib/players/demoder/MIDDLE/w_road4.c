inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, West Road";
long_desc = "You are on the inner city's West Road. You see the castle's "+
"moat to the\n"+
"east. To the west is the inner city's Smithy. The road continues north\n"+
"and south.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/w_road5", "north",
"players/demoder/MIDDLE/w_road3", "south",
"players/demoder/MIDDLE/smithy", "west" });
}
