inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, South Road";
long_desc = "You are upon the inner city's South Road. To the west you see "+
 "the Southwestern\n"+
 "Square. The road continues east.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/sw_square", "west",
 "players/demoder/MIDDLE/s_road4", "east" });
}
