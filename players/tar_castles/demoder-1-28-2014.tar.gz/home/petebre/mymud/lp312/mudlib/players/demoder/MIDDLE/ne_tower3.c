inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz City Northeast Upmost Tower";
long_desc = "You are at the top of the Northeast Tower. There is a spiralling\n"+
"stairway leading down. Through windows to the east, you can look out \n"+
"upon a forest stretching away to some mountains. The window to the south\n"+
"and west shows the city and castle of Demoz.\n\n";
dest_dir = ({"players/demoder/MIDDLE/ne_tower2", "down"});
}
