inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Guard's Bunker";
long_desc = "You are in the guard's bunker. This see orderly bunk-beds\n"+
"against the far wall. The guards seem to be very neat for soldiers.\n"+
"In one corner is a table with a deck of cards and some tokens neatly\n"+
"stacked on top. The guards seem to be very well-disciplined. There \n"+
"is a room to the south.\n\n";
dest_dir = {("players/demoder/MIDDLE/castle/hallway10", "east",
"players/demoder/MIDDLE/castle/hallway12a", "south"});
}
