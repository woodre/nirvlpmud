inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are in a long hallway. There is an arch to the northwest\n"+
"that leads into a tower. The hallway continues to the east and south.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/nw_tower", "northwest",
"players/demoder/MIDDLE/castle/hallway4", "east",
"players/demoder/MIDDLE/castle/hallway8", "south"});
}
