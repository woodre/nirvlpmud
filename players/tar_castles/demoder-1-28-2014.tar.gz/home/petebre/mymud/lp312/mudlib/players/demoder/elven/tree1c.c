inherit "room/room";
object g1, g2;
object target;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoder: First Holte Tree - Center";
   long_desc = "You are at the entrance to the corridor. You notice that\n"+
   "there are other corridors ranging about the floor of this central\n"+
   "point of the tree.\n\n";
   dest_dir = ({"players/demoder/elven/tree1cent", "east",
         "players/demoder/elven/tree1b", "west"});
}

init() {
   ::init();
   if(!present("elf guard", this_object())) {
      write("\n\nElf guards charge you from out of the shadows!!\n");
      write("The elf guard yells: How dare you enter the Sacred Holte!!\n");
      write("\n");
      g1 = clone_object("players/demoder/mon/elfguard");
      g2 = clone_object("players/demoder/mon/elfguard");
      move_object(g1, this_object());
      move_object(g2, this_object());
      g1->attacked_by(this_player());
      g2->attacked_by(this_player());
      return 1; }
   target=present("corpse", this_object());
   if(target) destruct(target);
}

