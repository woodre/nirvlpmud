inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoz Castle Hallway";
   long_desc = "You are in a long hallway stretching east and west.\n"+
   "There are rooms to both the north and south.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/castle/hallway5", "east",
         "players/demoder/MIDDLE/castle/guard_room", "north",
         "players/demoder/MIDDLE/castle/storeroom3", "south",
         "players/demoder/MIDDLE/castle/hallway1", "west"});
}
