#include "/obj/door.h"

object d_obj1, d_obj2, k_obj1;

MAKE_DOORS("players/demoder/MIDDLE/castle/hallway14", "north",
"players/demoder/MIDDLE/castle/red_room", "south",
"red", "red_advisor", "This is a blood red door with intricate carvings.\n",
1, 1, 1);
