inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are in a long hallway. The hallway continues to the north\n"+
"and south. To the west is a room.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway8", "north",
"players/demoder/MIDDLE/castle/hallway10a", "west",
"players/demoder/MIDDLE/castle/hallway12", "south"});
}
