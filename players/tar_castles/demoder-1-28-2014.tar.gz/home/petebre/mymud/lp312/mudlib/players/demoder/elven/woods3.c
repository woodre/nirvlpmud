inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc="Dem: Elven Woods";
long_desc="You are on a small path covered with leaves, needles and plenty"+
" of cones.\n"+
"The surrounding trees makes it very hard to see beyond the path that you\n"+
"are on. The path leads further southwest and the way back is north.\n\n";
dest_dir=({"players/demoder/elven/woods2", "north",
"players/demoder/elven/woods4", "southwest"});
}
