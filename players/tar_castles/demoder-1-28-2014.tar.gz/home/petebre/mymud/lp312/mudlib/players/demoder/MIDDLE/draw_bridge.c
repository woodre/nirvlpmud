inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Dem: Demoz Castle Daw Bridge";
   long_desc = "You are upon the draw bridge of Castle Demoz. You see\n"+
   "the moat bubbling on both sides of the bridge.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/n_road3", "north",
         "players/demoder/MIDDLE/castle/castle_entrance", "south"});
}
