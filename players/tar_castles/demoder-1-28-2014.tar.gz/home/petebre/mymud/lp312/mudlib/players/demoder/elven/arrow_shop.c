inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoder: Arrow Shop";
   long_desc = "This is where you come to refill your quarrel with arrows.\n"+
   "To refill your quarrel, type:\n"+
   "     'refill with <amount> <type of arrows>'\n"+
   "The cost is:     50 coins per normal arrow\n"+
   "                150 coins per +1 arrow\n"+
   "                300 coins per +2 arrow.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/smithy", "west"});
}

init() {
   ::init();
   add_action("refill_arrows", "refill");
}

refill_arrows(str) {
   object quarrel;
   string choice;
   int amt, price, alt_price, num, maxcharge;
   if(!str) return;
   if(sscanf(str, "with %d %s", amt, choice) != 2) {
      write("To refill type: 'refill with <amount> <type of arrows>'\n");
      return 1; }
   if(!present("multi_quarrel", this_player())) {
      write("But you have no quarrel!!\n");
      return 1; }
   quarrel = present("multi_quarrel", this_player());
   num = quarrel->query_charge();
   maxcharge = quarrel->query_max_charge();
   if(choice == "normal") price = 50*amt;
   if(choice == "+1") price = 150*amt;
   if(choice == "+2") price = 300*amt;
   if(choice != "normal" && choice != "+1" && choice != "+2") {
     write("Refill with normal, +1, or +2 arrows only!\n");
     return 1; }
   if(quarrel->query_charge() && quarrel->query_choice() != choice) {
     write("Your quarrel already has "+quarrel->query_choice()+" arrows!\n");
     write("Refill with same type only!\n");
     return 1; }
   if(this_player()->query_money() < price) {
      write("You don't have enough coins!\n");
      return 1; }
   if(quarrel->query_max_charge() < num+amt) {
     write("That is more than your quarrel can hold.\n");
     write("Filling to the maximum amount.\n");
     quarrel->set_charge(maxcharge);
     quarrel->set_choice(choice);
     if(choice == "normal") alt_price = (maxcharge - num)*50;
     if(choice == "+1") alt_price = (maxcharge - num)*150;
     if(choice == "+2") alt_price = (maxcharge - num)*300;
     quarrel->set_choice(choice);
     this_player()->add_money(-alt_price);
     write("You paid "+alt_price+" for a refill of arrows.\n");
     write("Your quarrel is now packed with "+maxcharge+" "+
        choice+" arrows.\n");
     return 1; }
   this_player()->add_money(-price);
   quarrel->set_charge(num+amt);
   if(!this_player()->add_weight(quarrel->query_weight())) {
      write("You can not carry that much!\n");
      quarrel->set_charge(-amt);
      this_player()->add_money(price);
      return 1; }
   quarrel->set_choice(choice);
   write("You paid "+price+" coins for arrow refills.\n");
   write("Your quarrel is now packed with "+quarrel->query_charge()+" "+
     choice+" arrows.\n");
   write("in your quarrel.\n");
   return 1; 
}

