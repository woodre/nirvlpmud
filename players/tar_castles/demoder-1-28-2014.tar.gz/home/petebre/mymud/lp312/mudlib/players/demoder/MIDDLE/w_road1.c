inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, West Road";
long_desc = "You are upon the West Road of the inner city. To the south you "+
 "see the\n"+
 "Southwestern Square. The road continues to the north.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/w_road2", "north",
 "players/demoder/MIDDLE/sw_square", "south" });
}
