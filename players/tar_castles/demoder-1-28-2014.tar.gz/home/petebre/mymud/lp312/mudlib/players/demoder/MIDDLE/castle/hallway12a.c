inherit "room/room";

reset(arg) {
int a, b, c;
if(!present("guard", this_object())) {
while(a<4) {
a+=1;
move_object(clone_object("players/demoder/mon/guard.c"), this_object());
}
while(b<2) {
b+=1;
move_object(clone_object("players/demoder/mon/s_guard.c"), this_object());
}
while(c<1) {
c+=1;
move_object(clone_object("players/demoder/mon/l_guard.c"), this_object());
}
}
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Storage Room";
long_desc = "You are in one of the many guard stations within Castle Demoz.\n"+
"It seems the guards here are off duty, but they may be called at any time\n"+
"to protect the king's staff. There is a room to the north.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway12", "east",
"players/demoder/MIDDLE/castle/hallway10a", "north"});
}
