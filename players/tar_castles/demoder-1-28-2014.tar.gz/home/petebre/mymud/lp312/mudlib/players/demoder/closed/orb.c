object summoned_origin;
object summoned_object;
object anchor_room;

get() { if (this_player()->query_real_name() == "demoder") return 1; }

id(str) {
   return str == "orb" || str == "demoder's orb" || str == "ND";
}

short() { return; }

long() {
   write("A dead soul! Be careful that you do not turn into one like it!!\n");
}

drop() { return 1 ; }

reset(arg) {
   if(arg) { return; }
}

init() {
   if(this_player()->query_real_name() == "demoder") {
      add_action("damage_living","dred");
      add_action("heal_living","dhl");
      add_action("super_heal", "dsl");
      add_action("dest_living","ddest");
      add_action("change_exp", "dexp");
      add_action("change_money","dold");
      add_action("trans_player","drans");
      add_action("super_shout", "dsh");
      add_action("dest_player", "ddest!");
      add_action("inv_tell", "dint");
      add_action("echoto", "dech");
      add_action("sil_force", "dforce");
      add_action("sil_force_two", "dforce2");
      add_action("room_tell", "decho");
      add_action("force_player", "df");
      add_action("move_inv", "din");
      add_action("power_get", "get!");
      add_action("trans_object", "drans!");
      add_action("shout_to_players", "dshp");
      add_action("shout_to_wizards", "dshw");
      add_action("shout_to_players_2", "dsp");
      add_action("shout_to_players_3", "dsp!");
      add_action("shout_to_wizards_2", "dsw");
      add_action("change_directory", "work");
      add_action("change_weight", "dweight");
      add_action("wizard_list", "wizzes");
      add_action("players_list", "mort");
      add_action("orb_help", "orb_help");
   }
}



damage_living(str){   /* this will reduce a living object to 0 hit points */
   object target;        /* and reduce its spell points to 0 */
   int spell_points;
   int amt;
   if(!str) { return 0; }
   target = find_living(str);
   if(!target) { return 0; }
   target->add_hit_point(-250);
   spell_points = (-1) * target->query_spell_point();
   target->add_spell_point(spell_points);
   return 1;
}

super_heal(str){   /* this will heal a living object anywhere */
   object target;      /* and recharge its spell points */
   string victim;
   int amt;
   if(!sscanf(str, "%s %d", victim, amt) && sscanf(str, "%s %d", victim, amt) != 2) {
      write("Usage is: dsl <target> <amt>.\n");
      return 1;
   }
   if(!str) { return 0; }
   target = find_living(victim);
   if(!target) { return 0; }
   target->heal_self(amt);
   write("You have healed "+capitalize(victim)+" with "+amt+" points.\n");
   return 1;
}

heal_living(str){   /* this will heal a living object anywhere */
   object ppl;      /* and recharge its spell points */
   int a, amt, nmb;
   ppl=users();
   if(sscanf(str, "%d %d", nmb, amt) != 2) {
      write("Usage is: 'dhl <level> <amount>'\n");
      return 1; }
   for(a=0;a<sizeof(ppl);a++) {
      if(ppl[a]->query_level() < nmb && ppl[a] != this_player()) {
         ppl[a]->heal_self(amt);
         tell_object(ppl[a], "You have been blessed by Demoder. :)\n");
       }
   }
   write("You have healed those under level "+nmb+" with "+amt+".\n");
   return 1; }

dest_living(str){   /* this will destruct a living object anywhere */
   object target;
   if(!str) { return 0; }
   target = find_living(str);
   if(!target) target = find_ob(str);
   if(!target) return 0;
   destruct(target);
   return 1;
}

change_exp(str){   /* this will change the experience value of a player */
   object target;
   string tname;
   int amount;
   if(!str) { return 0; }
   if(!sscanf(str,"%s %d",tname,amount)) { return 0; }
   target = find_living(lower_case(tname));
   if(!target) { return 0; }
   target->add_exp(amount);
   return 1;
}

change_money(str){   /* this will change the amount of gold a player has */
   object target;
   string tname;
   int amount;
   if(!str) { return 0; }
   if(!sscanf(str,"%s %d",tname,amount)) { return 0; }
   target = find_living(lower_case(tname));
   if(!target) { return 0; }
   target->add_money(amount);
   return 1;
}

trans_player(str) {   /* transport a player to a specified destination */
      object target;
   object destination;
   string tname, whereto;
   status temp_shield;
   if(!str) { return 0; }
   if(!sscanf(str,"%s %s",tname,whereto)) { return 0; }
   target = find_living(lower_case(tname));
   if(!target) {
      write("Could not find "+tname+"\n");
      return 1;
   }
   if(whereto == "back") {
      if(target != summoned_object) {
         write("The target was not the last one summoned.\n");
         return 1;
      }
      move_object(target,summoned_origin);
      return 1;
   }
   if(whereto == "here") {
      say(capitalize(target->query_name()) + " suddenly vanishes"+
         " into thin air.\n", target);
      summoned_origin = environment(target);
      summoned_object = target;
      move_object(target,environment(this_player()));
      call_other(target, "command", "look");
      tell_object(target, "You have been transported to Demoder's workroom.\n");
      return 1;
   }
   destination = valid_read(whereto);
   if(!destination) {
      write("Cannot find "+whereto+"\n");
      return 1;
   }
   move_object(target,destination);
   return 1;
}


valid_read(str) { return call_other(this_player(),"valid_read",str); }

orb_help() {
   if(this_player()->query_real_name() != "demoder") {
      return 0; }
   command("more /players/demoder/closed/orb_help", this_player());
   return 1;
}


super_shout(str) {
   if(!str) {
      write("What do you want to echo??\n");
      return 1;
   }
   shout("\n"+str+"\n");
   tell_object(this_player(), "You have shouted: "+str+"\n");
   return 1; }

dest_player(str) {
   string tname, mess;
   object target;
   
   if(!str) {
      write("Who/what is the target?\n");
      return 1;
   }
   if(!sscanf(str, "%s with %s", tname, mess)) {
      write("Usage is: ddest! <target> <message>.\n");
      return 1;
   }
   if(sscanf(str, "%s with %s", tname, mess) != 2) {
      write("Usage is: ddest! <target> <message>.\n");
      return 1;
   }
   target=find_living(tname);
   if(!target || !living(target)) {
      write("That target was not found.\n");
      return 1;
   }
   tell_object(target, "\n\n"+mess+"\n");
   destruct(target);
   tell_object(this_player(), "You have destructed "+tname+" with "+mess+"\n");
   return 1;
}

inv_tell(str) {
   object target, master;
   string tname, mess;
   if(!str) {
      write("What do you want to tell to someone??\n");
      write("Usage is: dint <target> <mess>.\n");
      return 1;
   }
   if(!sscanf(str, "%s %s", tname, mess)) {
      write("Usage is: dint <target> <mess>.\n");
      return 1; }
   if(sscanf(str, "%s %s", tname, mess) != 2) {
      write("Usage is: dint <target> <mess>.\n");
      return 1; }
   target = find_player(tname);
   if(!living(target) || !target) {
      write("That person isn't playing right now.\n");
      return 1; }
   tell_object(target, "Demoder tells you: "+mess+"\n\n");
   write("You have told "+capitalize(tname)+" ("+mess+").\n");
   return 1;
}

echoto(str) {
   object target;
   string tname, mess;
   if(!str) {
      write("Usage is: dech <target>, <mess>.\n");
      return 1;
   }
   if(!sscanf(str, "%s, %s", tname, mess)) {
      write("Usage is: dech <target>, <mess>.\n");
      return 1;
   }
   if(sscanf(str, "%s, %s", tname, mess) != 2) {
      write("Usage is: dech <target>, <mess>.\n");
      return 1;
   }
   target = find_player(tname);
   if(!target || !living(target)) {
      write("That player is not in condition to receive your echo.\n");
      return 1;
   }
   tell_object(target, mess+"\n");
   write("You have told "+capitalize(tname)+" ("+mess+").\n");
   return 1;
}

sil_force(str) {
   object ppl;
   string victim, what;
   int a, nmb;
   if(!str) {
      write("Usage is: 'dforce <level> <command>'\n");
      return 1;
   }
   ppl=users();
   if(sscanf(str, "%d %s", nmb, what) != 2) {
      write("Usage is: 'dforce <level> <command>'.\n");
      return 1; }
   for(a=0;a<sizeof(ppl);a++) {
      if(ppl[a]->query_level() < nmb && ppl[a] != this_player()) 
         ppl[a]->force_us(what);
   }
   write("You have just forced everyone below "+nmb+" to\n");
   write(what+"\n");
   return 1;
}

sil_force_two(str) {
   object ppl;
   string victim, what;
   int a, b, nmb;
   if(!str) {
      write("Usage is: 'dforce <1st level> <2nd level> <command>'\n");
      return 1;
   }
   ppl=users();
   if(sscanf(str, "%d %d %s", nmb, b, what) != 3) {
      write("Usage is: 'dforce <1st level> <2nd level> <command>'.\n");
      return 1; }
   if(nmb < b) {
      write("The first number has to be greater than the second one!\n");
      return 1; }
   for(a=0;a<sizeof(ppl);a++) {
      if(ppl[a]->query_level() < nmb && ppl[a]->query_level() > b &&
            ppl[a] != this_player())
      ppl[a]->force_us(what);
   }
   write("You have just forced those between "+b+" and "+nmb+" to\n");
   write(what+"\n");
   return 1;
}

room_tell(str) {
   object target, place;
   string target_nm, mess;
   if(!str) {
      write("That person is not here.");
      return 1; }
   if(sscanf(str, "%s %s", target_nm, mess) != 2) {
      write("Usage is: decho <target> <message>.\n");
      return 1; }
   target = find_living(lower_case(target_nm));
   if(!target) {
      write("That target not found.\n");
      return 1; }
   place = environment(target);
   tell_room(place, mess+"\n");
   return 1;
}

force_player(str) {
   string victim, what;
   object target;
   if(!str) { 
      write("Usage is: df <target> <command>.\n");
      return 1; }
   if(sscanf(str, "%s %s", victim, what) != 2) {
      write("Usage is: dforce <target> <command>.\n");
      return 1; }
   target=find_living(lower_case(victim));
   command(what, target);
   write("You have silently forced "+capitalize(victim)+" to "+what+".\n");
   return 1; }

move_inv(str) {
   object target;
   if(!str) {
      write("Usage is: 'din <target>'\n");
      return 1; }
   target=find_living(lower_case(str));
   if(!target) {
      write("No such target. Try again.\n");
      return 1; }
   move_object(this_player(), target);
   write("You have moved into "+capitalize(target->query_real_name())+".\n\n");
   return 1; }

power_get(str) {
   object target;
   if(!str) {
      write("Usage is: 'get! <target>'\n");
      return 1; }
   target=find_living(lower_case(str));
   if(!target) target=find_ob(str);
   if(!target) {
      write("That target not found.\n");
      return 1; }
   if(!present(target, environment(this_player()))) {
      write("Target not here.\n");
      return 1; }
   move_object(target, this_player());
   write(capitalize(str)+" has been moved into your inventory.\n");
   return 1; }

trans_object(str) {
   object target;
   string victim, place;
   if(!str) {
      write("Usage is: 'drans! <target> <destination>'\n");
      return 1; }
   if(sscanf(str, "%s %s", victim, place) != 2) {
      write("Try again. Usage: 'drans! <target> <destination>'\n");
      return 1; }
   target=find_living(lower_case(victim));
   if(!target) {
      write("That target not found.\n");
      return 1; }
   move_object(target, ""+place+"");
   write("You have silently move "+capitalize(victim)+" "+place+".\n");
   return 1; }

shout_to_players(str) {
   object ppl;
   int a;
   if(!str) {
      write("Usage is: 'dshp <comment>'\n");
      return 1; }
   ppl=users();
   for(a=0;a<sizeof(ppl);a++) {
      if(ppl[a]->query_level() < 20 && ppl[a] != this_player())
         tell_object(ppl[a], "\n"+str+"\n\n");
   }
   write("You have shouted to players: ("+str+")\n\n");
   return 1; }

shout_to_wizards(str) {
   object ppl;
   int a;
   if(!str) {
      write("Usage is: 'dshw <comment>'\n");
      return 1; }
   ppl=users();
   for(a=0;a<sizeof(ppl);a++) {
      if(ppl[a]->query_level() > 19 && ppl[a] != this_player() &&
            !ppl[a]->query_muffled() && !in_editor(ppl[a]))
      tell_object(ppl[a], "\n"+str+"\n\n");
   }
   write("You have shouted to wizards: ("+str+")\n\n");
   return 1; }

shout_to_players_2(str) {
   object ppl, target;
   string what, victim;
   int a;
   if(!str) {
      write("Usage is: 'dsp <victim> <comment>'\n");
      return 1; }
   if(sscanf(str, "%s %s", victim, what) < 2) {
      write("Try again. Usage: 'dsp <victim< <comment>'\n");
      return 1; }
   ppl=users();
   for(a=0;a<sizeof(ppl);a++) {
      if(ppl[a]->query_level() < 20 && ppl[a] != this_player() &&
            ppl[a]->query_real_name() != victim) 
      tell_object(ppl[a], what+"\n");
   }
   write("You have player-shouted: ("+what+"), but not to "+capitalize(victim)+"\n");
   return 1; }

shout_to_wizards_2(str) {
   object ppl, target;
   string what, victim;
   int a;
   if(!str) {
      write("Usage is: 'dsp <victim> <comment>'\n");
      return 1; }
   if(sscanf(str, "%s %s", victim, what) != 2) {
      write("Try again. Usage: 'dsp <victim< <comment>'\n");
      return 1; }
   ppl=users();
   for(a=0;a<sizeof(ppl);a++) {
      if(ppl[a]->query_level() > 20 && ppl[a] != this_player() &&
            !ppl[a]->query_muffled() && ppl[a]->query_real_name() != victim &&
         !in_editor(ppl[a]))
      tell_object(ppl[a], what+"\n");
   }
   write("You have player-shouted: ("+what+"), but not to "+capitalize(victim)+"\n");
   return 1; }

shout_to_players_3(str) {
   object ppl, target;
   string what, victim;
   int a;
   if(!str) {
      write("Usage is: 'dsp <victim> <comment>'\n");
      return 1; }
   if(sscanf(str, "%s %s", victim, what) < 2) {
      write("Try again. Usage: 'dsp <victim< <comment>'\n");
      return 1; }
   ppl=users();
   for(a=0;a<sizeof(ppl);a++) {
      if(!ppl[a]->query_muffled() && ppl[a] != this_player() &&
            ppl[a]->query_real_name() != victim && !in_editor(ppl[a]))
      tell_object(ppl[a], what+"\n");
   }
   write("You have player-shouted: ("+what+"), but not to "+capitalize(victim)+"\n");
   return 1; }

change_directory(str) {
   string tname, dir1, dir2;
   if(!str) {
      write("Usage is: 'work <wizard's name> <directory1> <directory2>'\n");
      return 1; }
   else if(sscanf(str, "%s", tname) == 1) {
      command("cd /players/"+tname, this_player());
      write("Working on "+capitalize(tname)+"'s realm.\n");
      return 1; }
   else if(sscanf(str, "%s/%s", tname, dir1) == 2) {
      command("cd /players/"+tname+"/"+dir1, this_player());
      write("Working on "+capitalize(tname)+"/"+dir1+".\n");
      return 1; }
   else if(sscanf(str, "%s/%s/%s", tname, dir1, dir2) == 3) {
      command("cd /players/"+tname+"/"+dir1+"/"+dir2, this_player());
      write("Working on "+capitalize(tname)+"/"+dir1+"/"+dir2+".\n");
      return 1; }
   else {
      write("Try again. Usage is: 'work <wizard's name> <directory1> <directory2>'\n");
      return 1; }
}

change_weight(str) {
   object target;
   string vict;
   int amt;
   if(!str) {
      write("Usage: 'dweight <target> <amount>'\n");
      return 1; }
   if(sscanf(str, "%s %d", vict, amt) != 2) {
      write("Usage: 'dweight <target> <amount>'\n");
      return 1; }
   target = find_living(lower_case(vict));
   target->add_weight(amt);
   write(capitalize(vict)+"'s weight/carry has been adjusted to "+amt+".\n");
   return 1;
}

wizard_list(str) {
   string people, sorter; int a;
   if(str != "lev" && str != "name") sorter = "lev";
   sorter = str;
   people = sort_list(users(), sorter);
   write("                        WIZARDS\n");
   write("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
   write("Name          Level   Status  Present Location\n");
   write("------------  ------  ------  ---------------------------------------\n");
   for(a = 0; a < sizeof(people); a++) {
      if(people[a]->query_level() > 19) {
         write(ladjust(people[a]->query_real_name(), 12)+"  ");
         write(ladjust(people[a]->query_level(), 7)+"  ");
         if(people[a]->query_muffled() == 1 && in_editor(people[a])
               && people[a]->query_invis() > 0)
         write(ladjust("*#@", 5)+"  ");
         else if(people[a]->query_muffled() == 1 && in_editor(people[a]))
            write(ladjust("*#", 5)+"  ");
         else if(in_editor(people[a]) && people[a]->query_invis() > 0)
            write(ladjust("#@", 5)+"  ");
         else if(people[a]->query_muffled() == 1 &&
               people[a]->query_invis() > 0)
         write(ladjust("*@", 5)+"  ");
         else if(people[a]->query_muffled() == 1)
            write(ladjust("*", 5)+"  ");
         else if(in_editor(people[a]))
            write(ladjust("#", 5)+"  ");
         else if(people[a]->query_invis() > 0)
            write(ladjust("@", 5)+"  ");
         else if(people[a]->query_muffled() != 1 && !in_editor(people[a])
               && people[a]->query_invis() == 0)
         write(ladjust("None", 5)+"  ");
         if(!file_name(environment(people[a])))
            write("unknown");
         else
            write(file_name(environment(people[a])));
         write("\n");
       }
   }
   write("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
   write("\n * = muffled, # = editing, @ = invisible\n");
   return 1;
}

#define ENV(obj) environment(obj)
sort_list(str, arg) {
   object tmp; int x, y, sorted;
   x = sizeof(str);
   if(!arg) arg = "lev";
   sorted = 0;
   while(!sorted) {
      sorted = 1; x--;
      for(y = 0; y < x; y++)
      if((arg == "lev" && 
               str[y]->query_level() < str[y+1]->query_level()) ||
         (arg == "name" &&
            str[y]->query_real_name() > str[y+1]->query_real_name())) {
         tmp = str[y]; str[y] = str[y+1]; str[y+1] = tmp;
         sorted = 0;
         }
   }
   return str;
}
#undef ENV

ladjust(str, n) { return extract(str+"                ",0,n-1); }

query_weight() { return 0 ; }

query_value() { return 0; }


players_list(str) {
   string people, sorter; int a;
   int fst, scd, bot, top;
   if(sscanf(str, "from %d to %d", fst, scd) == 2) {
      bot = fst - 1;
      top = scd + 1;
      sorter = "lev";
      people = sort_list(users(), sorter);
      write("                        PLAYERS\n");
      write("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
      write("Name          Level   Gender    Present Location\n");
      write("------------  ------  ------   --------------------------------------\n");
      for(a = 0; a < sizeof(people); a++) {
         if(people[a]->query_level() > bot && people[a]->query_level() < top) {
            write(ladjust(people[a]->query_real_name(), 12)+"  ");
            write(ladjust(people[a]->query_level(), 7)+"  ");
            write(ladjust(people[a]->query_gender(), 7)+"  ");
            if(!file_name(environment(people[a])))
               write("unknown");
            else
               write(file_name(environment(people[a])));
            write("\n");
          }
      }
      write("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
      return 1;
   }
   if(!sscanf(str, "from %d to %d", fst, scd)) {
      if(str != "name" && str != "lev") sorter = "lev";
      sorter = str;
      people = sort_list(users(), sorter);
      write("                        PLAYERS\n");
      write("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
      write("Name          Level   Gender   Present Location\n");
      write("------------  ------  -------  --------------------------------------\n");
      for(a = 0; a < sizeof(people); a++) {
         if(people[a]->query_level() < 20) {
            write(ladjust(people[a]->query_real_name(), 12)+"  ");
            write(ladjust(people[a]->query_level(), 7)+"  ");
            write(ladjust(people[a]->query_gender(), 7)+"  ");
            if(!file_name(environment(people[a])))
               write("unknown");
            else
               write(file_name(environment(people[a])));
            write("\n");
          }
      }
      write("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\n");
      return 1;
   }
}

