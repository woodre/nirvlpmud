inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc="Dem: Elven Track One";
long_desc="You are upon a track deep in the forest (oooohhh...scary!).\n";
dest_dir=({"players/demoder/elven/woods4", "east",
"players/demoder/elven/track2", "west" });
}
