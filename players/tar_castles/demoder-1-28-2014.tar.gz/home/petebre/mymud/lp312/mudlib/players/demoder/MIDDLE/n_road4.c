inherit "room/room";

reset(arg) {
 if(arg) return;
 set_light(1);
short_desc = "Middle Kingdom, North Road";
 long_desc = "You are upon the inner city's North Road. To the north is "+
  "the cityguards'\n"+
  "northern barracks. The road continues to the east and west.\n\n";
 dest_dir = ({ "players/demoder/MIDDLE/barrack1", "north",
  "players/demoder/MIDDLE/n_road3", "west",
  "players/demoder/MIDDLE/n_road5", "east" });
}
