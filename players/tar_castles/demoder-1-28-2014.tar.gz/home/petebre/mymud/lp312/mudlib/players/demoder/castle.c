#define NAME "Demoder"
#define DEST "room/jetty2"
/*
* This is just the facade to a castle. If you want to enable the
* "enter" command, move the player to a hall or something (which
   * you have to design yourself).
* The predefined string DEST is where a player should come when he
* leaves the castle.
*
* This file is loaded automatically from "init_file". We have to move
* ourself to where we are supposed to be.
*/

id(str) { return str == "rope" || str == "ladder"; }

short() {
   return "A rope ladder hanging down from the clouds..";
}

long() {
  write("A sturdy, rope ladder leading up into the clouds.\n");
   write("Although the wind is blowing violently, the ladder stays firm\n");
write("without seeming to be affected by the weather conditions. There\n");
write("seems to be nothing connecting it to the ground.\n");
write("\nYou can go `up' or `climb'.\n");
}

init() {
   add_action("climb", "climb");
   add_action("climb", "up");
}

climb() {
   write("Sorry. This castle is now closed for demolishing.\n");
   write("Construction of a new castle will follow soon (hopefully).\n");
   write("\n");
   return 1;
}

reset(arg) {
   if (arg)
      return;
   move_object(this_object(), DEST);
}
is_castle(){return 1;}
