inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
   set_name("sword");
   set_alt_name("sword");
   set_alias("weapon");
   set_short("Sword of Angels");
   set_long("This is the sword you recieved for fighting the warriors on\n" +
      "the island of darkness.  With your victory you gained great power with\n" +
      "the angels.  Type 'help angel' for commands.\n");
   set_class(19);
   set_weight(3);
   set_value(20000);
   set_heart_beat(1);
   set_hit_func(this_object());
}

init() {
   ::init();
   add_action("wmess", "wield");
}

weapon_hit(attacker){
   object user;
   user = environment(this_object());
   if (random (100) < 30) {
      write("The angels sing as you slice " + capitalize(attacker->query_name()) + ".\n");
      say("Angels sing as " + capitalize(this_player()->query_name())+ " uses the power of his sword.\n");
      return(random(6)+3);
   }
   write("Your attacker is:" + attacker->query_name()+"\n\n");
   if(user && attacker->query_hp() <100) {
      attacker->hit_player(80);
      user->add_spell_point(-20);
      tell_object(user,
         "A circle of 13 angels descend and fire blue light at " +
         attacker->query_name() + "\n" +
         "causing an instant but painful death.\n\n" +
         "The angels turn and look at you for a moment, then each acends back\n" +
         "into heaven  as they pass and touch your bloody sword.\n");
      return 25;
   }
}

wmess(str) {
   if(!id(str)) return 0;
   if(environment() != this_player()) return 0;
   if(wielded) {
      write("You already wield it!\n");
      return 1;
   }
   if(wield_func) 
      if(!call_other(wield_func, "wield", this_object()))
      return 1;
   call_other(this_player(), "wield", this_object());
   wielded = 1;
   wielded_by = this_player();
   write("You feel the power of the angels watching over you!\n");
   return 1;
}
