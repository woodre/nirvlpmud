inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoz Castle Storeroom";
   long_desc = "You are in a storeroom. Various useless objects are lying\n"+
   "about in anunorderly fashion.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/castle/hallway1", "north"});
}
