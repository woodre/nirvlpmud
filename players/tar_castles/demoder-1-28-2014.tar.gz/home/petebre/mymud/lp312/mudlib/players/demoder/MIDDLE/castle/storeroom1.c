inherit "room/room";
int ss;

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc = "Demoz Castle Storeroom";
   long_desc = "You are in a dusty storeroom. It looks like no one's\n"+
   "been in here for a long time.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/castle/hallway1", "south"});
   ss = 1;
}

init() {
   ::init();
   add_action("search", "search");
   add_action("down", "down");
}

search() {
   if(ss == 1) {
      write("You find a secret passage leading down!!\n\n");
      dest_dir = ({"players/demoder/MIDDLE/castle/hallway1", "south",
            "players/demoder/MIDDLE/castle/passage", "down"});
      this_player()->look();
      ss = 0;
      return 1;
   }
   ss = 1;
   write("You find nothing interesting.\n");
   return 1;
}

down() {
   if(ss != 1) return;
   this_player()->move_player("down#players/demoder/MIDDLE/castle/passage");
   return 1;
}
