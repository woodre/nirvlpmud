#define  part_room "/players/demoder/MIDDLE/castle/hallway14.c"
inherit "room/room";
object b_type, key_ob, d_door;
object part_door;
string a_type;
int door, lock;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "The Red Room";
   long_desc = "You are in the Red Advisor's room. You see a desk in the \n"+
   "southeast corner cluttered with various scrolls and documents. There are\n"+
   "curious paintings adorning the walls. There are also shelves filled with\n"+
   "leather-bound books on the east and west walls. There is a door here \n"+
   "leading north.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/castle/hallway14", "north"});
   if(!present("door")) {
      d_door = move_object(clone_object("players/demoder/obj/d_door"), this_object());
      d_door->set_dlong("A blood-red door with intricate carvings.");
   }
   door = 1; lock = 1;
}

set_closed(y) { door = y; }
query_closed() { return door; }

set_locked(x) { lock = x; }
query_locked() { return lock; }

init() {
   ::init();
   add_action("lock", "lock");
   add_action("unlock", "unlock");
   add_action("open", "open");
   add_action("close", "close");
   add_action("north", "north");
}

north() {
   if(door == 1) {
      write("The door is closed.\n");
      return 1;
   }
   if(door == 0) {
      this_player()->move_player("north#/players/demoder/MIDDLE/castle/hallway14");
      return 1;
   }
}

unlock(str) {
   if(!str) {
      write("Unlock what?\n");
      return 1;
   }
   if(sscanf(str, "door with %s key", a_type) == 1) {
      b_type = present(a_type+" key", this_player());
      if(!b_type) {
         write("You do not have that!\n");
         return 1;
      }
      if(b_type->query_code() != "red_advisor") {
         write("That key does not fit!\n");
         return 1;
      }
      if(lock == 0) {
         if(door == 0) {
            write("The door is standing wide open.\n");
            return 1;
         }
         write("The door is already unlocked.\n");
         return 1;
      }
      write("You unlock the door.\n");
      say(capitalize(this_player()->query_name())+" unlocks the door.\n");
      lock = 0;
      part_room->set_locked(0);
      return 1;
   }
   write("Unlock door with what key?\n");
   return 1;
}

lock(str) {
   if(!str) {
      write("Lock what?\n");
      return 1;
   }
   if(sscanf(str, "door with %s key", a_type) == 1) {
      b_type = present(a_type+" key", this_player());
      if(!b_type) {
         write("You do not have that.\n");
         return 1;
      }
      if(b_type->query_code() != "red_advisor") {
         write("That is not the correct key.\n");
         return 1;
      }
      if(door == 0) {
         write("The door is not closed yet.\n");
         return 1;
      }
      if(lock == 1) {
         write("The door is already locked.\n");
         return 1;
      }
      write("You lock the door.\n");
      say(capitalize(this_player()->query_name())+" locks the door -- Klick!\n");
      lock = 1;
      part_room->set_locked(1);
      return 1;
   }
   write("Lock the door with what?\n");
   return 1;
}

open(str) {
   if(str != "door") return 0;
   if(door == 0) {
      write("The door is already open.\n");
      return 1;
   }
   if(lock == 1) {
      write("The door is locked. You must unlock it first.\n");
      return 1;
   }
   write("You open the door.\n");
   say(capitalize(this_player()->query_name())+" opens the door.\n");
   door = 0;
   part_room->set_closed(0);
   if(present("door")) d_door->set_dclosed(0);
   inv_part_room();
   if(part_door) part_door->set_dclosed(0);
   return 1;
}

close(str) {
   if(str != "door") return 0;
   if(door == 1) {
      write("The door is already closed.\n");
      return 1;
   }
   write("You close the door.\n");
   say(capitalize(this_player()->query_name())+" closes the door.\n");
   door = 1;
   part_room->set_closed(1);
   if(present("door")) d_door->set_dclosed(1);
   inv_part_room();
   if(part_door) part_door->set_dclosed(1);
   return 1;
}

inv_part_room() {
   object obs, next_obs;
   obs = first_inventory(part_room);
   while(obs) {
      if(obs->id("door")) part_door = obs;
       obs = next_inventory(obs);
   }
}
