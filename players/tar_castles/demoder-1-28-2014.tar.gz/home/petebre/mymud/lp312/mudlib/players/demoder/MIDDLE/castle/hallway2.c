inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are in a long hallway stretching east and west.\n"+
"There is a room to the north.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway2a", "north",
"players/demoder/MIDDLE/castle/castle_entrance", "east",
"players/demoder/MIDDLE/castle/hallway4", "west"});
}
