inherit "obj/armor";

reset(arg) {
   ::reset(arg);
   set_name("ethereal cloak");
   set_type("misc");
   set_alias("cloak");
   set_short("An ethereal cloak");
   set_long("An ethereal cloak. It seems to waver and shift in the light.\n");
   set_ac(1);
   set_value(1000);
   set_weight(1);
}
