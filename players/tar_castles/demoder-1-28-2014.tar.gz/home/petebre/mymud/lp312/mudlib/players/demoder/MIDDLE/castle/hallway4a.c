inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Storeroom";
long_desc = "You are in a well-used storeroom. There isn't much here \n"+
"but various things that the castle servants would need.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway4", "north"});
move_object(clone_object("players/demoder/obj/broom"), this_object());
move_object(clone_object("players/demoder/obj/dustpan"), this_object());
move_object(clone_object("players/demoder/obj/lantern"), this_object());
move_object(clone_object("players/demoder/obj/wooden_key"), this_object());
}
