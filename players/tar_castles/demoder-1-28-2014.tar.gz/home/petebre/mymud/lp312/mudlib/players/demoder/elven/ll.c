inherit "obj/treasure";

reset(arg) {
if(arg) return;
set_id("tester");
set_short("tester");
set_long("tester");
set_weight(1);
set_value(10);
}

init() {
::init();
add_action("room_tell", "troom");
}

room_tell(str) {
if(!str) return;
tell_room("room/church", str+"\n");
return 1; }
