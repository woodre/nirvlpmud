inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Dem: MIDDLE Order-to-go";
long_desc =
"You are in the inner city's order-to-go - fast foods and drinks - center.\n"+
"You see a sign over the counter which says:\n"+
"\n            WE RESERVE THE RIGHT TO CHANGE PRICES\n\n"+
"         1. Nuts                   300 coins\n"+
"         2. Poboy                  600 coins\n"+
"         3. Chicken(20 pieces)     900 coins\n"+
"         4. Basket of Goodies     1200 coins\n"+
"         5. Local Ale              65 coins\n"+
"         6. Special of the House  100 coins\n"+
"         7. Dragon's Breath       175 coins\n\n";
dest_dir = ({ "players/demoder/MIDDLE/s_road2", "north" });
items = ({ "counter", "a normal-looking counter often seen in fast-food places" });
}

init() {
add_action("order", "order");
add_action("order", "buy");
::init();
}

order(str) {
object nuts, poboy, chicken, basket, ale, special, flame;
object who;
string who_name, sorry, carry;
int who_coin;
   who = this_player();
   who_name = this_player()->query_real_name();
   who_coin = this_player()->query_money();
   sorry = "Sorry, but you must have the money to buy first.\n";
   carry = "You can't carry that much";
   if(!str) {
    write("What would you like to order?(Please look at takeout sign.)\n");
    return 1;
    }
   if(str == "nuts" || str == "1") {
      if(who_coin < 300) {
         write(sorry);
         return 1;
      }
      nuts = clone_object("players/demoder/obj/nuts");
      if(!who->add_weight(nuts->query_weight())) {
         write(carry);
         return 1;
      }
      move_object(nuts, who);
      who->add_money(-300);
      write("You order some nuts.\n");
      say(capitalize(who_name)+" orders some nuts to go.\n");
      return 1;
   }
   else if(str == "po-boy" || str == "poboy" ||
           str == "2") {
      if(who_coin < 600) {
         write(sorry);
         return 1;
        }
      poboy = clone_object("players/demoder/obj/poboy");
      if(!who->add_weight(poboy->query_weight())) {
         write(carry);
         return 1;
       }
      move_object(poboy, who);
      who->add_money(-600);
      write("You order a foot-long po-boy.\n");
      say(capitalize(who_name)+" orders a foot-long po-boy to go.\n");
      return 1;
   }
   else if(str == "chicken" || str == "3") {
      if(who_coin < 900) {
         write(sorry);
         return 1;
       }
      chicken = clone_object("players/demoder/obj/chicken");
      if(!who->add_weight(chicken->query_weight())) {
         write(carry);
         return 1;
       }
      move_object(chicken, who);
      who->add_money(-900);
      write("You order 20 pieces of chicken to go.\n");
      say(capitalize(who_name)+" orders 20 pieces of chicken to go.\n");
      return 1;
   }
   else if(str == "basket" || str == "4") {
      if(who_coin < 1200) {
         write(sorry);
         return 1;
      }
      basket = clone_object("players/demoder/obj/basket");
      if(!who->add_weight(basket->query_weight())) {
         write (carry);
         return 1;
     }
      move_object(basket, who);
      who->add_money(-1200);
      write("You order a basket full of goodies.\n");
      say(capitalize(who_name)+" orders a basket full of goodies to go.\n");
      return 1;
   }
   else if(str == "ale" || str == "5") {
      if(who_coin < 65) {
         write(sorry);
         return 1;
      }
      ale = clone_object("players/demoder/obj/ale");
      if(!who->add_weight(ale->query_weight())) {
         write(carry);
         return 1;
       }
      move_object(ale, who);
      who->add_money(-65);
      write("You order a bottle of ale to go.\n");
      say(capitalize(who_name)+" orders a bottle of ale to go.\n");
      return 1;
   }
   else if(str == "special" || str == "6") {
      if(who_coin < 100) {
         write(sorry);
         return 1;
       }
      special = clone_object("players/demoder/obj/special");
      if(!who->add_weight(special->query_weight())) {
         write(carry);
         return 1;
      }
      move_object(special, who);
      who->add_money(-100);
      write("You order a bottle of the pub's special to go.\n");
      say(capitalize(who_name)+" orders a bottle of the pub's special to go.\n");
      return 1;
   }
   else if(str == "flame" || str == "7") {
      if(who_coin < 175) {
         write(sorry);
         return 1;
     }
      flame = clone_object("players/demoder/obj/flame");
      if(!who->add_weight(flame->query_weight())) {
         write(carry);
         return 1;
      }
      move_object(flame, who);
       who->add_money(-175);
      write("You order a bottle of Dragon's Flame to go.\n");
      say(capitalize(who_name)+" orders a bottle of Dragon's Flame to go.\n");
      return 1;
   }
   else {
      write("What would you like to order? (Please read sign.)\n");
      return 1;
   }
}
