inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are in a long hallway. The hallway continues to the south\n"+
"and curves westward to the north.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway5", "north",
"players/demoder/MIDDLE/castle/hallway9", "south"});
}
