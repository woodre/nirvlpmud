inherit "room/room";
object guard, s1, l1;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Dem: Demoz Castle Guardroom";
   long_desc = "You are in one of the guardrooms of the castle. Perhaps\n"+
   "you should leave before someone decides to notice you.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/castle/hallway3", "south"});
   for(a = 0; a < 4; a++) {
      guard = clone_object("players/demoder/mon/guard");
      move_object(guard, this_object());
   }
   s1 = move_object(clone_object("players/demoder/mon/s_guard"), this_object());
   l1 = move_object(clone_object("players/demoder/mon/l_guard"), this_object());
}
