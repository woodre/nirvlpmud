inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are standing in a hallway that stretches east and west.\n"+
"There is a room to the south.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway2", "east",
"players/demoder/MIDDLE/castle/hallway6", "west",
"players/demoder/MIDDLE/castle/hallway4a", "south"});
}
