inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoz Castle Entrance";
   long_desc = "You are standing in a hallway leading east and west.\n"+
   "There is an arch which you can pass through south. The\n"+
   "draw-bridge lies to the north.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/castle/hallway1", "east",
         "players/demoder/MIDDLE/castle/hallway2", "west",
         "players/demoder/MIDDLE/castle/arch1", "south",
         "players/demoder/MIDDLE/draw_bridge", "north"});
}
