inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, East Road";
long_desc = "You are upon the inner city's East Road. To the north you see "+
 "the Northeastern\n"+
 "Square. The road continues south.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/ne_square", "north",
 "players/demoder/MIDDLE/e_road2", "south" });
}
