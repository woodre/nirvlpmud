inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Hallway";
long_desc = "You are in a long hallway. There is an arch to the northeast\n"+
"that leads into a tower. The hallway continues to the west and south.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/ne_tower", "northeast",
"players/demoder/MIDDLE/castle/hallway3", "west",
"players/demoder/MIDDLE/castle/hallway7", "south"});
}
