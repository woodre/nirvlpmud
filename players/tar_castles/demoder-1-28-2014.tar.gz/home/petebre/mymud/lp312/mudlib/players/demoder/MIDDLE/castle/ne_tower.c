inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoz Castle Northeast Tower";
long_desc = "You are on the first floor of the northeast tower of the castle.\n"+
"There is are stairs leading up and the castle hallway lies to the southwest.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/ne_tower2", "up",
"players/demoder/MIDDLE/castle/hallway5", "southwest"});
}
