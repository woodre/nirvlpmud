inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc="Dem: Elven Woods";
long_desc="You are deep in the woods among towering trees. To your north "+
"is the way\n"+
"back. A path leads further south into the forest. The light seems to be\n"+
"getting dimmer.\n\n";
dest_dir=({"players/demoder/elven/woods1", "north",
"players/demoder/elven/woods3", "south"});
}
