inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, West Road";
long_desc = "You are upon the West Road of the inner city. You see the "+
 "local pub to the\n"+
 "west. To the east you see the western wall of the castle and the\n"+
 "moat surrounding it. The road continues to the north and south.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/pub", "west",
 "players/demoder/MIDDLE/w_road3", "north",
 "players/demoder/MIDDLE/w_road1", "south" });
}
