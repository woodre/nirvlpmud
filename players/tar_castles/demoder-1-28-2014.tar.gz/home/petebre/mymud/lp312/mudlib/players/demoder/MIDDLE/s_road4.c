inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Middle Kingdom, South Road";
long_desc = "You are upon the inner city's South Road. To the south you see "+
 "the Southern\n"+
 "Barracks. The road continues east and west.\n\n";
dest_dir = ({ "players/demoder/MIDDLE/s_road5", "west",
 "players/demoder/MIDDLE/barrack2", "south",
 "players/demoder/MIDDLE/s_road3", "east" });
}
