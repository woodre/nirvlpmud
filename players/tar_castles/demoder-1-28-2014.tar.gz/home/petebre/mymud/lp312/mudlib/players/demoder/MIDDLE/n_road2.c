inherit "room/room";

reset(arg) {
 if(arg) return;
 set_light(1);
 short_desc = "Middle Kingdom, North Road";
 long_desc = "You are upon the inner city's North Road. To the south you "+
  "see the \n"+
  "the moat surrounding the castle. To the north is the city's Magic Shop.\n"+
  "The road continues east and west.\n\n";
 dest_dir = ({ "players/demoder/MIDDLE/magic.c", "north",
  "players/demoder/MIDDLE/n_road1", "west",
  "players/demoder/MIDDLE/n_road3", "east" });
}
