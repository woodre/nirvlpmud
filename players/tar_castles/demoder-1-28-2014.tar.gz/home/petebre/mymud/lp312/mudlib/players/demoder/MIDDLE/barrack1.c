inherit "room/room";
object guard, l_guard, s_guard;
int a, i;

reset(arg) {
 if(arg) return;
 set_light(1);
 a = 0;
 i = 0;
 if(!present("guard")) {
 while(i<12) {
  guard=clone_object("players/demoder/mon/guard");
  move_object(guard, this_object());
  i += 1;
}
 while(a<3) {
  s_guard=clone_object("players/demoder/mon/s_guard");
  move_object(s_guard, this_object());
  a += 1;
 }
  l_guard=clone_object("players/demoder/mon/l_guard");
  move_object(l_guard, this_object());
 }
 short_desc = "Dem: MIDDLE Barracks One";
 long_desc = "You are in the northern barracks. It seems as though the "+
  "guards here\n"+
  "do not enjoy your presence. The armory is to the east. The way out is\n"+
  "to the south.\n\n";
 dest_dir = ({ "players/demoder/MIDDLE/armory1", "east",
  "players/demoder/MIDDLE/n_road4", "south" });
}

init() {
  ::init();
  add_action("east", "east");
}

east() {
  if(present("guard")) {
   write("The guard bars your way.\n");
   write("The guard glares at you.\n\n");
   return 1;
  }
  else if(!present("guard") && present("sergeant")) {
   write("The sergeant bars your way.\n");
   write("The sergeant glares at you.\n\n");
   return 1;
  }
  else if(!present("guard") && !present("sergeant") && present("lieutenant")) {
   write("The lieutenant bars your way.\n");
   write("The lieutenant says: Guards only! Stay out!\n\n");
   return 1;
  }
  else {
   this_player()->move_player("east#players/demoder/MIDDLE/armory1");
   return 1;
   }
}
