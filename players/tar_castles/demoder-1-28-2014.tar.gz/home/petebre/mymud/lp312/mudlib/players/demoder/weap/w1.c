inherit "obj/weapon";

reset(arg) {
   ::reset(arg);
   set_name("ethereal sword");
   set_alias("sword");
   set_short("An ethereal sword");
   set_long("An ethereal sword. It seems to reflect the light strangely.\n");
   set_class(random(6)+11);
   set_value(2500);
   set_weight(1);
   set_hit_func(this_object());
}

weapon_hit(attacker) {
   if(random(101) > 79) {
      write("\nThe ethereal sword glows dimly and quickly lashes out!!\n\n");
      return random(11)+10;
   }
}
