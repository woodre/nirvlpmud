inherit "room/room";

reset(arg) {
if(arg) return;
set_light(0);
short_desc = "Demoz Castle Storeroom";
long_desc = "You are in an old, musty storeroom. There doesn't seem to be\n"+
"much here, but then again, you never know till you try.\n\n";
dest_dir = ({"players/demoder/MIDDLE/castle/hallway2", "south"});
}

init() {
::init();
add_action("search", "search");
}

search() {
int xx, yy;
object bag, cc;
yy = 0;
xx = 0;
if(yy == 1) {
write("You search around but find nothing.\n");
return 1; 
}
if(yy != 1 && xx != 3) {
write("You look around but find nothing interesting.\n");
xx += 1;
return 1;
}
if(yy != 1 && xx != 3) {
write("You continue to search vigorously and at last your search \n");
write("has payed off. You find a bag under all the dust.\n");
bag = clone_object("obj/bag");
cc = clone_object("obj/money");
cc->set_money(random(1000)+250);
move_object(cc, bag);
move_object(bag, this_object());
yy = 1;
return 1;
}
}
