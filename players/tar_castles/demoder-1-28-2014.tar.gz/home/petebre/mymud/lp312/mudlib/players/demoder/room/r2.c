inherit "room/room";
object guard;

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Test Room 2";
long_desc = "This is the second testing room.\n\n";
dest_dir = ({"players/demoder/room/r1.c", "south",
  "players/demoder/room/r3.c", "north"});
set_heart_beat(1);
if(!present("ethereal guard")) {
guard = clone_object("players/demoder/mon/m1.c");
move_object(guard, this_object());
}
}

heart_beat() {
