inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoz City Northeast Tower";
   long_desc = "You are in the first level of the Northeast Tower. There is\n"+
   "a circular staircase leading up and a door to the east. The way out\n"+
   "is to the southwest.\n\n";
   dest_dir = ({"players/demoder/MIDDLE/ne_square", "southwest",
         "players/demoder/MIDDLE/ne_tower1a", "east",
         "players/demoder/MIDDLE/ne_tower2", "up"});
}
