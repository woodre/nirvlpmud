inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="Dem: Elven Woods";
   long_desc="You are in a dark wooded area. Little light penetrates the "+
   "thick foliage\n"+
   "of the surrounding tall, majestic trees. A path leads northwest into a\n"+
   "lighter area. The same path continues south deeper into the woods.\n\n";
   dest_dir=({"players/demoder/room/forest1", "northwest",
         "players/demoder/elven/woods2", "south"});
}
