inherit "room/room";

reset(arg) {
if(arg) return;
set_light(1);
short_desc = "Demoder: First Holte Tree - Corridor";
long_desc = "You are in a dark corridor of the huge tree. Impossible as it\n"+
"may seem, the inside appears larger than without. Behind you is, what seems\n"+
"to be, the interior bark of the tree. The light is poor here.\n"+
"The corridor continues to the east.\n";
dest_dir = ({"players/demoder/elven/tree1a", "east"});
}
