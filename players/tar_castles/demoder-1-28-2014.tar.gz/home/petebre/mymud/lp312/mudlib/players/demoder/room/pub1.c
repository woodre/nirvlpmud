object nuts, poboy, chicken, basket, ale, special, flame;
object who;
string who_name, sorry, carry, mess, type;
int heal, strt, cost;
int who_coin;

reset(arg) {
   if (arg) return;
   set_light(1);
}

short() {
   return "Demoder: Dragon's Den Pub"; }

long() {
   write("You enter the cave and discover that it is actually a pub carved\n"+
      "right out of the cliffside. You are astonished by the number of patrons\n"+
      "that grace this place.\n");
   write("A huge sign over the bar states:\n");
   write("           The Dragon's Den               \n");
   write("WE RESERVE THE RIGHT TO CHANGE PRICES AT ANYTIME.\n");
   write("You may order the following drinks here:\n\n");
   write("       1. Milk                 25 coins\n");
   write("       2. Goat Milk            50 coins\n");
   write("       3. Local Beer           40-100 coins\n");
   write("       4. Local Gin            80-140 coins\n");
   write("       5. Local Ale           120-180 coins\n");
   write("       6. Whiskey             180-280 coins\n");
   write("       7. The Den's Special   198-288 coins\n");
   write("       8. Dragon's Breath     208-361 coins\n");
   write("       9. Dragon's Flame      210-400 coins\n");
   write("\nFor a list of takeout items type `takeout'.\n\n");
   write("      There is one obvious exit:  south\n");
   return 1;
}

init() {
   add_action("order", "order");
   add_action("order", "buy");
   add_action("take_out", "takeout");
   add_action("order_two", "order2");
   add_action("order_two", "buy2");
   add_action("south", "south");
}

take_out() {
   write("You may order the following to bring along with you in\n");
   write("your travels:\n\n");
   write("      10. Walnuts and Pecans  300 coins\n");
   write("      11. Foot-long Po-boy    600 coins\n");
   write("      12. 20-piece Chicken   1000 coins\n");
   write("      13. Basket             1300 coins\n");
   write("      14. Ale in bottle       200 coins\n");
   write("      15. Special in bottle   360 coins\n");
   write("      16. Flame in bottle     600 coins\n");
   write("To order type `buy2(order2) #(name)'.\n\n");
   return 1;
}

south() {
   write("Have a nice day. And please come back.\n");
   this_player()->move_player("south#players/demoder/room/room7a");
   return 1;
}

order(str) {
   who = this_player();
   who_name = this_player()->query_real_name();
   who_coin = this_player()->query_money();
   sorry = "Sorry, but you must have the money in order to buy.\n";
   carry = "You can not carry that much.\n";
   if(!str) {
      write("You must say what you would like to order. You can use the #'s.\n");
      return 1;
   }
   if(str == "1" || str == "milk") {
      type = "a glass of milk";
      mess = "You drink milk and hear a voice in your head that says:\n"+
      "Milk. It does your body good...You smile.\n";
      strt = -2;
      heal = 0;
      cost = 25;
   }
   else if(str == "2" || str == "goat milk") {
      type = "a glass of goat milk";
      mess = "You order some goat milk. Wow! You feel invigorated!\n";
      strt = -4;
      heal = 0;
      cost = 50;
   }
   else if(str == "3" || str == "beer") {
      type = "a mug of beer";
      mess = "You order a mug of beer. It's it and that's that!\n";
      strt = 2;
      heal = random(4) + 2;
      cost = heal*20;
   }
   else if(str == "4" || str == "gin") {
      type = "a shot of gin";
      mess = "You quickly swallow your shot of gin. You feel much hotter now.\n";
      strt = 3;
      heal = random(4) + 4;
      cost = heal*20;
   }
   else if(str == "5" || str == "ale") {
      type = "a mug of ale";
      mess = "You order the local ale. It actually tastes decent.\n";
      strt = 4;
      heal = random(4) + 6;
      cost = heal*20;
   }
   else if(str == "6" || str == "whiskey") {
      type = "a shot of whiskey";
      mess = "You find the taste of whiskey pleasing though it leaves you"+
      " buzzed.\n";
      strt = 6;
      heal = random(5) + 9;
      cost = heal*20;
   }
   else if(str == "7" || str == "special") {
      type = "a glass of the pub's special";
      mess = "You order a special. Your are soaring among the clouds.\n";
      strt = 7;
      heal = random(7) + 11;
      cost = heal*18;
   }
   else if(str == "8" || str == "breath") {
      type = "a cup of Dragon's Breath";
      mess = "You order a Dragon's Breath. The drink burns as it goes down\n"+
      "your throat. It flares your guts.\n";
      strt = 11;
      heal = random(13)+16;
      cost = heal*13;
   }
   else if(str == "9" || str == "flame") {
      type = "an ounce of Dragon's Flame";
      mess = "You order a Dragon's Flame. The amount of alcohol you consume\n"+
      "knocks you off your feet. You feel dazed...almost unconscious.\n";
      strt = 14;
      heal = random(20)+21;
      cost = heal*10;
   }
   else {
      write("What would you like to order? (Please read sign.)\n\n");
      return 1;
   }
   if(who_coin < cost) {
      write(sorry);
      return 1;
   }
   if(strt > this_player()->query_level() + 2) {
      if(strt > this_player()->query_level() + 4) {
         say(capitalize(who_name)+" orders "+type+", tries to down it,\n"+
            "but instead vomits it all over the bar.\n"+
            "The barkeeper gives "+capitalize(who_name)+" a withering glance "+
            "and quickly wipes up the mess.\n");
         write("You order "+type+", try to down it, but instead\n"+
            "throw it up all over the bar.\n"+
            "The barkeeper gives you a withering look and cleans up the mess.\n");
         return 1;
      } else {
         say(capitalize(who_name)+" orders "+type+", tries to gulp it,\n"+
            "but instead sputters it all over the bar and its patrons.\n"+
            "Everyone looks at "+capitalize(who_name)+" with disgust.\n");
         write("You order "+type+", try to gulp it all at once,\n"+
            "and end up sputtering it all over the bar and its patrons.\n"+
            "Everyone looks at you in disgust.\n");
         return 1;
      }
      who->add_money(-cost);
      return 1;
   }
   if(!who->drink_alcohol(strt)) {
      say(capitalize(who_name)+" tries to order "+type+",\n"+
         "but the barkeeper refuses.\n");
      write("You try to order "+type+", but the barkeeper refuses.\n");
      return 1;
   }
say(capitalize(who_name)+" orders "+type+".\n\n");
   write("You order "+type+" and feel really happy.\n");
   write(mess);
   who->add_hit_point(heal);
   who->add_spell_point(heal);
   who->add_money(-cost);
   return 1;
}

order_two(str) {
   who = this_player();
   who_name = this_player()->query_real_name();
   who_coin = this_player()->query_money();
   sorry = "Sorry, but you must have the money to buy first.\n";
   carry = "You can't carry that much";
   if(!str) {
    write("What would you like to order?(Please look at takeout sign.)\n");
    return 1;
    }
   if(str == "walnuts" || str == "pecans" ||
      str == "10") {
      if(who_coin < 300) {
         write(sorry);
         return 1;
      }
      nuts = clone_object("players/demoder/obj/nuts");
      if(!who->add_weight(nuts->query_weight())) {
         write(carry);
         return 1;
      }
      move_object(nuts, who);
      who->add_money(-300);
      write("You order some nuts.\n");
      say(capitalize(who_name)+" orders some nuts to go.\n");
      return 1;
   }
   else if(str == "po-boy" || str == "poboy" ||
           str == "11") {
      if(who_coin < 600) {
         write(sorry);
         return 1;
        }
      poboy = clone_object("players/demoder/obj/poboy");
      if(!who->add_weight(poboy->query_weight())) {
         write(carry);
         return 1;
       }
      move_object(poboy, who);
      who->add_money(-600);
      write("You order a foot-long po-boy.\n");
      say(capitalize(who_name)+" orders a foot-long po-boy to go.\n");
      return 1;
   }
   else if(str == "chicken" || str == "12") {
      if(who_coin < 1000) {
         write(sorry);
         return 1;
       }
      chicken = clone_object("players/demoder/obj/chicken");
      if(!who->add_weight(chicken->query_weight())) {
         write(carry);
         return 1;
       }
      move_object(chicken, who);
      who->add_money(-1000);
      write("You order 20 pieces of chicken to go.\n");
      say(capitalize(who_name)+" orders 20 pieces of chicken to go.\n");
      return 1;
   }
   else if(str == "basket" || str == "13") {
      if(who_coin < 1300) {
         write(sorry);
         return 1;
      }
      basket = clone_object("players/demoder/obj/basket");
      if(!who->add_weight(basket->query_weight())) {
         write (carry);
         return 1;
     }
      move_object(basket, who);
      who->add_money(-1300);
      write("You order a basket full of goodies.\n");
      say(capitalize(who_name)+" orders a basket full of goodies to go.\n");
      return 1;
   }
   else if(str == "ale" || str == "14") {
      if(who_coin < 200) {
         write(sorry);
         return 1;
      }
      ale = clone_object("players/demoder/obj/ale");
      if(!who->add_weight(ale->query_weight())) {
         write(carry);
         return 1;
       }
      move_object(ale, who);
      who->add_money(-200);
      write("You order a bottle of ale to go.\n");
      say(capitalize(who_name)+" orders a bottle of ale to go.\n");
      return 1;
   }
   else if(str == "special" || str == "15") {
      if(who_coin < 350) {
         write(sorry);
         return 1;
       }
      special = clone_object("players/demoder/obj/special");
      if(!who->add_weight(special->query_weight())) {
         write(carry);
         return 1;
      }
      move_object(special, who);
      who->add_money(-350);
      write("You order a bottle of the pub's special to go.\n");
      say(capitalize(who_name)+" orders a bottle of the pub's special to go.\n");
      return 1;
   }
   else if(str == "flame" || str == "16") {
      if(who_coin < 600) {
         write(sorry);
         return 1;
     }
      flame = clone_object("players/demoder/obj/flame");
      if(!who->add_weight(flame->query_weight())) {
         write(carry);
         return 1;
      }
      move_object(flame, who);
     who->add_money(-600);
      write("You order a bottle of Dragon's Flame to go.\n");
      say(capitalize(who_name)+" orders a bottle of Dragon's Flame to go.\n");
      return 1;
   }
   else {
      write("What would you like to order? (Please read sign.)\n");
      return 1;
   }
}
