inherit "room/room";
object g1, g2, g3;
int ss;

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc = "Demoder: First Holte Tree - Corridor";
   long_desc = "The corridor of the tree ends abruptly to the east ahead, for\n"+
   "you can discern a peculiar light source, brighter than the one illuminating\n"+
   "the corridor, coming from up ahead to the east.\n\n";
   dest_dir = ({"players/demoder/elven/tree1a", "west",
         "players/demoder/elven/tree1c", "east"});
}

init() {
   ::init();
   add_action("east", "east");
}

east() {
   if(this_object()->query_trigger() != 1) {
      this_player()->move_player("east#players/demoder/elven/tree1c");
      return 1; }
   this_player()->move_player("east#players/demoder/elven/tree1c");
   g1 = clone_object("players/demoder/mon/elfguard");
   move_object(g1, "players/demoder/elven/tree1c");
   g2 = clone_object("players/demoder/mon/elfguard");
   move_object(g2, "players/demoder/elven/tree1c");
   g3 = clone_object("players/demoder/mon/elfguard");
   move_object(g3, "players/demoder/elven/tree1c");
   tell_room("players/demoder/elven/tree1c", 
      "Elf guards jump out to challenge you!\n");
   tell_room("players/demoder/elven/tree1c",
      "Elf guard yells: How dare you invade the Sacred Holte!!\n");
   set_trigger(1);
   return 1;
}

set_trigger(m) { ss = m; }

query_trigger() { return ss; }
