#include "../define.h"
#define ROOT_DIR "/players/vertebraker/swamp/"
#define OBJ_DIR ROOT_DIR+"OBJ/"
#define NPC_DIR ROOT_DIR+"NPC/"
#define ROOM_DIR ROOT_DIR+"ROOMS/"
#define SWAMP "/players/vertebraker/swamp/std/room.c";
#define ROOMS ROOT_DIR+"ROOMS/"
#define VILLAGE ROOT_DIR+"village/"
#define FOREST ROOT_DIR+"forest/"
