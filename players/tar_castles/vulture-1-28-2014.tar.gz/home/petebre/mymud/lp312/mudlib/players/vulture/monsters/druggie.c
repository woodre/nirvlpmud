inherit"obj/monster";
reset(arg){
::reset(arg);
if(!arg){
set_name("druggie");
set_alias("druggie");
set_short("A Druggie");
set_long("Wantin em...dreamin of em...He will do anything for them...including\nkill you\n");
set_ac(15);
set_wc(26);
set_al(-1000);
set_race("human");
set_level(18);
set_hp(450);
set_chat_chance(5);
load_chat("Druggie says:  Dude...got a hit....Dude!\n");
move_object(clone_object("players/vulture/misc/drugs/poison"),this_object());
}
}
