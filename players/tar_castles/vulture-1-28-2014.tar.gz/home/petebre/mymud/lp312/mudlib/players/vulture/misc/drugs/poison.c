inherit"obj/treasure";
reset(arg) {
set_id("poison");
set_short("poison");
set_long("A bottle of poison to use on your weapons.  Type poison <weapon name> to use.\n");
set_value(1000);
set_weight(1);
}
init() {
::init();
add_action("poison","poison");
}
poison(arg) {
object ob;
int weap,class;
if(!arg) {
write("Poison <weapon name>\n");
	return 1;
}
	if(!present(arg,this_player())) {
	write("You dont have that!\n");
	return 1;
	}
if(present(arg,this_player())->query_broke()) {
	write("Why waste it on a broken weapon?\n");
	return 1;
	}
class=present(arg,this_player())->weapon_class();
if(class>21){write("Sorry....the poison isnt strong enough to make a difference past what you have.\n");
	return 1;
	}
present(arg,this_player())->set_class(class+3);
write("The weapon is covered in the thick ooze...dont touch it or run the risk of\ndying!\n");
destruct_object(this_object());
return 1;
}
