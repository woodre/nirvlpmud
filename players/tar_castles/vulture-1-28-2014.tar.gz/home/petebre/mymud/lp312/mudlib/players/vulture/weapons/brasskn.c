inherit"/obj/weapon.c";
     reset(arg){
         set_name("brass knuckles");
         set_alias("knuckles");
         set_short("Brass knuckles");
         set_long("A strip of metal wich fits over you fist.\n");
         set_class(10);
         set_weight(1);
         set_value(250);
         set_hit_func(this_object());
}
weapon_hit(attacker){
     if(random(100)>50)
{
     write("You beat the shit out of your opponent.\n");
     say("That looks like it hurt.\n");
    attacker->hit_player(random(10));
     return random(10);
}
return;
}
