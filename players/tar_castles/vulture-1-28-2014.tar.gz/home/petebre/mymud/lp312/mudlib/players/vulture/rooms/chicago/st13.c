

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "A street";
	no_castle_flag=0;
	extra_reset();
	long_desc = 
		"This is just another street.  Be careful of everyone.  They will kill you\n"
		+ "when you least expect it.  There is a little bit of rubble and things also\n"
		+ "but nothing exciting.\n";
	dest_dir = 
	    ({
	"/players/vulture/rooms/chicago/st", "north",
	"/players/vulture/rooms/chicago/st", "south",
	"/players/vulture/rooms/chicago/st", "east",
	"/players/vulture/rooms/chicago/st", "west",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
int n,i;
object monst;
n=random(10);
if(!present("druggie"||"punk"||"solo"||"tt"||"kid")) {
if (n==1) {
monst=clone_object("/players/vulture/monsters/druggie");
move_object(monst,this_object());
}
if (n==2) {
while(i<2) {
i+=1;
monst=clone_object("/players/vulture/monsters/mpunk");
move_object(monst,this_object());
}
}
if(n==3) {
while(i<3) {
i+=1;
monst=clone_object("/players/vulture/monsters/csolo");
move_object(monst,this_object());
return 1;
}
}
if (n==4) {
while(i<3) {
i+=1;
monst=clone_object("/players/vulture/monsters/tt");
move_object(monst,this_object());
return 1;
}
}
if (n==5) {
while(i<4) {
i+=1;
monst=clone_object("/players/vulture/monsters/rkid");
move_object(monst,this_object());
return 1;
}
}
}
}
