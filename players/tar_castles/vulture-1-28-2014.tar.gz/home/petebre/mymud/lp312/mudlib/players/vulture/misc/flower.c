inherit"obj/treasure";
reset(arg) {
set_id("flower");
set_alias("flower");
set_short("A flower");
set_long("A Beautiful red rose to give to a lady.\n");
set_value(75);
set_weight(1);
}
