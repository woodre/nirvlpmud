

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "A dirty road";
	no_castle_flag=0;
extra_reset();
	long_desc = 
		"This is the end of civilization and Colfax to the east.  This once great \n"
		+ "avenue has been destroyed so bad that it is impossible to go farther east.\n"
		+ "It does extend west.  This place is completely trashed.\n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/colfax2", "west",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
int i;
i=0;
while(i<1) {
move_object(clone_object("players/vulture/monsters/punk"),this_object());
i += 1;
}
}
