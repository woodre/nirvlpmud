inherit "obj/treasure";

string spouse;
object ob,ob2;
int weight;

reset(arg)
{
  if(arg) return;
  name = "A beautiful red rose";
}

query_auto_load() { return("/players/vulture/closed/r/rose.c:" + spouse + ";"); }

id(str) { return (str == "rose" || str == "vulture_rose"); }

short() { if(spouse) {return name + " from " +capitalize(spouse); } else {return name;}}

long()
{
write("A perfect red long stemmed rose with a small card attached.  Obviously\nsomeone loves you very much!\n");
}

init_arg(str)
{
  sscanf(str,"%s;",spouse);
}

init()
{
::init();
  add_action("emot", "em");
   add_action("bri","bri");
  add_action("tele","tele");
  add_action("rose","rose");
  add_action("touch","touch");
  add_action("helpr","helpr");
add_action("bear","bear");
add_action("gaze","gaze");
add_action("pucker","pucker");
add_action("fsleep","fsleep");
add_action("show","show");
add_action("room","room");
  if (spouse) {
    ob = find_player(spouse);
    if (ob) {
      rose(this_player()->query_name() + " has entered the game!");
    } else {
      write("Rose tells you: "+capitalize(spouse) +" is not playing now.\n");
    }
  }
}

get() { return 1; }
query_value() { return (0); }
query_weight(){ return (0); }

get_spouse()
{
  if (spouse) {
    ob = find_player(spouse);
    if (ob) return(1);
    write(capitalize(spouse) + " tells you: I'm not here love *hug*\n");
  } else {
    write("You are not married!\n");
  }
  return;
}


local_set_spouse(str) { spouse = str; }

drop(str) { if (spouse) { return(1); } else { return(0); } }

emot(str)
{
  if (!get_spouse()) return(1);
  tell_object(ob,this_player()->query_name() +str+".\n");
  return(1);
}

bri(str)
{
  if (!get_spouse()) return(1);
  if (environment(ob)->realm() || environment(this_player())->realm()) {
    write("A magical barrier prevents you!\n");
    return(1);
  }
  if(this_player()->query_sp() < 50){
	write("Sorry, you don't have the spell points.\n");
	return 1;}
  this_player()->add_spell_point(-50);
  tell_room(environment(ob),this_player()->query_name() + " grabs "
    + ob->query_name() + " and drags " + ob->query_objective()
    + " off ...\n");
  tell_object(ob,this_player()->query_name() + " reaches out and takes you in "
    + this_player()->query_possessive() + " arms lovingly ...\n");
  write("You reach out and take " + ob->query_name() + " into your arms tenderly.\n");
  say(this_player()->query_name() + " reaches out and pulls " + ob->query_name()
   + " to " + this_player()->query_objective() + ".\n");
  move_object(ob, environment(this_player()));
  return(1);
}

tele(str)
{
  if (!get_spouse()) return(1);
  if (environment(ob)->realm() || environment(this_player())->realm()) {
    write("A magical barrier prevents you!\n");
    return(1);
  }
  if(this_player()->query_sp() < 50){
	write("Sorry, you don't have enough spell points.\n");
	return 1;}
  tell_room(environment(ob),this_player()->query_name() + " runs in and "
    + "hugs " + ob->query_name() + ".\n");
  this_player()->add_spell_point(-50);
  tell_object(ob,this_player()->query_name() + " appears and throws "
    + this_player()->query_possessive() + " arms around you!\n");
  write("You throw your arms around " + ob->query_name() + "!\n");
  say(this_player()->query_name() + " runs off.\n");
  move_object(this_player(),environment(ob));
  return(1);
}


helpr()
{
    write("em (messge) - emote to your sweetie\n");
    write("rose - tell your sweetie something through the rose\n");
    write("tele - teleport to your sweetie\n");
    write("bri - bring your sweetie to you\n");
	write("emotions\n    pucker,gaze,fsleep,show love\n bear -- brings a teddie bear to you\n room -- takes you to a special room\n");
    return(1);
  }
read(str) {
       if(str=="card") {
	write("This is a gift of love that is for you.  You will always be my number one.\nI will love you forever.\n			Love,"+spouse+"\n");
         return 1;
    } else return 0;
}
rose(str) {
	if(spouse) {
	if(find_player(spouse)) {
		tell_object(find_player(spouse),this_player()->query_real_name()+" tells you with love: "+str+"\n");
	write("You tell your sweetie: "+str+"\n");
return 1;
}
}
}
gaze() {
	write("You gaze into your sweethearts eyes.\n");
	emot("gazes deep into your eyes and your heart.\n");
	return 1;
}
pucker() {
	write("You pucker up for a kiss.\n");
	emot("puckers up and turns to you for a kiss.\n");
	return 1;
}
fsleep() {
	write("You cuddle up and fall asleep on your baby's shoulder.\n");
	emot("falls asleep on your shoulder and looks so cute and peaceful.\n");
	return 1;
}
show(str) {
	if(str == "love") {
	write("You show your sweetie love.\n");
	emot("shows you love and makes sure that you know how much you mean.\n");
	return 1;
}
}
room() {
if(this_player()->query_spell_point() < 50) {
	write("You dont have enough spell points!\n");
	return 0;}
move_object(this_player(),"/players/vulture/rooms/sproom");
move_object(get_spouse(),"/players/vulture/rooms/sproom");
call_other(this_player(),"add_spell_point",-50);
return 1;
}
bear() {
	write(spouse+" appears and gives you a small fuzzy teddie bear.\n");
	move_object(clone_object("/players/vulture/misc/bear"),this_player());
return 1;
}
