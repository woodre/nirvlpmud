inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg){
    object flower, bible,twax;
int j;
j=random(100);
	flower=clone_object("players/vulture/misc/flower");
bible=clone_object("players/vulture/misc/bible");
twax=clone_object("players/vulture/misc/twax");
    if(j>80) {
	move_object(bible,this_object()); }
    if(j<=80) {
	move_object(flower,this_object());
move_object(twax,this_object());
move_object(clone_object("obj/bag"),this_object());
}
	set_name("Hari Krishna");
	set_alias("krishna");
	set_short("hari krishna");
set_ep(5000);
set_al(-1000);
    set_long("He is annoying as hell and will bug you til the day he dies!\n");
	set_ac(5);
	set_wc(9);
	set_race("human");
	set_level(5);
	set_hp(75);
	set_chat_chance(3);
	load_chat("Hari Krishna says: Would you like a flower?\n");
	load_chat("Hari Krishna says: Join us and you will be free.\n");
	load_chat("You are blinded by the bald head of the Hari Krishna.\n");
}
}
