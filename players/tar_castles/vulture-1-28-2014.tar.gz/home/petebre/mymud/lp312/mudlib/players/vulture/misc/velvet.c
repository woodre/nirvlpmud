id(str) { return str == "velvet"; }
reset () {}
long() { write("You have a bottle of Black Velvet\n"); }
short() { return "A bottle of Black Velvet";  }
init() {
	add_action("drink"); add_verb("drink");
	add_action("drop_object"); add_verb("drop");
}

drink(arg) {
	say(call_other(this_player(),"query_name") + " drinks a bottle of Black Velvet.\n");
	write("You gulp down the Velvet.\n");
	call_other(this_player(),"heal_self",100);
   call_other(this_player(),"drink_alcohol",6);
	write("the bottle is dested for your convenience.\n");
	destruct(this_object());
	return 1;
}
get() {return 1; }
query_weight() {return 1; }
query_value() { return 5000; }
drop_object(str) {
	if (str == "all") {
		drop_object("velvet");
		return 0;
}
	if (str == "bottle") {
		drop_object("velvet");
		return 0;
}
	if (str == "black velvet") {
		drop_object("velvet");
		return 0;
}
	if (!str || !id(str))
		return 0;
	write("The bottle smashes as it hits the ground.\n");
	say(call_other(this_player(),"query_name") + " wastes some good alcohol.\n");
destruct(this_object());
return 1;
}
