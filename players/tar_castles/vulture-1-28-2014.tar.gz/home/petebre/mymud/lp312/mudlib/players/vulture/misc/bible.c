inherit"obj/treasure";
reset(arg) {
set_id("bible");
set_alias("bible");
set_short("A bible");
set_long("This is the holy book for Hari Krishna's.  It seems to have a\n" +
	"little power coming from within it.\n");
set_value(200);
set_weight(1);
}
init () {
add_action("read","read");
}
read(str) {
	if(str == "bible") {
	write("You read from the bible and the powers of God heal\n" +
	"your sorry ass!!!\n");
	say(capitalize(this_player()->query_real_name())+" is healed by God!\n");
	call_other(this_player(),"heal_self",15);
destruct(this_object());
	return 1;
	}
}
