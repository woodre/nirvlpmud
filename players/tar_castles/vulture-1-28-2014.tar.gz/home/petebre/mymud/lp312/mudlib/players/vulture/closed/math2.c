get() { return 1; }
short(){return "Finder";}
id(str){return str == "who" || str == "Finder" || str == "finder";}
long(){write("Uses: iwho (invis who) or awho (all who)\n");
}
/*            no need to make this autoload.....  mythos  <11/1/95>
query_auto_load() {
return "players/vulture/closed/math2:";
}
*/
init() {
	add_action("awho","awho");
  add_action("iwho","iwho");
  add_action("drop","drop");
}
drop(str) {
  if(str=="who"||str=="finder")
    {  write("Pentagram -- That would not be a good idea.\n");
    return 1; }
  return 1;
}
iwho(str) {
  object us;
string is_invis;
  int x, y;
  if(str) return;
  us=users();
write("Invisible player------------------------------------------->location\n");
  for(x=0;x<sizeof(us);x++) {
	is_invis = us[x]->short();
	y = x+1;
	if(is_invis==0){
	write(y + ".\t"+capitalize(us[x]->query_real_name()));
      if(strlen(us[x]->query_real_name())>7)
        write("\t"); else write("\t\t");
      write(environment(us[x])->short());
      write("\n");
	}
  }
  return 1;
}
awho(str){
object us;
int x, y;
if(str) return;
us = users();
write("<<<<<player>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<location>>>>>\n");
for(x=0;x<sizeof(us);x++){
	y = x + 1;
	write(y + ".\t" + capitalize(us[x]->query_real_name()));
	if(strlen(us[x]->query_real_name())>7)
		write("\t"); else write("\t\t");
	if(!environment(us[x])) write("Logging in");
		else write(environment(us[x])->short());
	write("\n");
		}
	return 1;
	}
