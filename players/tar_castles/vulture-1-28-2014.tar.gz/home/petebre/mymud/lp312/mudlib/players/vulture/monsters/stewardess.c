inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
	object weapon;
	weapon=clone_object("players/vulture/weapons/brasskn");
	move_object(weapon,this_object());
	command("wield knuckles",this_object());
	set_name("stewardess");
	set_alias("stewardess");
set_al(-1000);
	set_short("A stewardess");
	set_long("This is a mean looking flight attendant.  Don't give her any lip.\n" +
	"She may try to beat you up.\n");
	set_ac(5);
	set_wc(10);
	set_race("human");
	set_level(6);
	set_hp(90);
	set_chat_chance(3);
load_chat("Stewardess says: Take a seat and we will be off!\n");
load_chat("Stewardess tells you: Don't make me hurt you, Punk!\n");
}
}
