

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "Airplane";
	no_castle_flag=0;
	long_desc = 
	"This is a DC-20 armored for your personal protection.\n" +
	"Maybe if you take your seat then we will leave!.\n";
	extra_reset();
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/staple", "south",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
	object stewardess;
	int i;
	if(!present("stewardess")) {
	i=0;
	while(i<1) {
	i += 1;
	move_object(clone_object("players/vulture/monsters/stewardess"),this_object());
}
}
}
init() {
	::init();

	add_action("sit","sit");
}

sit() {
write("The plane wisks you off to Nirvana.  Have fun.\n");
say(capitalize(this_player()->query_real_name())+" is boarded on another plane and wisked to Nirvana.\n");
move_object(this_player(),"players/vulture/rooms/term_2");
command("look",this_player());
return 1;
}
