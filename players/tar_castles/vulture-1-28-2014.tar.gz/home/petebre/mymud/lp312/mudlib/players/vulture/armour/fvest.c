inherit"obj/armor";
reset(arg) {
if(!arg) {
set_name("vest");
set_alias("flack vest");
set_short("A flack vest");
set_long("This is a camouflaged flack vest...very in style.  And strong enough to\n withstand some hard hits.\n");
set_ac(4);
set_type("armor");
set_weight(5);
set_value(400);
}
}
