

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "Terminal [n,s]";
	no_castle_flag=0;
	long_desc = 
		"You are in a dark and evil looking terminal...there is only one person in the\n"
		+ "room.  If you want on the plane you will have to kill him for his ticket.\n"
		+ "He is mean so be warned.\n";
	dest_dir = 
	    ({
	"players/vulture/rooms/plane_4", "east",
	"players/vulture/rooms/airport", "west",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

