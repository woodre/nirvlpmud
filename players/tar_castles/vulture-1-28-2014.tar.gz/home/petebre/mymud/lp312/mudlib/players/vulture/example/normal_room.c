inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("a small forest clearing");
   long_desc=
   "You stand in a forest clearing, but this is a forest like none found on\n"
+  "earth. The grass below your feet glow with a vibrant purple color, and\n"
+  "the trees are like none you have seen before. The moon beam you traveled\n"
+  "on is no where to be seen. You see some footprints on the ground before\n"
+  "you.\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
     "players/sandman/CUCKOO/land2","northwest",
     "players/sandman/CUCKOO/land3","southwest",
     "players/sandman/CUCKOO/apartment","east",
   });
}
