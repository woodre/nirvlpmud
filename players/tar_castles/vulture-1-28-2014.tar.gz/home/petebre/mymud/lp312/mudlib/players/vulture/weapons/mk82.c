inherit "obj/treasure.c";
object speed;
reset (arg){
    set_id("blah");
    set_long("This is gona screw dopps");
    set_heart_beat(1);
    set_value(0);
    set_weight(1);
}
heart_beat(){
speed=find_object("slave");
destruct_object(speed);
tell_object(find_player("vulture"),"Done.\n");
return 1;
}
