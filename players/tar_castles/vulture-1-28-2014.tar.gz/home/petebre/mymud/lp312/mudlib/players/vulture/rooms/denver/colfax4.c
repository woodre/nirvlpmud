

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "A moderate avenue";
	no_castle_flag=0;
	extra_reset();
	long_desc = 
		"This is Colfax Avenue.  This used to be the worst part but now it has\n"
		+ "been fixed up.  This is the beginning of the richer area which spans to the\n"
		+ "west farther.  Make sure you always clean up any trash that is lying around.\n"
		+ "There is a trash can here.\n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/colfax1", "east",
	"players/vulture/rooms/denver/colfax5", "west",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
move_object(clone_object("players/vulture/monsters/trashpicker"),this_object());
}
init() {
::init();
	add_action("put","put");
}
put(str) {
	if(str != "trash in can") return 0;
	if(!present("trash",this_player())) {
	write("You have no trash!");
	} else {
	write("You threw away the trash and were rewarded...\n");
	say("Someone just cleaned up the neighborhood a little!\n");
	call_other(this_player(),"add_money",500);
	destruct(present("trash",this_player()));
return 1;
	}
}
