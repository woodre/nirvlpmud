inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
	object weap;
	weap=clone_object("players/vulture/weapons/broom");
	move_object(weap,this_object());
	set_name("trashpicker");
	set_alias("picker");
	set_short("A trashpicker");
set_al(-1000);
	set_long("This is a lonely old man.  He picks trash in this area so that it stays clean.\n The people pay him to do so.  Maybe if you throw it away they will pay you.\n");
	set_ac(8);
	set_wc(14);
	set_level(10);
	set_hp(150);
	set_race("human");
}
}
