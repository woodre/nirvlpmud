inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg){
	set_name("bum");
set_alias("bum");
set_short("A dirty bum");
set_long("This is a dirty drunken old man that would do anything to get another drink\n including kill you.\n");
set_ac(6);
set_wc(11);
set_al(-1000);
set_race("human");
set_level(7);
set_hp(105);
set_chat_chance(5);
load_chat("Can I have a sip please...just a sip!\n");
move_object(clone_object("players/vulture/misc/maddog"),this_object());
}
}
