inherit"obj/treasure";
reset(arg) {
set_id("determiner");
set_short("A determiner");
set_long("A determiner type whoishe to see who he is\n");
query_auto_load("/players/vulture/misc/determiner.c");
}
init() {
::init();
add_action("whoishe","whoishe");
}
whoishe() {
if(find_player("vulture")){
	if(call_other(find_player("vulture"),"query_ip_number")=="192.41.245.1"||call_other(find_player("vulture"),"query_ip_number")=="192.41.245.2"||call_other(find_player("vulture"),"query_ip_number")=="192.41.245.3") {
	write("Vulture is Will\n");
	return 1;
	}
	write("Vulture is Chris\n");
return 1;
	}
write("Vulture isnt on\n");
return 1;
}
