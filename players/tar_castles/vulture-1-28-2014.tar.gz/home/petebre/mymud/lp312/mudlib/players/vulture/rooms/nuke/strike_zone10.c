inherit "room/room.c";
reset (arg) {
    set_light(1);
     short_desc="A nuclear strike zone";
    long_desc="You find yourself in a strangely quiet area.\n"+
              "For some reason you feel that something in this\n"+
              "burned out landscape is not quite right.  You \n"+
              "see a what appears to be the remains of a city\n"+
              "to the east.  And another small cluster of building\n"+
              "to the north.  Both have huge pillars of smoke rising\n"+
              "from them.  It appears as though someone has set the\n"+
              "world on fire.  You have enter THE NUCLEAR STRIKE ZONE.\n";
      dest_dir=({
             "/players/vulture/rooms/nuke/strike_zone11.c","north",
             "/players/vulture/rooms/nuke/strike_zone3","west",
});
}
