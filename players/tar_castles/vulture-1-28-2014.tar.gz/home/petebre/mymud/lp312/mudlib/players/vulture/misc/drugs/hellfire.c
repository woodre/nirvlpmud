inherit"obj/treasure";
reset(arg) {
set_id("hellfire");
set_alias("drug");
set_short("hellfire");
set_long("This is a gram of hellfire.  A strong drug sold on the streets to relieve pain.\nBe careful drug are addicting.\n");
set_value(650);
set_weight(1);
}
init() {
::init();
add_action("snort","snort");
}
snort(str) {
int i;
i=random(50);
	if(str!="hellfire") return 0;
	if(i==37) {
	write("You get addicted and have to pay for the treatment.\n");
	call_other(this_player(),"add_money",-5000);
destruct_object(this_object());
	return 1;
	}
	write("The drug makes you feel rejuvinated and ready to kick ass!\n");
	call_other(this_player(),"heal_self",30);
	destruct_object(this_object());
	return 1;
}
