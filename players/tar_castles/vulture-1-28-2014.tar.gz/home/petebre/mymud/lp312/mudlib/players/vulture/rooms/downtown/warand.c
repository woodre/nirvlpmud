inherit "room/room";
reset(arg){
set_light(1);
short_desc="The corner of Randolf and Wabash";
long_desc="This is the corner of Randolf and Wabash.  Adams\n"+
          "runs to the east and west, and Wabash runs north\n"+
          "and south.  You notice that something is not right\n"+
          "this area should bustling with activity.  There is a\n"+
          "lot of activity to the south that might have some-\n"+
          "to do with it.  You should check it out.\n";
dest_dir=({
          "/players/vulture/rooms/downtown/rand1","east",
          "players/vulture/rooms/downtown/rand2","west",
          "players/vulture/rooms/downtown/wabash1","north",
          "players/vulture/rooms/downtown/wabash2","south",});
}
