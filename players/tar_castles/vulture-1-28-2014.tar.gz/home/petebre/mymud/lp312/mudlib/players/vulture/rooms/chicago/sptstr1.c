

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "sport store";
	no_castle_flag=0;
	long_desc = 
		"This is the Merc sho.  You can buy the tools needed to stay alive here.\n"
		+ "The stuff is to your east.  But be careful...dont make the guard angry or he will slam you.  He is mean!!!\n";
	dest_dir = 
	    ({
	"/players/vulture/rooms/chicago/st15", "south",
	"/players/vulture/rooms/chicago/sptstr2", "east",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

