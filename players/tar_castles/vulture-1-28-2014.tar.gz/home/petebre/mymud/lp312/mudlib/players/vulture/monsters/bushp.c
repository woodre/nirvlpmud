inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
object wig;
wig=clone_object("players/vulture/armour/swig");
move_object(wig,this_object());
set_name("Bush poser");
set_alias("poser");
set_short("A George Bush Poser");
set_al(-1000);
set_long("This is a man or woman posing as George Bush.  This is a gang thing.\n They are stupid...please kill them and save our country.\n");
set_ac(6);
set_wc(11);
set_hp(105);
money=(200);
set_level(7);
set_race("human, sorta");
set_chat_chance(4);
load_chat("Poser says: No new taxes!!!\n");
}
}
