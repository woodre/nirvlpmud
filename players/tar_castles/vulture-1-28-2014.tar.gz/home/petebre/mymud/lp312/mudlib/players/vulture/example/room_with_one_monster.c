inherit "room/room";

reset(arg) {
   if(!present("martin tenbones")) {
      move_object(clone_object("players/sandman/MONSTERS/martin"), this_object());
   }
   if(!arg) {
      set_light(1);
      short_desc=("A forest glade");
      long_desc=
      "This is a dark forest glade, the green and purple trees press in on\n"
+     "you heavily. As your eyes adjust to the dim light, you notice a\n"
+     "rather imposing figure before you. Could it be the Princess's champion?\n";
      dest_dir=
      ({
        "players/sandman/CUCKOO/land1", "northeast"
      });
   }
}
