

inherit "room/room";
int check;

reset(arg) {

	set_light(1);
	short_desc = "A car";
	no_castle_flag=0;
	long_desc = 
		"This is a Toyota Avante sports car.  The owner is dead laying in the \n"
		+ "passengers seat.  Just push him out.  His corpse is relatively \n"
		+ "fresh...looks like a professional hit.  Be careful.  His keys are still\n"
		+ "in the ignition.\n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/i25", "out",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

init(){
::init();
	add_action("search","search");
	add_action("turn","turn");
}
search(str) {
if (check!=0) return 0;
	if(str != "corpse") return 0;
	write("You found some money in his wallet!\n");
	call_other(this_player(),"add_money",200);
        check = 1;
	return 1;
}
turn(str) {
	if(str != "key") return 0;
	write("Vroom Vroom! Away you go!\n");
	say("The driver boots you out of his car and heads away!\n");
	move_object(this_player(),"players/vulture/rooms/denver/wp1");
	return 1;
}
