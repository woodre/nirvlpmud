inherit"/obj/treasure";
#define Me capitalize(this_player()->query_real_name())
reset(arg)
{
set_alias("neuralware");
set_long("You cant see it but you know its there\n"+
         "type (info) to see what you can do with it.\n");
set_weight(0);
this_player()->set_guild_name("Cyber psycho");
}
init(){
add_action("new_who","cybers");
add_action("stuff","info");
add_action("satt","su");
}
drop(){return 1;}
get(){return 1;}
satt(str){
string msg;
int num;
object players;
players=users();
msg=str;
for(num=0;num<sizeof(players);num++)
if(present("neuralware",players[num]))
tell_object(players[num],"Uplink Msg from "+Me+":"+str+"\n");
return 1;
}
stuff(){
write("You are in the CyberGuild founded by Vulture.\n"+
      "Below are a list of differant cybernetic implants\n"+
      "and replacement you can buy from the CyberDoc\n"+
      "to increase your powers.  Included are the commands\n"+
      "each part will give you.\n"+
      "\n"+"NeuralWare(Required to be in Guild)\n"+
      "su(satalite uplink)--allows communication with other\n"+
      "                     guild members\n"+
      "cybers--list of other guild members\n"+
      "\n");
      return 1;
}
new_who(){
object players;
int num,num2;
players=users();
for(num=0; num<sizeof(players); num++){
    if(present("neuralware",players[num])){
    write(capitalize(players[num]->query_real_name()));
    for(num2=strlen(players[num]->query_real_name()); num2<15; num2++){
    write(" ");}
    write(players[num]->query_level());
write("      ");
    if(players[num]->query_gender()=="male"){
    write("M");
    }
    if(players[num]->query_gender()=="female"){
    write("F");}
    if(players[num]->query_gender()=="creature"){
    write("C");}
    write("     ");
    write("\n");
}
}
return 1;
}
