inherit"obj/armor";
reset(arg) {
if(!arg) {
set_name("steel helmet");
set_alias("helmet");
set_short("A steel helmet");
set_long("This is a steel helmet that looks like it has seen some action\n" +
	"I hope you have more luck than the last person to wear it.\n");
set_ac(1);
set_type("helmet");
set_weight(1);
set_value(100);
}
}
