inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
set_name("housewife");
set_alias("wife");
set_short("A rich housewife");
set_long("This is a rich housewife....She is out on the town shopping.  If you are\n willing to lower your dignity then she will probably give you money if you beg.\n");
set_ac(8);
set_wc(14);
set_al(-1000);
set_race("human");
set_level(10);
money=(450);
set_chat_chance(5);
load_chat("Wife says: You trash, please leave me alone!\n");
}
}
init() {
	add_action("beg","beg"); }
beg() {
	int mon;
	mon=call_other(this_object(),"query_money");
	if(mon>=350) {
	write("the housewife gives you money to get you away from her!\n");
	call_other(this_player(),"add_money",50);
	money=(money-50);
	return 1; }
	if(mon<350) {
	write("You will have to kill her for the rest!\n");
	return 1;
}
}
