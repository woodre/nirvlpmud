

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "A park";
	no_castle_flag=0;
extra_reset();
	long_desc = 
		"This is Washington Park.  There are trees all around. The place is \n"
		+ "beautiful and untouched by the pain of the real world.  There are \n"
		+ "very few people here and eveything grows wild.  The park extends to\n"
		+ "the south and the east.  Your car is still here.\n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/wp2", "east",
	"players/vulture/rooms/denver/wp3", "south",
	"players/vulture/rooms/denver/i25", "car",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
int i;
i=0;
while(i<3) {
move_object(clone_object("players/vulture/monsters/cyberd"),this_object());
i += 1;
}
}
