

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "A descent strait";
	no_castle_flag=0;
	extra_reset();
	long_desc = 
		"This is a road leading to the good part of town.  Perhaps if you ask nicely\n"
		+ "they will give you some money.  If you need it.  \n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/colfax6", "west",
	"players/vulture/rooms/denver/colfax4", "east",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
int i;
i=0;
while(i<1) {
i += 1;
move_object(clone_object("players/vulture/monsters/richhswf"),this_object()); }
}
