

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "snuggle room";
	no_castle_flag=0;
	long_desc = 
		"This is a nice quiet, private room for smoochin'.  In here you will be safe\n"
		+ "from wandering ears and you will be able to do whatever you want.  The\n"
		+ "walls are red and there are heart shaped throw cushions scattered accross the\n"
		+ "room.  There is a fireplace.  Why dont you light up a fire.  There is\n"
		+ "a hot tub in the room to the east but you cant go there yet.  Have fun\n"
		+ "and tell me of any other ideas you have for it.\n"
		+ "	A dim candle peaks the mood and combines with the soft music for an\n"
		+ "air of romance.\n";
	dest_dir = 
	    ({
	"/room/church", "church",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

init() {
::init();
add_action("light","light");
}
light(str) {
if(str = "fire") {
	write("You light a fire.\n");
	say(this_player()->query_real_name()+" lights a warm romantic fire to get the love juices flowing\n");
	return 1;
}
}
