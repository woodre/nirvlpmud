inherit"obj/weapon";
	reset(arg)   {
		set_name("sub flachette gun");
		set_alias("gun");
		set_short("Sub-Flachette Machine Gun");
		set_long("A high powered sub machine gun that fires flachettes\n" +
			"for maximum damage and minimum resistance...\n");
		set_class(18);
		set_weight(4);
		set_value(15000);
		set_hit_func(this_object());
}
weapon_hit(attacker){
	if(random(100)<75)
{
	write("You have struck multiple blows on your opponent.\n");
	say("OUCHIE!!!!!!!!!!");
	attacker->hit_player(random(15));
	return(random(15));
}
	if(random(100)<20)
{	
	write("Blood trickles from your prey's skull");
	say("Sucks to be you");
	attacker->hit_player(random(20)+10);
	return(random(20)+10);
}
return;
}
