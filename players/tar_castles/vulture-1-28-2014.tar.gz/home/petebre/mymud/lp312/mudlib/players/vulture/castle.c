#define NAME "Vulture"
#define DEST "room/south/sforst17"
/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str =="airport";}

/*
short() {
return "Nirvana International Airport";
}
*/

long() {
    write("This is the " + short() + ".\n");
    write("Its is Big and Smog polluted.  Just what you\n"+
          "would expect an airport of 2020 to look like\n"+
         "Why don't you enter it and find out where\n"+
         "you can go?\n");
}

init() {
	add_action("enter","enter");
}

enter(str) {
    if (!id(str))
	return 0;
       say(this_player()->query_real_name()+" enters the airport.\n");
    write("You enter the airport.\n");
    move_object(this_player(), "players/vulture/rooms/airport");
    command("look",this_player());
    return 1;
}

reset(arg) {
	if(arg)
	return;
move_object(this_object(),DEST);
}
is_castle(){return 1;}
