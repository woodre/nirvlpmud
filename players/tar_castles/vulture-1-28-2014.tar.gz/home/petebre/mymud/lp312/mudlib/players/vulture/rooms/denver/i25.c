

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "A Highway";
	no_castle_flag=0;
	long_desc = 
		"This is I-25, the main highway in Denver.  There is a car here.  Perhaps\n"
		+ "you should go ahead and steal it.  You are a punk, act like it.  \n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/colfax1", "north",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

init() {
::init();
	add_action("steal","steal");
}
steal(str) {
	if(str != "car") return 0;
	write("you get in the car.\n");
	say(this_player()->query_real_name()+" gets in the car.\n");
	move_object(this_player(),"players/vulture/rooms/denver/car");
return 1;
}
