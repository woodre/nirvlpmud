inherit"obj/treasure";
reset(arg){
set_alias("fallout");
set_long("Its fallout you can't see it but you know its bad.\n");
set_weight(1000);
set_value(0);
}
init(){
add_action("take"),add_verb("take");
}
take(){
return 0;
}
