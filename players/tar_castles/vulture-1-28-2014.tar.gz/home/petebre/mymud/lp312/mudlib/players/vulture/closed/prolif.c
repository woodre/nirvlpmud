inherit"/obj/treasure";
reset(arg){
    set_id("nuke");
    set_alias("warhead");
    set_short("Nuclear Warhead");
    set_long("Please distribute freely.  Just type prolificate.\n");
    set_weight(2);
    set_value(1000);
}
init(){
add_action("prolificate","prolificate");
}
prolificate(){
shout("Mr. Happy Mushroom Cloud is coming to your town!\n");
shout("There's no need to run and hide for he will strike\n");
shout("you down!\n");
destruct(this_object());
return 1;
}
