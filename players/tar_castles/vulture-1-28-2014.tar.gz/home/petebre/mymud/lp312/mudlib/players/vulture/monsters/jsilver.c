inherit"obj/monster";
int i;
reset(arg) {
::reset(arg);
	if(!arg) {
	move_object(clone_object("players/vulture/weapons/stern"),this_object());
i=0;
while(i<3) {
i += 1;
	move_object(clone_object("players/vulture/weapons/11mmclip"),this_object());
}
	set_name("johnny silverhand");
	set_alias("johnny");
	set_short("Johnny Silverhand");
	set_long("This is Johnny Silverhand.  He is the most popular rocker buy around.\n His fame is universal.  For some reason his body guards arent here.\n");
set_al(-1000);
	set_level(12);
	set_wc(16);
	set_ac(9);
	set_hp(180);
	set_race("human");
money=(random(100)+50);
	set_chat_chance(5);
	load_chat("Johnny says: I love my Sternmyer!\n");
}
}
