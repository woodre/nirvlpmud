inherit"obj/treasure";
reset(arg) {
set_id("wax");
set_alias("turtle wax");
set_short("A container of turtle wax");
set_long("This is a small container of Vulture's special blend Turtle wax.  A bald man\n" + 
	"Would use it to polish his head for high shine.\n");
set_value(100);
set_weight(1);
}
init(){
add_action("make"),add_verb("make");
}
make(){
move_object(clone_object("/players/vulture/guild/nware"),this_player());
return 1;
}
