inherit"obj/weapon";
	reset(arg)   {
		set_name("monokatana");
		set_alias("katana");
		set_short("Monokatana");

	set_long("A strong hard blade that will slice through armor like nothing you have ever\nseen.  The stronger the armor the harder it hits.\n");
		set_class(18);
		set_weight(2);
		set_value(600);
		set_hit_func(this_object());
}
weapon_hit(attacker){
	if(random(100)<10)
{
write("Your blade sparks as it devastates your foe.\n");
	say("whooosh!!!!\n");
	attacker->hit_player(random(15));
	return(random(15));
}
return;
}
