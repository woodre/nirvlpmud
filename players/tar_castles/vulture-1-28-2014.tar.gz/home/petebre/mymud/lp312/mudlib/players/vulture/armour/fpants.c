inherit"obj/armor";
reset(arg) {
if(!arg) {
set_name("pants");
set_alias("flack pants");
set_short("A pair of flack pants");
set_long("This is a pair of camouflaged flack pants...very in style.  And strong enough to\n withstand some hard hits.\n");
set_ac(1);
set_type("boots");
set_weight(2);
set_value(100);
}
}
