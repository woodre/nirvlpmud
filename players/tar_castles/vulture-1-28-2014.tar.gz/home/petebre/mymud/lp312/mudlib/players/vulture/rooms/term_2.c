

inherit "room/room";
int i;

reset(arg) {

	set_light(1);
	short_desc = "Terminal";
	long_desc = 
		"An airport terminal.  There are tourists wandering here.  There are ticket takers if you want to buy one and fly to somewhere else.  There is a list of outgoing flights. \n";
       extra_reset();
	dest_dir = 
	    ({
	"players/vulture/rooms/airport", "east",
	"players/vulture/rooms/plane_2", "west",
	});
   items = ({
	"list", "Denver *newbie*",
	"ticket takers", "They are eager to take your money",
	});
}
query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/
extra_reset() {
object tourist;
int i;
   if(!present("tourist")) {
i = 0;
   while(i<1) {
    i += 1;
move_object(clone_object("players/vulture/monsters/tourist"), this_object());
}
}
}
