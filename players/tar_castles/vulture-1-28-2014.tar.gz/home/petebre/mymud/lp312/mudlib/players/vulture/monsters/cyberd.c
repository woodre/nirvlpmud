inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
move_object(clone_object("players/vulture/weapons/claw"),this_object());
	set_name("cyberdog");
	set_alias("dog");
	set_short("A cyberdog");
	set_long("This is the pet of someone who obviously got lost around here.  The dog\n can survive without food his master couldn't.\n");
	set_wc(15);
set_al(-1000);
	set_ac(9);
	set_hp(165);
	set_chat_chance(5);
	load_chat("dog growls: Woof Woof!\n");
}
}
