inherit "obj/treasure";
reset(arg){
set_id("nothing");
set_weight(0);
}
query_auto_load(){return("players/vulture/miscl/gl.c");}
drop(){return 1;}
init(){
add_action("ec"),add_verb("ec");
}
ec(str){
say(str);
say("\n");
write(str);
write("\n");
return 1;
}
