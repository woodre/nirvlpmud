inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
set_name("punk");
set_alias("cyberpunk");
set_short("A little cyberpunk");
set_long("This is a small but agile cyberpunk.  He is only maybe 14 years old.  He is stil tough.\n");
set_ac(7);
set_wc(12);
set_al(-1000);
set_level(8);
set_hp(random(40)+90);
money=(random(100)+280);
set_chat_chance(4);
load_chat("punk says: Just mess with me and I will slam you!\n");
load_chat("punk says: You are a loser in a big way.\n");
}
}
