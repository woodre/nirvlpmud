

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "barbrawl";
	no_castle_flag=0;
	long_desc = 
		"This is a dark and violent bar.  If you come here than expect to get\n"
		+ "in a lot of fights.  You better be heavily armed and ready for battle.\n"
		+ "But have some smash and a good time.\n";
	dest_dir = 
	    ({
	"/players/vulture/rooms/chicago/bb/crowd", "east",
	"/players/vulture/rooms/chicago/bb/crowd2", "south",
	"/players/vulture/rooms/chicago/st18", "out",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

