

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "airport";
	no_castle_flag=0;
	long_desc = 
		"This is Midway.  Amidst the hustle and bustle of everyday life is an air\n"
		+ "of scariness.  People are afraid of the streets of Chicago and you\n"
		+ "should be also.  Beware of people that will shoot you just for the fun of it.\n"
		+ "There are many of them.\n";
	dest_dir = 
	    ({
	"/players/vulture/rooms/chicago/st1", "south",
	"/players/vulture/rooms/chicago/st3", "west",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

