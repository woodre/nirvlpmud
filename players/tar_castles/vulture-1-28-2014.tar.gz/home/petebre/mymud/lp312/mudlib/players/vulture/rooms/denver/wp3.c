

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "A park";
	no_castle_flag=0;
extra_reset();
	long_desc = 
		"This is still Washington Park. There is a lake to the east with an island.\n"
		+ "The lake gleems bright...maybe you should go there. \n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/mi", "east",
	"players/vulture/rooms/denver/wp1", "north",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
move_object(clone_object("players/vulture/monsters/frog"),this_object());
}
