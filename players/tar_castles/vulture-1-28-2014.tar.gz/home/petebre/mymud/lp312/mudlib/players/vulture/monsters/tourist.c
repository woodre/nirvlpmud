inherit"obj/monster";
reset(arg){
::reset(arg);
if(!arg){
set_name("tourist");
set_alias("tourist");
set_short("A Tourist");
set_long("This is just an ordinary tourist...kill him!!!!!\n");
set_ac(6);
set_wc(11);
set_al(-1000);
set_al(-1000);
set_race("human");
set_level(7);
set_hp(105);
set_chat_chance(5);
load_chat("Tourist says:  Get out of my way.....I'm in a hurry\n");
move_object(clone_object("players/vulture/armour/kevt"),this_object());
}
}
