inherit"obj/treasure";
reset(arg) {
	set_id("bear");
	set_short("teddie bear");
	set_long("A small fuzzy teddie bear for you to hug and squeeze with a small nametag\n attached to its neck.  type readtag for help with the bear.\n");
set_value(0);
	set_weight(0);
}
init() {
::init();
add_action("readtag","readtag");
add_action("bsqu","bsqueeze");
add_action("bhug","bhug");
add_action("bhold","bhold");
}
readtag() {
	write("To squeeze it -- bsqueeze\nTo hug it -- bhug\nTo hold it -- bhold\n");
	return 1;
}
bsqu() {
	write("You squeeze you huggable little bear tight and you hear it say he loves you!\n");
	return 1;
}
bhug() {
	write("You hug the bear and kiss its cheek and it smiles back at you with love.\n");
	return 1;
}
bhold() {
	write("You hold the bear and tickle it and it giggles softly and kisses you.\n");
	return 1;
}
