inherit "obj/treasure";

string spouse;
object ob,ob2;
int weight;

reset(arg)
{
  if(arg) return;
  name = "A beautiful rose";
}

query_auto_load() { return("/players/vulture/misc/rose2.c:" + spouse + ";"); }

id(str) { return (str == "rose" || str == "vulture_rose"); }

short() { if(spouse) {return name + " from " +capitalize(spouse); } else {return name;}}

long()
{
  write("A perfect red rose that has a small gold card attached.\n"+
	"Maybe you should read it.\n");
}

init_arg(str)
{
  sscanf(str,"%s;",spouse);
}

init()
{
::init();
  add_action("emot", "em");
   add_action("bri","bri");
  add_action("tele","tele");
  add_action("rose","rose");
  add_action("read","read");
  add_action("helpr","helpr");
  if (spouse) {
    ob = find_player(spouse);
    if (ob) {
      rose(this_player()->query_name() + " has entered the game!");
    } else {
      write("Rose tells you: "+capitalize(spouse) +" is not playing now.\n");
    }
  }
}

get() { return 1; }
query_value() { return (0); }
query_weight(){ return (0); }

get_spouse()
{
  if (spouse) {
    ob = find_player(spouse);
    if (ob) return(1);
    write(capitalize(spouse) + " tells you: I'm not here love *hug*\n");
  } else {
    write("You are not married!\n");
  }
  return;
}


local_set_spouse(str) { spouse = str; }

drop(str) { if (spouse) { return(1); } else { return(0); } }

emot(str)
{
  if (!get_spouse()) return(1);
  tell_object(ob,this_player()->query_name() +str+".\n");
  write(this_player()->query_name() +" emote something privately..\n");
  return(1);
}

bri(str)
{
  if (!get_spouse()) return(1);
  if (environment(ob)->realm() || environment(this_player())->realm()) {
    write("A magical barrier prevents you!\n");
    return(1);
  }
  if(this_player()->query_sp() < 50){
	write("Sorry, you don't have the spell points.\n");
	return 1;}
  this_player()->add_spell_point(-50);
  tell_room(environment(ob),this_player()->query_name() + " grabs "
    + ob->query_name() + " and drags " + ob->query_objective()
    + " off ...\n");
  tell_object(ob,this_player()->query_name() + " reaches out and takes you in "
    + this_player()->query_possessive() + " arms lovingly ...\n");
  write("You reach out and take " + ob->query_name() + " into your arms tenderly.\n");
  say(this_player()->query_name() + " reaches out and pulls " + ob->query_name()
   + " to " + this_player()->query_objective() + ".\n");
  move_object(ob, environment(this_player()));
  return(1);
}

tele(str)
{
  if (!get_spouse()) return(1);
  if (environment(ob)->realm() || environment(this_player())->realm()) {
    write("A magical barrier prevents you!\n");
    return(1);
  }
  if(this_player()->query_sp() < 50){
	write("Sorry, you don't have enough spell points.\n");
	return 1;}
  tell_room(environment(ob),this_player()->query_name() + " runs in and "
    + "hugs " + ob->query_name() + ".\n");
  this_player()->add_spell_point(-50);
  tell_object(ob,this_player()->query_name() + " appears and throws "
    + this_player()->query_possessive() + " arms around you!\n");
  write("You throw your arms around " + ob->query_name() + "!\n");
  say(this_player()->query_name() + " runs off.\n");
  move_object(this_player(),environment(ob));
  return(1);
}


helpr()
{
    write("em (messge) - emote to your sweetie\n");
    write("rose - tell your sweetie something through the rose\n");
    write("tele - teleport to your sweetie\n");
    write("bri - bring your sweetie to you\n");
    return(1);
  }
read(str) {
       if(str=="card") {
         write("This is a beautiful flower as a sign of our love.\n"+
		"It is a symbol of us "+spouse+" and "+this_player()->query_real_name()+".\n"+
		"Love, "+spouse+".\n");
         return 1;
    } else return 0;
}
rose(str) {
	if(spouse) {
	if(find_player(spouse)) {
		tell_object(find_player(spouse),this_player()->query_real_name()+" tells you with love: "+str+"\n");
return 1;
}
}
}
