inherit "obj/weapon.c";

reset(arg) {
   set_name("rusty pike");
   set_alias("pike");
   set_short("Rusty Pike");
   set_long("This is an old rusty blood splattered pike.\n");
   set_class(14);
   set_weight(3);
   set_value(250);
   set_hit_func(this_object());
   
}

weapon_hit(attacker) {
   if(random(100) > 50) {
      write("The pike nicks your enemy, drawing blood.\n");
      return;
   }
   return;
}
