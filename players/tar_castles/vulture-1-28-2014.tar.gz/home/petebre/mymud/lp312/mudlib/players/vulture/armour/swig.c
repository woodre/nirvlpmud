inherit"obj/armor";
reset(arg) {
if(!arg) {
set_name("steel wig");
set_alias("wig");
set_short("A steel wig");
set_long("This is a wig made of steel.  It looks like George Bush's hair just\n"+
	"before he lost to that moron, what's his name!\n");
set_ac(1);
set_type("helmet");
set_value(100);
}
}
