inherit "/obj/treasure";
reset(arg){
     set_id("7.62 clip");
    set_alias("clip");
    set_short("7.62 mm clip");
    set_long("A 7.62 mm clip commonly used in assualt rifles like the AK-47.\n");
    set_value(50);
    set_weight(1);
}
init()
{
     add_action("insert","insert");
}
insert(str){
     object weapon;
     if(!str){write("Insert what?\n");
return 1;}
     if(str !="clip"){write("Insert what?\n");return 1;}
     weapon=present("7.62",this_player());
     if(!weapon){write("Where do you want it dick?\n");return 1;}
     call_other(weapon,"load");write("You load the weapon.\n");
     say (capitalize(this_player()->query_real_name())+" loads the AK-47.\n");
     destruct(this_object());
     return 1;}
