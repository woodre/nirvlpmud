inherit"obj/weapon";
reset(arg) {
if(!arg) {
set_name("broom");
set_short("A broom");
set_long("A broom for sweeping up.\n");
set_class(5);
set_weight(2);
set_value(50);
}
}
init() {
	add_action("sweep","sweep");
}
sweep() {
	write("You sweep up some trash!\n");
	move_object(clone_object("players/vulture/misc/trash"),environment(this_player()));
destruct(this_object());
return 1;
}
