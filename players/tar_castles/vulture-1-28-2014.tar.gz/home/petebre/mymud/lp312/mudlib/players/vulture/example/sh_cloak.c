inherit"obj/armor";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("cloak of shadows");
set_alias("cloak");
set_short("Cloak of Shadows");
set_long(
"A dark billowing cloak that seems to blend in with the night.\n");
set_weight(1);
set_value(250);
set_ac(1);
set_type("misc");
}
