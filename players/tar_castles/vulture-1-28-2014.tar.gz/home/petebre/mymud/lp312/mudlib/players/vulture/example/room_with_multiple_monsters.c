inherit "room/room";
int i;
reset(arg) {
   if(!present("shadow captain")) {
      move_object(clone_object("players/sandman/MONSTERS/shadow_capt"), this_object());
   }
   if(!present("shadow guard")) {
      for(i=0;i<2;i++) {
         move_object(clone_object("players/sandman/MONSTERS/shadow_gd"), this_object());
      }
   }
   if(!arg) {
      set_light(1);
      short_desc=("A dead end");
      long_desc=
      "The path ends here abruptly. The trees on both sides of the path\n"
+     "intertwine with each other, blocking the sun. Sounds and movements\n"
+     "catch your attention from the shadowy forest surrounding you. At the\n"
+     "of the path stands three desperate looking characters.\n";
      dest_dir=
      ({
        "players/sandman/CUCKOO/land4", "south"
      });
   }
}
