inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
	set_name("mutant ant");
	set_alias("ant");
	set_short("A mutant ant");
	set_long("This is an ant that has been mutated by the Nuclear waste that floated in\n the air after the war.  It is tough and is willing to eat anything including you.\n");
	set_ac(8);
	set_wc(14);
set_al(-1000);
set_level(10);
	set_hp(150);
	money=(random(200)+325);
}
}
