id(str) { return str == "mad dog" || "bottle"; }
reset () {}
long() { write("You have a bottle of Mad Dog 20/20\n"); }
short() { return "A bottle of Mad Dog";  }
init() {
	add_action("drink"); add_verb("drink");
	add_action("drop_object"); add_verb("drop");
}

drink(arg) {
	say(call_other(this_player(),"query_name") + " drinks a bottle of Mad Dog.\n");
	write("You gulp down the cheap wine.\n");
	call_other(this_player(),"heal_self",15);
   call_other(this_player(),"drink_alcohol",6);
	write("the bottle is dested for your convenience.\n");
	destruct(this_object());
	return 1;
}
get() {return 1; }
query_weight() {return 1; }
query_value() { return 300; }
drop_object(str) {
	if (str == "all") {
		drop_object("mad dog");
		return 0;
}
	if (str == "wine") {
		drop_object("mad dog");
		return 0;
}
	if (!str || !id(str))
		return 0;
	write("The bottle smashes as it hits the ground.\n");
	say(call_other(this_player(),"query_name") + " wastes some good alcohol.\n");
destruct(this_object());
return 1;
}
