

inherit "room/room";

reset(arg) {

	set_light(1);
	short_desc = "Ritzville";
	no_castle_flag=0;
	extra_reset();
	long_desc = 
		"This is one of the few rich areas since the war.  The buildings are all huge \n"
		+ "and the hotels are expensive.  This is a place for movie stars and \n"
		+ "billionaires, not you.  If you don't like it then kill them.\n";
	dest_dir = 
	    ({
	"players/vulture/rooms/denver/colfax5", "east",
	});
}

query_light() {
    return 1;
}
query_room_maker() {
	return 1;
}

/*
	remove the comments around the "room is modified()" code
	below to prevent changes you have done to this room to
	to be lost useing the roommaker
*/
/*
room_is_modified() {
	return 1;
}
*/
/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

extra_reset() {
move_object(clone_object("players/vulture/monsters/jsilver"),this_object());
move_object(clone_object("players/vulture/monsters/alt"),this_object());
}
