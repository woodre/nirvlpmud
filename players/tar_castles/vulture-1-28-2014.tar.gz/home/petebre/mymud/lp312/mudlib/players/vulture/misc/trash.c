inherit"obj/treasure";
reset(arg) {
set_id("trash");
set_short("A piece of trash");
set_long("This is a piece of nasty ickey garbage.  Throw it away!\n");
set_value(10);
set_weight(1);
}
