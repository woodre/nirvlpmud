inherit"obj/weapon";
reset(arg) {
if(!arg) {
	set_name("claw");
	set_short("A cyberclaw");
	set_long("This is a cyberclaw from a cyber dog.  It is razor sharp and very deadly.\n");
	set_class(14);
	set_value(500);
	set_weight(2);
}
}
