inherit "room/room";
int i;
reset(arg){
   if(!present("bum")){
      for(i=0;i<2;i++){
         move_object(clone_object("/players/vulture/monsters/bum"),this_object());
      }
      if(!present("punk")){
         for(i=0;i<3;i++){
            move_object(clone_object("/players/vulture/monsters/punk2"),this_object());
         }
         if(!arg){
            set_light(1);
            short_desc="A downtown el platform";
            long_desc="This is a rough graffitti covered el\n"+
            "platform station.  You see a strangely\n"+
            "quiet street below you.  The station is\n"+
            "empty except for a few punks and bums.\n"+
            "Somehow this isn't the bight future you\n"+
            "were expecting in 2020 Chicago.\n";
            dest_dir=({
                  "/players/vulture/rooms/downtown/warand","down",});
         }
      }
   }
}
