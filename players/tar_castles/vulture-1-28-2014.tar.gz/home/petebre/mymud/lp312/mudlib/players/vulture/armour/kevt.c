inherit"obj/armor";
reset(arg) {
if(!arg) {
set_name("shirt");
set_alias("t-shirt");
set_short("A kevlar T-shirt");
set_long("A yuppie t-shirt for protecting those that don't need it.\n" +
	"It has I LOVE NEW YORK on the back.\n");
set_ac(2);
set_type("armor");
set_weight(2);
set_value(200);
}
}
