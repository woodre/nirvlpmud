inherit "obj/weapon";
reset(arg){
set_name("CyberClaws");
set_alias("claws");
set_long("A pair of retractable cyber claws\n"+
         "a powerful weapon but you cannot \n"+
         "pick up items while using them.\n");
set_class(18);
set_weight(0);
}
init(){
::init();
add_action("getit","take");
add_action("getit","get");
}
getit(){
return 1;
}
