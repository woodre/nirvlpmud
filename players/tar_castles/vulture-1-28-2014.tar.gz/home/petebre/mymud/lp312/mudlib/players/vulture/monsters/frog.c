inherit"obj/monster";
reset(arg) {
::reset(arg);
	if(!arg) {
	set_name("deadly frog");
	set_alias("frog");
	set_short("a deadly frog");
	set_long("This is a very poisonous frog that has crawled out from the depths of hell.\n");
	set_level(15);
	set_ac(12);
set_al(-1000);
	set_wc(20);
	set_hp(225);
	money=(875);
	set_chat_chance(3);
	load_chat("Frog says: Ribbit!");
}
}
