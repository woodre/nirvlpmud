inherit"obj/monster";
reset(arg) {
::reset(arg);
if(!arg) {
	set_name("alt");
	set_alias("Alt");
	set_level(11);
	set_ac(9);
	set_wc(15);
	set_hp(165);
	set_race("human");
	set_al(-1000);
	money=(500);
	set_short("Alt");
	set_long("This is alt...Johnny's girlfriend.  She is the finest girl you have ever seen.\n If only johnny wasn't here and you were a cute guy.\n");
}
}
