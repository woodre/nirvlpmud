inherit"obj/monster";
reset(arg){
::reset(arg);
if(!arg){
set_name("major punk");
set_alias("major punk");
set_short("A Major punk");
set_long("I am a punk...mess with me and see what pain is all about.\n");
set_ac(14);
set_wc(24);
set_al(-1000);
set_race("human");
set_level(17);
set_hp(425);
money=(300);
set_chat_chance(5);
load_chat("Punk says:  I shot yo mamma, you wimp!\n");
move_object(clone_object("players/vulture/misc/drugs/hellfire"),this_object());
}
}
