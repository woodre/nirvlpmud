inherit "/obj/weapon.c";
int bullets;
reset(arg){
     int bullets;
     bullets = 0;
     set_name("gun");
     set_alias("22");
     set_short("Federated Arms X-22");
     set_long("This is a small handgun common in the new world disorder.\n"+
     "You probably won't kill anyone with it in one shot, but\n"+
     "it will hurt.\n");
     set_class(5);
     set_value(200);
     set_weight(2);
}
init() {
::init();
    add_action("fire","fire");}
fire(str) {
    object target;
   target=present(find_living(str), environment(this_player()));
    if(!str) { write("Who do you wish to shoot?\n"); return 1;}
    if(!target->query_npc()){write("You can't shoot players!\n");
    return 1;}
    if(bullets <= 0){write("You are out of ammo.\n");
return 1;
}
    if(!target) {write("Shoot who dick?  Shoot yourself.\n"); return 1;}
    call_other(target, "hit_player", random(6)+1);
    write("You shoot the X-22\n");
    call_other(target, "attacked_by", this_player());
    say("CRACK!");
    bullets = bullets -1;
    return 1;
}
load(){
   bullets = 8;
}
