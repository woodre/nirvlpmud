inherit "/obj/weapon.c";
reset(arg){
set_name("alchemy");
set_short("Alchemy");
set_long("This is electricity.  It is on of the \n"+
         "five magics you must master.\n");
set_weight(0);
set_class(18);
set_value(20);
}
