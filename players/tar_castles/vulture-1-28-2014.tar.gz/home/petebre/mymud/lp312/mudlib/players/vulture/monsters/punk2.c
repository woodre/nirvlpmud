inherit "obj/monster";
reset(arg){
set_name("punk");
set_alias("street punk");
set_short("A street punk");
set_long("This guy is a streetwise punk.  He looks like\n"+
       "he could rip your head off if he wanted to\n"+
         "Maybe you think twice before you mess with him\n");
set_ac(10);
set_wc(15);
set_al(-100);
set_level(10);
set_hp(212);
money=(random(200)+200);
set_chat_chance(10);
load_chat("Punk say: What are you looking at?\n");
load_chat("Punk says: Did I ask you?  I don't think so!1\n");
}
