#include "/sys/lib.h"
inherit "/room/room";

reset(arg) {
	::reset(arg);
	if(arg) return;
	set_light(1);
	short_desc = "Uj's place";
	long_desc = "A simple workroom without furnishings.\n";
	dest_dir = ({ "room/vill_green","green" });
	}
