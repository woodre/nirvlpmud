#include "/players/nikki/ansi.h"
inherit "room/room";

reset(arg) {
   if(!arg) {
set_light(1);
short_desc = HIB+"Blasting Zone!"+NORM;
}}
long () {
write (HIY+"                                        %"+HIR+"%"+HIY+"%"+HIR+"%"+HIY+"%"+HIR+"%"+HIY+"%"+HIR+"."+HIY+"."+HIR+"^"+HIY+"'"+HIR+"*"+HIY+"$"+HIR+"e"+HIY+".\n"+
"                               $"+HIR+"%"+HIY+" d"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIR+"$"+HIY+"$"+HIR+"%"+HIY+" '"+HIR+"*"+HIY+"$"+HIR+"`\n"+
"                             %"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+" '"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"%"+HIR+"."+HIY+"'"+HIR+"$"+HIY+"c\n"+
"                         %"+HIR+"$"+HIY+"$"+HIR+"%"+HIY+"   '"+HIR+"'"+HIY+"   ^"+HIR+"'"+HIY+"^"+HIR+"*"+HIY+"*"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"%"+HIR+"."+HIY+"^"+HIR+"$"+HIY+":\n"+
"");
write(""+
"                       %"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"'"+HIY+"'"+HIR+"'"+HIY+"           `"+HIR+"!"+HIY+"?"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"%"+HIR+"."+HIY+"^\n"+
"                     ."+HIR+"$"+HIY+"$"+HIR+"                   ~"+HIY+"!"+HIR+")"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"%\n"+
"                    %"+HIY+"$"+HIR+"$"+HIY+"                 *"+HIR+"*"+HIY+"@"+HIR+"b"+HIY+"."+HIR+" `"+HIY+"'"+HIR+")"+HIY+")"+HIR+"."+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$\n"+
"                   %"+HIR+"^"+HIY+"'"+HIR+"                           `"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+".\n"+
"                  %"+HIY+"$"+HIR+"%"+HIY+"                      ."+HIR+"."+HIY+"      '"+HIR+"*"+HIY+"*"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$\n"+
"");
write(""+
"                 :"+HIY+"$"+HIR+"$"+HIY+"           "+HIR+"."+HIY+"        ."+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"%"+HIR+"."+HIY+"    ."+HIR+"."+HIY+"  '"+HIR+" `"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$\n"+
"                 $"+HIR+"$"+HIY+"            $"+HIR+"          ^"+HIY+"*"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"%"+HIY+"   '"+HIR+"      $"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$\n"+
"                %"+HIY+"$"+HIR+"$"+HIY+"            $"+HIR+"%"+HIY+"    ."+HIR+"*"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"*"+HIR+"."+HIY+"'"+HIR+"*"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"."+HIR+"       $"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$\n"+
"                $"+HIR+"$"+HIY+"$"+HIR+"            $"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"%"+HIR+" '"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"  ="+HIY+"="+HIR+" $"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$\n"+
"                $"+HIY+"$"+HIR+"$"+HIY+"            $"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"%"+HIR+"   '"+HIY+"$"+HIR+"'"+HIY+" *"+HIR+" ?"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$\n"+
"                $"+HIR+"$"+HIY+"$"+HIR+"            '"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"%"+HIY+","+HIR+","+HIY+"."+HIR+"."+HIY+"."+HIR+"*"+HIY+"$"+HIR+" $"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$\n"+
"               '"+HIR+"$"+HIR+"$"+HIY+"$"+HIR+"             `"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIY+"$"+HIR+" '"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$\n"+
"");
write(""+
"                $"+HIY+"$"+HIR+"                  `"+HIY+"'"+HIR+"'"+HIY+"'"+HIR+"'"+HIY+"'"+HIR+"'"+HIY+"`"+HIR+"       `"+HIY+"'"+HIR+"*"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"&"+HIY+" $"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"%\n"+
"                $"+HIR+"  %"+HIY+"$"+HIR+"                                  '"+HIY+"$"+HIR+"$"+HIY+"."+HIR+" '"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$\n"+
"                `"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"`"+HIR+"                                   '"+HIY+"$"+HIR+"."+HIY+" "+HIR+"%"+HIY+"%"+HIR+"%"+HIY+"$\n"+
"                 $"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"%"+HIY+"                                   '"+HIR+"$"+HIY+"%"+HIR+"."+HIY+" ."+HIR+"%\n"+
"                 `"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"`"+HIY+"                                   '"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$\n"+
"                  $"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"                                    $"+HIY+"$"+HIR+"$"+HIY+"'\n"+
"                   $"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"  %"+HIY+"%"+HIR+"                                $"+HIY+"$"+HIR+",\n"+
"");
write(""+
"                    $"+HIY+"$"+HIR+"*"+HIY+"*"+HIR+"<"+HIY+"$"+HIR+"$"+HIY+"                                $"+HIR+"'\n"+
"                     `"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"%"+HIY+"%"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"%"+HIY+"."+HIR+"                        '\n"+
"                      ^"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"%\n"+
"                        `"+HIY+"'"+HIR+"*"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$"+HIR+"$"+HIY+"$\n"+
"\n"+NORM);
}


