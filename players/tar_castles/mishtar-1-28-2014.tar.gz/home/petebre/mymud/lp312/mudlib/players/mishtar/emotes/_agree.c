#include "all.h"

int cmd_agree(string arg)
{
	if(ghost()) return 0;
	if(!arg)
	{
		write("You nod in agreement.\n");
		say(TPN+" nods in agreement.\n",TP);
		return 1;
	}
	else
	{
		object who;
		if(!(who = arg_check(arg))) return 0;
		else if(who = present(arg, environment(TP)))
		{
			write("You nod in agreement with "+FPN+".\n");
			say(TPN+" nods in agreement with "+FPN+".\n", who);
			tell_object(who, TPN+" nods in agreement with you.\n");
		}
	else
	{
		write("You nod in agreement with "+FPN+" from afar.\n");
        tell_object(who, TPN+" nods in agreement with you from afar.\n");
	}
		return 1;
}}