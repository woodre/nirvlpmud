#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "obj/weapon";


int i;

reset(arg) {
   ::reset(arg);
   if(arg) return;
    set_name(HIK+"obsidian claws"+NORM);
    set_alias("claws");
	set_short(HIK+"A pair of obsidian claws"+NORM);
	set_long("\n"+HIK+
		"A vicious set of obsidian dragon claws. Traces of\n"+
		"dried blood and gore still crust their tips."+NORM+"\n");
	set_class(10000000);
	set_weight(2);
	set_value(0);
	set_type("exotic");

    set_hit_func(this_object());

    message_hit=({
    ""+HIR+"ravaged"+NORM+""," into small pieces with her claws",  
    ""+RED+"slashed"+NORM+""," leaving deep gashes with her claws",
    ""+HIK+"tore "+NORM+"into"," causing gaping wounds with her claws",
    ""+HIK+"ripped "+NORM+"open","'s flesh with her claws",
    ""+HIK+"pierced"+NORM+""," deeply with her claws",
    ""+CYN+"scraped"+NORM+""," with her claws",
    ""+CYN+"scratched"+NORM+""," lightly with the tips of her claws"});
}
status query_wear() { return 0; }



