#include <ansi.h>
inherit "players/vertebraker/closed/std/room.c";

reset (int arg){
	if (arg) return;
	set_light(1);
	set_short(HIK+"Town of Erethor"+NORM);
	set_long("\n"+
		"The marble roadway ends in a large square dominated by an ornate well.\n"+
		"Another marble road crosses the square to the east and west towards\n"+
		"other parts of town.  Just ahead rises a large tower made of crystal\n"+
		"shimmering in the sunlight.  Off to the west, the tall spires of a\n"+
		"grand temple loom on the horizon and to the east, an ornate stone wall\n"+
		"runs adjacent to the road until it melds with a fortified building made\n"+
		"of stone.  Back to the south, the road eventually leads to the crystal\n"+
		"gates of Erethor glittering in the sunshine.\n");
		
	add_item("road",
			 "The two wide marble roadways come together to form Erethor's\n"+
			 "town square at their intersection"); /*Needs work*/
	add_item("square",
			 "At the center of the square, the marble stones have been inlaid\n"+
			 "with multi-colored crystal shards to create a glittering mosaic\n"+
			 "of a great dragon");
	add_item("well",
			 "The well is made of blocks cut from a rich dark stone and its winch\n"+
			 "and bucket are carved from a deep red oak.  The well forms the eye\n"+
			 "of the crystal dragon mosaic\n");
	add_item("winch",
			 "The well's winch is delicatedly carved from oak down to the last gear.\n"+
			 "The handle "+HIK+"turns"+NORM+" with minimal effort and without a sound\n");
	add_item("bucket",
			 "The bucket is intricately carved from oak and forms a pair of dragons\n"+
			 "coiled around a deep bowl.  The rope holding the bucket is clutched in\n"+
			 "in their jaws");
	add_item("tower",
			 "A tall crystal spire stretches towards the sky above.  Its chisled crystalin\n"+
			 "surface glitters as the light bathes across its surface.  The fine outline\n"+
			 "of a door can barely be seen at its base");
	add_item("spires",
			 "The four spires reach for the sky above like grasping fingers");
	add_item("temple",
			 "The dark hewn structure of a temple dominates the western end of town");
	add_item("wall",
			 "A well constructed and sturdy stone wall blocks your view \n"+
			 "of whatever lies beyond");
	add_item("building",
			 "The building seems to grow from the wall as it stretches eastward down the road");
	add_item("horizon",
			 "The horizon is shrouded in tall the tall trees of the forest beyond the crystal\n"+
			 "walls of Erethor");
	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");
	
	add_exit("/players/mishtar/varminthor/erethor/eroad5.c","east");
	add_exit("/players/mishtar/varminthor/erethor/eroad4.c","west");
	add_exit("/players/mishtar/varminthor/erethor/eroad2.c","south");
	add_exit("/players/mishtar/varminthor/erethor/etower1.c","enter");
}
