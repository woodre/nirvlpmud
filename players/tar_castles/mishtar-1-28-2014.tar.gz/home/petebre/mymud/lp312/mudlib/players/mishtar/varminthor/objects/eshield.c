#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg);
	set_alias("shield");
	set_name(HIK+"an Erethorian shield"+NORM);
	set_short(HIK+"Erethorian shield"+NORM);
    set_long("\n"+
		"A sturdy looking shield made of the silvery metal known as\n"+
		"mithral.  It's surface is etched in gold with the seal of \n"+
		"Erethor: An ancient golden dragon coiled around a crystal \n"+
		"tower.\n");
    set_ac(2);
    set_weight(1);
	set_value(1000+random(500));
	set_type("shield");
}