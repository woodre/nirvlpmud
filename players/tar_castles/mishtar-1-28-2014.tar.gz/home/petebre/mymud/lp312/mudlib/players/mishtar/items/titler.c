#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "obj/treasure";
reset(arg){
	if(arg) return;
	set_id("titler");
	set_alias("titler");
	set_short(HIK+"A titler"+NORM);
	set_weight(0);
	set_value(0);
}

drop(){return 1;}
init(){
	add_action("set_guild","set_guild");}
set_guild(str){
	int s;
    string *words;
	string who,what;
	if(!str) return 0;
	if(sscanf(str,"%s %s",who,what));
	if(!find_player(who)) { write("Target is not in play.\n"); return 1; }
	  words = explode(what, "$");
      s = sizeof(words);
      while(s --)
        if(find_player(who)->replace_ansi(words[s]))
          words[s] = (string)find_player(who)->replace_ansi(words[s]);
      str = (implode(words, "")) + esc + "[0m";
	find_player(who)->set_guild_name(str);
	tell_object(find_player(who),"Mishtar has changed your guild name to "+str+".\n");
	write("You have set "+capitalize(who)+"'s guild name to "+str+".\n");
	return 1; }