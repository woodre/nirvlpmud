#include <ansi.h>

inherit "/obj/monster.c";

reset(arg) {
	::reset(arg);
	if(arg) return;
	set_alias("talorn");
	set_name("talorn");
	set_alt_name("shopkeep");
	set_race("elf");
	set_gender("male");
	set_short(HIK+"Talorn the Shopkeeper"+NORM);
	set_long(
	  "Talorn is a large, sturdy half elf wearing a simple black leather jerkin \n"+
	  "and breaches.  Although his hair is thinning and grayed, his well muscled \n"+
	  "frame has yet to give way to the passing of years.  He bares the wild look \n"+
	  "of insanity in his eyes as he looks up from his ledgers, but, within moments, \n"+
	  "it fades as he focuses a curious eye on you. \n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
