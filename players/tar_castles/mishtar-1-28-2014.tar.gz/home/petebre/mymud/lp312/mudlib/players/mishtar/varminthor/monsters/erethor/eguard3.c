#include <ansi.h>
#include "/players/mishtar/random.h"
#include "/players/mishtar/defs.h"

inherit "/obj/monster.c";

string hair, gen, gen3, genp, eyes;

reset(arg) {
	::reset(arg);
	if(arg) return;
	get_random();
	set_alias("peacekeeper");
	set_name("peacekeeper");
	set_alt_name("keeper");
	set_race("elf");
	set_gender((gen));
	set_short(HIK+"Erethorian Peacekeeper"+NORM);
	set_long(
	  "This young elven warrior slowly patrols the streets and alleys of Erethor. \n"+
	  CGP+" watchful eyes dart about warily as "+gen3+" grips "+genp+" ranseur tightly.  "+CG3+"\n"+
	  "wears a suit of brightly polished chainmail over which "+gen3+" has donned a \n"+
	  "dark purple tabard tied at the waist with a golden sash.  "+CGP+" armaments \n"+
	  "barely make a whisper as "+gen3+" passes. \n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
