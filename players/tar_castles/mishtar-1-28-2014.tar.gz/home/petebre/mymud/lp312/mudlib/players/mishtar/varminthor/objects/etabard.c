/*Mishtar -> created 10/22/03*/
#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg);
	set_alias("tabard");
	set_name(HIK+"an Erethorian tabard"+NORM);
	set_short(HIK+"Erethorian tabard"+NORM);
	set_long("\n"+
		"A dark purple silk tabard emblazoned on the front and back with the \n"+
		"seal of Erethor.  It is often worn by Erethor's city guard and tied \n"+
		"at the waist with a golden silk sash.\n");
    set_ac(0);
    set_weight(1);
	set_value(1000);
	set_type("button");
}