/*Erethor: eroad6.c
 *Wizard:  Mishtar
 *Created: 1/13/04
 *Edited:  3/11/04,3/18/04
 *Realm:   Erethor
 */

#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

reset (int arg){
	if (arg) return;
	set_light(1);
	set_short(HIK+"Town of Erethor"+NORM);
	set_long(HIK+"Town of Erethor"+NORM+"[n,e,w]\n"+
		"The marble roadway ends in a small circle shared by several buildings. \n"+
		"Ahead stands a stalwart stone building with a worn oak sign swinging \n"+
		"above the door.  To the north lies a grand temple carved from two oak \n"+
		"trees, its four long spires grasping for the sky above.  To the south \n"+
		"lies a well kept building made of stone and wood.  Its exotic design \n"+
		"lends a feeling of importance to the structure.  Back east lies the \n"+
		"hub of Erethor, the town square.\n");
		
	add_item("road",
			 "A wide marble road winds throughout the town. The elves \n"+
			 "have taken great pains to maintain its upkeep");
	add_item("windows",
			 "The window is made billiantly colored pieces of stained glass that \n"+
			 "obscures the goings on inside the building");
	add_item("church",
			 "Two dark oak trees slowly twisted as they grew and eventuall \n"+
			 "A two story building made from a fine dark oak.  From inside, the \n"+
			 "glitter of the fire dances acrossed the stained glass window");
	add_item("residence",
			 "Well trimmed bushes line the stone walkway towards the small oak \n"+
			 "home.  The house seems molded from the strange, squaty oak tree");
	add_item("spires",
			 "The four spires reach for the sky above like grasping fingers");
	add_item("temple",
			 "The dark hewn structure of a temple dominates the western end of town");
	add_item("horizon",
			 "The horizon is shrouded in tall the tall trees of the forest beyond the crystal\n"+
			 "walls of Erethor");
	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");

	add_exit("/players/mishtar/varminthor/erethor/echurch1.c","north");
	add_exit("/players/mishtar/varminthor/erethor/eroad4.c","east");
	add_exit("/players/mishtar/varminthor/erethor/ejail1.c","west");
}
init()
{
	::init();
		add_action("north","north",1);
		add_action("east","east",1);
		add_action("west","west",1);
}
/*Exits*/	
north()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/echurch1.c";
	write(HIK+"You humbly enter the church.\n"+NORM);
	say(TPN+" humbly enters the church.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/echurch1.c");
	command("look",TP);
	return 1;
}
east()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/eroad4.c";
	write(HIK+"You wander down the road.\n"+NORM);
	say(TPN+"wanders down the road.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad4.c");
	command("look",TP);
	return 1;
}
west()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/ejail1.c";
	write(HIK+"You stroll into the jail.\n"+NORM);
	say(TPN+" strolls into the jail.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/ejail1.c");
	command("look",TP);
	return 1;
}