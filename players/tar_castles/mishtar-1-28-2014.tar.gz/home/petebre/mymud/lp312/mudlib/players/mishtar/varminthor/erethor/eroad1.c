#include <ansi.h>
inherit "players/vertebraker/closed/std/room.c";
reset (int arg){
	if (arg) return;
	set_light(1);
	set_short(HIK+"Town of Erethor"+NORM);
	set_long("\n"+
		"A well kept, marble roadway stretches northward through town. \n"+
		"In the distance stands a tall crystal tower that shines in \n"+
		"the sunlight.  Elves of all types hussle about town minding \n"+
		"their own business.  Now and again a town guard can be seen \n"+
		"patrolling the streets.  To the south rise the large crystal \n"+
		"gates of Erethor, to the east resides a small, cozy wooden \n"+
		"home, and to the west appears to be a shop with a small sign \n"+
		"swinging idly above the door.\n");
		
	add_item("road",
			 "A wide marble road winds throughout the town. The elves \n"+
			 "have taken great pains to maintain its upkeep");
	add_item("gates",
			 "The large gates are delicately crafted from a brilliant red\n"+
			 "crystal that sparkles in the dim light of the clearing");
	add_item("elves",
			 "The elves vary widely; from the savage looking, wild \n"+
			 "haired wilder elf to the well-groomed and stately \n"+
			 "grey elf dressed in fine silken livery");
	add_item("sign",
			 "On a weather beaten sign, written in flowing elven script:\n"+
			 "	      "+HIK+"Korvanthor's Antiquities"+NORM);
	add_item("tower",
			 "A tall, spiraling tower lies ahead, glittering in the sunlight");
	add_item("home",
			 "The small house has been carefully tended.  The shutters \n"+
			 "have been opened and a couple of small pies left to cool \n"+
			 "in the soft breeze.  A small garden dominates the yard \n"+
			 "out front where a few herbs and vegetables can be seen \n"+
			 "growing amidst the coal black dirt");
	add_item("shop",
			 "A small weather beaten sign hangs above the door of this \n"+
			 "well kept shop.  The door has been proped open with a \n"+
			 "large rock delicately carved to look like dragon");

	add_smell("pies",
			  "The delicious odor of fresh baked pies tickles your nose \n"+
			  "as it is carried past on the soft breeze");

	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");
	
	add_exit("/players/mishtar/varminthor/erethor/eroad2.c","north");
	add_exit("/players/mishtar/varminthor/erethor/egate.c","south");
	add_exit("/players/mishtar/varminthor/erethor/eres1.c","east");
	add_exit("/players/mishtar/varminthor/erethor/eshop.c","west");
}