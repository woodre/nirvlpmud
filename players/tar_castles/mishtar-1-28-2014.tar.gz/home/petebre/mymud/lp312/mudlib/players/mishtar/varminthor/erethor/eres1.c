#include <ansi.h>
inherit "players/vertebraker/closed/std/room.c";
reset (int arg){
	if (arg) return;
	set_light(1);
	set_short(HIK+"An elven residence"+NORM);
	set_long("\n"+
		"The small oaken door opens up into this cozy little abode. \n"+
		"The small fire in a stone fireplace licks at the bottom of a \n"+
		"stew pot as it cooks slowly.  The pleasant aroma of the soup \n"+
		"within floats about the room and melds with the scent of the \n"+
		"pies cooling on the window sill.  Soft silken tapestries hang \n"+
		"on the walls for added warmth during the cool nights as well \n"+
		"as add a decorative feel to the home.\n");
		
	add_item("fire",
			 "The small golden fire crackles and hisses as it dances in \n"+
			 "the stone fireplace");
	add_item("fireplace",
			 "A smooth stoned fireplace sits tucked in the back wall of \n"+
			 "the house providing limited warmth and some light");
	add_item("pot",
			 "A finely made iron pot hangs over the fire slowly simmering \n"+
			 "a chicken and vegetable stew");
	add_item("pies",
			 "A pair of fresh, golden brown pies sit cooling on the sill");
	add_item("tapestries",
			 "The tapestries are made of fine silk of different colors. \n"+
			 "Each one depicts a different scene of elven life");
	
	add_smell("soup",
			  "The delicious aroma of slowly simmering chicken and fresh \n"+
			  "cut vegetables floats around the pot.");
	add_smell("pies",
			  "The delightful scent of warm berries wafts from the pies \n"+
			  "on the windowsill.");

	add_listen("main",
			   "The whispered crackle of the fire and a soft gurgling of the \n"+
			   "boiling stew compete with the cacauphony of noises floating \n"+
			   "in from the window.");
	
	add_exit("/players/mishtar/varminthor/erethor/eroad1.c","west");
}