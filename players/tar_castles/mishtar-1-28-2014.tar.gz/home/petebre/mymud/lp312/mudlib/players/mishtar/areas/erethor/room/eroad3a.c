/*Erethor: eroad3a.c
 *Wizard:  Mishtar
 *Created: 1/26/04
 *Edited:  2/24/04,3/3/04
 *Realm:   Erethor
 */

#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

reset (int arg)
{
	if (arg) return;
	set_light(1);
	set_short(HIK+"Town of Erethor"+NORM);
	set_long(HIK+"Town of Erethor"+NORM+"[s,e,w,enter]\n"+
		"The marble roadway ends in a large square dominated by an ornate well.\n"+
		"Another marble road crosses the square to the east and west towards\n"+
		"other parts of town.  Just ahead rises a large tower made of crystal\n"+
		"shimmering in the sunlight.  Off to the west, the tall spires of a\n"+
		"grand temple loom on the horizon and to the east, an ornate stone wall\n"+
		"runs adjacent to the road until it melds with a fortified building made\n"+
		"of stone.  Back to the south, the road eventually leads to the crystal\n"+
		"gates of Erethor glittering in the sunshine.\n");
		
	add_item("road",
			 "The two wide marble roadways come together to form Erethor's\n"+
			 "town square");
	add_item("square",
			 "At the center of the square, the marble stones have been inlaid\n"+
			 "with multi-colored crystal shards to create a glittering mosaic\n"+
			 "of a great dragon");
	add_item("well",
			 "The well is made of blocks cut from a rich dark stone and its winch\n"+
			 "and bucket are carved from a deep red oak.  The well forms the eye\n"+
			 "of the crystal dragon mosaic\n");
	add_item("winch",
			 "The well's winch is delicatedly carved from oak down to the last gear.\n"+
			 "The handle "+HIK+"turns"+NORM+" with minimal effort and without a sound\n");
	add_item("bucket",
			 "The bucket is intricately carved from oak and forms a pair of dragons\n"+
			 "coiled around a deep bowl.  The rope holding the bucket is clutched in\n"+
			 "in their jaws");
	add_item("tower",
			 "A tall crystal spire stretches towards the sky above.  Its chisled crystalin\n"+
			 "surface glitters as the light bathes across its surface.  The fine outline\n"+
			 "of a door can barely be seen at its base");
	add_item("spires",
			 "The four spires reach for the sky above like grasping fingers");
	add_item("temple",
			 "The dark hewn structure of a temple dominates the western end of town");
	add_item("wall",
			 "A well constructed and sturdy stone wall blocks your view \n"+
			 "of whatever lies beyond");
	add_item("building",
			 "The building seems to grow from the wall as it stretches eastward down the road");
	add_item("horizon",
			 "The horizon is shrouded in tall the tall trees of the forest beyond the crystal\n"+
			 "walls of Erethor");
	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");
	
	add_exit("/players/mishtar/areas/erethor/eroad5.c","east");
	add_exit("/players/mishtar/areas/erethor/eroad4.c","west");
	add_exit("/players/mishtar/areas/erethor/eroad2.c","south");
	add_exit("/players/mishtar/areas/erethor/etower1.c","enter");
}

init()
{
	::init();
		add_action("enter","enter");
		add_action("south","south");
		add_action("south","s");
		add_action("east","east",1);
		add_action("west","west",1);
}
/*Exits*/	
enter()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/etower1.c";
	write(HIK+"You cautiously enter the crystal tower.\n"+NORM);
	say(TPN+" cautiously enters the crystal tower.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/etower1.c");
	command("look",TP);
	return 1;
}

south()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/eroad2.c";
	write(HIK+"You wander down the road.\n"+NORM);
	say(TPN+" wanders down the road.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad2.c");
	command("look",TP);
	return 1;
}

east()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/eroad5.c";
	write(HIK+"You wander down the road.\n"+NORM);
	say(TPN+" wanders down the road.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/eres5.c");
	command("look",TP);
	return 1;
}

west()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/eroad4.c";
	write(HIK+"You wander down the road.\n"+NORM);
	say(TPN+" wanders wanders down the road.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad4.c");
	command("look",TP);
	return 1;
}