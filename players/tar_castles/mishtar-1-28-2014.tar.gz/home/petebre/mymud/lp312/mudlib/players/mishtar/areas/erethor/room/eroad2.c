/*Erethor: eroad2.c
 *Wizard:  Mishtar
 *Created: 1/16/04
 *Edited:  5/29/04
 *Realm:   Erethor
 */

#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

long(){
		if ((int)this_player()->query_brief() != 2)
		write(short()+"\n"); ::long(); 
	  }

reset (int arg)
{
	if (arg) return;
	set_light(1);
	set_short(GRN+"Town of Erethor"+NORM);
	set_long(GRN+
		"The marble roadway stretches to the north and south through the. \n"+
		"heart of town.  The sun glimmers as it passes through the tower \n"+
		"of crystal to the north.  Down the road to the north lies the \n"+
		"town square and a crossroads leading east and west.  The sounds \n"+
		"of combat can be heard behind a ornate stone wall to the east \n"+
		"and to the west is a quaint wooden building with a stained glass \n"+
		"window in the shape of a mug.  The road south leads back to the \n"+
		"great crystal gates and the forest beyond.\n"+NORM);
		
	add_item("road",
			 "A wide marble road winds throughout the town. The elves \n"+
			 "have taken great pains to maintain its upkeep");
	add_item("tavern",
			 "A two story building built from a fine dark oak. Inside \n"+
			 "the fires are always burning offering a warm welcome to \n"+
			 "any newcomers to the city of Erethor");
	add_item("wall",
			 "A well constructed and sturdy stone wall blocks your view \n"+
			 "of whatever lies beyond");
	
	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");
	
	add_exit("/players/mishtar/areas/erethor/room/eroad3a.c","north");
	add_exit_msg("north", ({GRN+"You wander down the road.\n"+NORM,"wanders down the road.\n"}));

	add_exit("/players/mishtar/areas/erethor/room/eroad1.c","south");
	add_exit_msg("south", ({GRN+"You wander down the road.\n"+NORM,"wanders down the road.\n"}));

	add_exit("/players/mishtar/areas/erethor/room/etavern.c","west");
	add_exit_msg("west", ({GRN+"You stroll into the tavern.\n"+NORM,"strolls into the tavern in search of drinks.\n"}));

}
