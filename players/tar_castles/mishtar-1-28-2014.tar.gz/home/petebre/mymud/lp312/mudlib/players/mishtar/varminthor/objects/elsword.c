#include <ansi.h>
inherit "obj/weapon";

int i;

reset(arg) {
   ::reset(arg);
   if(arg) return;
    set_name(HIK+"an Erethorian longsword"+NORM);
    set_alias("sword");
	set_short(HIK+"Erethorian longsword"+NORM);
	set_long("\n"+
		"An exquiste sword made of a silvery metal.  The long, straight blade is \n"+
		"double edged and has a small ridge running down its center.  The hilt \n"+
		"resembles a dragon in flight with its outstreched wings creating the \n"+
		"cross guard and the blade stretchs forth like a jet of flame from its \n"+
		"jaws.  Atop the pummel rests a small, flawless bloodstone that shines \n"+
		"with an inner fire.\n");
	set_class(18);
	set_weight(2);
	set_value(1000);
	set_type("sword");

      set_hit_func(this_object());
}
weapon_hit(attacker) {
  i=random(10);
  if (i>5) {
	say(this_player()->query_name()+"'s longsword "+HIR+"SLICES"+NORM+" through its foe!\n");
	write("You're longsword "+HIR+"SLICES"+NORM+" through its foe.\n");
  return 10;
    }
return;
}
