#include <ansi.h>

inherit "/obj/monster.c";

/*id(str) { return str == "kor" || str == "korvanthor" || str == "shopkeeper"; }*/

reset(arg) {
	::reset(arg);
	if(arg) return;
	set_alias("korvanthor");
	set_name("korvanthor");
	set_alt_name("kor");
	set_race("elf");
	set_gender("male");
	set_short(MAG+"Korvanthor the Shopkeeper"+NORM);
	set_long(
	  "Korvanthor is a large, sturdy half elf wearing a simple black leather jerkin \n"+
	  "and breaches.  Although his hair is thinning and grayed, his well muscled \n"+
	  "frame has yet to give way to the passing of years.  He bares the wild look \n"+
	  "of insanity in his eyes as he looks up from his ledgers, but, within moments, \n"+
	  "it fades as he focuses a curious eye on you. \n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
