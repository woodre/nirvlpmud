#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg);
	set_alias("plate");
	set_name(HIK+"Erethorian Plate"+NORM);
	set_short(HIK+"Erethorian Plate"+NORM);
    set_long("\n"+
		"This simple yet delicately crafted suit of platemail is \n"+
		"of elvish design and made from mithral.  It appears to \n"+
		"be standard issue amongst Erethor's elite guards. The \n"+
		"suit's breastplate is etched in gold with the seal of \n"+
		"Erethor: A depiction of an ancient gold dragon coiled \n"+
		"around a crystal tower.\n");
    set_ac(4);
    set_weight(2);
	set_value(2000+random(500));
	set_type("armor");
}