/*Just a toy Miso asked me for in a moment of boredness.*/
/*Mishtar -> created 10/3/03, updated 12/25/03*/

#include <ansi.h>
#include "/bin/ghost.c"
#include "/players/mishtar/defs.h"

inherit "obj/treasure";

query_auto_load() { return "players/mishtar/items/mbong.c:";}
extra_look(){
	if(environment() == this_player()) {
		write("Your skin is covered in a thin layer of "+HIK+"obsidian "+NORM+"scales.\n"+
		"You are a devoted follower of "+HIK+"Mishtar "+RED+"the "+HIK+"Lord "+RED+"of "+HIK+"Dragons."+NORM+"\n");}
	else {
		write(ENVQN+"'s skin is covered in a thin layer of "+HIK+"obsidian "+NORM+"scales.\n"+
		ENVQN+" is a devoted follower of "+HIK+"Mishtar "+RED+"the "+HIK+"Lord "+RED+"of "+HIK+"Dragons."+NORM+"\n");}}

reset(arg) {
  if(arg) return;
  set_id("bong");
  set_alias("bong");
  set_short(HIK+"A four foot glass bong"+NORM);
  set_long("\n"+HIK+
		   "A large 4 foot glass bong.  It is made in the shape of a dragon\n"+
		   "with the bowl held in its jaws.  There is a small set of runes\n"+
		   "inscribed on the bowl."+NORM+"\n");
  set_weight(0);
  set_value(0);
}

drop(){ return 1; }

init() {
	add_action("cmd_bhelp","bhelp");
	add_action("cmd_puff","puff");
	add_action("cmd_read","read");
	add_action("cmd_lbong","lbong");
	add_action("cmd_beyes","beyes");
	add_action("cmd_bcough","bcough");
	add_action("cmd_pbong","pbong");
	add_action("cmd_tell","tell");
	add_action("cmd_say","say");
	add_action("cmd_say"); add_xverb("'");
}
int cmd_bhelp(){
	tell_object(TP,
		"Commands available:\n"+
		"bhelp        -this file.\n"+
		"pbong        -pack your bong, Duh?\n"+
		"puff         -take a hit from your bong.\n"+
		"lbong        -light your bong of course.\n"+
		"beyes        -a nifty lil effect for your eyes.\n"+
		"bcough       -just another amusing emote effect.\n");
	return 1;}

cmd_read(str){
	if(str != "runes"){ write("Read what?\n"); return 1;}
	if(str == "runes"){
		say(TPN+" reads some runes on the bowl of "+TPP+" bong.\n",TP);
		tell_object(TP, "You decipher the runes to read: Use bhelp for a list of abilities.\n");
		return 1;}}

int cmd_pbong(){
	say(TPN+" pulls out a sack of "+GRN+"weed"+NORM+" and packs a large bunch into the bowl of "+TPP+" bong.\n",TP);
	tell_object(TP, "You pull out a sack of "+GRN+"weed"+NORM+" and pack a large bowl into the mouth of the dragon.\n");
	return 1;}

int cmd_puff(){
	say(TPN+" takes a long hit from "+TPP+" bong.\n",TP);
	tell_object(TP, "You take a long hit from your bong.\n");
	return 1;}

int cmd_lbong(){
	say(TPN+" pulls out "+TPP+" trusty bic lighter and "+HIY+"sparks "+NORM+TPP+" bowl.\n",TP);
	tell_object(TP, "You take out your trusty bic lighter and "+HIY+"spark "+NORM+"your bowl.\n");
	return 1;}

int cmd_beyes(){
	say(TPN+"'s eyes turn "+HIR+"red"+NORM+" and start to squint.\n",TP);
	tell_object(TP, "Your eyes go "+HIR+"red"+NORM+" and start to squint.\n");
	return 1;}

int cmd_bcough(){
	say(TPN+" hacks up a lung after that HUGE HIT!\n",TP);
	tell_object(TP, "You hack up a lung after that HUGE HIT!\n");
	return 1;}

cmd_tell(str){
	object player;
	object who;
	object what;
	int idle,m,s;

if(!str){
	write("Tell who what?\n");
	return 1;}
else 
  if(sscanf(str,"%s %s",who,what)==2){
		player = find_player(who);
	if(!player) {
		write(CAP(who)+" is not logged in.\n");
		return 1;}
  else 
		if(!player->query_interactive()){
			write(CAP(who)+" is disconnected.\n");
			return 1;}
  else
		if(player->query_invis() >= 21){
				write("Tell who what?\n");
			return 1;} 
  else 
		idle = query_idle(player);
		m = idle/60;
		s = idle%60;
		if(idle > 119) {
		write(""+GRN+CAP(who)+" has been idle for "+m+" minutes and "+s+" seconds."+NORM+"\n");}
		tell_object(player,""+HIK+TPN+" the pot head tells you: "+NORM+GRN+what+NORM+"\n");
		write(""+HIK+"You tell "+CAP(who)+": "+NORM+GRN+what+NORM+"\n");
		player->add_tellhistory(""+HIK+TPN+" the pot head told you: "+NORM+GRN+what+NORM+"\n");
		return 1; }}

cmd_say(string str){
	
	string verb;
	
	if(!str){
		write("Say what?\n");
		return 1;}
	if(strlen(str) > 0){
		if(str[strlen(str)-1] == '?')
			verb = "ask";
		else if(str[strlen(str)-1] == '!')
			verb = "exclaim";
		else
			verb = "say";
	}
	else verb = "say";
		write(""+HIK+"You "+verb+" \""+NORM+GRN+str+HIK+"\""+NORM+"\n");
		say(HIK+TPN+" the pot head "+verb+"s \""+NORM+GRN+str+HIK+"\""+NORM+"\n");
		return 1;}