#include <ansi.h>

inherit "/obj/monster.c";

reset(arg) {
	::reset(arg);
	if(arg) return;
	set_alias("saris");
	set_name("saris");
	set_alt_name("barkeep");
	set_race("elf");
	set_gender("female");
	set_short(HIK+"Saris the Barkeep"+NORM);
	set_long(
	  "Lounging behind the bar on a stool, this young elf calmly watches the guests \n"+
	  "in her tavern as she lazily wipes at the bar with a damp cloth.  She bears a \n"+
	  "striking resemblance to Laris, having the same soft smile, golden eyes, and \n"+
	  "wild mane of golden hair.  She is dressed in a tunic and breaches made of a \n"+
	  "deep blue silk and across her back is strapped a pair of simple rapiers. \n"+
	  "She eyes you curiously as you study her.\n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
