/*Erethor: eroad3b.c
 *Wizard:  Mishtar
 *Created: 1/26/04
 *Edited:  3/11/04
 *Realm:   Erethor
 */

#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

reset (int arg)
{
	if (arg) return;
	set_light(1);
	set_short(HIK+"Town of Erethor"+NORM);
	set_long(HIK+"Town of Erethor"+NORM+" [s,e,w,enter]\n"+
		"The marble roadway continues on westward through a large square to the \n"+
		"opposite end of town. A large stone well dominates the center of the \n"+
		"square.  Another marble road breaks off to the south towards Erethor's\n"+
		"grand crystal gates.  Just to the right rises a large crystal tower\n"+
		"shimmering in the sunlight.  Further west, the tall spires of a grand\n"+
		"temple loom on the horizon and back east, an ornate stone wall continues\n"+
		"until it melds with a fortified stone building.\n");
		
	add_item("road",
			 "The two wide marble roadways come together to form Erethor's\n"+
			 "town square");
	add_item("square",
			 "At the center of the square, the marble stones have been inlaid\n"+
			 "with multi-colored crystal shards to create a glittering mosaic\n"+
			 "of a great dragon");
	add_item("well",
			 "The well is made of blocks cut from a rich dark stone and its winch\n"+
			 "and bucket are carved from a deep red oak.  The well forms the eye\n"+
			 "of the crystal dragon mosaic\n");
	add_item("winch",
			 "The well's winch is delicatedly carved from oak down to the last gear.\n"+
			 "The handle "+HIK+"turns"+NORM+" with minimal effort and without a sound\n");
	add_item("bucket",
			 "The bucket is intricately carved from oak and forms a pair of dragons\n"+
			 "coiled around a deep bowl.  The rope holding the bucket is clutched in\n"+
			 "in their jaws");
	add_item("tower",
			 "A tall crystal spire stretches towards the sky above.  Its chisled crystalin\n"+
			 "surface glitters as the light bathes across its surface.  The fine outline\n"+
			 "of a door can barely be seen at its base");
	add_item("spires",
			 "The four spires reach for the sky above like grasping fingers");
	add_item("temple",
			 "The dark hewn structure of a temple dominates the western end of town");
	add_item("wall",
			 "A well constructed and sturdy stone wall blocks your view \n"+
			 "of whatever lies beyond");
	add_item("building",
			 "The building seems to grow from the wall as it stretches eastward down the road");
	add_item("horizon",
			 "The horizon is shrouded in tall the tall trees of the forest beyond the crystal\n"+
			 "walls of Erethor");
	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");
	
	add_exit("/players/mishtar/varminthor/erethor/eroad2.c","south");
	add_exit("/players/mishtar/varminthor/erethor/eroad5.c","east");
	add_exit("/players/mishtar/varminthor/erethor/eroad4.c","west");
	add_exit("/players/mishtar/varminthor/erethor/etower1.c","enter");
}
init()
{
	::init();
		add_action("enter","enter");
		add_action("south","south");
		add_action("south","s");
		add_action("east","east",1);
		add_action("west","west",1);
}
/*Exits*/	
enter()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/etower1.c";
	write(HIK+"You cautiously enter the crystal tower.\n"+NORM);
	say(TPN+" cautiously enters the crystal tower.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/etower1.c");
	command("look",TP);
	return 1;
}

south()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/eroad2.c";
	write(HIK+"You wander down the road.\n"+NORM);
	say(TPN+" wanders down the road.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad2.c");
	command("look",TP);
	return 1;
}

east()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/eroad5.c";
	write(HIK+"You wander down the road.\n"+NORM);
	say(TPN+" wanders down the road.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/eres5.c");
	command("look",TP);
	return 1;
}

west()
{
    string aroom;
    aroom = "/players/mishtar/areas/erethor/room/eroad4.c";
	write(HIK+"You wander down the road.\n"+NORM);
	say(TPN+" wanders wanders down the road.\n",TP);
	tell_room(aroom,TPN+" arrives.\n");
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad4.c");
	command("look",TP);
	return 1;
}