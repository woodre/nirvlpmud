#include <ansi.h>
inherit "players/vertebraker/closed/std/room.c";

reset (int arg){
	if (arg) return;
	set_light(1);
	set_short(HIK+"Korvanthor's Antiquities"+NORM);
	set_long("\n"+
		"A variety of wares line the shelves and cases that cover \n"+
		"nearly every inch of the small room.  Behind the counter \n"+
		"stands a jovial old half elf busy going over his ledgers \n"+
		"and mumbling softly to himself.  Behind him, on the wall, \n"+
		"is a large, red scaled head of a dragon mounted on a gold \n"+
		"plaque.  Beneath it and displayed in grand fashion, is a \n"+
		"large ornate sword.\n");

	add_item("shelves",
			 "Jars, bottles and an assortment of other odd items line \n"+
			 "the shelves of the shop");
	add_item("cases",
			 "The cases hold a variety of items from simple leather \n"+
			 "armors to other more expensive trinkets");
	add_item("counter",
			 "The counter is scattered with ledgers and inventory lists.\n");
	add_item("jars",
			 "The jars are filled with a variety of spices, herbs and \n"+
			 "other more exotic items");
	add_item("bottles",
			 "A wide range of fine wines and other liquors as well as \n"+
			 "other, more acrid smelling liquids fill the assortment \n"+
			 "of bottles around the shop");
	add_item("dragon",
			 "A large head of a red dragon.  Its lips are curled back in \n"+
			 "a snear of rage showing rows of sharp teeth");
	add_item("sword",
			 "Though its silvery blade is chipped and worn, the sword still\n"+
			 "shines as if it is polished daily.  Intricate runes run the \n"+
			 "length of the blade and the hilt is covered in a fine black \n"+
			 "leather.  Atop the pummel is a dragon's claw holding a dark \n"+
			 "crimson bloodstone that seems to glow with an inner fire. \n"+
			 "Perhaps you could <ask> the shopkeeper about it");
	
	add_smell("main",
			  "The crisp scent of fresh herbs and spices mixed with newly \n"+
			  "finished leather assails your senses.");			   
	
	add_exit("/players/mishtar/varminthor/erethor/eroad1.c","east");

	add_object("/players/mishtar/varminthor/monsters/erethor/korvanthor.c");
}