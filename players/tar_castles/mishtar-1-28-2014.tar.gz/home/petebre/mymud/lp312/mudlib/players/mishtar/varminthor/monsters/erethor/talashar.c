#include <ansi.h>

inherit "/obj/monster.c";

reset(arg) {
	::reset(arg);
	if(arg) return;
	set_alias("talashar");
	set_name("talashar");
	set_alt_name("shar");
	set_race("elf");
	set_gender("female");
	set_short(HIK+"Commander Talashar Windshear"+NORM);
	set_long(
	  "This grizzled veteran stands behind her desk with her brows furrowed in \n"+
	  "thought.  A wild mane of golden hair flows freely behind long pointed \n"+
	  "ears and frames a youthful yet weatherworn face.  Talashar is clad in an \n"+
	  "exquisite set of platemail that shines in the candlelit office and seems \n"+
	  "to flow with each of her graceful movements.  Strapped across her back \n"+
	  "is a vicious looking glaive that she reflexively caresses every so often \n"+
	  "as if for reassurance.\n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
