#include <ansi.h>
inherit "players/vertebraker/closed/std/room.c";

reset (int arg){
	if (arg) return;
	set_light(1);
	set_short(HIK+"The D"+HIW+"r"+HIK+"U"+HIW+"n"+HIK+"K"+HIW+"e"+HIK+"N Druid"+NORM);
	set_long("\n"+
		"The dim light of a large fireplace lights the room day or night.\n"+
		"A variety of locals and outlanders alike, sit about the tables \n"+
		"enjoying their drinks.  They pay scant attention to your entry. \n"+
		"A barmaid hustles about keeping drinks filled and tables clean. \n"+
		"Behind the bar, the tavern's owner keeps a careful eye on the \n"+
		"goings on in her tavern.  A small sign nearby details the days \n"+
		"specials available to order. \n");
		
	add_item("fireplace",
			 "A roaring fire is kept going thoughout the day in this lagre \n"+
			 "stone fireplace.  A large pot boils softly over the fire as \n"+
			 "it cooks");
	add_item("tables",
			 "The tables are made from a rich brown oak and have been kept \n"+
			 "in great repair.");
	add_item("bar",
			 "A tall wooden bar lines the western wall of the tavern. \n"+
			 "Made of a rich brown and highly polished oak, it seems \n"+
			 "as if nothing would stain it");
	add_item("locals",
			 "Several of the local populace, mostly elves, have come here for \n"+
			 "drinks and to swap stories");
	add_item("outlanders",
			 "Small in numbers, the few outlanders in the bar seem to be keeping \n"+
			 "pretty much keep to themselves.  A scattering of humans and a few \n"+
			 "dwarves make up the bunch.  Several have gathered around a table \n"+
			 "to trade tales of their exploits as they drink");
	add_item("pot",
			 "A heavy iron pot hangs over the fire soflty boiling the \n"+
			 "vegetable stew contained within");
	add_item("sign",
			 "A small oak sign with some eloquent writing on it, perhaps you "+
			 "should read it");
	
	add_listen("main",
			   "The soft chatter of various converstions and the jingle \n"+
			   "of coin are heard along side the the soft patter of the \n"+
			   "barmaid's feet as she hustles about the small tavern.");
	add_smell("main",
			  "The pleasant aroma of roast mutton and vegetable stew \n"+
			  "floats about the room.");

	add_object("/players/mishtar/varminthor/monsters/erethor/lasir.c");
	add_object("/players/mishtar/varminthor/monsters/erethor/saris.c");

	add_exit("/players/mishtar/varminthor/erethor/eroad2.c","east");
}
init(){
  ::init();   
  add_action("order", "order");
  add_action("read", "read");
}

read(str){
	if(str == "sign"){
		write("\n"+
			  "These items are available to order:\n"+
			  "1. Roast Mutton         :     50 coins.\n"+
			  "2. Vegetable Stew       :    100 coins.\n"+
			  "3. Elven Wine           :     50 coins.\n"+
			  "4. High Elven Brandy    :    100 coins.\n"+
			  "5. Sun Shooter          :    200 coins.\n"+
			  "6. Dragon's Blood       :    300 coins.\n");
     return 1;}
}
/*order(str){
 if(!present("saris", this_object())){
        write("Saris isn't here at this time.\n");
        return 1;
        }
        if(str == "1"){
          cost = 50;
		  heal = 5
          what = "some roast mutton";
		  mess = "??";}

        else if(str == "2"){
          cost = 100;
          heal = 10
          what = "some vegetable stew";
          }

        else if(str == "3"){
          cost = 500;
          item = clone_object("/players/pestilence/club/obj/labatts.c");
          what = "Labatts Blue";
          }
        else{
          write("Buy what?\n");
          return 1;
}
 if (call_other(this_player(), "query_money", 0) < cost) {
    write("I'm sorry, but you don't have enough coins for that.\n");
     return 1;
     }          
 if(!this_player()->add_weight(item->query_weight())) {
    write("It doesn't look like you can carry that.\n");
    destruct(item);
    return 1; }                 
 write("You pay "+cost+" coins for a "+what+".\n");
 say(tp->query_name() + " purchases a "+what+".\n");
 move_object(item,this_player());
 tp->add_money(-cost);
 return 1;
}
*/
order(str)
{
    string name, short_desc, mess;
    int value, cost, strength, heal;

    if (!str) {
       write("Order what ?\n");
       return 1;
    }
    if (!present("bartender")) {
       write("The bartender is gone and all the bottles appear to be \n"+
         "broken. Their contents spilled on the floor behind the bar.\n");
      return 1;
    }
    if (str == "beer") {
	mess = "That feels good";
	heal = 1;
    value = 10;
	strength = 3;
    }
    else if (str == "special" || str == "special of the house") {
	mess = "A tingling feeling goes through your body";
	heal = 10;
        value = 150;
        strength = 7;
    } else if (str == "firebreather" || str == "fire") {
	mess = "A shock wave runs through your body";
	heal = 25;
        value = 230;
        strength = 14;
    } else if (str == "coffee" || str == "cup of coffee") {
	mess = "You feel somewhat invigorated";
	heal = 0;
	value = 20;
	strength = -2;
    } else {
       write("The bartender says: What do you want?\n");
       return 1;
    }
    if (call_other(this_player(), "query_money", 0) < value) {
        write("That costs " + value + " gold coins, which you don't have.\n");
	return 1;
    }
    cost = value;
    if (strength > (call_other(this_player(), "query_level") + 2)) {
	if (strength > (call_other(this_player(), "query_level") + 5)) {
	    /* This drink is *much* too strong for the player */
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and immediately throws it up.\n");
	    write("You order a " + str + ", try to drink it, and throw up.\n");
	} else {
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and spews it all over you!\n");
	    write("You order a " + str + ", try to drink it, and sputter it all over the room!\n");
	}
	return 1;
    }
    write("You pay " + cost + " coins for a " + str + ".\n");
    say(call_other(this_player(), "query_name", 0) + " orders a " + str + ".\n");
    say("The bartender serves up the drink.\n");
    call_other(this_player(), "add_money", - cost);
    call_other(this_player(), "heal_self", heal);
    write("The bartender serves you your drink.\n");
    write(mess + ".\n");
    return 1;
}
