/*Erethor: ejail1.c
 *Wizard:  Mishtar
 *Created: 1/13/04
 *Edited:  5/19/04
 *Realm:   Erethor
 */
#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

int searched;

reset (int arg)
{
	if (arg) return;
	set_light(1);
	set_short(HIK+"Erethor Town Jail"+NORM);
	set_long(HIK+"The Erethor Town Jail"+NORM+" [out]\n"+
		"This small stone room is mysteriously warm and well lit.  A sturdy \n"+
		"wooden table and two chairs rest in the center of the room.  Several \n"+
		"heavy tapestries line the walls and at the back of the room resides \n"+
		"the iron bars of a large cell.  A large chest lies next to the cell's \n"+
		"door.  Two well-armed guards sit at the table playing cards as they \n"+
		"watch the chamber.\n");
		
	add_item("table",
			 "A game of cards is in progress on this simple oak table.  Several \n"+
			 "coins lay scattered among the cards");
	add_item("chest",
			 "A heavy wooden chest that is bound at the edges and strengthened \n"+
			 "by iron bands.  A large brass lock deteres any would-be thieves. \n"+
			 "The chest lies <open/closed>"); /*make open/closed function*/
	add_item("door",
			 "The cell's door is made of sturdy iron bars and swings easily \n"+
			 "on its hinges without making a sound");
	add_item("cards",
			 "An intricately detailed set of playing cards are layed out on the table");
	add_item("chairs",
			 "A pair of simple oak chairs.  Each one sits on the opposite side of the table");
	add_item("temple",
			 "The dark hewn structure of a temple dominates the western end of town");
	add_item("horizon",
			 "The horizon is shrouded in tall the tall trees of the forest beyond the crystal\n"+
			 "walls of Erethor");
	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");

	add_exit("/players/mishtar/areas/erethor/room/eroad6.c","out");
	add_exit_msg("out", ({"You leave out the door.\n","leaves out the door.\n"}));


searched = 0;
}


/*Search*/
cmd_search(str)
{
	object coins;
	if(str == "table" && searched == 0)
{
		write("You sift through the cards on the table and find a few coins.\n");
		say(TPN+" searches the area.\n");
		coins = clone_object("obj/money");
		coins->set_money(1000+random(500));
		move_object(coins, this_object());
		searched = 1;
		return 1;
}
	else if(searched != 0)
{
		write("You sift through the cards on the table but find nothing.\n");
		say(TPN+" searches the area.\n");
		return 1;
}
	else ::cmd_search(str);
	return 1;
}