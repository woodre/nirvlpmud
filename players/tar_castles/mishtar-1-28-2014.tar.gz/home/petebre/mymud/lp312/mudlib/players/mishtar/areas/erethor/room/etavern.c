/*Erethor: etavern1.c
 *Wizard:  Mishtar
 *Created: 1/13/04
 *Edited:  5/29/04
 *Realm:   Erethor
 */
#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

long(){
		if ((int)this_player()->query_brief() != 2)
		write(short()+"\n"); ::long(); 
	  }

reset (int arg)
{
	if (arg) return;
	set_light(1);
	set_short(NORM+GRN+"The D"+HIW+"r"+NORM+GRN+"U"+HIW+"n"+NORM+GRN+"K"+HIW+"e"+NORM+GRN+"N Druid"+NORM);
	set_long(GRN+
		"The dim light of a large fireplace lights the room day or night.\n"+
		"A variety of locals and outlanders alike, sit about the tables \n"+
		"enjoying their drinks.  They pay scant attention to your entry. \n"+
		"A barmaid hustles about keeping drinks filled and tables clean. \n"+
		"Behind the bar, the tavern's owner keeps a careful eye on the \n"+
		"goings on in her tavern.  A small sign nearby details the days \n"+
		"specials available to order. \n"+NORM);
		
	add_item("fireplace",
			 "A roaring fire is kept going thoughout the day in this lagre \n"+
			 "stone fireplace.  A large pot boils softly over the fire as \n"+
			 "it cooks");
	add_item("tables",
			 "The tables are made from a rich brown oak and have been kept \n"+
			 "in great repair.");
	add_item("bar",
			 "A tall wooden bar lines the western wall of the tavern. \n"+
			 "Made of a rich brown and highly polished oak, it seems \n"+
			 "as if nothing would stain it");
	add_item("locals",
			 "Several of the local populace, mostly elves, have come here for \n"+
			 "drinks and to swap stories");
	add_item("outlanders",
			 "Small in numbers, the few outlanders in the bar seem to be keeping \n"+
			 "pretty much keep to themselves.  A scattering of humans and a few \n"+
			 "dwarves make up the bunch.  Several have gathered around a table \n"+
			 "to trade tales of their exploits as they drink");
	add_item("pot",
			 "A heavy iron pot hangs over the fire soflty boiling the \n"+
			 "vegetable stew contained within");
	add_item("sign",
			 "A small oak sign with some eloquent writing on it, perhaps you "+
			 "should read it");
	
	add_listen("main",
			   "The soft chatter of various converstions and the jingle \n"+
			   "of coin are heard along side the the soft patter of the \n"+
			   "barmaid's feet as she hustles about the small tavern.");
	add_smell("main",
			  "The pleasant aroma of roast mutton and vegetable stew \n"+
			  "floats about the room.");

	add_object("/players/mishtar/varminthor/monsters/erethor/lasir.c");
	add_object("/players/mishtar/varminthor/monsters/erethor/saris.c");

	add_exit("/players/mishtar/areas/erethor/room/eroad2.c","east");
	add_exit_msg("east", ({GRN+"You stumble out into the street.\n"+NORM,"stumbles out into the street.\n"}));

	}
init()
{
  ::init();   
  add_action("order", "order");
  add_action("read", "read");
  add_action("inquire","inquire");
}

read(str)
{
	if(str == "sign")
{
		write("\n"+
			  "These items are available to order:\n"+
			  "1. Roast Mutton         :     50 coins.\n"+
			  "2. Vegetable Stew       :    100 coins.\n"+
			  "3. High Elven Brandy    :     50 coins.\n"+
			  "4. Elven Wine           :    100 coins.\n"+
			  "5. Sun Shooter          :    250 coins.\n"+
			  "6. Dragon's Blood       :    500 coins.\n"+
			  "You may also inquire about anything on the menu.\n");
     return 1;
}
}
inquire(string str)
{
	if(!str)
{
	write("Saris asks, \"What did you want to inquire about, hun?\"\n");
	return 1;
}
    if(str == "roast" || str == "mutton" || str == "roast mutton")
{
	write("Saris says, \"Roast mutton is a large hunk of tender meat still clinging \n"+
		  "to the bone and dripping savory juices.\"\n");
	return 1;
}
    else if (str == "stew" || str == "vegetable" || str == "vegetable stew")
{
	write("Saris says, \"The vegetable stew is a slowly broiled collection of carrots,\n"+
		  "celery, potatoes and chunks of savory beef.\"\n");
	return 1;
}
	else if (str == "brandy" || str == "elven brandy" || str == "high elven brandy")
{
	write("Saris says, \"High elven brandy is a refined, warm liquor that evaporates \n"+
		  "quickly causing little intoxication.\"\n");
	return 1;
}
	else if (str == "wine" || str == "elven wine")
{
	write("Saris says, \"Elven wine is a dark purple liquor thats highly intoxicating \n"+
		  "to all but the elves.\"\n");
	return 1;
}
	else if (str == "sun" || str == "shooter" || str == "sun shooter")
{
	write("Saris says, \"Sun shooter is a white liquor with a brandy-like flavor. It \n"+
		  "has an intensely warming effect that makes it perfect for cold winter nights.\"\n");
	return 1;
}
	else if (str == "dragon" || str == "blood" || str == "dragons blood")
{
	write("Saris says, \"Dragon's Blood is a mixed drink consisiting of Elven wine, \n"+
		  "dwarven spirits and a small dose of dragon's blood.\"\n");
	return 1;
}
	else {
       write("Saris asks, \"What did you want to inquire about, hun?\"\n");
       return 1;
}
}

order(string str)
{
	int cost,heal,strength;
	string type;
	if(!str)
{
	write("Saris asks, \"What did you want to order, hun?\"\n");
	return 1;
}
   switch(str)
{
      case "roast":
	  case "mutton":
	  case "roast mutton":
         cost=50;
         heal=5;
         strength=7;
         type="eat_food";
		 break;
      case "stew":
	  case "vegetable":
	  case "vegetable stew":
         cost=100;
         heal=15;
         strength=12;
         type="eat_food";
		 break;
      case "brandy":
	  case "elven brandy":
	  case "high elven brandy":
         cost=50;
         heal=5;
         strength=6;
         type="drink_alcohol";
		 break;
	  case "wine":
      case "elven wine":
	     cost=100;
         heal=12;
         strength=8;
         type="drink_alcohol";
         break;
	  case "sun":
      case "shooter":
	  case "sun shooter":
         cost=250;
         heal=25;
         strength=11;
         type="drink_alcohol";
         break;
      case "blood":
	  case "dragon":
	  case "dragon blood":
	  case "dragon's blood":
         cost=500;
         heal=50;
         strength=14;
         type="drink_alcohol";
         break;   
}
if(!present(("saris"),environment(this_player())))
{
	write("The bartkeep isn't here to serve you.\nCome back later.\n");
	return 1;
}

if(!cost)
{
    write("Saris says to you, \"What was it that you wanted to order, hun?\"\n");
    say("Saris says to "+TPN+", \"What was it that you wanted to order, hun?\"\n");
    return 1;
}
   write("You order some "+str+".\n");
   say(this_player()->query_name()+" orders some "+str+".\n");
   if(this_player()->query_money() < cost)
{
      write("Saris says to you, \"I'll need to see your coin before I sell you that.\"\n");
	  say("Saris says to "+TPN+", \"I'll need to see your coin before I sell you that.\"\n");
      return 1;
}
   if(!call_other(this_player(),type,strength) == 1)
{
      write("Saris smirks at you knowingly.\n"+
			"Saris says to you, \"You've had too much, hun, why don't you wait a while first.\"\n");
      say("Saris smirks at "+TPN+" knowingly.\n"+
		  "Saris says to "+TPN+", \"You've had too much, hun, why don't you wait a while first.\"\n");
      return 1;
}
   write("Saris deftly swipes the coins from your hand and hands you your "+str+".\n");
   write("Saris says to you, \"Thanks and enjoy.\"\n");
   say("Saris deflty swipes "+TPN+"'s coins from "+TPP+" hand and hands "+TPO+" the "+str+".\n");
   say("Saris says to "+TPN+", \"Thanks and enjoy.\"\n");
   this_player()->add_money(-cost);
   this_player()->heal_self(heal);
   give_stats();
   return 1;
}
give_stats()
{
   write(BOLD+"\tHP: "+NORM);
   write(HIK+"["+NORM+BOLD+TP->query_hp()+HIK+"/"+NORM+BOLD+TP->query_mhp()+HIK+"]  "+NORM);
   write(BOLD+"SP: "+NORM);
   write(HIK+"["+NORM+BOLD+TP->query_spell_point()+HIK+"/"+NORM+BOLD+TP->query_msp()+HIK+"]\n"+NORM);
}
