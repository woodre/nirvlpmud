#include <ansi.h>
inherit "/obj/monster.c";

reset(arg) {
	::reset(arg);
	if(arg) return;
	set_alias("salvarus");
	set_name("salvarus");
	set_alt_name("smith");
	set_race("elf");
	set_gender("male");
	set_short(HIK+"Salvarus the Smith"+NORM);
	set_long(
	  "A tall, well muscled elf lounges quietly behind the counter.  Two bright, \n"+
	  "silvery eyes light up the old warriors face.  His long mane of grey hair \n"+
	  "is tied back with a strip of leather showing off his long pointed ears. \n"+
	  "He wears a fine tunic and breaches of a rich black leather over which \n"+
	  "he has tied a heavy apron to shield himself from the roaring fires of \n"+
	  "his forge.  Slung through his belt is a long, heavy, iron hammer. \n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
