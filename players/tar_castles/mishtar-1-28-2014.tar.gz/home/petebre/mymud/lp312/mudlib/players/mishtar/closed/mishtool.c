#include "/bin/all.h"
#include <security.h>
#include <ansi.h>
#include "/players/boltar/things/esc.h"
#include "/players/mishtar/defs.h"

object who;

id(str) { return str == "dark_sight_object" || str == "tool" || str == "emoter"; }

extra_look(){
	if(environment() == TP) {
		write("Your "+RED+"crimson"+NORM+" eyes sparkle with mischief.\n");}
	else {
		write(ENVQN+"'s "+RED+"crimson"+NORM+" eyes sparkle with mischief.\n");}}

long(str){
	switch(str){
		case "tool":
		 write("This is a general all-purpose wiztool.\n"+
         "Commands:\n"+
         "wlog <action>#<reason>      writes a log of your actions\n"+
         "rules                       lists wizard rules & guidelines\n"+
         "I <name>                    inventory of name\n"+
         "IR <name>                   inv of room that name is in\n"+
		 "dest <name>                 dests an object of name \n"+
		 "clone <path>                clones a copy of object of path\n"+
		 "trans <name>                transports name to you\n"+
		 "scale <name>                clones teller to name\n"+
         "hand <name> <path>          hands name object of path\n"+
         "place <name> <path>         moves name to path\n"+
	     "church <name>               moves name to church\n"+
         "trans <name>                moves name to you\n"+
         "peace                       forces all combat to stop\n"+
         "money                       gives you 80k coins\n"+
         "heal <name>                 heal someone in the room\n"+
         "                            note: no name is yourself\n"+
         "set_level <name> <#>        sets the level of name\n"+
         "set_extra_level <name> <#>  sets the extra level of name\n"+
         "set_home <name> <path>      sets the home of name to path\n"+
         "add_xp <name> <#>           adds # xp to name\n"+
         "set_stat <name> <what> <#>  sets the stat what of name to #\n"+
		 "set_title <name> <what>     sets the title of name to what \n"+
		 "set_pretitle <name> <what>  sets the pretitle of name to what \n"+
		 "set_race <name> <what>      sets the race of name to what \n"+
		 "set_guild <name> <what>     sets the guild name of who to what \n"+
		 "set_align <name> <what>     sets the alignment of name to what \n"+
         "idest <name> <object>       dests object from name's inv\n");
		 break;
		
		case "emoter":
		 write("\nA compilation of draconic emotes!\n"+
         "Commands:\n"+
         "menace\n"+	
		 "nervous\n"+
		 "lazy\n"+
		 "dlick\n"+
		 "dgrin\n"+
		 "pounce\n"+
		 "perch\n");
		 break;	
		
		default:
		 write("Look at what?\n");
		break;}
		return 1;}

drop() { return 1;}

get() { return 1;}

init() {
  add_action("hand","hand");
  add_action("didest","idest");
  add_action("dchurch","church");
  add_action("dtrans","trans");
  add_action("set_title","set_title");
  add_action("set_race","set_race");
  add_action("set_guild","set_guild");
  add_action("set_pretitle","set_pretitle");
  add_action("set_align","set_align");
  add_action("dscale","scale");
  add_action("cmd_destruct","dest");
  add_action("dclone","clone");
  add_action("cmd_tell","tell");
  add_action("cmd_say","say");
  add_action("cmd_say"); add_xverb("'");
  add_action("cmd_emote","em");
  add_action("cmd_faremote","emt");
  add_action("cmd_menace","menace");
  add_action("lazy","lazy");
  add_action("nervous","nervous");
  add_action("cmd_dlick","lick");
  add_action("cmd_dgrin","grin");
  add_action("cmd_pounce","pounce");
  add_action("cmd_perch","perch");
  add_action("cmd_dinvis","dinvis");}

/*Commands*/

dchurch(str){
    string aroom;
    if(!str) return 0;
    who = find_player(str);
    if(!who) { write("Target is not game.\n"); return 1; }
    if(who && who != TP){
    aroom = "/room/church";
    write("\nA giant "+HIK+"onyx"+NORM+" dragon swoops down, captures "+FPN+" in its claws and carries them away.\n"+
		"You send "+FPN+" to the church.\n");
    say("A giant "+HIK+"onyx"+NORM+" dragon swoops down, captures "+FPN+" in its claws and carries them away.\n",who);
    tell_object(who,"A giant "+HIK+"onyx"+NORM+" dragon swoops down, captures you in its claws and carries you away.\n");
    tell_room(aroom,"A giant "+HIK+"onyx"+NORM+" dragon drops "+FPN+" from its claws.\n");
    move_object(who,aroom);
    tell_object(who,"You have arrived at the church!\n");
    return 1; }}

int dclone(string str){
 string err;
 object ob, soul;

 if((int)this_player()->query_level() < CREATE) return 0;

 if(!str) { write("Usage: 'clone <file_name>'\n"); return 1; }
 
 if(str == "player.c" || str == "/obj/player.c") {
  write("That is not allowed.\n");
  this_player()->illegal_patch("cloned player.c");
  return 1; }

 str = (string)this_player()->valid_read(str);

 if(!(soul = present("wiz_soul", this_player()))) {
  write("You don't have a soul.\n"+
        "Type 'soul on' to get one, then try again.\n");
  return 1; }

 if(!soul->query_errormsgs()) {
  if(err = catch(ob = clone_object(str)))  {  write(err+"\n");  return 1; }
 
 else ob = clone_object(str); }

 else ob = clone_object(str);

 this_player()->checked_say("A small "+RED+"crimson"+NORM+" dragon fetches something for Mishtar.\n");

 if(ob->get()) {
  this_player()->add_weight((int)ob->query_weight());
  move_object(ob, this_player()); }
 else
  move_object(ob, environment(this_player()));

 if(ob->short())
  write("A small "+RED+"crimson "+NORM+"dragon fetches "+(string)ob->short()+".\n");
 else write("Cloned an invisible object.\n");
 return 1;
}

dtrans(str) {
    object where;
    if(!str) return 0;
    if(!find_player(str)) { write("Target is not game.\n");
    return 1; }
    where = environment(find_player(str));
    say("A giant "+HIK+"onyx"+NORM+" dragon drops "+capitalize(str)+" from its claws.\n",this_player());
    move_object(find_player(str),environment(TP));
    tell_room(where,"A giant "+HIK+"onyx"+NORM+" dragon swoops down, captures "+
		capitalize(str)+" in its claws and carries them away.\n");
    write("You have transed "+capitalize(str)+" to you.\n");
    tell_object(find_player(str),"A giant "+HIK+"onyx"+NORM+" dragon swoops down, captures "+
		"you in its claws and carries you away.\n");
    return 1; }

set_guild(str){
	string who,what;
	if(!str) return 0;
	if(sscanf(str,"%s %s",who,what));
	if(!find_player(who)) { write("Target is not in play.\n"); return 1; }
	find_player(who)->set_guild_name(what);
/*	tell_object(find_player(who),"Mishtar has changed your guild name to "+what+".\n");*/
	write("You have set "+capitalize(who)+"'s guild name to "+what+".\n");
	return 1; }

set_race(str) {
    string who,what;
    if(!str) return 0;
    if(sscanf(str,"%s %s",who,what));
    if(!find_player(who)) { write("Target is not in play.\n"); return 1; }
    find_player(who)->set_race(what);
/*  tell_object(find_player(who),"Mishtar has changed your race to "+what+".\n");*/
    write("You have set "+capitalize(who)+"'s race to "+what+".\n");
    return 1; }

set_align(string str){
	int s;
    string *words;
	string who,what;
    if(!str){
      notify_fail("Set who's title to what?\n");
      return 0;}
    if(sscanf(str,"%s %s",who,what));
    if(!find_player(who)) { write("Target is not in play.\n"); return 1; }
      words = explode(what, "$");
      s = sizeof(words);
      while(s --)
        if(find_player(who)->replace_ansi(words[s]))
          words[s] = (string)find_player(who)->replace_ansi(words[s]);
      str = (implode(words, "")) + esc + "[0m";
/*  tell_object(find_player(who),"Mishtar has changed your alignment to "+str+".\n");*/
	write("You have set "+capitalize(who)+"'s alignment to "+str+"\n");
    find_player(who)->set_al_title(str);
    return 1;}

set_title(string str){
	int s;
    string *words;
	string who,what;
    if(!str){
      notify_fail("Set who's title to what?\n");
      return 0;}
    if(sscanf(str,"%s %s",who,what));
    if(!find_player(who)) { write("Target is not in play.\n"); return 1; }
      words = explode(what, "$");
      s = sizeof(words);
      while(s --)
        if(find_player(who)->replace_ansi(words[s]))
          words[s] = (string)find_player(who)->replace_ansi(words[s]);
      str = (implode(words, "")) + esc + "[0m";
/*  tell_object(find_player(who),"Mishtar has changed your title to "+str+".\n");*/
	write("You have set "+capitalize(who)+"'s title to "+str+"\n");
    find_player(who)->set_title(str);
    return 1;}

set_pretitle(string str){
	int s;
    string *words;
	string who,what;
    if(!str){
      notify_fail("Set who's pretitle to what?\n");
      return 0;}
    if(sscanf(str,"%s %s",who,what));
    if(!find_player(who)) { write("Target is not in play.\n"); return 1; }
      words = explode(what, "$");
      s = sizeof(words);
      while(s --)
        if(find_player(who)->replace_ansi(words[s]))
          words[s] = (string)find_player(who)->replace_ansi(words[s]);
      str = (implode(words, "")) + esc + "[0m";
/*	tell_object(find_player(who),"Mishtar has changed your pretitle to "+str+".\n");*/
	write("You have set "+capitalize(who)+"'s pretitle to "+str+"\n");
    find_player(who)->set_pretitle(str);
    return 1;}

hand(str) { 
    string what,name;
    object ob,targ;
    ob = 0;
    if(!str) return 0;
    if(sscanf(str,"%s %s",name,what) != 2) return 0;
    targ = find_player(name);
    if(!targ) { write("Target not in play.\n"); return 1; }
    if(catch(ob = clone_object(what)))
    return (write("Object did not clone.\n"), 1);
    move_object(ob,targ);
    tell_object(targ,"A tiny "+RED+"crimson"+NORM+" scaled dragon has "+ 
                   "dropped something into your inventory.\n");
    write("You have cloned "+what+" to "+capitalize(name)+".\n");
    return 1;}

dscale(name) { 
    object ob,targ;
    ob = 0;
    if(!name) return 0;
    targ = find_player(name);
    if(!targ) { write("Target not in play.\n"); return 1; }
    if(catch(ob = clone_object("/players/mishtar/closed/mishtell.c")))
    return (write("Object did not clone.\n"), 1);
    move_object(ob,targ);
    tell_object(targ,"A tiny "+RED+"crimson"+NORM+" scaled dragon has "+ 
                   "dropped something into your inventory.\n");
    write("You have given a scale to "+capitalize(name)+".\n");
    return 1;}

void destruct_inventory(){
    object ob, oc;
    ob = first_inventory(this_player());
    while(ob){
    oc=next_inventory(ob);
    if(!ob->id("ND")){
      destruct(ob);
      write("destruct: " + (string)ob->short() + ".\n");}
    ob=oc;}}

int cmd_destruct(string str){
    object ob;
    if (!str) {
    write("Destruct what?\n");
    return 1;}
    str = lower_case(str);
    if (str == "all"){
    destruct_inventory();
    return 1;}
    if(!(ob=present(str, TP)) &&
     !(ob=present(str,ENVTP))){
    write("You don't see " + str + " here.\n");
    return 1;}
    say("A small "+HIK+"black "+NORM+"dragon flies in and destroys "+ob->short()+" \n",this_player());
    write("A small "+HIK+"black "+NORM+"dragon disintegrates "+ob->short()+".\n");
    destruct(ob);
    return 1;}

didest(str) { 
    string name,what;
    object ob,targ;
    if(!str) return 0;
    if(sscanf(str,"%s %s",name,what) != 2) return 0;
    targ = find_player(name);
    if(!targ) { write("Target is not in play.\n");
    return 1; }
    ob = present(what,targ);
    if(!ob) { write("Object is not on target.\n");
    return 1; }
    destruct(ob);
/*  tell_object(targ,"A small "+HIK+"black "+NORM+"dragon disintegrates "+what+" off you.\n");*/
    write("You have dested "+what+" off "+capitalize(name)+".\n");
    return 1; }

cmd_dinvis()
{
	if(TP->query_invis())
{
		write("You are already invisible.\n");
		return 1;
}
	else
		this_player()->set_invs_sp();
		write("Dozens of tiny "+HIK+"shadow"+NORM+" dragons coil around you and you disappear.\n");
		say("Dozens of tiny "+HIK+"shadow"+NORM+" dragons coil around "+TPN+" and "+TPPN+" disappears.\n");
		return 1;
}
/*
cmd_visible()
{
	if(TP->query_invis())
{
*/	

/*Teller*/

cmd_tell(str){
	object player, who, what;
	string verba,verbb,verbc;
	int idle,m,s;
     if(!str){ write("Tell who what?\n"); return 1;}
    else 
     if(sscanf(str,"%s %s",who,what)==2){
		player = find_player(who);
		if(!player){ write(CAP(who)+" is not logged in.\n"); return 1;}
	else 
		if(!player->query_interactive()){ write(CAP(who)+" is disconnected.\n"); return 1;}
	else 
		idle = query_idle(player);
		m = idle/60;
		s = idle%60;
		if(idle > 119) { 
		write(""+HIK+CAP(who)+" has been idle for "+m+" minutes and "+s+" seconds."+NORM+"\n");}
	if(strlen(str) > 0){
		if(str[strlen(str)-1] == '?'){
			verba = "softly asks";
			verbb = "softly ask";
			verbc = "softly asked";}
		else if(str[strlen(str)-1] == '!'){
			verba = "softly exclaims to";
			verbb = "softly exclaim to";
			verbc = "softly exclaimed to";}
		else{
			verba = "whispers to";
			verbb = "whisper to";
			verbc = "whispered to";}}
/*	else verb = "whisper";*/
		tell_object(player,""+HIK+TPN+" "+verba+" you \""+RED+what+HIK+"\""+NORM+"\n");
		write(""+HIK+"You "+verbb+" "+CAP(who)+" \""+RED+what+HIK+"\""+NORM+"\n");
		player->add_tellhistory(""+HIK+TPN+" "+verbc+" you \""+RED+what+HIK+"\""+NORM+"");
		return 1; }}

cmd_faremote(string str)
{
	object ob,player,who,what;
	int idle,m,s;
     if(!str)
{
		write("Emote what?\n");return 1;
}
    else 
     if(sscanf(str,"%s %s",who,what)==2)
{
		player = find_player(who);
	 if(!player)
{
	write(CAP(who)+" is not logged in.\n");return 1;
}
    else 
	 if(!player->query_interactive())
{
	write(CAP(who)+" is disconnected.\n");return 1;
}
	else
		idle = query_idle(player);
		m = idle/60;
		s = idle%60;
	 if(idle > 119)
{
		write(""+HIK+CAP(who)+" has been idle for "+m+" minutes and "+s+" seconds."+NORM+"\n");
}
		ob = present(player,environment(this_player()));
		if(!ob)
{
     		write(""+HIK+"You faremote to "+CAP(who)+RED+": "+HIK+TPN+" "+what+NORM+"\n");
			tell_object(player,""+HIK+"~"+RED+"<"+HIK+"*"+RED+">"+HIK+"~ "+HIK+TPN+
			" "+what+NORM+"\n");
			return 1;
}
		else
	     	write(""+HIK+"You discreet emote to "+CAP(who)+RED+": "+HIK+TPN+" "+what+NORM+"\n");
			tell_object(player,""+HIR+"<"+HIK+"*"+RED+"> "+HIK+TPN+" "+what+NORM+"\n");
			return 1;
}}

cmd_emote(string str){
   write(HIK+TPN+" "+str+NORM+"\n");
   say(HIK+TPN+" "+str+NORM+"\n", TP);
   return 1;
}

cmd_say(string str){
	string verb;
	if(!str){write("Say what?\n");return 1;}
	if(TP->query_invis()){
		if(strlen(str) > 0){
			if(str[strlen(str)-1] == '?')
				verb = "ask";
			else if(str[strlen(str)-1] == '!')
				verb = "exclaim";
			else
				verb = "say";}
		write("You "+verb+" \""+str+"\"\n");
		say("Someone "+verb+"s \""+str+"\"\n");
		return 1;}
	else
	if(strlen(str) > 0){
		if(str[strlen(str)-1] == '?')
			verb = "softly ask";
		else if(str[strlen(str)-1] == '!')
			verb = "softly exclaim";
		else
			verb = "whisper";
	}
/*	else verb = "whisper";*/
		write(""+HIK+"You "+verb+" \""+RED+str+HIK+"\""+NORM+NORM+"\n");
		say(HIK+TPN+" "+verb+"s \""+RED+str+HIK+"\""+NORM+NORM+"\n");
		return 1;}

/*emoter*/

int cmd_dlick(string arg){
if(ghost()) return 0;
if(!arg){ write("Lick who?\n"); return 1;}
if(!(who = arg_check(arg))) return 0;
else if(who = present(arg, environment(TP))){
	write(HIK+"You lick "+FPN+" with your "+NORM+MAG+"purple"+HIK+" little dragon tongue."+NORM+"\n");
	say(HIK+TPN+" licks "+FPN+" with "+TPP+NORM+MAG+" purple"+HIK+" little dragon tongue."+NORM+"\n", who);
	tell_object(who,HIK+TPN+" licks you with "+TPP+NORM+MAG+" purple"+HIK+" little dragon tongue."+NORM+"\n");
}
else{
	who = find_player(arg);
	write(HIK+"From afar, you lick "+FPN+" with your "+NORM+MAG+"purple "+HIK+"little dragon tongue."+NORM+"\n");
    tell_object(who, HIK+"From afar, "+TPN+" licks you with "+TPP+NORM+MAG+" purple "+HIK+"little dragon tongue."+NORM+"\n");
}
return 1;
}

int cmd_menace(string arg){
if(ghost()) return 0;
if(!arg){
	write(HIK+"You stretch your wings and hiss menacingly."+NORM+"\n");
	say(HIK+TPN+" stretches "+TPP+" wings and hisses menacingly."+NORM+"\n",TP);
	return 1;
}
else{
	
	if(!(who = arg_check(arg))) return 0;
	else if(who = present(arg, environment(TP))){
		write(HIK+"You stretch your wings and hiss menacingly at "+FPN+"."+NORM+"\n");
		say(HIK+TPN+" stretches "+TPP+" wings and hisses menacingly at "+FPN+"."+NORM+"\n", who);
		tell_object(who, HIK+TPN+" stretches "+TPP+" wings and hisses menacingly at you."+NORM+"\n");
	}
	else{
		who = find_player(arg);
		write(HIK+"From afar, you stretch your wings and hiss menacingly at "+FPN+"."+NORM+"\n");
	    tell_object(who, HIK+"From afar, "+TPN+" streches "+TPP+" wings and hisses at you."+NORM+"\n");
	}
return 1;
}}


int cmd_dgrin(string arg){
if(ghost()) return 0;
if(!arg){
	write(HIK+"You grin wickedly, displaying your jagged fangs."+NORM+"\n");
	say(HIK+TPN+" grins wickedly, displaying "+TPP+" jagged fangs."+NORM+"\n",TP);
	return 1;
}
else{
	if(!(who = arg_check(arg))) return 0;
	else if(who = present(arg, environment(TP))){
		write(HIK+"You grin wickedly at "+FPN+", displaying your jagged fangs."+NORM+"\n");
		say(HIK+TPN+" grins wickedly at "+FPN+", displaying "+TPP+" jagged fangs."+NORM+"\n", who);
		tell_object(who, HIK+TPN+" grins wickedly at you, displaying "+TPP+" jagged fangs."+NORM+"\n"); 
	}
	else{
		who = find_player(arg);
		write(HIK+"From afar, you grin wickedly at "+FPN+", displaying your jagged fangs."+NORM+"\n");
		tell_object(who, HIK+"From afar, "+TPN+" grins wickedly at you, displaying "+TPP+" jagged fangs."+NORM+"\n");
	}
return 1;
}}


int cmd_pounce(string arg){
if(ghost() || !arg) return 0;
if(!(who = arg_check(arg))) return 0;
else if(who = present(arg, environment(TP))){
	write(HIK+"You hunch down, swish your tail, and pounce upon "+FPN+"!"+NORM+"\n");
	say(HIK+TPN+" hunches down, swishes "+TPP+" tail, and pounces upon "+FPN+"!"+NORM+"\n", who);
	tell_object(who, HIK+TPN+" hunches down, swishes "+TPP+" tail, and pounces on you!"+NORM+"\n");
}
else{
	write("You don't see "+capitalize(arg)+" here.\n");
}
return 1;
}

int cmd_perch(string arg){
if(ghost() || !arg){ write("Perch on who?"); return 1;}
else{

if(!(who = arg_check(arg))) return 0;
else if(who = present(arg, environment(TP))){
	write(HIK+"You perch on "+FPN+"'s shoulder and hiss softly!"+NORM+"\n");
	say(HIK+TPN+" perches on "+FPN+"'s shoulder and hisses softly!"+NORM+"\n", who);
	tell_object(who, HIK+TPN+" perches on your shoulder and hisses softly!"+NORM+"\n");
}
else{
	write("You don't see "+capitalize(arg)+" here.\n");
}
return 1;
}}

lazy(){
	say(HIK+TPN+" stretches "+TPP+" wings and yawns lazily showing off "+TPP+" jagged fangs."+NORM+"\n",TP);
	tell_object(TP,HIK+"You stretch your wings and yawn lazily showing off your jagged fangs."+NORM+"\n");
	return 1;}

nervous(){
	say(HIK+TPN+" shifts "+TPP+" wings nervously and claws the ground with "+TPP+" talons."+NORM+"\n",TP);
	tell_object(TP,HIK+"You shift your wings nervously and claw the ground with your talons."+NORM+"\n");
	return 1;}
