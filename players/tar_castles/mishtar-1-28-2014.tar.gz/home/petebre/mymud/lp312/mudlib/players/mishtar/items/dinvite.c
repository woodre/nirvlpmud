/*Mishtar -> created 3/25/04*/
#include <ansi.h>
#include "/players/mishtar/defs.h"

inherit "obj/treasure" ;

reset(arg)
{
  if(arg) return;
	set_alias("invite");
    set_weight(0);
	set_value(0);
}

init(){
	::init();
	add_action("ansreq","ansreq");
}

int ansreq()
{
object ob;
ob = first_inventory(ENVTP);
	while(ob)
{
	if(living(ob) && (status)ob->is_player())
{
	if(ob != TP)
	tell_object(ob,
	"A huge "+BLU+"azure"+NORM+" dragon swoops down and hisses softly to "+TPN+".\n");
	else
	tell_object(ob,
	"\nA huge "+BLU+"azure"+NORM+" dragon swoops down and hisses to you, \n"+
	"\"My master, Mishtar, wishes to invite you into her presence\".\n<"+BOLD+"y"+NORM+"es> or"+
	" <"+BOLD+"n"+NORM+"o>?\n");
}
	ob = next_inventory(ob);
}
	input_to("answer");
	return 1;
}

int answer(string str)
{
	if(str == "Y" || str == "y" || str == "yes")
{
	write("The huge "+BLU+"azure"+NORM+" dragon hisses excitedly, helps you up onto its"+
		  " back and flies away.\n");
	say("The huge "+BLU+"azure"+NORM+" dragon hisses excitedly at "+TPN+", helps "+TPO+
		" climb onto its back and flies away.\n");
	move_object(TP,"/players/mishtar/workroom.c");
	command("look",TP);
	write("The huge "+BLU+"azure"+NORM+" dragon lands, helps you off its back and then flies away.\n");
	say("\nA huge "+BLU+"azure"+NORM+" dragon flies in, lets "+TPN+" climb down off its back"+
	" and then flies away.\n");
}
	else
{	
	object ob;
	write(
		"The huge "+BLU+"azure"+NORM+" dragon hisses to you, \"Okay, maybe some other time "+
		"then\" and flies away.\n");
	say("The huge "+BLU+"azure"+NORM+" dragon hisses softly to "+TPN+" then stretches its "+
		"wings and flies away.\n");
	ob = first_inventory(environment(find_player("mishtar")));
	while(ob)
{
	if(living(ob) && (status)ob->is_player())
{
	if(ob = find_player("mishtar"))
	tell_object(ob,
	  "\nA huge "+BLU+"azure"+NORM+" dragon flies in and hisses to you, \""+TPN+" has declined "+
	  "master\" then flies away.\n");
	else
	tell_object(ob,
	  "\nA huge "+BLU+"azure"+NORM+" dragon flies in and hisses softly to Mishtar then flies away.\n");
}
	ob = next_inventory(ob);
}
}
	destruct(this_object());
	return 1;
}
drop() { return 1; }