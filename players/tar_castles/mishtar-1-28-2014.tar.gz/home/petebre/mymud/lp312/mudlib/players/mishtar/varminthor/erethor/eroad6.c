#include <ansi.h>
inherit "players/vertebraker/closed/std/room.c";

reset (int arg){
	if (arg) return;
	set_light(1);
	set_short(HIK+"Town of Erethor"+NORM);
	set_long("\n"+
		"The marble roadway ends in a small circle shared by several buildings. \n"+
		"Ahead stands a stalwart stone building with a worn oak sign swinging \n"+
		"above the door.  To the north lies a grand temple carved from two oak \n"+
		"trees, its four long spires grasping for the sky above.  To the south \n"+
		"lies a well kept building made of stone and wood.  Its exotic design \n"+
		"lends a feeling of importance to the structure.  Back east lies the \n"+
		"hub of Erethor, the town square.\n");
		
	add_item("road",
			 "A wide marble road winds throughout the town. The elves \n"+
			 "have taken great pains to maintain its upkeep");
	add_item("windows",
			 "The window is made billiantly colored pieces of stained glass that \n"+
			 "obscures the goings on inside the building");
	add_item("church",
			 "Two dark oak trees slowly twisted as they grew and eventuall \n"+
			 "A two story building made from a fine dark oak.  From inside, the \n"+
			 "glitter of the fire dances acrossed the stained glass window");
	add_item("residence",
			 "Well trimmed bushes line the stone walkway towards the small oak \n"+
			 "home.  The house seems molded from the strange, squaty oak tree");
	add_item("spires",
			 "The four spires reach for the sky above like grasping fingers");
	add_item("temple",
			 "The dark hewn structure of a temple dominates the western end of town");
	add_item("horizon",
			 "The horizon is shrouded in tall the tall trees of the forest beyond the crystal\n"+
			 "walls of Erethor");
	add_listen("main",
			   "The boystrous sounds of lively elves going about their \n"+
			   "daily business and the muffled clanking of the guard's \b"+
			   "armor as they patrol the streets are commonplace");

	add_exit("/players/mishtar/varminthor/erethor/echurch1.c","north");
	add_exit("/players/mishtar/varminthor/erethor/eroad4.c","east");
	add_exit("/players/mishtar/varminthor/erethor/ejail1.c","jail");
}
