/*Erethor: egate.c
 *Wizard:  Mishtar
 *Created: 1/13/04
 *Edited:  5/29/04
 *Realm:   Erethor
 */

#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

long(){
		if ((int)this_player()->query_brief() != 2)
		write(short()+"\n"); ::long(); 
	  }

reset (int arg)
{
	if (arg) return;
	set_light(1);
	set_short(GRN+"Gates of Erethor"+NORM);
	set_long(GRN+
		"A small dirt trail empties into a large clearing dominated by a\n"+
		"large, flowing crystal gate.  A stout tower flanks each side of\n"+
		"the gateway, atop which sit two heavy wooden balista that point\n"+
		"menacingly at the clearing below.  Standing opposite each door\n"+
		"are two sturdy looking guards, each adorned in the livery of \n"+
		"Erethor.  They seem to be keeping a watchful eye on their\n"+
		"surroundings.\n"+NORM);
		
	add_item("trail",
			 "A worn dirt path leads off to the south");
	add_item("tower",
			 "Two stout crystal towers glisten in the sun");
	add_item("balista",
			 "A matching set of heavy wooded balista accompanied by a \n"+
			 "a couple of guards to man them can be seen\n");
	add_item("clearing",
			 "The clearing has been carefully tended by unknown hands \n"+
			 "leaving it free of anything but the softest of grasses");
	add_item("gates",
			 "The large gates are delicately crafted from a brilliant red\n"+
			 "crystal that sparkles in the dim light of the clearing");

	add_smell("main",
			  "The smell of crisp grass and fresh flowers is carried on the breeze.\n");

	add_listen("main",
			   "The noise of the bustling town ahead is accompainied by the soft chirp \n"+
			   "of birds in the trees and the rustle of leaves in the breeze.\n");
	
	add_exit("/players/mishtar/areas/erethor/room/eroad1.c","enter");
	add_exit_msg("enter", ({GRN+"You pass through the gates of Erethor.\n"+NORM,"passes through the gates of Erethor.\n"}));

	add_object("/players/mishtar/varminthor/monsters/erethor/eguard1.c",1);
}