#include <ansi.h>
#include "/players/mishtar/defs.h"

string spoken;

/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "gate" || str == "castle" || str == "dragons" || str == "runes" ||
				 str == "forest" || str == "clearing" || str == "seal";}

short() { return HIK+"Ancient Gate of Varminthor"+NORM;}

long(str) {
	switch(str)
	{
	case "gate":
		write(
			"This ancient gate stands amidst a small clearing in the middle \n"+
			"of this dense forest.  The clearing is eerily quiet.  Neither \n"+
			"plant nor animal encroaches upon this place.  Two large dragons, \n"+
			"locked in an eternal struggle, form the arches of the this dark \n"+
			"marble structure as they fight for dominance of the doors set \n"+
			"between them.  A large, rune covered seal locks the two doors.\n");
		say(TPN+" looks at the gate.\n",TP);
		break;
	
	case "forest":
		write(
			"This large forest is crowded by ancient trees and dense underbrush. \n"+
			"Only a few motes of light sprinkle down through the tangled limbs \n"+
			"of the canopy above creating a dim glow to light the forest. Still, \n"+
			"the passing of several adventurers has worn away small trails that \n"+
			"half hazardly cut through the dense underbrush.\n");
		say(TPN+" looks at the surrounding forest.\n",TP);
		break;
	
	case "clearing":
		write(
			"The clearing is dominated by a large dark marble gate. Little in the\n"+
			"way of vegetation grows here.  Most has withered away and died in the \n"+
			"great gate's shadow. An eerie feeling of foreboding dominates this \n"+
			"place and has scared most of the wildlife to safer regions of the \n"+
			"forest. \n");
		say(TPN+" looks around the clearing.\n",TP);
		break;
	
	case "dragons":
		write(
			"The two large dragons are intricately carved in great detail. One \n"+
			"great dragon's scales have been inlayed with a brilliant golden \n"+
			"metal and its nemesis in a reddish metal of unknown origins.  Two \n"+
			"sparkling red bloodstones have been inset in each head to serve as \n"+
			"their eyes.  The two almost seem to come alive in their struggle \n"+
			"as the dim light of the clearing dances over them.\n");
		say(TPN+" looks at the dragons.\n",TP);
		break;
	
	case "seal":
		write(
			"This large seal has been inset in the center of the two great doors. \n"+
			"It has been made out of a brilliant gold disc and engraved with runes \n"+
			"of some dark crystal.  There doesn't apear to be any means of removing \n"+
			"it from the doors.\n");
		say(TPN+" looks at the seal.\n",TP);
		break;

	case "runes":
		write(
			"The runes are made from melted down onyx crystal and poored into the \n"+
			"engravings on the ancient golden seal.  A feeling of intense magical \n"+
			"power radiates from the runes.  Perhaps one could decipher their \n"+
			"meaning.\n");
		say(TPN+" looks at the runes.\n",TP);
		break;
	
	default:
		write("Look at what?\n");
		break;
	}
	return 1;
}
init() {
    add_action("enter"); add_verb("enter");
	add_action("decipher"); add_verb("decipher");
	add_action("speak"); add_verb("speak");
}
speak(str) {
	if (str != "hakarmaskannar revanthas"){
		write(
			"Both dragons turn their fiery gaze upon you and hiss: \n"+
			"This is not the words you must speak to pass our sacred gates! \n"+
			"Moments later your skin peels and burns under the fiery \n"+
			"onslaught of their breath as the great dragons punish \n"+
			"your insolance.\n");
		TP->do_damage( ({ random(20)+5 }) , ({ "other|fire" }) );
		say("Powerful magic crackles through the air as "+TPN+" speaks \n"+
			"ancient words of great power, but only seems to have attracted the ire \n",TP);
		say("of the great dragons guarding the gate.  You feel the intense heat as \n"+
			TPN+" is slowly roasted admist the dragons fiery breath. \n",TP);
			return 1;}
	else 
		write(
			"As the last sylables of the words of power escape your \n"+
			"lips, a soft hiss is heard as the seal slowly seperates \n"+
			"down its center and the large marble doors slowly swing \n"+
			"inward allowing you passage.  The dragons look on with \n"+
			"with a look resembling something like approval in their \n"+
			"great, bloodstone eyes.\n");
		say("Powerful magic crackles through the air as "+TPN+" speaks \n"+
			"the ancient words of great power.  A soft hiss is heard as \n"+
			"the seal breaks down its center and the two large, marble \n"+
			"doors swing inward allowing passage through them. \n", TP);
		spoken = TPN;
		return 1;
}

enter(str) {
	if (str != "gate"){	write("Enter what?\n"); return 1;}
	else 
		if (str == "gate" && spoken != TP->query_name()){
		write(
			"Perhaps you should try speaking the words of power to \n"+
			"unlock the gate's seal before trying to pass through it. \n");
		say(TPN+" tries to go throught the gate without unlocking it first.\n",TP);
		return 1;}
	else 
		if (str == "gate" && spoken == TP->query_name()){
		write(
			"As you pass through the ancient gateway, the wind seems to \n"+
			"pick up swiftly and a low rumbling can be heard in the \n"+
			"distance.  Soon the rumbling changes to the rythmic beating \n"+
			"of wings as they cut through the air and a huge "+HIK+"obsidian"+NORM+" \n"+
			"dragon appears on the horizon, bearing down on you with \n"+
			"great speed.  Moments later, you are swept up in its great \n"+
			"claws and carried away. \n");
		say("As "+TPN+" passes through the ancient gateway, a huge "+
		HIK+"obsidian\n"+NORM+"dragon sweeps "+TPO+" up in its great "+
			"claws and carries "+TPO+" away.\n", TP);
		move_object(TP,"/players/mishtar/varminthor/gentrance");
		write(
			"Having passed out during the flight, you awake to find \n"+
			"yourself in a strange new world.");
		return 1;}
}

decipher(str){
	if(str != "runes"){ write("Decipher what?\n"); return 1;}
	if(str == "runes"){
		write(
			"Your fingers slowly trace over the ancient script and tingle \n"+
			"with magical energy as you struggle to decipher the runes.  \n"+
			"After several moments, you are thrown back as the words of \n"+
			"power are painfully burned into your mind:\n"+
			" \n"+
			HIR+"	Hakarmaskannar Revanthas"+NORM+" \n");
		TP->do_damage( ({ random(10)+5 }) , ({ "magical" }) );
		say(TPN+" slowly traces the runes and tries to decipher them.\n",TP);
		return 1;}
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
}
is_castle(){return 1;}