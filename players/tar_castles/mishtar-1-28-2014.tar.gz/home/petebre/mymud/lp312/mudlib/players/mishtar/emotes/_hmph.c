inherit "/bin/std";

void
reset(int x)
{
    if(!x)
    {
      ::reset();
      nontarget("You stick your nose in the air and go: Hmph!\n",
			    "#MN# sticks #MP# nose in the air and goes: Hmph!\n");
      target("You go hmph at #TN#.\n", "#MN# goes hmph at #TN#!\n","#MN# goes hmph at you!\n");
      afar("You go hmph at #TN# from afar!\n","#MN# goes hmph at you from afar!\n");
    }
}

int
cmd_hmph(string arg)
{
    return do_cmd(arg);
}

query_code_word() { return "verbal_kint"; }