/*Mishtar -> created 12/14/03*/
#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg);
	set_alias("halo");
	set_name(HIK+"a"+HIY+" halo"+NORM);
	set_short(HIK+"A "+HIY+"golden "+HIK+"halo"+NORM);
	set_long("\n"+HIK+"A small "+HIY+"golden"+HIK+" halo."+NORM+"\n");
    set_ac(0);
    set_weight(1);
	set_value(0);
	set_type("button");
}
drop(){	return 1;}