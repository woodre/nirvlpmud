/*Erethor: eshop.c
 *Wizard:  Mishtar
 *Created: 1/14/04
 *Edited:  5/29/04
 *Realm:   Erethor
  */

#include <ansi.h>
#include "/players/mishtar/defs.h"
inherit "players/vertebraker/closed/std/room.c";

int dummy;
/*
short() { return GRN+"Korvanthor's Antiquities
"+NORM+NORM+"[east]"; }
long(){
		if ((int)this_player()->query_brief() != 2)
		write(short()+"\n"); ::long(); 
	  }
*/
reset (int arg)
{
	if (arg) return;
	set_light(1);
	set_short(GRN+"Korvanthor's Antiquities"+NORM);
	set_long(GRN+"Korvanthor's Antiquities"+NORM+"[east]\n"+GRN+
		"A variety of wares line the shelves and cases that cover \n"+
		"nearly every inch of the small room.  Behind the counter \n"+
		"stands a jovial old half elf busy going over his ledgers \n"+
		"and mumbling softly to himself.  Behind him, on the wall, \n"+
		"is a large, red scaled head of a dragon mounted on a gold \n"+
		"plaque.  Beneath it and displayed in grand fashion, is a \n"+
		"large ornate sword.\n"+NORM);

	add_item("shelves",
			 "\nJars, bottles and an assortment of other\n"+ 
			 "odd items line the shelves of the shop");
	add_item("cases",
			 "\nThe cases hold a variety of items from simple leather\n"+
			 "armors to other more expensive trinkets");
	add_item("counter",
			 "\nThe counter is scattered with ledgers and inventory lists");
	add_item("jars",
			 "\nThe jars are filled with a variety of\n"+
			 "spices, herbs and other exotic items");
	add_item("bottles",
			 "\nA wide range of fine wines and other liquors as well as\n"+
			 "other, more acrid smelling liquids fill the assortment\n"+
			 "of bottles around the shop");
	add_item("dragon",
			 "\nA large head of a red dragon.  Its lips are curled back\n"+
			 "in a snear of rage showing rows of sharp teeth");
	add_item("sword",
			 "\nThough its silvery blade is chipped and worn, the sword still\n"+
			 "shines as if it is polished daily.  Intricate runes run the\n"+
			 "length of the blade and the hilt is covered in a fine black\n"+
			 "leather.  Atop the pummel is a dragon's claw holding a dark\n"+
			 "crimson bloodstone that seems to glow with an inner fire");
			 /*"Perhaps you could <ask> the shopkeeper about it");*/
	
	add_smell("main",
			  "\nThe crisp scent of fresh herbs and spices mixed\n"+
			  "with newly finished leather assails your senses.");			   
	
	add_exit("/players/mishtar/areas/erethor/room/eroad1.c","east");
	add_exit_msg("east", ({GRN+"You depart the shop.\n"+NORM,"departs the shop.\n"}));

	add_object("/players/mishtar/varminthor/monsters/erethor/korvanthor.c");
}

init()
{
	::init();
		add_action("north","north");
		add_action("sell","sell");
		add_action("value","value");
		add_action("buy","buy");
		add_action("list","list");

}
north()
{
    if (TPL < 30) {return 0;}
    write("You here a soft click and the door swings open for you.\n");
    move_object(TP,"/players/mishtar/areas/erethor/room/store.c");
    return 1;
}


/*Shop code adopted from /room/shop.c for the time being until I puzzle it out*/
sell(item)
{
object ob;
    if(!present(("korvanthor"),environment(this_player())))
{
	write("The merchant isn't here to run the shop.\n");
	return 1;
}
    if (!item){
	write("Korvanthor says \"What did you want to sell?\"\n");
	return 1;
}
	dummy = -TP->query_alignment();
	if(dummy>39)
{
	write("Korvanthor says to you \"I won't deal with the likes of you, begone vile menace!\"\n");
	write("Korvanthor throws you from his shop!\n");
	say("Korvanthor says to "+TPN+" \"I won't deal with the likes of you, begone vile menace!\"\n",TP);
	say("Korvanthor throws "+TPN+" from his shop!\n",TP);
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad1.c");
	return 1;
}	 
    if (item == "all")
{
	object next;
	ob = first_inventory(TP);
	while(ob) {
	    next = next_inventory(ob);
	    if (!ob->drop() && ob->query_value())
{
		write(ob->short() + ":\t");
		do_sell(ob);
}
	    ob = next;
}
	return 1;
}
    ob = present(item, TP);
    if (!ob)
	ob = present(item, TO);
    if (!ob)
{
	write("Korvanthor asks \"What are ye trying to do, cheat me?\"\n");
	write("Korvanthor says \"You don't have a "+item+" to sell!\"\n");
	return 1;
}
    do_sell(ob);
    return 1;
}

do_sell(ob)
{
    int value, do_destroy;
    value = ob->query_value();
    if (!value)
{
	write("Korvanthor says \""+(string)ob->short()+" has no value.\"\n");
	return 1;
}
    if (ENV(ob) == TP)
{
    int weight;
	if (call_other(ob, "drop", 0))
{
    write("Korvanthor says \"I wouldn't want to take "+(string)ob->short()+" from you!\n");
    return 1;
}
    weight = call_other(ob, "query_weight", 0);
	call_other(this_player(), "add_weight", - weight);
}
    if (value > 600000)
	do_destroy = 1;
    if(ob->query_dest_flag()) do_destroy = 1;
    if (value > 1000) {
    if(value < 1500) value = 1000;
    else value = 1000 + random(501);
}
    write("Korvanthor hands you "+value+" gold coins for "+(string)ob->short()+".\n");
    say("Korvanthor takes "+(string)ob->short()+" from "+TPN+" and hands "+TPO+" some coins.\n");
    call_other(this_player(), "add_money", value);
    /*add_worth(value, ob);*/
    if (do_destroy)
{
	write("The valuable item is hidden away.\n");
	destruct(ob);
	return 1;
}
    call_other("/players/mishtar/areas/erethor/room/store", "store", ob);
    return 1;
}
/*-------------------------------*/
value(item)
{
    int value;
    string name_of_item;
    if(!present(("korvanthor"),environment(this_player())))
{
	write("The merchant isn't here to run the shop.\n");
	return 1;
}
    if (!item)
{
	write("Korvanthor says \"What did you want to know the value of?\"\n");
	return 1;
}
	dummy = -TP->query_alignment();
	if(dummy>39)
{
	write("Korvanthor says to you \"I won't deal with the likes of you, begone vile menace!\"\n");
	write("Korvanthor throws you from his shop!\n");
	say("Korvanthor says to "+TPN+" \"I won't deal with the likes of you, begone vile menace!\"\n",TP);
	say("Korvanthor throws "+TPN+" from his shop!\n",TP);
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad1.c");
	return 1;
}
    name_of_item = present(item);
    if (!name_of_item)
      name_of_item = find_item_in_player(item);
    if (!name_of_item)
{
	if (call_other("/players/mishtar/areas/erethor/room/store", "value", item))
	    return 1;
	write("Korvanthor says \"No such item as "+item+" in my shop.\"\n");
	return 1;
}
    value = call_other(name_of_item, "query_value", 0);
    if (!value)
{
	write("Korvanthor says \""+item+" has no value.\"\n");
	return 1;
}
    write("Korvanthor says \"You would get "+value+" gold coins for "+item+".\"\n");
    return 1;
}

buy(item)
{
    if(!present(("korvanthor"),environment(this_player())))
{
	write("The merchant isn't here to run the shop.\n");
	return 1;
}
    if (!item)
{
	write("Korvanthor says \"What did you want to buy?\"\n");
	return 1;
}
	dummy = -TP->query_alignment();
	if(dummy>39)
{
	write("Korvanthor says to you \"I won't deal with the likes of you, begone vile menace!\"\n");
	write("Korvanthor throws you from his shop!\n");
	say("Korvanthor says to "+TPN+" \"I won't deal with the likes of you, begone vile menace!\"\n",TP);
	say("Korvanthor throws "+TPN+" from his shop!\n",TP);
	move_object(TP,"/players/mishtar/areas/erethor/room/eroad1.c");
	return 1;
}	 
    call_other("/players/mishtar/areas/erethor/room/store", "buy", item);
    return 1;
}

list(obj)
{
    if(!present(("korvanthor"),environment(this_player())))
{
	write("The merchant isn't here to show you his wares\n");
	return 1;
}
    call_other("/players/mishtar/areas/erethor/room/store", "inventory", obj);
    return 1;
}

find_item_in_player(i)
{
    object ob;

    ob = first_inventory(this_player());
    while(ob)
{
        if (call_other(ob, "id", i))
	    return ob;
	ob = next_inventory(ob);
}
    return 0;
}