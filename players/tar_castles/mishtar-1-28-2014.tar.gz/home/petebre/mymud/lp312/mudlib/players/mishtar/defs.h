/*Define inherit compiled by Mishtar as of 12/26/03*/

#pragma combine_strings

/*General*/

#define TO this_object()

/*Living Queries*/

#define QN query_name()

#define QRN query_real_name()

#define QP query_possessive()

#define QL query_level()

#define QXL query_extra_level()

#define QA(x) query_attrib(x)


/*This Player*/

#define TP this_player()

#define TPN (string)TP->query_name()

#define TPRN (string)TP->query_real_name()

#define TPL (int)TP->query_level() 

#define TPXL (int)TP->query_extra_level()

#define TPP (string)TP->query_possessive() 

#define TPA(x) (int)TP->query_attrib(x)

#define TPPN (string)TP->query_pronoun()

#define TPO	(string)TP->query_objective()


/*Find Player*/

#define FP(who) find_player(who)

#define FPN (string)who->query_name()

#define FPRN (string)who->query_real_name()

#define FPL (int)who->query_level()

#define FPXL (int)who->query_extra_level()

#define FPP (string)who->query_possessive() 

#define FPA(x) (int)who->query_attrib(x)

#define FPR (string)who->query_pronoun()

#define FPO	(string)who->query_objective()


/* ATTACKING OBJECT */

#define ATT (object)this_object->query_attack() 

#define ATTN (string)ATT->query_name() 

#define ATTRN (string)ATT->query_real_name() 

#define ATTL (int)ATT->query_level()

#define ATTXL (int)ATT->query_extra_level()

#define ATTP (string)ATT->query_possessive()

#define ATTA(x) (int)ATT->query_attrib(x)


/* ENVIRONMENTAL */

#define ENV(x) environment(x) 

#define ENVTP environment(this_player())

#define ENVTO environment(this_object())

#define ENVTOO (string)environment(ENVTO)

#define ENVQN (string)environment()->query_name()

#define ENVQRN (string)environment()->query_real_name()


/* CODING */

#define CAP(x) (string)capitalize(x) 

#define CGP CAP(genp)

#define CG3 CAP(gen3)

#define CPS capitalize(str)

#define WPS (string)wielded_by->query_possessive()

/*Workroom*/

#define OWNER "mishtar"


/*Castle*/

#define NAME "Mishtar"

#define DEST "/players/mishtar/workroom.c"
