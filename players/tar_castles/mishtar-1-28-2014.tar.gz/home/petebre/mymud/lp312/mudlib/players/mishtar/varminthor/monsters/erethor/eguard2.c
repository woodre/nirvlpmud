#include <ansi.h>
#include "/players/mishtar/random.h"
#include "/players/mishtar/defs.h"

inherit "/obj/monster.c";

string hair, gen, gen3, genp, eyes;

reset(arg) {
	::reset(arg);
	if(arg) return;
	get_random();
	set_alias("peacekeeper");
	set_name("peacekeeper");
	set_alt_name("elite");
	set_race("elf");
	set_gender((gen));
	set_short(HIK+"Erethorian Elite Peacekeeper"+NORM);
	set_long(
	  "A wild mane of "+hair+" hair frames this grizzled elf's face. \n"+
	  "Two "+eyes+" eyes scan the streets warily as "+gen3+" patrols. "+CG3+"'s\n"+
	  "clad in an ornate suit of shining platemail that has been \n"+
	  "carefully oiled and polished.  "+CG3+" casually grips the hilts of\n"+
	  "a set of twin rapiers on "+genp+" belt as "+gen3+" passes.\n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
