/*Mishtar -> created 12/14/03*/
#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg);
	set_alias("collar");
	set_name(HIK+"a "+HIR+"jeweled "+HIR+"dragon collar"+NORM);
	set_short(HIK+"A "+HIR+"jeweled "+HIK+"dragon collar"+NORM);
	set_long("\n"+HIK+"A sturdy black leather collar studded with "+HIR+"red"+HIK+" jewels."+NORM+"\n");
    set_weight(1);
	set_ac(0);
	set_value(0);
	set_type("button");
}