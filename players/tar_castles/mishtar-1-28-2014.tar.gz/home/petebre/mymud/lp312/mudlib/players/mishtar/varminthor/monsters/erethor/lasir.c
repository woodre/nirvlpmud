#include <ansi.h>

inherit "/obj/monster.c";

reset(arg) {
	::reset(arg);
	if(arg) return;
	set_alias("lasir");
	set_name("lasir");
	set_alt_name("barmaid");
	set_race("elf");
	set_gender("female");
	set_short(HIK+"Lasir the Barmaid"+NORM);
	set_long(
	  "A young, golden eyed elf bustles about struggling to keep up with the requests \n"+
	  "of each of her customers.  A long mane of golden hair flows wildly about her \n"+
	  "shoulders.  She wears a small apron tied over a simple blue silk dress.  She \n"+
	  "gives you a soft smile when she notices you looking at her. \n");

	set_level(20);
	set_hp(800);
	set_al(800);
	set_wc(40+random(5));
	set_ac(10+random(5));
}
