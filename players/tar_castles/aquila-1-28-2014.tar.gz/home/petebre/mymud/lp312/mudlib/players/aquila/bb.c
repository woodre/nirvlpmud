init(){
add_action("c","c");
}
c(str) {
find_player(str)->write_tellhistory();
write("done");
return 1;
}
