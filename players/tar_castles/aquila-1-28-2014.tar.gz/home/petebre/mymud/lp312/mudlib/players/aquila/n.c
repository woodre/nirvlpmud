init() {
add_action("ffg","ffg");
}
ffg(str) {
write_file("/log/WR/aquila_workreport",str);
return 1;
}
id(str) {
return str == "n";
}
