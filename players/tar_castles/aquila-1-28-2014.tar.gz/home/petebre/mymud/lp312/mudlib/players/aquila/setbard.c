init()
{
  find_player("aquila")->set_guild_name("bard");
  find_player("aquila")->set_guild_rank(50);
  present("instrument",find_player("aquila"))->set_bard_level("20");
}
get() { return 1;}
