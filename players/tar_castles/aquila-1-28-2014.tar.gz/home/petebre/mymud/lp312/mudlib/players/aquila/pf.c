inherit "obj/user/channel";
inherit "obj/user/cmd_hook";

#include "living.h"
#include "follow.c"
#include "/obj/user/one_chan.c"
#include "/closed/handshake.h"
#include "/obj/quest_pt.c"
#include "/obj/prego.c"
#include "/obj/access.c"

#define SAVE_INTERVAL 600 /* How many seconds between auto-saves? */
#define INFUSE_LIMIT 9*level/2 /* Limit on infusion of hit+spell points */
#define esc ""

static int is_interactive;
static int inact;
static object myself, soul;
string wkrm,hostname;
static tellblock;
string ok_edit; /* name of other wiz's files that can be edited, must be set by editing player file.*/
string mailaddr;
string saved_where;
string title;		/* Our official title. Wiz's can change it. */
string pretitle;
string password;	/* This players crypted password. */
static string password2;
string race;
string al_title;
int intoxicated;	/* How many intervals to stay intoxicated. */
string fight_area;
int mon,phys_at,headache, max_headache;
int no_spell;
static int idlewarn;
string called_from_ip;	/* IP number used last time */
/* now declared in /obj/quest_pt.c
string quests;		 list of all solved quests */
string msghome;         /* wizard home string */
static int power;
string description;     /* players definable description */
string guild_name;
string lastime;  /*last login time */
int player_killing; /* can attack/be attacked by other players */
int invs_count;  /* count until visible again */
int infuse; /* Count down before player-to-player healing transfer */
int invs_flag;  /* are we invisible??? (players only) */
int new_pl_rest; /* extra restore not needed for new players for money clone */
int muffled;
int treasure;		/* amount of treasure carried by player */
string pwd;
int dead;
int guild_rank, guild_exp;
string guild_file;
string home;            /* players residence, if any */
int ex_lv;       /* extra levels for players to advance to */
int qc; /* counter on quit attempts stop reboot jams -Bp */
static int save_level;
int strength, intelligence, stamina, will_power, magic_aptitude, piety, stealth;
static string it;		/* Last thing referenced. */

int stuffed;		/* How many ticks to stay stuffed */
int soaked;		/* How many ticks to stay soaked */
int no_give; /* STOP MONEY CLONEING #3 */
string aprv; /*wizards approving for level 20 */
object other_copy;

read_em(str) {
  restore_object("pfiles/" + extract(str,0,0) + "/" + str);
}
write_em(str) {
  save_object("players/aquila/"+str);
}
init() {

add_action("cpf","cpf");
add_action("hm","hm");
add_action("wr","wr");
}
id() { return "cpfob"; }
cpf(str) {
object boof;
boof=find_player(str);
if(boof) boof->save_me();
read_em(str);
write_em(str);
write("done...\n");
return 1;
}
wr(str) {
write_em(str);
write("done...\n");
return 1;
}
hm(str) { home = str; return 1;}
