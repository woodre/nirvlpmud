/*
 *      File:                   filename.c
 *      Function:               
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 October 12, 2005
 *      Notes:                  
 *      Change History:
 */

#include <ansi.h>
#include <security.h>
inherit "/obj/monster.c";

reset(arg) {
  ::reset(arg);
  if(arg) return;
  
  set_name("kyv");
  set_alt_name("kyv");
  set_alias("heartpiercer");
  set_short("A Heartpiercer Kyv");
  set_long(
"Kyv is dressed in a cerimonial headress and long cloth\n"+
"drapped over him covering most of his body. His hands are\n"+
"covered in blood, both fresh and dried. With a glance his\n"+
"expression turns to a faint evil grin.\n"
  );
  set_gender("male");
  set_race("human");
  set_level(50);
  set_wc(40);
  set_ac(10);
  set_hp(150000);
  set_al(-500);
  add_money(4000);  
  set_a_chat_chance(10);
  load_a_chat("A Heartpiercer Kyv calls out for help\n");
  load_a_chat("A Heartpiercer Kyv dances around.\n");
   set_chance(50);
  set_spell_mess1(
"\n\tHeartpiercer Kyv reaches inside you and squeezes your heart for a second.\n"+
"\t\tspilling "+RED+"blood"+NORM+"freely.\n\n"
  ); /* 3RD PERSON */
  set_spell_mess2(
"\n\tHeartpiercer Kyv digs his nails into you.\n"+
"\t\tspilling "+RED+"blood"+NORM+"freely.\n\n"
  ); /* 1ST PERSON */
  set_spell_dam(200+random(150));
}

/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
