/*
 *      File:                   roomtemplate.c
 *      Function:               
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 10/12/05
 *      Notes:                  
 *      Change History:
 */

#include <ansi.h>
#include <security.h>
inherit "/room/room.c";

reset(int arg)
{
   if(arg) return;
   set_light(1);
   set_short("Inside a cave");
   set_long(
      "  There are stalagmites protruding from the ground making \n"+
      "it difficult to more further into the cave. A narrow \n"+
      "passage continues onward as it becomes more difficult. \n");
 
   add_item("stalagmites","Huge pieces of rock growing up from the floor that have formed over millions of years");
   add_item("stalagtites","Huge pieces of rock growing down from the ceiling that have formed over millions of years");

   add_exit("/players/veeshan/pod/northtunnel2.c","north"); 
   add_exit("/players/veeshan/pod/caveenterance.c","south"); 
}


/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
