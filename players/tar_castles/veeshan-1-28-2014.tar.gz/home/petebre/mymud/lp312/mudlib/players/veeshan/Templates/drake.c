/*
 *      File:                   filename.c
 *      Function:               
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 October 12, 2005
 *      Notes:                  
 *      Change History:
 */

#include <ansi.h>
#include <security.h>
inherit "/obj/monster.c";

reset(arg) {
  ::reset(arg);
  if(arg) return;
  
  set_name("drake");
  set_alt_name("dragon");
  set_alias("drake");
  set_short("A Drake");
  set_long(
"A rather small looking dragon grey in color with small \n"+
"spikes protruding across it's whole body. It has razor\n"+
"sharp claws covered in blood that can inflict massive\n"+
" damage if provoked.\n"
  );
  set_gender("male");
  set_race("human");
  set_level(20);
  set_wc(22);
  set_ac(30);
  set_hp(1500);
  set_al(-500);
  add_money(4000);  
  set_a_chat_chance(10);
  load_a_chat("A Heartpiercer Kyv calls out for help\n");
  load_a_chat("A Heartpiercer Kyv dances around.\n");
   set_chance(15);
  set_spell_mess1(
"\n\tDrake reaches scratches you spilling "+RED+"blood"+NORM+"freely.\n\n"
  ); /* 3RD PERSON */
  set_spell_mess2(
"\n\tA Drake digs his nails into you spilling "+RED+"blood"+NORM+"freely.\n\n"
  ); /* 1ST PERSON */
  set_spell_dam(20+random(30));
}

/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
