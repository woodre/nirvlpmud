/*
 *      File:                   roomtemplate.c
 *      Function:               
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 10/12/05
 *      Notes:                  
 *      Change History:
 */

#include <ansi.h>
#include <security.h>
inherit "/room/room.c";

reset(int arg)
{
   if(arg) return;
   set_light(1);
   set_short("Cave Entrance");
   set_long(
      "  A large cave entrance that moves deeper into the darkness. \n"+
      "Large stalagmites and stalagtites cluster this area making \n"+
      "it hard to move around. The tunnel to the east seams quite \n"+
      "smaller and tougher to get through. \n");
 
   add_item("stalagmites","Huge pieces of rock growing up from the floor that have formed over millions of years");
   add_item("stalagtites","Huge pieces of rock growing down from the ceiling that have formed over millions of years");

   add_exit("/players/veeshan/pod/northtunnel1.c","north"); 
}


/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
