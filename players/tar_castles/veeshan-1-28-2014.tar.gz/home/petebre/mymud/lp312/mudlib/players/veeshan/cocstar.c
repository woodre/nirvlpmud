/*
 *      File:                   coc.c
 *      Function:               wiztool for echostar
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 10/12/05
 *      Notes:                  
 *      Change History:
 */

#include "ansi.h"
#include <security.h>
inherit "/obj/treasure";

main(str)
{
   string who, what;
   object *us; int x;
   if(!str)
      {
      write("No.\n");
      return 1;
   }
   if(sscanf(str,"%s#%s",who,what) < 2)
      {
      write("No.\n");
      return 1;
   }
   us = users();
   for(x=0;x<sizeof(us);x++)
   {
      if(present("star_tattoo",us[x]) && !(present("star_tattoo",us[x])->query_muff()))
         {
         tell_object(us[x],YEL+"~*~"+NORM+BOLD+CAP(who)+NORM+YEL+"~*~:"+NORM+" "+what+"\n");
       }
   }
   write("Okay.\n");
   return 1;
}


void reset(status arg) {
  set_id("stick");
  set_alias("magic stick");
  set_short("A special stick");
  set_weight(1000);
  set_value(0);
}


/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
