#include <ansi.h>
inherit "/players/wocket/std/wiztell.c";

reset(arg){
  if(arg) return;
  owner = "veeshan";
  cap_owner = "Veeshan";
  color = HIR;
  extra_look = "yeh yeh Veeshan is a motherf**kin' pimp";
}

