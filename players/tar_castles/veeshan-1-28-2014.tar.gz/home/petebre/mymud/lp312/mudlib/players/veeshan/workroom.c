/*
 *      File:                   roomtemplate.c
 *      Function:               
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 10/12/05
 *      Notes:                  
 *      Change History:
 */

#include <ansi.h>
#include <security.h>
inherit "/room/room.c";

reset(int arg)
{
   if(arg) return;
   set_light(1);
   set_short(HIW+"Plane"+NORM+HIK+" of"+HIR+" Dragons"+NORM);
   set_long(
      "  This is the enterance to the mighty Plane. There are several\n"+
      "dragon statues standing in upwards of 30 feet each. A shimmering \n"+
      "portal stands in the middle of the room. \n");
 
   add_item("statues","Large grey statues of mighty dragons that have been known to rule the Plane");
   add_item("portal","A magical portal to the Plane of Dragons");

   add_exit("/players/veeshan/workroom2.c","Enter"); 
}


/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
