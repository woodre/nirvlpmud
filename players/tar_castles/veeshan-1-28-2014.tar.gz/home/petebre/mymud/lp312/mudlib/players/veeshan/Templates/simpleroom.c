/*
 *      File:                   roomtemplate.c
 *      Function:               
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 10/12/05
 *      Notes:                  
 *      Change History:
 */

#include <ansi.h>
#include <security.h>
inherit "/room/room.c";

reset(int arg)
{
   if(arg) return;
   set_light(1);
   set_short("Village Green");
   set_long(
      "  This is a fairly wide open room that spans as far as the eyes \n"+
      "can see in each direction. There is a small sign stuck into the \n"+
      "ground beneath your feet. \n");
 
   add_item("sign","Welcome to my test room!");

   add_exit("/room/church.c","north");
   add_exit("/room/vill_green.c","west"); 
   add_exit("/players/veeshan/workroom.c","east"); 
}


/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
