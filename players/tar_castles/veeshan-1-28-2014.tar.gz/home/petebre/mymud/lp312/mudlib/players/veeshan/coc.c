/*
 *      File:                   coc.c
 *      Function:               wiztool for echochan
 *      Author(s):              Veeshan@Nirvana
 *      Copyright:              Copyright (c) 2005 Veeshan
 *                                      All Rights Reserved.
 *      Source:                 10/12/05
 *      Notes:                  
 *      Change History:
 */

#include "ansi.h"
#include <security.h>
inherit "/obj/treasure";

#pragma strict_types
#pragma save_types

int
cmd_echan(string str) {
  string message, channel;
  int count;

   if (sscanf(str, "%s %s", channel, message) != 2) {
    write("Echo what on what channel?\n");
    return 1;
  }
  count = emit_channel(channel, message + "\n");
  write(format("You echo " + message + " to " + count +
    " people on channel " + channel + "."));
  return 1;
}

void init() {add_action("cmd_echan",
"echochan"); }

void reset(status arg) {
  set_id("stick");
  set_alias("magic stick");
  set_short("A stick");
  set_weight(100);
  set_value(0);
}


/* 
 * Function name:
 * Description:
 * Arguments:
 * Returns:
 */
