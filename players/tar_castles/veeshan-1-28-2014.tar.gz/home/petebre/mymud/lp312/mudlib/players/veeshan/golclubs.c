#include "/players/fred/ansi.h"
inherit "obj/treasure";

reset(arg){
if(!arg){

  set_id("clubs");
  set_short(BOLD+"A"+HIY+" SET OF"+RED+" GOLF"+GRN+" Clubs"+NORM);
  set_long("A very large cannon to get your"+BOLD+RED+" REVENGE!!!"+NORM+"\n"+
                "Use "+GRN+"help_clubs"+NORM+" to see how!\n");
   } 
 }

init(){
 ::init();
  add_action("helpem","help_clubs");
  add_action("bombem","bomb");
 }

helpem(){
  write("To use this kick ass set of clubs simply:\n\n");
  write("1: bomb <name>\n");
  write("2: point and laugh at said <name>\n");
  return 1; }

bombem(str){
  object who;
  if (str == "earwax") str = "veeshan";
  if(!str){ write("Hit the ball at who?\n"); return 1; }
  who = find_player(str);
  if(!who){ write("You can't find that person.\n"); return 1;}
   write("You aim the club at "+capitalize(str)+ " and start your swing!\n\n");
   tell_object(who,
   capitalize(this_player()->query_name())+" hits an explosive golf ball at you."+BOLD+"\n"+
   "            RUN!!"+NORM+"\n\n");
    tell_room(environment(who),
   capitalize(this_player()->query_name())+" hits the ball at "+capitalize(str)+"."+BOLD+"\n"+
  "         FORE!!!"+RED+"\n\n"+
  "BBBBBBBBB            OOOOOOO           OOOOOOO       MM             MM\n"+
  "BB       BB        OO       OO       OO       OO     MM MM       MM MM\n"+
  "BB        BB      OO         OO     OO         OO    MM  MM     MM  MM\n"+
  "BB        BB     OO           OO   OO           OO   MM   MM   MM   MM\n"+
  "BB       BB      OO           OO   OO           OO   MM    MM MM    MM\n"+
  "BBBBBBBBB        OO           OO   OO           OO   MM     MM      MM\n"+
  "BB       BB      OO           OO   OO           OO   MM             MM\n"+
  "BB        BB      OO         OO     OO         OO    MM             MM\n"+
  "BB        BB       OO       OO       OO       OO     MM             MM\n"+
  "BBBBBBBBBB           OOOOOOO           OOOOOOO       MM             MM"+NORM+BOLD+"\n\n"+
  "                     "+capitalize(str)+" done got fucked up!"+NORM+"\n");
  destruct(who);
  write("You fire the cannon at "+capitalize(str)+BOLD+BLU+"\n\n"+
  "BBBBBBBBB            OOOOOOO           OOOOOOO       MM             MM\n"+
  "BB       BB        OO       OO       OO       OO     MM MM       MM MM\n"+
  "BB        BB      OO         OO     OO         OO    MM  MM     MM  MM\n"+
  "BB        BB     OO           OO   OO           OO   MM   MM   MM   MM\n"+
  "BB       BB      OO           OO   OO           OO   MM    MM MM    MM\n"+
  "BBBBBBBBB        OO           OO   OO           OO   MM     MM      MM\n"+
  "BB       BB      OO           OO   OO           OO   MM             MM\n"+
  "BB        BB      OO         OO     OO         OO    MM             MM\n"+
  "BB        BB       OO       OO       OO       OO     MM             MM\n"+
  "BBBBBBBBBB           OOOOOOO           OOOOOOO       MM             MM"+NORM+BOLD+"\n\n"+
  capitalize(str)+" is blown to bits!"+NORM+"\n\n");  
  return 1; }

      
