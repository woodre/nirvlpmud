inherit "obj/monster";
init(){
   add_action("give","give");
   add_action("show","show");
}

reset(arg){
   ::reset(arg);
   if(arg) return;
   set_name("daemontologist");
   set_race("elf");
   set_alias("man");
   set_short("A elf daemontologist");
   set_long("The daemontologist eyes you appraisingly. He seems dangerous,\nbut wise...\n\n");
   set_level(22);
   set_hp(1350);
   set_al(0);
   set_wc(25);
   set_ac(16);
   set_chance(15);
   set_spell_dam(random(20)+10);
   set_spell_mess1("The daemontologist summons a funnel of silver flames!");
   set_spell_mess2("You are overcome by the heat of a summoned funnel of silver flames.");
   set_chat_chance (20);
   load_chat("The daemontologist chants, 'Je ne maja. Je ne soi. Je ne je.'\n");
   load_chat("The drow throws magical dust into a small brazier.\n");
   load_chat("The daemontologist whispers, 'The priestess must pay....'\n");
   load_chat("The elf mutters, 'They should have returned with that jar by now.'\n");
   load_chat("The drow says, 'A party such as you went after the necessary\ncomponents, but I fear they are lost to the mazes.'\n");
}
give(arg){
   object sealedjar;
   string what,to,who;
   if(sscanf(arg, "%s %s %s",what,to,who) == 3){
      if(what=="jar" && to=="to" && who=="daemontologist"){
         if(present("platinumjar",this_player())){
            say(capitalize(this_player()->query_real_name())+" hands the drow a jar.\n");
            say("The drow raises the jar and begins a quick chanting...\n");
            say("A great wind arises, you hear a shriek.\n");
            say("A spirit appears out of nowhere and is sucked into the jar!\n");
            say("The man hands "+capitalize(this_player()->query_real_name())+ " a now sealed jar.\n");
            destruct(present("platinumjar",this_player()));
            sealedjar=clone_object("/players/ladyfinger/obj/sealedjar");
            move_object(sealedjar,this_player());
            return 1;
         }
         write("The daemontologist grunts. You don't seem to have the right jar.\n");
         return 1;
      }
      return 0;
   }
   write("Give what to who?\n");
   return 1;
}
show(arg){
   int x,ma;
   if(!arg){
      write("Show what?\n");
      return 1;
   }
   if(arg!="aura"){
      write("The daemontologist has no interest in your "+arg+".\n");
      return 1;
   }
   if(arg=="aura"){
      if(!restore_object("players/sweetness/qlog/"+this_player()->query_real_name())){
         write("You must solve the quest.\n");
         return 1;
      }
   }
   if(arg=="aura"){
      if(present("baura",this_player())){
         ma=this_player()->query_attrib("mag");
         if(ma>=20){
            x=30-ma;
            this_player()->raise_magic_aptitude(x);
            write("The daemontologist examines your aura approvingly.\nHe chants and smears your face with blood.\nCongratulations, you are now more skilled in the ways of magic.\n");
            return 1;
         }
         else{write("The daemontologist says: You are not yet skilled enough in the ways of magic.\n");
            return 1;
         }
      }
      if(!present("baura",this_player())){
         if(!restore_object("players/sweetness/qlog/"+this_player()->query_real_name())){
            write("The daemontologist looks at you and says: I'm sure your aura is\na very nice aura, but I am intrested in only black auras.\n");
            return 1;
         }
         move_object(clone_object("/players/sweetness/obj/aura"),this_player());
         command("show aura",this_player());
         return 1;
      }
   }
}
