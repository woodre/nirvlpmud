inherit "room/room";
reset(arg) {
   if(arg){extra_reset(); return;}
   short_desc = "tinkor the terrible";
   long_desc = "This is a small nitch in the rocky cliff\n"+
   "wall. A tiny man, Tinkor, pours over the\n"+
   "map of the vale, ploting evil plans.\n";
   set_light(1);
   dest_dir =
   ({
         "/players/ladyfinger/room/caves/pathc", "north",
    });
   extra_reset();
}
extra_reset(){
   object monster;
   if(!present("mage")){
      monster=clone_object("/players/ladyfinger/monster/mage");
      move_object(monster,this_object());
   }
}
