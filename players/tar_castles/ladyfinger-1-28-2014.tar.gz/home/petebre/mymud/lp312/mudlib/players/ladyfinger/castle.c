#define NAME "Ladyfinger"
#define DEST "room/townh"
/*
* This is just the facade to a castle. If you want to enable the
* "enter" command, move the player to a hall or something (which
   * you have to design yourself).
* The predefined string DEST is where a player should come when he
* leaves the castle.
*
* This file is loaded automatically from "init_file". We have to move
* ourself to where we are supposed to be.
*/

id(str) { return str == "door"; }

short() {
   return "Door to the Vale of the Druids to the north";
}

is_castle() { return 1; }

long() {
   write("A door is here back of the hall.\n");
   write("It is rumored to lead to the peaceful land of the druids...\n");
   write("Why not step north through the door and see for yourself?\n");
}

init() {
   add_action("north");
   add_verb("north");
}

north(){
   write("You are pulled through the doorway to the north!\n");
   move_object(this_player(),"/players/ladyfinger/room/vale/landa");
   command("look",this_player());
   tell_room(DEST,this_player()->query_name()+" leaves north through the door.\n");
   return 1;
}

reset(arg) {
   object room,quest;
   room = find_object("room/quest_room");
   if (!present("vale",room)){
      quest = clone_object("obj/quest_obj");
      quest->set_name("vale");
      quest->set_hint("Seek out the druid sage of the vale. He might have a task for you.\n");
      move_object(quest,room);
   }
   if (arg)
      return;
   move_object(this_object(), DEST);
}
