inherit "obj/armor";
int var;
init(){
   add_action("wear","wear");
   add_action("remove","remove");
   add_action("fill","fill");
   add_action("vit"); add_verb("vit");
}
reset(arg){
   ::reset(arg);
   set_short("Ring of spell storing");
   set_long("This highly prized ring provides\n"+
      "protection, but you can also charge\n"+
      "the it with spell points <fill number>\n"+
      "and then vitalize yourself later\n"+
      "<vit number>.\n");
   set_ac(1);
   set_weight(1);
   set_value(10000);
   set_alias("spellring");
   set_name("ring");
   set_type("ring");
}

refresh_desc(){
   set_short("Ring of spell storing with "+ var +" points");
   return;
}
fill(arg){
   int a,b;
   if (!arg){
      write("Fill the ring with how much?\n");
      return 1;
   }
   if(sscanf(arg,"%d",b) != 1){
      write("To charge the ring please type, 'fill <number>'.\n");
      return 1;
   }
   a = this_player()->query_spell_point();
   if(b > a){
      write("You don't have the necessary magical energy.\n");
      return 1;
   }
   if (b < 1){
      write("That is not possible.\n");
      return 1;
   }
   var = var +b;
   if (var > 75){
      write("I'm sorry, but that would excede the ring's limit of 75.\n");
      var = var - b;
      return 1;}
   this_player()->add_spell_point(-b);
   write("The magic has been absorbed into the ring.\n");
   refresh_desc();
   return 1;
}
vit(arg){
   int a,b,now,ideal;
   if (!arg){
      write("How much do you wish to absorb from the ring?\n");
      return 1;
   }
   if(sscanf(arg,"%d",b) != 1){
      write("To vitalize yourself please use, 'vit <number>'.\n");
      return 1;
   }
   a = this_player()->query_msp();
   now = this_player()->query_spell_point();
   ideal = a - now;
   if(b < var || b == var){
      if (b > ideal){
         write("You absorb " + ideal + " before reaching your limit!\n");
         this_player()->add_spell_point(ideal);
         var = var - ideal;
         refresh_desc();
         return 1;
      }
      if(b < 1){
         write("How would you do that?\n");
         return 1;
      }
      write("You absorb " + b + " and vitalize yourself.\n");
      this_player()->add_spell_point(b);
      var = var - b;
      refresh_desc();
      return 1;
   }
   write("There does not seem to be that much magic in the ring.\n");
   return 1;
}
long(){write("This highly prized ring provides\nprotection, but you can also charge\nthe it with spell points <fill number>\nand then vitalize yourself later <vit\number>.\n");}
