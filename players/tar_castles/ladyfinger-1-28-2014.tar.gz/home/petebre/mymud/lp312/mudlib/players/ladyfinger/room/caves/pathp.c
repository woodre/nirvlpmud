inherit "room/room";
reset(arg) {
   if(arg){extra_reset(); return;}
   short_desc = "a strange pit";
long_desc="This area is quite dark, however, you keen powers of\nobservation detect an opening in the ceiling you could\neasily climb through. A breeze blows down from it. You\ncan hear various sounds of battle as well.\n";
   set_light(1);
   dest_dir =
   ({
         "/players/ladyfinger/room/caves/patho", "west",
         "/players/ladyfinger/room/drow/rooma", "up",
    });
   extra_reset();
}
extra_reset(){
   object monster;
   if(!present("snakeman")){
      monster=clone_object("/players/ladyfinger/monster/snakeman");
      move_object(monster,this_object());
   }
}
