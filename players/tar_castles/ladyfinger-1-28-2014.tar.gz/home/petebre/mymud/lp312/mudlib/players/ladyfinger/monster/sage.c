inherit "obj/monster";
object room;

init(){
   add_action("yell","yell");
}
reset(arg){
   object gold,staff;
   ::reset(arg);
   if(arg) return;
   set_name("druid");
   set_race("human");
   set_alias("sage");
   set_short("A blind druid sage");
   set_long("The old sage seems to gaze into nothing with blind eyes.\n");
   set_level(30);
   set_hp(4000);
   set_al(1000);
   set_wc(30);
   set_ac(20);
   gold=clone_object("obj/money");
   gold->set_money(2000);
   move_object(gold,this_object());
   staff=clone_object("players/ladyfinger/obj/woodstaff");
   move_object(staff,this_object());
}
yell(arg){
   room = environment(this_object());
   if (!arg){
      write("Yell what?\n");
      return 1;
   }
   if (arg == "hello" || arg == "hi"){
      if (present("iridiumcrown",this_player())){
         tell_room(room,"The druid exclaims, 'You have returned with\n");
         tell_room(room,"the fabled Midnight Crown! I must destroy it\n");
         tell_room(room,"at once!' The druid begins chanting... the\n");
         tell_room(room,"crown glows red... the crown glows blue...\n");
         tell_room(room,"and finnaly it glow white before vanishing\n");
         tell_room(room,"utterly. The midnight crown is no more.\n");
         destruct(present("iridiumcrown",this_player()));
         this_player()->add_exp(1000);
this_player()->set_quest("vale");
         return 1;
       }
      if (present("tincrown",this_player())){
         tell_room(room,"The druid takes the tin crown and looks sad.\n");
         tell_room(room,"'I am afraid that you have been tricked. This\n");
         tell_room(room,"This crown is a fake,' says the old man. 'I\n");
         tell_room(room,"fear that you have been duped by a great evil.'\n");
         destruct(present("tincrown",this_player()));
         return 1;
       }
      tell_room(room,"'Oh!' says the sage, a little startled. 'I didn't\n");
      tell_room(room,"hear you come in.' He thinks for a second... 'If\n");
      tell_room(room,"you are hear about the evil menace north of the\n");
      tell_room(room,"mountains, you should know that somone is massing\n");
      tell_room(room,"an army. We have sent spies, but we recently lost\n");
      tell_room(room,"contact. If you venture up that way, would you\n");
      tell_room(room,"please, uh--uhm--errr, that is, could you destroy\n");
      tell_room(room,"evil menace and bring back proof of the deed?'\n");
      tell_room(room,"The sage blushes before staring off again.\n");
      return 1;
   }
   write("You fail to get the old druid's attention yelling that.\n");
   return 1;
}
