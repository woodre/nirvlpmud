inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
   set_name("Anything sword");
   set_alt_name("sword");
   set_alias("sword");
   set_short("Broad sword");
   set_long("This is a mysterious broadsword...\n");
   set_class(17);
   set_weight(3);
   set_value(35000);
   set_hit_func(this_object());
}

weapon_hit(attacker){
   int x;
   if (random(100) > 70){
      x = random(100);
      if (x < 10){
         this_object()->set_class(8);
         this_object()->set_short("A puny dagger <Anything sword>");
         say(capitalize(this_player()->query_name()) + "'s Anything Sword flahes brightly.\n The blade becomes a puny dagger.\n\n");
         write("The Anything Sword glows brightly!\n");
         write("You now wield a puny dagger.\n");
       }
      if (x < 30 && x > 9){
         this_object()->set_class(13);
         this_object()->set_short("A balanced hand axe <Anything sword>");
         say(capitalize(this_player()->query_name()) + "'s Anything Sword flahes brightly.\n The blade becomes a balanced hand axe.\n\n");
         write("The Anything Sword glows brightly!\n");
         write("You have a balanced hand axe.\n");
       }
      if (x < 65 && x > 29){
         this_object()->set_class(17);
         this_object()->set_short("A fine broadsword <Anything sword>");
         say(capitalize(this_player()->query_name()) + "'s Anything Sword flahess brightly.\n The blade becomes a fine broadsword.\n\n");
         write("The Anything Sword glows brightly!\n");
         write("You hold a fine broadsword.\n");
       }
      if (x < 90 && x > 64){
         this_object()->set_class(20);
         this_object()->set_short("A supurb battle axe <Anything sword>");
         say(capitalize(this_player()->query_name()) + "'s Anything Sword flahes brightly.\n The blade becomes a supurb battle axe!\n\n");
         write("The Anything Sword glows brightly!\n");
         write("You swing a supurb battle axe!\n");
       }
      if (x > 89){
         this_object()->set_class(30);
         this_object()->set_short("A glowing longsword <Anything sword>");
         say(capitalize(this_player()->query_name()) + "'s Anything Sword flahes brightly.\n The blade becomes a glowing longsword!\n\n");
         write("The Anything Sword glows brightly!\n");
         write("A glowing longsword has appeared!\n");
       }
      command("unwield anything",this_player());
      command("wield anything",this_player());
      return 0;
   }
}
id(str){return str == "anything" || str == "sword";}
