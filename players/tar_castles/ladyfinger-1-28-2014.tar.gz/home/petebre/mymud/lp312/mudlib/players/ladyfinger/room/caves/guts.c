inherit "room/room";
reset(arg) {
   if(arg){extra_reset(); return;}
   short_desc = "inside the worm";
   long_desc="You are knee deep in acid! Every moment you are\n"+
   "in this room you are hurt! Your only hope will be\n"+
   "chop an opening and free yourself!\n";
   set_light(1);
   dest_dir =
   ({
    });
   extra_reset();
}
extra_reset(){
   object monster,gold,skin,log,ring,opening,fungus;
   if(present("opening")){
      destruct(present("opening",this_object()));
   }
   if(!present("guts")){
      monster=clone_object("/players/ladyfinger/monster/guts");
      move_object(monster,this_object());
   }
   if(!present("coins")){
      gold=clone_object("obj/money");
      gold->set_money(1000 + random(1000));
      move_object(gold,this_object());
   }
   if(!present("fungus")){
      fungus=clone_object("players/ladyfinger/obj/worm_fungus");
      move_object(fungus,this_object());
   }
   if(!present("skin")){
      skin=clone_object("players/ladyfinger/obj/skin");
      move_object(skin,this_object());
   }
   if(!present("log")){
      log=clone_object("players/ladyfinger/weapon/log");
      move_object(log,this_object());
   }
   if(!present("ring")){
      ring=clone_object("players/ladyfinger/armor/nose_ring");
      move_object(ring,this_object());
   }
}
realm(){return "NT";}
