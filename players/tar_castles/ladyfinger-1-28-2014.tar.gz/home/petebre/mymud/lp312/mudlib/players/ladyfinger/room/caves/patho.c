inherit "room/room";
reset(arg) {
   if(arg){extra_reset(); return;}
   short_desc = "a strange pit";
   long_desc="You're heart skips a beat as you descend into a\npit that is only partially lighted. You can,\nhowever, hear the din of battle echoing through the\npassage to the east.\n";
   set_light(1);
   dest_dir =
   ({
         "/players/ladyfinger/room/caves/pathp", "east",
         "/players/ladyfinger/room/caves/pathl", "up",
    });
   extra_reset();
}
extra_reset(){
   object monster;
   if(!present("snakeman")){
      monster=clone_object("/players/ladyfinger/monster/snakeman");
      move_object(monster,this_object());
   }
}
