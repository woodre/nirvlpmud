inherit "room/room";
reset(arg) {
   if(arg) return;
   short_desc = "Ladyfinger's Playpen";
   long_desc = "Every newbie-wiz needs to have her own home away\n"+
   "from home. Ten manservants line the walls... here to\n"+
   "serve and obey...\n";
   set_light(1);
   dest_dir =
   ({
         "/room/church", "church",
         "/room/shop", "shop",
         "/players/sweetness/closed/workroom", "sweetness",
         "/players/ladyfinger/room/vale/landa","vale",
         "/players/ladyfinger/room/drow/rooma","drow",
    });
}
realm(){return "NT";}
