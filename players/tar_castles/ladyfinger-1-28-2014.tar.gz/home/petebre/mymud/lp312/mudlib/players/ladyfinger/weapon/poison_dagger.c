inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
   set_name("dagger");
   set_alt_name("knife");
   set_alias("dagger");
   set_short("A poisoned dagger");
   set_long("This dagger is laced with a poison deadly to humans!\n");
   set_class(15);
   set_weight(2);
   set_value(1000);
   set_hit_func(this_object());
}
weapon_hit(attacker){
   string race;
   if (attacker->id("human")){
      if (1 == random(8)){
         write("Your poisoned blade really does the trick!\n");
       }
      return 10;
   }
   else{
      return 0;
   }
}
