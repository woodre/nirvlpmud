inherit "obj/monster";
object attacker;
string attacker_name;

reset(arg){
   object gold,hailstaff;
   ::reset(arg);
   if(arg) return;
   set_name("tinkor");
   set_race("human");
   set_alias("mage");
   set_short("Tinkor, the evil mage");
   set_long("The mage shimmers with a soft glow of power.\n");
   set_level(26);
   set_hp(1700);
   set_al(-850);
   set_wc(14);
   set_ac(12);
   set_dead_ob(this_object());
   gold=clone_object("obj/money");
   gold->set_money(2500);
   move_object(gold,this_object());
   hailstaff=clone_object("players/ladyfinger/obj/hailstaff");
   move_object(hailstaff,this_object());
   set_heart_beat(1);
}
heart_beat(){
   int a,b;
   object room;
   ::heart_beat();
   room = environment(this_object());
   attacker=this_object()->query_attack();
   if(attacker){
      attacker_name=attacker->query_real_name();
      if(present(attacker_name,environment(this_object()))){
         b = random(100);
         if (b < 65){
            a = random(6);
            if (a < 3){
               attacker->hit_player(random(18));
               if (1 == random(2)){
                  tell_room(room,"Tinkor summons a shower of acid.\n");
                }
               else{
                  tell_room(room,"An arc of fire springs from the mage's hands.\n");
                }
               tell_room(room,"\n");
             }
            
            if (a > 3){
               attacker->hit_player(random(25)+10);
               if (1 == random(2)){
                  tell_room(room,"Tinkor gestures... You are crushed by an intangible force!\n");
                }
               else{
                  tell_room(room,"The mage conjures a hundred flying daggers!\n");
                }
               tell_room(room,"\n");
             }
            
            if (a == 3){
               attacker->hit_player(random(40)+20);
               tell_room(room,"Tinkor draws upon ancient power and bathes you in liquid magic!!!\n");
               tell_room(room,"You feel hurt, but Tinkor looks healthier!\n");
               this_object()->add_hit_point(random(20)+10);
             }
         }
      }
   }
}
