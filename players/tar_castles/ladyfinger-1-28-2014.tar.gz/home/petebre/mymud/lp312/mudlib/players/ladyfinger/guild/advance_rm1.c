inherit "room/room";

reset(arg) {
  if(arg) return;

set_light(1);
short_desc="Generic Advance Room";
long_desc="Even more generic of a description";
}
void init() {
  ::init();
  add_action("exchange","exchange");
}
int exchange(int Arg) {
int arg;
int xp;
xp=(int)this_player()->query_exp();
sscanf(Arg, "%d",arg);
if(!arg) {
 notify_fail("Use exchange <ammount>\n");
 return 0;
}
if(arg>xp) {
 notify_fail("You aint got enough, I will flesh this out more later\n");
 return 0;
}
this_player()->add_exp(-arg);
this_player()->add_guild_exp(arg);
write("You exchange "+arg+" to guild experience.\n");
write("You now have "+guild_exp+".\n");
}
