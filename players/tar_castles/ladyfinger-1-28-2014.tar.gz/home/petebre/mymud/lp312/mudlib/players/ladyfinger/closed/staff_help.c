  Help		Printout this text. (DUH!)

  Home          silently go home
  where		Location of USERS all users on game
  whom		Nirvana USERS list ALL USERS
  Tell		Tell ANYONE (even if invis) a message Someone:
  scurse	shout curse a person
  imprison	Send a player to prison
  get1		Move ANY object into your inventory
  damage	Kill a target INSTANTLY
  sheal		silent Heal of a target
  make		Force a player to perform a command
  bring		Find a player and bring them to you
  mail		Query POST for mail
  read		Read mail from post office
  count		?
  Get		Get <obj1> from <obj2>
  reset		reset an object(room etc)
  Goto		Move to environment(living)
  List		List of currently remembered objects etc.
  light		Set current location's light level
  rem		Remember an object (desc/path etc.) for later reference
  here		List inventory of environment of object
  trace		Find an object desc and current location
  Goin		Move directly into object
  Look		Look into an object (See ALL including invis by path.)
  Move		Move <obj 1> into <obj 2>
  Clone		Clone an object, specify path
  Trans		Move object to environment(load)
  Destruct 	Destruct and object by any means necces.
  patch		fix <obj> <func> <argument>
  clean		remove all contents of an object(if no soul)
  I		Inventory of present location or object
  aecho		Echo(shout) to all players on game
  echo		Echo(say) to all objects in a room
  contell	Tell someone something (they just type: re to reply)
  re 		Reply to a Contell
  ere		Tell a player something no editor querys etc.
  pecho		echo to <plyr> a <message>
