inherit "obj/monster";
int i,x;
object attacker;
string attacker_name;
reset(arg){
   object axe,gold;
   ::reset();
   if(arg){return;}
   set_short("Snakeman");
   set_long("This snakeman is covered from head to toe in scaley flesh\nHe wields an axe deftly.\n");
   set_level(16);
   set_ac(12);
   set_wc(17);
   set_hp(400);
   set_name("snakeman");
   set_race("snake");
   set_al(-800);
   set_race("snake");
   set_aggressive(1);
   set_chat_chance (14);
   load_chat("The snakeman sneers, 'We will dessssssstroy thissssss town!'\n");
   load_chat("The snakeman roars, 'You mussssssst pay!\n");
   load_chat("The snakeman slays another citizen of Asobar, sending blood everywhere.\n");
   load_chat("The snakeman raises his axe to strike!\n");
   load_chat("The snakeman hisses with a forked tounge.\n");
   axe=clone_object("/players/ladyfinger/weapon/axe");
   move_object(axe,this_object());
   gold=clone_object("obj/money");
   gold->set_money(700);
   move_object(gold,this_object());
   set_heart_beat(55);
   enable_commands();
}
id(str){return str=="snakeman" || str=="snake";}
heart_beat() {
   ::heart_beat();
   attacker=this_object()->query_attack();
   if(!attacker){
      i=random(10);
      if(i==2){
         command("east",this_object());}
      if(i==3){
         command("west",this_object());}
      if(i==4){
         command("north",this_object());}
      if(i==5){
         command("south",this_object());}
   }
   else{
      attacker_name=attacker->query_real_name();
      if(!present(attacker_name,environment(this_object()))){
         i=random(10);
         if(i==2){
            command("east",this_object());}
         x++;
         if(x==50){
            x=0;
            if(i==3){
               command("west",this_object());}
            if(i==4){
               command("north",this_object());}
            if(i==5){
               command("south",this_object());}
         }
      }
   }
}
