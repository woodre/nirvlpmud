inherit "obj/monster";
object attacker;
string attacker_name;

reset(arg){
   object gold,staff;
   ::reset(arg);
   if(arg) return;
   set_name("druid");
   set_race("human");
   set_alias("druid");
   set_short("A peaceful Druid");
   set_long("This druid is wearing earth hued robes.\n");
   set_level(30);
   set_hp(3500 + random(500));
   set_al(1000);
   set_wc(28);
   set_ac(24);
   gold=clone_object("obj/money");
   gold->set_money(2000);
   move_object(gold,this_object());
   staff=clone_object("players/ladyfinger/weapon/druid_staff.c");
   move_object(staff,this_object());
   set_heart_beat(1);
}
heart_beat(){
   ::heart_beat();
   attacker=this_object()->query_attack();
   if(!attacker){
      destruct(present("coins",this_object()));
      destruct(present("staff",this_object()));
      destruct(this_object());
   }
   attacker_name=attacker->query_real_name();
   if(!present(attacker_name,environment(this_object()))){
      destruct(present("coins",this_object()));
      destruct(present("staff",this_object()));
      destruct(this_object());
   }
}
