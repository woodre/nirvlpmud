inherit "room/room";
reset(arg) {
 if(arg) return;
 short_desc="Before the Glade";
  long_desc="You find yourself standing in a lush land. All about the sun\n"+
             "shines in marvelous power. To the north you see the outer rim\n"+
             "of a forest. It is rumored that within the forest there is a\n"+
               "hidden glade. The waters of the glade are said to hold many\n"+
               "many strange properties, as well as herbs of power.\n";
   set_light(1);
   dest_dir =
   ({
     "/players/ladyfinger/room/glade/glade_rm2","north",
   });
  }
