inherit "obj/weapon.c";

reset(arg) {
  ::reset(arg);
  if(arg) return;

set_name("staff");
set_alias("staff");
set_short("Druidic Staff");
set_long("This staff is made from flawless birch. It seems to radiate\n"+
         "an aura of power.\n");
set_class(21);
set_weight(3);
set_value(100);
set_hit_func(this_object());
}
weapon_hit(attacker) {
int A;
A=random(2);
if(A>1) {
 say("The Druidic staff releases a energy discharge into its target!\n");
 write("Your Druidic staff releases a dischare of energy into its target.\n");
 return(350);
 }
 return;
}
