Hate to do this but until you are level 40 please use the 
/obj/wiz_tool.c
- Mythos <6-4-97>
