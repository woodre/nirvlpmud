inherit "obj/armor";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("boxer") ;
        set_short("Painted boxer") ;
        set_long("A pair of coloured boxer, with sun painted on them \n");
        set_weight(1) ;
        set_value(250);
        set_type("armor") ;
        set_ac(1) ;
}
