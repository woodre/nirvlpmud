inherit "obj/drink";
reset(arg){
    ::reset(arg);
    if (arg) return;
    set_value("tankard#A wine tankard#You drink a wine tankard#25#200#6");
}
