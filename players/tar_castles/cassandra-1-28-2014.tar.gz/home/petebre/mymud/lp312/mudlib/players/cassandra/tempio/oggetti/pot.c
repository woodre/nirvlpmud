inherit "obj/treasure";

	int soldi;
reset(arg) {
        object gold;
	soldi=1350;
	if(arg) return;
        set_id("pot");
        set_short("gold pot");
        set_long("This is the famous pot you can find at the end of any rainbow. It's \n"+
                 "full of gold coins.. very heavy gold coins \n");
         set_weight(4);
         set_value(20);}

init(){
	::init();
	add_action("get","get");
      }
get(str){
	  if (str=="gold from pot" || str=="all from pot"){
                if (soldi==1350) {
			call_other(this_player(),"add_money",1350);
			write("You got all gold coins from pot\n");
			soldi=0;
			return(1);
			}
		else {
			write("Pot is empty.\n");
			return(1);
			}
	}
}
