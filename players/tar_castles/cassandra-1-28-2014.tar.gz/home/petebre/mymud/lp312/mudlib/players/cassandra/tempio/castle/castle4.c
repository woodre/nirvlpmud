inherit "room/room"; 
reset(arg) {
  object obj,ob1;
  int i;
  short_desc="Cassiophea's Castle";
  long_desc ="You're walking on a avenue across beautiful garden full of perfumed\n "+
             "flowers and exotical plantes. Surely who live here have to love beauty more \n"+
             "than any other thing.\n"; 
  dest_dir = ({"/players/cassandra/tempio/castle/castle3.c","south",
       "/players/cassandra/tempio/castle/castle2.c","east"});
  for (i=0;i<5;i++){
  obj=clone_object("/players/cassandra/tempio/monsters/flower.c");
  move_object(obj,this_object());}
  ob1=clone_object("/players/cassandra/tempio/monsters/gardener.c");
  move_object(ob1,this_object());
  set_light(1);
}
