inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="A dark path";
  long_desc="This is a dark path obtained moving big stones with a enormous strenght.\n"+
	    " But.. what a strange.. everything here seems made of stone.\n";
  dest_dir = ({ "players/cassandra/olimpo/hell/path2.c","north",
       "players/cassandra/olimpo/hell/shore.c","west"});
   set_light(1);
}


