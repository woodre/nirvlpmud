id(str) { return str == "turkey"; }

reset() {}

long() { write("A enormous stuffed turkey just taken away from oven. Eat it to heal.\n"); }

short() { return "A stuffed turkey"; }

init() {
    add_action("heal"); add_verb("eat");
}

heal(arg) {
        if (arg != "turkey"){
                notify_fail("What do you want to eat?\n");
                return 0;
                }
    say(call_other(this_player(),"query_name") + " eats a enormous stuffed turkey.\n");
    write("You eat stuffed turkey. You feel better now\n");
    call_other(this_player(),"heal_self",26);
    destruct(this_object());
    return 1;
}
get() { return 1; }

drop() { return 0; }
query_weight() { return 0; }

query_value() { return 450; }
