inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("trident");
        set_short("Neptune trident") ;
        set_long("A powerful weapon made by platinum; its points tips can pierce any \n"+
                 "type of material, even if it's rather light to carry \n");
        set_weight(1) ;
        set_value(2500);
        set_class(19) ;
        set_hit_func(this_object());
}

