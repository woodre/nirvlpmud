inherit "room/room"; 
reset(arg) {
  object obj;
  set_light(1);
  short_desc="On the rainbow";
  long_desc="TONF... You go down from rainbow and you fall in the middle of a wet \n"+ 
            "green grass. As in the most famous legend at the end of rainbow you \n"+
            "could see...\n";
  dest_dir = ({ 
       "players/cassandra/tempio/rainbow5", "up",
       "players/cassandra/tempio/nroom7.c","southeast",
       "players/cassandra/tempio/gn_home1.c","west",
       "players/cassandra/tempio/gn_home4.c","north",
       "players/cassandra/tempio/gn_home5.c","east"});
  obj=clone_object("players/cassandra/tempio/monsters/gnome.c");      
  move_object(obj,this_object());
  set_light(1);
}
