inherit "obj/armor";
reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("collar");
        set_short("Iron collar");
        set_long("A leather collar with some iron points on it. It's pretty new.\n");
        set_weight(2);
        set_value(850);
        set_type("armor");
        set_ac(4) ;
}
