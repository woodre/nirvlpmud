inherit "room/room"; 
reset(arg) {
  short_desc="Path to Mountain";
  long_desc ="All around you the grass is frozen and the only vegetation which \n"+
             "could live here is made up by pines. Two different pathes start from here \n";  
 dest_dir = ({ 
       "players/cassandra/tempio/mountain3.c", "west",
       "players/cassandra/tempio/olimpo/olimpo1.c","east",
       "players/cassandra/tempio/mountain1.c","down"});
  set_light(1);}

 
