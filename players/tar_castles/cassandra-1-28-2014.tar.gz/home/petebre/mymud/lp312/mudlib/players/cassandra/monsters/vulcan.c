inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Vulcan, the god of fire");
    set_long("You see a tall and fat man.. or better, he isn't fatty but he's full of \n"+
	     "enormous muscles \n");
    set_name("vulcan");
    set_gender("male");
    set_level(18);
    set_hp(450);
    set_al(-200);
    set_wc(22);
    set_ac(22);
    set_race("human");
    set_chat_chance(25);
    ob1=clone_object("/players/cassandra/object/hammer.c");
    move_object(ob1,this_object());
    gold=clone_object("obj/money");
    gold->set_money(200);
    move_object(gold,this_object());
    command("wield hammer",this_object());
}
