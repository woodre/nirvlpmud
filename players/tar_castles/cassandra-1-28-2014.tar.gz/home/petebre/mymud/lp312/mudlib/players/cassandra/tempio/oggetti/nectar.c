id(str) {return str=="nectar";}
reset(){}
long(){write("Some flower nectar, very good and nourishing\n");}
short(){return"Flower nectar";}
init(){
     add_action("heal","eat");
}
heal(arg){
	if (arg!="nectar"){
 	   notify_fail("What do you want to eat?\n");
           return 0;
	}
    say(call_other(this_player(),"query_name")+" eats some nectar\n");
    write("You eat some nectar.. yuhm very good!\n");
    call_other(this_player(),"heal_self",20);
    destruct(this_object());
    return 1;
}
get(){return 1;}
drop(){return 0;}
query_weight(){return 0;}
query_value(){return 200;}
