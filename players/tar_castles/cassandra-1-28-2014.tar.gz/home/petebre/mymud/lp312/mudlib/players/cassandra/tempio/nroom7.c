inherit "room/room"; 
reset(arg) {
  short_desc="A sunny land";
  long_desc ="You escape to open air. It stopped raining only 5 minutes \n"+
             "ago, so now you can see a wonderful rainbow [climb rainbow].\n"+
             "There're some mountains far to north and a sadly know river to east. \n"; 
  dest_dir = ({ 
       "players/cassandra/tempio/entrance.c", "south",
       "players/cassandra/tempio/mountain1.c","north",
       "players/cassandra/tempio/stigs1.c","east",
       "players/cassandra/tempio/castle/castle1.c","west"});
  set_light(1);}

  init(){
    ::init();
    add_action("climb","climb");
  }
 
  climb(str){
    if (str!="rainbow")
        return 0;
    write(this_player()->query_name()+" starts climbing rainbow \n");
    move_object(this_player(),"players/cassandra/tempio/rainbow1"); 
    return 1;
  }



