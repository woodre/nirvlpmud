inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="O.H. Kitchen";
  long_desc="The corridor slowly restrict until becoming a narrow tunnel in the ground \n"+
	    "You can here sound of water coming from tunnel. It's very dark there \n";
  dest_dir = ({ 
       "players/cassandra/olimpo/odown1.c","west",
       "players/cassandra/olimpo/otunnel1.c","tunnel"});
  set_light(1);
 }

