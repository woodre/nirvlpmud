inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3,k;
  int i; 
  short_desc="Neptune treasury";
  long_desc="You enter in a small cave under the sea. \n"+
            "When a sea shipwrecked, its treasury is taken here so that Neptune could \n"+
            "admire it when he wants. Of course it's well protected. \n";
  dest_dir = ({ 
     "players/cassandra/olimpo/swn.c","north"});
  set_light(1);
  ob1=clone_object("players/cassandra/monsters/squid.c");
  move_object(ob1,this_object());
  ob2=clone_object("players/cassandra/object/treasury.c");
  move_object(ob2,this_object());
 
 }

init(){
	::init();
	add_action("my_get","get");
       }

my_get(str){ if (str=="treasury") {
	            if (present("squid")) {
	                 write("You've to kill its guardian first. \n");
                         return 1;
                    }}
             else {	
		    write("Get what? \n");
                    return 1;
                   }
}
