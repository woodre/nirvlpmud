inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Mercury, the Gods' messenger");
    set_long("A handsome and sports boy which is used to run very fast. \n");
    set_name("mercury");
    set_level(17);
    set_hp(425);
    set_al(-100);
    set_wc(20);
    set_ac(20);
    ob1=clone_object("players/cassandra/object/shoes.c");
    move_object(ob1,this_object());
    command("wear shoes",this_object());
   }
