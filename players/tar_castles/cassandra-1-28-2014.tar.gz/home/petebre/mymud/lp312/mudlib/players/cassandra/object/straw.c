inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("straw");
        set_short("A heap of straw");
        set_long("A heap of fresch and soft straw, a confortable bed for a horse\n");
        set_weight(1);
        set_value(100);
}

