inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3;
  short_desc="House of Gnomes";
  long_desc="This is a cubby-hole, full of thousand of unknow and small items.\n"+
            "You can hear a strong smell of animal urine\n";
  dest_dir = ({ "players/cassandra/tempio/gn_home2.c", "east"});
  ob1=clone_object("players/cassandra/tempio/monsters/dog.c");      
  move_object(ob1,this_object());
  ob2=clone_object("players/cassandra/tempio/monsters/cat.c");      
  move_object(ob2,this_object()); 
  set_light(1);
	
 }


