inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="Olimpo Hotel";
  long_desc="Following the idea of a fresh bath you cross the big main room. \n"+
             "All around you can see demi-gods talking about their business sitting on \n"+
	     "soft divans .. hmm .. perhaps divans haven't been still invented, but  \n"+
	     "we're talking about gods affairs, so everything is possible! \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/olimpo2.c","south",
       "players/cassandra/olimpo/sw_pool1.c","east"});
  set_light(1);
  for (i=0;i<6;i++){
  ob1=clone_object("players/cassandra/monsters/demi-god.c");
 move_object(ob1,this_object());}
 }

