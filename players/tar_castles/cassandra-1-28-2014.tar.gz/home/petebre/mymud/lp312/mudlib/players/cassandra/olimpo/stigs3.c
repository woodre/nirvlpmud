inherit "room/room"; 
reset(arg) {
  object ob1;
  int i;
  short_desc="On the rive of the Stigs";
  long_desc="You are floating in a strange area.. cloud and fog all around you, wet air \n"+
	    "and bad smell comes from a dark river flowing near path.\n"+
	    "To east you can see a old and unsteady landing stage\n";
  dest_dir = ({ "players/cassandra/olimpo/stigs2.c","south",
		"players/cassandra/olimpo/river.c","east"});
  set_light(1);
}
