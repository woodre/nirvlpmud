inherit "room/room"; 
reset(arg) {
  object obj;
  int i;
  short_desc="A dark path";
  long_desc="This is a dark path obtained moving big stones with a enormous strenght.\n"+
            " But.. what a strange.. everything here seems made of stone, there're too..\n";
  dest_dir = ({ "players/cassandra/olimpo/hell/path4.c","north",
       "players/cassandra/olimpo/hell/path2.c","east"});
  for (i=0; i<4+random(4); i++){
      obj=clone_object("/players/cassandra/monsters/soldiers.c");
      move_object(obj,this_object());
  }
   set_light(1);
}

