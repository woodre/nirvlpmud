#define NAME "Cassandra"
#define DEST "room/forest6"

id(str) { return str == "temple"; }

short() {

    return "Temple of " + NAME;
}

long() {
    write("This is the " + short() + ".\n");
    write("You think and see hundreds and hundreds of coloumns with \n");
    write("elaborated capital on them. If you enter here you'll be taken \n");
    write("back to a century of heroes, gods and mythology monsters.\n");
}

init() {
    add_action("enter"); add_verb("enter");
}

enter(str) {
    if (!id(str))
        return 0;
   write("It isn't open yet. Wait a little please");
 
return 1;
}

reset(arg) {
    if (arg)
        return;
    move_object(this_object(), DEST);
}
is_castle(){return 1;}
