inherit "room/room"; 
reset(arg) {
  object obj;
  int i;
  short_desc="Near Meduse's palace";
  long_desc="You're standing in a plain full of ruins. Once upon a time this area was\n"+
            "a beautiful palace with a lovely garden in fron of it. You don't know what\n"+
            "happened here, but is must had been something terrible. An ancient portal\n"+   
            "with a sign on it lets you enter.\n";
  dest_dir = ({"players/cassandra/olimpo/hell/path4.c","south"});
  set_light(1);
}

init(){
    ::init ();
    add_action("enter", "enter");
    add_action("read","read");
    add_action("pass","look");
}


pass(str) {
        if(str=="at sign")  {
                command("read sign",this_player());
                return 1;
                }
        }

read(str) {
     if(str !="sign")
         return 0;
    write("This is Meduse's palace, a very dangerous place. Beware!!\n");
    return 1;
}

enter(str){
     if(str!="portal")
         return 0;
     write(this_player()->query_name() + " enters Meduse's palace.\n"); 
     move_object(this_player(), "/players/cassandra/olimpo/hell/labirynth1.c");
     return 1;
}  
