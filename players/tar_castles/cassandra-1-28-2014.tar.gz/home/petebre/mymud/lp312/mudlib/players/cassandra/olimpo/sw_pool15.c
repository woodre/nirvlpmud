inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3,k;
  int i; 
  short_desc="In Swimming Pool";
  long_desc="The warm is obviously at a perfect temperature to have a bath.  \n"+
            "All around you hear a irresistible but dangerous lyric, because \n"+
            "it's song by ... \n";
  dest_dir = ({ 
     "players/cassandra/olimpo/sw_pool11.c","north",
       "players/cassandra/olimpo/sw_pool13.c","west",
       "players/cassandra/olimpo/swn.c","south"});
  set_light(1);
  for (k=0;k<2+random(3);k++){
  ob1=clone_object("players/cassandra/monsters/mermaid.c");
     move_object(ob1,this_object());}
 
 }

