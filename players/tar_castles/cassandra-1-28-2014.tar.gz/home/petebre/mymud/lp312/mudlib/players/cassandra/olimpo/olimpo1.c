inherit "room/room"; 
reset(arg) {
  object ob1;
  int k; 
  short_desc="Olimpo Hotel";
  long_desc="You're standing in front of a elegant Hotel, the Olimpo Hotel. \n"+
            "Perhaps you didn't imagine Olimpo is this way, but which could be a \n"+
            "better residence for Gods than a Grand Hotel? \n"+
            "The entrance is to east \n";
             dest_dir = ({ 
       "players/cassandra/tempio/mountain2", "west",
       "players/cassandra/olimpo/olimpo2.c","east"});
  for (k=0; k<2; k++){
  ob1=clone_object("players/cassandra/monsters/doorkeper.c");

     move_object(ob1,this_object());}
  set_light(1);
}



