inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A half freezed elf");
    set_long("A half freezed and fear elf. He passed here last 3 months \n");  
    set_name("elf");
    set_gender("male");
    set_level(8);
    set_hp(100);
    set_al(50);
    set_wc(11);
    set_ac(7);
    gold=clone_object("obj/money"); 
    gold->set_money(300);
    move_object(gold,this_object()); 
}

