id(str) { return str == "spaghetti"; }

reset() {}

long() { write("A mountain of spaghetti with red tomatoes. Eat it to heal.\n");}

short() { return "a dish of spaghetti"; }

init() {
    add_action("heal"); add_verb("eat");
}

heal(arg) {
        if (arg != "spaghetti"){
                notify_fail("What do you want to eat?\n");
                return 0;
                }
    say(call_other(this_player(),"query_name") + " eats spaghetti and dirty himself with sauce.\n");
    write("You eat the spaghetti. You feel better now\n");
    call_other(this_player(),"heal_self",20);
    destruct(this_object());
    return 1;
}
get() { return 1; }

drop() { return 0; }
query_weight() { return 0; }

query_value() { return 350; }
