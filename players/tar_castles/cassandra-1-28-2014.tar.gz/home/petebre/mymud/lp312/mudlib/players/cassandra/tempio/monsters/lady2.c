inherit "obj/monster";
object ob1,obj,ob2,gold;
reset(arg){
    ::reset(arg);
    if (arg) return;
    set_short("Scarlet lady");
    set_long("A old lady dressed in scarlet. She will not help you if you don't give \n"+
	     "her everything she wants\n");
    set_name("scarlet lady");
    set_alias("l1");
    set_level(18);
    set_hp(500);
    set_al(-300);
    set_wc(21);
    set_ac(30);
    set_aggressive(1);
    set_chat_chance(10);
    load_chat("Scarlet lady says: 'I would like anything to improve my soul'\n");
    set_chance(10);
    set_spell_dam(10);
    set_spell_mess1("Young meat, tender meat!!!\n");
    gold=clone_object("obj/money"); 
    gold->set_money(1000);
    move_object(gold,this_object());
    
}

init(){
	::init();
	add_action("give","give");
	}
give(str){
if ((str=="blood to purple lady") && (present("blood",this_player()))) {
	  write("Scarlet lady drinks blood and says: 'Child blood is what i needed to clear my soul'\n");
          ob2=present("blood",this_player());
          move_object(ob2,this_object());
          ob1=clone_object("/players/cassandra/tempio/oggetti/o2.c");
	  move_object(ob2,environment(this_object()));
          if ((present("oggetto1",environment(this_object()))) && (present("oggetto2",environment(this_object()))) && (present("oggetto3",environment(this_object())))) {
            obj=clone_object("players/cassandra/tempio/oggetti/mshield.c");
		    move_object(obj,this_player());
            write("You receive a glass shield from old women \n");
            write("Women tell you: 'if you're looking for the glory you've to follow the sun path\n'");}
	return 1;}
}
