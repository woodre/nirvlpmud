inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3;
  set_light(1);
  short_desc="Women room";
  long_desc="You enter in a dark and stinking room, which is going to rack and ruin.\n"+
            "This is the residence of three old women, better know as Scorpion Ladies\n";
  dest_dir = ({ 
       "players/cassandra/closed/maze/maze11.c","east",
       "players/cassandra/closed/maze/maze11.c","north",
       "players/cassandra/closed/maze/maze11.c","south"});
  ob1=clone_object("players/cassandra/tempio/monsters/lady1.c");      
  move_object(ob1,this_object());
  ob2=clone_object("players/cassandra/tempio/monsters/lady2.c");      
  move_object(ob2,this_object());
  ob3=clone_object("players/cassandra/tempio/monsters/lady3.c");      
  move_object(ob3,this_object());
  set_light(1);
}

init(){
	::init();
	add_action("my_east","east");       
}

my_east(){ write("You escape to the open air. \n");
	move_object(this_player(), "players/cassandra/tempio/nroom7.c");  
        write("You escape to open air. It stopped raining only 5 minutes \n");
        write("ago, so now you can see a wonderful rainbow [climb rainbow].\n");
        write("There're some mountains far to north and a sadly know river to east. \n");  
	write("There are four obvious exits: south, north, east and west \n");
	return 1;
      }	

