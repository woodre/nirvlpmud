inherit "room/room"; 
reset(arg) {
  object ob1,ob2,k;
  int i; 
  short_desc="Small Box";
  long_desc="Without doubts this is a horse box, lived by .. \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool18.c","hall"});	 
  set_light(1);
  ob1=clone_object("/players/cassandra/monsters/sun-horse.c");
  move_object(ob1,this_object());  
}

