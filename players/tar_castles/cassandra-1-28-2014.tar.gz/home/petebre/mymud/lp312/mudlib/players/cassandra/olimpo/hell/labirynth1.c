inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="Medusa's Palace";
  long_desc ="You are walking between lights and shadows.. None can know who or what \n"+
             "is hidding by darkness, the only thing you're sure is that you wouldn't \n"+
             "stay in this place for a long time. You can go further or [leave] from here.\n";
 dest_dir = ({"players/cassandra/olimpo/hell/labirynth4.c", "north",
    "players/cassandra/olimpo/hell/labirynth3.c", "west",
    "players/cassandra/olimpo/hell/labirynth2.c", "east",
    "players/cassandra/olimpo/hell/labirynth5.c","south"});
 if (!find_living("medusa")) {
          obj=clone_object("players/cassandra/monsters/meduse.c");
    	  move_object(obj,this_object());
          return 1;}
 set_light(1);
}
init(){
        ::init();
	add_action("leave","leave");
      }

leave(str){
       write(this_player()->query_name() + " leaves Medusa's palace.\n"); 
       move_object(this_player(), "/players/cassandra/olimpo/hell/portal.c");    
       return 1;
}

