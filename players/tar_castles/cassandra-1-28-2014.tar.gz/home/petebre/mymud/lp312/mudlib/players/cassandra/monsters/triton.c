inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A strong triton");
    set_long("This creature is half human and half fish, and it's a very good \n"+
              "warrior, expecially in water \n");
    set_name("triton");
    set_level(18);
    set_hp(450);
    set_al(-200);
    set_wc(30);
    set_ac(18);
    ob1=clone_object("players/cassandra/object/trident.c");
    move_object(ob1,this_object());
    command("wield trident",this_object());
}
