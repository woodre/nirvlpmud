inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("whip");
        set_short("7 tails whip") ;
        set_long("A powerful weapon made by hide worked very carefully.\n"+
                 "It may be very dangerous.\n");
        set_weight(2) ;
        set_value(875);
        set_class(18) ;
        set_hit_func(this_object());
}

weapon_hit(attacker)
{
 if (random (10) > 3) return 0;
 write("Whip cut your opponent skin like hot knife with butter.\n");
 say (this_player()->query_name()+" cut his opponent into slice.\n");
 return 20+random(25);
}

