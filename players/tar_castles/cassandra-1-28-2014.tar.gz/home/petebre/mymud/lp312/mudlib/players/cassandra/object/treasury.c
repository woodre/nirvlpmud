inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("treasury");
        set_short("Neptune treasury");
        set_weight(2);
        set_value(950);
        set_long("A trunk full of jewel and gold money \n");

}
