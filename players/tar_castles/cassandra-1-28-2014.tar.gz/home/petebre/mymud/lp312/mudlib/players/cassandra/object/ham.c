id(str) { return str == "ham"; }

reset() {}

long() { write("A very good sliced ham. Eat it to heal.\n"); }

short() { return "Sliced ham"; }

init() {
    add_action("heal"); add_verb("eat");
}

heal(arg) {
        if (arg != "ham"){
                notify_fail("What do you want to eat?\n");
                return 0;
                }
    say(call_other(this_player(),"query_name") + " eats sliced ham.\n");
    write("You eat the sliced ham. You feel better now\n");
    call_other(this_player(),"heal_self",15);
    destruct(this_object());
    return 1;
}
get() { return 1; }

drop() { return 0; }
query_weight() { return 0; }

query_value() { return 250; }
