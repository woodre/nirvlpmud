inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("bone");
        set_short("A dog bone");
        set_long("An old bone wet by dog's saliva.. what a disgust!!!\n");
        set_weight(1);
        set_value(10);
}

