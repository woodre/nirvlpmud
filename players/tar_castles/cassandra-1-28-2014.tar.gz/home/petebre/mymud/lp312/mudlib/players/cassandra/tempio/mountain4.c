inherit "room/room"; 
reset(arg) {
  short_desc="Path to Mountain";
  long_desc ="The temperature is always more cold, there is neither vegetable life \n"+
             "nor animal one. You couldn't image who could live here. \n"+
             "A dark cavern to south. Beware, caverns are always dark and dangerous \n";
 dest_dir = ({ 
       "players/cassandra/tempio/cavern.c","south",
       "players/cassandra/tempio/mountain3.c", "down",
       "players/cassandra/tempio/mountain5.c","up"});
  set_light(1);}

 
