inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A hungry mouse");
    set_long("Used to live in a quiet and empty world, this mouse is very angry because you\n"+
	     "disturb its calm and feed up with eating the same things \n");
    set_name("mouse");
    set_level(4);
    set_hp(60);
    set_al(-100);
    set_wc(8);
    set_ac(4);
    set_aggressive(1);
   }
