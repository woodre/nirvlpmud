inherit "room/room"; 
reset(arg) {
  short_desc="Maze of Fate";
  long_desc ="You're in a difficult maze, but at least here the temperature isn't \n"+
             "cold as outside and there isn't snow to make tiring walking. \n"+
             "There're 4 doors leading somewhere, and some letters on them\n" +
             "                               C                              \n"+
             "                            A     B                           \n"+
             "                               D                              \n";
              dest_dir = ({ 
       "players/cassandra/closed/maze/maze2", "west",
       "players/cassandra/closed/maze/maze3","east",
       "players/cassandra/closed/maze/mazeC","north",
       "players/cassandra/closed/maze/maze4","south"});
  set_light(1);}

