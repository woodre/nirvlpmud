inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="At the hell";
  long_desc="You enter in a gloomy cavern. Stairs leading down, in earth profundity \n"+
	    "Will you be so crazy to down to hell? \n"+
	    "A sign\n";
  dest_dir = ({"players/cassandra/olimpo/hell/shore.c", "south",
       "players/cassandra/olimpo/hell/hell2.c","down"});
   set_light(1);
}


init(){
	::init();
	add_action("read","read");
	}

read(str){
	if (str=="sign") {
	      write("Give up all hope, you which enter here \n");
              return 1;
	}
 }
