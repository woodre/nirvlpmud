inherit "room/room";
object player;
reset(arg) {
  short_desc="Path to Mountain";
  long_desc ="The temperature is always more cold, there is neither vegetable life \n"+
             "nor animal one. You couldn't image who could live here. \n"+
             "and probably you'll not survive any longer.\n"+
             "Run away until you can! \n";
   dest_dir = ({ 
       "players/cassandra/tempio/mountain6.c", "up",
       "players/cassandra/tempio/mountain4.c","down"});
  set_light(1);}

freeze(){
	  write("A snow storm freezes your body..\n");
          call_other(player,"heal_self",-80);
          write("If you stay here any longer you'll become a piece of ice \n");
          call_out("freeze",15);
}

init(){
        ::init();
	player=this_player(); 
	call_out("freeze",15);
}

