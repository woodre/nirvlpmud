inherit "obj/armor";
reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("collar");
        set_short("A dog collar");
        set_long("A leather collar with some iron points on it. It's pretty new.\n");
        set_weight(1);
        set_value(500);
        set_type("armor");
        set_ac(1) ;
}
