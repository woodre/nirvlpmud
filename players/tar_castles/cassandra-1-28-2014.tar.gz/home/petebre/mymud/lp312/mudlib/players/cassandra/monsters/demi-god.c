inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Demi-God");
    set_long("Characters like this were born from a extra-conjugal relation between \n"+
	     "a God and a human, so they've magical power only 12 hours a day.\n"+
	     "Perhaps you should be lucky to guess the right 12?\n");
    set_name("demi-god");
    set_gender("male");
    set_level(10+random(6));
    set_hp(140+random(400));
    set_al(250);
    set_wc(15+random(8));
    set_ac(7+random(4));
    set_chance(10);
    set_spell_dam(random(20)+20);
    set_spell_mess1("You're unlucky.. you chose the wrong 12 hours!");
    ob1=clone_object("players/cassandra/object/cigar.c");
    move_object(ob1,this_object());
    ob2=clone_object("players/cassandra/object/whiskey.c");
    move_object(ob2,this_object());
}
