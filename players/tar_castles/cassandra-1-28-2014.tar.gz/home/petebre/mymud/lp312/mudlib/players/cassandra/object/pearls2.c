inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("pearls");
        set_short("A bag full of pearls");
        set_weight(1);
        set_value(1800);
        set_long("You have never seen so pure; surely their value is rather high  \n");

}
