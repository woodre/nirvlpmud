inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="O.H. Kitchen";
  long_desc="You're in the middle of a passage leading to west or east. \n"+
	    "Metallic sounds coming from west\n";
  dest_dir = ({ 
       "players/cassandra/olimpo/odown3.c","west",
       "players/cassandra/olimpo/odown1.c","east"});
  set_light(1);
 }

