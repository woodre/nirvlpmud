inherit "obj/armor";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("boots") ;
        set_short("Stone boots") ;
        set_long("A pair of heavy stone boots \n");
        set_weight(3) ;
        set_value(250);
        set_type("boots") ;
        set_ac(1) ;
}
