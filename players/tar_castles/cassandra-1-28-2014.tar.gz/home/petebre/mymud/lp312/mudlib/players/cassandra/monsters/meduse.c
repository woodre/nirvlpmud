inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (!arg) {
      set_short("The famous Medusa");
      set_long("Once upon a time she was a beautiful girl, but now you can see a monster with\n"+
               "scorpion tail and head made of deadly snakes\n");        
      set_name("medusa");
      set_gender("female");
      set_level(21);
      set_hp(1500);
      set_al(-400);
      set_wc(30);
      set_ac(17);
      set_aggressive(1);
      ob1=clone_object("/players/cassandra/object/medusa-head.c");
      move_object(ob1,this_object());
      command("wield head",this_object());
      set_spell_mess1("Medusa stoned you with her hissed snakes\n");
      set_chance(20);
      set_spell_dam(15+random(5));
      call_out("random_move",5);
    }
}

status random_move(){
  int n;
  n = random(6);
  switch(n) {
   case 0 : command("north"); break;
   case 1 : command("east"); break;
   case 2 : command("west"); break;
   case 3 : command("south"); break;
   case 4 : command("up"); break;
   case 5 : command("down"); break;
  }
 call_out("random_move",5);
return 1;}

