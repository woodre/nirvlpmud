inherit "room/room"; 
reset(arg) {
  short_desc="Maze of Fate";
  long_desc ="You're in a difficult maze, but at least here the temperature isn't \n"+
             "cold as outside and there isn't snow to make tiring walking. \n"+
             "There're 4 doors leading somewhere, and some letters on them\n" +
             "                               I                              \n"+
             "                            L     M                           \n"+
             "                               N                              \n";
  dest_dir = ({     "players/cassandra/closed/maze/maze1", "west",
       "players/cassandra/closed/maze/maze1","north",
       "players/cassandra/closed/maze/maze1","east",
       "players/cassandra/closed/maze/mazeN","south"});
       set_light(1);}

init(){
        ::init();
	add_action("direzione","west");
        add_action("direzione","north");
        add_action("direzione","east");
      }

direzione(){
  int n;
  n = random(6);
  write("You're in a difficult maze, but at least here the temperature isn't \n");
  write("cold as outside and there isn't snow to make tiring walking. \n");
  write("There're 4 doors leading somewhere, and some letters on them\n");   
  switch(n) {
   case 0:                     
      move_object(this_player(),"/players/cassandra/closed/maze/maze2.c");
      write("                              E                              \n");
      write("                           F     G                           \n");
      write("                              H                              \n");
    break;
   case 1:    
      move_object(this_player(),"/players/cassandra/closed/maze/maze3.c");
      write("                              C                              \n");
      write("                           A     B                           \n");
      write("                              D                              \n");
    break;
   case 2: 
      move_object(this_player(),"/players/cassandra/closed/maze/maze4.c");
       write("                              L                              \n");
      write("                           M     N                           \n");
      write("                              O                              \n");
break; 
   case 3: 
      move_object(this_player(),"/players/cassandra/closed/maze/maze5.c");
      write("                              T                              \n");
      write("                           U     V                           \n");
      write("                              Z                              \n");
break;
   case 4: 
      move_object(this_player(),"/players/cassandra/closed/maze/maze6.c");
      write("                              P                              \n");
      write("                           Q     R                           \n");
      write("                              S                              \n");
break;
   case 5:
move_object(this_player(),"/players/cassandra/closed/maze/maze1.c");break;
}
return 1;}


