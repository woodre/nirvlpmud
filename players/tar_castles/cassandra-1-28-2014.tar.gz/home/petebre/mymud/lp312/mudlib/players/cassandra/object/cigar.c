id(str) { return str == "cigar"; }

reset() {}

long() { write("This cigar tobacco is get from leaves which grow on Olimpo slope\n"); }

short() { return "A very strange cigar"; }

init() {
    add_action("smoke"); add_verb("smoke");
}

heal(arg) {
        if (arg != "cigar"){
                notify_fail("What do you want to eat?\n");
                return 0;
                }
    say(call_other(this_player(),"query_name") + " smokes cigar (Perhaps already chewed by someone other.. what a disgust!.\n");
    write("But at least you feel better!\n");
    call_other(this_player(),"heal_self",35);
    destruct(this_object());
    return 1;
}
get() { return 1; }

drop() { return 0; }
query_weight() { return 0; }

query_value() { return 400; }
