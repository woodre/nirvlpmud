inherit "room/room"; 
reset(arg) {
  short_desc="Path to Mountain";
  long_desc ="The temperature is always more cold, there is neither vegetable life \n"+
             "nor animal one. You couldn't image who could live here \n";
 dest_dir = ({ 
       "players/cassandra/tempio/mountain2.c", "east",
       "players/cassandra/tempio/mountain4.c","up"});
  set_light(1);}

 
