inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A beautiful stallion");
    set_long("This is one of four horses that lead the sun-cart. You've never seen \n"+
             "a so wonderful animan. \n");
    set_name("horse");
    set_alias("stallion");
    set_level(15);
    set_hp(250);
    set_al(100);
    set_wc(18);
    set_ac(18);
    gold=clone_object("obj/money"); 
    gold->set_money(1500);
    move_object(gold,this_object()); 
}
