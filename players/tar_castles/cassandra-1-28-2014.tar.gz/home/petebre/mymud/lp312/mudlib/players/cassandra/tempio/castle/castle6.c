inherit "room/room"; 
reset(arg) {
  object obj;
  int i;
  short_desc="Cassiophea's Castle";
  long_desc ="In this area there're hundreds of fruit tree .. apples, pears, oranges,\n"+
	     "peaches fill the branches \n";
  dest_dir = ({ 
       "players/cassandra/tempio/castle/castle7.c", "west",
       "players/cassandra/tempio/castle/castle2.c","south"});
  set_light(1);
}
