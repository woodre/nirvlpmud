inherit "room/room"; 
reset(arg) {
  object ob1,ob2,k;
  int i; 
  short_desc="Olimpo Hotel Swimming Pool";
  long_desc="You're on the right edge of swimming pool, which seems very populate. \n"+
            "Further to east you can see some beautiful women sunbathing and chatting\n"+
            "You can also go in water  [dive] \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool10.c","north",
       "players/cassandra/olimpo/sw_pool16.c","east",
       "players/cassandra/olimpo/sw_pool17.c","south",
       "players/cassandra/olimpo/sw_pool15.c","dive"});
  set_light(1);
  }

