inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("dolly");
        set_short("Barbie dolly");
        set_long("Don't tell me you ever hear about the most famous dolly in world!! You can play with it too.\n");
         set_weight(1);
         set_value(150);

}
init(){
	add_action("play","play");
      }

play(str){
	write("You start undressing Barbie to change her dress (at least i hope this \n");
	write("is the only scope!!) When you push her back she says 'Hello world'! \n");
	return(1);
}


