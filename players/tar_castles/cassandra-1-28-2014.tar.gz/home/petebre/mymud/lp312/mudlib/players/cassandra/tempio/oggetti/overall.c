inherit "obj/armor";
reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("overall");
        set_short("A gardener overall");
        set_long("A green overall with a big flower painted in red and yellow.\n");
        set_weight(1);
        set_value(50);
        set_type("armor");
        set_ac(1) ;
}
