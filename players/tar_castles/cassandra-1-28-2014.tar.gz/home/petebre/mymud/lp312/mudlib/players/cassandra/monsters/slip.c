inherit "obj/armor";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("trunks") ;
        set_short("Swimming trunks") ;
        set_long("Pink swimming trunks used by Venus.. and never washed :P \n");
        set_weight(1) ;
        set_value(340);
        set_type("armor") ;
        set_ac(1) ;
}
