inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A irresistible mermaid");
    set_long("A beautiful creature usually living in the abyss of the oceans \n"+
	      "which is here on holiday \n");
    set_name("mermaid");
    set_gender("female");
    set_level(15);
    set_hp(225);
    set_al(-150);
    set_wc(20);
    set_ac(12);
    set_chat_chance(10);
    load_chat("Mermaid looks at you and sings 'My brave hero, stay here with me \n");
    set_chance(10);
    ob1=clone_object("players/cassandra/object/pearls.c");
    move_object(ob1,this_object());
    command("wear pearls",this_object());
}
