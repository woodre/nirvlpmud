inherit "obj/monster";
object ob1,ob2,obj,gold;
reset(arg){
    ::reset(arg);
    if (arg) return;
    set_short("Purple Lady");
    set_long("A old lady dressed in purple. She will not help you if you don't give \n"+
	     "her everything she wants\n");
    set_name("purple lady");
    set_alias("l3");
    set_level(18);
    set_hp(500);
    set_al(-300);
    set_wc(21);
    set_ac(30);
    set_aggressive(1);
set_chat_chance(10);
    load_chat("Purple woman says: 'I would like anything to improve my look'\n");
    set_chance(10);
    set_spell_dam(10);
    set_spell_mess1("Young meat, tender meat!!!\n");
    gold=clone_object("obj/money"); 
    gold->set_money(1000);
    move_object(gold,this_object());
}
init(){
	::init();
	add_action("give","give");
	}
give(str){
	if ((str=="rubin to purple lady") && (present("rubino",this_player()))) {
	  write("Purple lady says: 'What a wonderful rubin. My look is perfect now.'\n");
          ob2=present("rubin",this_player());
          move_object(ob2,this_object());
          ob1=clone_object("/players/cassandra/tempio/oggetti/o3.c");
	  move_object(ob1,environment(this_object()));
          if ((present("oggetto1",environment(this_object()))) && (present("oggetto2",environment(this_object()))) && (present("oggetto3",environment(this_object())))) {
            obj=clone_object("players/cassandra/tempio/oggetti/mshield.c");
	    move_object(obj,this_player());
             write("You receive a glass shield from old women \n");
            write("Women tell you: 'if you're looking for the glory you've to follow the sun path\n'");}
	return 1;}
}


