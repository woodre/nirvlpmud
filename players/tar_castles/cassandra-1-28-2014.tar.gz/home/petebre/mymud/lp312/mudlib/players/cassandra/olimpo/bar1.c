inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="Olimpo Hotel";
  long_desc="You enter in the commercial area of Hotel: west of here you can find a bar \n"+
	    "and to east there's a shop. \n";
  dest_dir = ({ 
       "players/cassandra/olimpo/olimpo2.c", "north",
       "players/cassandra/olimpo/bar.c","west",
       "players/cassandra/olimpo/shop.c","east",
     });
  set_light(1);
  }
