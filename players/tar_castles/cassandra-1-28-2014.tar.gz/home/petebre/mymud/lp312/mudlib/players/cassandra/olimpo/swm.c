inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="A little hide-out";
  long_desc="In hedge a little hide-out has been built to spying what guests are \n"+
            "doing and selling information to scandaloused newspaper \n"+
            "South there's hedge with hole you used to come here. \n"; 
  dest_dir = ({ 
      "players/cassandra/olimpo/sw_pool4.c","hole"});
  set_light(1);
  ob1=clone_object("/players/cassandra/monsters/mercury.c");
  move_object(ob1,this_object());
 }

