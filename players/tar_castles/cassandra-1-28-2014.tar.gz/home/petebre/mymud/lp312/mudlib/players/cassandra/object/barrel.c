inherit "obj/treasure";
int i,ciucco;
reset(arg){
    if (arg) return;
    i=10;
    set_id("barrel");
    set_short("A wine barrel");
    set_long("A barrel more or less full of red wine.Type [drink barrel] to drink\n");
    set_weight(2);
    set_value(850);

}
init(){
	::init();
	add_action("drink","drink");
	}

drink(str){
if (str!="barrel") return 0;
            if (str=="barrel"){
                 if (!call_other(this_player(),"drink_alcohol",8)) {
                     write("You're dead drunk.. it's better you wait a little \n");
	             return 1;}
                 else {
                     if (i>0) {
		         write("You take away cork from barrel and continue drinking until you've\n");
	                 write("to stop to breathe. \n");
                         call_other(this_player(),"heal_self",20);
                         i=i-1;
                         return 1;}
	             else  {
	                 write("The barrel is empty \n");
                         return 1;
	             }
                  }
             }
}
