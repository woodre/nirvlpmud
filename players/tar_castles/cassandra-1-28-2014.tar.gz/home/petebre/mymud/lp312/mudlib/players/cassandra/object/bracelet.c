inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("bracelet");
        set_short("Gold and diamonds bracelet");
        set_long("A gold and diamonds bracelet finely finished; someone which used chainging-room lose it \n");
         set_weight(1);
         set_value(450);

}
init(){
	add_action("wear","wear");
      }

wear(str){
             if (str=="bracelet") {write ("It isn't yours! \n"); return 1;}
}


