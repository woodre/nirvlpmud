inherit "room/room"; 
reset(arg) {
  set_light(1);
  short_desc="On the rainbow";
  long_desc="How strange is to walk here. All around you there're only clouds "+
            "and under you can see the world between the rainbow colours. \n"+
            "You seem you remember something like a legend about rainbow. \n"+
            "There's a very very strong light from west. \n";
  dest_dir = ({ 
       "players/cassandra/tempio/rainbow2", "down",
       "players/cassandra/tempio/rainbow4","north",
       "players/cassandra/tempio/sun","west"});
      
}
