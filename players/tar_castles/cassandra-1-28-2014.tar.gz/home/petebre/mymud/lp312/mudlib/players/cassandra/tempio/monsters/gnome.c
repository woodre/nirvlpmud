inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("The rainbow gnome");
    set_long("A small fellow wearing a multicolor t-shirt. He seems very tired,\n"+ 
             "perhaps because he's carrying something very heavy.\n");
    set_name("gnome");
    set_gender("male");
    set_level(14);
    set_hp(200);
    set_al(-80);
    set_wc(15);
    set_ac(12);
    ob1=clone_object("/players/cassandra/tempio/oggetti/pot.c");
    move_object(ob1,this_object());
}
