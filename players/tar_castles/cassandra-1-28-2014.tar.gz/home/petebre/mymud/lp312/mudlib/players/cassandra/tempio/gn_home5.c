inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3;
  int i;
  short_desc="Garden of Gnomes";
  long_desc="You arrive in gnomes' garden. There's a fine little \n"+
	    "lake and some baby-gnomes playing around it.\n";
  dest_dir = ({ "players/cassandra/tempio/gn_home6.c", "north",
		"players/cassandra/tempio/rainbow6.c","west"});
  ob2=clone_object("players/cassandra/tempio/oggetti/blood.c");
  ob1=clone_object("players/cassandra/tempio/monsters/babygn.c");      
  move_object(ob1,this_object());
  move_object(ob2,ob1);
  for (i=0; i<4+random(4); i++){
      ob1=clone_object("players/cassandra/tempio/monsters/babygn.c");      
      move_object(ob1,this_object());}
  set_light(1);
	
 }


