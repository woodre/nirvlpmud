inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("gun");
        set_short("A stone-gun") ;
        set_long("This is a complex gun used to shoot stones to a long distance \n"+
                 "or with a great strenght\n");
        set_weight(1) ;
        set_value(500);
        set_class(12) ;
}
