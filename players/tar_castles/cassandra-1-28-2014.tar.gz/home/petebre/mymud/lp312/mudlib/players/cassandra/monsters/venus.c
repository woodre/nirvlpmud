inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Venus, the beauty goddess");
    set_long("Long blond hairs, blue eyes and a perfect body: you have never seen \n"+
             "a so charming lady. She's only wearing very small swimming trunks \n"+
              "and perhaps you could try taking off them *grin* \n");
    set_name("venus");
    set_level(18);
    set_hp(450);
    set_al(150);
    set_wc(26);
    set_ac(15);
    ob1=clone_object("players/cassandra/object/slip.c");
    move_object(ob1,this_object());
    command("wear trunks",this_object());
    }

