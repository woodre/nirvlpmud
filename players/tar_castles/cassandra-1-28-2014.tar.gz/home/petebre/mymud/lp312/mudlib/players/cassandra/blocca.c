inherit "room/room";
object h, h1, h2;

reset(arg) {
    h = clone_object ("players/beren/Monsters/Olgyo/piai.c");
    move_object (h, this_object());
    h1 = clone_object ("players/beren/Monsters/Olgyo/carmic.c");
    move_object (h1, this_object ());
    h2 = clone_object ("players/beren/Monsters/Olgyo/nameless.c");
    move_object (h2, this_object ());
    if (arg) return;

    set_light(1);
    short_desc = "A small hut";
    long_desc =
"You've just entered the small hut. You can see three Olgyos here and you\n"+
"can be sure - they won't let you out with all your money!\n";
    dest_dir = ({"players/beren/Rooms/Olgyo/oroom5", "west"});
}

init ()
{
    ::init ();
    add_action ("my_west", "west");
}

my_west (str)
{

    if (present ("piai") || present ("carmic") || present ("nameless")) {
            write ("You can't get out when Olgyo are still alive!");
            return 1;
    }
}
