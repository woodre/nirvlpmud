inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="Tunnel in the ground";
  long_desc="You continue walking in almost obscurity; you can only see the walls \n"+
	    "near you, and you can't know which kind of strange animals is running \n"+
	    "along the tunnel climbing on your feet too. \n";
  dest_dir = ({ 
       "players/cassandra/olimpo/otunnel2.c","back",
       "players/cassandra/olimpo/otunnel4.c","forward"});
 }

