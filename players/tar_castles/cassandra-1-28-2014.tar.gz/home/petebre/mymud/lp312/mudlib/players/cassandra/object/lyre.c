inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("lyre");
        set_short("Apollo's lyre");
        set_long("This is the instrument that Apollo used to play: a beautiful lyre made \n"+
              "of pure gold. It would be a real treasure for a musician, but few useful \n"+
              "for a warrior.\n");
         set_weight(2);
         set_value(950);

}
init(){
        add_action("play","play");
      }

play(str){
        if (!str) {
                write("What do you want to play?\n");
                return(1);
         }
        if (str=="lyre") {
                write("Your finger softly pluck the lyre strings and a magical music diffuses all around you.");
                write("You feel peaceful and somewhat a little healing\n");
                call_other(this_player(),"heal_self",3);
                return(1);
                
        }
        return(0);
}
