inherit "room/room"; 
reset(arg) {
  object ob1,ob2,k;
  int i; 
  short_desc="Olimpo Hotel Chainging room";
  long_desc="Here is where guests come to change their dress and wear costume,\n"+
            "and vice versa. Beware, there could be anyone spying from key hole \n"; 
  dest_dir = ({ 
      "players/cassandra/olimpo/sw_pool5.c","south"});
  set_light(0);
   ob1=clone_object("players/cassandra/object/bracelet.c");
     move_object(ob1,this_object());}

