inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3,k;
  int i; 
  short_desc="Neptune throne room";
  long_desc="You're standing in front of powerful king of any seas. \n"+
            "All around you a lot of corals and sea stars make room quite suggestive.\n"+
            "Here you can finally see a little stairs leading out of swimming pool \n";
  dest_dir = ({ 
     "players/cassandra/olimpo/sw_pool13.c","northwest",
       "players/cassandra/olimpo/sw_pool15.c","northeast",
       "players/cassandra/olimpo/sw_pool12.c","up",
       "players/cassandra/olimpo/swn1.c","south"});
  set_light(1);
  ob1=clone_object("players/cassandra/monsters/neptune.c");
  move_object(ob1,this_object());
 }

