inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="Olimpo Hotel Swimming Pool";
  long_desc="Finally you escape to open air; in front of you a magnificious swimming-pool \n"+
	    "extends in all its beauty. Hundreds of deck-chairs everywhere \n"+
             "You can start diving in pool. \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool6.c","west",
       "players/cassandra/olimpo/sw_pool7.c","north",
       "players/cassandra/olimpo/sw_pool11.c","dive",
       "players/cassandra/olimpo/sw_pool10.c","east"});
  set_light(1);
 }

