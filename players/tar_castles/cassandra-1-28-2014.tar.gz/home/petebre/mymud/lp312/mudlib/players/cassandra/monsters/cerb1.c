inherit "obj/monster";
object summoner_ob;
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Cerberus, the hell keeper, body ");
    set_long("You see a snarling dog with three different heads. \n"+
             "Everyone has long antlers and sharp teeths \n");
    set_name("body");
    set_level(15);
    set_hp(225);
    set_al(-500);
    set_wc(20);
    set_ac(12);
    ob1=clone_object("players/cassandra/object/collar.c");
    move_object(ob1,this_object());
}

