inherit "room/room"; 
int dato;
reset(arg) {
  object obj;
  dato=0;
  short_desc="A dark cavern";
  long_desc ="It's difficult to enter here. It's a wet big hole carved in rock where \n"+
             "you can see ... \n";
 dest_dir = ({ 
       "players/cassandra/tempio/cavern.c","west"});
 obj=clone_object("players/cassandra/tempio/monsters/elf.c");
 move_object(obj,this_object());
set_light(0);}

init(){
	::init();
	add_action("give","give");
        add_action("ask","ask");
}

give(str){
          if (str=="fur to elf"){
              write("Elf wears bear skin and starts defrosting. \n");
              write("You save his life, and surely he will be very grateful to you \n");
              destruct(present("fur",this_player()));
              dato=1;
          return 1;
          }
         }


ask(str){
	if (!str=="help") {
	   return 1;}
        else {
              if (dato==0) {
	            write("Elf can't help you.. he is half freezed \n");
                    return 1;
              }
              else {
   	            write("Elf says: 'You saved my life, and now i'll help you' \n");
                    write("Elf says: 'A lot of time passed since a guy came here' \n");
                    write("Elf says: 'looking for old women, and he never came back' \n");
                    write("Elf says: 'I don't know if they're still alive, but if'\n");
                    write("Elf says: 'they are you'll find them after solving maze.'\n");
                    write("Elf says: 'You've only to follow cleverness.'\n"); 
              return 1;
            }}
}

