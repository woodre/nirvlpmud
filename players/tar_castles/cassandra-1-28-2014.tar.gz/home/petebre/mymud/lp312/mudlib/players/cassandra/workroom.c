#define HEAL 500

inherit "room/room";
reset(arg) {
   if(arg) return;
   short_desc = "The Castle of Ruby";
   long_desc = "You can see a small room carved in one very big red ruby.\n"+
   "The light coming from out paints all rooms with strange and beautiful\n"+
   "red shadows, as you are in the middle of fire. But you feel very calm\n"+
   "and relaxed in such a nuances concert. By one corner there's a neat\n"+
   "table with a sun sparc station on it, and by another one a portal\n"+
   "leading to a beauty center\n";   
    dest_dir = ({ 
    "room/church", "church",
    "room/post"  , "post" ,
    "room/adv_guild" , "adv" ,
    "room/shop"  , "shop" ,
    "room/forest6" , "out" ,
    "players/cassandra/bedroom" , "west"
    });
   set_light(1);

}

init(){
    ::init();
        add_action("center","center");
}
center() {

    int res,max;
write ("You enter in Cassandra's beauty center. A 3-D projector send\n"+
"images about grove, stream and multicoulored singing bird, so you\n"+
    "in the middle of nature. Some handsome boys puts you on a bed and\n"+
    "starts a slow and healed massage with their clever hands. You\n"+
    "really feel in paradise\n");
    say (this_player()->query_name() + " is getting a massage.\n");
    call_other(this_player(),"heal_self",HEAL);
    return 1;
}
realm(){return "NT";}
