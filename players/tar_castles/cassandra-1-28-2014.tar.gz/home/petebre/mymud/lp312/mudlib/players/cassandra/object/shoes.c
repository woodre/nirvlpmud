inherit "obj/armor";

string backp,bpatt,patt,ggg;
object obj;

reset(arg){
   if(arg) return;
   patt=allocate(1);
   bpatt=allocate(1);
   backp=allocate(1);
   ::reset(arg);
        set_name("shoes") ;
        set_short("Winged shoes") ;
        set_long("A pair of winged boots. If you have them you can [fly] faster. \n"+
                 "Type [info] for help \n");
        set_weight(1) ;
        set_value(20000);
        set_type("armor") ;
        set_ac(1) ;
        set_save_flag(0);
}

init(){
	::init();
	add_action("fly","fly");
	add_action("info","info");
	}

info(){
	write("         / Mercury winged shoes \\ \n");
	write("With this shoes you can move faster between rooms \n");
	write("Just type 'fly dir,dir,....,dir' and you'll be taken \n");
	write("Wherever you want \n");
        return 1;
	}

fly(str){	
         if (!str){ 
               write("Where do you want to fly? \n"); return 1;}
         else {
               obj=this_player();
               patt=str;
               bpatt=gira(str);
               backp=volta(str);
               ggg=patt;
               write("Flying to: "+ggg+".\n");
               vola();
               return 1;}
}

gira(str) {
        int cont;        string pri,sec,rets;
        cont=1;
        rets="";
        while(cont!=0)  {
                cont=0;
                sec=str;
                str="";
                while(sscanf(sec,"%s,%s",pri,sec)==2)  {
                        if(cont!=0)
                                str+=",";
                        str+=pri;
                        ++cont;
                        }
                rets+=sec;
                if(cont!=0)
                        rets+=",";
                }
        return rets;
}

volta(str) {
        int cont;
        string pri,sec,rets;
        cont=1;
        rets="";
        while(cont!=0)  {
                cont=0;
                sec=str;
                str="";
                while(sscanf(sec,"%s,%s",pri,sec)==2)  {
                        if(cont!=0)
                                str+=",";
                        str+=pri;
                        ++cont;
                        }
                if(sec=="e")
                        sec="w";
                else if(sec=="w")
                         sec="e";
                else if(sec=="n")
                        sec="s";
                else if(sec=="s")
                        sec="n";
                else if(sec=="ne")
                        sec="sw";
                else if(sec=="nw")
                        sec="se";
                else if(sec=="se")
                        sec="nw";
                else if(sec=="sw")
                        sec="ne";
                else if(sec=="u")
                        sec="d";
                else if(sec=="d")
                        sec="u";
                rets+=sec;
                if(cont!=0)
                        rets+=",";
                }
        return rets;
}


vola()  {
        string path;
        int cont;
        int number;
        number=5;
        if(obj->query_brief()==1)
        number=10;       
        for(cont=0;cont<number;++cont)  {
                if(sscanf(ggg,"%s,%s",path,ggg)==2)  {
                        if(path=="e")
                                call_other(obj,"go_east");
                        else if(path=="w") 
                                call_other(obj,"go_west");
                        else if(path=="n")
                                call_other(obj,"go_north");
                        else if(path=="s")
                                call_other(obj,"go_south");
                        else if(path=="ne")
                                call_other(obj,"go_northeast");
                        else if(path=="nw")
                                call_other(obj,"go_northwest");
                        else if(path=="se")
                                call_other(obj,"go_southeast");
                        else if(path=="sw")
                                call_other(obj,"go_southwest");
                        else if(path=="u")
                                call_other(obj,"go_up");
                        else if(path=="d")
                                call_other(obj,"go_down");
                        else
                                tell_object(obj,"Illegal move!\n");
                }
                else {  
                        if(ggg=="e")
                                call_other(obj,"go_east");
                        else if(ggg=="w")
                                call_other(obj,"go_west");
                        else if(ggg=="n")
                                call_other(obj,"go_north");
                        else if(ggg=="s")
                                call_other(obj,"go_south");
                        else if(ggg=="ne")
                                call_other(obj,"go_northeast");
                        else if(ggg=="nw")
                                call_other(obj,"go_northwest");
                        else if(ggg=="se")
                                call_other(obj,"go_southeast");
                        else if(ggg=="sw")
                                call_other(obj,"go_southwest");
                        else if(ggg=="u")
                                call_other(obj,"go_up");
                        else if(ggg=="d")
                                call_other(obj,"go_down");
                        else
                                tell_object(obj,"Illegal move!\n");
                        tell_object(obj,"Done.\n");
                        return 1;
                        }
        }
        call_out("vola",1);
        return 1;
}


