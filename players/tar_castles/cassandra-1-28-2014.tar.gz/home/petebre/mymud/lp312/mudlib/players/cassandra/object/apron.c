inherit "obj/armor";
reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("apron");
        set_short("A heavy apron");
        set_long("This apron is made of a particular material which protects from spots \n"+
	         "and somehow from hits too \n");            
        set_weight(3);
        set_value(700);
        set_type("armor");
        set_ac(3);
}
