inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Queen Cassiophea");
    set_long("The powerful queen Cassiopea is crying despairness. Perhaps you could ask \n"+
            "her about her troubles.\n");
    set_name("cassiophea");
    set_alias("queen");
    set_gender("female");
    set_level(20);
    set_hp(500);
    set_al(100);
    set_wc(25);
    set_ac(17);
    gold=clone_object("obj/money"); 
    gold->set_money(4000);
    move_object(gold,this_object());
}


