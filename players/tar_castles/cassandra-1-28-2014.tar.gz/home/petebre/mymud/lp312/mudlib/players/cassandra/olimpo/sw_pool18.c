inherit "room/room"; 
reset(arg) {
  object ob1,ob2,k;
  int i; 
  short_desc="Olimpo Hotel Garages";
  long_desc="You enter in a large shed, which seems more a stable than a garage\n"+
	    "There're small doors with a number on everybody \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool17.c","north",
       "players/cassandra/olimpo/g1.c","1",
       "players/cassandra/olimpo/g2.c","2",
       "players/cassandra/olimpo/g3.c","3",
       "players/cassandra/olimpo/g4.c","4",
       "players/cassandra/olimpo/g5.c","5",
       "players/cassandra/olimpo/g6.c","6"});	 
  set_light(1);
  }

