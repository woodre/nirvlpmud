inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("oggetto3");
        set_long("This is a perfect red apple. It seems made of rubin.\n");
        set_weight(1);
        set_alias("mela");
        set_value(100);
}
