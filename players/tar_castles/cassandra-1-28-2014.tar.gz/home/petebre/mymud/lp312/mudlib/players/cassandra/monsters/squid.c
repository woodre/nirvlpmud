inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A giant black squid");
    set_long("You have never seen a so giant creature. It has eight long tentacles \n"+
             "and very cutting teeth. \n");
    set_name("squid");
    set_level(17);
    set_hp(450);
    set_al(-180);
    set_wc(24);
    set_ac(15);
}
