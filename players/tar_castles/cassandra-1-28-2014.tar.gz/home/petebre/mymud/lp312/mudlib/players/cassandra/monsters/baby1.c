inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A male baby");
    set_long("The child of some god too busy in enjoy him/herself to take care of him.\n"+
	     "He's carrying the money for snack.\n");  
    set_name("male baby");
    set_alias("baby");
    set_level(5);
    set_hp(70);
    set_al(30);
    set_wc(9);
    set_ac(5);
    gold=clone_object("obj/money"); 
    gold->set_money(80+random(40));
    move_object(gold,this_object()); 
    ob1=clone_object("/players/cassandra/object/ball.c");
    move_object(ob1,this_object());
}
