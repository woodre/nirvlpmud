inherit "room/room"; 

reset(arg) {
  object obj,ob1,ob2,ob3;
  short_desc="At the hell";
  long_desc="You enter in a gloomy hole, bad lightened only by smoky and pale torch\n"+
	    "Looking better you see this is a lift, with 3 push-buttons,  \n"+
	    "numbered with 1,2,3 \n";
  dest_dir = ({"players/cassandra/olimpo/hell/hell2.c","back"});
   set_light(1);
  }
init(){
	::init();
       add_action("push","press");
	add_action("press","press");
        add_action("press","push");
	}
press(str){
	if (str=="1") {
	      move_object(this_player(),"/players/cassandra/olimpo/olimpo2.c");
	      write("The lift starts moving up and stops in Hotel Hall \n");
	      return 1;}
	else if (str=="2"){
	      move_object(this_player(),"/players/cassandra/olimpo/hell/shore.c");
	      write("The lift starts moving up and after some seconds doors open again \n");
	      write("While you're trying to understand where you're the lift disappears \n");
	      return 1;}
	else if (str=="3"){
		write("You're just at level three ! \n");
	        return 1;}
	else 
	    {write("press what? \n");
	     return 1;}
}
