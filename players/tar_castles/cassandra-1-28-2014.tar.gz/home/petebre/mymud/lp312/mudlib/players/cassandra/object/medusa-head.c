inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("head");
        set_short("Medusa's head") ;
        set_long("This is the Medusa's head. It has the power to stoned everyone looks it\n"+
                 "except who is wielding it\n");
        set_weight(2) ;
        set_value(5000);
        set_class(18) ;
        set_hit_func(this_object());
}

weapon_hit(attacker)
{
 if (random (10) > 3) return 0;
 write("Your opponent feels its body stoned.\n");
 say (this_player()->query_name()+" slowly stoned his opponent\n");
 return 10+random (15);
}
