inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="House of Gnomes";
  long_desc="You've to stoop for enter in this small house. All around you \n"+
            "there're small chairs, a little table, a little divan and on it \n"+
            "there's sitting..\n";
  dest_dir = ({ "players/cassandra/tempio/gn_home2.c", "north",
       "players/cassandra/tempio/rainbow6.c","east"});
  obj=clone_object("players/cassandra/tempio/monsters/lgnome.c");      
  move_object(obj,this_object());
  set_light(1);
}
