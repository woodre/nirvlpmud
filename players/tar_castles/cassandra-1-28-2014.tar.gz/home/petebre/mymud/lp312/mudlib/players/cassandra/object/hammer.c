inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("hammer");
        set_short("A heavy hammer") ;
        set_long("This hammer is so heavy that it can crush almost everything \n");
        set_weight(4) ;
        set_value(800);
        set_class(20) ;
        set_hit_func(this_object());
}

weapon_hit(attacker) {
if (random(10)>3) return 0;
write("You crush your opponent to a shapeless mush\n");
say(this_player()->query_name()+" crushes his opponent. \n");
return random(25);
}

