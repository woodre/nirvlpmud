inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A stoned soldier");
    set_long("A greek soldier imprisoned in stone. He's moving leading by a magical force\n"); 
    set_name("soldier");
    set_level(13);
    set_hp(200);
    set_al(100);
    set_wc(17);
    set_ac(15);
    ob1=clone_object("/players/cassandra/object/sboots.c");
    move_object(ob1,this_object());
    ob2=clone_object("/players/cassandra/object/s-gun.c");
    move_object(ob2,this_object());
    command("wear boots",this_object());
    command("wield gun",this_object());
}
