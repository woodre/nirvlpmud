inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A deadly scorpion");
    set_long("You haven't ever seen a so big scorpion.. you could think about a \n"+
	     "genetics mutation.. if genetics has been just invented \n");
    set_name("scorpion");
    set_level(12);
    set_hp(180);
    set_al(-200);
    set_wc(18);
    set_ac(9);
    set_aggressive(1);
    set_chance(15);
    set_spell_dam(random(15));
    set_spell_mess1("Scorpion hits you with its tail and you're poisoned \n");
    ob1=clone_object("/players/cassandra/object/poison.c");
    move_object(ob1,this_object());
   }


