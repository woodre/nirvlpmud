inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="On Caron's ferry";
  long_desc ="You're standing in a small ferry.. and you see the world swings around you\n"+
	     "The ferry slowly slides on water until it arrives in the middle of the river \n"+
             "and stops \n";
 
 obj=clone_object("players/cassandra/monsters/caron.c");
 move_object(obj,this_object());
 set_light(1);
}

init(){
        add_action("give","give");
        add_action("pay","pay");
      }


pay(str){
          if (str=="caron"){
              command("give coins to caron",this_player());
              return(1);
          }
          else {
              write("Pay who? \n");
	      return (1);}
}

give(str){
          if (present("caron",environment(this_player()))){
          	if (str=="gold to caron" || str=="coins to caron") {
             		write("Caron clasps his hand, puts coins in pocket and magically the ferry \n");
             		write("restarts. After some seconds you arrive on the other bank.\n");
             		call_other(this_player(),"add_money",-100); 
             		move_object(this_player(), "players/cassandra/olimpo/hell/shore.c");    
             		return 1;
         	}
	        else {
			write("Give what to who?\n");                
			return 0;}}      
          else {
		write("There is nobody to give anything \n");
                return 0;}
         
}

	
                
 
