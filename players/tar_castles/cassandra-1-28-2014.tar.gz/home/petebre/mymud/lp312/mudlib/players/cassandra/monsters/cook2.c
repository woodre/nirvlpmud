inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Cook");
    set_long("A boy very busy in preparing first dishes for guests' dinner\n");
    set_name("cook");
    set_level(8);
    set_hp(120);
    set_al(-50);
    set_wc(12);
    set_ac(7);
    ob1=clone_object("players/cassandra/object/spaghetti.c");
    move_object(ob1,this_object());
}
