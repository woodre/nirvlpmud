inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("sting");
        set_short("A poisoned sting") ;
        set_long("You see a black and deadly sting, pouring poison \n");
        set_weight(2) ;
        set_value(600);
        set_class(12) ;
        set_hit_func(this_object());
}

weapon_hit(attacker) {
if (random(10)>3) return 0;
write("You poison your opponent \n");
say(this_player()->query_name()+" has been poisoned. \n");
return 10+random(10);
}

