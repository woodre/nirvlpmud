inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A flower");
    set_long("This flower is called 'lion tooth', but you don't know it has the lion courage too\n");
    set_name("flower");
    set_level(6);
    set_hp(90);
    set_al(-20);
    set_wc(11);
    set_ac(5);
    set_aggressive(random(1));
    ob1=clone_object("/players/cassandra/tempio/oggetti/nectar");
    move_object(ob1,this_object());
    gold=clone_object("/obj/money");
    gold->set_value(100);
    move_object(gold,this_object());
}
