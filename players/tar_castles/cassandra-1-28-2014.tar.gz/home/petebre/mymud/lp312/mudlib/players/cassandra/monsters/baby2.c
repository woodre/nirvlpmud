inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A female baby");
    set_long("The child of some god too busy in enjoy him/herself to take care of her.\n"+
	     "She's carrying the money for snack.\n");  
    set_name("female baby");
    set_alias("baby");
    set_level(8);
    set_hp(120);
    set_al(50);
    set_wc(12);
    set_ac(7);
    gold=clone_object("obj/money"); 
    gold->set_money(150+random(100));
    move_object(gold,this_object()); 
    ob1=clone_object("/players/cassandra/object/dolly.c");
    move_object(ob1,this_object());
}
