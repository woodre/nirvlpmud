inherit "room/room"; 
reset(arg) {
  short_desc="Path to Mountain";
  long_desc ="You're following a narrow path leading north. Walking up you \n"+
             "feel the temperature becoming more cold\n";
  dest_dir = ({ 
       "players/cassandra/tempio/nroom7.c", "south",
       "players/cassandra/tempio/mountain2.c","up"});
  set_light(1);}

 
