reset(arg) {
        if(arg) return;
        /* Initialization code goes here */
}
    query_auto_load() {
    return "/players/cassandra/tool.c:";
}
long() {
        write( "This is a strange looking object. It seems to be a wiztool.\n" );
        return 1;
}

short() {
   return "A bloody brain";
}

id(str) {
        if( str == "tool" ) return 1;
        return 0;
}

init() {
        add_action( "trans", "trans" );
        add_action( "dhl", "dhl" );
        add_action( "force", "force" );
        add_action( "leaf", "leaf" );
        return 1;
}






force(str) {
  object who;
  string what;
  if(sscanf(str,"%s %s",who,what)==2) {
    if(!find_living(who)) {
      notify_fail("That is not on the MUD!\n");
      return 0;
    }
    command(what,find_living(who));
    write("Done.\n");
    write("You forced :"+who+" to "+what+".\n");
    return 1;
  }
  write("Usage: force <player> <action>\n");
  return 1;
}


dhl(str)
 { 
    string stuff,rece;
    object stuff1,rece1;
    if((!str) || ((sscanf(str,"%s %s",stuff,rece) !=2)))
      {   notify_fail("You fail to send.\n");
          return 0;
      }
    if(!present(stuff) || !find_living(rece))
      {   notify_fail("Stuff or receiver not present.\n");
          return 0;
      }
    rece1=find_living(rece);
    stuff1=present(stuff);
    move_object(stuff1,rece1);
    tell_object(rece1,"A butterfly flies out from a flower and gives you a "+stuff+" saying it's from Cassandra.\n");
    write("You send a "+stuff+" to "+rece1->query_name()+".\n");

    return 1;
  }


trans( str ) {
        object  who;
        object  env;
        object       envwho;
        string  filenm;

        who = find_living( str );
        if( !who ) {
                notify_fail( "You cannot trans non-living things!\n" );
                return 0;
        }

        env = environment( this_player() );
        if( !env ) {
                notify_fail( "Bug! You have no environment!?!\n" );
                return 0;
        }

   if( !interactive( who ) ) {
                move_object( who, env );
                write( "Ok.\n" );
                return 1;
        }

        envwho = environment( who );
   tell_object( who, "\nYou feel on the wing of the wind. Cassandra summons you\n" );
   tell_room(  env, "\nCassandra snaps his fingers and " +who->query_name() + 
       " appears at his feet.\n");
        move_object( who, env );
   tell_room(  envwho, "\nYou see a flash of light ." +who->query_name() + 
               " disappears in it.\n");


  return 1;

}


leaf(str)
 {
      string stuff,rece;
       object stuff1,rece1;
       rece=str;
       if((!str))
              {   notify_fail("You fail to send.\n");
              return 0;
              }
      if(!present("leaflet") || !find_living(rece))
             {   notify_fail("Leaflet or receiver not present.\n");
               return 0;
             }
 rece1=find_living(rece);
 stuff1=present("leaflet");
 move_object(stuff1,rece1);
write("You send a leaflet to "+rece1->query_name()+".\n");
tell_object(rece1,"Cassandra sends you a leaflet saying: 'aren't you curious?'.\n");
 return 1;
 }
