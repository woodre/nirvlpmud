inherit "obj/treasure";
reset(arg) {
        object gold;
        if(arg) return;
        set_id("pot");
        set_short("gold pot");
        set_long("This is one of the famous pots you can find at the end of any rainbow.\n"+
                 "It's empty and a little dirty.\n");
         set_weight(1);
         set_value(20);
}
