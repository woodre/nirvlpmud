inherit "obj/drink";
reset(arg){
   ::reset(arg);
   if(arg) return;
   set_value("blood#A test tube full of blood#You drink the children blood and you feel diabolic.#35#500#6");
} 
