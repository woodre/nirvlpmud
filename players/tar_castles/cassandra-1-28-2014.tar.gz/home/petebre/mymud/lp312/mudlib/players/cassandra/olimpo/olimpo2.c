inherit "room/room";
int fiammiferi; 
reset(arg) {
  object ob1,ob2;
  int i; 
  fiammiferi=20;
  short_desc="Olimpo Hotel";
  long_desc="You enter in Hotel and you're impressed by too many magnificence.\n"+
            "A marble stairs lead to upper levels, and through a glass wall you can \n"+
	    "accede to swimming-pool and garden (north).\n"+
            "There's obviously a reception where you can ask for information. \n"+
	    "On the desk there's a small basket \n";
  dest_dir = ({ 
       "players/cassandra/olimpo/olimpo1.c", "west",
       "players/cassandra/olimpo/sw_pool1.c","north",
       "players/cassandra/olimpo/bar1.c","south",
       "players/cassandra/olimpo/olimpoup1.c","up",
       "players/cassandra/olimpo/odown1.c","down"});
  set_light(1);
  for (i=0;i<6;i++){
  ob1=clone_object("players/cassandra/monsters/man.c");
  move_object(ob1,this_object());}
 }

init(){
	::init();
	add_action("ask","ask");
        add_action("up","up");
        add_action("look","look");
	add_action("get","get");
       }

look(str){
	   if ((str=="at basket") || (str=="at small basket")){
		write("It's a basket full of boxes of matches, with the Hotel compliments \n");
	        write("Perhaps you could take one, if you need it \n");
	        return 1;}
	}

get(str){
	object box;
         if ((str=="matches") || (str=="box of matches") || (str=="box")) {
	     if (fiammiferi>0) {
		write("You furtively stretch out your hand and get a box of matches \n");
	        fiammiferi=fiammiferi-1;
	        box=clone_object("/players/cassandra/object/matches.c");
	        move_object(box,this_player());
	        return 1;
     	     }
	     else {
	        write("There are no more boxes of matches in small basket, sorry \n");
	        return 1;}
	    }
	else {
	    write("Get what? \n");
	    return 1;
	}
}  
	        

ask(){
	write("One man at reception looks at you and says: \n");
        write("'We need neither dishwasher nor porter' \n");
        write("Go down to kitchen if you want a warm soup, but '\n");
        write("         DON'T DISTURB OUR GUESTS !!     '\n");
        write("Man returns to his work, ignoring you. \n");
        return 1;
}

up(){
	write("This area is at the moment closed for works \n");
	write("It'll be ready at the end of november (i hope) \n");
 	return 1;
}
