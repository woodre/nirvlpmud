inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="O.H. Kitchen";
  long_desc="Down from the hall elegance you arrive in a hot and dark place  \n"+
	    "You're in the middle of a passage leading to west or east. \n"+
	    "Metallic sounds coming from west, and a inviting smell comes from south \n";
  dest_dir = ({ 
       "players/cassandra/olimpo/odown4.c","west",
       "players/cassandra/olimpo/odown2.c","east",
       "players/cassandra/olimpo/odown6.c","south"});
  set_light(1);
 }

