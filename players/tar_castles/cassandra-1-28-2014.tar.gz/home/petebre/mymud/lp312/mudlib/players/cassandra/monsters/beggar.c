inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A poor beggar");
    set_long("A poor and sick man wearing dirty rugs. From his breath you can understand "+
             "he drinks a lot in last 24 hours.\n");
    set_name("beggar");
    set_gender("male");
    set_level(7);
    set_hp(100);
    set_al(50);
    set_wc(11);
    set_ac(6);
    set_race("human");
    set_chat_chance(20);
    load_chat("Beggar says: '..hic .. i never drrrrrink too much .. hic'\n");
    load_chat("Beggar says: ' my bbbest friend .. hic.. is wine .. hic '\n");
    load_chat("Beggar says: 'It's the .. hic.. best way to spend .. hic.. mmmoney'\n");
    set_chance(8);
    set_spell_dam(random(10)+5);
    set_spell_mess1("Beggar drinks a gulp of wine and become stranger \n");
    gold=clone_object("obj/money"); 
    ob1=clone_object("/players/cassandra/object/bottiglia.c");
    move_object(ob1,this_object());
}
