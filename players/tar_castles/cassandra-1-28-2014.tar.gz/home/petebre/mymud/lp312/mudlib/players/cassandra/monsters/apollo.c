inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Apollo the god of sun");
    set_long("A young and very handsome man. He lead the sun-cart every day so he's \n"+
             "very sun-tanned. He's playing his lyre and singing a love song.\n");
    set_name("apollo");
    set_gender("male");
    set_level(21);
    set_hp(650);
    set_al(300);
    set_wc(30);
    set_ac(18);
    set_race("human");
    set_chat_chance(25);
    load_chat("Apollo says: 'I'm the sun god.. go away from us silly mortal!!'\n");
    set_chance(10);
    set_spell_dam(random(20)+20);
    set_spell_mess1("Apollo burns your body with a sun-ray \n");
    ob1=clone_object("/players/cassandra/object/lyre.c");
    move_object(ob1,this_object());
    ob2=clone_object("players/cassandra/object/Ap_elmo.c");
    move_object(ob2,this_object());
    command("wear helmet",this_object());
    set_aggressive(1);
}
