inherit "room/room"; 
reset(arg) {
  object obj;
  int i;
  short_desc="Cassiophea's Castle";
  long_desc ="In this area there're hundreds of fruit tree .. apples, pears, oranges,\n"+
	     "peaches fill the branches. A apple tree larger than others.\n";
  dest_dir = ({ 
       "players/cassandra/tempio/castle/castle6.c", "east"});
  set_light(1);
}

init(){
	::init();
	add_action("climb","climb");
       }

climb(str){
	if (!str=="tree")
	   {return 1;}
	else {
               write(this_player()->query_name() + " climbs tree\n"); 
               move_object(this_player(), "/players/cassandra/tempio/castle/tree.c");
               return 1;}
}
       
		
