inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Pluto, the god of hell");
    set_long("You see a huge figure partially hidden by dark.\n"+
	     "The only thing you can see very well are two malignant and yellow eyes \n"+
	     "looking and you \n");
    set_name("pluto");
    set_gender("male");
    set_level(18);
    set_hp(450);
    set_al(-500);
    set_wc(26);
    set_ac(15);
    set_chance(10);
    set_spell_dam(random(10)+10);
    set_spell_mess1("Pluto's eyes sparkle full of hatred and you feel winded round\n"+
		    "by burned flames \n");
    ob1=clone_object("/players/cassandra/object/flame_thrower.c");
    move_object(ob1,this_object());
    command("wield flame_thrower",this_object());
    set_aggressive(1);
}
