inherit "room/room";
reset(arg) {
   if(arg) return;
   short_desc = "The Castle of Ruby";
   long_desc = "This is a woman bedroom. All you can see is a burnt chimney\n"+
               "digged in rubin, a large mirror and a inviting baldachin bed\n"+
               "with soft silk sheet. How exiting should be sleep there.\n";
    dest_dir = ({ 
    "players/cassandra/workroom" , "east"
    });
   set_light(1);

}

realm(){return "NT";}
