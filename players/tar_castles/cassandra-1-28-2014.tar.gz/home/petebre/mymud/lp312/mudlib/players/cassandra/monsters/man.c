inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A man at reception");
    set_long("A unctuous face in a blue uniform, full of tips.\n");  
    set_name("man");
    set_gender("male");
    set_level(10);
    set_hp(150);
    set_al(-100);
    set_wc(12);
    set_ac(10);
    gold=clone_object("obj/money"); 
    gold->set_money(300+random(150));
    move_object(gold,this_object()); 
}
