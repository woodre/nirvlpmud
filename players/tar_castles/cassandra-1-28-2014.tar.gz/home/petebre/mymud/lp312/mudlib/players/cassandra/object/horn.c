inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("horn");
        set_alias("corno");
        set_short("Stigs horn");
        set_long("An old and infernal horn. It's used to call Caron and cross the Stigs\n");
        set_weight(1);
        set_value(200);
}


