inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3,k;
  int i; 
  short_desc="In Swimming Pool";
  long_desc="The warm is obviously at a perfect temperature to have a bath.  \n"+
            "You notice that water is rather deep, so that some animals could enjoy \n"+
	    "itself too; after all here domestic pets are allowed \n";
  dest_dir = ({ 
     "players/cassandra/olimpo/sw_pool8.c","north",
       "players/cassandra/olimpo/sw_pool15.c","south",
       "players/cassandra/olimpo/sw_pool9.c","west"});
  set_light(1);
  for (k=0;k<2+random(2);k++){
  ob1=clone_object("players/cassandra/monsters/triton.c");
     move_object(ob1,this_object());}
 
 }

init(){
	::init();
	add_action("my_south","south");
       }

my_south(){
	    if (present("triton")) {
	        write("Triton blocks your way defending its king \n");
                return 1;
             }
}
