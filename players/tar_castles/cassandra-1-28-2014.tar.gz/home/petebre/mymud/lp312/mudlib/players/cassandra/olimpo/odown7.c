inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3;
  int i; 
  short_desc="O.H. Kitchen";
  long_desc="This is the really kitchen of hotel: you don't understand how could  \n"+
	    "a so small kitchen prepares dinners for all guests, but probably there's \n"+
	    "some magical secrets. \n"+
	    "From here someone is directing all operations \n";
  dest_dir = ({ 
       "players/cassandra/olimpo/odown6.c","north"});
  set_light(1);
  ob1=clone_object("/players/cassandra/monsters/juno.c");
  move_object(ob1,this_object());
  }

