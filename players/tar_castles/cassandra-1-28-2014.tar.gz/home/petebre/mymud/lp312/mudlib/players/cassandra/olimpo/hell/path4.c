inherit "room/room"; 
reset(arg) {
  object obj;
  int i;
  short_desc="A dark path";
  long_desc="This is a dark path obtained moving big stones with a enormous strenght.\n"+
            "A stone portal to north. But.. what a strange.. everything here seems \n"+
            "made of stone, there're too..\n";
  dest_dir = ({ "players/cassandra/olimpo/hell/portal.c","north",
       "players/cassandra/olimpo/hell/path2.c","south"});
  for (i=0; i<4; i++){
set_light(1);
       obj=clone_object("/players/cassandra/monsters/general.c");
      move_object(obj,this_object());
  }
}

init(){
    ::init ();
    add_action ("my_north", "north");
}

my_north (str)
{
    if (present ("general")) {
            write("General doesn't let you pass\n");
            return 1;
    }
}
