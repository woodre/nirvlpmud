inherit "obj/monster";
reset(arg){
    object ob1,ob2;
    ::reset(arg);
    if (arg) return;
    set_short("A fleaded dog");
    set_long("A angry dog which wants to eat cat. \n");
    set_name("dog");
    set_level(9);
    set_hp(100);
    set_al(-40);
    set_wc(10);
    set_ac(8);
    set_aggressive(1);
    ob1=clone_object("/players/cassandra/tempio/oggetti/bone.c");
    move_object(ob1,this_object());
    ob2=clone_object("/players/cassandra/tempio/oggetti/collar.c");
    move_object(ob2,this_object());
    command("wear collar",this_object());

}
