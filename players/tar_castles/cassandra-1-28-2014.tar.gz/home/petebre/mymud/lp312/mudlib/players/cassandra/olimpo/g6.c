inherit "room/room"; 
reset(arg) {
  object ob1,ob2,k;
  int i; 
  short_desc="Small Box";
  long_desc="This is a empty horse box.\n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool18.c","hall"});	 
  set_light(1);
  ob1=clone_object("/players/cassandra/object/straw.c");
  move_object(ob1,this_object());
 }

