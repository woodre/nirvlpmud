inherit "room/room"; 
reset(arg) {
  short_desc="Maze of Fate";
  long_desc ="You're in a difficult maze, but at least here the temperature isn't \n"+
             "cold as outside and there isn't snow to make tiring walking. \n"+
             "A big portal in front of you. \n";
              dest_dir = ({ 
       "players/cassandra/closed/maze/maze1", "west",
       "players/cassandra/closed/maze/maze1","north",
       "players/cassandra/closed/maze/maze1","east",
       "players/cassandra/closed/maze/maze1","south"});
  set_light(1);}

init(){
        ::init();
        add_action("pass","look");
        add_action("enter","enter");
             }


enter(str){if (str=="portal"){

	write(this_player()->query_name()+" enters portal\n");
        move_object(this_player(),"players/cassandra/closed/maze/women_room.c");
        return 1;
       }
       else write("Where do you want to enter? /n");
       } 

pass(str){
	   if (str=="at portal"){
	     write("A old and unsafe portal. You hear some noises coming from other side \n");
	     return 1;}
	 }

