inherit "obj/drink";
reset(arg){
    ::reset(arg);
    if (arg) return;
    set_value("whiskey#A drink of aged whiskey#You drink all liqueur and you feel so hot#30#300#15");
}
