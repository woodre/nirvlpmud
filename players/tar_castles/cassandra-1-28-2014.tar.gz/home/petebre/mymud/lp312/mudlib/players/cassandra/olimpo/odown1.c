inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="O.H. Kitchen";
  long_desc="Down from the hall elegance you arrive in a hot and dark place  \n"+
	    "You're in the middle of a passage leading to west or east. \n"+
	    "Metallic sounds coming from west\n";
  dest_dir = ({ 
       "players/cassandra/olimpo/olimpo2.c","up",
       "players/cassandra/olimpo/odown2.c","west",
       "players/cassandra/olimpo/odown10.c","east"});
  set_light(1);
 }

