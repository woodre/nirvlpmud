inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3,k; 
  short_desc="Olimpo Hotel Swimming Pool";
  long_desc="There's a hedge to north which could guarantee hotel guests calm, but \n"+
            "what can guarantee it from a horde of uleashed children? \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool6.c","west",
       "players/cassandra/olimpo/sw_pool5.c","north",
       "players/cassandra/olimpo/sw_pool8.c","south",
       "players/cassandra/olimpo/sw_pool10.c","southeast"});
  set_light(1);
  for (k=0;k<3;k++){
  ob1=clone_object("players/cassandra/monsters/baby1.c");
     move_object(ob1,this_object());}
  for (k=0;k<3;k++){
  ob2=clone_object("players/cassandra/monsters/baby2.c");
     move_object(ob2,this_object());}
   for (k=0;k<2;k++){
  ob3=clone_object("players/cassandra/monsters/teacher.c");
     move_object(ob3,this_object());}
 
 }

