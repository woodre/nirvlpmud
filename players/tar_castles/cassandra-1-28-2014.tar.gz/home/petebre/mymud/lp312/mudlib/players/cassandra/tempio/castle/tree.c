inherit "room/room"; 
int barca,num;
object obj,ob1,newobj;
object env;

reset(arg) {
  short_desc="Cassiophea's Castle";
  long_desc="You're at the top of a big big apple tree. From here you can see all \n"+
	    "the garden, and you are fascineted by nature beauty. What can you find on a \n"+
            "apple tree except .. \n";
dest_dir = ({ "players/cassandra/tempio/castle/castle7.c", "down"});
   ob1=clone_object("/players/cassandra/tempio/oggetti/apple.c");
   move_object(ob1,this_object());  
   set_light(1);
}

