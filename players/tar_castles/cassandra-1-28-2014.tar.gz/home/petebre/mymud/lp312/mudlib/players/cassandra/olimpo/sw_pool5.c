inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3,k;
  int i; 
  short_desc="Olimpo Hotel Swimming Pool";
  long_desc="There's a hedge to north which could guarantee hotel guests calm, but \n"+
            "what can guarantee it from a horde of uleashed children? \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool4.c","west",
       "players/cassandra/olimpo/sw_pool7.c","south",
       "players/cassandra/olimpo/sw_pool2.c","north"});
  set_light(1);
  for (k=0;k<2+random(1);k++){
  ob1=clone_object("players/cassandra/monsters/baby1.c");
     move_object(ob1,this_object());}
  for (k=0;k<2+random(1);k++){
  ob2=clone_object("players/cassandra/monsters/baby2.c");
     move_object(ob2,this_object());}
 for (k=0;k<2+random(1);k++){
  ob3=clone_object("players/cassandra/monsters/teacher.c");
     move_object(ob3,this_object());}
}

