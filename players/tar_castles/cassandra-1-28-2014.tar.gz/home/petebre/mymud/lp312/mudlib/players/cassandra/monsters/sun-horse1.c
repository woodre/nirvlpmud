inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A beautiful stallion");
    set_long("This could be one of four horses that lead the sun-cart., it's the \n"+
	     "reserve one. \n");
    set_name("horse");
    set_alias("stallion");
    set_level(13);
    set_hp(200);
    set_al(100);
    set_wc(15);
    set_ac(15);
    gold=clone_object("obj/money"); 
    gold->set_money(1000);
    move_object(gold,this_object()); 
}
