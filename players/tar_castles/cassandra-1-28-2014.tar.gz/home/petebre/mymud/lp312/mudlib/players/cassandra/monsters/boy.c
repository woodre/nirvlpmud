inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A handsome boy");
    set_long("God are used to enjoy themselves using the same methods human do,\n"+
             "at least it's what you could think looking this boy with a girl :P \n");  
    set_name("boy");
    set_level(13);
    set_hp(195);
    set_al(-100);
    set_wc(15);
    set_ac(12);
    ob1=clone_object("/players/cassandra/object/boxer.c");
    move_object(ob1,this_object());
    command("wear boxer",this_object());
}
