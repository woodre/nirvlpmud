inherit "obj/monster";
reset(arg){
    object ob1,ob2;
    ::reset(arg);
    if (arg) return;
    set_short("A mangy cat");
    set_long("A afraid cat using all its nail to defend itself.\n"); 
    set_name("cat");
    set_level(10);
    set_hp(100);
    set_al(-40);
    set_wc(12);
    set_ac(8); 
    set_aggressive(1);
    ob1=clone_object("/players/cassandra/tempio/oggetti/nail.c");
    move_object(ob1,this_object());
    command("wield claws",this_object());
}
