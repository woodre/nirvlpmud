inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Young Cook");
    set_long("A boy very busy in preparing hors d'oeuvres for guests' dinner \n");
    set_name("cook");
    set_alias("young cook");
    set_level(6);
    set_hp(90);
    set_al(-30);
    set_wc(10);
    set_ac(5);
    ob1=clone_object("players/cassandra/object/ham.c");
    move_object(ob1,this_object());
}
