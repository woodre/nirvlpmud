inherit "room/room";
reset(arg){
    set_light(1);
    short_desc= "Mythology Realm Entrance";
    long_desc="You climb the small stairs in front of Temple and enter in \n"+
    "darkness. Wait.. not yet your eyes get used to twilight you \n"+
    "see there're some torches giving off low and qwivering light \n"+
    "A kind of map is carved on a near column. \n";
 dest_dir = ({ 
    "players/cassandra/tempio/nroom1", "north",
    "players/cassandra/tempio/wroom1", "west",
    "players/cassandra/tempio/eroom1", "east",
    "players/cassandra/tempio/bar", "south"});}

init() {
    ::init();
    add_action("read","read");
    add_action("read","look");
  }

read(str) {
    if (str != "map")
        return 0;
    write("Welcome in Mythology Realm.");
    write("Here you can find area and monster for newbies, middle_lever players \n");
    write("and high level ones (this area is where i could materialize my \n");
    write("worst cruel instincts). \n");
    write("Enjoy yourself.. if you can *grin* \n");
    write(" \n");
    write("                High level Area         \n");
    write("                       |                \n");
    write("                       n                \n");
    write("                       |                \n");
    write(" Middle L. A. -w-  you're here  -e- Newbie \n");
    write("                       |                \n");
    write("                       s                \n");
    write("                       |                \n");
    write("                      Bar               \n");
    write(" \n");
    write("For bugs, suggestions or other mail Cassandra \n"); 
    return 1;
 }
