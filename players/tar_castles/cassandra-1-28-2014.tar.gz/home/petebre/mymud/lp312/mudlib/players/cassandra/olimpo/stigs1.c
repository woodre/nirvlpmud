inherit "room/room"; 
reset(arg) {
  object ob1;
  int i;
  short_desc="On the rive of the Stigs";
  long_desc="You are floating in a strange area.. cloud and fog all around you, wet air \n"+
	    "and bad smell come from a dark river flowing near path.\n";
  dest_dir = ({ "players/cassandra/olimpo/stigs2.c", "north",
		"players/cassandra/olimpo/otunnel6.c","tunnel",
		"players/cassandra/olimpo/river.c","east"});
  set_light(1);
}

init(){
        ::init();
	add_action("go_east","east");
       }

go_east(){
	  write("If you want to cross the river go further until you'll find the cursed ferry-man\n ");
	  return 1;}
		


