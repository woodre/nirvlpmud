inherit "room/room"; 
int porta1,porta2,porta3;
object ob;

reset(arg) {
  object obj,ob1,ob2,ob3;
  short_desc="At the hell";
  long_desc="Descending stairs between lapilluses and cinders you arrive in a \n"+
	    "large cavern where you can see three doors. And... \n";
  dest_dir = ({"players/cassandra/olimpo/hell/hell1.c","up",
               "players/cassandra/olimpo/hell/door1.c","red_door",
	       "players/cassandra/olimpo/hell/door2.c","yellow_door",
	       "players/cassandra/olimpo/hell/door3.c","black_door"});
   set_light(1);
  ob=clone_object("players/cassandra/monsters/cerb1.c");
   move_object(ob,this_object());
   ob1=clone_object("players/cassandra/monsters/cerb2.c");
   move_object(ob1,this_object());
   ob2=clone_object("players/cassandra/monsters/cerb3.c");
   move_object(ob2,this_object());	
   ob3=clone_object("players/cassandra/monsters/cerb4.c");
   move_object(ob3,this_object());
   porta1=1;
   porta2=1;
   porta3=1;
}

init(){
	::init();
	add_action("red_door","red_door");
	add_action("yellow_door","yellow_door");
	add_action("black_door","black_door");
        add_action("use","use");
      }

use(str){
	  if ((str=="red_key in red_door") && (present("red_key",this_player())))
		{ porta1=0;
	          write("You here a click and door slowly opens with a dismal squeaking \n");
                  return 1; }
           else if ((str=="yellow_key in yellow_door") && (present("yellow_key",this_player())))
	        { porta2=0;
	          write("You here a click and door slowly opens with a dismal squeaking \n");
                  return 1; }
           else if ((str=="black_key in black_door") && (present("black_key",this_player()))) 
	      	{ porta3=0;
	          write("You here a click and door slowly opens with a dismal squeaking \n");
                  return 1; }
           else {
	          write("Try typing 'use <key> in <door>' \n");
	          write("Of course only if you've the right key \n");
                  return 1;
	        }
}


yellow_door(){
	     if (porta2==1) {
	            write ("Yellow door is locked \n");
                    return 1;}
	   }

 
black_door(){
	     if (porta3==1) {
	            write ("Black door is locked \n");
                    return 1;}
	   }

 			 

red_door(){
	     if (porta1==1) {
	          write("Red door is locked \n");
	          return 1;}
	}
