inherit "obj/monster";
reset(arg){
    object ob1,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A bear in hybernation");
    set_long("A enormous angry bear. He hates when someone wake up him!.\n");
    set_name("bear");
    set_level(20);
    set_hp(600);
    set_al(-300);
    set_wc(30);
    set_ac(22);
    set_aggressive(1);
    ob1=clone_object("/players/cassandra/tempio/oggetti/fur.c");
    move_object(ob1,this_object());
    gold=clone_object("obj/money");
    gold->set_money(3500);
    move_object(gold,this_object());
    command("wear fur",this_object());
    }
