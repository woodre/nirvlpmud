inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="Medusa's Palace";
  long_desc ="You are walking between lights and shadows.. None can know who or what \n"+
             "is hidding by darkness, the only thing you're sure is that you wouldn't \n"+
             "stay in this place for a long time. \n";

 dest_dir = ({ 
    "players/cassandra/olimpo/hell/labirynth4", "west",
    "players/cassandra/olimpo/hell/labirynth2", "south",
    "players/cassandra/olimpo/hell/labirynth5","north",
    "players/cassandra/olimpo/hell/labirynth3","east"});
 obj=clone_object("players/cassandra/monsters/beggar.c");
 move_object(obj,this_object());
 set_light(1);

}

