inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("keys");
        set_short("A bunch of keys");
        set_long("These are all keys of hotel rooms.. but you're not interested in stealing (at least i hope). \n");
        set_weight(1);
        set_value(35);
}

