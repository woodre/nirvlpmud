inherit "room/room"; 

reset(arg) {
  object obj,ob1,ob2,ob3;
  short_desc="At the hell";
  long_desc="You enter in a gloomy hole, bad lightened only by smoky and pale torch\n"+
	    "This is the residence of.. \n";
  dest_dir = ({"players/cassandra/olimpo/hell/hell2.c","back"});
   set_light(1);
   obj=clone_object("players/cassandra/monsters/pluto.c");
   move_object(obj,this_object());
  }

