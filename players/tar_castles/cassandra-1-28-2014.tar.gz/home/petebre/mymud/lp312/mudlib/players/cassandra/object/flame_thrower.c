inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("flame_thrower");
        set_short("Flame_thrower") ;
        set_long("This flame_thrower is a very powerful weapon which multiplies by ten the energy\n");
        set_weight(2) ;
        set_value(1000);
        set_class(18) ;
        set_hit_func(this_object());
}

weapon_hit(attacker)
{
 if (random (10) < 3) return 0;
 write("You press trigger on flame_thrower and your opponent is surrounded by fire \n");
 say (this_player()->query_name()+" surround his opponent in flames\n");
 add_spell_point(this_player(),-2);
 return 20;
}

