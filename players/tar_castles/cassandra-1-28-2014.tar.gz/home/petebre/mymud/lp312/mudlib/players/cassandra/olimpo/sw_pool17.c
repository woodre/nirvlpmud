inherit "room/room"; 
reset(arg) {
  object ob1,ob2,k;
  int i; 
  short_desc="Olimpo Hotel";
  long_desc="You leave swimming pool and start walking on a path leading to garages \n"+
	    "even if you can't imagine what kind of locomotion means can be used here\n"+
	    "But usually garages aren't near swimming pool too \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool12.c","north",
       "players/cassandra/olimpo/sw_pool18.c","south",
       });
  set_light(1);
  }

