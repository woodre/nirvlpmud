inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Gardener of Castle");
    set_long("A old man who passed all his life cutting hedges and taking care of flowers.\n");  
    set_name("gardener");
    set_alias("man");
    set_gender("male");
    set_level(16);
    set_hp(410);
    set_al(150);
    set_wc(22);
    set_ac(13);
    set_race("human");
    set_chat_chance(25);
    load_chat("Gardener says: 'You little bastard, go away from my creatures'\n");
    load_chat("Gardener gives some water to flowers\n");
    load_chat("Gardener gives manure to plants \n");
    ob1=clone_object("/players/cassandra/tempio/oggetti/secateurs.c");
    move_object(ob1,this_object());
    ob2=clone_object("/players/cassandra/tempio/oggetti/overall.c");
    move_object(ob2,this_object());
    command("wield secateurs",this_object());
    command("wear overall",this_object());
}
