inherit "room/room"; 
reset(arg) {
  short_desc="Path to Mountain";
  long_desc ="The temperature is always more cold, there is neither vegetable life \n"+
             "nor animal one. You couldn't image who could live here. \n"+
             "and probably you couldn't survive without the right equipment \n"+
             "There's a black opening to east \n";
              dest_dir = ({ 
       "players/cassandra/tempio/mountain5.c", "down",
       "players/cassandra/closed/maze/maze1.c","east"});
  set_light(1);}

