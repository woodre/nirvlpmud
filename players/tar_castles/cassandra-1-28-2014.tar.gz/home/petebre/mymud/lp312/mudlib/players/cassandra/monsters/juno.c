inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Juno");
    set_long("She's the wife of hotel director, so she takes care of kitchen direction;\n"+
	     "Looking at her you think that she's particullary interested in tasting foods. \n");
    set_name("juno");
    set_gender("female");
    set_level(12);
    set_hp(180);
    set_al(-100);
    set_wc(16);
    set_ac(9);
    set_chat_chance(15);
    load_chat("Juno shouts: 'Hurry up! Hurry up! It's late! Very late!' \n");
    ob1=clone_object("/players/cassandra/object/apron.c");
    move_object(ob1,this_object());
    command("wear apron",this_object());
}
