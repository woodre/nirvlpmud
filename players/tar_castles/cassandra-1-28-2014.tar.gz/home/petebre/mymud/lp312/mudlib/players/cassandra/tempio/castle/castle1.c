inherit "room/room"; 
reset(arg) {
  object obj;
  int i;
  short_desc="Cassiophea's Castle";
  long_desc ="You're walking on a avenue across beautiful garden full of perfumed\n "+
             "flowers and exotical plantes. Surely who live here have to love beauty more \n"+
             "than any other thing.\n"; 
  dest_dir = ({ 
       "players/cassandra/tempio/nroom7.c", "east",
       "players/cassandra/tempio/castle/castle2.c","north",
       "players/cassandra/tempio/castle/castle3.c","west"});
  for (i=0;i<5;i++){
  obj=clone_object("players/cassandra/tempio/monsters/flower.c");
  move_object(obj,this_object());}
  set_light(1);
}
