inherit "obj/treasure";
reset(arg) {
        if(arg) return;
        set_id("Ball");
        set_short("A baseball ball");
        set_long("A ball came here from some very powerful human player throw. You can play with it too.\n");
         set_weight(1);
         set_value(100);

}
init(){
	add_action("play","play");
      }

play(str){
	write("You start making ball bounce.. boing... boing... boing... \n");
	write("Don't you feel a little stupid? \n");
	return(1);
}


