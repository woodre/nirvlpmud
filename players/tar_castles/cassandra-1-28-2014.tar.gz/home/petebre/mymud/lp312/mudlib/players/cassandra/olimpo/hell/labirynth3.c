inherit "room/room"; 
reset(arg) {
  set_light(1);
  short_desc="Medusa's Palace";
   long_desc ="You are walking between lights and shadows.. None can know who or what \n"+
             "is hidding by darkness, the only thing you're sure is that you wouldn't \n"+
             "stay in this place for a long time. \n";

   dest_dir = ({ 
    "players/cassandra/olimpo/hell/labirynth4", "north",
    "players/cassandra/olimpo/hell/labirynth1", "east",
    "players/cassandra/olimpo/hell/labirynth6","west",
    "players/cassandra/olimpo/hell/labirynth2","south"});
}

