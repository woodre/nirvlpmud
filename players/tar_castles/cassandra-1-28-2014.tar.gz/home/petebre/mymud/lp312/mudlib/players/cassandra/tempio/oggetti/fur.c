inherit "obj/armor";
reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("fur");
        set_alias("pelliccia");
        set_short("Brown bear fur");
        set_long("This is a warm and comforting brown fur \n");            
        set_weight(2);
        set_value(1000);
        set_type("armor");
        set_ac(1) ;
}
