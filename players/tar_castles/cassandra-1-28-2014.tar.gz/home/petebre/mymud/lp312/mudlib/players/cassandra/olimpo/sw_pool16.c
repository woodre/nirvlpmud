inherit "room/room"; 
   object ob1,ob2,ob3;
   int i;
reset(arg) {
  short_desc="Solarium";
  long_desc="It's very hot here: this place has been studied for people which only \n"+
            "wants sunbathing; It's made by a cement circular platform coloured in yellow \n"+
            "A sign \n";  
  dest_dir = ({ 
            "players/cassandra/olimpo/sw_pool12.c","west"});
  set_light(1);
  ob1=clone_object("players/cassandra/monsters/venus.c");
  move_object(ob1,this_object());
 }

init(){
	::init();
	add_action("read","read");
        add_action("take","take");
        add_action("my_west","west");
	}

read(str){
	  if (str=="sign") {
	       write("On a metal plate there's written in gold: \n");
               write("Next friday, since 14 to 18, there will not be \n");
               write("sun rays for Apollo very important appointment \n");
               return 1;
           }
           else return 1;
          }


take(str){
	  if (str=="off swimming trunks") {
		write("Profitting by a Venus carelessness moment you take off \n");
	        write("her swimming trunks.. she notice what are you doing and start \n");
	        write("insulting you and calling for help. \n");
 if (ob3=present("trunks",ob1)) {
	                move_object(ob3,this_player());}
                write("After any seconds a powerful and very angry Apollo appears! \n");
      	        ob2=clone_object("players/cassandra/monsters/apollo.c");
                move_object(ob2,this_object());
                return 1;
	}
}

my_west(){
	   if (present("apollo")){
	       write("You're dazzled by sun-rays and you can't find right direction \n");
	       write("You've quite to kill Apollo, i'm afraid! \n");
	       write("Bad thing to bother woman, don't you think? \n");
	       return 1;
	   }
	   else{
	       move_object(this_player(),"players/cassandra/olimpo/sw_pool12.c");
	         write("You come back to other room \n");
	         return 1;
	        }
}
