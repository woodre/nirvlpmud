inherit "room/room"; 
reset(arg) {
  object obj,ob1;
  int i;
  short_desc="Cassiophea's Castle";
  long_desc ="This is the main room of Cassiophea Castle. It's full of people, and everybody \n"+
             "is listening to Queen Cassiophea. There's a large statue dedicated to Venus \n"+
             "at the other side of room \n";
  dest_dir = ({"players/cassandra/tempio/castle/castle2.c","west"});
  obj=clone_object("players/cassandra/tempio/monsters/cassiophea.c");
  move_object(obj,this_object());
   set_light(1);
}

init(){
	::init();
	add_action("pass","ask");
       }

pass(str){
	if (str!="cassiophea") {
            return 1;}
        else {
        if (present("queen",environment(this_player()))){
		write("Cassiophea says : ' Oh my poor doughter.. so beautiful, so sweet.. '\n");
		write("Cassiophea says : 'I said she was more beautiful than sea mermaid and '\n");
        	write("Cassiophea says : 'now Neptunus wants to sacrifice her to Kraken '\n");
		write("Cassiophea says : 'Everyone says than Kraken is unbeatable, but i can't '\n");
		write("Cassiophea says : 'believe i have to give up to my Andromeda.' \n");
        	write("Cassiophea says : 'Perhaps the old three women on Fate Mountains can '\n");
		write("Cassiophea says : 'have some ideas, but look out! They eat human meat '\n");
		write("Cassiophea says : 'Please try, save my doughter and my heart! '\n");
        	return 1;}
          else {
		write("Queen Cassiophea is no more here \n");
	  	return 1;
		}
	}
}
         
