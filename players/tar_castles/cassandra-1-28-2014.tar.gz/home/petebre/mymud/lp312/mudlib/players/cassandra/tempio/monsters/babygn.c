inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A baby gnome");
    set_long("A child of Rainbow Gnome and his wife, wearing a multicolor hat.\n");  
    set_name("gnome");
    set_alias("baby");
    set_level(8);
    set_hp(100);
    set_al(40);
    set_wc(10);
    set_ac(10);
    gold=clone_object("obj/money"); 
    gold->set_money(150+random(100));
    move_object(gold,this_object()); 
}
