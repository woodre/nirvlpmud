inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="At the hell";
  long_desc="You're on a desolate beach. The temperature is rather high so nothing grows \n"+
            "on this isle. You can see a cave to north and a small path to east.\n"+
            "If you are quite afraid you can come back church from here.\n";
  dest_dir = ({ "players/cassandra/olimpo/hell/hell1.c", "north",
       "players/cassandra/olimpo/hell/path.c","east",
       "room/church","church"});
   set_light(1);
}


