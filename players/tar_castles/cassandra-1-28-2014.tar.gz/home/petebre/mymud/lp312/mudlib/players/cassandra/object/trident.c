inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("trident");
        set_short("A Coral trident") ;
set_long("A powerful weapon which 5 points. If you have always thought \n"+
                 "that coral was not good for weapon, now you'll change idea \n");
        set_weight(3) ;
        set_value(1000);
        set_class(18) ;
        set_hit_func(this_object());
}

