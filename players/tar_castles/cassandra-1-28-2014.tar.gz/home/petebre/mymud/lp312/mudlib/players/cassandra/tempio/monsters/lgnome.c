inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("The rainbow lady gnome");
    set_long("A pretty lady gnome which is clearing a gold pot with a rag\n");  
    set_name("gnome");
    set_alias("lady");
    set_gender("female");
    set_level(14);
    set_hp(180);
    set_al(-80);
    set_wc(15);
    set_ac(11);
    ob1=clone_object("/players/cassandra/tempio/oggetti/pot2.c");
    move_object(ob1,this_object());
    gold=clone_object("obj/money"); 
    gold->set_money(1200);
    move_object(gold,this_object()); 
}
