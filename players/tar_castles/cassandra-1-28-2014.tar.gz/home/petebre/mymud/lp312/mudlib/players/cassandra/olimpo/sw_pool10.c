inherit "room/room"; 
reset(arg) {
  object ob1,ob2,k;
  int i; 
  short_desc="Olimpo Hotel Swimming Pool";
  long_desc="You're on the right edge of swimming pool. You could go further if \n"+
            "there shouldn't be .. \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool8.c","west",
       "players/cassandra/olimpo/sw_pool12.c","south",
       "players/cassandra/olimpo/sw_pool7.c","northwest"});
  set_light(1);
  ob1=clone_object("players/cassandra/monsters/boy.c");
     move_object(ob1,this_object());
  ob2=clone_object("players/cassandra/monsters/girl.c");
     move_object(ob2,this_object());
}

init(){
  ::init();
  add_action("my_south","south");
  }

my_south(){
          if (present ("boy") || present("girl")) {
            write("Someone is dozing at sun, i hope you wouldn't pass over him \n");
            return 1;
    }
}
