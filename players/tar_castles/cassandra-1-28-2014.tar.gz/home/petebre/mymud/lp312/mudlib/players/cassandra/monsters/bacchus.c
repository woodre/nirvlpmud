inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Bacchus the god of wine");
    set_long("May this drunk and swinging figure be a god? \n"+
	     "Yes, it's Bacchus, obviously god of wine \n");
    set_name("bacchus");
    set_gender("male");
    set_level(16);
    set_hp(400);
    set_al(-200);
    set_wc(22);
    set_ac(13);
    set_chat_chance(10);
    load_chat("Hic.. will iou waaant .. hic.. aaanything to drinkkkk ?\n");
    set_chance(5);
    set_spell_dam(0);
    set_spell_mess1("Bacchus open his mouth to speak and you're hit by alcool smell. You feel a little more drunk\n");
    call_other(this_player(), "drink_alcohol", 1);
    ob1=clone_object("/players/cassandra/object/barrel.c");
    move_object(ob1,this_object());
}
