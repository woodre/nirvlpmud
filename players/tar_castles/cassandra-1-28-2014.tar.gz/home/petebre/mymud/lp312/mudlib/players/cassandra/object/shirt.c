inherit "obj/armor";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("shirt") ;
        set_short("A t-shirt") ;
        set_long("A small t-shirt with the inscription 'i love Apollo and his sons' \n");
        set_weight(1) ;
        set_value(200);
        set_type("armor") ;
        set_ac(1) ;
}
