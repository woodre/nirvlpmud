inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Neptune, the king of seas");
    set_long("A muscled giant wearing a crown and wielding a platinum trident. \n"+
             "He's looking at a sea map chosing where to send next hurricane \n");
    set_name("neptune");
    set_level(21);
    set_hp(600);
    set_al(-300);
    set_wc(31);
    set_ac(20);
    ob1=clone_object("players/cassandra/object/ntrident.c");
    move_object(ob1,this_object());
    command("wield trident",this_object());
    ob2=clone_object("players/cassandra/object/pearls2.c");
    move_object(ob2,this_object());
}
