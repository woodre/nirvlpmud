inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A stoned general");
    set_long("A greek general imprisoned in stone. He's moving leading by a magical force\n"); 
    set_name("general");
    set_level(17);
    set_hp(400);
    set_al(100);
    set_wc(22);
    set_ac(15);
    ob1=clone_object("/players/cassandra/object/sboots.c");
    move_object(ob1,this_object());
    ob2=clone_object("/players/cassandra/object/s-gun.c");
    move_object(ob2,this_object());
    gold=clone_object("obj/money");
    gold->set_money(250);
    move_object(gold,this_object());
    command("wear boots",this_object());
    command("wield gun",this_object());
}
