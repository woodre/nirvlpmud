inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="House of Gnomes";
  long_desc="You enter in gnomes's house passage. Hundrens of picture about them \n"+
            "at the walls. You hear someone crying to east and there's a door to west\n";
  dest_dir = ({"players/cassandra/tempio/gn_home1.c", "south",
       "players/cassandra/tempio/gn_home4.c","east"});
set_light(1);
}

init(){
        ::init();
        add_action("open","open");
      }
open(str) {
    if (!str) {
        write("What do you want to open?\n");
        return 1;}
    if (str=="door"){
        write("You press the handle and the door opens\n");
        move_object(this_player(), "players/cassandra/tempio/gn_home3.c");    
        return 1;
     }
return 0;
}
        

