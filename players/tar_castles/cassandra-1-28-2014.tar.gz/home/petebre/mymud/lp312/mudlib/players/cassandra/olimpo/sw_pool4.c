inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="Olimpo Hotel Swimming Pool";
  long_desc="Finally you escape to open air; in front of you a magnificious swimming-pool \n"+
	    "extends in all its beauty. Hundreds of deck-chairs everywhere \n"+
            "There's a hedge to north to guarantee hotel guests calm.. oh strange, \n"+
            "there's a little hole in it \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/sw_pool5.c","east",
       "players/cassandra/olimpo/sw_pool1.c","west",
       "players/cassandra/olimpo/sw_pool6.c","south",
       "players/cassandra/olimpo/swm.c","hole"});
  set_light(1);
 }
