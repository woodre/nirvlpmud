inherit "room/room"; 
int barca,num;
object obj,ob1,newobj;
object env;

reset(arg) {
  short_desc="On the rive of the Stigs";
  long_desc="You are walking on a wobbling landing stage in the middle of river; Everything \n"+
	    "is gloomy and vague, so you can't see the other river bank. Perhaps sign and horn can help you\n";
dest_dir = ({ "players/cassandra/olimpo/stigs3.c", "west"});
	  set_light(1);
   barca=0;	
   ob1=clone_object("/players/cassandra/object/horn.c");
   move_object(ob1,this_object());

}

init(){
        ::init();
	add_action("read","read");
	add_action("pass","look");
	add_action("play","play");
        add_action("embark","embark");
       }

pass(str) {
        if(str=="at sign")  {
                command("read sign",this_player());
                return 1;
                }
        }

read(str) {
     if(str !="sign")
         return 0;
     write("       Damned, welcome on the river of the Stigs.\n"); 
     write("       You're very near to your eternal pain abode\n");
     write("       To cross the cursed water play the horn,\n");
     write("       to call the infernal ferry-man\n");
     return 1;
}

embark(str){
       if (!str) {
        write("Where do you want to embark?\n");
        return 1;}
       else
       {  
           if (barca==0) {
	       write("The ferry is not here \n");
	       return 1;
	    }
            else { 
	       write(this_player()->query_name() + " embarks on ferry.\n"); 
               move_object(this_player(),"/players/cassandra/olimpo/ferry.c");
               return 1;}
        }
}
     



messages(){
	   if (num==0) {
                barca=1; 
		return 0;
	    }
           if (num==5) {
                tell_room(env,"You get horn from near bolt and blow into it. A deep song escapes \n");
		tell_room(env,"from instrument\n");}
	   if (num==4) {
	        tell_room(env,"You think and see something far in the middle of fog ... \n");}
	   if (num==3) {
	        tell_room(env,"A black outline sketches .. \n");}
	   if (num==2) {
		tell_room(env,"It's a ferry and a hooded figure is leading it.\n");
                tell_room(env,"You don't understand how it is able to move without rows and sails\n");}
	   if (num==1) {
		tell_room(env,"The ferry stops near landing stage, now you can embark.\n");}
	    --num;
	    call_out("messages",5);
}
	     
play(str){
     if (barca==1) 
 	{write("Ferry is already here!\n");
         return 1;}
      else {
            if (str!="horn")
         	  return 0;
            if (present("corno",environment(this_player())) || present("corno",this_player())) 
            {      
          	write(this_player()->query_name() + " plays the horn.\n"); 
	 	env=environment(this_player());
         	newobj=this_object();
         	obj=this_player();
         	num=5;
         	call_out("messages",5);
         	return 1;}
     	     else {write("No horn here\n.");
           	return 1;}
       }
}
		

