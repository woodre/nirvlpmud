inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Caron the infernal ferry-man");
    set_long("All you can see is a hooded figure and a skeletal hand stretched towards you\n"); 
    set_name("caron");
    set_level(18);
    set_hp(500);
    set_al(-300);
    set_wc(20);
    set_ac(30);
    gold=clone_object("obj/money"); 
    gold->set_money(4000+random(1000));
    move_object(gold,this_object());
}

