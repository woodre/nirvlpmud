inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("claws");
        set_short("Cat's claws") ;
        set_long("The better iron claws you ever seen.\n") ;
        set_weight(3) ;
        set_value(1000);
        set_class(12) ;
}
