inherit "obj/armor";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("helmet") ;
        set_alias("helmet");
        set_short("Helmet of Sun") ;
        set_long("This is the powerful Helmet of Sun. It's made by a strange material \n"+
                 "which reflect the whole Sun Light.\n");
        set_weight(3) ;
        set_value(2500);
        set_type("helmet") ;
        set_ac(3) ;
        set_arm_light(10);
}
