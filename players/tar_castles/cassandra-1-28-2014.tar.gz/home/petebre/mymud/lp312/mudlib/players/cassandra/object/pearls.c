inherit "obj/armor";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("pearls") ;
        set_short("A necklace of pearls") ;
        set_long("You have never seen so pure; surely their value is rather high  \n");
        set_weight(1) ;
        set_value(875);
        set_type("armor") ;
        set_ac(1) ;
}
