inherit "room/room"; 
reset(arg) {
  set_light(1);
  short_desc="On the rainbow";
  long_desc="You pass the middle of rainbow and arrive at the descenting part: the \n"+
            "path is very slippery so you start going down. Only with a great effort \n"+
            "you can go up. \n";
  dest_dir = ({ 
       "players/cassandra/tempio/rainbow4", "up",
       "players/cassandra/tempio/rainbow6","down"});
      
}
