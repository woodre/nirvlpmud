inherit "obj/treasure";
int fiammiferi,luce;
reset(arg) {
        if(arg) return;
        set_id("matches");
set_alias("box");
        set_short("A box full of matches");
               set_weight(1);
        set_value(50);
        fiammiferi=50;
        set_long("A normal box of matching reporting Olimpo Hotel publicity \n"+
	         "It contains a lot of matches \n");

	luce=2;
}

init(){
	    add_action("light"); add_verb("light");
}

light(str) {
	 object ob;
	if ((str=="match") && (fiammiferi>0)){
	     write("You rub match against box and you got a fine light \n");
	     fiammiferi-=1;
             set_light(1);
             set_heart_beat(1);
	     return 1;}
}

heart_beat() {
	luce -=1;
	if (luce>0) return;
	say("The match extinguishes and you goes dark \n");
        set_heart_beat(0);
	set_light(-1);
	}
