inherit "room/room"; 
reset(arg) {
  object ob1,ob2,ob3;
  int i; 
  short_desc="O.H. Kitchen";
  long_desc="This is the really kitchen of hotel: you don't understand how could  \n"+
	    "a so small kitchen prepares dinners for all guests, but probably there's \n"+
	    "some magical secrets. \n";
  dest_dir = ({ 
       "players/cassandra/olimpo/odown7.c","south",
       "players/cassandra/olimpo/odown3.c","north"});
  set_light(1);
  for (i=0;i<3;i++){
  	ob1=clone_object("/players/cassandra/monsters/cook1.c");
        move_object(ob1,this_object());
  }
 for (i=0;i<3;i++){
  	ob2=clone_object("/players/cassandra/monsters/cook2.c");
        move_object(ob2,this_object());
  }
 for (i=0;i<3;i++){
  	ob3=clone_object("/players/cassandra/monsters/cook3.c");
        move_object(ob3,this_object());
  }

 }

