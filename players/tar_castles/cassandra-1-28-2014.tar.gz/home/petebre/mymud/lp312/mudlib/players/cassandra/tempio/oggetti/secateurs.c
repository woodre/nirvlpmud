inherit "obj/weapon";

reset(arg){
   if(arg) return;
   ::reset(arg);
        set_name("secateurs");
        set_short("A pair of secateurs") ;
        set_long("A pair of secateurs very sharpened, ideal for working in garden \n");
        set_weight(1);
        set_value(840);
        set_class(14);
        set_hit_func(this_object());
}

weapon_hit(attacker)
{
 if (random (10) > 3) return 0;
 write("You cut your opponent's hair\n");
 say (this_player()->query_name()+" cuts his opponent's hair\n");
 return random (14);
}

