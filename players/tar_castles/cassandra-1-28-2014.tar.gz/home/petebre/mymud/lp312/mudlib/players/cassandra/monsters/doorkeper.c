inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A huge and distingushed doorkeper");
    set_long("There should be someome opening door to Gods, or not?\n"+
             "Of course he is ignoring you. \n");
    set_name("doorkeper");
    set_gender("male");
    set_level(13);
    set_hp(200);
    set_al(50);
    set_wc(13);
    set_ac(13);
    ob1=clone_object("players/cassandra/tempio/oggetti/keys.c");
    move_object(ob1,this_object());
}
