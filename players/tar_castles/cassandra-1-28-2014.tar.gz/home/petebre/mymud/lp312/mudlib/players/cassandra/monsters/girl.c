inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("A sexy girl");
    set_long("God are used to enjoy themselves using the same methods human do,\n"+
             "at least it's what you could think looking this girl with a boy :P \n");  
    set_name("girl");
    set_level(9);
    set_hp(135);
    set_al(-80);
    set_wc(14);
    set_ac(6);
    ob1=clone_object("/players/cassandra/object/shirt.c");
    move_object(ob1,this_object());
    command("wear shirt",this_object());
}
