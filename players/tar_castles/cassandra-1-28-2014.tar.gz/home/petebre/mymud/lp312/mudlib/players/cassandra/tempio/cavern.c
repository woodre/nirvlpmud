inherit "room/room"; 
reset(arg) {
  object obj;
  short_desc="A dark cavern";
  long_desc ="You enter in a dark large cavern. The temperature is less cold than out \n"+
             "and this is because there's 'someone' sleeping. A small hole to east.\n";
 dest_dir = ({ 
       "players/cassandra/tempio/mountain4.c","north",
       "players/cassandra/tempio/cavern2.c","east"});
 obj=clone_object("players/cassandra/tempio/monsters/bear.c");
 move_object(obj,this_object());
set_light(0);}

init(){
	::init();
	add_action("my_north", "north");
 	add_action("my_east", "east");

}

my_east (str)
{
    if (present ("bear")) {
            write("Bear blocks your way \n");
            return 1;
    }
}

 


my_north (str)
{
    if (present ("bear")) {
            write("Bear blocks your way \n");
            return 1;
    }
}


