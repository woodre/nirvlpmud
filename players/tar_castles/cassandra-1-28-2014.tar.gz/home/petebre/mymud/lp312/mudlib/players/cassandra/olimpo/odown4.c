inherit "room/room"; 
reset(arg) {
  object ob1,ob2;
  int i; 
  short_desc="O.H. Kitchen";
  long_desc="You arrive in the hottest part of kitchen; surely this place is not used \n"+
	    "to cook but as a forge to create weapon \n"; 
  dest_dir = ({ 
       "players/cassandra/olimpo/odown3.c","east"});
  set_light(1);
  ob1=clone_object("/players/cassandra/monsters/vulcan.c");
  move_object(ob1,this_object());
 }
