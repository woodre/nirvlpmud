inherit "obj/monster";
reset(arg){
    object ob1,ob2,gold;
    ::reset(arg);
    if (arg) return;
    set_short("Baby-sitter");
    set_long("Unleasched children baby sitter. She's trying to calm them before using \n"+
             "too strong systems.\n");
    set_name("baby-sitter");
    set_gender("female");
    set_level(15);
    set_hp(225);
    set_al(-150);
    set_wc(23);
    set_ac(10);
    set_race("human");
    set_chat_chance(25);
    load_chat("Baby-sitter says: 'Please children.. be quiet!! \n");
    set_chance(10);
    set_spell_dam(random(20)+15);
    set_spell_mess1("She can use strong systems with you and hit you with her whip \n");
    ob1=clone_object("players/cassandra/object/whip.c");
    move_object(ob1,this_object());
    command("wield whip",this_object());
}
