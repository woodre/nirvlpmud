inherit "obj/drink";
reset(arg){
    ::reset(arg);
    if (arg) return;
    set_value("elisir#Flowers ekisir#You drink a flower elisir#250#200#0");
}
