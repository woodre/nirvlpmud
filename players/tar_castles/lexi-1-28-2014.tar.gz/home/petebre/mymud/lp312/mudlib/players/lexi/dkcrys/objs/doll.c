#include "/players/lexi/ansi.h"
inherit "/obj/treasure.c";

reset(arg){
  if(arg) return;
  set_id("doll");
  set_alias("rag doll");
  set_short("A doll");
set_long(
"A tiny rag doll made of tattered old cloth. It doesn't seem like\n"+
"much to you, but to a small child it's a precious treasure.\n");
  set_value(75);
  set_weight(3);
}
