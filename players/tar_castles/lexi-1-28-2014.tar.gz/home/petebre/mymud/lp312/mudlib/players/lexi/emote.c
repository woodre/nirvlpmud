#include "/bin/gender.c"
#include "/bin/ghost.c"

#define tp this_player()
#define tpq this_player()->query_level()
#define tpn this_player()->query_name()
#define tpp posess(tp)
#define tpz pro(tp)
#define cpn capitalize(str)
#define cpt capitalize(tpn)

int menace(string str) {
  object who;
  if(ghost() || !str){
	write("You stretch your wings and hiss menacingly.\n");
	say(tpn+" stretches "+tpp+" wings and hisses menacingly.\n",tp);
	return 1;}
  else{
  who = present(str, environment(tp));
    if(who && living(who)) {
    if(who == tp) 
      return 0;
	write("You stretch your wings and hiss menacingly at "+cpn+".\n");
	say(tpn+" stretches "+tpp+" wings and hisses menacingly at "+cpn+".\n", who);
	tell_object(who, tpn+" stretches "+tpp+" wings and hisses menacingly at you.\n");}
  else {
    who = find_player(str);
    if(!who || who == tp || in_editor(who) || who->query_invis() >= tpq)
      return 0;
    if(who->query_tellblock()) { 
      write(cpn+" is blocking emotes.\n");
      return 1;}
	write("From afar, you stretch your wings and hiss menacingly at "+cpn+".\n");
    tell_object(who, "From afar, "+tpn+" streches "+tpp+" wings and hisses at you.\n");}
  return 1;
}}