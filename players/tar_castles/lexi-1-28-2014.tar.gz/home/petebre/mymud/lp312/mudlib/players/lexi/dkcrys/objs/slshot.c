#include "/players/lexi/ansi.h"
inherit "obj/weapon.c";

reset(arg) {
  ::reset(arg);
  if (arg) return;

  set_name("slingshot");
  set_alias("slingshot");
  set_short("A small slingshot");
  set_long(
"A small slingshot made out of the branch of a tiny tree. It\n"+
"doesn't look like it could do much damage.\n");
  set_type("bow");
  set_class(13);
  set_weight(2);
  set_value(120);
}
