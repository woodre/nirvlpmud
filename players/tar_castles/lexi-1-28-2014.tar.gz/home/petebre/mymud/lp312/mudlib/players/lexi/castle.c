#define NAME "Lexi"
#define DEST "room/plane12"
#include <ansi.h>
/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "store"; }

short() {
    return "The Screening Room Videos";
}

long() {
    write("This is a newly constructed video store.\n");
    write("Although the outside seems well built the sounds\n")+
    write("of construction echo through the walls. The doors\n")+
    write("are locked. A large sign hangs in one of the windows:\n");
    write("     "+HIR+"          Comming Soon!!"+NORM+"\n");
}

init() {
    add_action("enter"); add_verb("enter");
}

enter(str) {
    if (!id(str))
	return 0;
    write("The store is closed. Please check back soon!\n");
    return 1;
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
}
is_castle(){return 1;}
