#include "/players/lexi/ansi.h"
#define TP this_player()
inherit "room/room";

reset(arg) {
  if(arg) return;


short_desc = "A dirt path";
long_desc =
  "    A short dirt path stretches out toward the north. Trees and \n"+
  "lush green foliage line either side of the walkway. In the distance\n"+
  "ahead a small village can be seen peeking through the trees and brush.\n";
  


set_light(1);

items = ({
  "path","A well worn path through a forest. Maybe it leads to somewhere.",
  "trees","Large trees with low hanging branches.",
  "foliage","Tall shoots of grass and low laying flowers cover the ground.",
  "village","Off in the distance a small Podling village can be seen.",
  "walkway","A well worn path through a forest. Maybe it leads to somewhere.",
 });

dest_dir = ({
  "/players/lexi/dkcrys/rooms/vil2.c","north",
});
}
