/*Mishtar's Wiztell*/

#include "/obj/ansi.h"
inherit "obj/treasure";

query_auto_load() { return "players/lexi/items/lexitell.c:";}

reset(arg){
	if(arg) return;
	set_id("heart");
 	set_alias("teller");
	set_long("This is a small, "+NORM+RED+"heart"+NORM+" shaped tattoo given to you by Lexi.\n"+
	"You can use this tattoo to speak with Lexi, if she is present.\n"+
	"Use 'lt' to send a tell or 'le' to send an emote.\n");
	set_weight(0);
	set_value(0);
	}
extra_look(){
	if(environment() == this_player()) {
		write("You have a small "+RED+"heart"+NORM+" shaped tattoo on your left shoulder blade.\n");}
	else {
		write(environment()->query_name()+" has a small "+RED+"heart"+NORM+" shaped tattoo on their left shoulder blade.\n");}
	}
drop(){ return 1; }

init(){
	::init();
	add_action("cmd_tell","lt");
	add_action("cmd_emote","le");
	}

cmd_tell(str){
	object ltell;
	ltell=find_player("lexi");
	if(!ltell){
		notify_fail("Lexi has bounced off the mud. She'll be back later.\n");
		return 0;
	}

	if(in_editor(ltell)){
		notify_fail("Lexi is busy right now, try back later.\n");
	}

	write(""+HIW+"~"+NORM+CYN+"<"+HIC+"*"+NORM+CYN+">"+HIW+"~ "+NORM+MAG+" You tell Lexi"+HIW+": "+HIC+str+NORM+"\n");
	tell_object(ltell,""+HIW+"~"+NORM+CYN+"<"+HIC+"*"+NORM+CYN+">"+HIW+"~ "+NORM+MAG+this_player()->query_name()+HIW+" : "+HIC+str+NORM+"\n");
	ltell->add_tellhistory(""+HIW+"~"+NORM+CYN+"<"+HIC+"*"+NORM+CYN+">"+HIW+"~"+NORM+MAG+this_player()->query_name()+HIW+" : "+HIC+str+NORM+"\n");
	return 1;
	}


cmd_emote(str){
	object ltelle;
	ltelle=find_player("lexi");
	if(!ltelle){
		notify_fail("Lexi has bounced off the mud. She'll be back later.\n");
		return 0;
	}

	if(in_editor(ltelle)){
		notify_fail("Lexi is busy right now, try back later.\n");
	}

	write(""+HIW+"~"+NORM+CYN+"<"+HIC+"*"+NORM+CYN+">"+HIW+"~"+NORM+MAG+" You emote to Lexi"+HIW+": "+HIC+this_player()->query_name()+" "+str+NORM+"\n");
	tell_object(ltelle,""+HIW+"~"+NORM+CYN+"<"+HIC+"*"+NORM+CYN+">"+HIW+"~ "+NORM+MAG+this_player()->query_name()+" "+str+NORM+"\n");
	return 1;
	}
