#include "/players/lexi/ansi.h"
inherit "/obj/monster.c";
 
reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("Child"); 
  set_alias("child");
  set_short("A Podling Child");
  set_long("A bratty little boy podling. He seems a bit confident for being\n"+
           "only a child.\n");
set_race("podling");
  set_gender("male");
  set_level(3);
  set_wc(8);
  set_ac(40);
  set_hp(30);
  set_ep(1000);
  add_money(0);
  set_aggressive(0);
set_dead_ob(this_object());
  set_al(200);
  load_chat("The child says,'I'm not affraid of no Skeksi...'\n");
  load_chat("The child takes aim with his slingshot.\n");
  set_chat_chance(5);
}
monster_died() {
  move_object(clone_object("/players/lexi/dkcrys/objs/slshot.c"),
      environment(this_object()));
  tell_room(environment(this_object()),
        "The child's dead body falls to the ground.\n");
return 0; }
