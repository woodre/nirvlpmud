#include "/players/lexi/ansi.h"
#define TP this_player()
inherit "room/room";

reset(arg) {
  if(arg) return;


short_desc = "A Small Clearing";
long_desc =
  "    The path fades away opening up into a small clearing that holds\n"+
  "the tiny pod village. Small dome shaped houses are scattered about\n"+
  "dotting the clearing. Everywhere podlings can be seen bustling around,\n"+
  "within and between their houses.\n";
  


set_light(1);

items = ({
  "path","A well worn path through a forest that leads back into the forest.",
  "houses","Doorways, windows, and chimneys have been neatly carved out of giant\n"+ 
         "seed pods and framed in wood.",
  "podlings","Simple peasants who live hidden in the depths of the forest,\n"+ 
           "these people tend all the things that grow.",
  "village","A small Podling village made up of dome shaped houses.",
  });

dest_dir = ({
  "/players/lexi/dkcrys/rooms/vil1.c","south",
  "/players/lexi/dkcrys/rooms/vilcen.c", "north",
  "/players/lexi/dkcrys/rooms/vilhouse1.c", "west",
});
}
