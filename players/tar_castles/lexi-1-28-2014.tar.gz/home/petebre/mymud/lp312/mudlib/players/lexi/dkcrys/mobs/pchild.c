#include "/players/lexi/ansi.h"
inherit "/obj/monster.c";
 
reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("Child"); 
  set_alias("child");
  set_short("A Podling Child");
  set_long("A very small and timid child with large eyes and pudgy cheeks.\n"+
           "It is dressed in tattered clothes and seems to be a bit scared.\n");
set_race("podling");
  set_gender("female");
  set_level(2);
  set_wc(6);
  set_ac(3);
  set_hp(30);
  set_ep(1000);
  add_money(0);
  set_aggressive(0);
set_dead_ob(this_object());
  set_al(200);
  load_chat("The child peers at you with wide eyes.\n");
  load_chat("The child asks, 'Are you a Skeksi?'\n");
  set_chat_chance(5);
}
monster_died() {
  move_object(clone_object("/players/lexi/dkcrys/objs/doll.c"),
      environment(this_object()));
  tell_room(environment(this_object()),
        "The childs dead body falls to the ground.\n");
return 0; }
