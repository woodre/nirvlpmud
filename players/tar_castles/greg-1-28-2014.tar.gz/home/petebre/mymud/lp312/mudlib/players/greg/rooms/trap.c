/*
inherit "room/room";
*/
 
realm() { return "NT"; }
 
short() 
{
	return "Impossible Escape [no exits]";
}
 
long() 
{
   write("This is Greg's torture room, where he can keep\n");
   write("you indefinately! You can see nothing but blackness\n");
   write("Looks like you aren't mudding for a while...\n");
   write("\nThere are NO exits.\n");
}
 
reset(arg) 
{
   if(!arg) {
    set_light(1);
    
}
}
 
init() 
{
   if(this_player()->query_level() < 20)
   {
    add_action("junk_this"); add_xverb("");
   }
}
 
junk_this(str) 
{
  string my_verb;
  my_verb = query_verb();
  if (my_verb == "look") look();
  if (my_verb == "gossip") gossip(str);
  if (my_verb == "shout") shout(str);
  if (my_verb == "risque") nope(str);
  if (my_verb == "junk") nope(str);
  if (my_verb == "equip") nope(str);
  if (my_verb == "tell") tell_it(str);
  if (my_verb == "say") say_it(str);
  if (my_verb == "quit") no_quit();
  
  return 1;
}
 
look() 
{
  this_player()->look();
  return 1;
}
 
gossip(str)
{
  echochan("gossip",capitalize(this_player()->query_name())+" gossips from his holding cell: "+str+"\n");
  return 1;
}  
 
shout(str)
{
  echochan("shout",capitalize(this_player()->query_name())+" shouts from his holding cell: "+str+"\n");
  return 1;
}  
 
nope(str)
{
  write("Why would you want to do that?\n");
  return 1;
}
 
tell_it(str)
{
  object plyr;
  string who, what;
  
  if (!str) 
   {
    write("Tell what?\n"); 
    return 1;
   }
  if(sscanf(str, "%s %s", who, what) == 2)
   {
     plyr = find_living(who);
     if(!plyr)
      {
       write(capitalize(who) + " is not online now.\n");
       return 1;
      }
     if(in_editor(who))
      {
        write("You can't tell "+capitalize(who)+" while they are editing.\n");
        return 1;
      }
     if(this_player()->query_invis() > 20) 
      {
       tell_object(plyr,"Someone tells you: "+what+"\n");
       write("You tell "+capitalize(who)+": "+what+"\n");
       return 1;
      }
     else
      {
      tell_object(plyr,capitalize(this_player()->query_name())+" tells you: "+what+"\n");
       write("You tell "+capitalize(who)+": "+what+"\n");
       return 1;
      }
   }    
}
 
say_it(str)
{
  write("You say: "+str+"\n");
  say(capitalize(this_player()->query_name())+" says: "+str+"\n");
  return 1;
}
 
quit()
{
  write("Why do you want to quit from here?\n");
  return 1;
}
 
leave_jail() {
  write("You have served your time, now get out!\n");
  say(capitalize(this_player()->query_name())+" is released from jail.\n");
  move_object(this_player(),"room/church");
}
