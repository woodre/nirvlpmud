inherit "room/room";
reset(arg) {
	if(arg) return;
set_light(1);
short_desc=("Greg's World");
long_desc=
"You have entered a small, cramped dorm room. It looks very crowded\n"+
"in here. There is a small little desk next to the bed which\n"+
"is surrounded by piles of papers, Lots of computer books are stacked above\n"+
"it and all about the room. There is one set of books that looks\n" +
"brand new. They are seperated in a special glass case.\n"+
" ",
items=
({
"case","This is a gold-rimmed, glass case that looks extremly protective",
"set","You can see the title of the set, 'Complete Knowledge of Everything'\n"+
      "                                   By Greg (The Great One)\n",
});
dest_dir=
({
"room/forest8.c","castle2",
"room/church.c","church",
});
}
