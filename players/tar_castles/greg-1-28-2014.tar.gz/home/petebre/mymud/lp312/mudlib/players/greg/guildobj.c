#define GP "/players/greg/closed/guild/bulk"
id(str) {return str == "orb";}

get() {return 1;}
drop() {return 1;}
short() {return "Staff of the Mage";}
init() {
	add_action("gwho","gwho");
        }

gwho(str) {return GP->gwho(str);}
