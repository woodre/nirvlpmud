com(str,pob,gobj)
{
object ob;
ob=find_player(str);
if (!ob)
	return 0;
write("( "+ob->query_hp()+", "+ob->query_spell_point()+
" )\n");
return 1;
}
