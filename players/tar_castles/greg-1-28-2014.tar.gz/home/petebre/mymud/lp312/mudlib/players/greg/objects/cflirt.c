#include <ansi.h>
#define BULK "/players/greg/objects/fbulk"
#define FLIRT "/players/greg/objects/cflirt.c:"
id(str) {return str == "flirter";}

get() {return 1;}
drop() {return 1;}
short() {return "C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" + WHT +
"F"+GRE+"U"+RED+"L "+BLU+"Flirter"+WHT;
}
init() {
	add_action("cgrin","cgrin");
	add_action("csmile","csmile");
	add_action("chug","chug");
	add_action("ctickle","ctickle");
	add_action("chit","chit");
	add_action("cthwap","cthwap");
	add_action("cpoem1","cpoem1");
	add_action("ckiss","ckiss");
	add_action("cskiss","cskiss");
	add_action("click","click");
	add_action("cstrut","cstrut");
        }
query_auto_load() {return FLIRT;}
cgrin(str) {return BULK->flirtit(str," grinz colorfully ", "",this_player(),1);}
csmile(str) {return BULK->flirtit(str," shows ", " a beautiful smile",this_player(),1);}
chug(str) {return BULK->flirtit(str," gives ", " a big hug",this_player(),2);}
ctickle(str)
{return BULK->flirtit(str," reaches over and starts to tickle ", "",this_player(),2);}
chit(str) {return BULK->flirtit(str," hits ", " HARD",this_player(),2);}
cthwap(str) {return BULK->flirtit(str," thwaps ", " on the head",this_player(),2);}
cpoem1(str) {return BULK->flirtit(str," recites:  Twas long ago when i knew ",
	        " would be mine...",this_player(),2);}
ckiss(str) {return BULK->flirtit(str," leans over and kisses ", "",this_player(),2);}
cskiss(str) {return BULK->flirtit(str," gives ",
	      " a deep, passionate kiss",this_player(),2);}
click(str) {return BULK->flirtit(str," licks ", "",this_player(),2);}
cstrut(str) {return BULK->flirtit(str," struts around as if extremely excited.\n",
	 " You wonder whats the big deal",this_player(),1);}


