#include "/players/greg/color.h"
#define MG "players/greg/closed/guild/"
#define MS "/players/greg/closed/guild/spells/"

object pob,gzombie;
	object lasttell;
int ohp;
int glevel;
query_auto_load() { return MG + "mage:"; }

id(str) { return str == "mandlebrot" || str=="staff" || str=="ND"; }
	long() { write(HIR+"Fracton's Baby! We RoX this MuD!!\n"+
		HIY+"This is the heart of your power, \n"+
		"it would be a good idea not to lose it. :)\n"+
		"For guild help type: 'Fracton Help'\n"+
		HIM + "Live Long, And Prosper!\n"+NOR);
		}

reset(arg) {
	if(arg)
return;
	{
	if (pob=present("mandlebrot",this_player()))
		destruct(pob);
	glevel=1;
	pob=this_player();
ohp=pob->query_hps();
write(HIR+"FrAcToN'S RuLe!\n"+HIB+"Party On!!!\n"+NOR);
	}
}

drop() { return 1; }

get() { return 1; }

init() {
	string all;
  if(!environment()) return;
  if(environment() != this_player()) return;
	pob = this_player();
  if(!pob) return;
	add_action("all"); add_xverb("");
	return 1;

}
q_last_tell() { return lasttell; }

c_last_tell(str) { lasttell=str; return 1; }
c_lev(int1) { glevel = int1; return 1; }
   q_glevel() { return glevel; }
q_gzombie() { return gzombie; }
c_gzombie(zomobj) { gzombie = zomobj; return 1; }
all(str)
{
string path;
	string str1,str2;
sscanf(str,"%s %s",str1,str2);
if (!str1) str1=str;
if (str=="mon")
	{
	write(HIR+"Your HP mon is on, Go KILL!\n"+NOR);
	return 1;
	}
if (str=="nmon")
{
write(HIG+"Your mon is off, oh no!\n"+NOR);
	set_heart_beat(0);
return 1;
}
	set_heart_beat(0);
	if (str=="quit")
	{
	if (gzombie)
	{
	write("Your Beastie is disintegrated as you depart.\n");
	destruct(gzombie);
	}
	write(HIM+"Ok Frac, but your gonna miss all the"+
" fun\n Come back ASAP, we'll be here!!!\n\n"+
"Laterz\n"+NOR);
	return 0;
	}
if (str=="destit")
	{destit(); return 1;}
path= MS + "_" + str1 + ".c";
if (file_size(path) >= 0 )
	{
	path->com(str2,pob,this_object());
	return 1;
	}
	return 0;
	}
destit()
{
destruct(this_object());
return 1;
}

