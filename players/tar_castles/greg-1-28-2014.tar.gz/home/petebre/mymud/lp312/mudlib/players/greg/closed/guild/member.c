#define MG "players/greg/closed/guild/"
string members;

member(str) {
  string s1, s2;
  if(!str) return 0;
  if (restore_object(MG + "mages"))
	  if(sscanf(members,"%s#"+str+"%s", s1, s2) == 2) return 1;
  return 0;
}

