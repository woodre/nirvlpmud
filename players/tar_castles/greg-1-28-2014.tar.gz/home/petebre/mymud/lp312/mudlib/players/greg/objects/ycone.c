#include <ansi.h>
 inherit "obj/food";

reset()
	{
	::reset();
   	set_name("apple pie");
	set_alias("cone");
	set_name(YEL+"Ice cream cone"+WHT);
	set_short(YEL+"Ice cream cone"+WHT);
	set_long(YEL+"Looks pretty tasty.\n"+WHT);
	set_value(0);
	set_weight(3);
	set_strength(10);
	set_eater_mess(YEL+"You lick and lick until its all gone, "+
			"Mmm Mmm good!\n"+WHT);
	set_eating_mess(" eats a cool "+YEL+
	"yellow "+WHT+"ice cream cone.\n");
	return 1;
	}


