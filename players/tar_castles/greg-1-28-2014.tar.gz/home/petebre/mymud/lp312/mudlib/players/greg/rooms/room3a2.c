#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<4 ;i++) {
          move_object(clone_object(MP + "yfuzzy"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = YEL + "Southern Fuzzys" + WHT;
       long_desc = "\n"+
        YEL + "Southern Fuzzys\n" +
	"     It is very peaceful here. There are cute fuzzy creatures here\n"+
	"that have 'Kill ME' written all over them\n" + WHT;
        dest_dir = ( {
            GP + "room3a" , "north",
                });
        }
}
