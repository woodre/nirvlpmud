#include <ansi.h>
#define WP "players/greg/weapons/"
#define AP "players/greg/armor/"
inherit "obj/monster";

reset(arg)
{
  object money, weapon;
  ::reset(arg);
  if(arg) return;
  set_name("blob");
   set_race("blobber");
  set_alias("blob");
  set_short(  BLU + "A Blue Blob" + WHT);
  set_long(BLU+"This is just nasty! A big gob of blueish\n"+
	"slime. It doesnt look to tasty. You might\n"+
	"wanna have something different for dinner.\n"+
	WHT);
  set_level(14);
  set_hp(250);
  set_al(0);
  set_wc(17);
  set_ac(10);
	set_aggressive(1);
     money=clone_object("obj/money");
  call_other(money,"set_money",random(2000));
  move_object(money,this_object());
   weapon=clone_object(WP + "blobit");
  move_object(weapon,this_object());
}
