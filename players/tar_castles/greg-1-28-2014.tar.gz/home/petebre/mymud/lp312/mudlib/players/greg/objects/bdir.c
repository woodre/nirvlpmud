#include <ansi.h>
#include "std.h"

id(str) { return str == "directions"; }

long() {
        write( BLU + "A hint sheet for the Blue World\n" +
	"It says that searching could prove useful in this area.\n"+
	WHT);
}

short() {
        return BLU + "A hint sheet for the Blue World" + WHT;
}

query_value()
{
    return 0;
}

get()
	{
    	return 1;
	}

drop()
{
	return 1;
	}
	
query_weight() {
    return 7;
}

