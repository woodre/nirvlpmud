#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guy")) {
          for(i=0;i<4;i++) {
          move_object(clone_object(MP + "gguys"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "Protectors of the king" + WHT;
       long_desc = "\n"+
        GRE + "Protectors of the king\n" +
	"     These guys look pretty mean, and they aint gonna let\n"+
	"you by without you destroying them all. Apparently. the increased\n"+
	"protection is due to the fact that the frogs stormed this castle a while back\n"+
	"and stole the king's power crown. He prob. be grateful to anyone who returned\n"+
	"it to him. The king is south of here.\n" + WHT;

        dest_dir = ( {
	GP +"room4", "south",
	GP + "room4",  "north",
	    });
        }
}

init()
	{::init();
	add_action("south","south");
	}

south()
	{
	if(!present("guy")) {
        		move_object(this_player(),GP + "room4b1");
		write("You head south towards the king.\n");
		return 1;
		}
	write( GRE + "The Green guys are in your way!\n"+
		        "They will NOT let you pass\n" + WHT );
	return 1;
	}	
