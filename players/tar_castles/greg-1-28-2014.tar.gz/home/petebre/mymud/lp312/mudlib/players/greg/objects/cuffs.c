id(str) {return str == "cuffs"; }
 
get() {return 1;}
 
short() 
{
	return "Immobility Shackles (Your screwed!)";
}
 
long() 
{
	return "You've done it now, pissed the GREAT one off!";
}
 
reset(arg) 
{
   if(!arg) {
    set_light(1);
    
}
}
 
init() 
{
   if(this_player()->query_level() < 20)
   {
    add_action("junk_this"); add_xverb("");
   }
}
 
junk_this(str) 
{
  string my_verb;
  my_verb = query_verb();
  if (my_verb == "quit") {no_quit();}
	else {write("DEATH to the unbeliever!!!\n");
	tell_room(this_room(),capitalize(this_player()->query_name()) + "  squirms in their shackles\n");};
  
  return 1;
}
 
quit()
{
  write("Why do you want to quit from here?\n");
  return 1;
}
 
