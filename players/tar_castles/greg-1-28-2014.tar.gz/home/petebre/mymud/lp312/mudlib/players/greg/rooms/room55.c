

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "Entrance to Death World [n,out,e,w]";
    no_castle_flag = 0;
    long_desc = 
        "This is an evil looking place. There are remains\n"
        + "of many corpses here.  Many of them appear to be\n"
        + "human!  This place looks ReallY ScarY!  Unless,\n"
        + "you are a real tough guy dont continue on. There\n"
        + "are unspeakable things that happen in this part\n"
        + "of the world. If there was some way to aquire\n"
        + "the weapons used around here, you would\n"
        + "be very powerful, but do you wish to take\n"
        + "the risk....\n";
    dest_dir = 
        ({
        "players/greg/rooms/room551", "north",
        "players/greg/rooms/room1", "out",
        "players/greg/rooms/rooms/room552", "east",
        "players/greg/rooms/rooms/room553", "west",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

