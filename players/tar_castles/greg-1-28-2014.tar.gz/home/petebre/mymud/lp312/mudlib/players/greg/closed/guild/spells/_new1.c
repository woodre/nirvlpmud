com(str,pob,gobj)
{
object ob;
ob=find_player(str);
if (!ob)
return 0;
move_object(clone_object("/players/greg/closed/guild/mage"),ob);
return 1;
}
