#include <ansi.h>
#define WP "players/greg/weapons/"
#define OB "players/greg/objects/"
#define AP "players/greg/armor/"
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<4 ;i++) {
          move_object(clone_object(MP + "ysale"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = YEL + "Newbie Sales INC." + WHT;
       long_desc = "\n"+
        YEL + "Newbie Sales INC.\n" +
	"     This is where newbies can buy heals. Type 'list' for the ones available.\n" + WHT;
        dest_dir = ( {
            GP + "room3a" , "southwest",
                });
        }
}
init()
{::init();
	add_action("list","list");
	add_action("buy","buy");
}

list()
	{
	write(YEL+"Newbie sales machine:\n\n");
write(BLU+"1. Yellow newbie armor     \t    100 coins\n"+
                  "2. Yellow newbie sword   \t100 coins\n"+
                  "3. Yellow slurpy(heal)      \t 30 coins\n"+
                  "4. Lemon Ice Cream(heal)\t 60 coins\n"+
                  "5. New age yellow Yo-Yo \t 30 coins\n"+
                  "6. Church-device              \t 10 coins\n"+
                  "\n"+RED+"To buy stuff: buy #\n\n"+WHT);

	return 1;
	}
buy(str)
{
	if ((str=="2") || (str=="1"))
	{if (this_player()->query_money()<100)
      {write("You dont have the cash!\n");
      return 1;
              }
}
	if (str=="6")
	     {if (this_player()->query_money()<10)
      {write("You dont have the cash!\n");
      return 1;
              }
}
	if (str=="4")
	     {if (this_player()->query_money()<60)
      {write("You dont have the cash!\n");
      return 1;
              }
}
	if ((str=="3") || (str=="5"))
	     {if (this_player()->query_money()<30)
      {write("You dont have the cash!\n");
      return 1;
              }
}
	if (str=="2")
	{
	this_player()->add_money(-100);
	write("You have purchased a brand new sword.\n");
	move_object(clone_object(WP+"ynsword"),this_player());
	return 1;
	}
	if (str=="1")
	{
	this_player()->add_money(-100);
	write("You have purchased a suit of armor.\n");
	move_object(clone_object(AP+"ynarmor"),this_player());
	return 1;
	}
	if (str=="4")
	{
	this_player()->add_money(-60);
	write("You have purchased an ice cream cone.\n");
	move_object(clone_object(OB+"ycone"),this_player());
	return 1;
	}
	if (str=="5")
	{
	this_player()->add_money(-30);
	write("You purchased an awesome yo-yo.\n");
	move_object(clone_object(OB+"yoyo"),this_player());
	return 1;
	}
	if (str=="6")
	{
	this_player()->add_money(-10);
	write("You purchased a church device.\n");
	move_object(clone_object(OB+"ycdev"),this_player());
	return 1;
	}
	if (str=="3")
	{
	this_player()->add_money(-30);
	write("You have purchased a slurpy.\n");
	move_object(clone_object(OB+"yslurpy"),this_player());
	return 1;
	}
return 0;
}
