#define MP "/players/greg/mons/"
com(str,pob,gobj)
{
        object ob;
	if (gobj->q_glevel()<1)
	{ write ("Your magical skills are not that advanced!\n");
	  return 1;
	}

	if (gobj->q_gzombie())
		{ write("You already have a beast!!!\n");
		  write ("Don't be greedy! \n");
		  return 1;
		}
			
	if (pob->query_sp()<50)
		{ write ("You do not have enough sps...\n");
		  return 1;
		}
       pob->add_spell_point(-50);
        ob=clone_object(MP+"beastman");
        move_object(ob,environment(pob) );
        ob->set_follow(pob->query_real_name() );
	write("You call upon the ancient powers of life itself.\n"+
		"and a beast materializes in front of you.\n");
	say("A beast appears from nowhere and strides over to "+
	pob->query_real_name() + "\n" );
	gobj->c_gzombie(ob);
 return 1;
}
