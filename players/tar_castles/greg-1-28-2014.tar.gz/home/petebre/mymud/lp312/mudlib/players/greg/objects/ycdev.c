#include <ansi.h>
#include "std.h"

id(str) { return str == "device"; }

long() {
        write( YEL + "This is very useful for newbies\n"+
	"It will bring you back to the church if you are\n"+
	"lost. The church is where you first appeared in\n"+
	"the game. To use type 'colorme'\n"+WHT);
}

short() {
        return YEL+"Yellow church device"+WHT;
}

init()
	{
	add_action("colorme","colorme");
	return 1;
	}

colorme()
	{
	if (this_player()->query_level()<5)
	{if (!(environment(this_player())->realm()))
	  {
	write("You are transported to safety.\n");
	move_object(this_player(),"/room/church");
	destruct(this_object());
	   return 1;
	}
	else
	 {write("You are in a protected zone, NO TELEPORTS!\n");
	 return 1;
	}
	}
	write("You're level is too high to use this.\n"+
	        "You should know how to get around by now.\n");
return 1;
	}

query_value()
{
    return 0;
}

get()
	{
    	return 1;
	}

drop()
{
	return 1;
	}
	
query_weight() {
    return 3;
}

