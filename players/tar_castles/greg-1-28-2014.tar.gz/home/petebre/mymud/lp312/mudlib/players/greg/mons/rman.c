#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name(RED + "A red man" + WHT);
   set_race("Red");
  set_alias("man");
  set_short( RED + "A red man" + WHT);
  set_long("This is a red man.\n" +
	    "He looks like he could be helpful.\n");
  set_level(20);
	set_hp(500);
  set_wc(30);
  set_ac(15);
	  money=clone_object("obj/money");
  call_other(money,"set_money",random(2000));
  move_object(money,this_object());
	  set_chat_chance(10);
  load_chat("The red man says: Journey forth into the red desert\n"+
	      "On the other side, in monger land, You will find something\n"+
	"useful.\nREMEMBER: This is a very dangerous area and the"+
	" rooms have\n"+
	"	  clues to the solution.\n");


	return 1;
}
