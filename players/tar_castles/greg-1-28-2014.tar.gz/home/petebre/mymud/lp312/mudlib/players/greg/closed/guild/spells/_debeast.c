com(str,pob,gobj)
{
	object ob;
	ob=gobj->q_gzombie();
	if (!ob) {
	write ("You do not have a beastie.\n");
	return 1;
	}
	destruct(ob);
gobj->c_gzombie(0);
write("You call on the powers of lightning\n"+
	"and totally obliterate your beast.\n");
say(pob->query_real_name()+ "'s beast is disingrated by a sudden flash of lightning.\n");
return 1;
}
