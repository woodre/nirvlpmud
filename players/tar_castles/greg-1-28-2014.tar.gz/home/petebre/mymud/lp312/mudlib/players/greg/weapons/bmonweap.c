#include <ansi.h>
#define OB "/players/greg/objects/"
int i;
reset(arg) {
   ::reset(arg);
   if(arg) return;
      set_alias("dagger");
 set_name("The " + BLU + "Blue " + WHT + "dagger of destruction");
        set_short("The " + BLU + "Blue " + WHT + "dagger of destruction");
        set_long("An fearsome weapon used for massive slaughter\n");
        set_class(18);
        set_weight(6);
        set_value(5000);
        set_hit_func(this_object());
}
weapon_hit(attacker) {
	i=(random(10));
  if (i>5) {

        say(this_player()->query_name()+"'s lunges through the enemy with ease\n"+
		"Blood splatters everywhere...\n");
        write(RED + "You " + WHT + "really " + RED + "slam" + WHT + " your " +
                RED + "opponent " + WHT + "HARD!\n");
  return 1;
    }
   return 0;
}
init()
{
::init();
add_action("change","change");
}
change()
{
move_object(clone_object(OB + "bpiece"),this_player());
	write("The dagger dissappears and the blue piece\n" +
	"Appears!\n");
	 destruct(this_object());
	return 1;
}
