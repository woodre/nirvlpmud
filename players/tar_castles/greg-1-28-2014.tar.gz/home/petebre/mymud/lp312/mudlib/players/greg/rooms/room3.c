#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<4 ;i++) {
          move_object(clone_object(MP + "yguard"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = YEL + "Entrance to the Yellow Submarine" + WHT;
       long_desc = "\n"+
        YEL + "Entrance to the Yellow Submarine\n" +
	"     This a the newbie area. Should be pretty easy for you guys.\n"+
	"No one over level 7 is allowed to enter. The area is yellow in color.\n"+
	"If you start to find other colors, then try to get away cause yellow is\n"+
	"the newbie area. There should be enough easy monsters in here to\n"+
	"keep all the newbies content. Have fun, when you level you can try out\n"+
	"the other sections of Color world.\n" + WHT;
        dest_dir = ( {
            GP + "room32" , "south",
	    GP + "room3", "east",
            GP + "room1", "west",
                });
        }
}

init()
	{
	::init();
	add_action("east","east");
	}

east()
	{
	if ((this_player())->query_level() < 8 )
		{
		move_object(this_player(),GP + "room3a");
	write("You have enter the newbie zone....\n"+
		"Have fun and be careful!!!\n");
		return 1;
		}
write("You CAN'T go in there, Your too powerfull!!!\n\n");
	return 1;
	}
	
