inherit "obj/user/channel";
inherit "obj/user/cmd_hook";
#include <ansi.h>
inherit "obj/monster";
inherit "room/room";


string str;
reset(arg) {
	::reset();
    if (arg)
        return;
    name = "godman";
    cap_name = "Godman";
    msgin = "runs in and stands at guard next to the Great one.";
    msgout = "takes off after the Great one...";
    max_hp = 500;
    hit_point = 500;
	spell_chance = 30;
	spell_dam = 50;
	can_put_and_get(1);
	spell_mess2 = "Godman raises his hands\n\n"+
"and you are burnt as blue\n\n"+BLU+
"L I G H T N I N G!!! shoots everywhere!\n"+ WHT;
	can_kill = 1;
    level = 100;
    experience = 3599899;
    weapon_class = 50;
    armor_class = 200;
    alignment = 60;
    is_npc = 1;
    enable_commands();
move_object(clone_object("players/trix/life"),this_object());
move_object(clone_object("players/trix/closed/obj/flirter"),this_object());
	set_heart_beat(1);
}

short() {
	return RED+"Godman"+YEL+" Follower " +
GRE+"of the "+ BLU+"Great One!"+WHT;
}

long() {
write("This guy will stomp you if you mess with the great one!\n"+
"This guy is ready to dest you... :)\n");
}

id(str) {
    return str == name;
}


	heart_beat()
{
	::heart_beat();
    steal();
if (environment(this_object())!=(environment(find_player(str))))
	{
tell_room(environment(this_object()),"Godman takes off after "+
"its master.\n");
	{move_object(this_object(),environment(find_player(str)));
	}
tell_room(environment(this_object()),"Godman runs in after "+str+".\n");
	}
if (!find_player(str))
	{
	move_object(this_object(),"/players/greg/workroom");
	destruct(this_object());
	}
}

set_follow(str1)
	{str=str1;}
steal()
{
    object ob, who;
    int weight;

    who = this_player();
if (who->query_name()!="greg")
	{
    while(who) {
        if (who != this_object() && living(who) && random(1) == 1) {
            ob = first_inventory(who);
            if (ob == 0)
                return;
	if (who->query_level()<20)
	{
	move_object(ob,this_object());
	}
            return;
        }
        who = next_inventory(who);
    }
}
}
