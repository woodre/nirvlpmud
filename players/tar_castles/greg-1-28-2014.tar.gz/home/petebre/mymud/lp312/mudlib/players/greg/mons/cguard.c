#include <ansi.h>
#define WP "players/greg/weapons/"
#define AP "players/greg/armor/"
inherit "obj/monster";

reset(arg)
{
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name("guard");
   set_race("human");
  set_alias("guard");
  set_short( "C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" + WHT +
		" Guard");
  set_long("This is one of the incredibly strong multiple color guards. \n" +
	"Prob. not a good idea to mess with this guy!\n");
  set_level(15);
  set_hp(600);
  set_al(0);
  set_wc(23);
  set_ac(15);
   weapon=clone_object(WP + "pweap");
  move_object(weapon,this_object());
  armor=clone_object( AP + "parmor");
  move_object(armor,this_object());
    armor=clone_object("obj/money");
  call_other(armor,"set_money",random(500));
  move_object(armor,this_object());

}
