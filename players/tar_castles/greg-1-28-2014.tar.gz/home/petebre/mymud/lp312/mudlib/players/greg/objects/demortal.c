#include <ansi.h>

#include "std.h"

id(str) { return str == "deimmortalizer"; }

reset(arg) {
	if (!arg) return;
}

long() {
write("The is the deimmortalizer, its a very strange looking\n"+
	"orb. Different colors seem to be flowing through it\n"+
	"constently. You feel this object is vital in your\n"+
	"quest.\n");
}

short() {
	return YEL+"The Deimmortalizer"+WHT;
}

query_value()
{
	return 5;
}

init() {
	add_action("beat","beat");
}
search(str)
{
	object ob;
	         ob = first_inventory(environment(this_player()));
         while(ob) {
                if (ob->questbaby())
		{ return ob; }
	    ob = next_inventory(ob);
                }
        return 0;
	}


	beat(str)
	{
	object ob;
	if (str=="on god")
	{
	ob=search("12");
	if (ob)
		{
		write("The god seems to falter a bit,\n"+
		"Now's your chance....\n");
		ob->weakenit();
		return 1;
		}
	else
		{
		write("The proper god isnt here\n");
		return 1;
		}
	}
	return 0;
}
get() {
    return 1;
}

query_weight() {
    return 2;
}
