#include <ansi.h>
#define OP "players/greg/objects/"
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

realm() { return "NT"; }
int i;

reset(arg) {
        if(!present("mongers")) {
          for(i=0;i<4;i++) {
          move_object(clone_object(MP + "mongers"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
	 short_desc = RED + "The Red Combo Room" + WHT;
       long_desc = "\n"+
 	RED + "The Red Combo Room.\n" +
	"     As you look around, you notice everything is red.\n" +
	"There is a combination lock in front of you, looks like\n" +
	"might be able to get something if you could figure out\n" +
	"the combination.  Type combo <n1>,<n2>,<n3> to enter " +
	"a combination.\n" + WHT;
        dest_dir = ( {
            GP + "room1", "leave",
               });
        }
}
init()
	{::init();
	add_action("combo","combo");
	}


combo(n1)
	{
	if (n1="23,1,94")
		{write("As you open the lock lets out a\n"+ RED +
			"\n	B O L T OF LIGHTNING\n\n" +
			WHT + "			...an objects falls into your inventory\n");
		move_object(clone_object( OP + "rpiece"),this_player());
		return 1;
		}
	write("W  R  O N G O!!!!!!!!!   D U D E !!!!!  See ya later pal!\n");
	move_object(this_player(),GP + "room1");
	return 1;
	}
 
