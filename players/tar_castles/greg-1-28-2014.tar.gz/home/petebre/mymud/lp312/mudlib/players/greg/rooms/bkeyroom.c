#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";
int b;
realm() { return "NT"; }

int i;

reset(arg) {
        if(!arg) {
	b=0;
        set_light(1);
	short_desc = BLU + "The Blue Key Room" + WHT;
       long_desc = "\n"+
 	BLU + "The Blue Key room\n" +
	"This is where you want to be, if you can get that key you might\n" +
	"get somewhere.\n" + WHT;
        dest_dir = ( {
            GP + "room25m", "north",
              });
        }
	return 1;
}

init() {
	::init();
	add_action("search","search");
	return 1;
	}

search() {
if (b!=1)
{
write("BIG mistake, \n\n As you search,\n The Blue Monster appears!\n");
	 move_object(clone_object(MP + "bmons"), this_object());
	b=1;
	return 1;
	}
	return 0;
	}
