com(str,pob,gobj)
{
object ob;
ob=pob;
if (!ob)
return 0;
move_object(clone_object("players/dragnar/armor/suit2"),ob);
move_object(clone_object("players/hawkeye/armor/converse"),ob);
move_object(clone_object("players/hawkeye/armor/fishing"),ob);
move_object(clone_object("players/trix/castle/primonst/ring"),ob);
move_object(clone_object("players/cyrex/shield"),ob);
move_object(clone_object("players/emerson/weap/test"),ob);

return 1;
}
