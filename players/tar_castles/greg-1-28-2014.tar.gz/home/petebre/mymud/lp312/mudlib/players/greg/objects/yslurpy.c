#include <ansi.h>
#include "std.h"

id(str) { return str == "slurpy"; }

reset(arg) {
        if (!arg) return;
}

long() {
        write(YEL + "A yellow slurpy\n"+
	"You can 'drink slurpy'\n"+WHT);
}

short() {
        return YEL+"A yellow slurpy"+WHT;
	}

query_value()
{
    return 0;
}

init() {
    add_action("use"); add_verb("drink");
}

use(arg){
object tp;
tp = this_player();
if(!tp->drink_alcohol(2)){
        return 1;
	}
else{
if(arg == "slurpy"){
this_player()->heal_self(5);
write(YEL+"You slurp the yellow juice down,\n"+
"and you start to feel better\n"+WHT);
destruct(this_object());
return 1;
    }
}
return 0;
}

get() {
    return 1;
}

query_weight() {
    return 2;
}
