#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!arg) {
        set_light(1);
short_desc = BLU + "A Blue hallway" + WHT;
       long_desc = "\n"+
 	BLU + "A Blue hallway\n" +
	"Not much to it, \n" +
	"It's Blue & it's a hallway\n" + WHT;
        dest_dir = ( {
            GP + "room24a", "north",
            GP + "room25a" , "south",
            GP + "room25g", "east",
	    });
        }
}
