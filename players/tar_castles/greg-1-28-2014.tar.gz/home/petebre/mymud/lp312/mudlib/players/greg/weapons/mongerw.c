#include <ansi.h>
inherit "obj/weapon";
int i;
reset(arg) {
   ::reset(arg);
   if(arg) return;
        set_alias("bar");
        set_name("a " + RED + "Red monger " + WHT + "bar");
        set_short("A " + RED + "Red monger " + WHT + "bar");
        set_long("This looks pretty cheap but, at least, its a weapon.\n");
        set_class(10);
        set_weight(4);
        set_value(500);
}

