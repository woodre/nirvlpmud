#include <ansi.h>
inherit "obj/monster";
#define AP "players/greg/armor/"
#define WP "players/greg/weapons/"

reset(arg)
{
	object money;
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name("god");
   set_race("god");
  set_alias("god");
  set_short( "C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" + WHT +
		" God");
  set_long("This is the one and only, color god. He looks\n" +
	    "incrediibly well protected. Plus, he has the \n" +
	    "awesome Color Monger with him. Killing him\n" +
	    "him would,obviously, bring you closer to the end\n" +
	    "of your quest. But he seems way to powerful! \n" +
	    "You must figure a way to even the odds...\n");
  set_level(30);
  set_hp(5000);
  set_al(0);
  set_wc(55);
  set_ac(1000);
	money=clone_object("obj/money");
  call_other(money,"set_money",random(7000));
  move_object(money,this_object());

   weapon=clone_object(WP + "cgodweap");
  move_object(weapon,this_object());
  armor=clone_object( AP + "cgodarm");
  move_object(armor,this_object());
}
weakenit()
{
::reset();
this_object()->set_ac(50);
return 1;
}
questbaby() { return 1;}
