#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("salesman");
   set_race("human");
  set_alias("man");
  set_short( YEL + "A helpful salesman" + WHT);
  set_long(YEL + "This guy is really helpful, but he is getting on your nerves.\n"+ WHT);
  set_level(7);
  set_hp(40);
  set_al(0);
  set_wc(10);
  set_ac(3);
money=clone_object("obj/money");
  call_other(money,"set_money",random(100));
  move_object(money,this_object());

}
