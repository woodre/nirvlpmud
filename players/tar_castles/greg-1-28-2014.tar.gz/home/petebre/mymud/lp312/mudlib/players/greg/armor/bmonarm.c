#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg) ;
        set_short( BLU + "Blue " + WHT + "Armor");
        set_long("This is the armor made for the blue monsters of the world,\n" +
	"looks relatively protective\n");
     set_ac(4);
     set_weight(7);
        set_value(3000);
        set_alias("armor");
        set_name("armor");
        set_type("armor");
}
