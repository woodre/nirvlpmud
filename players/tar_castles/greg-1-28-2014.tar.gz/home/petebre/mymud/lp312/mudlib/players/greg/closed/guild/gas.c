#include "/players/greg/color.h"

int gtime;
object ob;
id(str) { return str == "gases"; }
short() { return HIM+"TOXIC GASES"+NOR; }
drop() { return 1; }

reset(arg)
{ if(arg) return; gtime = random(50)+10; set_heart_beat(1); }

heart_beat() {
  if(!gtime) {
    tell_room(environment(),HIY+"The gasses disipate..."+NOR+" You can breath again.\n");
    destruct(this_object());
  }
	if (!random(3)) {
	say(HIR+"You can't breath...\n"+
		"Ack, that gas is toxic!!!\n"+NOR);
	}
  gtime -= 1;
  ob = first_inventory(environment());
  while(ob) {
    if(living(ob)) call_other(ob,"hit_player",random(10));
    ob = next_inventory(ob);
}
  }

