#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("king");
   set_race("king");
  set_alias("king");
  set_short( GRE + "The Green king " + WHT);
  set_long("It's the king of those damn green guys. He appears to \n" +
	"have lost his crown and he is very upset.\n");
  set_level(30);
  set_hp(600);
  set_al(0);
  set_wc(34);
  set_ac(14);
  money=clone_object("obj/money");
  call_other(money,"set_money",random(3500));
  move_object(money,this_object());
  set_chat_chance(20);
  set_a_chat_chance(33);
  load_chat("The kings yells: I want my god damn crown back!!! Those frogs are gonna PAY!\n");
  load_a_chat("The king says: Hey, stop hitting me... you meanie!\n");
}
