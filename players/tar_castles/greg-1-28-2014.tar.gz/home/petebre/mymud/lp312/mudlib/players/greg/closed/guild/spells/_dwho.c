#include "/players/greg/color.h"
search(ob1)
{
         object ob;
         ob = first_inventory(ob1);
         while(ob) {
	
	if (ob->q_glevel())
		{
	return ob->q_glevel();
		}
	    ob = next_inventory(ob);
                }
        return 0;
	}

com(str,pob) {
            object us;
	int lev1,glev;
            int x, y;
            us = users();
            for(x=0;x<sizeof(us);x++){

if (glev=search(us[x]))
{
y = y + 1;
lev1=us[x]->query_level();
if (lev1<10)
        write(HIY);
else if (lev1<15)
                write(HIB);
        else if (lev1<20)
        write(HIG);
else write (HIR);
        write(y + ". ");
if (y<10) write (" ");
        write("" +
        capitalize(us[x]->query_real_name()));
        if (strlen(us[x]->query_real_name())<6)
        write ("\t");
        write("\t");
        write(us[x]->query_level() + "\t");
        write(NOR);
	write(glev + "\t");
	 if(!environment(us[x])) write("Logging in");
               else write(environment(us[x])->short());
        write("\n");
              }
}

            return 1;
                }

