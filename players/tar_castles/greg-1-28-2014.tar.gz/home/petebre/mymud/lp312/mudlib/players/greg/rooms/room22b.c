#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<3;i++) {
          move_object(clone_object(MP + "bguard"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
	short_desc = BLU + "The Secondary Blue Guard room" + WHT;
       long_desc = "\n"+
 	BLU + "The Secondary Blue Guard room.\n" +
	"     This room contains extra guards to assist if there is a massive\n"+
	"assault on the castle.\n" + WHT;
        dest_dir = ( {
            GP + "room24b", "west",
	GP + "room2", "east",
	    });
        }
}
