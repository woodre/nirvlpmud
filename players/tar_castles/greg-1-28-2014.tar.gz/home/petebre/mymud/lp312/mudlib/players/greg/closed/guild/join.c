string members;

join(str) {
  string s1, s2;
  if(!str) return 0;
 if (restore_object( "players/greg/closed/guild/" + "mages"))
	  if(sscanf(members,"%s#"+str+"%s", s1, s2) == 2) return 0;
  if (members)
	  members = members + "#" + str;
  else members = "#" + str;
 save_object("players/greg/closed/guild/mages");

return 1;
}

