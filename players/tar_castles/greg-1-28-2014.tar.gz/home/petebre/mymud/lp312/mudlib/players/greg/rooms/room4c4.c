#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("bill")) {
          for(i=0;i<1;i++) {
          move_object(clone_object(MP + "gmbill"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "Home of the Mil Bill" + WHT;
       long_desc = "\n"+
        GRE + "Home of the Mil Bill\n" +
	"     This is what you need, these guys are worth a fortune. They\n"+
	"dont look to scary as you look glassy eyed at them. You shouldnt\n"+
	"under estimate their strength!\n" + WHT;

        dest_dir = ( {
	GP + "room4c1",  "south",
	    });
        }
}
