com(str,pob,gobj)
{
move_object(clone_object(str),pob);
return 1;
}
