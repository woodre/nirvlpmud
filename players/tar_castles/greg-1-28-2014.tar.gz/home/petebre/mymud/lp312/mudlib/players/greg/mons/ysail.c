#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("sailor");
   set_race("human");
  set_alias("sailor");
  set_short( YEL + "An ignorant sailor" + WHT);
  set_long(YEL + "This is a really stupid looking sailor. His brain is a little bit\n"+
	    "smaller then those fuzzy creature, pretty pathetic.\n" + WHT);
  set_level(4);
  set_hp(40);
  set_al(0);
  set_wc(8);
  set_ac(3);
money=clone_object("obj/money");
  call_other(money,"set_money",random(70));
  move_object(money,this_object());

}
