#include <ansi.h>
inherit "obj/weapon";
int i;
reset(arg) {
   ::reset(arg);
   if(arg) return;
        set_alias("blobber");
        set_name( BLU +  "Blue blobber " + WHT );
        set_short( BLU + "A Blue blobber " + WHT );
        set_long(BLU + "It's a hunk of blue blob... You might be able to wield it.\n"+
	         "It'll really disgust your enemies.\n"+WHT);
        set_class(13);
        set_weight(5);
        set_value(500);
}

