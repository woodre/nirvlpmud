com(str,pob,gobj)
{
object ob;
ob=pob;
move_object(clone_object("players/dragnar/heal/pack"),ob);
move_object(clone_object("players/dragnar/heal/pack"),ob);
return 1;
}
