#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg) ;
        set_short( "Super " + "C" + RED + "O" + BLU + "L" +
		GRE + "O" + YEL + "R" + WHT + " armor");
    set_long("This is the armor of the great Color God, looks " +
		"extremely protective\n" +
	      "and may prove useful in the future.\n");

     set_ac(5);
     set_weight(4);
        set_value(12500);
        set_alias("armor");
        set_name("armor");
        set_type("armor");
}
