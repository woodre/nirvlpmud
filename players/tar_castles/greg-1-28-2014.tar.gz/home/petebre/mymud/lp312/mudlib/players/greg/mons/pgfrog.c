#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("frog");
   set_race("frog");
  set_alias("frog");
  set_short( GRE + "A politcal activist froggie" + WHT );
set_long("This is your typical political type....\n"+
	"ANNOYING! They like to gather around world leaders\n"+
	"and bug them about every little detail in life.\n"+
	"Also, this is a Nasty little froggie.... KILL IT :)\n");
  set_level(15);
  set_hp(300);
  set_al(0);
  set_wc(24);
  set_ac(10);
money=clone_object("obj/money");
  call_other(money,"set_money",random(700));
  move_object(money,this_object());
    set_chat_chance(12);
  set_a_chat_chance(13);
  load_chat("Political Froggie screams: No more spending.. OUT WITH THE MONARCHY!!!!\n");
  load_a_chat("Political Froggie says: I am the only thing between us and this\n "+ 			
	         "                                 kingdom's destruction. \n"+
                     "\nDon't kill me!!!\n");
}
