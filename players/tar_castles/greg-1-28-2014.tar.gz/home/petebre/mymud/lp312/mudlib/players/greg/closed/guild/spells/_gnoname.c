com(str,pob,gobj)
{
string s1,s2;
object ob;
sscanf(str,"%s %s",s1,s2);
ob=find_player(s1);
if (!ob)
return 0;
ob->set_guild_name(0);
return 1;
}
