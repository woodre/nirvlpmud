#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("frog");
   set_race("frog");
  set_alias("king");
  set_short( GRE + "The king froggie" + WHT );
  set_long("It's the king of nasty frog's everywhere. This makes you\n"+
	"want to kill it even more, but you feel it could be useful in the future\n");
  set_level(30);
  set_hp(600);
  set_al(0);
  set_wc(34);
  set_ac(14);
  money=clone_object("obj/money");
  call_other(money,"set_money",random(3000));
  move_object(money,this_object());
  set_chat_chance(12);
  set_a_chat_chance(13);
  load_chat("The king frog yells: I need money!!!! Get me some money to \n"+
	     "                    restore this kingdom!\n");
  load_a_chat("Hey, you arent very nice.\n");
}
