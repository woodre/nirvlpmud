#include "/players/greg/color.h"
com(str, pob) {
            object plyr;
        string name;
	string junk;
string who;
	string str1,str2;
            string what;
	int check;
	int x,y;
	who=allocate(11);
	check=0;
	x=1;
        	name=pob->query_real_name();
	name = capitalize(name);
             if(!str) {write("Tell what?\n"); return 1;}
	while ( (sscanf(str,"%s,%s", str2,str1)==2) && (check!=1) )
	{
	if (sscanf(str2,"%s %s",junk,junk)!=2)
	{
	str=str1;
	who[x]=str2;
	x=x+1;
	}
	else { check=1; }
}
	sscanf(str,"%s %s",str2,what);
	if (!what) return 0;
	y=x+1;
	who[x]=str2;
	for (x=1; x<y; x++)
	{ plyr = find_living(who[x]);
	if(!plyr) {write(capitalize(who[x]) +
" is not online now. \n");
        		}
	if (plyr)
	{
	tell_object(plyr, HIR + name +
                " tells you -->> " + NOR + what + "\n");
	write("You tell "+capitalize(who[x])+": "+what+"\n");
              }
	}
	 return 1;
           }
