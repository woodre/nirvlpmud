#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("frog")) {
          for(i=0;i<3;i++) {
          move_object(clone_object(MP + "pgfrog"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "A green castle room" + WHT;
       long_desc = "\n"+
        GRE + "A green castle room\n" +
	"     You have made it to the castle of the frogs. This area is filledf\n"+
	"with frogs protesting the monarchy of the kingdom. There seems to\n"+
	"be a problem with the financial state of the government.\n" + WHT;
        dest_dir = ( {
            GP + "room4a5", "north",
            GP + "room4a1", "east",
	GP + "room4a6", "south",
                });
        }
}
