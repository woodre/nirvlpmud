#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("man")) {
          for(i=0;i<1;i++) {
          move_object(clone_object(MP + "rman"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
short_desc = RED + "The start of the Red land." + WHT;
       long_desc = "\n"+
 	RED + "The start of the Red Land.\n" +
	"     As you look around, you notice everything has changed\n" +
	" to red. You know that something useful lies within this part of\n" +
	"the castle.\n" +
	WHT;
        dest_dir = ( {
            GP + "room9a", "north",
            GP + "room1" , "south",
            GP + "room9b", "east",
	GP + "room25b", "west",
	    });
        }
}
