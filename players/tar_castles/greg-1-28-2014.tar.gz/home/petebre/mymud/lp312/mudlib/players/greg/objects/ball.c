 id(str) { return str == "ball" || str == "crystal ball"; }
short() { return "A beautiful crystal ball"; }
long() {
  write("A Beautiful Crystal ball that you just want to 'kick'.\n");
  }

init() {
  add_action("kickme","kick");


	}
kickme() {
  if (this_player()) {
  this_player()->raise_stamina(1000);
  this_player()->raise_magic_aptitude(1000);
  destruct(this_object());
  return 1;
  }
