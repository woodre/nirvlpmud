#include <ansi.h>
inherit "obj/weapon";

reset(arg) {
   ::reset(arg);
   if(arg) return;
        set_alias("sword");
        set_name(YEL + "Beginner's sword" + WHT);
        set_short(YEL + "A beginner's sword" +WHT);
        set_long(YEL + "This will help you achieve levels.\n"+
		"Now, go out and kill something.\n"+WHT);
	set_class(6);
        set_weight(2);
        set_value(50);
}

