#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("bill")) {
          for(i=0;i<2;i++) {
          move_object(clone_object(MP + "gtbill"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "The T-bills West" + WHT;
       long_desc = "\n"+
        GRE + "The T-bills West\n" +
	"     The value of these creature just shot up quite a bit. You really\n"+
	"would like to have these guys in your pocket. They are worth quite a bit\n"+
	"You think that if you could find a Mil bill you could prob. start your own kingdom.\n"+
	WHT;

        dest_dir = ( {
	GP + "room4c1",  "east",
	    });
        }
}
