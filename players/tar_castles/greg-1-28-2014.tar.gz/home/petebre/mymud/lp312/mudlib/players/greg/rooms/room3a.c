#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<4 ;i++) {
          move_object(clone_object(MP + "yfuzzy"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = YEL + "Inside the Sub" + WHT;
       long_desc = "\n"+
        YEL + "Inside the Sub\n" +
	"     It is very peaceful here. There are cute fuzzy creatures here\n"+
	"that have 'Kill ME' written all over them\n" + 
	"These fuzzy's are from the deep sea and relatively easy\n"+
	"to beat. To the northeast is a place to buy heals.\n" + 
	WHT;
        dest_dir = ( {
	GP + "room31", "northeast",
            GP + "room3a1", "north",
            GP + "room3a2" , "south",
            GP + "room3b", "east",
	GP + "room3", "west",
                });
        }
}
