#include <ansi.h>
inherit "obj/armor";

reset(arg) {
   ::reset(arg);
  if(arg) return;
    set_name(GRE + "Super CooL green paint armor" + WHT);
    set_alias("armor");
    set_short( GRE+ "Super CooL green paint armor" + WHT );
    set_long("This armor looks cool.\n"+
                "You can spaint <color>.\n");
  set_ac(5);
     set_weight(4);
        set_value(1250);
        set_alias("armor");
        set_name("armor");
        set_type("armor");
}
      init()
     {
      ::init();
       add_action("spaint","spaint");
        return 1;
        }
spaint(str)
        { write ("You paint your armor " + str + ". \n");
tell_room(environment(this_player()),this_player()->query_name() +
              "'s armor is painted "+ str +".\n");
if (str=="red")  { set_name( RED + "Super CooL " +str+" paint armor" + WHT);}
else if (str=="blue") { set_name( BLU + "Super CooL "+ str + " paint armor" + WHT); }
else if (str=="yellow")  { set_name( YEL + "Super CooL "+ str + " paint armor" + WHT);
 }
else if (str=="green") { set_name( GRE + "Super CooL "+ str + " paint armor" + WHT); }
else if (str=="white")   { set_name( WHT + "Super CooL "+ str + " paint armor" + WHT);
 }
else {set_name(RED + "Super CooL "+BLU+str+YEL+" paint "+GRE+"armor"+WHT);}
set_short(query_name());
set_long("This armor looks cool.\n"+
                "You can spaint <color>.\n");
          return 1;
                }

