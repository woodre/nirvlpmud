#include <ansi.h>
#define GP "players/greg/rooms/"
#define MPP "/players/greg/mons/delmar.c"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
	if (!find_living("delmar"))
	{
	move_object(clone_object(MPP),this_object());
	}
	if (!present("guard"))
	{
	for (i=0;i<6;i++)
	{
	move_object(clone_object(MP+"bguard"),this_object());
	}
	}
        if(!arg) {
        set_light(1);
	short_desc = BLU + "The Main Blue Guard room" + WHT;
       long_desc = "\n"+
 	BLU + "The Main Blue Guard room.\n" +
	"     This is the first of the many guard rooms around\n" +
	"this castle. Each room is color coded to the difficulty\n" +
	"of that particular room. Blue being the easy rooms.\n" +
	"All of the other colors you will have to figure out by yourself\n" +
	WHT;
        dest_dir = ( {
            GP + "room1", "out",
	    GP + "room22a", "east",
        GP + "room22b", "west",
	    });
        }
}
