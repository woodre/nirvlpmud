#include <ansi.h>
#define MP "players/greg/mons/"
#define GP "players/greg/rooms/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<2;i++) {
	move_object(clone_object(MP + "cguard"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
short_desc = "Entrance to C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" +
	WHT + " world!";
        long_desc = "\n"+
"Entrance to C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" +
	WHT + " world!\n" +

        "     You have entered the a new realm of life.\n"+
        "It looks pretty cool in here. There are many exits\n"+
	"that lead everywhere! There is a sign here.\n";
        dest_dir = ( {
            GP + "room9", "north",
	GP + "orbroom" , "up",
            GP + "room2" , "enter",
            GP + "room3", "east",
	GP + "room4", "west",
	GP + "room5", "northeast",
	GP + "room6", "northwest",
	GP + "room7", "southeast",
	GP + "room8", "southwest",
	"/room/forest8", "exit",
                });
        }
}
init() {
	::init();
	add_action("read","read");
	return 1;
	}
read(str)
	{if (!str)
	{write ("Read what???\n");}
	else {
	write(RED + "\n\n WELCOME, You have entered the COLOR world!\n"+
	WHT + "\n---------------------------------------------------------\n"+
	GRE + "This is a land based on the different colors.\n" +
	"There are monsters for all to kill.\n"+
"Some easier then others.\n"+
"The easiest section is to the east, this is the\n"+
"newbie area.  So if your new you better head that way!\n"+
"This whole area is color coded yellow being the easiest.\n"+
"red and multiple colors being the most difficult.\n"+
"Well, good luck, there's lots of rooms to enjoy\n"+
"\nThere is also a quest in my area for those who like a challenge.\n"+
	"\nGooD Luck!! and have fun...\n" +
	BLU + "\n\n    GREG\n" + WHT );
return 1;
}
}
