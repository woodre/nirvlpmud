#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";
realm() { return "NT"; }

int i;

reset(arg) {
        if(!arg) {
        set_light(1);
	short_desc = RED + "A desert of Red land." + WHT;
       long_desc = "\n"+
 	RED + "A desert of Red Land.\n" +
	"     As you look around, you notice everything is red.\n" +
	" You struggle to find your way around the redland.\n" +
	WHT;
        dest_dir = ( {
            GP + "room9", "north",
            GP + "room25h" , "south",
            GP + "room9g", "east",
	GP + "room9h", "west",
	    });
        }
}
