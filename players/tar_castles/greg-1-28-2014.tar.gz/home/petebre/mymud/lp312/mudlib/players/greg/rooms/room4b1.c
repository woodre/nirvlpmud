#include <ansi.h>
#define GP "players/greg/rooms/"
#define OB "players/greg/objects/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("king")) {
          for(i=0;i<1;i++) {
          move_object(clone_object(MP + "gking"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "The green king" + WHT;
       long_desc = "\n"+
        GRE + "The green king\n" +
	"     The king seems rather sad. He is really upset about losing his\n"+
	"crown. If only you could get it back for him, he would prob. help you\n"+
	"out a great deal!\n" + WHT;

        dest_dir = ( {
	GP + "room4b",  "north",
	    });
        }
}

init()
	{::init();
	add_action("return_it","return");
	}
	
        search(str1,str)
        {
        object ob,ob1;
         ob = first_inventory(this_player());
         while(ob) {
                ob1=ob;
        str=ob->pieceme();
                if (str==str1)
                {
        destruct(ob);
        return 1;
                }
                ob = next_inventory(ob1);
                }
        return 0;
        }

return_it()
	{
	if ((present("king")) && (search("8")))
	{
        		
		move_object(clone_object(OB + "gpiece"), this_player());
		write("As you show the crown to the king his eyes light up!\n"+
		"and all of a sudden his up and kickin!\n"+
		"You have restored the kingdoms of the green world!!!\n\n"+
		GRE +	"	HOORAY!!!!!\n			HOORAY!!!!\n\n" +
		WHT + "The king is extremely happy and pulls out the green treasure\n"+
		"that you have been questing for...\n"+
		"The king says thanks as he hands you the object.\n\n"+
		"Then, he says: BE GONE, I AM KING!!!!! I HAVE WORK TO DO!!!!\n");
		return 1;
		}
	write(  "Either the king isnt here or you dont have the crown.\n"+
		"You can do nothing here!\n" + WHT );
	return 1;
	}	
