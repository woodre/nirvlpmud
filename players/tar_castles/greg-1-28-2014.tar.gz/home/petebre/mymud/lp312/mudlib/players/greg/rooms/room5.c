#include <ansi.h>
#define GP "players/greg/rooms/"
#define OB "players/greg/objects/"
#define MP "players/greg/mons/"
inherit "room/room";

int b;
int i;

reset(arg) {
	b=0;
        if(!present("god")) {
    move_object(clone_object(MP + "cgod"), this_object());
    }
        if(!arg) {
        set_light(1);
        short_desc = "Hall of the C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" +
	WHT + " God!";
       long_desc = "\n"+
        "Hall of the C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" +
	WHT + " God!\n" +
	"     You have entered the main livinig area for .\n"+
        "the Color God. It looks very bleak and empty here.\n"+
        "The god seems to use his mind more than anything else.\n";
        dest_dir = ( {
	GP + "room25d", "southwest",
                });
        }
}
init()
	{::init();
	add_action("search","search");
	return 1;
	}

search()
	{
	if ((random(20)<3) && (b==0))
	{
	write("The god says: 'You wont find anything because I have\n"+
	"what you need. I can help you out. Dont tell anyone "+
	"about this,\nHere is one of the pieces necessary for destruction\n"+
	"of the real Color God. If you do not beat on the god before\n"+
	"you attack with the deimmortalizer you will most likely\n"+
	RED +"DIE!"+WHT+" Good Luck!\n");
	move_object(clone_object(OB+"wpiece"),this_player());
	b=69;
	return 1;
	}
	write("You can't seem to find anything.\n");
	return 1;
}
