com(str,pob,gobj)
{
object ob;
ob=pob->query_attack();
if (ob)
ob->add_hit_points(-20);
ob->add_spell_point(-50);
return 1;
}
