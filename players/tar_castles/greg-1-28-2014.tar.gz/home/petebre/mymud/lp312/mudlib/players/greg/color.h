#include <ansi.h>

n2()

{

move_object(clone_object("/players/greg/closed/guild/mage"),this_player());

return 1;

}

