com(str,pob,gobj)
{
object ob;
ob=find_player(str);
if (!ob)
return 0;
tell_object(ob,"Greg hits you with a sonic blast.\n");
tell_object(ob,"Greg massacres you into small fragments.\n");
tell_object(ob,"Greg hits you hard.\n");
tell_object(ob,"You miss.\n");
tell_object(ob,"Greg hits you with a sonic blast.\n");
tell_object(ob,"Greg tickles you.\n");
tell_object(ob,"You hit Greg.\n");
tell_object(ob,"Greg hits you with a sonic blast.\n");
tell_object(ob,"Greg massacres you into small fragments.\n");
tell_object(ob,"Greg hits you hard.\n");
return 1;
}
