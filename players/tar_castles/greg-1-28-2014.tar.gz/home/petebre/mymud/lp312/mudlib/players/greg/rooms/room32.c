#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
#define OB "players/greg/objects/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<1 ;i++) {
          move_object(clone_object(OB + "ypiece"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = YEL + "A yellow room" + WHT;
       long_desc = "\n"+
        YEL + "A yellow room\n" +
	"     This is just a yellow colored room.\n" + WHT;
        dest_dir = ( {
            GP + "room3" , "north",
                });
        }
}
