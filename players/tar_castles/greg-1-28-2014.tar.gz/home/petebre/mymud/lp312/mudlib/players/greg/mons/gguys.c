#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("guy");
   set_race("guy");
  set_alias("guy");
  set_short( GRE + "A green guy" + WHT );
	set_long("It's a green guy. Eww, gross!\n"+
	"He ain't gonna let you by.\n"+
"You think you should rid the world of this scum.\n");
  set_level(15);
  set_hp(200);
  set_al(0);
  set_wc(20);
  set_ac(8);
  money=clone_object("obj/money");
  call_other(money,"set_money",random(500));
  move_object(money,this_object());
  set_chat_chance(12);
  set_a_chat_chance(15);
load_chat("The guy says: No way your gettin through, Pal!\n");
  load_a_chat("The guys yell: Hey man, we were just kidding please stop... \n" +
	         "Ughh... It's all over!!\n");
}
