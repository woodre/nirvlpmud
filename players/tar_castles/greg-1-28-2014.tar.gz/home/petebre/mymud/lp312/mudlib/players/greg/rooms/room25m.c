#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int g;
int i;

reset(arg) {
        if(!arg) {
        set_light(1);
	g=0;
	short_desc = BLU + "A Blue hallway" + WHT;
       long_desc = "\n"+
 	BLU + "A Blue hallway\n" +
	"Not much to it, except there might be something here \n" +
	"It's Blue & it's a hallway\n" + WHT;
        dest_dir = ( {
            GP + "room25n", "west",
            GP + "room25l" , "east",
	    });
        }
return 1;
}
init() {
	::init();
add_action("south","south");
	add_action("search","search");
        }
search(str)
	{
	if (random(9)<2)
		{write("A secret door opens to the south.\n");
		 g=1;
		return 1;
		}
	return 0;

	}
south()
	{
	if (g==1)
	{
	move_object(this_player(),GP + "bkeyroom");
	write("You head through the secret door.\n");
	return 1;
	}
	}
