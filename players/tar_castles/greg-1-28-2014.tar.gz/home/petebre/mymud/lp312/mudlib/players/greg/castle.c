#include <ansi.h>
#define NAME "Greg"
#define DEST "room/forest8"
/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "castle"; }

short() {
	return "Greg's World of C"+RED+"O"+BLU+"L"+GRN+"O"+YEL+"R"+WHT;
}

long() {
    write("This is the " + short() + ".\n");
	write ("Come on in, and visit the new world of color!!!\n");
}

init() {
	add_action("y","y");
add_action("n2","registerme");
	add_action("n","n");
    add_action("enter"); add_verb("enter");
}

enter(str) {
	str=this_player()->query_name()+" "+ctime()+"\n";
	write ("You enter the beautiful castle.\n");
	write_file("/players/greg/clog",str);
	write ("This castle uses ansi escape sequences,\n"+
	"If your computer does not have that capability\n"+
	"then you should not go in this castle. You can\n"+
	"try it, then quit if it doesnt work.\n");
	write("Do still wish to enter: (y or n) ");
    return 1;
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
}
y()
{
write("Cool, you decided to come visit my world!\n");
write("C"+RED+"O"+BLU+"L"+GRN+"O"+YEL+"R"+RED+" RULEZ!\n"+WHT);
return 1;
}
n()
{
write("ok, see ya later, your missin out!\n");
return 1;
}
is_castle(){return 1;}
