#include <ansi.h>
#include "std.h"

id(str) { return str == "yoyo"; }

long() {
        write( YEL + "This is a neat yellow yoyo\n"+
	"You can use it by yoyo <player>\n"+WHT);
}

short() {
        return YEL+"A Yellow Yo-Yo"+WHT;
}

init()
	{
	add_action("yoyo","yoyo");
	}

yoyo(str)
{
	string str1;
	str1=this_player()->query_name();
	if ((str) && (find_player(str)))
{
if (environment(this_player())==environment(find_player(str)))
	{
	str=capitalize(str);
	tell_room(environment(this_player()),YEL+str1+" whips a "+
	"yo-yo all the way around "+str+". \n"+
	"Everyone in the room is impressed.\n"+
	"\nLook out, "+this_player()->query_name()+
	" is here and he knows how to yo-yo!\n"+WHT);
}
	return 1;
	}
write("You have to specify a player that is in the room.\n");
return 1;
}

query_value()
{
    return 100;
}

get()
	{
    	return 1;
	}

drop()
{
	return 1;
	}
	
query_weight() {
    return 3;
}

