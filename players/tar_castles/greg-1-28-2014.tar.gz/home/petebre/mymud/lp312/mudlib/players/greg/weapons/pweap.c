#include <ansi.h>
inherit "obj/weapon";



reset(arg) {

   ::reset(arg);

  if(arg) return;

    set_name(RED + "A TubulaR red sword" + WHT);

    set_alias("sword");

    set_short( RED + "A TubulaR red paint sword" + WHT );

    set_long("This sword looks cool.\n"+

                "You can paints <color>.\n");

    set_class(15);

	set_weight(3);

     set_value(1000);

     set_hit_func(this_object());

}

      init()

     {

      ::init();

       add_action("paints","paints");

        return 1;

        }

        paints(str)

                { write ("You paint your sword " + str + ". \n");

tell_room(environment(this_player()),this_player()->query_name() +

              "'s sword is painted "+ str +".\n");

if (str=="red")  { set_name( RED + "TubulaR " +str+" paint sword" + WHT);}

else if (str=="blue") { set_name( BLU + "TubulaR "+ str + " paint sword" + WHT); }

else if (str=="yellow")  { set_name( YEL + "TubulaR "+ str + " paint sword" + WHT); }

else if (str=="green") { set_name( GRE + "TubulaR "+ str + " paint sword" + WHT); }

else if (str=="white")   { set_name( WHT + "TubulaR "+ str + " paint sword" + WHT); }

else {set_name(RED + "TubulaR "+BLU+str+YEL+" paint "+GRE+"sword"+WHT);}

	set_short(query_name());
set_long("This sword looks cool.\n"+

                "You can paints <color>.\n");


          return 1;

                }



weapon_hit(attacker) {

int i;

i=random(10);

  if (i>5) {

        say(this_player()->query_name()+"'s sword hits suprisingly hard!\n");

        write("Wow, you really hammered that guy!\n");

 return 1;

    }

   return 0;

}
