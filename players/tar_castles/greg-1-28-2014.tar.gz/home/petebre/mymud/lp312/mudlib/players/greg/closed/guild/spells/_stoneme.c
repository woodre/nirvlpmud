com(str,pob,gobj)
{
object ob;
ob=pob;
move_object(clone_object("players/hawkeye/items/stone"),ob);
return 1;
}
