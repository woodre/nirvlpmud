#include "/players/dragnar/closed/color.h"
inherit "obj/weapon";
	int k;
int i;
reset(arg) {
   ::reset(arg);
   if(arg) return;
	set_name("the C" + RED + "O" + BLU + "L" + GRE + "O" +
                YEL + "R" + WHI + " Monger");
      set_alias("monger");
        set_short("The C" + RED + "O" + BLU + "L" + GRE + "O" +
		YEL + "R" + WHI + " Monger");
 set_long("An awesome weapon used by the infamous C" + RED + "O" +
	          BLU + "L" +  GRE + "O" + YEL + "R" + WHI + " God, \n" +
		"You are lucky to have it and still be alive!\n");
	set_class(17);
        set_weight(3);
        set_value(10000);
      set_hit_func(this_object());
}

weapon_hit(attacker) {
	object ob;
	i=(random(10));
  if (i>5) {

tell_room(environment(this_player()),this_player()->query_name() +
	"'s awesome weapon rips through the flesh of the enemy\n"+
RED + "SPLAT! " + WHI + "You whale on your opponent.\n" +
		"and " + RED + "red blood " + WHI + "spews everywhere!\n");
	if (k==0)
		{

	k=1;
	}
  return 1;
    }
	if (k==1)
	{
	k=0;
	}
   return 0;
}
query_save_flag() { return 1; }
