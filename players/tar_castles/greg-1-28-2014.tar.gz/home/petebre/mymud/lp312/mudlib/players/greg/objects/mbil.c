#include <ansi.h>
#include "std.h"

id(str) { return str == "milbill"; }

long() {
        write( GRE + "A MilBill\n" + WHT +
	"It looks like a lot of money for one bill.\n" );
}

short() {
        return GRE + "A MilBill" + WHT;
}

query_value()
{
    return 0;
}
pieceme()
	{
	return "7";
	}

get()
	{
    	return 1;
	}

drop()
{
	return 1;
	}
	
query_weight() {
    return 6;
}

