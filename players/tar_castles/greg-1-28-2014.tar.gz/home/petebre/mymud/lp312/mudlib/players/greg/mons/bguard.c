#include <ansi.h>
#define WP "players/greg/weapons/"
#define AP "players/greg/armor/"
inherit "obj/monster";

reset(arg)
{
	object money;
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name("guard");
   set_race("human");
  set_alias("guard");
  set_short(  BLU + "A Blue Guard" + WHT);
  set_long("This is one of the famous Blue guards found throughout this castle.\n"+
	   "He looks rather tough, but he is the easiest of all the color guards.\n");
  set_level(14);
  set_hp(250);
  set_al(0);
  set_wc(20);
  set_ac(13);
     money=clone_object("obj/money");
  call_other(money,"set_money",random(2000));
  move_object(money,this_object());
   weapon=clone_object(WP + "pweap");
  move_object(weapon,this_object());
  armor=clone_object( AP + "parmor");
  move_object(armor,this_object());
}
