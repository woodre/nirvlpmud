#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("bill")) {
          for(i=0;i<4;i++) {
          move_object(clone_object(MP + "g1bill"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "The green bill creations" + WHT;
       long_desc = "\n"+
        GRE + "The green bill creations\n" +
	"     You have have wondered upon the land of living money.\n"+
	"Scary to think you could be killed by a bill. These guys look\n"+
	"pretty friendly though. You shouldnt have too much trouble with\n"+
	"them unless you start something.\n" + WHT;

        dest_dir = ( {
            GP + "room4", "south",
	GP + "room4c1", "north",
                });
        }
}
