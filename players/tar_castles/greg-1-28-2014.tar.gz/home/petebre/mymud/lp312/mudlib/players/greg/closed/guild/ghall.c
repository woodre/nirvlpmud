#define MG "/players/greg/closed/guild/"
#include "tune.h"
#include "/players/greg/color.h"
inherit "/room/room";
inherit "/room/adv_guild.c";

init() {
    add_action("join"); add_verb("join");
    add_action("cost_for_level"); add_verb("cost");
    add_action("list_quests"); add_verb("list");
    add_action("advance"); add_verb("advance");
	add_action("raiseit","raise");
    add_action("read"); add_verb("read");
    add_action("buy"); add_verb("buy");
   add_action("do_install"); add_verb("guidance");
   ::init();
}

reset(arg) {

if (arg) return 0;
dest_dir=
({
"room/forest8.c","castle2",
"room/post","post",
	"room/adv_guild.c","adv",
	"players/catwoman/tl.c", "lockme",
	"players/boltar/hotel/hotel.c","hotel",
	"room/shop.c","shop",
	"players/trix/castle/disco/bar.c","bar",
"room/church.c","church",
});
short_desc=  HIM +"Fracton Guild Hall" + NOR;
long_desc = HIG + "This is the mainstay for Fracton's everywhere\n"+
	      "It looks very well used, and there are many magical\n"+
	"objects just floating around the room. As you look closer,\n"+
	"you cant seem to see any walls, it's like your in an endless\n"+
	"void. But you dont mind, Fracton's have grown used to this\n"+
	"type of magical environment. It is also a good place to practice\n"+
	"new spells, so you dont hurt anyone or something :)\n"+HIY+
	"There is a sign, that is rather stationary, in front of you.\n"+
	"Also, you a thought enters your mind that there is a list\n"+
	"to be read.\n"+NOR;
	set_light(1);
	}
join(str) {
   if(!str) return 0;
   if (call_other(this_player(), "query_int") < 13) {
	}
   if (call_other(this_player(), "query_whimpy")) {
	write("Wimps do NOT joins this guild!\n");
	return 1;
	}
if(call_other(MG + "member", "member", call_other(this_player(),"query_name"))){
      write("You are all ready a member, foolish one!\n");
      return 1;
   }
   write(HIY+"An old fracton appears in front of you...\n\n"+
"He doesnt look real enthusiastic about letting you join.\n"+
 "You probably better give him some money for his troubles.\n"+
   "How much do you wish to donate: "+NOR);
   input_to("joinme");
   return 1;
}
	raiseit(str)
	{ 
	::raise(str);
	return 1;
	}
read(str)
	{
	if (!str)
		return 0;
	if (str=="list")
		cat(MG+"list");
	if (str=="sign")
		cat(MG+"sign");
	return 1;
	}
joinme(str) {
int tmp;
string tmp1;
int tmp2;
   if (sscanf(str, "%d", tmp) != 1) return;
 tmp1= this_player()->query_money();
 if (tmp > tmp1) {write(HIM+"You dont have enough money, dude!!\n"+NOR);
	return 1;
	}
   if (tmp < 1) return 1;
 tmp=-tmp;
 this_player()->add_money(tmp);
if ( tmp == "60000" ) {
     write(HIM+"Come on, thats all i get...\n"+
	 "I dont think your qualified to join our guild. :)\n"+
	NOR);
     return 1;
   }
if ( this_player()->query_guild_name() )
	{ write ("You are a member of another guild\n"+
	"You must quit that one first.\n");
	return 1;
	}
   if(call_other(MG + "join", "join", call_other(this_player(),"query_name"))){
	this_player()->set_guild_name("fracton");
   say(HIM+"You are now a fracton.\n"+NOR);
   cat(MG + "spell.lst", 58, 16);
   move_object(clone_object(MG + "mage"),this_player());
   }
   else write(HIM+"We just dont want you! Go away!.\n"+NOR);
   return 1;
}


