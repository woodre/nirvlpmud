#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("frog");
   set_race("frog");
  set_alias("god");
  set_short( GRE + "A cute, little, green froggie" + WHT );
set_long("It's a nasty frog... KILL it!\n");
  set_level(10);
  set_hp(150);
  set_al(0);
  set_wc(14);
  set_ac(5);

  money=clone_object("obj/money");
  call_other(money,"set_money",random(800));
  move_object(money,this_object());
	set_chat_chance(13);
  set_a_chat_chance(20);
  load_chat("Ribbit!! Ribbit!!!!\n");
  load_a_chat("RIBBIT!!!! RIBBIT!!!\n!");
	return 1;
}
