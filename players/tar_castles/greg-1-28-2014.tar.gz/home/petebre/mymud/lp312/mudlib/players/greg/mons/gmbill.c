#include <ansi.h>
#define OB "/players/greg/objects/"
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("Mil Bill");
   set_race("bill");
  set_alias("bill");
  set_short( GRE + "A very, large Mil bill" + WHT );
  set_long("A cool million worth... Lots 'o money!\n");
  set_level(16);
  set_hp(400);
  set_al(0);
  set_wc(25);
  set_ac(8);
  money=clone_object("obj/money");
  call_other(money,"set_money",random(300));
  move_object(money,this_object());
	move_object(clone_object(OB + "mbil"),this_object());
  set_chat_chance(12);
  set_a_chat_chance(18);
  load_chat("Mil Bill states: Dude, Im rich.\n");
  load_a_chat("Mil Bill threatens: I'm gonna take all your money!\n");
}	
