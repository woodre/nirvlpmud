#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<4 ;i++) {
          move_object(clone_object(MP + "ysail"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = YEL + "Sailor's Northern Quarters" + WHT;
       long_desc = "\n"+
        YEL + "Sailor's Northern Quarters\n" +
	"     There are a bunch of ignorant sailors to be killed here\n" + WHT;
        dest_dir = ( {
            GP + "room3b" , "south",
                });
        }
}
