#include <ansi.h>
inherit "obj/monster";

reset(arg)
	{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("bill");
   set_race("bill");
  set_alias("bill");
  set_short( GRE + "A green dollar bill" + WHT );
  set_long("It's a green dollar bill. Cool! Walkin money!\n");
 set_level(10);
  set_hp(100);
  set_al(0);
  set_wc(17);
  set_ac(8);
  money=clone_object("obj/money");
  call_other(money,"set_money",random(500));
  move_object(money,this_object());
  set_chat_chance(12);
  set_a_chat_chance(33);
load_chat("The bill says: Hey Man, I Dont need no stinkin cash.\n");
load_a_chat("The bill says: Hey, I'm a bill, you can't kill me.\n");
}
