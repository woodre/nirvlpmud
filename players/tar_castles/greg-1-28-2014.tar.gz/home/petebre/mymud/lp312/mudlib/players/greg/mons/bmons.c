#include <ansi.h>
#define AP "players/greg/armor/"
#define WP "players/greg/weapons/"
inherit "obj/monster";

reset(arg)
{
	object money;
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name(BLU + "The Blue Monster" + WHT);
  set_alias("monster");
  set_short( BLU + "The Blue Monster" + WHT);
  set_long("This is the just what it says\n" +
	    "A mean looking, deadly blue monster.\n" +
	    "It seems that you need something from this creature\n" +
	    "and he doesn't look like a guy that'll just give it too ya,\n");
  set_level(20);
  set_hp(750);
  set_al(-20);
  set_wc(30);
  set_aggressive(1);
  set_ac(15);
   weapon=clone_object(WP + "bmonweap");
  move_object(weapon,this_object());
  armor=clone_object( AP + "bmonarm");
  move_object(armor,this_object());
	money=clone_object("obj/money");
  call_other(money,"set_money",random(3000));
  move_object(money,this_object());

}
