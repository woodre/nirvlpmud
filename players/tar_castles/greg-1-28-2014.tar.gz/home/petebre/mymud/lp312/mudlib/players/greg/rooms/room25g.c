#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
	if (!present("guy"))
	{
	for (i=0;i<2;i++)
		{
		move_object(clone_object(MP+"bguy"),this_object());
		}
	}
        if(!arg) {
        set_light(1);
        short_desc = BLU + "A Blue hallway." + WHT ;
       long_desc = BLU + "A Blue hallway\n" +
	"Not much to it, \n" +
	"It's Blue & it's a hallway\n" + WHT;
        dest_dir = ( {
            GP + "room21", "west",
            GP + "room25h" , "east",
	    });
        }
}
