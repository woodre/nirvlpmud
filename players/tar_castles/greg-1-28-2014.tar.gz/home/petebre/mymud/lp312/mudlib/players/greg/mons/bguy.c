#include <ansi.h>
#define WP "players/greg/weapons/"
#define AP "players/greg/armor/"
#define OB "players/greg/objects/"

inherit "obj/monster";

reset(arg)
{
  object money, weapon;
  ::reset(arg);
  if(arg) return;
  set_name("guy");
   set_race("color man");
  set_alias("guy");
  set_short(  BLU + "A Blue Guy" + WHT);
  set_long(BLU+"This looks kinda like you only\n"+
	"this guy got a bucket of blue paint thrown on\n"+
	"him at some point. Maybe he just doesnt take\n"+
	"baths quite as often as he should....\n"+
	WHT);
  set_level(10);
  set_hp(250);
  set_al(0);
  set_wc(17);
  set_ac(10);
     money=clone_object("obj/money");
  call_other(money,"set_money",random(2000));
  move_object(money,this_object());
   weapon=clone_object(OB + "bdir");
  move_object(weapon,this_object());
}
