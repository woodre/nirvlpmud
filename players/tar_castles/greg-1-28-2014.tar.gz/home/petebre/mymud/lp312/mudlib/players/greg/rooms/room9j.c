#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";
realm() { return "NT"; }

int i;

reset(arg) {
        if(!present("mongers")) {
          for(i=0;i<4;i++) {
          move_object(clone_object(MP + "mongers"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
	short_desc = RED + "The Red Land Monger Room" + WHT;
       long_desc = "\n"+
 	RED + "The Red Land Monger Room.\n" +
	"     As you look around, you notice everything is red.\n" +
	" You have finally made it to somewhere, as to where god only\n" +
	"knows.\n" + WHT;
        dest_dir = ( {
            GP + "room9n", "north",
               });
        }
}
