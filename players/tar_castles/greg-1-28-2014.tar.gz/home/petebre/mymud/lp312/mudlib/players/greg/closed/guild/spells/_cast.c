com(str,pob,gobj)

{
move_object(clone_object("players/emerson/weap/test"),pob);



return 1;

}
