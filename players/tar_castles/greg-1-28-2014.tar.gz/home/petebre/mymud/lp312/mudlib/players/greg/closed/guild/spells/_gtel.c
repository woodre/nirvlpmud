#include "/players/greg/color.h"
com(str, pob, gobj) {
            object plyr;
	string name;
            string who;
            string what;
	name=pob->query_real_name();
            if(!str) {write("Tell what?\n"); return 1;}
	plyr=gobj->q_last_tell();
	if (!find_living(plyr->query_real_name())) {
write("That player is not on!\n");
return 1;
}
	who = plyr->query_real_name();
	name = capitalize(name);
                tell_object(plyr, HIR + name +
		" tells you -->> " + NOR + str + "\n");
               write("You tell "+capitalize(who)+": "+str+"\n");
               return 1;
              }
