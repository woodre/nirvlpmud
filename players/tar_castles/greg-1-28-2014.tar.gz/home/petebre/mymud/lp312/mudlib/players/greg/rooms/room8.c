#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("god")) {
	 move_object(clone_object(MP + "cgod"), this_object());
    }
        if(!arg) {
        set_light(1);
        short_desc = "Hall of the C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" +
	WHT + " God!";
       long_desc = "\n"+
        "Hall of the C" + RED + "O" + BLU + "L" + GRE + "O" + YEL + "R" +
	WHT + " God!\n" +
	"     You have entered the main livinig area for .\n"+
        "the Color God. It looks very bleak and empty here.\n"+
        "The god seems to use his mind more than anything else.\n";
        dest_dir = ( {
	GP + "room25i", "northeast",
                });
        }
}

