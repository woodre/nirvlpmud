#include "/players/greg/color.h"
com(str,pob)
{
write(YEL+"You begin to burn with the fires from "+
	RED+"H E L L !!!"+NOR+"\n");
say(YEL+capitalize(pob->query_real_name())+ "begins to "+
"burn of the fires from "+RED+"HELL!\n"+NOR);
say("This burning body lights the room up\n");
set_light(1);
return 1;
}
