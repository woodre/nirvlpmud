#include "/players/greg/color.h"
com(str, pob, gobj) {
if (gobj->q_glevel()<1)
	{ return 0; }
	if (pob->query_sp()<50)
	{ write ("You dont have enough sps.\n");
	  return 1;
	}
pob->add_spell_point(-50);


	if (environment(pob)->realm()!="NT")
		{
write(HIY+"There is a strange feeling in your body as you are\n"+
	    "transformed into pure energy\n");
     say(pob->query_real_name()+" is transported elsewhere.\n");
write(HIM+"You are transported back to the place of"+
	" your creation.\n"+NOR);
move_object(pob,"/players/greg/closed/guild/ghall");
say(pob->query_real_name()+" materializes into view.\n");
	return 1;
	}
else
write (HIR+"Your magic is blocked as you attempt the teleport"+NOR);
write("\n");
return 1;
}


