#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_name("captain");
   set_race("human");
  set_alias("captain");
  set_short( YEL + "The Subs. Captain" + WHT);
  set_long(YEL + "This is the hardest guy around the newbie area\n"+
		  "but still he's not to tough, plus you get more xps\n"+
		   "for killling him.\n" + WHT);
  set_level(7);
  set_hp(80);
  set_al(0);
  set_wc(8);
  set_ac(3);
}
