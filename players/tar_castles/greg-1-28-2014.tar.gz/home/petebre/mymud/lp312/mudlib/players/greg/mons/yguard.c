#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
  set_name("guard");
   set_race("human");
  set_alias("guard");
  set_short( YEL + "A Yellow Guard" + WHT);
  set_long(YEL + "This is one of the famous yellow guards found throughout this castle.\n"+
	   "He looks rather tough, but he is incredibly easy to kill.\n" + WHT);
  set_level(5);
  set_hp(75);
  set_al(0);
  set_wc(10);
  set_ac(5);
}
