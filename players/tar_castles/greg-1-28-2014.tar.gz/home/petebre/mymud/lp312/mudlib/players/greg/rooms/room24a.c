#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<5;i++) {
          move_object(clone_object(MP + "bmguard"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
	short_desc = BLU + "The Far Eastern Blue Guard room" + WHT;
       long_desc = "\n"+
 	BLU + "The Far Eastern Blue Guard room.\n" +
	"     This room contains the final defense of blue guards.\n" + WHT;
        dest_dir = ( {
	GP + "room21", "south",
       	GP + "room22a", "west",
	    });
        }
}
