#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<1 ;i++) {
          move_object(clone_object(MP + "ycapt"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = YEL + "The Bridge" + WHT;
       long_desc = "\n"+
        YEL + "The Bridge\n" +
	"     Theis is where all the action is!\n"+
	"The control center of this awesome submarine\n"+
	"The captain usually stays here to keep track of his\n"+
	"ship.\n" + WHT;
        dest_dir = ( {
	GP + "room3b", "west",
                });
        }
}
