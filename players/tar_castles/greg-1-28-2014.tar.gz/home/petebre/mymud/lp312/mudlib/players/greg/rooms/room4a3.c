#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("frog")) {
          for(i=0;i<4;i++) {
          move_object(clone_object(MP + "gfrog"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "A green frog room" + WHT;
       long_desc = "\n"+
        GRE + "A green frog room\n" +
	"     Fitting to have green things in a green realm. There are frogs\n"+
	"all over the place. You should really kill em all off, Trust me, they\n"+
	"want to DIE.\n" + WHT;
        dest_dir = ( {
            GP + "room4a1", "south",
            GP + "room4a", "southeast",
	GP + "room4a5", "west",
                });
        }
}
