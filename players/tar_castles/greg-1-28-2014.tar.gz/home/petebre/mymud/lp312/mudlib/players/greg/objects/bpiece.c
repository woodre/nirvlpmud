#include <ansi.h>
#include "std.h"

id(str) { return str == "piece"; }

long() {
        write( BLU + "A Blue piece of something\n" + WHT +
	"It looks like you could <create orb>\n" +
	"in the proper room...\n" );
}

short() {
        return BLU + "The Blue piece" + WHT;
}

query_value()
{
    return 0;
}

get()
	{
    	return 1;
	}

drop()
{
	return 1;
	}
	
query_weight() {
    return 3;
}
pieceme()
{return "4";}

