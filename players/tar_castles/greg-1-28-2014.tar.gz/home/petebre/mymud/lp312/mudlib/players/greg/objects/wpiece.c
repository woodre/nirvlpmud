#include <ansi.h>
#include "std.h"

id(str) { return str == "piece"; }

long() {
        write( "A White piece of something\n" +
	"It looks like you could <create orb>\n" +
	"in the proper room...\n" );
}

short() {
        return "The White piece" + WHT;
}

query_value()
{
    return 0;
}

get()
	{
    	return 1;
	}

drop()
	{
	
	return 1;
	}
	
query_weight() {
    return 3;
}
pieceme()
{return "3";}

