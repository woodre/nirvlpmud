#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg) ;
	set_name(RED + "Red monger armor" + WHT);
	set_short(RED + "Red monger armor" + WHT);
	set_long("This is MONGER armor, DEAL WITH IT!\n");
        set_ac(3);
        set_weight(7);
        set_value(300);
        set_alias("armor");
        set_name("armor");
        set_type("armor");
}

