#include <ansi.h>
#define WP "players/greg/weapons/"
#define AP "players/greg/armor/"
#define OB "/players/greg/objects/"
inherit "obj/monster";

reset(arg)
{
        object money;
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name("guard");
   set_race("master");
  set_alias("guard");
  set_short(  BLU + "A Master Blue Guard" + WHT);
  set_long("This is one of the final means of defense for this area.\n"+
	    "He looks pretty difficult compared to reg. blue guards.\n"+
	    "You'd better be careful trying to kill this guy off!\n");

  set_level(25);
  set_hp(600);
	set_aggressive(1);
  set_al(30);
  set_wc(35);
  set_ac(15);
     money=clone_object("obj/money");
  call_other(money,"set_money",random(5000));
  move_object(money,this_object());
	weapon=clone_object(OB+"cflirt");
	move_object(weapon,this_object());
  armor=clone_object( AP + "pmarmor");
  move_object(armor,this_object());
}
