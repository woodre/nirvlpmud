#include <ansi.h>
#define WP "players/greg/weapons/"
#define AP "players/greg/armor/"
inherit "obj/monster";

reset(arg)
{
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name("guard");
   set_race("human");
  set_alias("guard");
	set_short( GRE + "A Green Guard" + WHT);
  set_long("This is one of the famous green guards found throughout this castle.\n"+
"He looks pretty well built for the middle ranked guard in the realm\n");
  set_level(14);
  set_hp(250);
  set_al(0);
  set_wc(17);
  set_ac(10);
   weapon=clone_object(WP + "pweap");
  move_object(weapon,this_object());
  armor=clone_object( AP + "parmor");
  move_object(armor,this_object());
}
