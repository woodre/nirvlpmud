#include "/players/greg/color.h"
com(str, pob) {
            object ob;
        string name;
string color;
	int x,lev1;
	lev1=pob->query_level();
        name=pob->query_real_name();
if (lev1<10)
	color=HIY;
else if (lev1<15)
	color=HIB;
else if (lev1<20)
	color=HIG;
else color=HIR;
            if(!str) {write("Tell what?\n"); return 1;}
               ob = users();
        name = capitalize(name);
                 for(x=0;x<sizeof(ob);x++){
if (ob[x]->query_guild_name()=="fracton")
{
         tell_object(ob[x], color+"<<{{{ " + name +
	 " }}}>> "+ NOR + str + "\n");
              }
	}
            return 1;
           }

