#include <ansi.h>

inherit "/obj/monster.c";

reset(arg) {
	::reset();
    if (arg)
        return;
	set_heart_beat(1);
	set_short(RED+"Delmar " + BLU + "The Wandering Guardian of the Blue World"+
WHT);
	set_long("This guy keeps things under control around here\n"+
        "He might be helpful but he also likes to take things\n"+
        "from people and rooms. He looks rather mean.\n"+
        "You DONT have any question about his authority.\n");
	set_alias("delmar");
	set_name("Delmar");
	set_level(10);
	set_hp(250);
	set_al(0);
	set_wc(10);
	set_ac(5);
}

random_move() 
{
	int n;
	if (present("corpse"))
	{
	move_object(present("corpse"),this_object());
	}
  n = random(5);
  if (n == 0)
    command("west");
  if (n == 1)
    command("east");
  if (n == 2)
    command("north");
  if (n == 3)
    command("south");
  if (n == 4)
    command("up");
  if (n == 5)
    command("down");
}

heart_beat()
{
	::heart_beat();
    steal();
	attack();
    if (random(5) > 0) random_move();
    if (attacker_ob && hit_point < (max_hp - 10))
       random_move();
}

steal()
{
    object ob, who;
    int weight;

    who = this_player();
    while(who) {
        if (who != this_object() && living(who) && random(2) == 0) {
            if (call_other(this_player(),"query_dex") < random (100))
                return;
            ob = first_inventory(who);
            if (ob == 0)
                return;
            transfer(ob, this_object());
            return;
        }
        who = next_inventory(who);
    }
}
