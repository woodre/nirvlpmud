#include <ansi.h>
#define GP "/players/greg/rooms/"
#define OB "/players/greg/objects/"
inherit "room/room";

reset(arg) {
        if(!arg) {
        set_light(1);
        short_desc = "The Orb Room";
       long_desc = "\n"+
	GRE +
	"The Orb Room\n" +
	YEL +
	"Cool lookin room, \n" +
	RED +
	"You feel a magical presence is about.\n" + WHT;

        dest_dir = ( {
            GP + "room1", "down",
                });
        }
}

init()
	{
	::init();
	add_action("create","create");
	return 1;
	}

	search(str1,str)
	{
	object ob,ob1;
         ob = first_inventory(this_player());
         while(ob) {
		ob1=ob;
	str=ob->pieceme();
		if (str==str1)
		{
	destruct(ob);
	return 1;
		}
		ob = next_inventory(ob1);
                }
        return 0;
	}

create(str)
	{
if ( (str=="orb") && (search("1")) && (search("2"))
&& (search("4")) && (search("5")) && (search("3")) )
		{move_object(clone_object(OB + "demortal"), this_player());
write("You have created the " + RED + "Deimmortalizer!!!\n\n" + WHT +
			"	You are very close to the end...\n" +
	"You must now search carefully for the god because\n" +
	"attacking the wrong one will lead to almost certain death!\n" +
	"\nKill the god and destroy the weapon which contains all\n"+
	"of his power.\n");
		return 1;
		}
	if (str=="orb")
	{
	search("2");search("3");search("4");search("5");
	write("You aint got it all! Bummer DUDE!\n"+
		"Now you have to start all over again... :) \n");
	return 1;
	}
	return 0;
	}
