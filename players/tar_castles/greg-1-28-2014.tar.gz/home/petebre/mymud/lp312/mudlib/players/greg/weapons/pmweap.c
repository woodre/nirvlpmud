#include <ansi.h>
inherit "obj/weapon";

reset(arg) {
   ::reset(arg);
  if(arg) return;
    set_name(RED + "A Super Tubular red sword" + WHT);
    set_alias("sword");
    set_short( RED + "A Super Tubular red paint sword" + WHT );
    set_long("This sword looks cool.\n"+
                "You can spaints <color>.\n");
     set_class(17);
     set_weight(5);
     set_value(3000);
     set_hit_func(this_object());
}
      init()
     {
      ::init();
       add_action("spaints","spaints");
        return 1;
        }
spaints(str)
                { write ("You paint your sword " + str + ". \n");
tell_room(environment(this_player()),this_player()->query_name() +
              "'s sword is painted "+ str +".\n");
if (str=="red")  { set_name( RED + "Super Tubular " +str+
" paint sword" + WHT);}
else if (str=="blue") { set_name( BLU + "Super Tubular "+ str +
 " paint sword" + WHT); }
else if (str=="yellow")  { set_name( YEL + "Super Tubular "+ str +
" paint sword" + WHT); }
else if (str=="green") { set_name( GRE + "Super Tubular "+ str +
 " paint sword" + WHT); }
else if (str=="white")   { set_name( WHT + "Super Tubular "+ str +
" paint sword" + WHT); }
else {set_name(RED + "Super Tubular "+BLU+str+
YEL+" paint "+GRE+"sword"+WHT);}
        set_short(query_name());
set_long("This sword looks cool.\n"+
                "You can spaints <color>.\n");
         return 1;
                }

weapon_hit(attacker) {
	object ob;
int i;
	ob=this_player()->query_attack();
i=random(10);
  if (i>8) {
       tell_room(environment(this_player()),this_player()->query_name()+
	" slashes through "+RED + "bones and guts!\n" + WHT);
       tell_room(environment(this_player()),RED + "Guts" + WHT +
		" are flying everywhere.\n");
	ob->reduce_hit_points(20);
    }
    if(i>5) {
	tell_room(environment(this_player()),this_player()->query_name()+
	"'s sword " + BLU +"splats paint "+WHT+"all over "+YEL+"you"+
	WHT+".\n");
	}
   return 1;
}

