#include <ansi.h>
#define AP "/players/greg/armor/"
#define WP "/players/greg/weapons/"
inherit "obj/monster";

reset(arg)
{
	object money;
  object weapon, armor;
  ::reset(arg);
  if(arg) return;
  set_name("monger");
  set_alias("monger");
  set_short( RED + "Red monger"+ WHT);
  set_long("Here is a really mean lookin colored guy.\n" +
	"Your prob surrounded by them cause they travel\n" +
	"in packs. They look pissed off!\n");
  set_level(12);
  set_hp(200);
  set_al(-5);
  set_wc(16);
 set_aggressive(1);
  set_ac(7);
  weapon=clone_object(WP + "mongerw");
  move_object(weapon,this_object());
  armor=clone_object( AP + "mongera");
  move_object(armor,this_object());
	money=clone_object("obj/money");
  call_other(money,"set_money",random(500));
  move_object(money,this_object());

}
