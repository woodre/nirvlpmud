#include "/players/greg/color.h"
com(str, pob, gobj) {
            object plyr;
	string name;
            string who;
            string what;
	name=pob->query_real_name();
            if(!str) {write("Tell what?\n"); return 1;}
            if(sscanf(str,"%s %s",who,what)==2){
               plyr = find_living(who);
               if(!plyr) {write(capitalize(who) + " is not online now.\n"); 
	return 1;
	}
	name = capitalize(name);
	gobj->c_last_tell(plyr);
                tell_object(plyr, HIR + name +
		" tells you -->> " + NOR + what + "\n");
               write("You tell "+capitalize(who)+": "+what+"\n");
               return 1;
              }
            write("Tell what to whom?\n");
            return 1;
           }
