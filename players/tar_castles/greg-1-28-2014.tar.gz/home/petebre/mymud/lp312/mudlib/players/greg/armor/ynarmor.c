#include <ansi.h>
inherit "obj/armor" ;

reset(arg)
{
  ::reset(arg) ;
        set_short( YEL + "Simple Yellow Armor" + WHT);
    set_long(YEL + "This is perfect for the newbie.\n"+WHT);
     set_ac(2);
     set_weight(2);
        set_value(50);
        set_alias("armor");
        set_name("armor");
        set_type("armor");
}

