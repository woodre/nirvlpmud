#include <ansi.h>
#define GP "players/greg/rooms/"
#define MP "players/greg/mons/"
inherit "room/room";

int i;

reset(arg) {
        if(!present("guard")) {
          for(i=0;i<4;i++) {
          move_object(clone_object(MP + "gguard"), this_object());
        }
    }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "Entrance to the Green realm" + WHT;
       long_desc = "\n"+
        GRE + "Entrance to the Green realm\n" +
	"     This a the medium difficulty area for mid to high level\n"+
	"players. There are lots of monsters around here to kill.\n"+
	"there should be enough to keep you busy. If not just go\n"+
	"to one of the other colored areas\n" + WHT;
        dest_dir = ( {
            GP + "room4c", "north",
            GP + "room4b" , "south",
            GP + "room1", "east",
	GP + "room4a", "west",
                });
        }
}
