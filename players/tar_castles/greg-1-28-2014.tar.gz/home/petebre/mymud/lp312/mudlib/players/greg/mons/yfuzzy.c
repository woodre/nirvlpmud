#include <ansi.h>
inherit "obj/monster";

reset(arg)
{
	object money;
  ::reset(arg);
  if(arg) return;
  set_name("fuzzy");
   set_race("human");
  set_alias("fuzzy");
  set_short( YEL + "A Yellow, fuzzy creature" + WHT);
  set_long(YEL + "It looks so cute, you just want to bash its brains in.\n" + WHT);
  set_level(2);
  set_hp(25);
  set_al(0);
  set_wc(5);
  set_ac(1);
	money=clone_object("obj/money");
  call_other(money,"set_money",random(20));
  move_object(money,this_object());

}
