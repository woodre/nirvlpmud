#include <ansi.h>
#include "std.h"

id(str) { return str == "crown"; }

long() {
        write( GRE + "A Green Crown\n" + WHT +
	"This crown doesn't seem like a crown\n"+
	"that ever belonged to the frog kingdom.\n"+
	"You feel that someone is out there searching for\n"+
	"this item....\n");
}

short() {
        return GRE + "A Green Crown" + WHT;
}

query_value()
{
    return 0;
}
pieceme()
	{
	return "8";
	}

get()
	{
    	return 1;
	}

drop()
{
	return 1;
	}
	
query_weight() {
    return 6;
}

