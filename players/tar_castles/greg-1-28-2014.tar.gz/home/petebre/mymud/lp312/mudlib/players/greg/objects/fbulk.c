#include <ansi.h>

flirtit(play1,str1,str2,ob,int1)
        {
	object ob1;
	if (play1)
	ob1=find_player(play1);
	if ( (str1) && (ob1))
	{
	if (environment(ob)==environment(ob1))
		{say(RED+ob->query_name()+BLU+str1+GRE+
		ob1->query_name()+YEL+str2+WHT+".\n",ob1);
        		tell_object(ob,RED+"You"+BLU+str1+
		GRE+ob1->query_name()+YEL+str2+WHT+".\n");
		tell_object(ob1,RED+ob->query_name()+BLU+str1+
		GRE+"you"+YEL+str2+WHT+".\n",);
		return 1;
		} else  {
		tell_object(ob,RED+"You"+BLU+str1+
		GRE+ob1->query_name()+YEL+str2+WHT+
		" from afar.\n");
		tell_object(ob1,RED+ob->query_name()+BLU+str1+
		GRE+"you"+YEL+str2+WHT+" from afar.\n");
		return 1;
		}
	}
	if (int1<2)
	{tell_room(environment(ob),RED+ob->query_name()+BLU+str1+GRE+str2+WHT+".\n");
	return 1;
	}
	write("You have to specify a player for that one.\n");
	return 1;
}

