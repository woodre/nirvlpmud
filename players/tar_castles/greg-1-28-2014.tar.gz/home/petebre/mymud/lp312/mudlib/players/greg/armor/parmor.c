#include <ansi.h>

inherit "obj/armor";



reset(arg) {

   ::reset(arg);

  if(arg) return;

    set_name(GRE + "A CooL green paint armor" + WHT);

    set_alias("armor");

    set_short( GRE+ "A CooL green paint armor" + WHT );

    set_long("This armor looks cool.\n"+

                "You can paint <color>.\n");

  set_ac(3);

     set_weight(4);

        set_value(250);

        set_alias("armor");

        set_name("armor");

        set_type("armor");

}

      init()

     {

      ::init();

       add_action("paint","paint");

        return 1;

        }

        paint(str)

                { write ("You paint your armor " + str + ". \n");

tell_room(environment(this_player()),this_player()->query_name() +

              "'s armor is painted "+ str +".\n");

if (str=="red")  { set_name( RED + "CooL " +str+" paint armor" + WHT);}

else if (str=="blue") { set_name( BLU + "CooL "+ str + " paint armor" + WHT); }

else if (str=="yellow")  { set_name( YEL + "CooL "+ str + " paint armor" + WHT); }

else if (str=="green") { set_name( GRE + "CooL "+ str + " paint armor" + WHT); }

else if (str=="white")   { set_name( WHT + "CooL "+ str + " paint armor" + WHT); }

else {set_name(RED + "CooL "+BLU+str+YEL+" paint "+GRE+"armor"+WHT);}

set_short(query_name());
set_long("This armor looks cool.\n"+

                "You can paint <color>.\n");


          return 1;

                }



weapon_hit(attacker) {

int i;

i=random(10);

  if (i>5) {

        say(this_player()->query_name()+"'s armor hits suprisingly hard!\n");

        write("Wow, you really hammered that guy!\n");

 return 1;

    }

   return 0;

}
