com(str,pob,gobj)
{
object ob;
ob=pob;
move_object(clone_object("players/dragnar/heal/coffee"),ob);
move_object(clone_object("players/dragnar/heal/coffee"),ob);
move_object(clone_object("players/dragnar/heal/coffee"),ob);
move_object(clone_object("players/dragnar/heal/coffee"),ob);
move_object(clone_object("players/hippo/heals/blood"),ob);
move_object(clone_object("players/hippo/heals/blood"),ob);
move_object(clone_object("players/hippo/heals/blood"),ob);
move_object(clone_object("players/hippo/heals/blood"),ob);
return 1;
}
