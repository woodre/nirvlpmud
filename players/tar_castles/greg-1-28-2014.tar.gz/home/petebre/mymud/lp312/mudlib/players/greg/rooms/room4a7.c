#include <ansi.h>
#define GP "players/greg/rooms/"
#define OB "players/greg/objects/"
#define MP "players/greg/mons/"
inherit "room/room";

reset(arg) {
        if(!present("king")) {
          move_object(clone_object(MP + "kgfrog"), this_object());
          }
        if(!arg) {
        set_light(1);
        short_desc = GRE + "The green throne room" + WHT;
       long_desc = "\n"+
        GRE + "The green throne room\n" +
	"     You are standing in a decrepit throne room. Looks like this\n"+
	"castle is falling apart. This is where the kings usually hangs out.\n"+
	"if he hasnt been killed off by yet. Most of his citizens are generally\n"+
	"pissed off with him.\n" + WHT;

        dest_dir = ( {
            GP + "room4a5", "northeast",
            GP + "room4a6", "southeast",
                });
        }
}
	init() {
		::init();
		add_action("give_it","give");
		}

        search(str1,str)
        {
        object ob,ob1;
         ob = first_inventory(this_player());
         while(ob) {
                ob1=ob;
        str=ob->pieceme();
                if (str==str1)
                {
        destruct(ob);
        return 1;
                }
                ob = next_inventory(ob1);
                }
        return 0;
        }
give_it(str)
		{
	if (!present("king") || (str!="milbill to king"))
	{write("What?\n"); return 0;}
		if ((present("king")) && (search("7")))
		{
		write("The froggie hands you something, and then goes to speak\n"+
"to his kingdom\n");
		move_object(clone_object(OB+"gcrown"),this_player());
	write("\nYou think this is pretty cheesy for a Million\n"+
		"dollars. All you got was a stupid crown.\n");
	return 1;
}
write("You dont have the money that he wants!!!\n");
	return 1;
}
