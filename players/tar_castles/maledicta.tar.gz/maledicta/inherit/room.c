#include "/room/clean.c"
/*
 * This is a proposal of a replacement to std.h. It is used with
 * 'inherit "room/room";'.
 * All global variables below are supposed to be setup by the reset()
 * in the function that inherits this file.
   Added set_room_type()  - see the variable below.
         read_mess = ({})  so you can set up a read command that works
                           like the items setup.  "sign", "Test sign.\n"....

 */

/* An array with destinations and directions: "room/church", "north" ... */
string *dest_dir;

/* Short description of the room */
string short_desc;

/* Long description of the room */
string long_desc;

/* Special items in the room. "table", "A nice table", "window", "A window" */
string *items;

/* Fact about this room. ex: "no_fight", "no_steal" */
string property;

/* Mob or no Mob */
int mobbed;

/* No castles are allowed to be dropped here */
int no_castle_flag;
int no_exits;

/* What type of room is this: Plain, Forest, Cave, City, Mountain, Hill, Water, Desert */
string room_type;

/* A setup for reading objects in the room. */
string *read_mess;

reset(){
set_light(1);
}


init() {
   int i;
   if (set_light(0) <= 0) {
      set_light(1);
      }
   if(random(100) < 10 && !mobbed){
   mobbed = 1;
   if(short_desc == "a large plain"){
   move_object(clone_object("/players/maledicta/cont/mobs/plain1.c"), this_object());
    }
   else if(short_desc == "a forest"){
   move_object(clone_object("/players/maledicta/cont/mobs/forest1.c"), this_object());
    }
   else if(short_desc == "foothills"){
   move_object(clone_object("/players/maledicta/cont/mobs/foot1.c"), this_object());
    }
   else{
   move_object(clone_object("/players/maledicta/cont/mobs/plain1.c"), this_object());
    }
   }
   else{
   mobbed = 1;
   }
   
   if (read_mess) {
        add_action("read"); add_verb("read");
    }
    
    if (!dest_dir)
	return;
    i = 1;
    while(i < sizeof(dest_dir)) {
	add_action("move", dest_dir[i]);
	i += 2;
    }
}


read(string str){
int i;
while(i < sizeof(read_mess)) {
    if(read_mess[i] == str){
	    write(read_mess[i+1]+"\n");
	    return 1;  }
    i += 2;
    }	    
}


id(str) {
    int i;
    if (!items)
	return;
    while(i < sizeof(items)) {
	if (items[i] == str)
	    return 1;
	i += 2;
    }
    return 0;
}

long(str) {
    int i;
    if (set_light(0) == 0){
       write("It is dark.\n");
       return;
    }
    if (!str) {
        if(short_desc)
        write(short_desc+"\n");
	write(long_desc);
if(!dest_dir || no_exits)
	    write("    No obvious exits.\n");
	else {
	    i = 1;
	    if (sizeof(dest_dir) == 2)
		write("    There is one obvious exit:");
	    else
		write("    There are " + convert_number(sizeof(dest_dir)/2) +
		      " obvious exits:");
	    while(i < sizeof(dest_dir)) {
		write(" " + dest_dir[i]);
		i += 2;
		if (i == sizeof(dest_dir) - 1)
		    write(" and");
		else if (i < sizeof(dest_dir))
		    write(",");
	    }
	    write("\n");
	}
	return;
    }
    if (!items)
	return;
    i = 0;
    while(i < sizeof(items)) {
	if (items[i] == str) {
	    write(items[i+1] + ".\n");
	    return;
	}
	i += 2;
    }
}

/*
 * Does this room has a special property ?
 * The 'property' variable can be both a string and array of strings.
 * If no argument is given, return the 'property' variable.
 */
query_property(str) {
    int i;
    if (str == 0)
	return property;
    if (!property)
	return 0;
    if (stringp(property))
	return str == property;
    while(i < sizeof(property)) {
	if (property[i] == str)
	    return 1;
	i += 1;
    }
    return 0;
}

move(str) {
    int i;
    i = 1;
    while(i < sizeof(dest_dir)) {
	if (query_verb() == dest_dir[i]) {
	    this_player()->move_player(dest_dir[i] + "#" + dest_dir[i-1]);
	    return 1;
	}
	i += 2;
    }
}

short() {
  int i;
  string temp;
    if (set_light(0))
	{
	  temp = short_desc + " [";
	  if (!dest_dir || no_exits) temp += "no exits";
	  else
	    for (i=1;i<sizeof(dest_dir);i+=2)
                {
	          temp += translate_exit(dest_dir[i]);
                  if (i < sizeof(dest_dir)-2) temp += ",";
		}
	  temp += "]";
          return temp;
	}
    return "Dark room";
}

translate_exit(str) {
  if (str == "north") return "n";
  if (str == "south") return "s";
  if (str == "east") return "e";
  if (str == "west") return "w";
  if (str == "northeast") return "ne";
  if (str == "northwest") return "nw";
  if (str == "southeast") return "se";
  if (str == "southwest") return "sw";
  if (str == "up") return "u";
  if (str == "down") return "d";
  return str;
}

query_dest_dir() {
    return dest_dir;
}

query_long() {
    return long_desc;
}

/*
 * Convert a number to a word. The array is being created by the
 * standard room/room, and shared by all rooms.
 */
string numbers;

convert_number(n) {
    if (!pointerp(numbers))
	numbers = query_numbers();
    if (n > 9)
	return "lot of";
    return numbers[n];
}

query_numbers() {
    if (!numbers) {
	if (file_name(this_object()) == "room/room")
	    numbers = ({"no", "one", "two", "three", "four", "five",
			    "six", "seven", "eight", "nine" });
	else
	    numbers = call_other("room/room", "query_numbers");
    }
    return numbers;
}

query_drop_castle() {
    return no_castle_flag;
}


set_room_type(string str){ room_type = str; }

query_room_type(){
string str;
if(!room_type) return str == "none"; 
return room_type;
}
