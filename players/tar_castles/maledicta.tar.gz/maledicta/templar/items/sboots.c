#include "/players/maledicta/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("boots");
set_short("squire's boots");
set_long(
"   A pair of black leather boots. They are lightweight and commonly\n"+
"given to squires for added protection.\n");
set_ac(1);
set_type("boots");  
set_weight(1);
set_value(50);
 
}

