#include "/players/maledicta/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("shield");
set_short("Templar Shield");
set_long(
"  This is the shield of the Templar Knights.  It prominently displays\n"+
"the red cross of the templars on a white background. Heavy leather\n"+
"straps are bolted to the backside allowing for ease of carry and use.\n");
set_ac(1);
set_type("shield");
set_weight(2);
set_value(500);

}

	
