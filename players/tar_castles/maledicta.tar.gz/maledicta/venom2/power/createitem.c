/*  Level 5 Creation Spell: createitem - Allows the Symb to make lightweight
weapons and armor that can be given out or used.  Cost is 70 mp +
100 sps.   Forms a ball of matter that they can then shape. */

#include "/players/maledicta/venom2/sdefine.h"


main(string str, object gob, object player)
{
	object woot;
	if(USER->query_ghost()) return 0;
	if(CRE < 5) return 0;
	if(GOB->query_mp() < 70){ tell_object(USER, "You are too low on "+BOLD+"Dark Matter"+NORM+" to perform that.\n"); return 1; }
	if(USER->query_sp() < 100){ tell_object(USER, "You lack the energy to perform a heal.\n"); return 1; }
	USER->add_spell_point(-100);
	GOB->add_mp(-70);
	tell_object(USER,
		"You hold out your hand and concentrate for a moment...\n"+
	"A creation ball of "+BOLD+"Dark Matter"+NORM+" forms in your upward turned palm.  Look at it to see how to use it.\n");
	tell_room(environment(USER),
	USER->query_name()+" closes "+USER->POS+" eyes and forms a ball of "+BOLD+"Dark Matter"+NORM+" in "+USER->POS+" palm.\n", ({USER}));
	woot = clone_object("/players/maledicta/venom2/OBJ/creationball.c");
	woot->set_who(USER->query_real_name());
	move_object(woot, USER);
	return 1;
}
