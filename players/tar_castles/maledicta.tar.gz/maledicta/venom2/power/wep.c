/*  Level 1 Combat Spell: Wep -   Uses the shapetype from the old and makes a
frontline spell attack vs. opponents.  +20 WC, No randomization because the
lib does it for us.  sp cost: 15    THIS IS THE MAIN SPELL - NOT Darts  */

#include "/players/maledicta/venom2/sdefine.h"


main(string str, object gob, object player)
{
	object target;
	int woot;
	string msg,msg2,msg3;
	int damage,spamount;
	string wep,where,how;
	if(USER->query_ghost()) return 0;
	if(COM < 1) return 0;
	if(USER->query_spell_dam()) return 1;
	if(GOB->query_spell_delay()){
		tell_object(USER,
		"You are already using "+GOB->query_spell_delay()+".\n");
		return 1;
	}
	if(USER->query_sp() < 15){
		tell_object(USER,
		"Your symbiotic link is too weak for that.\n");
		return 1;
	}
	if(!USER->query_attack()){
		tell_object(USER, "You are not fighting!\n");
		return 1;
	}
	
	switch(random(10) + 1){
		case 10:  wep = "BattleAxe"; break;
		case   9:  wep = "Spear"; break;
		case   8:  wep = "Sword"; break;
		case   7:  wep = "WarDagger"; break;
		case   6:  wep = "Whip"; break;
		case   5:  wep = "Claw"; break;
		case   4:  wep = "Mace"; break;
		case   3:  wep = "WarHammer"; break;
		case   2:  wep = "Maul"; break;
		case   1:  wep = "Scythe"; break;
	}
	switch(random(10) + 1){
		case  10: where = "head"; break;
		case    9: where = "hand"; break;
		case    8: where = "arm"; break;
		case    7: where = "leg"; break;
		case    6: where = "thigh"; break;
		case    5: where = "neck"; break;
		case    4: where = "shoulder"; break;
		case    3: where = "stomach"; break;
		case    2: where = "chest"; break;
		case    1: where = "chest"; break;
	}

   spamount = 15;
	damage = random(11) + 10;

	switch(damage){
		case 20:  how = HIR+"D e s t r o y e d"+NORM;
		case 17..19: how = HIR+"Butchered"+NORM;
		case 15..16: how = RED+"Crushed"+NORM;
		case 12..14: how = RED+"Struck"+NORM;
		case 10..11: how = BOLD+"Hit"+NORM;
		case 1..9:     how = "Hit";
	}
	tell_object(USER,
	COLOR+"<Weapon>"+NORM+" You shape your arm into a "+wep+"...\n");
	
	tell_object(USER,
	"You "+how+" "+ATTN+" with a "+BOLD+"Dark Matter"+NORM+" "+wep+" swing to the "+where+".\n");
	tell_room(environment(USER),
	USER->query_name()+" "+how+" "+ATTN+" with a "+BOLD+"Dark Matter"+NORM+" "+wep+" swing to the "+where+".\n", ({ USER }));
	msg = "";
	msg2 = "";
	msg3 = "";
	USER->spell_object(ATT, COLOR+"Dark Matter Weapon"+NORM, damage, spamount,
	msg, msg2, msg3);
	return 1;
}
