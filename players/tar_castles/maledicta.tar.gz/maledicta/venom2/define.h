#define SKEELLS "/players/maledicta/venom2/power/"

#define GUILDNAME "neo symbiote"

#define SAVE_PATH "players/maledicta/closed/save/"
#define SAVE_PATH2 "players/maledicta/venom2/member/backup/"
#define USER environment(this_object())
#define ENVU environment(USER)
#define UN USER->query_name()
#define attack USER->query_attack()
#define Attack User->query_attack()
#define ATT USER->query_attack()
#define ATTN ATT->query_name()
#define PO previous_object()
#define User environment(previous_object())
#define NAME USER->query_real_name()
#define Name User->query_real_name()
#define QN query_name()
#define POS query_possessive()   /*  his her  */
#define UP USER->POS
#define PRO query_pronoun()    /*  he she  */
#define UPR USER->PRO
#define OBJ query_objective()    /*  him her  */
#define UO USER->OBJ
#define TOU tell_object(User,
#define TRU tell_room(environment(User),
#define COLOR query_color()
