reset(arg){
if(arg) return;
	set_heart_beat(1);
	skills = ({ "cleanse", "absorbi", "burnoff", "heal", "regeneration",
			"feed", "suffocate", "wound", "wep", "darts", "ko", "fatal",
			"hypermode", "dominate", "block", "shapearmor", "alarm",
            "implant", "createball", "createitem", "lair", "place",
            "spikes"});
	tentacles = allocate(10);
       sh_armors = allocate(8);

  }

