#include "/players/maledicta/ansi.h"
inherit "obj/monster.c";
#define ATT this_object()->query_attack()
#define AAT this_object()->query_alt_attack()
reset(arg)  {
  ::reset(arg);
  if(arg) return;

set_name("golem");
set_alt_name("huge_golem");
set_race("golem");
set_short(""+HIW+"A Shadowstone Golem"+NORM+"");
set_long(
"  This huge magical creation is made from the most resistant and\n"+
"impenetrable stone ever found on the shadowplane. Its body is\n"+
"sculpted into a towering form, its head neckless and formed \n"+
"straight into its huge chest. Its arms are long and end in twin\n"+
"spiked balls, easily able to crush the life from any mortal. A\n"+
"single large gem can be seen where its eyes would be, its crystal\n"+
"surface glimmering with magical power.\n");
set_level(20);
set_hp(800);
set_al(0);
set_wc(40);
set_ac(20);
set_aggressive(0);
set_heart_beat(1);
set_a_chat_chance(25);
  load_a_chat("Your weapon rings out against the thick stone of the golem.\n");
  load_a_chat("The golem stomps toward you.\n");

set_dead_ob(this_object());
}


heart_beat(){
int hit_amount;
   ::heart_beat();

hit_amount = random(35)+10;
if(ATT){
  if(hit_amount > 30){
   tell_object(ATT,
   "Golem massacre you to small fragments.\n");
   tell_room(environment(),
   "Golem massacre "+ATT->query_name()+" to small fragments.\n", ({ATT}));
   ATT->hit_player(hit_amount);		   	 
   }
else if(hit_amount > 20){
   tell_object(ATT,
   "Golem smashed you with a bone crushing sound.\n");
   tell_room(environment(),
   "Golem smashed "+ATT->query_name()+" with a bone crushing sound.\n", ({ATT}));
   ATT->hit_player(hit_amount);
   }
else if(hit_amount > 13){
   tell_object(ATT,
   "Golem hit you very hard.\n");
   tell_room(environment(),
   "Golem hit "+ATT->query_name()+" very hard.\n", ({ATT}));
   ATT->hit_player(hit_amount);
   }
else{
   tell_object(ATT,
   "Golem missed you.\n");
   tell_room(environment(),
   "Golem missed "+ATT->query_name()+".\n", ({ATT}));
   }
 }
if(AAT){
if(AAT->is_pet() && random(100) < 50){
 tell_room(environment(),
 HIR+
 "The golem looks over at the small pet attacking it and smashes it to a bloody pulp!"+NORM+"\n");
 AAT->hit_player(1000);
   }
  }
 }

monster_died(){
object corpse;
object gold;
  corpse = present("corpse", environment()); 
  tell_room(environment(),
  "As the golem dies, its huge body falls to the ground smashing into a thousand\n"+
  "large pieces. A large amount of coins flows from its body and out onto the\n"+
  "floor. \n");	
 gold = clone_object("obj/money");
 gold->set_money(6000 + random(2000));
 move_object(gold,environment(this_object()));
 if(corpse)
    destruct(corpse);
return 1; }
					   	