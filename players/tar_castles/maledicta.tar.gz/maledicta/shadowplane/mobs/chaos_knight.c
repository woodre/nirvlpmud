#include "/players/maledicta/ansi.h"
inherit "obj/monster.c";
#define ATT this_object()->query_attack()
#define AAT this_object()->query_alt_attack()
reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("knight");
set_alt_name("chaos_knight");
set_race("unknown");
set_short(""+HIB+"C"+HIR+"h"+HIG+"a"+HIY+"o"+HIM+"s "+HIW+"Knight"+NORM+"");
set_long(
" A knight of chaos, this half-man half-beast, is fully armored\n"+
"with no part of its form showing. Its broad shoulders and huge\n"+
"barrel-like chest are held aloft by long thick legs, all of which\n"+
"are covered in heavy gray plates. A large double bladed axe is\n"+
"carried in its right gloved hand, its edge razor sharp and heavily\n"+
"enchanted. Spikes and steel chains cover the knights armor,\n"+
"clanking loudly with every step.\n");  
set_level(20);
set_hp(700);
set_al(0);
set_wc(15);
set_ac(35);
set_aggressive(0);
set_heart_beat(1);
set_chat_chance(10);
  load_chat("Chaos knight stares at you with pure hatred.\n");
  load_chat("The chaos knight slowly swings its battle axe back and forth.\n");
}


heart_beat(){
int hit_amount;
   ::heart_beat();
hit_amount = random(5) + 1;
if(random(100) < 35){
switch(hit_amount){
case 5..100:
    tell_object(ATT,
    "You are hit by a series of acidic arrows from the chaos knight!\n"+
    "                        "+HIG+"THUNK!"+NORM+"\n"+
    "                          "+HIG+"THUNK!"+NORM+"\n"+
    "                            "+HIG+"THUNK!"+NORM+"\n"+
    "                                You feel the acid burn into your skin!\n");
    ATT->hit_player(random(30) + 35);
break;
case 3..4:
   tell_object(ATT,
   "You feel an intense heat as flames flow up from the ground...\n"+
   "                 "+HIR+"WOOOOSH!!!"+NORM+"\n"+
   "          You body catches fire and burns!\n");
   ATT->hit_player(random(30) + 25);
break;
case 2:
   tell_object(ATT,
   "The "+HIW+"Chaos Knight"+NORM+" throws a series of small "+HIB+"electrical discs"+NORM+" from his hands..\n"+
   ""+HIY+"    PELT!"+HIB+"__--_-_-_---"+HIY+"PELT!"+HIB+"_-_----_-"+
   "__--"+HIY+"PELT!"+HIB+"___--__---_--_"+HIY+"PELT!"+HIB+"--__---__"+HIY+"PELT!"+HIB+"\n"+       
   ""+HIY+"  PELT!"+HIB+"____----_--_"+HIY+"PELT!"+HIB+"___---_-_--"+
   "--"+HIY+"PELT!"+HIB+"___----__--_-_"+HIY+"PELT!"+HIB+"---_---_-"+HIY+"PELT!"+HIY+"\n"+
   "PELT!"+HIB+"---_---__---"+HIY+"PELT!"+HIB+"___---_-_-___"+
   ""+HIY+"PELT!"+HIB+"---_-____---__"+HIY+"PELT!"+HIB+"--___---_"+HIY+"PELT!"+NORM+"\n"+
   "    You feel extreme pain from each disc as it pierces your body!\n");
   ATT->hit_player(random(40) + 30);
break;
case 1:
   tell_object(ATT,
   "A swirling cone of cold jets forth from the Knight...\n"+
   "              "+HIB+"FREEZING DEATH"+NORM+"\n"+
   "                      slams into you!\n");
   ATT->hit_player(random(35) + 20);
break;
default:
tell_object(ATT,
   "A swirling cone of cold jets forth from the Knight...\n"+
   "              "+HIB+"FREEZING DEATH"+NORM+"\n"+
   "                      slams into you!\n");
   ATT->hit_player(random(35) + 20);
break;
  }      
 }
}

					   	