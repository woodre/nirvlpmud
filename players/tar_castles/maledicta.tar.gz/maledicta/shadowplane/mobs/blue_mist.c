#include "/players/maledicta/ansi.h"
inherit "obj/monster.c";
#define ATT this_object()->query_attack()
#define AAT this_object()->query_alt_attack()
reset(arg)  {
object gold;
  ::reset(arg);
  if(arg) return;

set_name("mist");
set_alt_name("blue_mist");
set_race("unknown");
set_short(""+HIB+"Blue Mist"+NORM+"");
set_long(
"  This thick foglike thing floats about three feet off of the\n"+
"ground and swirls about lazily. It seems to have a certain\n"+
"amount of intelligence as it moves towards you slowly, drawn\n"+
"by something you aren't sure about.\n");
set_level(20);
set_hp(400);
set_al(0);
set_wc(20);
set_ac(20);
set_aggressive(0);
set_heart_beat(1);
set_chat_chance(10);
  load_chat("The blue mist changes shape and form continuously before your eyes.\n");
  load_chat("The mist moves towards you.\n");
set_dead_ob(this_object());
}


heart_beat(){
int hit_amount;
   ::heart_beat();
if(ATT && random(100) < 30){
  tell_object(ATT,
  HIB+
  "You are enveloped by the Blue Mist and feel it begin to drain all of your magical energy!"+NORM+"\n");
  ATT->add_spell_point(-(ATT->query_sp()));	
 }
}

monster_died(){
object corpse;
  corpse = present("corpse", environment()); 
  tell_room(environment(),
"As the blue mist is defeated, it disperses into nothing carried away by the wind.\n"+
"In its place you find a glowing ball.\n");

 move_object(clone_object("/players/maledicta/shadowplane/obj/essence.c"), 
 environment(this_object()));

 if(corpse)
    destruct(corpse);
return 1; }
					   	