#include "/players/maledicta/ansi.h"
inherit "obj/monster.c";
object attacked;
#define attacked (this_object()->query_attack())


reset(arg)  {
  ::reset(arg);
  if(arg) return;

set_name("archangel");
set_alt_name("battler");
set_race("archangel");
set_short(""+BOLD+"Archangel"+NORM+" "+HIB+"["+NORM+BLU+"Battler"+NORM+HIB+"]"+NORM+"");
set_long(
"This is an Archangel of the Order of the Noctis. It stands\n"+
"nearly seven feet tall, and is thin and well-muscled. Its\n"+
"skin is a deep black, and its eyes are burning blue.  It is\n"+
"bald, with no body hair at all. Huge black wings sweep out\n"+
"behind it, long feathers extending outward from them. This\n"+
"archangel wears a lightweight set of platemail, and wields\n"+
"a longsword that glows with a spectral light.\n");
set_level(20);
set_hp(600 + random(200));
set_al(-random(1000));
set_wc(28 + random(4));
set_ac(14 + random(5));
set_dead_ob(this_object());
set_chat_chance(5);
  load_chat("The Battler Angel stands watching your every move.\n");
  load_chat("The Archangels blue eyes flare slightly as it watches you.\n");
set_chance(25 + random(10));
set_spell_dam(35 + random(20));
set_spell_mess1(
""+BOLD+"Battler Angel"+NORM+" "+HIR+"---- - -- SLICES --- --- --"+NORM+BOLD+""+
" into its opponent!"+NORM+"\n");
set_spell_mess2(
"You fall back in terrible pain as the Battler Angel "+HIR+"SLICES"+NORM+" into you!\n");
}
  
heart_beat(){
  ::heart_beat(); 		
  if(attacker_ob && !random(5)){
     tell_room(environment(),
     "The Battler launches into the air!\n"+
     "     "+BOLD+" === "+NORM+HIY+"DIVE ATTACK "+NORM+BOLD+"==="+NORM+"\n");
     switch(random(3)+1){
      case 3..100: 
      tell_room(environment(),
      attacker_ob->query_name()+" is struck from overhead!\n");
      break;
      case 2:
      tell_room(environment(),
      attacker_ob->query_name()+" is pierced and driven to the ground!\n");
      break;
      case 1:
      tell_room(environment(),
      attacker_ob->query_name()+" is slammed to the ground!\n");
      break;
      default:
      tell_room(environment(),
      attacker_ob->query_name()+" is pierced and driven to the ground!\n");
      break;
      }
      attacker_ob->hit_player(30);
     }
     if(!random(10) && attacker_ob){
        tell_room(environment(),
        BOLD+"The Battler Angel *"+RED+"RAKES"+NORM+BOLD+"* "+attacker_ob->query_name()+""+
        " with its claws!"+NORM+"\n");
        attacker_ob->hit_player(10);
        }
     if(alt_attacker_ob && alt_attacker_ob != attacker_ob){
        tell_room(environment(),
     BOLD+"The Battler turns to "+alt_attacker_ob->query_name()+"..."+NORM+"\n"+
     "       "+RED+"~~~~"+NORM+HIR+"  Burning Hate"+NORM+RED+"  ~~~~"+NORM+"\n"+
     BOLD+alt_attacker_ob->query_name()+" falls back as their flesh burns!"+NORM+"\n");
     alt_attacker_ob->hit_player(50);
     }  
 }   



monster_died() {
  object corpse;
  int i;
  int feathers;
  feathers = random(3) + 1;
  corpse = present("corpse", environment()); 
  tell_object(attacked,
"The Battler Angel dies, falling to the ground. Its sword erupts into a\n"+
"burning ball of flame and melts away the armor and weapon, leaving no\n"+
"sign of either, as well as the Archangel that wore and wielded them.\n\n\n"+
"You do notice "+feathers+" feathers that have fallen from its wings.\n");
/*
for(i = 0; i < feathers; i ++){
  move_object(clone_object("/players/maledicta/shadowplane/treasure/feather.c"),
  environment(this_object()));
  }
*/
 if(corpse)
    destruct(corpse);
return 1; }
