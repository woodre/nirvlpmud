#include "/players/maledicta/ansi.h"
inherit "obj/monster.c";
#define ATT this_object()->query_attack()
object demon_item;
object demon_item2;
object demon_item3;
string item;
string item2;
string item3;

reset(arg)  {

  ::reset(arg);
  if(arg) return;

set_name("demon");
set_alt_name("shadow_demon");
set_race("demon");
set_aggressive(1);
set_heart_beat(2);

switch(random(11)){
  case 7..10:
    demon1();
    item = "/players/maledicta/shadowplane/obj/bloodgem.c";
    item2 = "/players/maledicta/shadowplane/obj/gem.c";
    item3 = 0;
   break;
  case 4..6:
    demon2();
    item = "/players/maledicta/shadowplane/obj/blood.c";
    item2 = "/players/maledicta/shadowplane/obj/gem.c";
    item3 = 0;
   break;
  case 2..3:
    demon3();
    item = "/players/maledicta/shadowplane/obj/blood.c";
    item2 = "/players/maledicta/shadowplane/obj/bloodgem.c";
    item3 = "/players/maledicta/shadowplane/obj/gem.c";
   break;
  case 1:
    demon4();
    item = "/players/maledicta/shadowplane/obj/dark_crystal.c";
    item2 = "/players/maledicta/shadowplane/obj/dark_crystal.c";
    item3 = 0;
   break;
  case 0:
    demon5();
    item = "/players/maledicta/shadowplane/obj/bloodgem.c";
    item2 = "/players/maledicta/shadowplane/obj/bloodgem.c";
    item3 = "/players/maledicta/shadowplane/obj/blood.c";
   break;
  default:
    demon1();
    item = "/players/maledicta/shadowplane/obj/bloodgem.c";
    item2 = "/players/maledicta/shadowplane/obj/gem.c";
    item3 = 0;
   break;
  }
if(item){
demon_item = clone_object(item);
move_object(demon_item,this_object());
  }
if(item2){
demon_item2 = clone_object(item2);
move_object(demon_item2,this_object());	
  }
if(item3){
demon_item3 = clone_object(item3);
move_object(demon_item3,this_object());	
  }
}	


                             
demon1(){
set_short(""+HIW+"ShadowDemon"+NORM+" "+BOLD+BLK+"-"+HIR+"mane"+NORM+""+BOLD+BLK+"-"+NORM+"");
set_long(
""+HIW+" This is a very small shadow demon. Its skin is black as night, and ripples\n"+
"slightly as light touches it. Deep blue eyes stare at you from within a head\n"+
"covered with small horns. Long sharp nails gleam and click together anxiously\n"+
"as this little creature begins to determine if you are its next meal."+NORM+"\n");
set_level(15);
set_hp(300);
set_ac(6);
set_wc(18);
set_al(-1000);
set_chance(20);
set_spell_dam(random(10)+10);
set_spell_mess1(
  "Shadow demon lashes out wildly with its clawed hands!\n");
set_spell_mess2(
  "The shadow demon lashes at you with its clawed hands!\n");

}

demon2(){
set_short(""+HIW+"ShadowDemon"+NORM+" "+BOLD+BLK+"-"+HIR+"guard"+NORM+""+BOLD+BLK+"-"+NORM+"");
set_long(

""+HIW+"  Standing before you, this huge black-skinned demon is covered with short\n"+
"horns and in some places, thick exoskeleton plates. Its head is huge, two\n"+
"long horns protruding from either side of its head, and deep blue eyes\n"+
"staring out from under thickskinned brows. Its large knuckles are tipped\n"+
"with wicked spikes, allowing for huge damage to anyone foolish enough\n"+
"to fight this beast."+NORM+"\n");
set_level(18);
set_hp(650);
set_ac(10);
set_wc(25);
set_al(-1000);
set_chance(25);
set_spell_dam(random(15)+20);
set_spell_mess1(
  "The Demon Guard slams its opponent with a double fisted bash!\n");
set_spell_mess2(
  "The Demon Guard slams you with a double fisted bash!\n");
}	

demon3(){
set_short(""+HIW+"ShadowDemon"+NORM+" "+BOLD+BLK+"-"+HIR+"knight"+NORM+""+BOLD+BLK+"-"+NORM+"");	
set_long(
""+HIW+"  This demon is tall and thin, its entire form built with strength and\n"+
"an unnatural power. Thick plates adorn its entire body, lending it an\n"+
"invulnerability to most normal attacks. Huge serrated bones extend from\n"+
"its forearms, acting as sharp blades, and capable of extreme damage. This\n"+
"creature is very powerful."+NORM+"\n");
set_level(20);
set_hp(800);
set_ac(16);
set_wc(32);
set_al(-1000);
set_chance(25);
set_spell_dam(random(20)+30);
set_spell_mess1(
  "The Demon Knight slashes at its opponent with it's twin arm blades!\n");
set_spell_mess2(
  "The Demon Knight slashes at you with its twin arm blades!\n");
}

demon4(){
set_short(""+HIW+"ShadowDemon"+NORM+" "+BOLD+BLK+"-"+HIG+"mage"+NORM+""+BOLD+BLK+"-"+NORM+"");
set_long(
""+HIW+"  Short and stocky, this demon is known for its uncanny ability to summon\n"+
"forth the powers of darkness and chaos. Its entire form is covered with a\n"+
"thick black skin, capable of protecting it from some damage. Its green eyes\n"+
"stare out with a barely contained evil power, its light flaring dangerously\n"+
"around the socket. Its hands are tipped with dangerous claws. The demon mage\n"+
"seems ready for combat."+NORM+"\n");
set_level(19);
set_hp(300);
set_ac(6);
set_wc(22);
set_al(-1000);
set_chance(45);
set_spell_dam(random(30)+40);
set_spell_mess1(
  "The Demon Mage unleashes a flury of shadow magic...\n\n"+
  "                 "+HIB+"DEVASTATING"+NORM+"\n\n"+
  "                           it's opponent with powerful forces!\n");
  
set_spell_mess2(
  "The Demon Mage unleashes a flury of shadow magic...\n\n"+
  "                 "+HIB+"DEVASTATING"+NORM+"\n\n"+
  "                          you with powerful forces!\n");
}

demon5(){
set_short(""+HIW+"ShadowDemon"+NORM+" "+BOLD+BLK+"-"+HIR+"titan"+NORM+""+BOLD+BLK+"-"+NORM+"");	
set_long(
""+HIW+" This creature is unbelievably huge. It stands at nearly fifty feet tall, its\n"+
"body muscled so completely that any strike from this creature would probably\n"+
"demolish nearly anything it came in contact with. Its blue eyes stare down\n"+
"with complete hatred for anything that is not of it realm."+NORM+"\n"); 
set_level(20);
set_hp(1000);
set_ac(12);
set_wc(45);
set_al(-1000);
set_chance(20);
set_spell_dam(random(30)+50);
set_spell_mess1(
  "The Demon Titan reaches out and....\n\n"+
  "                 "+HIR+"SLAMS"+NORM+"\n\n"+
  "                     it's opponent to a bloody pulp!\n");
set_spell_mess2(
  "The Demon Titan reaches out and....\n\n"+
  "                 "+HIY+"SLAMS"+NORM+"\n\n"+
  "                          you into oblivion!\n");
}

heart_beat(){
::heart_beat();		

  }		
		  	