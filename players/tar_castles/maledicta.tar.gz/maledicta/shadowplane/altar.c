#include "/players/maledicta/ansi.h"
#define PATH "/players/maledicta/shadowplane/rooms/"
#define PATH2 "/players/maledicta/shadowplane/obj/"
#define MO move_object
#define CO clone_object
#include "/players/maledicta/shadowplane/objects.h"

int altar_value;
int destination;
string where;

short(){ return BOLD+"The Altar of Sacrifice"+NORM; }

long(){
write(
"This is the great altar of sacrifice. Its surface is made\n"+
"of a smooth black onyx stone with numerous etchings carved\n"+
"into it. The carvings seem to be of a place in another\n"+
"reality similar to our own. It is rumored that by placing\n"+
"items of value onto the altar, you may 'invoke' it's power\n"+
"and open the portal to the shadowrealm.\n");
return 1;
}

query_weight(){ return 50000; }
query_value(){ return 0; }

reset(arg){
 if(arg) return;
/* make_em(); */
call_out("place_this", 1);
}

id(str){ return str == "altar" || str == "altar of sacrifice"; }


init(){
 add_action("place_items","place");
 add_action("invoke_altar","invoke");
 } 

invoke_altar(str){
if(!str){
 write("Invoke what?\n");
 return 1;
 }
if(str == "altar"){
 if(!altar_value){
  write("There is nothing on the altar!\n");
  return 1;
  }
 if(altar_value < 5000){
  write("The items on the altar are not valuable enough.\n");
  return 1;
  }
if(!destination){
  write("Something is wrong and the altar fails...\n");
  return 1; 
  }
altar_value = 0;
tell_room(environment(),
"The power of the altar is invoked...\n");
tell_room(environment(),
this_player()->query_name()+" vanishes from sight...\n", ({ this_player() }));
tell_object(this_player(),
"You feel your body phase out of existence and enter into the realm of shadows..\n");
move_object(this_player(), "/players/maledicta/shadowplane/rooms/"+where+"");
command("look", this_player());
tell_object(this_player(),
"You arrive in a place similar to where you were, yet darker and more foreboding...\n");
tell_room(environment(this_player()),
this_player()->query_name()+" phases into view...\n", ({ this_player() }));
return 1;
}
write("invoke what?\n");
return 1;
}

place_items(str){
    int i;
    string item;
    string container;
    object item_o;
    if (!str){
     write("place <item> on altar.\n");
     return 1;
     } 
   
   if (sscanf(str, "%s on altar", item) != 1) {
	write("place <item> on altar.\n");
	return 1;
      }
    
    item = lower_case(item);
    item_o = present(item, this_player());
    if (!item_o) {
	write("You have no " + item + "!\n");
	return 1;
      }
    if (call_other(item_o, "drop", 0))
	return 1;
    if (!item_o)
        return 1;
    i = call_other(item_o, "query_weight");
    if(item_o->query_weight() <= 0) {
      write("You cannot place that!\n");
      return 1;
      }
    if(item_o->query_value() < 100) {
      write("You cannot place that, it is not worth enough!\n");
      return 1;
      }
    if(item_o->query_value() < 1) {
      write("You cannot place that, it is worthless!\n");
      return 1;
      }
	/* Remove the weight from the previous container. */
	call_other(environment(item_o), "add_weight", -i);
	tell_room(environment(),
      this_player()->query_name()+" places something on the altar.\n");
	write("Ok.\n");
      altar_value += item_o->query_value();
 	destruct(item_o);
      return 1;
      }
 


place_this(){
destination = random(20) + 1;
if(destination == 20) where = "shore2";
else if(destination == 19) where = "sea_bottom";
else if(destination == 18) where = "eastroad1";
else if(destination == 17) where = "sunalley2";
else if(destination == 16) where = "inn";
else if(destination == 15) where = "lanceroad2";
else if(destination == 14) where = "yard";
else if(destination == 13) where = "forest2";
else if(destination == 12) where = "forest5";
else if(destination == 11) where = "orc_dump";
else if(destination == 10) where = "plane2";
else if(destination == 9) where = "plane7";
else if(destination == 8) where = "plane10";
else if(destination == 7) where = "plane9";
else if(destination == 6) where = "ravine";
else if(destination == 5) where = "mount_top2";
else if(destination == 4) where = "plane6";
else if(destination == 3) where = "townh";
else if(destination == 2) where = "southroad1";
else where = "southroad3";
tell_room(environment(),
"The altar becomes insubstantial and fades from view..."+where+"\n");
move_object(this_object(), "/room/"+where+""); 
tell_room(environment(),
"An altar swirls into view from the shadows.\n");
call_out("place_this", 1200);
}

