#include "/players/maledicta/ansi.h"
inherit "obj/weapon.c";

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("scimitar");
set_short(""+HIB+"a Scimitar ["+HIW+"energy weaver"+HIB+"]"+NORM+"");
set_long(
" This huge scimitar is tinted blue and seems to glow with an\n"+
"inner power. Its decorated hilt is covered with gold trim and\n"+
"brightly gleaming sapphires. Its blade is made of an unbreakable\n"+
"steel, and holds a razor edge.\n");
set_type("sword"); 
set_class(18);
set_weight(3);
set_value(5000);
set_hit_func(this_object());
}

weapon_hit(attacker){
if(random(100) < 20){
   write(
   ""+HIY+"A funnel of pure "+HIB+"ENERGY"+NORM+""+HIY+" jets out of your Scimitar, striking"+
   " "+attacker->query_name()+" in the chest!"+NORM+"\n");
   say(
   "A funnel of energy streams from "+environment(this_object())->query_name()+"'s scimitar!\n");
   return 8;
   }		
if(random(100) < 25){
   write(
   "Your Scimitar leaps out stabbing visciously into "+attacker->query_name()+"!\n");
   say(
   environment(this_object())->query_name()+" visciously stabs "+attacker->query_name()+"!\n");
   return 4;
   }
if(random(100) < 30){
	write(
" The Scimitar known as "+HIY+"Energy Weaver"+NORM+" slices into "+attacker->query_name()+"!\n");
say(
environment(this_object())->query_name()+" "+HIY+"SLICES"+NORM+" into "+
	""+attacker->query_name()+"!\n");
	return 3;
       }
return 0;
}  	
  	
