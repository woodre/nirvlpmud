#include "/players/maledicta/ansi.h"
inherit "obj/weapon.c";
#define USER environment(this_object())
#define NAME USER->query_name()
#define ATT attacker->query_attack()


int spell_saved;

reset(arg){
  ::reset(arg);
  if (arg) return;

set_name("axe");
set_short(""+HIW+"Axe of "+HIB+"C"+HIR+"h"+HIG+"a"+HIY+"o"+HIM+"s"+NORM+"");
set_long(
"  This is the axe used by the Chaos Knights. It is made from adamantium and\n"+
"its huge head holds a razor edge that is magically enhanced. The shaft and\n"+
"handle is made of a dark wood that is polished and nearly unbreakable. Small\n"+
"multicolored rings can be found between the handle and head, eight in all.\n");
set_type("axe"); 
set_class(18);
set_weight(4);
set_value(10000);
set_hit_func(this_object());
}

weapon_hit(attacker){
int damage;
damage = 0;

if(random(100) < 60){
switch(random(20) + 1){
case 19..20:
 write(
"The "+HIG+"green"+NORM+" band glows brightly as it unleashes healing powers to you.\n");
 say(NAME+
" is covered with a soft green glow.\n");
 USER->heal_self(random(5));
break;
case 15..18:
write(
"The "+HIB+"blue"+NORM+" band glows brightly for a moment, bathing you in a warm energy.\n");
say(NAME+
" is bathed in a soft blue light.\n");
 USER->add_spell_point(random(10) + 1);
break;
case 11..14:
write(
"The "+HIM+"purple"+NORM+" band sends a stream of energy into your body, you feel better.\n");
say(NAME+
" is struck by a small purple beam of energy.\n");
call_other(USER,"drink_alcohol",-(random(5)+1));
break;
case 7..10:
write(
"The "+HIY+"yellow"+NORM+" band glows softly bathing you in its light.\n");
say(NAME+
" is bathed in a yellow light.\n");
USER->drink_soft(-3);
USER->eat_food(-3);
break;
case 5..6:
write(
"The "+HIR+"red"+NORM+" band burns brightly sending harmless flames across your body.\n");
say(NAME+
" is covered in harmless flames.\n");
 USER->add_exp(random(100));
break;
case 1..4:
write(
"The "+BOLD+BLK+"black"+NORM+" band vibrates sending out waves of power.\n");
damage = 15;
break;
default:
write(
"The "+HIB+"blue"+NORM+" band glows brightly for a moment, bathing you in a warm energy.\n");
say(NAME+
" is bathed in a soft blue light.\n");
 USER->add_spell_point(random(10) + 1);
break;
  }
}	

if(!random(3)){
 write(
"You swing the Axe of Chaos with fury, cleaving into your enemy!\n");
 say(NAME+
"'s Axe cleaves through the air pulverizing "+USER->query_possessive()+" enemy!\n");
damage += random(5);
return damage;
   }
return 0;
}  	

	