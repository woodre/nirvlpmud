

shadow_peer(string str){

if(!str) return 0;
if(str == "outward"){
if(this_player()->query_attack()){
write("You are too distracted to do that!\n");
return 1;
}

tell_object(this_player(),
"    ---=====[You Peer Outward Through the Shadows]=====---\n\n");
move_object(this_player(), DEST);
command("look", this_player());
move_object(this_player(), this_object());
tell_object(this_player(), 
""+HIR+"You grimace in pain as the Shadow plane and Prime Material pull at you!"+NORM+"\n");
this_player()->hit_player(10);
return 1; }
return 0;
}

shadow_help(){
write(
         "\t"+BOLD+""+BLK+"________________________ ["+HIR+"Shadow Realm"+BOLD+""+BLK+"] _______________________\n");
write(
BOLD+BLK+"\t The Realm of Shadows holds many mysteries, some of great power\n"+
         "\tand some of even greater danger. As you travel through this\n"+
         "\trealm know that your body is one with the prime material plane,\n"+
         "\tthis meaning that when in this realm movement of any kind can\n"+
         "\tcause you pain as the two realms vie for control of your very\n"+
         "\texistence.\n"+
         "\t When looking around and searching the plane of shadows, the\n"+
         "\tfirst thing to remember is that although you can see something\n"+
         "\tmost of the time it isn't really there. Items, buildings, roads,\n"+
         "\tetc. are nothing more than illusions of what you know. Looking\n"+
         "\tat them will only show their true nature, illusions. When\n"+
         "\tyou do finally encounter something substantial, then beware.\n"+
         "\tWhat you can feel can kill you.\n"+
         "\t When in the Shadow Realm know that you will have a certain\n"+
         "\tamount of control over the area you exist in. The following\n"+
         "\tare powers available for you to call upon:\n\n"+
         "\t "+HIB+"peer outward "+BOLD+""+BLK+"- Will allow you to see out of the shadow realm\n"+
         "\t                and into the room that it mimics in the prime\n"+
         "\t                material plane.\n"+
         "\t "+HIB+"leave shadows"+BOLD+""+BLK+" - When used this power will allow you to step\n"+
         "\t                 from the Shadow Plane, on a one way trip, to\n"+
         "\t                 the Prime Material. Such a movement and shock\n"+
         "\t                 to the system can leave a person with a con-\n"+
         "\t                 siderable amount of damage, so beware.\n"+
         "\tOther noteworthy items: \n"+
         "\tFollowing another player is impossible unless you use\n"+
         "\t'feelfollow'.\n"+
         "\tWhen in the Shadowplane you will be able to attack and be attacked\n"+
         "\tby other players("+HIR+"Pk Area"+NORM+""+BOLD+""+BLK+").\n");
write(   "\t_______________________________________________________________"+NORM+"\n");
return 1;
}         
          
leave_here(string str){
if(!str){ return 0; }
if(this_player()->query_attack()){
write("You are too distracted to do that!\n");
return 1;
}
if(str == "shadows"){
write("You concentrate and step from the shadow plane and into the Prime-material.\n");
move_object(this_player(), DEST);
command("look", this_player());
this_player()->hit_player(random(50));
tell_object(this_player(),
HIR+"You cry out in agony as you step from the Shadow plane back to your own reality!"+NORM+"\n");
return 1;
   }
return 0;
}  

init(){
::init();
add_action("shadow_peer", "peer");
add_action("leave_here", "leave");
add_action("shadow_help","shadow_help");

this_player()->set_fight_area();
}

exit(){    if(this_player()) this_player()->clear_fight_area();     }	      