inherit "obj/treasure";
#include "/players/maledicta/ansi.h"
#define ATT this_player()->query_attack()
#define ATTN ATT->query_name()
#define WEP this_player()->query_weapon()

reset (arg) {
if(!arg){

  set_id("feather");
  set_short(BOLD+"a feather"+NORM+"");
  set_long(
  "This is the feather from an Archangel. It is unknown what effect\n"+
  "it will have, but it is said to carry mystical properties. It can\n"+
  "be snapped to release the inherent power that it carries.\n");
  set_weight(1);
  set_value(8000);
    }
  }

  init(){
  ::init();
  add_action("snap_this", "snap");
}

snap_this(string str){
if(!str){ write("snap what?\n"); return 1; }
if(str == "feather"){
write(
HIB+"You snap the feather and release the energy within!"+NORM+"\n");
switch(random(10) + 1){
  case 10..100:
  this_player()->heal_self(80);
  break;
  case 9:
  this_player()->drink_soft(-100);
  this_player()->eat_food(-100);
  break; 
  case 7..8:
  this_player()->add_spell_point(100);
  break;
  case 5..6:
  this_player()->add_hit_point(100);
  break;
  case 4:
  if(WEP){
  write(HIG+"The power of the feather flows along your arm and into your weapon!"+NORM+"\n");
  WEP->fix_weapon();
  WEP->set_misses(0);
  }
  else{
  write("Nothing happens.\n");
  }
  break; 
  case 2..3:
  this_player()->add_hit_point(50);
  this_player()->add_spell_point(50);
  break;
  case 1:
  if(this_player()->query_attack()){
  tell_room(environment(this_player()),
  this_player()->query_name()+" breaks the feather...\n"+
  "       "+HIR+" --- "+NORM+RED+"BURNING POWER"+NORM+HIR+" ---"+NORM+"\n"+
  "    "+ATTN+" falls back in pain!\n");
  ATT->hit_player(random(15) + 30);
  }
  else{
  write("Nothing happens.\n");
  }
  break;
  default:
  this_player()->add_hit_point(50);
  this_player()->add_spell_point(50);
  break;
 } 
destruct(this_object());
this_player()->recalc_carry();
return 1;
  }
return;
}