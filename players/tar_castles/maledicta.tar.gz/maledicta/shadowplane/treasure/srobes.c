#include "/players/maledicta/ansi.h"
#define USER environment()
#define ENV environment(USER)
#define ATT USER->query_attack()
inherit "obj/armor";

reset(arg) {
 ::reset(arg);
set_name("robe");
set_short(BOLD+"dark robe"+NORM);
set_long(
"This is a flowing black robe that was once worn by\n"+
"the dark druid.  It is torn in a few places, but\n"+
"otherwise is in good condition. As you look closely\n"+
"you see that it has a darker pattern of fiber weaved\n"+
"throughout its fabric.\n");
set_ac(2);
set_type("armor");
set_weight(1);
set_value(1000);
}

do_special(owner){
 int abonus;
 
 if(random(100) < 5 && USER->query_hp() > 100){
    abonus = 3;
    tell_room(ENV,
    BOLD+"SHADOWS EXPLODE...\n\n"+
    "' '' ' '' ' ''   ' ' ' ' ' ' ' '  ' ' '' ' '  ' '  ' ' ' '' ' ' '\n"+
    " ' ' ' ' ' ''  ' ''  '' '' ' ' '' '' ''' ' ' '   ' ' ' ' ' '''  '\n"+
    "' ' ' ' '' '' '  ' ' ' ' '' '' ' ' ' ' ' ' '' ' ' ' ' ' ' ' ' ' '\n");
    tell_room(ENV,
    "' ' '' '' '' '  ' ' ' ' ' '' ' ' '''' ' ' ' ' ' ' ' ' ' ' ''  '''\n"+
    "'' '' '' ' ' ' ' '  ' ' '  ' ' ' ' ''' ' ' ' ' ' ' ' ' ' '' ''' '\n"+
    "''' ' ' ' ' ' ' ' ' ' ' ' ' ' '''  ' ' ' ' ' ' ' '''' ' ' ' ' ' '\n");
    tell_room(ENV,
    "'' '' ' ' ' '' '  ' ' ' ' '' ' '' ' ''' ' ' ' ' ' ' '' ''' ' ' ' \n"+
    "' ' '  ' ' ' ' ' ' ' ' ' ''' ' ' ' ' '' ' ' ' ' ' ' ' '''' '  ' '\n"+
    "'''' ' '  ' ''  '' ''  ' '' ' ' ' ' ' ' ' ''' ' ' ' ' ' ' ' ' ' '\n");
    tell_room(ENV,
    "''   ' ' ' ' ' ' '''  ' ' ' ''' ''''' ' ' ' ' ' ' ' ' ' ' ' ' '''\n"+
    "''' ' ' ' ' '' ' '' ' ' ' '' ' ' ' ' ' ' ''' ' ' ' ' ''  '''' ' '\n"+
    "' ' '' ' ' ' ''' ' ' ' ' ' ' ''' ''  ' ' ' ' ' '''' ' ' ' '' ' ' \n");
    tell_room(ENV,
    "' '' '' ' ' ''' ' ' '' ' ' ' ' '''' ' ' ' '' ''' ' ' '' ' ' ' ' '\n"+
    "''' ' ' ' ' ''' ' ' ' ' ''' ' ' '' ''' ' ' ' ' ' ' '' ' ' ' ' ' '\n"+
    "'' ' ' ' ' ''' ' ' ' '' ' '' ' ' ' '''' ' ' ' ' ' ' ' ' ' ' ' '''\n");
    tell_room(ENV,
    "      ------ - - --- - DEATH REIGNS --- - --- - - ---            "+NORM+"\n");
    USER->add_hit_point(-5);
    if(ATT->is_npc())
     ATT->heal_self(-(random(6) + 5));
    else
     ATT->add_hit_point(-(random(6) + 5));
    }
 else{
    switch(random(10) + 1){
     case 10..100:
     abonus = 1;
     tell_object(USER,
     BOLD+"Your robes swirl around you protectively..."+NORM+"\n");      
     break;
     case 9:
     abonus = 1; 
     tell_object(USER,
     BOLD+"The weaving patterns on your robes darken, absorbing light..."+NORM+"\n");
     break;
     case 7..8:
     abonus = 0;
     tell_object(USER,
     BOLD+"Your robes sweep backwards, flowing behind you in an invisible wind!"+NORM+"\n");
     break;
     case 6:
     abonus = -2;
     tell_object(USER,
     BOLD+"You feel a strong emotion flow from the power of your robes...\n"+
     "You grow ANGRY and charge ahead without fear!"+NORM+"\n");
     break;
     case 3..5:
     abonus = 1;
     tell_object(USER,
     BOLD+"Your robes whip about you confusing your enemy!"+NORM+"\n");
     tell_object(ATT,
     BOLD+USER->query_name()+"'s robes whip into your face confusing you!"+NORM+"\n");
     break;
     case 2:
     abonus = 2;
     tell_object(USER,
     BOLD+"You rise up on invisible currents of darkness, the power of your\n"+
     "robes carrying you into the air and defending you!"+NORM+"\n");
     tell_object(ATT,
     BOLD+USER->query_name()+" is lifted into the air as you are assaulted\n"+
     "by strong forces of Shadow!"+NORM+"\n");
     break;
     case 1:
     abonus = -1;
     tell_object(USER,
     BOLD+"Your robes whip about oddly and you are jerked towards your opponent!"+NORM+"\n");
     break;
     default:
     abonus = -1;
     tell_object(USER,
     BOLD+"Your robes whip about oddly and you are jerked towards your opponent!"+NORM+"\n");
     break;
     }
  }
return abonus;
}