/* This armor is used to help carry by having a 0 weight. It has an ac of 3, but is
   offset by a high cost: 50000 coins.                                                */

#include "/players/maledicta/include/setac.h"
#include "/players/maledicta/ansi.h"
#define USER environment(this_object())
#define ATT USER->query_attack()

inherit "obj/armor";
int armor_wear;
string wear_mess;
reset(arg) {
set_name("armor");
set_long(
"  A huge suit of reddish steel armor. It covers the main body providing\n"+
"excellent protection from any attack. The armor seems to be vibrating\n"+
"slightly.\n");
set_alias("demonmail");
set_short("a Full Suit of DemonMail");
set_ac(5);
set_type("armor");
set_weight(5);
set_value(8000);
}


do_special(owner){
if(ATT->query_spell_dam() && !ATT->is_npc()){
tell_object(USER, 
"Your armor vibrates as it absorbs part of your opponents spell!\n");
USER->add_hit_point(ATT->query_spell_dam()/4);
  }	
}	
	