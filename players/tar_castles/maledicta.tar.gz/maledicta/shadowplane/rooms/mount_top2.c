#define DEST "/room/mount_top2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are on a large, open plateau on top of the mountain.\n"+
"The view is fantastic in all directions and the clouds\n"+
"that rush past above feels so close you could almost\n"+
"touch them. The air here is fresh and clean."+
""+NORM+"\n";

items = ({
  "mountain",
  "A huge mountain that perfectly mimics the prime material plane",
  "clouds",
  "A shadowy imitation of puffy white clouds, only carrying a darkness that\n"+
  "is reminiscent of this land",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/mount_top","west",
});

}

