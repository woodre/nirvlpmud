#define DEST "/room/mount_top"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are on top of a mountain. There is a small plateau to the\n"+
"east."+
""+NORM+"\n";

items = ({
  "mountain",
  "A huge mountain that perfectly mimics the prime material plane",
  "plateau",
  "A flat plateau of stone, it is a perfect mimickry of the prime-\n"+
  "material plane",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/ravine","down",
  "/players/maledicta/shadowplane/rooms/mount_top2","east",
});

}

