#define DEST "/room/vill_shore"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are on a road going out of the village. Eastroad runs north from here,\n"+
"along the eastern perimeter of the city, and to the south are some fields\n"+
"planted with all the crops that the city needs. The main road runs towards\n"+
"the shore to the east, and into the city to the west."+
""+NORM+"\n";

items = ({
  "crops",
  "Tall crops that reach out into the surrounding fields, all of which is\n"+
  "is nothing more than illusion",
  "fields",
  "Huge illusionary fields of crops",
  "road",
  "A broad road made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_road3","west",
  "/players/maledicta/shadowplane/rooms/jetty","east",
  "/players/maledicta/shadowplane/rooms/eastroad1","north",
  "/players/maledicta/shadowplane/rooms/crop","south",
});

}

