#define DEST "/room/pub2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in the local pub.\n"+
"A large sign here says:\n"+
"WE RESERVE THE RIGHT TO CHANGE PRICES WITHOUT NOTICE\n\n"+
"You can order drinks here.\n\n"+
"     First class beer    :  10 coins\n"+
"     Cup of coffee       :  20 coins\n"+
"     Special of the house: 150 coins\n"+
"     Firebreather        : 230 coins\n"+
""+NORM+"\n";

items = ({
  "sign",
  "A wooden sign that is readable even though it is insubstantial",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/yard","west",
});

}

