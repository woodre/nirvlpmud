#define DEST "/room/mount_pass"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in a pass going into the mountain with a steep slope\n"+
"upwards to the north.\n"+
"However, the path is barred.\n"+
"There is a tunnel entrance to the north.\n"+
"It might be possible to climb up, though."+
""+NORM+"\n";

items = ({
  "pass",
  "A shadowy pass leading into the mountains, it mimics perfectly the\n"+
  "prime-material plane",
  "mountain",
  "A huge mountain that perfectly mimics the prime material plane",
  "path",
  "A narrow dirt path leading into the illusionary mountains",
  "entrance",
  "A dark illusion of an entrance that doesn't truly exist",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/plane11","south",
  "/players/maledicta/shadowplane/rooms/ravine","up",
});

}

