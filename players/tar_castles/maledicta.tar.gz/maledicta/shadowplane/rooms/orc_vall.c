#define DEST "/room/orc_vall"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in the orc valley. This place is inhabited by orcs.\n"+
"There is a fortress to the north, with lot of signs of orcs."+
""+NORM+"\n";

items = ({
  "fortress",
 "A huge shadowy fortress that perfectly mimics the one in the prime-material\n"+
 "plane",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/slope","east",
  "/players/maledicta/shadowplane/rooms/orc_dump","west",
});

}

