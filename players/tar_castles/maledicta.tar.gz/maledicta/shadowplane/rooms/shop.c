#define DEST "/room/shop.c"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in a shop. You can buy or sell things here.\n" +
"Commands are: 'buy item', 'sell item', 'sell all', 'list', 'list weapons'\n"+
"'list armors' and 'value item'.\n" +
"There is an opening to the north, and some shimmering\n" +
"blue light in the doorway.\n"+
"To the west you see a small room."+
""+NORM+"\n";

items = ({
"opening",
  "An opening in an illusionary wall that leads nowhere",
  "doorway",
  "A shadowy doorway that leads nowhere", });
dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_road2","south",
  "/players/maledicta/shadowplane/rooms/storage","west",
  "/players/maledicta/shadowplane/rooms/ptroom","east",
});

}

