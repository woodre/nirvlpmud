#define DEST "/room/southroad2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A road running north south through the village, there looks like there is\n"+
"an intersection to the south."+
""+NORM+"\n";

items = ({
  "road",
  "A broad road made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/southroad1","north",
  "/players/maledicta/shadowplane/rooms/southroad3","south",
});

}

