#define DEST "/room/lanceroad2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are on the recently paved Lance Road.  The front entrance to the post\n"+
"office is to the north. Lance road continues to the east and west."+
""+NORM+"\n";

items = ({
 "road",
  "A broad road of stone, which is nothing more than a shadowy illusion\n"+
  "here",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/lanceroad3","east",
  "/players/maledicta/shadowplane/rooms/lanceroad1","west",
  "/players/maledicta/shadowplane/rooms/post","north",
});

}

