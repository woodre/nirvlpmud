#define DEST "/room/crop"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in the middle of the fields where the city grows all its crops.\n"+
"A road runs north of here."+
""+NORM+"\n";

items = ({
  "fields",
  "An illusionary field of crops that has no form or substance",
  "crops",
  "Shadowy stalks sway around you, without substance",
  "road",
  "A small road made of dirt and some stones, it is a shadowy illusion of\n"+
  "the prime-material plane",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_shore","north",
});
}

