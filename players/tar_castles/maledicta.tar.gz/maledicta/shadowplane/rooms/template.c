#define DEST "/room/"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
+
""+NORM+"\n";

items = ({
  "",
  "A shadowy mockery of an item that exists only in the prime-material\n"+
  "plane, here it is nothing more than an insubstantial image",
  "",
  "A shadowy mockery of an item that exists only in the prime-material\n"+
  "plane, here it is nothing more than an insubstantial image",
  "",
  "A shadowy mockery of an item that exists only in the prime-material\n"+
  "plane, here it is nothing more than an insubstantial image",
  "",
  "A shadowy mockery of an item that exists only in the prime-material\n"+
  "plane, here it is nothing more than an insubstantial image",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/","",
  "/players/maledicta/shadowplane/rooms/","",
  "/players/maledicta/shadowplane/rooms/","",
  "/players/maledicta/shadowplane/rooms/","",
});

}

init(){
::init();
add_action("shadow_peer", "peer");
add_action("leave_here", "leave");
add_action("shadow_help","shadow_help");
}
	