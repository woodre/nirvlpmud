#define DEST "/room/storage"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in a small and dusty storage room.\n"+
"You can see the shop through the opening to the east."+
""+NORM+"\n";

items = ({
  "opening",
  "A shadowy mockery of an item that exists only in the prime-material\n"+
  "plane, here it is nothing more than an insubstantial image",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/shop","east",
});

}

