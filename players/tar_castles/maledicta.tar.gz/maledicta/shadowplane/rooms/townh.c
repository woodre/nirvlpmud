#define DEST "/room/townh"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"This is the town council chambers.\n"+
"Here will be posted issues\n"+
"for players to vote upon.\n"+
"Look at the notices to see what is\n"+
"there.\n"+
"Your vote will only be counted ONCE.\n"+
"If you vote MORE than once, the actual vote will be RANDOMLY\n"+
"from all your votes made (or discounted)."+
""+NORM+"\n";

items = ({
  "notices",
 "Dark papers that have no substance here",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/church.c","south",
  
});

}

