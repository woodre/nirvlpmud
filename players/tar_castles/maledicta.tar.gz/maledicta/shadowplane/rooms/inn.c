#define DEST "/room/inn"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in the Eastroad Inn. Here you can buy food to still your\n"+
"hunger, but only a limited selection is available."+
""+NORM+"\n";

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/eastroad5","east",
});

}

