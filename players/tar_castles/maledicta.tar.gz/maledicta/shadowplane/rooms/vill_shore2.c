#define DEST "/room/vill_shore2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"The village shore. A jetty leads out to the east. To the north some stairs\n"+
"leads down to the north beach. A road starts to the west."+
""+NORM+"\n";

items = ({
  "stairs",
  "Shadowy stairs made of stone, that lead nowhere",
 "road",
  "A broad road made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/jetty","west",
  "/players/maledicta/shadowplane/rooms/farmroad2","south",
  "/players/maledicta/shadowplane/rooms/jetty2","east",
});

}

