#define DEST "/room/vill_road3"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A long road going east and west through the village. To the northwest is\n"+
"the main shop, to the southwest the adventures guild. There is a cross road\n"+
"heading north and south, with what looks like a bunch of small shops to the\n"+
"north."+
""+NORM+"\n";

items = ({
  "road",
  "A broad road made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  "shops",
  "Illusionary buildings that mimic the same that exist in the prime-material\n"+
  "plane",
  "shop",
  "An illusionary building that mimics the same that exist in the prime-\n"+
  "material plane",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_shore","east",
  "/players/maledicta/shadowplane/rooms/northroad1","north",
  "/players/maledicta/shadowplane/rooms/southroad1","south",
  "/players/maledicta/shadowplane/rooms/vill_road2","west",
});

}

