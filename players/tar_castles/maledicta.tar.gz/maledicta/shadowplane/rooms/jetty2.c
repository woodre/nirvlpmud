#define DEST "/room/jetty2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are at a jetty. The waves rolls in from east.\n"+
"A small path leads back to west."+
""+NORM+"\n";

items = ({
  "waves",
  "Silent waves that are created to mimic the prime-material plane",
  "path",
  "A small dirt path mimicking the prime-material plane",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_shore2","west",
  "/players/maledicta/shadowplane/rooms/sea","east",
});

}

