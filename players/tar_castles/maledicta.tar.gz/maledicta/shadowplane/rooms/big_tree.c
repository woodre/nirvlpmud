#define DEST "/room/big_tree"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A big single tree on the plain."+
""+NORM+"\n";

items = ({
  "tree",
  "A large oak tree that stands tall, it is solid and yet an illusion at the\n"+
  "same time",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/plane7","east",
});

}

