#define DEST "/room/orc_dump"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You notice a very foul stench in this area. You can see something burning\n"+
"to the west. Nothing seems to growing here, there are only a few dead trees.\n"+
"There are piles of trash and other debris all around you. This must be the.\n"+
"place where the orc dispose of their trash."+
""+NORM+"\n";

items = ({
  "trees",
  "Shadowy dead trees that are immaterial in form",
  "trash",
  "Strewn about, it is immaterial with no substance",
  "debris",
  "Strewn about, it is immaterial with no substance",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/orc_vall","east",
});

}

