#define DEST "/room/eastroad5"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"East road runs south from here.\n"+
"To the west lies the Eastroad Inn."+
""+NORM+"\n";

items = ({
  "inn",
  "A large illusionary inn which can be entered. It is made of wood and stone",
  "road",
  "A broad road made of stone, it is a simple illusion that mimics the prime-\n"+
  "material plane",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/eastroad4","south",
  "/players/maledicta/shadowplane/rooms/inn","west",
});

}

