#define DEST "/room/police"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"This is the town police station. Here is where the peace keepers\n" +
"gather. Everything looks well kept and in order.  There is a small bared\n"+
"cell to the west and benches along the east wall.\n"+
"The station looks quite old."+
""+NORM+"\n";

items = ({
  "cell",
  "Made with steel and stone, it is used to keep criminals inside, but\n"+
  "here it is nothing but illusion, holding nothing",
  "benches",
  "Wooden benches that line the wall, they are purely illusional",
  "wall",
  "A stone wall that is not solid",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/southroad1","east",
});

}

