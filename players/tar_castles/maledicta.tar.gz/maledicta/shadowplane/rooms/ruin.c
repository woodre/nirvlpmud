#define DEST "/room/ruin"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A very old looking ruin. There is no roof, and no door."+
""+NORM+"\n";

items = ({
  "ruin",
  "A dark illusion surrounding you of a structure",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/plane4","south",
  "/players/maledicta/shadowplane/rooms/plane8","north",
  "/players/maledicta/shadowplane/rooms/plane9","east",
  "/players/maledicta/shadowplane/rooms/plane3","west",
});

}

