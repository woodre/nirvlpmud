#define DEST "/room/ptroom"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"This room looks like a meeting area. Adventurers gather here to form\n" +
  "parties to go out and seek their fortune in groups rather than alone.\n" +
  "If there is no party object here press the button on the wall.\n"+
  "If you wish to form a party, have the player you want to be your leader\n"+
  "pick up the party object and add members and set shares to make the party."+
""+NORM+"\n";

items = ({
  "button",
  "A solid looking button among items that are mostly insubstantial",
  "wall",
  "A stone wall that mimics the one in the prime-material plane",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/shop.c","west",
});
}

