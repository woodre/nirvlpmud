#define DEST "/room/clearing"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A small clearing. There are trees all around you.\n" +
"However, the trees are sparse to the north."+
""+NORM+"\n";

items = ({
  "trees",
  "Large illusionary trees that hold no substance in this realm",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/forest1","east",
  "/players/maledicta/shadowplane/rooms/forest2","west",
  "/players/maledicta/shadowplane/rooms/plane1","north",
});

}

