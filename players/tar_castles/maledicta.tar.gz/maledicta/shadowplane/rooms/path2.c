#define DEST "/room/path2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"This is a narrow foot path leading uphill towards the village church.\n"+
"It has long been used as a short cut for villagers living on the east end\n"+
"of Lance road.  The path continues to the south with the track to the north."+
""+NORM+"\n";

items = ({
  "path",
  "A narrow dirt path that is an illusion",
  "road",
  "A wide paved road that is purely an illusion",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/path1","south",
  "/players/maledicta/shadowplane/rooms/vill_track","north",
});

}

