#define DEST "/room/lanceroad1"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are walking along the recently paved Lance Road. You notice a hole\n"+
"in the road off to the side where village workers have already cut up the\n"+
"new pavement to get at a pipe or something. Lance road continues to the\n"+
"east and west."+
""+NORM+"\n";

items = ({
  "road",
  "A broad road of stone, which is nothing more than a shadowy illusion\n"+
  "here",
  "hole",
  "A dark hole in the ground which doesn't truly exist",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/southroad3","east",
  "/players/maledicta/shadowplane/rooms/lanceroad2","west",
  "/players/maledicta/shadowplane/rooms/new_alley","northwest",
});

}

