#define DEST "/room/pub3"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in the local pub.\n"+
"You can order drinks here.\n\n"+
"     First class beer    : 24 coins\n"+
"     Special of the house: 162 coins\n"+
"     Firebreather        : 242 coins\n"+
""+NORM+"\n";

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/alley","north",
});

}

