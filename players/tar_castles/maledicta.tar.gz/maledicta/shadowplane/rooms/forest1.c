#define DEST "/room/forest1"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in a big forest."+
""+NORM+"\n";

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/wild1.c","east",
  "/players/maledicta/shadowplane/rooms/clearing","west",
});

}

