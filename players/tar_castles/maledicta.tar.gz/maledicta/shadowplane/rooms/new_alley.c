#define DEST "/room/new_alley"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"This is alley running along the east side of the post office. To the north\n"+
"you see the rear of the adventurer's guild building. The alley runs to the\n"+
"Lance road to the southeast and the well to the northwest."+
""+NORM+"\n";

items = ({
  "alley",
  "A dark illusion of an alley that runs between two shadowy buildings",
  "building",
  "An illusion of a stone building",
  "road",
  "A broad road of stone, which is nothing more than a shadowy illusion\n"+
  "here",
  "well",
  "An illusion of a stone well, its form is insubstantial",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/narr_alley","northwest",
  "/players/maledicta/shadowplane/rooms/lanceroad1","southeast",
});

}

