#define DEST "/room/church"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in the local village church.\n"+
"There is a huge pit in the center,\n"+
"and a door in the west wall. There is a button beside the door.\n"+
"This church has the service of reviving ghosts. Dead people come\n"+
"to the church and pray.\n"+
"There is a clock on the wall."+NORM+"\n";

items = ({
  "pit",
  "A large pit made of stone, here in the shadow plane it is nothing more\n"+
  "than a shadowy object with no substance",
  "door",
  "A metal door leading to an elevator. It is nothing more than a shadowy\n"+
  "illusion",
  "button",
  "A simple plastic button, here though, it is nothing more than a dark\n"+
  "illusion",
  "clock",
  "A large clock made of wood and steel, it is nothing more than a dark\n"+
  "illusion here",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_green.c","south",
  "/players/maledicta/shadowplane/rooms/townh.c", "north",
});

}

