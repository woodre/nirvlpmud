#define DEST "/room/plane6"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A large open plain."+
""+NORM+"\n";

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/plane3","south",
  "/players/maledicta/shadowplane/rooms/plane11","north",
  "/players/maledicta/shadowplane/rooms/plane8","east",
  "/players/maledicta/shadowplane/rooms/plane10","west",
  
});

}

