#define DEST "/room/northroad1"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A road running north and south through the village, This seems to be the   \n"+
"start of the business district. There is a bank to the east as well as other"+
"\nshops and "+
"buildings along both sides of the street."+
""+NORM+"\n";

items = ({
  "road",
  "A broad stone road that is a perfect mimickry of the prime-material planes",
  "buildings",
  "Shadowy stone buildings that do not truly exist here",
  "shops",
  "Shadowy stone buildings that do not truly exist here",
  "bank",
  "A dark shadowy building representing the bank of the prime-material plane",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_road3","south",
  "/players/maledicta/shadowplane/rooms/northroad2","north",
  "/players/maledicta/shadowplane/rooms/bank","east",
});

}

