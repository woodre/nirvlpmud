#define DEST "/room/bank"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"To the east is a low counter. The counter is covered\n" +
	 "with heavy iron bars. On the wall beside the counter, a door\n" +
	 "leads further east"+
""+NORM+"\n";

items = ({
  "door",
  "A solid looking wooden door, here though it is insubstantial and can easily\n"+
  "be walked through",
  "counter",
  "A low counter made of wood, it is solid though only in the prime-material\n"+
  "plane",
  "bars",
  "Large steel bars that were once used to keep people away, now they are\n"+
  "as solid as wisps of smoke",
  "wall",
  "A long wall that is a shadowy illusion here",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/northroad1","west",
  "/players/maledicta/shadowplane/rooms/bankroom","east",
});

}


	