#define DEST "/room/eastroad1"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"The East Road runs north-south. Sitting off to the west is a temple.\n"+
"You can hear the clashing of weapons from beyond the temple's high\n"+
"granite walls, and menacing bronze gate."+
""+NORM+"\n";

items = ({
  "road",
  "A broad road paved with stone. Here though it is a shadowy form that\n"+
  "has no solidity",
  "temple",
  "A large temple made of stone. Here though it is a shadowy form that is\n"+
  "as substantial as a portrait",
  "walls",
  "A high granite wall that is a complete illusion in this realm",
  "gate",
  "A bronze gate that is insubstantial and illusionary",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/eastroad2","north",
  "/players/maledicta/shadowplane/rooms/vill_shore","south",
});

}

