#define DEST "/room/plane3"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A large open plain. There is some kind of building to the east."+
""+NORM+"\n";

items = ({
  "building",
  "A shadowy structure that is without solidity",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/plane2","south",
  "/players/maledicta/shadowplane/rooms/plane6","north",
  "/players/maledicta/shadowplane/rooms/ruin","east",
  "/players/maledicta/shadowplane/rooms/plane7","west",
});

}

