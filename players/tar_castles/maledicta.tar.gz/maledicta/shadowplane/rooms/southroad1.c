#define DEST "/room/southroad1"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A road running north and south through the village, This seems to be the \n"+
"start of the housing district. There is a police station to the west."+
""+NORM+"\n";

items = ({
  "road",
  "A broad road made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  "station",
  "An illusionary building made of stone",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_road3","north",
  "/players/maledicta/shadowplane/rooms/police","west",
  "/players/maledicta/shadowplane/rooms/southroad2","south",
});

}

