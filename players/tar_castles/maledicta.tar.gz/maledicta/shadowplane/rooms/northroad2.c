#define DEST "/room/northroad2"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A road running north and south through the village business district. There\n"+
"are shops and other buildings on both sides.\n"+
"There is a trail to the arena to the northeast."+
""+NORM+"\n";

items = ({
  "buildings",
  "Shadowy stone buildings that do not truly exist here",
  "shops",
  "Shadowy stone buildings that do not truly exist here",
  "arena",
  "A large stone arena that is purely illusional here\n",
  "trail",
  "A small dirt trail leading to the illusionary arena",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/northroad1","south",
  "/players/maledicta/shadowplane/rooms/northroad3","north",
});

}

