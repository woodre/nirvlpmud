#define DEST "/room/farmroad1"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are on a deeply rutted north-south road used by the farmers to tend\n"+
"the various crops grown to feed the villagers."+
""+NORM+"\n";

items = ({
  "road",
  "A road that has been used alot, it is made of dirt and deeply rutted. It\n"+
  "is a simple illusion of reality",
  "crops",
  "Tall crops that mimic the hard work of the villagers in the prime-material\n"+
  "plane",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/lanceroad4","west",
  "/players/maledicta/shadowplane/rooms/farmroad2","north",
});

}

