#define DEST "/room/jetty"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are on a road going out of the village. To the east the road widens out\n"+
"as it leads down to the shore. To the west lies the city."+
""+NORM+"\n";

items = ({
  "road",
  "A small paved road leading out of the illusionary village",
  "city",
  "A shadowy illusion of a town that exists in the prime-material plane",
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_shore","west",
  "/players/maledicta/shadowplane/rooms/vill_shore2","east",
});

}

