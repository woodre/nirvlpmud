#define DEST "/room/vill_track"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A track going into the village. The track opens up to a road to the east\n" +
"and ends with a green lawn to the west. There is a foot path to the south."+
""+NORM+"\n";

items = ({
  "track",
  "A narrow track made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  "road",
  "A broad road made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  "lawn",
  "A dark illusionary lawn of grass",
  "path",
  "An illusionary dirt path that leads south",
  
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_green","west",
  "/players/maledicta/shadowplane/rooms/vill_road1","east",
  "/players/maledicta/shadowplane/rooms/path2","south",
});

}

