#define DEST "/room/vill_road1"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A long road going east through the village. The road narrows to a\n"+
"track to the west. There is an alley to the north and the south."+
""+NORM+"\n";

items = ({
  "road",
  "A broad road made of stone, it seems to be without substance and mimics\n"+
  "the one in the prime-material plane perfectly",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_track","west",
  "/players/maledicta/shadowplane/rooms/yard","north",
  "/players/maledicta/shadowplane/rooms/narr_alley","south",
  "/players/maledicta/shadowplane/rooms/vill_road2","east",
});

}

