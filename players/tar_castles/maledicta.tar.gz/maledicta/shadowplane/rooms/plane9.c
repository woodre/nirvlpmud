#define DEST "/room/plane9"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"A large open plain. There is a river to the east,\n"+
"and some kind of building to the west"+
""+NORM+"\n";

items = ({
  "river",
  "A fast running river that is nothing but pure illusion",
  "building",
  "A dark stone structure that has no substance"
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/ruin","west",
  
});

}

