#define DEST "/room/ravine"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You are in a ravine between mountains. It seems to be possible\n"+
"to go up from here."+
""+NORM+"\n";

items = ({
  "ravine",
  "A shadowy illusion of a ravine running between the mountains",
  "mountains",
  "Large illusionary mountains without substance",
  
});

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/mount_pass","down",
  "/players/maledicta/shadowplane/rooms/mount_top","up",
  
  
});

}

