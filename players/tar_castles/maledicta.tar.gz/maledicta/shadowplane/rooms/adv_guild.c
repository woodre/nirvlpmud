#define DEST "/room/adv_guild"

#define tp this_player()
#define tpn this_player()->query_name()
#define tpp this_player()->query_possessive()
#include "/players/maledicta/ansi.h"
#include "/players/maledicta/shadowplane/include/scommands.h"
inherit "room/room";

reset(arg) {
  if(arg) return;
set_light(0);

short_desc = "a dark room";
long_desc =
""+BOLD+""+BLK+""+
"You have to come here when you want to advance your level.\n" +
   "You can also buy points for a new level.\n" +
   "Commands: cost, advance, list (number).\n" +
    "raise <str, sta, wil, mag, pie, ste, luc, int>\n" +
    "There are some stairs leading up to the second level.\n" +
   "There is an opening to the south, and some shimmering\n" +
   "blue light in the doorway."+
""+NORM+"\n";

items = ({
  "stairs",
  "A set of wooden stairs that have no substance here, and cannot be used\n"+
  "to reach the top floor",
  "doorway",
  "An opening in the black illusionary wall. It leads nowhere",
  });

dest_dir = ({
  "/players/maledicta/shadowplane/rooms/vill_road2","north",
});

}

