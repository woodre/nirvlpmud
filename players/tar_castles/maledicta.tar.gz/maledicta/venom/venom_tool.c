#include "/players/zeus/closed/all.h"
#define ATT ppl[i]->query_attack()
#define ATTN ATT->query_name()
#define VENOM present("venom_object", ppl[i])
#define PLAYER find_living(who)
#define PATH "/players/maledicta/logs/tool/"
#define FC present("venom_object", PLAYER)
#define VENOB clone_object("/players/maledicta/venom/venom")

inherit "obj/treasure";
#include "/players/maledicta/ansi.h"

reset (arg) {
if(!arg){

  set_id("tool");
  set_short("The Venom Tool");
  set_alias("venom_tool");
  set_long("Usage: \n"+
           "        vwho        - Will list all symbiotes on.\n"+
           "        vforce <who> <what> - Force a symbiote to do an action.\n"+
           "        envenom <who>       - Creates a symbiote.\n"+
           "        vname <who> <what>  - Names a symbiote.\n");
   }  }

  init(){
  ::init();

  add_action("whonew", "vwho");
  add_action("force_venom", "vforce");
  add_action("create_venom", "envenom");
  add_action("name_venom", "vname");  
  add_action("add_mp", "mpup");
  }

  add_mp(str){
	  object vwho;
	  vwho = find_living(str);
      present("venom_object", vwho)->add_mp(300);
	  write("done.\n");
	  return 1;
  }

	  
force_venom(string str){
string who;
string what;	
if(sscanf(str, "%s %s", who, what) == 2){
if(!who || !what) return 0;
if(!PLAYER){
  write("Cannot find that person.\n");
  return 1;
  }
if(!FC){
  write("That person is not a symbiote.\n");
  return 1;
  }
  write_file("/players/maledicta/log/tool/FORCE", ctime(time())+" "+TP->QRN+": "+who+" "+what+"\n");
  write("You force "+who+" to "+what+".\n");
  command(what, PLAYER);
  return 1;
  }
return 1;
}		

create_venom(string str){
object who;
  who = find_living(str);
  if(!who){
  write("You cannot find them.\n");
  return 1;
  }
  
  if(who->query_guild_name() && who->query_guild_name() != 0){
  write("They are guilded.\n"); return 1; }
  if(who->query_guild_rank()){ write("They are guilded.\n"); return 1; }
  if(who->query_guild_exp()){ write("They are guilded.\n"); return 1; }
  		
  write_file("/players/maledicta/log/tool/VENOM", ctime(time())+"  "+TP->QRN+": "+str+"\n");
  write("You make "+str+" into a venom.\n");
  if(who->query_exp() > 5885) {
     who->add_exp(-(who->query_exp() - 5885));
     who->set_level(5);
     who->set_extra_level(0);
     } 
     if(who->query_attrib("str") > 14){
     who->set_attrib("str", 14);
     }
     if(who->query_attrib("mag") > 5){
     who->set_attrib("mag", 5);
     }
     if(who->query_attrib("ste") > 14){
     who->set_attrib("ste", 14);
     }
     if(who->query_attrib("wil") > 14){
     who->set_attrib("wil", 14);
     }
     if(who->query_attrib("sta") > 14){
     who->set_attrib("sta", 14);
     }
     if(who->query_attrib("luc") > 14){
     who->set_attrib("luc", 14);
     }
     if(who->query_attrib("pie") > 14){
     who->set_attrib("pie", 14);
     }
     if(who->query_attrib("int") > 14){
     who->set_attrib("int", 14);
     }
     who->save_me();
     who->reset();
  move_object(VENOB, who);
  present("venom_object", who)->save_venom();
  write("done.\n");
return 1;
}		

name_venom(string str){
string who;
string what;	
if(sscanf(str, "%s %s", who, what) == 2){
if(!who || !what) return 0;
if(!PLAYER){
  write("Cannot find that person.\n");
  return 1;
  }
if(!FC){
  write("That person is not a symbiote.\n");
  return 1;
  }
  write_file("/players/maledicta/log/tool/NAME", ctime(time())+" "+TP->QRN+": "+who+" "+what+"\n");
  write("You name "+who+" "+what+".\n");
FC->set_symbiote(what);
  return 1;
  }
return 1;
}		


whonew(){
 object* ppl;
  int i;
  ppl = users();
  write(
"Name:         \n");	
  for(i = 0; i < sizeof(ppl); i++){
    if(present("venom_object", ppl[i])){	
  tell_object(this_player(),
ppl[i]->query_real_name()+" "+VENOM->query_mp()+" "+VENOM->query_symbiote()+"\n");
  if(VENOM->query_venomed()){
  tell_object(this_player(),
	  "Changed\n"); }
	}
   }
write("\n");
return 1;
}


drop(){
return 1;
}
can_put_and_get(){
return 1;
}		
