/* This Code is directly adapted from the Power Ranger Guild Weapon.
   Special Thanks to Beck for supplying it.
   updated sept 29th                         */
   
static status wielded;
static object wielded_by;
static int broke;
static int eff_wc;
static int misses,hits;
static int save_flag,class_of_weapon;
static object hit_func;
static string type;
static string *message_hit;
weapon_class() {
   return class_of_weapon;
}
hit(attacker)
{
   if (hit_func)
      return call_other(hit_func,"weapon_hit",attacker);
   return 0;
}
set_class(c) { class_of_weapon = c; }
weapon_breaks(){
   if(broke) return 1;
   return 1;
}
count_misses() {
   misses += 1;
   return 1;
}
count_hit_made(w) {
   hits += 1;
   eff_wc=((hits-1)*eff_wc + w)/hits;
   return 1;
}
query_wear() {
   return 0;
}
add_wear(arg) {
   misses = 0;
   hits = 0;
}
fix_weapon() {
   if (!broke) {
      return 0;
   }
   broke = 0;
   return 1;
}
re_break() { 
   broke = 1;
   return 1;
}

query_broke(){return broke;}

query_pro_weapon(){ return 1;}

proficiency_hit(ob){

string mess1,mess11,mess2,mess22;
int base;
int shapedam;
int dam1, dam2, dam3, dam4;
int rand1, rand2, rand3, rand4;
dam1 = 0;
dam2 = 0;
dam3 = 0;
dam4 = 0;
rand1 = random(100);
rand2 = random(100);
rand3 = random(100);
rand4 = random(100);
shapedam = random(5) + 1;
base = random(USER->query_attrib("str"));	
if(base < 12) base = 12;
if(base > 16) base = 16;

if(bitestat > 100 && random(1000) < 5){
bitestat -= 1;
}
if(slamstat > 100 && random(100) < 5){
slamstat -= 1;
}

if(hardened){
base -= 4;
return base;
}

if(frenzy_attack){
base += frenzy_attack;
}

if(shaped && shapetype != "shield"){
if(shapetype == "sword"){
switch(random(10)){
case 7..100:
mess1 = "slash";
mess11 = "slashes";
break;
case 4..6:
mess1 = "stab";
mess11 = "stabs";
break;
case 1..3:
mess1 = "slice";
mess11 = "slices";
break;
default:
mess1 = "stab";
mess11 = "stabs";
break;
 } 
}
else if(shapetype == "spear"){
switch(random(10)){
case 7..100:
mess1 = "stab";
mess11 = "stabs";
break;
case 4..6:
mess1 = "impale";
mess11 = "impales";
break;
case 1..3:
mess1 = "thrust";
mess11 = "impales";
break;
default:
mess1 = "impale";
mess11 = "impales";
break;
 } 
}
else if(shapetype == "axe"){
switch(random(10)){
case 7..100:
mess1 = "chop";
mess11 = "chops";
break;
case 4..6:
mess1 = "cleave";
mess11 = "cleaves";
break;
case 1..3:
mess1 = "slash";
mess11 = "slashes";
break;
default:
mess1 = "slash";
mess11 = "slashes";
break;
 } 
}
switch(random(10)){
case 7..100:
mess2 = "chest";
break;
case 4..6:
mess2 = "arm";
break;
case 1..3:
mess2 = "leg";
break;
default:
mess2 = "arm";
break;
 } 
if(mess1 && mess2 && USER->query_attack() && random(100) < USER->query_attrib("str") + USER->query_attrib("ste")){
 tell_object(USER,
""+HIR+"<"+HIW+shapetype+NORM+HIR+">"+NORM+" You "+mess1+" "+attack->query_name()+" in the "+mess2+"!\n");
 tell_room(environment(USER),
USER->query_name()+" "+mess11+" "+attack->query_name()+" in the "+mess2+" with his "+shapetype+" arm!\n", ({USER}));
}
 ATT->heal_self(-(shapedam));
 ATT->add_spell_point(shapedam);
 }


if(rand1 < (1 + USER->query_level())){
  dam1 = slamtwo();
   }
else if(rand1 < (25 + USER->query_level())){
  dam1 = bitetwo();
   }
else if(rand1 < (30 + USER->query_level())){
  dam1 = kicktwo();
   }
else if(rand1 < (50 + USER->query_level())){
  dam1 = clawstwo();
  }
if(USER->query_level() > 9){
 if(rand2 < (25 + USER->query_level())){
  dam2 = bitetwo();
   }
else if(rand2 < (35 + USER->query_level())){
  dam2 = kicktwo();
   }
 else if(rand2 < (55 + USER->query_level())){
  dam2 = clawstwo();
  }
} else{ dam2 = 0; }

if(hyper_mode){
if(rand3 < (10 + USER->query_level())){
  dam3 = slamtwo();
   }
else if(rand3 < (40 + USER->query_level())){
  dam3 = bitetwo();
   }
else if(rand3 < (60 + USER->query_level())){
  dam3 = kicktwo();
   }
else if(rand3 < (75 + USER->query_level())){
  dam3 = clawstwo();
  }	  

if(rand4 < (10 + USER->query_level())){
  dam4 = slamtwo();
  }
else if(rand4 < (40 + USER->query_level())){
  dam4 = clawstwo();
  }	
else if(rand4 < (60 + USER->query_level())){
  dam4 = bitetwo();
   }
else if(rand4 < (75 + USER->query_level())){
  dam4 = kicktwo();
   }
base += 10; 
} 		
damage_bonus = dam1 + dam2 + dam3 + dam4;

 if(damage_bonus > 0){
 
   base += damage_bonus;
  }
 
 if(attack && attack->webbed()){
 base += random(USER->query_level()/2);
 }
 return base;	
}


query_message_hit(tmp) {
  string *mess;

 if (tmp > 55) {
  mess = ({message_hit[1],message_hit[0]}); 
  }
  else if (tmp > 45){
  mess = ({message_hit[3],message_hit[2]});
  }
  else if (tmp > 35){
  mess = ({message_hit[5],message_hit[4]});
  }
  else if (tmp > 30) {
  mess = ({message_hit[7],message_hit[6]});
  }
  else if (tmp > 25) {
  mess = ({message_hit[9],message_hit[8]});
  }
  else if (tmp > 20) {
  mess = ({message_hit[11],message_hit[10]});
  }
  else if (tmp > 10) {
  mess = ({message_hit[13],message_hit[12]});
  }
  else if (tmp > 5) {
  mess = ({message_hit[15],message_hit[14]});
  }
  else if (tmp > 3) {
  mess = ({message_hit[17],message_hit[16]});
  }
  else if (tmp > 1) {
  mess = ({message_hit[19],message_hit[18]});
  }
  else if (tmp == 1){
  mess = ({message_hit[21],message_hit[20]});
  }
  
  return mess;
}


 	            
