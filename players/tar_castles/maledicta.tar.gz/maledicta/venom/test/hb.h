/* updated sept 29th */

heart_beat(){
int rate;

	if(!environment())
		return ;
	if(!USER->is_player())
		return ;
      if(USER->query_ghost()) return;

/***** Caps MP ***********************************/
  if(mp > 300) mp = 300;
  if(mp < 1) mp = 0;
/*************************************************/

/***** HB counter for logs ***********************/
if(USER->query_attack()){
  hb_count +=1;
}

/***** Symbiote Coward drawback ******************/
if(venomed && USER->query_attack() && (USER->query_hp()*10)/(USER->query_mhp()) < 3){
if(((USER->query_intoxination() * 2) + random(100)) > 
((USER->query_attrib("wil")*3)+ random(100))){
command("changeform", USER);
command("drop all", USER);
move_object(clone_object("/players/maledicta/venom/OBJ/ouch.c"), environment());
tell_object(USER,
"\n\n"+
HIR+capitalize(symb_name)+" screams in fear as it retreats back into your spine!"+NORM+"\n\n");
 }
}
/*************************************************/

/********* Bite delay ****************************/
if(bite_delay) bite_delay -= 1;
if(anti_webs) anti_webs = 0;
/************ MP monitor while in combat *********/
if(USER->query_attack() && venomed){
tell_object(USER,
HIW+"  MP   [  "+mp+"/300  ]"+NORM+"  ");

if(regen){
tell_object(USER,
HIR+" [Regen "+NORM+"ON"+HIR+"]"+NORM+"");
}
if(burnoff){
tell_object(USER,
HIG+"  [Burnoff "+NORM+"ON"+HIG+"]"+NORM+"");
}
if(hyper_mode){
tell_object(USER,
HIB+"  [Hypermode "+NORM+"ON"+HIB+"]"+NORM+"");
}
tell_object(USER,
"\n");
/*
if(frenzy_level >= 60){
tell_object(USER, ""+HBGRN+"|  |"+NORM+"  "+HBGRN+"|  |"+NORM+"  "+HBGRN+"|  |"+NORM+"   ["+HIG+"3"+NORM+"]\n");
}
else if(frenzy_level > 39){
tell_object(USER, ""+HBGRN+"|  |"+NORM+"  "+HBGRN+"|  |"+NORM+"   ["+HIG+"2"+NORM+"]\n");
}
else if(frenzy_level > 19){
tell_object(USER, ""+HBGRN+"|  |"+NORM+"   ["+HIG+"1"+NORM+"]\n");
}
else{
tell_object(USER, "\n");
} */
}
/*************************************************/


/****** If mp drops below 10 the symbiote will take 50 hps to survive ******/
if(mp < 10){
tell_object(USER,
"You feel a horrible pain as the symbiote feeds from your flesh to survive!\n");
USER->hit_player(150);
mp += 10;
}	        
/***************************************************************************/

/**** infusion hurts a symbiote ******************/
if(USER->query_infuse() && !random(4) && venomed){
tell_object(USER,
""+HIR+"The infusion within your body eats away at your symbiote, you feel great pain!"+NORM+"\n");	
USER->heal_self(-(5 + random(5)));
if(USER->query_hp() <= 0){
USER->hit_player(1000);
   }
}
/*************************************************/



/****** Burn off *********************************/

if(burnoff && USER->query_hp() < 50){
tell_object(USER,
"Your body can no longer sustain the burnoff process...\n");
burnoff = 0;
}

if(burnoff){
if(USER->query_hp() > 50 && random(100) > 24){
if(USER->query_intoxination()){
USER->add_intoxination(-1);
USER->add_hit_point(-1); 
  }
 }
if(USER->query_hp() > 50 && random(100) > 24){
if(USER->query_stuffed()){
USER->add_stuffed(-1);
}
if(USER->query_soaked()){
USER->add_soaked(-1);
}
USER->add_hit_point(-1);
}
if(!random(3)){
tell_object(USER, "You feel the waste in your body begin to dissipate...\n");
 }
}
/*************************************************/

if(regen && USER->query_sp() < 50){
	tell_object(USER,
    "Not enough energy to regen, stopping the regeneration process...\n");
	regen = 0;
}

/********* Regeneration **************************/
if(regen > 0){
if(random(2)){
USER->add_hit_point(1);
USER->add_spell_point(-1);
tell_object(USER, 
""+capitalize(symb_name)+" slowly mends your wounds...\n");
  }
}
/*************************************************/


/****** Stop hypermode when dead *****************/
if(hyper_mode && USER->query_ghost()){
hyper_mode = 0;
}
/*************************************************/	
	
	
/****** Hypermode attack *************************/
if(hyper_mode){
	if(hyper_mode && !USER->query_attack()){
		hyper_mode -= 10; }
	else{	
	hyper_mode -= 1;
        }
        if(hyper_mode < 0) hyper_mode = 0;
  if(!random(3) && !USER->query_attack()){
  switch(random(5)){
  case 4..100:
  tell_room(environment(USER),
  ""+USER->query_name()+"/"+capitalize(symb_name)+" flies wildly about the room in a mad rage!\n", ({USER}));
  break;
  case 3:
  tell_room(environment(USER),
  ""+USER->query_name()+"/"+capitalize(symb_name)+" lashes out at imaginary enemies!\n", ({USER}));
  break;
  case 2:
  tell_room(environment(USER),
  ""+USER->query_name()+"/"+capitalize(symb_name)+" howls with mad laughter!\n", ({USER}));  
  break;
  case 1:
  tell_room(environment(USER),
  ""+USER->query_name()+"/"+capitalize(symb_name)+" growls at you.\n", ({USER}));
  break;
  default: 
  tell_room(environment(USER),
  ""+USER->query_name()+"/"+capitalize(symb_name)+"'s tongue lashes about violently!\n", ({USER}));  
  break;          
        }	
	}
    }
/*************************************************/



/****** Set magic to 5 if higher *****************/
if(USER->query_level() < 20){
        if(USER->query_attrib("mag") > 5){
tell_object(USER,
"Your symbiote feeds on your magical life! Magic drops to 5.\n");
                        USER->set_attrib("mag", 5);
                        USER->save();
                        call_other(USER, "reset", 1);
        }
    }
/*************************************************/

/****** Set stealth to 20 if higher **************/

/* Reason for this is if they join felines and raise stealth
   before it dests they will have a 25 stealth. */
   
if(USER->query_level() < 20){
        if(USER->query_attrib("ste") > 20){
                        USER->set_attrib("ste", 20);
                        USER->save();
                        call_other(USER, "reset", 1);
        }
    }
/*************************************************/
}

