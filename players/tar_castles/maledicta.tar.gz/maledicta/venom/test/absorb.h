absorb_corpse(){
object corpse;
int cvalue;
string extra;

if(USER->query_ghost()){
return 0;
}	
 
corpse = present("corpse", environment(USER));

 if (!corpse) {
      write("There is no corpse.\n");
      return 1;
       }
if (sscanf(file_name(corpse),"obj/corpse%s",extra)!=1) return 1;
if(venomed){
tell_room(environment(USER),
""+USER->query_name()+"/"+capitalize(symb_name)+" picks up a corpse and strangely begins to hug it.\n"+
"The corpse is slowly engulfed by the symbiotic life form.\n");

}
else{
tell_room(environment(USER),
USER->query_name()+" places his palm onto a corpse.\n"+
"A black ooze seeps out of "+USER->query_name()+"'s palm covering the corpse.\n"+
"The black ooze seeps back inside "+USER->query_name()+", leaving no remnants of\n"+
"the corpse.\n");
}

cvalue = (corpse->query_corpse_level() / 2) + random(corpse->query_corpse_level() / 2);

if(mp + cvalue > 300){
tell_object(USER,
capitalize(symb_name)+" whispers to you, 'We have enough matter to sustain...Now we heal.'\n");
USER->heal_self(((mp + cvalue) - 300)/3);
mp = 300;
}
else if(mp + cvalue <= 300){
   mp += cvalue;
}

   if(mp > 300) mp = 300;
   destruct(corpse);
   return 1;
   }
