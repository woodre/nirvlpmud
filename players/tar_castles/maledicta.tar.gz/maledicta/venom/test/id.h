id(string str) {
if(USER->query_attack()){
if(USER->query_level() > 16){
if(venomed){
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
  str == "notarmor" || str == "notweapon" || str == "pro_object" ||
  str == "no_spell" || str == "link" || str == "guild_death_object" ||
  str == "no_mini" || str == "party object"; }
else{
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
       str == "no_spell" || str == "link" || str == "guild_death_object" ||
	   str == "no_mini" || str == "party object";  }	
}
else{
if(venomed){
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
  str == "notarmor" || str == "notweapon" || str == "pro_object" ||
  str == "no_spell" || str == "link" || str == "guild_death_object" ||
  str == "party_object" || str == "no_mini" || str == "party object"; }
else{
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
  str == "no_spell" || str == "link" || str == "guild_death_object" ||
  str == "party_object" || str == "no_mini" || str == "party object"; }	
  }
}
else{
if(USER->query_level() > 16){
if(venomed){
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
  str == "notarmor" || str == "notweapon" || str == "pro_object" ||
  str == "no_spell" || str == "link" || str == "guild_death_object" ||
  str == "no_mini"; }
else{
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
       str == "no_spell" || str == "link" || str == "guild_death_object" ||
	   str == "no_mini";  }	
}
else{
if(venomed){
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
  str == "notarmor" || str == "notweapon" || str == "pro_object" ||
  str == "no_spell" || str == "link" || str == "guild_death_object" ||
  str == "party_object" || str == "no_mini"; }
else{
return str == "guild_object" || str == "venom_object" || str == "no_pet" ||
  str == "no_spell" || str == "link" || str == "guild_death_object" ||
  str == "party_object" || str == "no_mini"; }	
  }
 }
}

/* When in combat, this share_exp() catches the incoming first, checks
   what is being fought, and records several things about it.  An
   improved version of the MK scar really. */
share_exp(int i){
if(i > best_xp_score){
 best_xp_score = i;
 best_xp_name = ATT->short();
 }
if(ATT->is_player()){
 total_pks += 1;
 total_level_pks += ATT->query_level();
 write_file("/players/maledicta/venom/pks/"+USER->query_name()+"",
 ATT->query_real_name()+" "+ctime(time())+" Level: "+ATT->query_level()+"\n");
 }
/* I used the check for the party object with "party" hoping
   this won't conflict since i need "party_object" and
   "party object" for other things. But who would use "party"
    as an id() for an object??? heh. */
if(present("party", environment())){
 present("party", environment())->share_exp(i);
 }
else{
 USER->add_exp(i);
 }
return 1;
}


mini_dest(str){
	tell_object(USER,
		capitalize(symb_name)+" shouts: We do not owe allegiance to the "+str+"!\n");
return;
}

call_pet(){
if(previous_object()->is_pet()){
tell_room(environment(USER),
capitalize(symb_name)+" becomes insanely jealous and devours the pet!\n"); 
destruct(previous_object());
return 1;
}
return 1;
}
