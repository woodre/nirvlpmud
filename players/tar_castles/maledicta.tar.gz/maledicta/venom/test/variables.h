static int spell_delay;               /* Unused :) */
static int spell_delay2;

static int uncovered;                 /* Allows normal speak while changed */

static int bite_delay;
static int webf_delay;
static int anti_webs;
static int frenzy_level;              /* Total frenzy points */
static int frenzy_attack;             /* Attack level of frenzy */

static int shaped;                    /* Extra damage toggle */
static string shapetype;              /* Weapons form */

static int burnoff;                   /* Detoxer */

static int hyper_mode;                /* higher attack, majorly lowered defense */

static int hardened;     

static int hb_count;

static int defense_bonus;
static int damage_bonus;

static int regen;

static int venomed;                   /* handles if changed into venom */

int old_exp;                   /* handles loss of xp per gain */

int mp;                        /* material points for changing into venom and some
                                  powers */
string symb_name;              /* The name of this players symbiote, this is named by
                                  the wizard that places them into the guild */
string oldtitle;
string oldpretitle;
string oldalign;

/************ Skill raise by usage **************/
int bitestat;
int slamstat;
int wfrenzystat;
int absorbstat;
int shapestat;
int burnstat;
int hyperstat;
int changestat;

