/* This is the revised version of webslam. It allows the symbiote
   to up its damage by expending a greater sum of sps.  The change
   over of sps to damage is 2 pts = 1 pt of random damage. This
   cannot be gained until level 15.  */

web_slam(int i) {
int x_power;
object target, comp;
int z, spamount;
int how_many;
int damage, damage2; 
string atkmsg, msg, msg2, msg3;
        if(USER->query_ghost()) return 0;
        if(!venomed) return 0; 
        if(USER->query_spell_dam()) return 1;
	if(USER->query_level() < 7) return 0;
      if(webf_delay) return 1;
      if(hardened) return 1;
      if(!USER->query_attack()){
      write("You are not currently fighting.\n");
      return 1;
      }
/* Can't overload a webslam until 15th level */
if(i && USER->query_level() < 15){
i = 0;
}

if(i){
sscanf(i, "%d", x_power);      
if(x_power < 1){
  write("You must use a positive amount.\n");
  return 1;
  }
if(x_power > 40){
  write("You cannot put that much energy into your attack!\n");
  return 1;
  }
}

/***** Sp cost **********/
if(slamstat > 5000){
spamount = 15;
  }
else if(slamstat > 1000){
spamount = 16;
  }
else if(slamstat > 600){
spamount = 17;
  }
else if(slamstat > 300){
spamount = 18;
  }
else if(slamstat > 100){
spamount = 19;
  }
else{
spamount = 20;
  }
/*************************/
     if(USER->query_sp() < spamount + x_power){
	tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
        }
spamount += x_power;
target = USER->query_attack();

/***** damage amount **********/
if(slamstat > 5000){
damage = random(11) + 10;
  }
else if(slamstat > 1000){ 
damage = random(11) + 9;
  }
else if(slamstat > 600){
damage = random(11) + 8;
  }
else if(slamstat > 300){
damage = random(11) + 7;
  }
else if(slamstat > 100){
damage = random(11) + 6;
  }
else{
damage = random(11) + 5;
  }
/*************************/

if(x_power) damage += random(x_power / 2) + 1;

slamstat += 1;

tell_room(environment(USER),
"A stream of "+HIW+"webs"+NORM+" shoots out from "+capitalize(symb_name)+"'s hands.\n"+ 
"The stream of "+HIW+"web"+NORM+" hits "+target->query_name()+" in the chest.\n");
if(damage > 33){
tell_room(environment(USER),
capitalize(symb_name)+" spins "+target->query_name()+" overhead "+HIR+"S L A M M I N G"+NORM+" them off of the ground.\n");
}
else if(damage > 28){
tell_room(environment(USER),
capitalize(symb_name)+" spins "+target->query_name()+" about "+HIR+"Pounding"+NORM+" them against the ground.\n");
}
else if(damage > 20){
tell_room(environment(USER),
capitalize(symb_name)+" flips "+target->query_name()+" over it's shoulder, "+RED+"Driving"+NORM+" them to the ground.\n");
}
else if(damage > 15){
tell_room(environment(USER),
capitalize(symb_name)+" sends "+target->query_name()+" flying through the air and landing with a dull thud.\n");
}
else if(damage > 10){
tell_room(environment(USER),
capitalize(symb_name)+" throws "+target->query_name()+", sending them "+(random(40) + 10)+" feet across the room.\n");
}
else{
tell_room(environment(USER),
capitalize(symb_name)+" slings "+target->query_name()+", sending them bouncing across the floor.\n");
}
if(USER->query_level() > 19){
tell_object(USER,
"Damage: "+damage+"\n");
}
        msg = "";
        msg2 = "";
        msg3 = "";
        USER->spell_object(target, "web slam", damage, spamount, 
	msg, msg2, msg3);
        return 1;
}
