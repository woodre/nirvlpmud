/* updated sept 29th */

change_form(){
object inv;
int x, w, mpamount;	
if(!venomed){
/***** Mp cost **********/
if(changestat > 5000){
mpamount = 150;
  }
else if(changestat > 1000){
mpamount = 160;
  }
else if(changestat > 600){
mpamount = 170;
  }
else if(changestat > 300){
mpamount = 180;
  }
else if(changestat > 100){
mpamount = 190;
  }
else{
mpamount = 200;
  }
/*************************/
if(mp < mpamount){ 
  write("You don't have the energy to do this!\n");
  return 1;
  }
if(USER->query_sp() < 50){
  write("You don't have the energy to do this!\n");
  return 1;
  }
inv = all_inventory(USER);
	for(x = 0; x < sizeof(inv); x++){
		if(inv[x]->query_worn() && inv[x]->query_type() != "mine"){
		write("You cannot change form while wearing armor!\n");
		return 1;
		}	
	}
	for(w = 0; w < sizeof(inv); w++){
		if(inv[w]->query_wielded() && inv[w]->query_type() != "mine"){
		write("You cannot change form while wielding a weapon!\n");
		return 1;
		}	
	}
tell_room(environment(USER),
"Tentacles of ooze suddenly lash out of "+USER->query_name()+"'s body.\n"+
""+USER->query_name()+" writhes in pleasure as "+USER->PRO+" is transformed into "+capitalize(symb_name)+".\n");
venomed = 1;
USER->add_spell_point(-50);
wielded_by = this_player();
call_other(this_player(), "wield", this_object(), 1);
wielded = 1;
changestat += 1;
mp -= mpamount;
/* by verte */ this_player()->add_player_id(symb_name);
save_object(SAVE_PATH+NAME);
return 1;
 }  
tell_room(environment(USER),
"Dark matter retracts from "+USER->query_name()+"'s body.\n"+
"It disappears into "+USER->POS+" spine.\n");
shaped = 0;
shapetype = 0;
hyper_mode = 0;
burnoff = 0;
hardened = 0;
webf_delay = 0;
regen = 0;
call_other(this_player(), "stop_wielding", this_object());
wielded = 0;
wielded_by = 0;
venomed = 0;
this_player()->remove_player_id(symb_name);
save_object(SAVE_PATH+NAME);
return 1;
}

  
  
