
hypermode() {
int spamount;
        if(USER->query_ghost()) return 0;
        if(!venomed) return 0; 
if(USER->query_extra_level() < 8) return 0;
if(!USER->query_pl_k()){
	write("You must be pk to use this ability.\n");
    return 1;
}
	/***** Sp cost **********/
if(hyperstat > 5000){
spamount = 50;
  }
else if(hyperstat > 1000){
spamount = 55;
  }
else if(hyperstat > 600){
spamount = 60;
  }
else if(hyperstat > 300){
spamount = 62;
  }
else if(hyperstat > 100){
spamount = 65;
  }
else{
spamount = 70;
  }
/*************************/
	if(USER->query_sp() < spamount){
	tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	
		
tell_room(environment(USER),
USER->query_name()+" begins to work "+USER->OBJ+"self into a frenzy!\n");	
        hyper_mode += 30 + (USER->query_extra_level() * 3);
        USER->add_spell_point(-(spamount));
hyperstat += 1;
        return 1;
}
