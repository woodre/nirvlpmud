
web_blocker(string str){
int daexit;
string room1;
object webbing;
    if(USER->query_ghost()) return 0;
    if(USER->query_extra_level() < 2) return 0;
    if(!venomed) return 0;
    if(USER->query_spell_point() < 50){
      write("Your symbiotic link is too weak for that.\n");
      return 1;
      }
    if(present("web_symbiotes", environment(USER))){
      write("There is already a web here!\n");
      return 1;
      }
    if(!str){
      write("Web which exit?\n");
      return 1;
      }
if(sscanf(file_name(environment(USER)), "room/%s", room1) == 1){
  write("You cannot web here!\n");
  return 1;
  }
if(environment(USER)->query_no_fight()){
  write("You cannot web here!\n");
  return 1;
  }
if(str == "north" || str == "south" || str == "east" || str == "west" ||
   str == "northeast" || str == "northwest" || str == "southeast" ||
   str == "southwest" || str == "up" || str == "down" || str == "out" ||
   str == "enter"){



webbing = clone_object("/players/maledicta/venom/OBJ/web_blocker.c");
webbing->set_no_exit(str);
if(str == "south") webbing->set_no_exit2("s");
if(str == "east") webbing->set_no_exit2("e");
if(str == "west") webbing->set_no_exit2("w");
if(str == "north") webbing->set_no_exit2("n");
if(str == "up") webbing->set_no_exit2("u");
if(str == "down") webbing->set_no_exit2("d");
if(str == "northeast") webbing->set_no_exit2("ne");
if(str == "northwest") webbing->set_no_exit2("nw");
if(str == "southeast") webbing->set_no_exit2("se");
if(str == "southwest") webbing->set_no_exit2("sw");
move_object(webbing, environment(USER));

mp -= 15;
USER->add_spell_point(-50);
tell_room(environment(USER),
capitalize(symb_name)+" holds its hand towards the "+str+" exit...\n"+
"A spray of webbing covers it!\n");
return 1;
}
write("That exit cannot be blocked!\n");
return 1;
}