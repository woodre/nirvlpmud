
bite_spell() {
object target, comp;
int z;
int how_many;
int damage, damage2, spamount; 
string atkmsg, msg, msg2, msg3;
        
      if(USER->query_ghost()) return 0;
      if(!venomed) return 0; 
      if(USER->checkNM()) return 0;
	  if(USER->query_spell_dam()) return 1;
	  if(USER->query_level() < 12) return 0;
	  if(bite_delay){
		write("You cannot bite again so soon.\n");
		return 1; }
      if(webf_delay) return 1;
      if(hardened) return 1;

/***** Sp cost **********/
if(bitestat > 5000){
spamount = 25;
  }
else if(bitestat > 1000){
spamount = 27;
  }
else if(bitestat > 600){
spamount = 30;
  }
else if(bitestat > 300){
spamount = 32;
  }
else{
spamount = 36;
}
/*************************/

	if(USER->query_sp() < spamount){
	tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	
	if(USER->query_attack())
		target = USER->query_attack();

	else if(!USER->query_attack()){
		tell_object(USER,
		"You can only do this in combat!\n");
		return 1; }

	 if(!present(target, environment(USER))){
		  tell_object(USER,
			  "You don't see them here!\n");
		  return 1;
	  }
how_many = random(USER->query_attrib("wil") / 4) + 1;
damage = 0;

if(how_many > 4) how_many = 4;

tell_room(environment(USER),
capitalize(symb_name)+" cackles with glee!\n");	
while(how_many > 0){
   damage += bitetwo();
   how_many--;
   }

if(bitestat > 5000){
damage += bitetwo();
damage += bitetwo();
}
else if(bitestat > 600){
damage += bitetwo();
}

bitestat += 1;
mp -= 4;
bite_delay = 5 + random(3); 
        msg = "";
        msg2 = "";
        msg3 = "";

        USER->spell_object(target, "bite attack", damage, spamount, 
	msg, msg2, msg3);
 
       	return 1;
}
