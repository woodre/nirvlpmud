finish_spell() {
object target, comp;
int spamount; 
int cost;
        if(USER->query_ghost()) return 0;
        if(!venomed) return 0; 

        if(USER->query_attack())
		target = USER->query_attack();
	  else if(!USER->query_attack()){
		tell_object(USER,
		"You can only do this in combat!\n");
		return 1;
            }
	  if(!present(target, environment(USER))){
		  tell_object(USER,
			  "You don't see them here!\n");
		  return 1;
	  }
    if(!target->query_npc()){
      tell_object(USER,
      "You cannot do this to players!\n");
      return 1;
      }
    cost = target->query_hp()/3;
    if(cost > USER->query_hp()){
	tell_object(USER,
	"You are too weak.\n");
	return 1;
      }

if(USER->query_attack() && attack->query_hp() < 50){
if((attack->query_hp()*10)/(attack->query_mhp()) < 1){
if(random(100) < 80){
tell_room(environment(USER),
"<"+HIG+"devour"+NORM+"> "+USER->query_name()+"'s symbiotic mouth elongates to a massives size.\n"+
"         "+USER->query_name()+"'s razor like teeth begin its decent...\n");
tell_room(environment(USER), 
"         "+attack->query_name()+"'s headless body drops lifelessly to the ground.\n");
}
else{
tell_room(environment(USER),
"<"+HIG+"eviscerate"+NORM+"> A horde of tentacles lash out from "+USER->query_name()+".\n"+
"             "+attack->query_name()+" decides to run but its far too late.\n");
tell_room(environment(USER),
"             You can see "+attack->query_name()+"'s eyes stare blankly at the inevitable...\n"+
"             "+attack->query_name()+" groans in pain as it is ripped limb from limb.\n");
}
    USER->add_hit_point(-cost);
    target->heal_self(-(target->query_hp()));
    target->hit_player(USER->query_level());
    return 1;
  }
 tell_object(USER, "Your opponent is still too strong.\n");
       	return 1;
 }
 tell_object(USER, "Your opponent is still too strong.\n");
       	return 1;
}
