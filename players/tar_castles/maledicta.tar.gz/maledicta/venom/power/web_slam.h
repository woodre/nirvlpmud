

web_slam(str) {
object target, comp;
int z, spamount;
int how_many;
int damage, damage2; 
string atkmsg, msg, msg2, msg3;
        if(USER->query_ghost()) return 0;
        if(!venomed) return 0; 
/*
        anti_webs += 1;
        if(anti_webs > 3){
         write("You overtax your symbiote with spamming!\n");
         USER->heal_self(-10);
         return 1;
         }
*/
        if(USER->query_spell_dam()) return 1;
	if(USER->query_level() < 7) return 0;
      if(webf_delay) return 1;
      if(hardened) return 1;
      
/***** Sp cost **********/
if(slamstat > 5000){
spamount = 15;
  }
else if(slamstat > 1000){
spamount = 16;
  }
else if(slamstat > 600){
spamount = 17;
  }
else if(slamstat > 300){
spamount = 18;
  }
else if(slamstat > 100){
spamount = 19;
  }
else{
spamount = 20;
  }
/*************************/
        if(USER->query_sp() < spamount){
	tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
        }
	if(!str && USER->query_attack())
		target = USER->query_attack();

	else if(str)
		target = present(str, environment(USER));

	else if(!str && !USER->query_attack())
		return 0;

	if(!target){
		tell_object(USER,
		"You don't see "+str+" here.\n");
		return 1;
	}
     if(!present(target, environment(USER))){
		  tell_object(USER,
			  "You don't see them here!\n");
		  return 1;
	  }
	if(!living(target)){
		tell_object(USER,
		"You cannot attack "+str+"!\n");
		return 1;
	}
/***** damage amount **********/
if(slamstat > 5000){
damage = random(11) + 10;
  }
else if(slamstat > 1000){ 
damage = random(11) + 9;
  }
else if(slamstat > 600){
damage = random(11) + 8;
  }
else if(slamstat > 300){
damage = random(11) + 7;
  }
else if(slamstat > 100){
damage = random(11) + 6;
  }
else{
damage = random(11) + 5;
  }
/*************************/
slamstat += 1;
tell_room(environment(USER),
"A stream of "+HIW+"webs"+NORM+" shoots out from "+capitalize(symb_name)+"'s hands.\n"+ 
"The stream of "+HIW+"web"+NORM+" hits "+target->query_name()+" in the chest.\n"+
""+target->query_name()+" is spun wildly about the room, slamming\n"+
"heavily into the ground!\n");
        msg = "";
        msg2 = "";
        msg3 = "";
        USER->spell_object(target, "web slam", damage, spamount, 
	msg, msg2, msg3);
        return 1;
}
