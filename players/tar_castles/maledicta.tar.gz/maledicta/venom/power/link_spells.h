/* updated January 10th, 2000 */
link_spell(string str){

if(USER->query_ghost()) return 0;
if(!venomed){
write(capitalize(symb_name)+" hisses,'We are not changed...'\n");
return 1;
}

/********* Link help ***********/
if(!str){
if(USER->query_level() < 8) {
 write("You must be at least level 8 to have link abilites.\n");
}
if(USER->query_level() > 7){
write(
""+HIW+""+capitalize(symb_name)+""+NORM+" whispers into your mind,\n"+
"  'I can help you do the following abilities..'\n");
write(
"       "+HIB+"Flee..."+NORM+"\n");
}
if(USER->query_level() > 7 && hardened){
write(
"       "+HIB+"Harden..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
         }
else if(USER->query_level() > 7){
write(
"       "+HIB+"Harden..."+NORM+"\n");
         }         
/*
if(USER->query_level() > 9 && regen){
write(
""+HIB+"       Regenerate..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
         }

else if(USER->query_level() > 9){
write(
"       "+HIB+"Regenerate..."+NORM+"\n");
         }

*/
if(USER->query_level() > 10 && shapetype == "sword"){
write(
"       "+HIB+"Sword..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
}
else if(USER->query_level() > 10){
write(
"       "+HIB+"Sword..."+NORM+"\n");
}
if(USER->query_level() > 10 && shapetype == "spear"){
write(
"       "+HIB+"Spear..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
}
else if(USER->query_level() > 10){
write(
"       "+HIB+"Spear..."+NORM+"\n");
}
if(USER->query_level() > 10 && shapetype == "maul"){
write(
"       "+HIB+"Maul..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
}
else if(USER->query_level() > 10){
write(
"       "+HIB+"Maul..."+NORM+"\n");
}
if(USER->query_level() > 10 && shapetype == "axe"){
write(
"       "+HIB+"Axe..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
}
else if(USER->query_level() > 10){
write(
"       "+HIB+"Axe..."+NORM+"\n");
}
if(USER->query_level() > 10 && shapetype == "shield"){
write(
"       "+HIB+"Shield..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
}
else if(USER->query_level() > 10){
write(
"       "+HIB+"Shield..."+NORM+"\n");
}
if(USER->query_level() > 10){
write(
"       "+HIB+"Noshape..."+NORM+"\n");
         }

if(USER->query_level() > 18 && burnoff){
write(
"       "+HIB+"Burnoff..."+NORM+" "+HIR+"(Active)"+NORM+"\n");
         }
else if(USER->query_level() > 18){
write(
"       "+HIB+"Burnoff..."+NORM+"\n");
         }

write("\n"+NORM+""+HIW+"You can "+HIB+"link <power>"+HIW+" to perform any of the above abilities."+NORM+"\n");         
 return 1;
 }       
/*************************************/


/********** Flee *************************/

if(str == "flee" || str == "Flee"){

object ob,altob;                             
ob = USER->query_attack();     
altob = USER->query_alt_attack();

  if(USER->query_level() < 8) return 0;
  if(USER->query_sp() < 15){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	
	if(!USER->query_attack()){
	tell_object(USER,
	"You can only do this in combat!\n");
	return 1; }

tell_room(environment(USER),
""+USER->query_name()+" snarls and flees from combat!\n\n");                 
if(altob){
  if(altob->query_attack() == USER){  	  
    altob->stop_fight();    
    USER->stop_fight();
    altob->stop_hunter();
    USER->stop_hunter();
    } }               
  if(ob->query_attack() == USER){        
    ob->stop_fight();
    USER->stop_fight();   
    ob->stop_hunter();
    USER->stop_hunter();
    }
 if(altob){
  if(altob->query_attack() == USER){  	  
    altob->stop_fight();    
    USER->stop_fight();
    altob->stop_hunter();
    USER->stop_hunter();
    } }               
 if(ob){
  if(ob->query_attack() == USER){        
    ob->stop_fight();
    USER->stop_fight();   
    ob->stop_hunter();
    USER->stop_hunter();
    }}
 
tell_object(USER,
"You turn and flee from combat!\n");
USER->add_spell_point(-15);
return 1;
}

/***************************************************/

/********** Harden *********************************/
if(str == "harden"){

if(USER->query_level() < 8) return 0;
if(USER->query_sp() < 10 || mp < 1){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	
if(!hardened && no_harden){
 tell_object(USER,
  "You cannot harden again so soon!\n");
  return 1;
  }	
if(hardened){
tell_room(environment(USER),
USER->query_name()+"'s body softens into a smooth black skin..\n");
hardened = 0;
return 1;
}      
tell_room(environment(USER),
USER->query_name()+" concentrates briefly.\n"+
""+USER->query_name()+"'s body hardens into a unbreakable armor.\n");
hardened = 1;
no_harden = 300;
mp -= 1;
USER->add_spell_point(-10);
return 1;
}
/***************************************************/


/********** Sword, Spear, Axe, Shield, Noshape *****/
/***************************************************/
if(str == "sword"){
if(USER->query_level() < 11) return 0;
  if(USER->query_sp() < 50 || mp < 50){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	
if(shaped){
tell_object(USER, 
"You concentrate and feel your arm return to normal...\n");
shaped = 0;
shapetype = 0;
return 1;
}

shaped = 1;
shapetype = "sword";
mp -= 50;
USER->add_spell_point(-50);
tell_object(USER,
"You concentrate briefly and feel the symbiote reshape itself into a razor sharp sword!\n");
return 1;
}

if(str == "maul"){
if(USER->query_level() < 11) return 0;
  if(USER->query_sp() < 50 || mp < 50){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	
if(shaped){
tell_object(USER, 
"You concentrate and feel your arm return to normal...\n");
shaped = 0;
shapetype = 0;
return 1;
}

shaped = 1;
shapetype = "maul";
mp -= 50;
USER->add_spell_point(-50);
tell_object(USER,
"You concentrate briefly and feel the symbiote reshape itself into a powerful maul!\n");
return 1;
}

if(str == "spear"){
if(USER->query_level() < 11) return 0;
  if(USER->query_sp() < 50 || mp < 50){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	

if(shaped){
tell_object(USER, 
"You concentrate and feel your arm return to normal...\n");
shaped = 0;
shapetype = 0;
return 1;
}

shaped = 1;
shapetype = "spear";
mp -= 50;
USER->add_spell_point(-50);
tell_object(USER,
"You concentrate briefly and feel the symbiote reshape itself into a long spear!\n");
return 1;
}

if(str == "shield"){
if(USER->query_level() < 11) return 0;
  if(USER->query_sp() < 50 || mp < 50){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	

if(shaped){
tell_object(USER, 
"You concentrate and feel your arm return to normal...\n");
shaped = 0;
shapetype = 0;
return 1;
}

shaped = 1;
shapetype = "shield";
mp -= 50;
USER->add_spell_point(-50);
tell_object(USER,
"You concentrate briefly and feel the symbiote reshape itself into a huge shield!\n");
return 1;
}


if(str == "axe"){
if(USER->query_level() < 11) return 0;
  if(USER->query_sp() < 50 || mp < 50){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}	

if(shaped){
tell_object(USER, 
"You concentrate and feel your arm return to normal...\n");
shaped = 0;
shapetype = 0;
return 1;
}

shaped = 1;
shapetype = "axe";
mp -= 50;
USER->add_spell_point(-50);
tell_object(USER,
"You concentrate briefly and feel the symbiote reshape itself into a huge battle axe!\n");
return 1;
}

if(str == "noshape"){
if(shaped){
tell_object(USER, 
"You concentrate and feel your arm return to normal...\n");
shaped = 0;
shapetype = 0;
return 1;
}
tell_object(USER,
capitalize(symb_name)+" sends you a mental grunt of confusion.\n");
return 1;
}
/***************************************************/

/********** Burnoff ********************************/
if(str == "burnoff" || str == "Burnoff"){
if(USER->query_level() < 19) return 0;
if(burnoff){
tell_object(USER,
"Stopping the burnoff process...\n");
burnoff = 0;
return 1;
}
if(USER->query_sp() < 15 || mp < 1){
  tell_object(USER,
	"Your symbiotic link is too weak for that.\n");
	return 1;
	}
if(USER->query_hp() < 50){
tell_object(USER,
"Your body is too weak to begin this process.\n");
return 1; }	
burnoff = 1;	
USER->add_spell_point(-15);
mp -= 1;
write("You concentrate on your link and will it to burn off the harmful toxins in your\n"+
      "blood...\n");
return 1;
}      
/***************************************************/


/******** Weakness *********************************/
/***************************************************/

/******** Regeneration *****************************/
/*
if(str == "regen" || str == "regenerate"){
if(USER->query_level() < 10) return 0;

if(regen){
   tell_object(USER,
   "You stop regenerating.\n");
   regen = 0;
   return 1;
}
 
if(USER->query_sp() < 10 || mp < 1){
   tell_object(USER,
   "Your symbiotic link is too weak for that.\n");
   return 1;
}	

tell_object(USER,
"You concentrate briefly and feel "+capitalize(symb_name)+" begin to slowly mend your wounds.\n");
regen = 1;
USER->add_spell_point(-10);
mp -= 1;
return 1;
}
*/
/***************************************************/
return 0;
}
