#include "/players/maledicta/ansi.h"

int sleeping;

id(str){ return str == "inn_room"; }

short(){ return "Inn of New Ares"; }
long(){ write("You can't see this!\n"); return 1; }

realm(){ return "NT"; } 