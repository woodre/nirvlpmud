#include "/players/eurale/closed/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("N");
set_alias("A");
set_short("Shrt");
set_long(
  "Long description\n");

set_ac(AC);
set_type("T");  /* armor,helmet,boots,ring,amulet,shield,misc  */
set_weight(W);
set_value(V);
set_arm_light(0);  /*  makes armor glow if it's > 0  */
}

