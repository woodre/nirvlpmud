#include "/players/maledicta/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("vest");
set_alias("flakvest");
set_short("a flakvest");
set_long(
"  A green flak vest made of rough material and built to resist\n"+
"damage. It is lightweight and rugged.\n");
set_ac(2);
set_type("armor");  
set_weight(1);
set_value(400);
}


