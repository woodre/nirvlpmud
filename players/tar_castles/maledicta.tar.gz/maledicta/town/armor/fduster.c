#include "/players/maledicta/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("duster");
set_alias("flakduster");
set_short("a flak duster");
set_long(
"  This is a long coat with built in plates of armor. Much like a flak\n"+
"vest, only it protects the legs also. It is black in color and made to\n"+
"resist damage.\n");

set_ac(3);
set_type("armor"); 
set_weight(3);
set_value(700);
}

