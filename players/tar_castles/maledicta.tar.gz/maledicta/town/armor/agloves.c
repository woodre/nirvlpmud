#include "/players/maledicta/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("gloves");
set_short("armored gloves");
set_long(
"  A pair of black leather and steel combat gloves. They are lightweight\n"+
"and sturdy.\n");

set_ac(1);
set_type("ring");  
set_weight(1);
set_value(50);
}

