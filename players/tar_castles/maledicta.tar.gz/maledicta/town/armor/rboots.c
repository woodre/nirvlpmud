#include "/players/maledicta/ansi.h"
inherit "obj/armor";

reset(arg) {
set_name("boots");
set_short("steel-reinforced boots");
set_long(
"   A pair of black rugged steel reinforced boots. They are lightweight\n"+
"and very tough.\n");

set_ac(1);
set_type("boots");  
set_weight(1);
set_value(50);
 
}

