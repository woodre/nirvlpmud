object howl, amu, money;
reset(arg)
{
   if(!arg)
   set_light(1);
   extra_reset();
}

extra_reset()
{
   amu = "/players/silent/castle/barrow/equip/amu.c";
   if(!present("howl"))
   {
     howl = clone_object("obj/monster");
     howl->set_name("howler");
     howl->set_id("howler");
     howl->set_al(-50);
     howl->set_short("howler");
     howl->set_long("one of the evil ten who were taken.  the howler\n"+
                    "is notorious for his, well, howling...  he hasn't\n"+
                    "been bothered in his tomb for many centuries.\n"+
                    "you get the unsettling impression that he is\n"+
                    "glad to see you.\n");
     howl->set_wc(15);
     howl->set_ac(8);
     howl->set_hp(165);
     if(!present("amu", this_player()))
     {
       howl->set_aggressive(1);
     }
     else
     {
       howl->set_aggressive(0);
     }
     howl->set_level(12);
     howl->set_chance(25);
     howl->set_spell_dam(15);
     howl->set_spell_mess1("the howler shrieks piercingly.\n");
     howl->set_spell_mess2("the howler howls at you.\n");
     move_object(howl, this_object());
     money = clone_object("obj/money");
     money->set_money(random(600));
     move_object(money, howl);
   }
}

init()
{
   add_action("ne", "northeast");
   add_action("s", "south");
}

ne()
{
   this_player()->move_player("northeast#players/silent/castle/barrow/barr2.c");
   return 1;
}
s()
{
   this_player()->move_player("south#players/silent/castle/barrow/cook6.c");
   return 1;
}

short()
{
   return "the howler's tomb";
   write("the howler's tomb");
}

long()
{
   write("this is the first of the tombs of the ten who were taken\n"+
         "the ten have been entombed for over 400 years and are more\n"+
         "than happy to 'entertain' guests.\n");
   write("\n there are two obvious exits: northeast, south\n");
}
