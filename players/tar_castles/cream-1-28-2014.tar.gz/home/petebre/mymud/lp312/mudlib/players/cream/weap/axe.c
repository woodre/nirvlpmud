inherit "obj/weapon.c";

#define AMOUNT_OF_MAGIC 500

int magic_left;
status first_wield;

long() {
   write("You see an ancient, combat-scarred axe.  It's handle is covered\n");
   write("with strange inscriptions and runes.  The well-balanced blade\n");
   write("feels like it could do some major damage.\n");
   if (magic_left>0 && !first_wield) {

      write("The mystical weapon has a bright magical glow!\n");
   }
   if (magic_left<0) {
      write("The runes seem to have been burnt out.  You can barely read them.\n");
   }
}
query_value() {
   if(magic_left>0) {
      return(magic_left*100);
   }
   return 100;
}
out_of_magic() { 
   write ("Suddenly you hear the horrible wail of a thousand souls!!!\n");
   say("Suddenly you hear the horrible wail of a thousand souls!!!\n");
   write("The runes on your axe glow madly in a myriad of colors!\n");
   write("You see the last of the axe's magic streak out and hit your target.\n");
   say("A bolt of magic streaks out from "+this_player()->query_name()+"'s axe!\n");
   write("The skies echo with thunder.  BOOOOOMMM!!!\n");
   say ("The skies echo with thunder.  BOOOOOMMM!!!\n");
  set_name("a battle axe");
  set_short("a battle axe");
  set_class(15);
   call_out("all_gone",0);
}

all_gone() {
   tell_object(environment(),"As the axe reverts back to normal form, you see smoke rise up\n");
   tell_object(environment(),"from the runes on the handle.\n");
}

reset(arg) {
   if(!arg) {
      ::reset(arg);
      set_name("a battle axe");
      set_alt_name("battle axe");
      set_alias("axe");
      set_short("A battle axe");
      set_class(0);
      set_weight(1);
      set_hit_func(this_object());
      magic_left = AMOUNT_OF_MAGIC;
      first_wield = 1;
   }
}

weapon_hit(attacker) {
   if(call_other(environment(this_player()), "realm") == "enterprise") {
      write("The axe suffers an anachronism and falls to the floor!\n");
      write("This axe can't be used on the Enterprise.\n");
      transfer(present("heavy battle axe",this_player()),
         environment(this_player()));
      return 0;
   }
   if(magic_left < 0 ) return 0;
   if(magic_left == 0 ) {
      out_of_magic();
      magic_left--;
      return 18;
   }
   if(random(3) > 4) return 0;
      write("A bolt of lightning shoots from the sky, striking your opponent!\n");
      say("A bolt of lightning shoots from the sky.  KRAAAACK!\n");
      magic_left--;
      return 18;
}

wield(str) {
   if(!id(str)) return 0;
   if(environment() != this_player()) return 0;
   if (wielded) {
      write("You're already wielding it!\n");
      return 1;
   }
   if(first_wield) {
write("The crystal hilt begins to pulse in your hands.\n");
      set_name("Crystal axe");
      set_short("Crystal axe");
      first_wield = 0;
   }
   if (magic_left) {
      write("The axe's magic courses through your body!\n");
      write("You feel STRANGE!!\n");
   }
   wielded_by = this_player();
   call_other(this_player(),"wield",this_object());
   wielded = 1;
   return 1;
}
