#include "std.h"
int drinks, price;

id(str) { return str == "ale"; }

reset(arg) {
	if (!arg) drinks = 15;
	price = drinks * 150;
}

long() {
	write("This is a flask with thick brown ale in it. There are ["+drinks+"] drinks left.\n");
}

short() {
     return "A flask of ale";
}

query_value()
{
    return price;
}

init() {
    add_action("use"); add_verb("drink");
}

use(arg){
object tp;
tp = this_player();
if(!arg || arg != "ale"){
	return 0;
} else {
if(!tp->drink_alcohol(15)){
	return 1;
}else{
	if(arg == "ale"){
drinks=drinks - 1;
tp->heal_self(30);
	write("You open the flask and take a swig of ale.\n"+
	"["+tp->query_hp()+"]hp ["+tp->query_sp()+"]sp ["+
	drinks+"] drinks left.\n");
	say(capitalize(tp->query_name()) + " swigs some thick brown liquid.\n");
if(drinks == 0){
	destruct(this_object());
write("You empty the flask and drop it, it breaks on the ground below.\n");
	tp->add_weight(-1);
		}
return 1;
		}
	}
}
}

get() {
    return 1;
}

query_weight() {
    return 1;
}
