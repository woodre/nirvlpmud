#include "std.h"

reset(arg){
     if(!arg){
     set_light(1);
     }
}
/*  Sets what the room will do at reset(In this case, make it a lighted room)  )*/

init(){
/*  A very important basic function.  All of the actions that this room
does are put in this function.  */

     add_action("exit_shop","shop");
     add_action("exit_church","church");
}

exit_shop(){
     call_other(this_player(), "move_player",
       "shop#room/shop");
     return 1;
}

exit_church(){
     call_other(this_player(), "move_player",
       "church#room/church");
     return 1;
}


/*  Above, we see the init() functions defined.    */
short() { return "Cream's workroom"; }

long(){
 write("This is a small, cozy library where Cream likes to come and read.\n");
 write("Be quiet and maybe she'll let you stay.\n");
     write("There are two obvious exits: shop and church\n");
}
