object croaker, money, bow;
reset(arg)
{
   if(!arg)
   set_light(1);
   extra_reset();
}

extra_reset()
{
   if(!present("croaker"))
     {
     croaker = clone_object("obj/monster");
     croaker->set_name("croaker");
     croaker->set_id("croaker");
     croaker->set_al(25);
     croaker->set_short("croaker");
     croaker->set_long("the black company's physician and annalist\n");
     croaker->set_wc(9);
     croaker->set_ac(4);
     croaker->set_hp(75);
     croaker->set_level(5);
     croaker->set_chat_chance(25);
     croaker->load_chat("croaker says: you'll never beat the dominator without the white rose\n");
     croaker->load_chat("croaker says: get out of the way, i have to stitch someone up\n");
     croaker->load_chat("croaker says: i hope i'm not getting too personal when i write the annals\n");
     move_object(croaker, this_object());
     money = clone_object("obj/money");
     money->set_money(random(100));
     move_object(money, croaker);
     bow = clone_object("obj/weapon");
     bow->set_id("bow");
     bow->set_name("bow");
     bow->set_class(13);
     bow->set_weight(2);
     bow->set_value(100);
     bow->set_short("short bow");
     move_object(bow, croaker);
     }
}

init()
{
   add_action("nw", "northwest");
   add_action("n", "north");
   add_action("ne", "northeast");
   add_action("s", "south");
}

nw()
{
   this_player()->move_player("northwest#players/silent/castle/barrow/cook2.c");
   return 1;
}
n()
{
   this_player()->move_player("north#players/silent/castle/barrow/cook3.c");
   return 1;
}
ne()
{
   this_player()->move_player("northeast#players/silent/castle/barrow/cook4.c");
   return 1;
}
s()
{
   write("this exit not open currently");
   return 1;
}

short()
{
   return "field hospital";
}

long()
{
   write("this is a field hospital.  the attending physician, croaker, is\n"+
         "talking while he works (must be the stress is getting to him).\n"+
         "you get the impression he may have some useful information.\n");
   write("\n there are four obvious exits: northwest, north, northeast, south\n");
}
