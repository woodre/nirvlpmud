id(str) { return str == "heal"; }
 
reset() {}
 
long() { write("A healing potion.\n"); }
 
short() { return "A healing potion"; }
 
init() {
    add_action("cast"); add_verb("cast");
    add_action("sp"); add_verb("quaff");
    add_action("drop_object"); add_verb("drop");
}
 
get() { return 1; }
 
query_weight() { return 0; }
 
query_value() { return 5000; }
 
 sp(str)  {
string who;
  int amt;
if(!str || sscanf(str,"%s%d", who, amt) ! = 2) {
   write("sp <who> <amt>\n");
  return 1;
}
  if(!find_player(who)) {
    write(capitalize(who)+" is not on.\n");
  return 1;
}
call_other(find_player(who), "add_spell_point", amt);
  write("You have given "+capitalize(who)+" "+amt+" of sps.\n");
  return 1;
}
