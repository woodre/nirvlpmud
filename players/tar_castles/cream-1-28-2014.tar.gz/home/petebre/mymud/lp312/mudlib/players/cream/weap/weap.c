inherit "obj/weapon";
string owner;

reset(arg){
   if(arg) return;
   ::reset(arg);
   set_name("basic weapon");
   set_alt_name("basic");
   set_alias("weapon");
   set_short("Basic Weapon");
   set_long("This is a basic weapon. With a special attack.\n");
   set_class(18);
   set_hit_func(this_object());
   set_weight(3);
   set_value(100000);
}
weapon_hit(attacker){
   if(random(600) > 20){
      write("This line goes to the wielder.\n");
      say("This line is told to the room.\n");
      return 7;
   }
}
