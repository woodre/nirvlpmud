object howl, amu, money;
reset(arg)
{
   if(!arg)
   set_light(1);
   extra_reset();
}

extra_reset()
{
}

init()
{
add_action("north","north");
add_action("guild","guild");
add_action("shop","shop");
add_action("advg","advg");
add_action("church","church");
}

church() {
this_player()->move_player("church#room/church");
return 1; }
guild() {
this_player()->move_player("guild#players/deathmonger/ASSASSIN/cenguild");
return 1; }
shop() {
this_player()->move_player("shop##room/shop");
return 1; }
advg() {
this_player()->move_player("adventure guild#room/adv_guild");
return 1; }
north() {
this_player()->move_player("north#players/cream/room/tunnel2");
return 1; }

short()
{
return "The Assassins tunnel 1";
}

long()
{
write("The Assassins Tunnel 1\n"+
"You are inside one of the most famous underground tunnel in the MUD\n"+
"This room tunnel will lead you to some destination in the village.\n"+
"You see some ladders lead you up to the door on the ceiling.\n"+
"You also see exit to north.\n"+
"The obvious exits: guild, church, shop, advg(adventure guild), and north.\n");
}
