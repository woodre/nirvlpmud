id(str) { return str == "shield"; }

reset() {}

long() { write("A redcross on a blue shield...hmmmm..\n"); }

short() { return "A blue shield"; }

init() {
    add_action("sp"); add_verb("heal");
}

 sp(str)  {
string who;
  int amt;
if (!str || sscanf(str "%s%d", who, amt) ! = 2) {
   write("sp <who> <amt>\n");
  return 1;
}
  if(!find_player(who)) {
    write(capitalize(who)+" is not on.\n");
  return 1;
}
call_other(find_player(who), "add_spell_point", amt);
  write("You have given "+capitalize(who)+" "+amt+" of sps.\n");
  return 1;
}


get() { return 1; }

query_weight() { return 1; }

query_value() { return 5000; }

