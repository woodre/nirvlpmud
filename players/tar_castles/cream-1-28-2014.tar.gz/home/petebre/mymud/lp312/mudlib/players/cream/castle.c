#define NAME "Cream"
#define DEST "room/eastroad5"
 object ob;
/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "temple"; }

short() {
 return "Temple of Light";
}

long() {
 write("" + short()+"\n");
write("This castle is under heavy development.\n");
write("Please be patient, it will be a very good place in the future.\n");
}

init() {
  add_action("climb", "climb");
  add_action("climb", "climb hill");
/*
    add_action("enter"); add_verb("enter");
*/
}

 climb() {
  write(" You barely see a building beyond a the small hill in front of you.\n");
 this_player()->move_player("up#players/cream/me");
    write("It is not an open castle.\n");
    return 1;
}

reset(arg) {
    if (arg)
	return;
 move_object(this_object(), DEST);
 ob = clone_object("/players/cream/pin.c");
destruct(ob);
}
is_castle(){return 1;}
