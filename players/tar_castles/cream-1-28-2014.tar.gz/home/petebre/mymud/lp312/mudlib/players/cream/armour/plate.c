inherit "obj/armor";

reset(arg){
   ::reset(arg);
   set_short("Basic Armor");
   set_long("This is a basic armor.\n");
   set_ac(4);
   set_weight(3);
   set_value(5000);
   set_alias("basic");
   set_name("basic");
   set_type("armor");
}
