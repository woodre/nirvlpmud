inherit "obj/armor";
reset(arg)
{
  ::reset(arg) ;
    set_short ( "Bone Amulet" ) ;
    set_long ( "An Amulet made of bone, symbolizing nothing.\n" ) ;
    set_ac (1) ;
    set_weight (1) ;
    set_value (200) ;
    set_alias ( "amulet" ) ;
    set_name ( "Bone Amulet" ) ;
set_type ("amulet"); }
init() {
  ::init();
  add_action("see", "see");
}
see(str) {
object ob;
if(!str) {
write("Enter a name to locate, genius\n");
return 1;
}
ob =find_player(str);
if (!ob) {
write("Why don't you try finding someone who is actually here?\n");
return 1;
}
call_other(ob, "look");
return 1;
}
