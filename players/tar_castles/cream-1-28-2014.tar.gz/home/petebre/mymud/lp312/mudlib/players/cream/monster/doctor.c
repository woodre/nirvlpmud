inherit "obj/monster";

reset(arg){
   object gold,armor,weapon,basmon;
   ::reset(arg);
   if(arg) return;
set_name("doctor");
set_alias("doc");
set_short("Clinic doctor");
set_long("This doctor is specialist on changing your sex.\n"+
"Type 'change sex' to change your sex.\n");
set_level(20);
set_hp(2000);
set_chance(10);
set_spell_dam(50);
set_spell_mess1("The doctor kicks your ass.\n");
 set_spell_mess2("The doctors injects you with protophyne.\n");
set_chat_chance(20);
load_chat("Do you want to change your sex?\n");
load_chat("It costs only 1000 coins.\n");
add_money(1000);
}
init() {
add_action("change","change");
}
change(str) {
string s;
if(!str) {
write("Change what?\n");
return; }
if(!str=="sex") {
write("You can't change that here!\n");
return 1;}
if(this_player()->query_money()<1000) {
write("You don't have enough money.\n");
return 1; }
s=this_player()->query_gender();
if(s=="male") {
this_player()->set_gender("female");
write("The doctor injects you with some kind of hormone and\n"+
"does a little operation on your genital.\n");
say(this_player()->query_name()+" changes his sex to female.\n");
write("Now, You are a female\n");
this_player()->add_money(-1000);
this_object()->add_money(1000);
return 1; }
if(s=="female") {
this_player()->set_gender("male");
write("The doctor injects you with some kind of hormone and\n"+
"does a little operation on your genital.\n");
say(this_player()->query_name()+" changes her sex to male.\n");
write("Now you are a male!\n");
this_player()->add_money(-1000);
this_object()->add_money(1000);
return 1; }
write("I can't change your sex, you have to contact other doctor,\n");
write("I don't deal with neuter!\n");
return 1; }
