inherit "obj/monster";

reset(arg)
{
  object armor,weapon;
  ::reset(arg);
  if(arg) return;
  set_name("Skull Warrior");
  set_race("undead");
  set_alias("warrior");
set_short();
  set_long("The warrior is a servant of Lord Bane.\n");
  set_level(9);
  set_hp(135);
  set_al(-500);
  set_wc(13);
  set_ac(7);
  set_chat_chance(2);
  load_chat("Warrior says: I welcome you to Lord Bane's Kingdom.\n");
  load_chat("Warrior says: Hey, don't get killed....\n");
  weapon=clone_object("/players/rumplemintz/weapon/bonsword");
  move_object(weapon,this_object());
  armor=clone_object("/players/rumplemintz/armor/boamulet");
  move_object(armor,this_object());
}
