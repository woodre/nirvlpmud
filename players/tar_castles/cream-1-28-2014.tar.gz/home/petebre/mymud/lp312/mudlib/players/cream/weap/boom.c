
inherit "obj/weapon";
reset(arg) {
::reset(arg);
if(arg) return;
set_name("axe");
set_alias("axe of hurling");
set_short("An axe of hurling");
set_long("This is the axe of hurling that served Ragnarok the Ranger well.\n"+
         "To use it, just [hurl at <opponent].\n");

set_class(20);
set_weight(6);
set_value(12000);
}


init(){
       add_action("hurl","hurl");
       add_action("cast","cast");
      }

hurl(str){
       object ob,dest;
       string who,what;
if(!str || sscanf(str, "at %s",who) !=1) {
write("You have to [hurl at <target>].\n");
     return 1;
     }

if(!find_player(who)) {
    write(capitalize(who)+" is not in this domain.\n");
    return 1;
    }

dest = environment(find_player(who));
write("You hurl the axe at "+capitalize(who)+".\n");
ob = find_player(who);
say(capitalize(this_player()->query_name())+" hurls the axe at "+capitalize(who)+".\n");
ob = find_living(who);
move_object(this_object(),dest);
tell_room(dest, capitalize(who)+" is struck in the chest by an axe of hurling.\n");
ob->hit_player(20);
return 1;
}

