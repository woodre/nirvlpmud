reset(arg) {
        if(arg) return;
        /* Initialization code goes here */

}
long() {
write("This is a vending machine, type 'list' to see ");
write("what you can purchase.\n");
        return 1;
}

short() {
   return "A vending machine";
}

id(str) {
        if( str == "machine" ) return 1;
        return 0;
}

init() {
        add_action( "buy", "buy" );
        add_action( "list", "list");
        return 1;
}

query_weight()
{   return 50;
}

list()
{ cat("/players/cream/heals");
    return 1;
  }

buy(str)
{  int value,choice;
   object cosa;
   string name;
   if((!str) || ((sscanf(str,"%d",choice) !=1)))
     { tell_object(this_player(),"Buy what?!?\n");
       return 0;
     }
   if (choice<1 || choice>5)
    { tell_object(this_player(),"You can only choose items from 1 to 5.\n");
      return 0;
    }  
   if (choice==1)
   { value=5000;
     if(call_other(this_player(),"query_money",)<value) { write("You don't have enough money.\n"); return 1; } 
cosa=clone_object("players/cream/heal/exa.c");
name="a healing potion";
   }

   if (choice==2)
   { value=1200; 
     if(call_other(this_player(),"query_money",)<value) { write("You don't have enough money.\n"); return 1; } 
     cosa=clone_object("players/trix/castle/dismonst/machine/hashish.c");
     name="a joint of hashish"; 
   }

   if (choice==3)
   { value=2400; 
     if(call_other(this_player(),"query_money",)<value) { write("You don't have enough money.\n"); return 1; } 
     cosa=clone_object("players/trix/castle/dismonst/machine/xtc.c");
     name="an ecstasy"; 
   }

   if (choice==4)
   { value=3000; 
     if(call_other(this_player(),"query_money",)<value) { write("You don't have enough money.\n"); return 1; } 
     cosa=clone_object("players/trix/castle/dismonst/machine/acid.c");
     name="a dragon acid"; 
   }

   if (choice==5)
   { value=10000; 
     if(call_other(this_player(),"query_money",)<value) { write("You don't have enough money.\n"); return 1; } 
     cosa=clone_object("players/trix/castle/dismonst/machine/cocaine.c");
     name="1 gram of cocaine"; 
   }
   move_object(cosa,this_player());
   tell_object(this_player(),"You push button number "+choice+" and "+name+" falls in your hand.\n");
   call_other(this_player(), "add_money", - value);
   return 1;
}

get() {
        return 0;
}

drop() {
        return 1;
}
