inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Empty room";
  long_desc = 
   "Plain room with white-wash walls.\n";
  no_exits = 1;
  property = ({"NT", "NF"});
  dest_dir = ({"/players/cream/workroom.c", "out"});
  }
}
