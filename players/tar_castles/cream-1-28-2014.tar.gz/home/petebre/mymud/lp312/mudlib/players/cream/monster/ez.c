inherit "obj/monster";

reset(arg){
   object gold,armor,weapon,basmon;
   ::reset(arg);
   if(arg) return;
   set_name("basic monster");
   set_race("monster");
   set_alias("basic");
   set_short("Basic monster");
   set_long("This is a basic monster.\n");
set_level(2);
   set_hp(100);
   set_al(-1000);
   set_ac(6);
   set_chance(30);
   set_spell_dam(50);
set_spell_mess1("The monster shrieks and deafens you.");
set_spell_mess2("Your ears ring for a few seconds.\n");
   set_chat_chance(10);
load_chat("Don't hurt me......I'm not bothering you am I?\n");
load_chat("Ok, if you want it that way, AHHHHHHHHHHHHH.\n");
   gold=clone_object("obj/money");
   gold->set_money(random(100)+200);
   move_object(gold,this_object());
weapon= clone_object("players/saber/mini/gypsy");
   move_object(weapon,this_object());
armor=clone_object("players/sandman/paladin/obj/boots");
   move_object(armor,this_object());
basmon=clone_object("players/saber/closed/bards/coat_of_arms");
move_object(basmon,this_object());
}
