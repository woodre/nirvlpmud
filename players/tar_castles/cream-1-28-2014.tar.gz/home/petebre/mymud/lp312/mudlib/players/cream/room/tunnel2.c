object howl, amu, money;
reset(arg)
{
   if(!arg)
   set_light(1);
   extra_reset();
}

extra_reset()
{
}

init()
{
add_action("south","south");
add_action("black","blackadder");
add_action("scathe","scathe");
add_action("hawkeye","hawkeye");
add_action("trix","trix");
}

south() {
this_player()->move_player("south#players/cream/room/tunnel1");
return 1; }
black() {
this_player()->move_player("blackadder castle#players/blackadder/entrance");
return 1; }
scathe() {
this_player()->move_player("Scathe's cave#players/scathe/cave/entry");
return 1; }
hawkeye() {
this_player()->move_player("Hawkeye's time portal#players/hawkeye/room/entrance");
return 1; }
trix() {
this_player()->move_player("Trix's Realm#players/trix/castle/center");
return 1; }

short()
{
return "The Assassins tunnel 2";
}

long()
{
write("The Assassins Tunnel 2\n"+
"You are inside one of the most famous underground tunnel in the MUD\n"+
"This room tunnel will lead you to some destination in wizards castle.\n"+
"You see some ladders lead you up to the door on the ceiling.\n"+
"You also see exit to south.\n"+
"The obvious exits: south, blackadder, scathe, hawkeye, trix.\n");
}
