inherit "obj/monster";

reset(arg){
   object gold,armor,weapon,basmon;
   ::reset(arg);
   if(arg) return;
   set_name("ugly monster");
   set_race("monster");
   set_alias("ugly");
   set_short("Ugly monster");
set_long("This monster smells and looks deformed.\n");
set_level(1);
   set_al(-1000);
   set_chance(30);
   set_spell_dam(50);
set_spell_mess1("The monster pukes on you.");
set_spell_mess2("You puke from the smell in this room.\n");
set_chat_chance(50);
load_chat("You the one stinks so bad, or is that me?\n");
load_chat("The monster spits on you.\n");
 gold=clone_object("players/sandman/paladin/obj/boots");
   move_object(gold,this_object());
}
