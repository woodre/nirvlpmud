id(str) { return str == "potion"; }
 
reset() {}
 
long() { write("A healing potion. Quaff to drink.\n"); }
 
short() { return "A healing potion"; }
 
init() {
    add_action("cast"); add_verb("grant");
    add_action("drink"); add_verb("quaff");
    add_action("drop_object"); add_verb("drop");
}
 
get() { return 1; }
 
query_weight() { return 0; }
 
query_value() { return 5000; }
 
 cast(str)  {
string who;
  int amt;
     object ob;

 if(!str || sscanf(str, "%s %d", who, amt)!=2) {
   write("sp <who> <amt>\n");
  return 1;
}
   ob = find_player(who);
   if(!ob) {
    write(capitalize(who)+" is not on.\n");
  return 1;
}
   call_other(ob, "add_spell_point", amt);
  write("You have given "+capitalize(who)+" "+amt+" of sps.\n");
  return 1;
}

drink()
{
call_other(this_player(), "add_spell_point", 350);
write("You regain your spell points, ");
write("the potion is used up.\n");
    destruct(this_object());
return 1;
}
sip(str) {
    int amt;
    if(!str) {
    write("Usage: Quaff (amount).\n");
          return 1;
       }
     sscanf(str, "%d", amt);
  call_other(this_player(), "add_spell_point", amt);
       return 1;
 }
