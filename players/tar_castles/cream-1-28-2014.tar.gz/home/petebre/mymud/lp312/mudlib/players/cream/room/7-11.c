inherit "room/room";
#define charge call_other(this_player(), "add_money", 0 - value );
#define sp_potion "players/cream/heal/exa"
#define big_gulp "players/lew/drinks/big_gulp"
#define sp_potion "players/cream/heal/exa"
#define mystic "players/lew/drinks/mystic"
#define beer "players/lew/drinks/beer"
#define carry if(!call_other(this_player(), "add_weight", weight)) { write("You can't carry more.\n") return 1; }
object drink;
reset(arg){
   object guard;
   if(!arg) {
      set_light(1);
      short_desc = "Magic Shop";
      long_desc =
"This is a magic shop. You see a glass window with a row of colored\n"+
"vials behind it.  An old man sits at a stool behind the window\n"+
"and seems pretty preoccupied\n"+
"Knock to get his attention.\n";
      
      
      dest_dir = ( {
            "players/lew/commons", "south",
            });
   }
   
}
init() {
   ::init();
   
   add_action("buy"); add_verb("buy");
   add_action("knock"); add_verb("knock");
}

knock() {
   
write("You get the old man's attention and he slides open a door\n"+
"in the window and he shows you a list of what he has.\n"+
"You may buy the following.\n"+
"\n"+
"   #         item      price\n"+
"\n"+
      "1. slurpie            1000 coins\n"+
      "2. big gulp           2000 coins\n"+
      "3. Super BIG Gulp     5000 coins\n"+
      "4. Mystic tea        10000 coins\n"+
      "5. Beer (6 pack)     6000 coins\n"+
"\n"+
      "Purchase by number.\n");
   return 1;
}

buy(str) {
   int value, weight, i;
   if(!str) { write("The manager says:  What was that you weesh to purchase?\n");return 1;}
   if(str=="1") { value=1000; weight==1; drink==sp_potion; charge;
      move_object(clone_object(drink), this_player());
      write("Ok.\n");
      return 1; }
  if(str=="2") { value=2000; charge; move_object(clone_object(big_gulp), this_player()); write("Ok.\n");
    return 1; }
  if(str=="3") { value=5000; charge; move_object(clone_object(sp_potion), this_player());
  write("Ok.\n"); return 1; }
  if(str=="4") { value=10000; charge;
    move_object(clone_object(mystic), this_player());
    write("Ok.\n");
    return 1; }
   if(str=="5") { value=6000; charge;
   move_object(clone_object(beer), this_player());
   move_object(clone_object(beer), this_player());
   move_object(clone_object(beer), this_player());
   move_object(clone_object(beer), this_player());
   move_object(clone_object(beer), this_player());
   move_object(clone_object(beer), this_player());
   write("Ok.\n");
   return 1;}
}
