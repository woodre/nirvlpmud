inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("dig","dig");
   add_action("detect","detect");
   add_action("west","west");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A crossroads";
   
   long_desc="You`re at a crossroads.  There are beaches to the east and west.\n"+
   "The peninsula and pier are to the north while the town lies to the\n"+
   "south.\n\n"+
   "THE WEST IS UNDER CONSTRUCTION.\n\n";
   
   items=({"crossroads","This crossroads joins the beaches with the pier (to\n"+
         "the north) and the road to town (to the south)",
         "beaches","They look sunny and warm.  You almost want to take a swim or\n"+
         "build a sand castle",
         "construction","Workers look busy as they hurry to complete the realm",
         "peninsula","It seems to be a manmade structure that leads to the pier",
         "pier","It looks like an interesting and busy place",
         "structure","It`s shaped in a buttress form and looks like this:\n"+
         "                    --------------------\n"+
         "                   !                    !\n"+
         "                  !                      !\n"+
         "                 !                        !\n"+
         "                !                          !\n"+
         "                ----------------------------\n"+
         "It looks very strong",
         "town","The town is to the south"});
   
   dest_dir=({"/players/predator/realm/pier/pier1","north",
         "/players/predator/realm/beach/beach3","east",
         "/players/predator/realm/beach/beach1","south",
         "/players/predator/realm/beach/beach66","west"});
}

search() {
   write("You look around examining everything you see but find nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+"searches the area.\n");
   return 1;
}

dig() {
   if(!present("shovel", this_player())) {
      write("Yeah right.  You plane to dig up a road with your hands?\n");
      say(capitalize(this_player()->query_real_name())+" feels like an idiot.\n");
      return 1;
   }
   
   write("The ground here is too hard packed to dig.\n");
   return 1;
}

detect() {
   if(!present("detector", this_player())) {
      write("How could you detect anything without a metal detector?\n");
      say(capitalize(this_player()->query_real_name())+" feels like an idiot.\n");
      return 1;
   }
   
   write("The road is too well-traveled for you to hope to find anything.\n");
   return 1;
}

west() {
   write("A foreman steps out from the piles of materials and says: Sorry,\n"+
      "but this area is closed off until further notice.\n");
   say(capitalize(this_player()->query_real_name())+" tries to go west but is\n"+
      "stopped by a foreman and decides to stay where "+this_player()->query_pronoun()+" is.\n");
   return 1;
}
