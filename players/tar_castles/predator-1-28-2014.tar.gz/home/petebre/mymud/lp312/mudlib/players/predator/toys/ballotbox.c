inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_id("booth");
   set_alias("voting booth");
   set_short("A voting booth");
   set_long("This voting booth seems sort of out of place, but you seem strangely\n"+
      "drawn to enter it.  It is totally encased except for a curtain that hangs\n"+
      "on one side.\n");
   
   set_weight(100);
   set_value(10000);
}

init() {
   ::init();
   add_action("enter_booth","enter");
   add_action("open_curtain","open");
   add_action("examine_curtain","examine");
   add_action("exa_curtain","exa");
   add_action("close_curatin","close");
}

examine_curtain(str) {
   
   write("It`s just a curtain that hangs across one side of the booth.\n");
   return 1;
}

exa_curtain(str) {
   
   write("It`s just a curtain that hangs across one side of the booth.\n");
   return 1;
}


enter_booth() {
   this_player()->move_player("into the booth#/players/predator/realm/ballotroom");
   return 1;
}
