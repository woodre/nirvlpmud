inherit "obj/food";

reset(arg) {
   set_name("potion");
   set_alt_name("healing potion");
   set_alias("healing potion");
   set_short("A nomadic healing potion");
   set_long("This is a nomadic healing potion, created from the mysteries of\n"+
      "the nomadic mages.  No one is quite sure how they are made.\n");
   set_weight(0);
}

init() {
   add_action("drink","drink");
}

drink(str) {
   if(!str) {
      return 0;
   }
   
   else if(str!= "potion" && str!= "healing potion") {
      return 0;
   }
   
   write("You lift the potion to your mouth and drink.  All of the sudden you\n"+
      "feel as if a new life charge has been born in you.\n");
   say(capitalize(this_player()->query_real_name())+" drinks a nomadic potion.\n");
   this_player()->add_hit_point(30);
   this_player()->add_spell_point(30);
   destruct(this_object());
   return 1;
}
