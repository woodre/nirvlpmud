inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="In A Desert";
   
   long_desc="You are in a desert.  To the north you can see a sort of road, you think.\n"+
   "To the east and west is just more desert, and a look to the south reveals\n"+
   "what looks like a forbidding part of the desert.\n\n";
   
   dest_dir=({"/players/predator/realm/desert/desert13","north",
         "/players/predator/realm/desert/desert19","east",
         "/players/predator/realm/desert/desert23","south",
         "/players/predator/realm/desert/desert17","west"});
}

search() {
   write("You look around carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}
