inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("butt","butt");
   add_action("butt","headbutt");
   add_action("butt","hit");
   add_action("butt","charge");
   add_action("not","kill");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="The Troll's Bridge";
   
   long_desc="You have walked onto a flat wooden bridge that spans the river.  The planks\n"+
   "look old, but strong.  The river flows beneath you, twisting and turning in\n"+
   "pursuit of itself, until it fades out of your sight.  What you thought to\n"+
   "be some sort of shadow turned out to be a troll, guarding his bridge.\n\n";
   
   items=({"bridge","The bridge looks old, but sturdy",
         "river","The river flows beneath the bridge.  You wonder where it leads",
         "shadow","It materialized as a troll",
         "troll","He looks ferocious"});
   
   dest_dir=({"/players/predator/realm/desert/dsrt_clrng","east",
         "/players/predator/realm/desert/dsrt_gorge3","west"});
   
   if(!present("troll")) {
      move_object(clone_object("/players/predator/monster/desert/troll"), this_object());
   }
}

search() {
   write("You look around the area carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}

butt() {
   if(present("troll")) {
      write("You lower your head and charge the troll.  The troll is caught off balance.\n"+
         "With every ounce of energy you can muster you slam into the troll!\n");
      say(capitalize(this_player()->query_name())+" charges the troll!\n");
      call_out("fall", 2);
      return 1;
   }
}

fall() {
   write("The troll teeters on the edge of the bridge for what seems an eternity, then\n"+
      "falls off the side.\n");
   say("The troll teeters on the edge of the bridge for what seems an eternity, then\n"+
      "falls off the side.\n");
   call_out("destruct", 0);
   call_out("help", 2);
   return 1;
}


destruct() {
   destruct(this_object());
   return 1;
}

help() {
   write("You hear a, `Help!  I can't swim!!' and then just a Glug glug glug...\n");
   say("You hear a, `Help!  I can't swim!!' and then just a Glug glug glug...\n");
   return 1;
}

kill(str) {
   if(!str) {
      return 0;
   }
   
   else if(str != "troll") {
      return 0;
   }
   
   else if(str == "troll") {
      int num;
      num = random(3);
      
      write("The troll looks at you and says, `I don'n think so pal.'\n"+
         "The troll pulls out a shotgun and blows you away!\n");
      if(num = 0) {
         write("You are hit in the leg!\n");
         call_other(this_player(), add_hit_point(-50));
         return 1;
         }
      
      else if(num = 1) {
         write("You a hit in the shoulder!\n");
         call_other(this_player(), add_hit_point(-50));
         return 1;
         }
      
      else if(num = 2) {
         write("You a hit in the thigh!\n");
         call_other(this_player(), add_hit_point(-50));
         return 1;
         }
      
      say("The troll blows away "+capitalize(this_player()->query_name())+" with his shotgun!\n");
   }
}
