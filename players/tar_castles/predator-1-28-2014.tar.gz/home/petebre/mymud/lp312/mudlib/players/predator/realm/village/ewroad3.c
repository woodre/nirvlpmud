#include "/players/balowski/lib.h"
inherit ROOM;

init() {
   ::init();
   add_action("search","search");
   add_action("smell","smell");
   add_action("listen","listen");
}

void
reset(int arg)
{
    ::reset(arg);
    if (arg)
        return;
    set_short("A east-west road");
    set_long(
	"The road continues west to the town...\n"+
	"The beach seems to move away from the road to the north, and\n"+ 
	"the forest presses very close to the road to the south.  You\n"+
	"see the gates to the town before you, and some guardhouses\n"+
	"on both side.\n\n"+
	"There is a sign on the side of the road...\n"
	);
    set_items(([
        "road" :
        "A well maintained dirt road, very wide and well travelled...\n",
	"forest" :
	"The forest to the south gets extremely dense, almost unpenatrable.\n",
	"beach" :
	"Waves crash against the distant beach to the north, many dunes away.\n",
	"ditch" :
	"A VERY steep incline, maybe you can cross further down the road.\n",
	"town" :
	"The town gates are almost in front of you, blocking your view...\n",
	"sign" :
	"========================\n"+
	"| You are now entering |\n"+
	"| the town of Penual.  |\n"+
	"|                      |\n"+
	"| Population: 5013     |\n"+
	"========================\n",
	"gates" :
	"The gates to the town, protected by two guardhouses on either side\n"+
	"of the road...\n",
	"guardhouses" :
	"There are some guardhouses protecting the gates.\n"
	]));
    set_exits(([
/*
        "west" : "/players/reflex/realms/paran/road07",
*/
        "east" : "/players/predator/realm/village/ewroad2",
        ]));
    set_light(1);

    replace_program(ROOM);
}

search() {
   write("You look around examining everything closely, but see nothing\n"+
      "unusual.\n");
   
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   
   return 1;
}

smell() {
    write("You smell dust from the road...\n");
    return 1;
;
}
