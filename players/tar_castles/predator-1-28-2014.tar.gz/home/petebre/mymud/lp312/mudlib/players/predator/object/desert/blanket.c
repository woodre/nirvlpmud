inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   
   set_id("blanket");
   set_alias("old blanket");
   set_short("An old Bedouin blanket");
   set_long("This is an old gray and maroon blanket.  It look heavily used.\n");
   set_weight(3);
   set_value(225);
}

init() {
   ::init();
   add_action("wear","wear");
}

wear(str) {
   if(str == "blanket" || str == "old blanket") {
      write("The blanket is too old and worn.  It slips off your shoulders.\n");
      say(capitalize(this_player()->query_name())+" tries to wear an old blanket but it slips off "+this_player()->query_possessive()+" shoulders.\n");
      return 1;
   }
}
