inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(!arg) {
      int num;
      set_level(13);
      set_ep(300000);
      set_hp(400);
      set_wc(13);
      set_ac(9);
      set_al(100);
      set_name("thief");
set_short("\n\n"+
"A thief hiding in the shadows waiting so he can jump you and\n"+
"steal all your stuff and leave you for dead so he can go and sell you\n"+
"your loot because he wants to get money but he won't be able to sell it for\n"+
"a whole lot because they're hot items and he'll probably get ripped off\n"+
"by whoever hawks it off him.");
set_long("Just anonther ordinary thif.\n");
}
}
