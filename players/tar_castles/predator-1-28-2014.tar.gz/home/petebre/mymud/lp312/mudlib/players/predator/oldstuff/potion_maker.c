inherit "obj/treasure";
object vial;
int hitpoint, spellpoint;
int cost;

reset(arg) {
   if(!arg) {
 
      set_id("maker");
      set_alias("vial maker");
      set_short("A machine of healing vials");
      set_long("This is a vial maker.  You can see a sign on the side of it "+
         "that says,\nbuy vial #hp's/#sp's (Example: buy vial 120/80 "+
         "would heal you 120 hit\npoints and 80 spell points.)\n");
      set_value(0);
      set_weight(99999);
   }
}

init() {
   add_action("buy"    ,"buy");
}

buy(str) {

   if(!this_player()->add_weight(3)) {
      write("Alas, you cannot carry the vial.\n");
      return 1;
   }

   if(sscanf(str, "vial %d/%d", hitpoint, spellpoint) != 2) {
      write("Try 'buy vial <# of hp's>/<# of sp's>'\n");
      return 1;
   }

   cost = 15 * hitpoint + 5 * spellpoint + random(20) - 10;
   if(this_player()->query_money() < cost) {
      write("You cannot pay for the vial of healing.\n");
      return 1;
   }

   if(hitpoint > 300 || spellpoint > 300) {
      write("The machine cannot make healing vials that strong.\n");
      return 1;
   }

   if(hitpoint < 0 || spellpoint < 0) {
      write("You cannot order healing vials for negative healing.\n");
      return 1;
  }

   write("You pay "+cost+" coins for a vial of "+hitpoint+" hit points and "+
      spellpoint+" spell points.\n");
   say(this_player()->query_name()+" buys a healing vial.\n");
   vial = clone_object("players/predator/potion");
   tell_room("/players/predator/workroom", "The vial is now in "+
      environment(this_object())->short()+".\n");
   vial->set_hitpoint(hitpoint);
   vial->set_spellpoint(spellpoint);
   move_object(vial, this_player());
   this_player()->add_money(-cost);
   return 1;
}
