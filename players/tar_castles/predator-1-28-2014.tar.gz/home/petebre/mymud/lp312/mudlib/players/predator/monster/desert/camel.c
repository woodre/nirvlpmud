inherit "obj/monster";

init() {
   ::init();
   add_action("cant","mount");
   add_action("cant","ride");
   add_action("cant","get on");
}

reset(arg) {
   ::reset(arg);
   if(!arg) {
      set_level(10);
      set_ep(2000000);
      set_hp(1500);
      set_wc(13);
      set_ac(15);
      set_al(500);
      set_name("camel");
      set_short("A camel");
      set_long("The camel is the best transport in the desert.  It is capable of traveling\n"+
         "up to 2 weeks without water.  This camel looks like he just drank up the\n"+
         "whole oasis.\n");
      set_chat_chance(10);
      set_a_chat_chance(10);
      load_chat("The camel noisily slurps from the waterhole.\n");
      load_a_chat("The camel thrusts his head forward and pukes on you.\n");
      
      move_object(clone_object("players/predator/armor/desert/cml_skin"), this_object());
   }
}

cant(str) {
   if(!str) {
      return 0;
   }
   
   else if(str != "camel") {
      return 0;
   }
   
   else if(str == "camel") {
      write("The camel skittishly moves away as you try to mount him.\n");
      say(capitalize(this_player()->query_real_name())+" unsuccessfuly tries to mount the camel.\n");
      return 1;
   }
}
