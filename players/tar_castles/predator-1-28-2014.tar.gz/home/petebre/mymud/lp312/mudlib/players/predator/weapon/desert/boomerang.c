inherit "obj/treasure";

reset(arg) {
   if(!arg) {
      
      set_id("boomerang");
      set_alias("wooden boomerang");
      set_short("A wooden boomerang");
      set_long("A wooden boomerang.  It looks made well and is nicely weighted.\n"+
         "If you throw it maybe it would come back to you.\n");
      set_weight(2);
      set_value(485);
   }
}

init() {
   add_action("throw"   ,"throw");
}

throw(str) {
   string who;
   object target;
   
   if(!str) {
      return 0;
   }
   
   if(sscanf(str, "boomerang at %s", who) != 1) {
      write("Try throwing the boomerang at something.\n");
      return 1;
   }
   
   target = find_living(lower_case(who));
   if(!target || !present(target, environment(this_player()))) {
      write("There is nothing like that here.\n");
      return 1;
   }
   
   if(!target->query_npc() && !target->query_pl_k()) {
      write("You may not throw your boomerang at that person.\n");
      return 1;
   }
   
   write("You take the boomerang and hurl it at "+capitalize(who)+".\n");
   
   say(this_player()->query_name()+" hurls "+this_player()->query_possessive()+" boomerang at "+capitalize(who)+".\n");
   call_other(target, "hit_player", 20 + random(15));
   move_object(clone_object("/players/predator/weapon/desert/boom_wait"),          this_player());
   destruct(this_object());
   return 1;
   
   call_other(target, "attacked_by", this_player());
   call_other(this_player(), "attack_object", target);
   call_other(this_player(), "attack", target);
}
