inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Desert Entrance";
   
   long_desc="You are on a sandy path that connects the crossroads with the desert.\n"+
   "To the east is a hot looking desert and the crossroads lie to the east.\n"+
   "To your north and south passage is blocked by high and steep mountains.\n";
   
   items=({"path","The path links the desert to the crossroads",
         "crossroads","They are to your east",
         "desert","The desert lies to your west",
         "mountains","They are high and very steep.  Climbing them seems impossible"});
   
   dest_dir=({"/players/predator/realm/village/xroad1.c","east",
         "/players/predator/realm/desert/desert14","west"});
}

search() {
   write("You carefully scan the area but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
