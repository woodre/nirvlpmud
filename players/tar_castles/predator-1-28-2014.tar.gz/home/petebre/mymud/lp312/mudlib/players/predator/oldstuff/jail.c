inherit "room/room";

init() {
   ::init();
   add_action("search");
}

reset(arg) {
   if (arg) return;
   
   set_light(1);
   
   short_desc="Predator's Workroom";
   
   long_desc = "A very bleak jail dude\n\n";
   
   items=({"workroom","Why don`t you just look around...",
         "things","Read the rest of the sentence, stupid",
         "trophies","These trophies have been well cared for, you note",
         "skulls","Skulls are skulls",
         "spinal cord","It`s been carefully cleaned and well preserved",
         "cord","It`s been carefully cleaned and well preserved",
         "container","It seems like this container is like a permanent\n"+
         "mummification device",
         "walls","The gray walls are very Spartan looking"});
   
   dest_dir=({"room/church","church",
         "room/orc_dump","realm",
         "room/adv_guild","guild"});
}

search() {
   write("You search in every nook and cranny you can thing of, but\n"+
      "turn up nothing.\n");
   return 1;
}
