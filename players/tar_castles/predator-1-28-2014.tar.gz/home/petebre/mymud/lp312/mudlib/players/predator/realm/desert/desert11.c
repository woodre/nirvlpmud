inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Desert Middle";
   
   long_desc="This is a sort of road that you assume cuts throught the middle of the\n"+
   "desert.  It's very hot, and the reflection of the sun in the sand glares in\n"+
   "your eyes.  All around you all you can see is desert.\n\n";
   
   items=({"road","You can barely call it a road.  but it definately has a shape, even\n"+
         "though the sands of the desert constantly blow across it",
         "reflection","It's so bright it almost blinds you",
         "desert","The desert is indeed a bleak and desolate place",
         "sun","You can see it`s reflection on the hot sands"});
   
   dest_dir=({"/players/predator/realm/desert/desert4","north",
         "/players/predator/realm/desert/desert12","east",
         "/players/predator/realm/desert/desert16","south",
         "players/predator/realm/desert/desert10","west"});
}

search() {
   write("You carefully scan the area but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
