inherit "room/room";

init() {
   ::init();
   object check;
   int i;
   
   add_action("search","search");
   
   check = allocate(50);
   i = 0;
   check=all_inventory(this_object());
   if(all_inventory(this_object())) {
      while(i<sizeof(check)) {
         if(!living(check[i])) {
            destruct(check[i]);
            return 1;
            }
         i += 1;
      }
   }
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A Desert";
   
   long_desc="You are in the middle of a desert.   The sun reflects off the hot sand and\n"+
   "disorients you.  Everything starts to look the same.\n\n";
   
   items=({"desert","It is extremely hot in this desert",
         "sun","The sun harshly glares down on the sands.  You can painfully feel it's\n"+
         "immense heat radiating from it.",
         "heat","The heat is very hot",
         "sand","The sand is burning hot"});
   
   dest_dir=({"/players/predator/realm/desert/desert3","north",
         "/players/predator/realm/desert/desert4","east",
         "/players/predator/realm/desert/desert10","south",
         "/players/predator/realm/desert/desert3","west"});
   
}

search() {
   write("You look around but notice nothing other than the sand.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}

