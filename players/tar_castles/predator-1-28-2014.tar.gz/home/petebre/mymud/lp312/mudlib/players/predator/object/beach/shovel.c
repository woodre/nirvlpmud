inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   
   set_id("shovel");
   set_short("A shovel");
   set_weight(1);
set_long("This looks like a well-made shovel.\n");
   set_value(30);
}

init() {
   add_action("wield_shovel","wield");
}

wield_shovel() {
   write("The shovel would make a poor weapon.  You decide not to wield it.\n");
   return 1;
}
