inherit "room/room";

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   set_short="A peninsula";
   
   set_long="You are on a short but important peninsula.  Not too far to the north\n"+
   "you can see the pier and the ships that are docked there.  To the south is\n"+
   "the village and on your east and west lies the endless expanse of azure\n"+
   "blue ocean.  The peninsula is about 40 feet wide, and rises around 15 feet\n"+
   "above the water.  It is definately manmade, but you wonder who made it,\n"+
   "since the type of structure seems too advanced for the citizens of Randolin\n";
