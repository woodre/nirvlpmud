inherit "obj/treasure";

reset(arg) {
   if(!arg) {
      
      set_id("titler");
      set_short("A titler");
      set_long("A titler, change someone's title.\n");
      set_weight(500);
      set_value(0);
   }
}

init() {
   add_action("newtitle"  ,"ptitle");
}

newtitle(str) {
   string who, what;
   object target;
   
   if(!str) {
      return 0;
   }
   
   if(sscanf(str, "%s to %s", who, what) != 2) {
      write("Try `title <person> to <new title>'.\n");
      return 1;
   }
   target = find_living(lower_case(who));
   
if(!target) {
write("No such person on right now.\n");
return 1;
}

   write("You set "+who+"'s title to "+what+".  Heheheheeee...\n");
   target->set_title(what);
   tell_object(target, "Something seems wierd about "+what+"...\n");
   return 1;
}
