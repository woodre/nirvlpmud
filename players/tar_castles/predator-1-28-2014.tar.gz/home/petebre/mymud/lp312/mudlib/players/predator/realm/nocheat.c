id(str) {
   return str == "nocheatdevice";
}

short() { 
   return 0;
}

long() {
   return 0;
}

get() { 
   return 1;
}

drop() {
   return 1;
}
