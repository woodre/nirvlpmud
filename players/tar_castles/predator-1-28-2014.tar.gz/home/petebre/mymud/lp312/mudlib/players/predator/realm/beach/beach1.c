inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("dig","dig");
   add_action("detect","detect");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A path towards the beach";
   
   long_desc="You are on a short path leading to the beach that seems to\n"+
   "surround the ocean.  To your north is the lively pier, which seems to\n"+
   "be larger than you had first thought.  The town lies to the south.\n\n";
   
   items=({"path","It leads from the crossroads to the beach",
         "beach","The beach looks lovely, and makes you feel like taking a dip",
         "ocean","It stretches out as far as you can see..",
         "peninsula","It seems to be manmade, as the shape it`s in is not at\n"+
         "all natural by any means.  You`re puzzled as to who built it, since\n"+
         "the structure of the buildings in the town is very different",
         "shape","The shape of the peninsula is a buttress, which looks like:\n"+
         "                 --------------------                   \n"+
         "                l                    l                  \n"+
         "               l                      l                 \n"+
         "              l                        l                \n"+
         "             l                          l               \n"+
         "            l                            l              \n"+
         "            ------------------------------              \n"+
         "It seems very strong",
         "pier","The pier has turned out to be what you surmise is a peninsula\n"+
         "which extends into the ocean before becoming joining the pier",
         "town","The town lies to the south"});
   
   dest_dir=({"/players/predator/realm/beach/beach2.c","north",
         "/players/predator/realm/village/xroad1","south"});
}

search() {
   write("You search the area carefully but turn up nothing of interest.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}

dig() {
   if(!present("shovel", this_player())) {
      write("Yeah right.  You plan to dig up a road with your hands?\n");
      say(capitalize(this_player()->query_real_name())+" feels like an idiot.\n");
      return 1;
      
   }
   write("The ground is way too hard to try to dig.\n");
   say(capitalize(this_player()->query_real_name())+" looks at the ground like "+this_player()->query_pronoun()+" would like to dig, but then\n"+
      "changes "+this_player()->query_possessive()+" mind.\n");
   return 1;
}

detect() {
   if(!present("detector", this_player())) {
      write("How could you detect anything without a metal detector?\n");
      say(capitalize(this_player()->query_real_name())+" feels like an idiot.\n");
      return 1;
   }
   
   write("The ground is too well traveled to yield anything.\n");
   return 1;
}
