inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   
   set_id("stem");
   set_alias("date stem");
   set_short("The stem from some dates");
   set_long("This is the stem from some dates that were obviously eaten.\n");
   set_weight(1);
   set_value(15);
}
