inherit "obj/treasure";

reset(arg) {
   if(!arg) {
    set_id("jailer");
    set_short("A jailer");
    set_long("To use: type jail <player>\n");
    set_weight(1);
    set_value(1);
   }
}

init() {
   ::init();
  add_action("jail"  ,"jail");
}

jail(str) {
object target;
target = find_living(str);

if(!str) {
   write("No such person.\n");
   return 1;
}

write("You put "+str+" in jail.\n");
tell_object(target, "You have been naughty.  You are going to jail.\n");
call_other(target, "move_player", "screaming#/players/predator/jail");
return 1;
}
