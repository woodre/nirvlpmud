id(str) {
   return "nobuysell";
}

short() {
   return 0;
}

long() {
   return 0;
}

get() {
   return 1;
}

drop() {
   return 1;
}

init() {
   add_action("buy_thing","buy");
   add_action("sell_thing","sell");
   add_action("sell_thing","xsell");
}

sell_thing(str) {
   object obj;
   if(!str) {
      return 0;
   }
   
   if(str == "all") {
      write("With that thief's brand on your forehead the shopkeeper won't let you sell\n"+
         "just one item, much less all of them!\n");
      return 1;
   }
   obj = present(str, this_player());
   
   if(!obj) {
      write("You may not sell what you do not have.\n");
      return 1;
   }
   
   if(obj->sell() || !obj->shot()) {
      write("You cannot sell that.\n");
      return 1;
   }
   
   write("The shopkeeper looks at you and says get out of here.\n");
   return 1;
}
