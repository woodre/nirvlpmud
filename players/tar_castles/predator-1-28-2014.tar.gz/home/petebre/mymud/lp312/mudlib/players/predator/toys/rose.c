
int charge;
reset(arg) {
   if(arg) return;
   charge = 3;
}

id(str) {
   return (str == "rose" || str == "red_rose");
}

short () {
   return "A pretty red rose";
}

long() {
   write("A beautiful rose that amazes your eyes and smells like heaven.\n");
}

get() {
   return 1;
}

query_weight() {
   return 1;
}

query_value() {
   return 45;
}

init() {
   add_action("smell_rose","smell");
}

smell_rose(str) {
   if((!str) || !id(str))
      {
      return 0;
   }
   if(charge == 0) {
      dest();
      return 1;
   }
   while(charge > 0) {
      charge--;
      
      write("You inhale the wonderful fragrances the rose has to offer.\n"+
         "You feel slightly better.\n");
      say(capitalize(this_player()->query_real_name())+" smells "+this_player()
         ->query_possessive()+" rose and seems refreshed.\n");
      
      this_player()->add_hit_point(5);
      
      return 1;
   }
}

dest() {
   write("The beautiful rose has lost all its fragrance...\n"+
      "It slowly withers and fades away into oblivion...\n");
   say("A once-beautiful rose falls to the floor and vanishes...\n");
   destruct(this_object());
   return 1;
}
