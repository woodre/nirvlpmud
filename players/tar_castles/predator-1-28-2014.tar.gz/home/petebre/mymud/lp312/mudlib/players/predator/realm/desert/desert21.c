inherit "room/room";
object drop_item;

init() {
   ::init();
   add_action("search","search");
   add_action("drop_something","drop");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A Desert";
   
   long_desc="You are in the middle of a desert.   The sun reflects off the hot sand and\n"+
   "disorients you.  Everything starts to look the same.\n\n";
   
   items=({"desert","It is extremely hot in this desert",
         "sun","The sun harshly glares down on the sands.  You can painfully feel it's\n"+
         "immense heat radiating from it.",
         "heat","The heat is very hot",
         "sand","The sand is burning hot"});
   
   dest_dir=({"/players/predator/realm/desert/desert16","north",
         "/players/predator/realm/desert/desert22","east",
         "/players/predator/realm/desert/desert21","south",
         "/players/predator/realm/desert/desert21","west"});
   
}

search() {
   write("You look around but notice nothing other than the sand.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}

drop_something(str) {
   if(!str) {
      return 0;
   }
   
   if(str == "all") {
      write("That would be unwise.  Your items would be lost.\n");
      return 1;
   }
   
   drop_item = present(str, this_player());
   if(!drop_item) {
      write("You cannot drop what you do not have.\n");
      return 1;
   }
   
   if(drop_item->drop() || !drop_item->short()) {
      write("You cannot drop that.\n");
      return 1;
   }
   
   destruct(drop_item);
   write("The "+str+" falls onto the burning sand and melts in a fiery flame.\n");
   say("A "+str+" falls onto the burning sand and melts in a fiery flame.\n");
   return 1;
}
