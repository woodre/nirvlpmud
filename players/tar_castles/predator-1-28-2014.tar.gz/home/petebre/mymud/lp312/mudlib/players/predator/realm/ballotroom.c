inherit "room/room";


init() {
   ::init();
   add_action("push_button","push");
   add_action("close_curtain","close");
   add_action("search","search");
   add_action("slogans","slogans");
   add_action("sit","sit");
}

reset(arg) {
   if (arg) return;
   
   set_light(1);
   
   short_desc="A voting booth";
   
   long_desc="You are in a small room.  As you look around you see that\n"+
   "the booth is a lot more high tech than you had assumed from the outside.\n"+
   "The small room that your`re in is lit by a single overhead flourescent\n"+
   "inset into the white ceiling.  The off-white walls have no markings on\n"+
   "them except for some campaing slogans.  In front of you is a chair and a\n"+
   "panel that`s fastened to the wall.  The panel has eight buttons on it.\n\n";
   
   items=({"room","You could just have easily looked around",
         "booth","You could just have easily looked around",
         "ceiling","The ceiling is totally white, but it`s an off-white so\n"+
         "it doesn`t glare in your eyes.  There is a small venitlation shaft\n"+
         "in one corner of it.",
         "walls","The walls are a off-white, and so spotless that you could\n"+
         "almost see your face in them, but you can`t.",
         "flourescent","Well whaduyuno...above you is a flourescent light...",
         "wall","wall, walls...big difference.",
         "markings","It said there weren`t any, stupid!",
         "shaft","It`s built into the ceiling, and is there so you don`t die\n"+
         "of suffocation while you`re in here.",
         "chair","There`s a chair sitting in front of you that you`d probably\n"+
         "want to sit in if you want to vote.  It`s bolted to the floor so\n"+
         "there`s no chance of you taking it. (Don`t even try.  Please.)",
         "panel","It`s a pretty sophisticated panel.  But as you sort the\n"+
         "buttons out, you see that basically there`s the name of each\n"+
         "candidate with a number beside the button by their name\n\n"+
         "           Rebuplicans:\n"+
         "                1.  George Bush\n"+
         "                2.  David Duke\n"+
         "                3.  Pat Buchanan\n\n"+
         "           Democrats:\n"+
         "                4.  Paul Tsongas\n"+
         "                5.  Bob Kerrey\n"+
         "                6.  Bill Clinton\n"+
         "                7.  Tom Harkin\n"+
         "                8.  Jerry Brown\n\n"+
         "To vote type `push button <button number for your candidate>'.\n\n"+
         "Thank you for voting.  Your vote will make a difference!",
         "buttons","They`re probably for you to push.",
         "button","It`s probably there for you to push",
         "slogans","Type `slogans' for some campaign slogans"});
   
   dest_dir=({"room/vill_road2","out"});
}

slogans() {
   int X;
   X=random(8);
   
   if(X==0) {
      write("The Man Who Can Do No Wrongness--Vote Tsongas!!\n");
      return 1;
   }
   if(X==1) {
      write("Our Campaign Is Not Scary--Vote Kerrey!!\n");
      return 1;
   }
   if(X==2) {
      write("The KKK Does Not Spook--Vote Duke!!\n");
      return 1;
   }
   if(X==3) {
      write("A Man Of Renown--Vote Jeffrey Brown!!\n");
      return 1;
   }
   if(X==4) {
      write("I Like Blueberry Dannon--Vote Buchanan!!\n");
      return 1;
   }
   if(X==5) {
      write("Foreign Police Will I Push--Vote Bush!!\n");
      return 1;
   }
   if(X==6) {
      write("About Vietnam..uh..I Wasn`t Wimpin'--(please) Vote Clinton!!\n");
      return 1;
   }
   if(X==7) {
      write("Up The Wrong Tree You`ll Be Barkin If You Don`t Vote Harkin!!\n");
      return 1;
   }
}

push_button(str) {
   string who, one;
   object thing;
   
   if(present("nocheatdevice", this_player())) { 
      write("Did you really think you would be allowed to vote twice?\n");
      return 1;
   }
   
   if(!str) {
      write("Correct voting procedure: Push button <Number of your candidate>\n"+
         "Example: Push button 2\n");
      return 1;
   }
   
   if(str=="button 1") {
      who = call_other(this_player(), "query_name");
      thing = clone_object("/players/predator/realm/nocheat");
      
      write("Thank you for voting.  Your vote for George Bush has been recorded.\n");
say("this player voted...
z
         "1"+"|"+who+"\n");
      move_object(thing, this_player());
      return 1;
   }
   
   else if(str=="button 2") {
      thing = clone_object("players/predator/realm/nocheat");
      write("Thank you for voting.  Your vote for David Duke has been recorded.\n");
      move_object(thing, this_player());
      return 1;
   }
   
   else if(str=="button 3") {
      thing = clone_object("players/predator/realm/nocheat");
      write("Thank you for voting.  Your vote for Pat Buchanan has been recorded.\n");
      move_object(thing, this_player());
      return 1;
   }
   
   else if(str=="button 4") {
      thing = clone_object("players/predator/realm/nocheat");
      write("Thank you for voting.  Your vote for Paul Tsongas has been recorded.\n");
      move_object(thing, this_player());
      return 1;
   }
   
   else if(str=="button 5") {
      thing = clone_object("players/predator/realm/nocheat");
      write("Thank you for voting.  Your vote for Bob Kerrey has been recorded.\n");
      move_object(thing, this_player());
      return 1;
   }
   
   else if(str=="button 6") {
      thing = clone_object("players/predator/realm/nocheat");
      write("Thank you for voting.  Your vote for Bill Clinton has been recorded.\n");
      move_object(thing, this_player());
      return 1;
   }
   
   else if(str=="button 7") {
      thing = clone_object("players/predator/realm/nocheat");
      write("Thank you for voting.  Your vote for Tom Harkin has been recorded.\n");
      move_object(thing, this_player());
      return 1;
   }
   
   else if(str=="button 8") {
      thing = clone_object("players/predator/realm/nocheat");
      write("Thank you for voting.  Your vote for Jerry Brown has been recorded.\n");
      move_object(thing, this_player());
      return 1;
   }
   else write("Proper voting procedure: Push button <Number of your candidate>\n"+
         "Example: Push button 2\n");
   return 1;
}

sit() {
   write("You sit in the chair and begin the voting process.\n");
   return 1;
}
