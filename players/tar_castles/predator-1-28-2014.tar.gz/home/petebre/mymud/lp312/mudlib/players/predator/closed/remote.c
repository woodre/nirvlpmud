reset(arg) {
   if(arg) return;
}

id(str) {
   return str == "control" || str == "remote control";
}

short() {
   return "";
}

long() {
   write("This remote control gadget is a conglomeration of buttons, switches,\n"+
      " dials, and just about anything else you can think of.\n");
}

get() {
   if(this_player()->query_real_name()!="reflex") {
      write("Do you want to get dested?\n");
      destruct(this_object());
      return 1;
   }}

query_weight() {
   return 1;
}

init() {
   add_action("say","say");
   add_action("force","fforce");
   add_action("tell","tell");
   add_action("shout","shout");
   add_action("invis_say","ssay");
   add_action("invis_tell","ttell");
   add_action("invis_shout","sshout");
   add_action("echo","echo");
   add_action("echoto","echoto");
   add_action("echoall","echoall");
   add_action("earmuffs_on","eao");
   add_action("earmuffs_off","eaf");
   add_action("heal","heal");
   add_action("pretitle","pretitle");
   add_action("title","title");
   add_action("setal","setal");
}

echoall(str) {
   if(!str)
      return 0;
   shout("\n"+str+"\n\n");
   write("You echo allover: "+str+"\n");
   return 1;
}

pretitle(str) {
   if(!str)
      return 0;
   this_player()->set_pretitle(str);
   write("Your pretitle is now: "+str+"\n");
   return 1;
}

title(str) {
   if(!str)
      return 0;
   this_player()->set_title(str);
   write("Your title is now: "+str+"\n");
   return 1;
}

setal(str) {
   if(!str)
      return 0;
   this_player()->set_align(str);
   write("Your parenthesis now reads: "+str+"\n");
   return 1;
}

earmuffs_on() {
   write("Your earmuffs are now on.\n");
   say("Predator has put his earmuffs on.\n");
   this_player()->earmuffs_on();
   return 1;
}

echo(str) {
   if(!str) {
      write("Echo what.\n");
      return 1;
   }
   
   say(str+"\n");
   write("You echo"+str+"\n");
   return 1;
}

force(str) {
   string who, what;
   object target;
   if(!str) return;
   if(sscanf(str, "%s %s", who, what) != 2) return;
   target=find_living(lower_case(who));
   if(!target) { write("Can't find that target.\n"); return 1; }
   command(what, target);
   write("You have silently forced "+capitalize(who)+" to "+what+".\n");
   return 1; }

money(str) {
   string who;
   int amt;
   
   if(!str || sscanf(str, "%s %d", who, amt) != 2) {
      write("Try `money <person> <amount>'.\n");
      return 1;
   }
   
   if(!find_player(who)) {
      write(capitalize(who)+" is not playing right now.\n");
      return 1;
   }
   call_other(find_player(who), "add_money", amt);
   write("You added "+amt+" gold coins to "+capitalize(who)+"'s inventory.\n");
   return 1;
}
