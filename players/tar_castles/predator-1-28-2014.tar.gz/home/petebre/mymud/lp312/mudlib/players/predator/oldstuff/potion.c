inherit "obj/treasure";
int hitpoint, spellpoint;
set_hitpoint(x) {
   hitpoint = x;
}
set_spellpoint(z) {
   spellpoint = z;
}

reset(arg) {
   if(!arg) {

   set_id("vial");
   set_short("A small vial");
   set_value(random(500));
   set_weight(3);
   }
}

long() {
   write("This is a small vial that houses a bubbling liquid.  It looks like "+
      "It would heal\nyou if you drank it.  On the side you see the numbers "+
      hitpoint+"/"+spellpoint+".\n");
}

init() {
   add_action("drink"   ,"drink");
}

drink(str) {
   if(str == "vial" || str == "small vial") {
      write("You drink the fluids that were contained in the bottle.  It makes"+
         " you feel\nhealed.  The vial disappears.\n");
      say(this_player()->query_name()+" drinks from a small vial.\n");
      this_player()->add_hit_point(hitpoint);
      this_player()->add_spell_point(spellpoint);
      destruct(this_object());
      return 1;
   }
}
