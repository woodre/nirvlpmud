inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("jump","jump");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Edge of Cliff";
   
   long_desc="You are at a small cliff.  To your north and south are impassable\n"+
   "mountains.  Back to your east the pass continues and to the west is a cliff\n"+
   "that looks a bit dangerous.\n\n";
   
   items=({"cliff","You estimate the cliff stretches down about 10 feet, not that\n"+
         "far.  It looks like you might be able to jump down",
         "mountains","They dispel any notions you might have about going in that direction",
         "pass","The pass ends here"});
   
   
   dest_dir=({"/players/predator/realm/desert/desert26","east"});
}

search() {
   write("You carefully scan the area but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}

jump(str) {
   if(!str) {
      write("You jump up and down.\n");
      say(capitalize(this_player()->query_name())+" jumps up and down.\n");
      return 1;
   }
   
   else if(str == "down" || str == "off the cliff" || str == "off cliff") {
      write("You take a great leap and jump off the cliff....\n");
      say(capitalize(this_player()->query_real_name())+" jumps off the cliff.\n");
      call_other(this_player(), "move_player", "screaming#players/predator/realm/desert/dsrt_fall");
      call_out("thud", 2);
      return 1;
   }
}

thud() {
   say("You hear an:  AAAAAAIIIIIIYYYYYYYYEEEEEEEEEEEEEEEEE.....and then a distant thud.\n");
   return 1;
}
