inherit "obj/monster";

reset(arg) {
  if(arg) return;

  set_name("monster");
  set_alt_name("guilder");
  set_alias("guild monster");
  set_short("A super duper guild monster");
  set_long("This is a guild monster.  For 25 coins he will join you into"+
     " Nirvana's\nSuper Guild!  To join, type `join guild'.  And yes, you "+
     "may still be\na member of your other guild.\n");
  set_level(19);
  set_hp(10000);
  set_wc(80);
  set_ac(40);
  set_al(1000);
  set_ep(1800000);
}

init() {
   ::init();
   add_action("join"  ,"join");
}

join(str) {
   object cape;
   if(str == "guild") {
      if(this_player()->query_money() < 5) {
         write("You are too poor.\n");
         return 1;
      }

      write("You pay 25 coins for a cape.\n");
      say(this_player()->query_name()+" buys a cape of the super guild.\n");
      this_player()->add_money(-25);
      cape = clone_object("/players/predator/guild");
      move_object(cape, this_player());
      return 1;
   }
}
