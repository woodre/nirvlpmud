id(str) {
   return( str == "cymbals" );
}

short() {
   return "A pair of shiny brass cymbals";
}

long() {
   write("A beautiful pair of brass cymbals that reflect the sun like"+
      " a mirror.\n");
}

get() {
   return 1;
}

query_weight() {
   return 1;
}

query_value() {
   return 15;
}
init() {
   add_action("clash_cymbals","clash");
   add_action("play_cymbals","play");
}

clash_cymbals(str) {
   if((!str) || !id(str))
      {
      return 0;
   }
   write("You clash the cymbals together and find out that your thumb is now the\n"+
      " width of a emery board. O U C H !!!\n");
   
   say(capitalize(this_player()->query_real_name())+" clashes the cymbals on "+
      this_player()->query_possessive()+" thumb and falls down\n"+
      "clutching "+this_player()->query_possessive()+" hand and screaming in pain.\n");
   
   call_out("scream",2);
   this_player()->add_hit_point(-150);
   return 1;
}

scream() {
   say(capitalize(this_playe()->query_real_name())+" screams loudly.\n");
   return 1;
}

play_cymbals(str) {
   if((!str) || !id(str))
      {
      return 0;
   }
   write("You play the cymbals beautifully...B R A V O !!!\n");
   say(capitalize(this_player()->query_real_name())+" plays the cymbals beautifully.\n");
   return 1;
}
