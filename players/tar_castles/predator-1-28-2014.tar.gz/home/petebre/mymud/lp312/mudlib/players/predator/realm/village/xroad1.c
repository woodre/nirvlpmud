inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("get_sign","get");
   add_action("not","south");
   add_action("not","north");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Major crossroads";
   
   long_desc="You have reached the crossroads of this realm.  To the east\n"+
   "is the rest of the known world and to the west lies a barren desert.\n"+
   "From the south you can hear the business of a town, while the pier,\n"+
   "with it`s own hubbub, is to the north.  There is a sign here.\n\n"+
   "THE PIER (NORTH) AND TOWN (SOUTH) ARE CURRENTLY UNDER CONSTRUCTION.\n\n";
   
   items=({"crossroads","Four exits branch out from here: North, East, South, and West",
         "construction","You see workers of all types hurrying along to finish the realm quickly",
         "realm","By the size of the ocean you assume that the realm is very large",
         "world","Well, it`s the world as you know it",
         "desert","It looks totally desolate, as most deserts do",
         "town","The town that you`ve seen all the way on the east-west road is\n"+
         "just south of where you are",
         "pier","You can see a lot of activity from that area",
         "sign","\n\n\n"+
         "      ===========================================\n"+
         "      |                                          |\n"+
         "      |         ^                                |\n"+
         "      |         |     Randolin Pier              |\n"+
         "      |        -->    The East-West Road         |\n"+
         "      |         |                                |\n"+
         "      |        `.'    Randolin, 1/4 mile         |\n"+
         "      |        <--    The Forbidden Desert       |\n"+
         "      |                                          |\n"+
         "      ============================:======:========\n"+
         "                                  !      !\n"+
         "                                   !     !\n"+
         "                                  !      !\n"+
         "                                  !       !\n"+
         "                                   !       !\n"+
         "                                  !       !\n"+
         "                                  !      !\n"+
         "                                  !      !\n"+
         "                                  !        !\n"+
         "                                !          !\n"+
         "                               !____________!\n"});
   
   dest_dir=({"/players/predator/realm/desert/dsrt_enter.c","west",
         "/players/predator/realm/beach/beach1.c","north",
         "/players/predator/realm/village/nsroad1.c","south",
         "/players/predator/realm/village/ewroad5.c","east"});
}

search() {
   write("You search the aea carefully but turn up nothing of interest.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}

get_sign() {
   write("The town guards that are in these parts probably wouldn`t enjoy you\n"+
      "taking that, even if it was for short term borrowing, as you`d be sure to\n"+
      "tell them.\n");
   say(capitalize(this_player()->query_real_name())+" has foolishly tried to pick up\n"+
      "the sign that rests here.  Maybe he`ll get arrested.\n");
   return 0;
}

not() {
   write("A construction foreman steps out of the piles of materials and says:\n"+
      "Hey you!...This area is under construction.  Come back later.\n");
   say(capitalize(this_player()->query_real_name())+" starts to go north but looks\n"+
      "at the construction sign and decides to stay here.\n");
   return 1;
}

