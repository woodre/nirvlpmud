inherit "room/room";
int i;

init() {
   ::init();
   add_action("search","search");
   add_action("down","down");
   add_action("down","out");
   add_action("down","leave");
   add_action("down","exit");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="In a palm";
   
   long_desc="You are at the top of a palm tree.  The wind blows through your hair, slightly\n"+
   "messing it up.\n\n";
   
   items=({"tree","The tree is nice, and you feel great sitting up here and looking at\n"+
         "the oasis below you",
         "palm tree","The tree is nice, and you feel great sitting up here and looking at\n"+
         "the oasis below you",
         "wind","You can feel it, but you can't see it",
         "oasis","Yes, you can look down at the oasis"});
   
   dest_dir=({"/players/predator/realm/desert/desert8","down"});
   
   i = 0;
   if(!present("dates")) {
      while(i<2) {
         i += 1;
         move_object(clone_object("/players/predator/object/desert/dates"), this_object());
      }
   }
   
}

search() {
   write("You look around carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}

down() {
   write("You start to slowly climb down the palm but your foot slips and you fall the\n"+
      "rest of the way.....*** OUCH ***\n\n");
   say(capitalize(this_player()->query_name())+" falls out of the tree\n");
   call_other(this_player(), "move_player", "#/players/predator/realm/desert/desert8");
   return 1;
}

