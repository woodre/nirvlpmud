inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(!arg) {
      int num;
      set_level(18);
      set_ep(1800000);
      set_hp(800);
      set_wc(30);
      set_ac(15);
      set_al(100);
      set_name("mage");
      set_alt_name("stharkem");
      set_short("A Bedouin mage");
      set_long("Stharkem, the mage, looks back at you carefully.  He is an old and wizened\n"+
         "man, but you can see the wisdom and power in his eyes.\n");
      set_chat_chance(5);
      set_a_chat_chance(10);
      load_chat("Stharkem peers at you carefully.\n");
      load_chat("Stharkem takes a puff on his peace pipe, then settles back.\n");
      load_chat("The mage looks like he is deep in a trance.\n");
      load_a_chat("The mage waves his hands and a scorching fireball scorches you!\n");
      load_a_chat("Stharkem mutters an old spell that makes you feel drowsy.\n");
      load_a_chat("The mage annihlates you to bitty fragments.\n");
      load_a_chat("Stharkem reads a scroll and a lightning bolt appears from nowhere to\n"+
         "strike you to the ground.\n");
      gold = clone_object("obj/money");
      gold->set_money(random(1000) + 750);
      move_object(gold, this_object());
      
      move_object(clone_object("/players/predator/object/desert/pipe"),               this_object());
      move_object(clone_object("/players/predator/object/desert/backpack"),           this_object());
   }
}
