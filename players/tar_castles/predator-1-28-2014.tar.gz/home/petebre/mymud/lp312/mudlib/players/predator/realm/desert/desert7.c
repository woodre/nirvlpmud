inherit "room/room";
object nomad;

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Northeast Desert";
   
   long_desc="You are in the desrt.  The air is dry and your throat becomes parched.\n"+
   "Your east and west passage is blocked by steep mountains and to your north and\n"+
   "south you see still more desert.\n\n";
   
   items=({"desert","The desert is a barren and wasted land",
         "air","The air is so dry it cackles with static electricity",
         "electricity","It's there, but you can`t see it",
         "throat","Yes, you have a throat",
         "mountains","The steep and dangerous looking mountains dispel any thoughts you might\n"+
         "have had of going in that direction"});
   
   dest_dir=({"/players/predator/realm/desert/desert2","north",
         "/players/predator/realm/desert/desert14","south"});
   
   if(!present("nomad")) {
      nomad = clone_object("/players/predator/monster/desert/nomad");
      move_object(nomad, this_object());
   }
   
   if(!present("nomad")) {
      nomad = clone_object("/players/predator/monster/desert/nomad");
      move_object(nomad, this_object());
   }
}

search() {
   write("You carefully scan the area but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
