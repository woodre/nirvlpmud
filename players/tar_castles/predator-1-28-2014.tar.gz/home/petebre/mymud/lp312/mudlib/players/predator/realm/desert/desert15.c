inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A Desert Pass";
   
   long_desc="You have walked into the entrance of a desert pass.  The pass sstretches out\n"+
   "to the south, while the desert is to the north.  To your east and west moun-\n"+
   "tains rise high into the sky, blocking any passage.\n\n";
   
   items=({"pass","The pass continues to the south",
         "desert","You can see the desert to your north",
         "mountains","The mountains on your east and west impede progress in those directions"});
   
   dest_dir=({"players/predator/realm/desert/desert10","north",
         "players/predator/realm/desert/desert20","south"});
}

search() { 
   write("You look carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}
