inherit "obj/armor";

reset(arg) {
if(arg) return;
set_name("skin");
set_alias("camel skin");
set_type("armor");
set_short("A camel skin");
set_long("This camel skin looks very tough and durable.\n");
set_ac(3);
set_value(950);
set_weight(4);
}
