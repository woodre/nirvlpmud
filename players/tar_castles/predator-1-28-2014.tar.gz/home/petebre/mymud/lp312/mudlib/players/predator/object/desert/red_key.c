inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   
   set_id("key");
   set_alias("red key");
   set_short("A red key");
   set_long("This is a carved entirely from ruby.  It seems to attract light.  You\n"+
      "notice that this key must be very valuable.\n");
   set_weight(1);
   set_value(2500);
}
