inherit "obj/armor";

reset(arg) {
   if(arg) return;
   set_name("platemail");
   set_alias("sand platemail");
   set_type("armor");
   set_short("Sand platemail");
   set_long("This sand platemail sparkles with the brilliance of the sun, and\n"+
      "the particles of sand look like light collectors.  The sand seems fused\n"+
      "together, thus forming the platemail.\n");
   set_ac(4);
   set_value(2150);
   set_weight(6);
   set_arm_light(1);
}
