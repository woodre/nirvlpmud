inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Northeast Desert";
   
   long_desc="You are in the desert.  The air is dry and your throat becomes parched.\n"+
   "Your passage to the north and east is blocked by steep mountains and to your\n"+
   "south you see still more desert.  To your west is what appears to be a small\n"+
   "nomad camp.\n\n";
   
   items=({"desert","The desert is a barren and wasted land",
         "air","The air is so dry it cackles with static electricity",
         "electricity","It's there, but you can`t see it",
         "throat","Yes, you have a throat",
         "camp","You see a very small nomadic camp to the west",
         "mountains","The steep and dangerous looking mountains dispel any thoughts you might\n"+
         "have had of going in that direction"});
   
   dest_dir=({"/players/predator/realm/desert/desert7","south",
         "/players/predator/realm/desert/desert1","west"});
}

search() {
   write("You carefully scan the area but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
