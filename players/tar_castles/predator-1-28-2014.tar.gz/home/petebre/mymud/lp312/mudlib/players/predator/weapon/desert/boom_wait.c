inherit "obj/treasure";

reset(arg) {
   if(!arg) {
      
      set_id("thingysoyouwontthrowtheboomerangtoomanytimes");
      set_long("Just what the set_id implies.\n");
      set_weight(0);
      set_value(0);
   }
}

drop() {
return 1;
}

init() {
   call_out("throw_wait", 90 + random(60));
}

throw_wait() {
   int num;
   num = random(6);
   if(num > 4) {
      write("The boomerang comes back and lands in your hand.\n");
      say("The boomerang comes back to its owner.\n");
      move_object(clone_object("/players/predator/weapon/desert/boomerang"),          environment(this_object()));
      destruct(this_object());
      return 1;
   }
   
   else 
      write("The bomerang must have gotten lost in the trees because it doesn't come back.\n");
      destruct(this_object());
      return 1;
   }
}
