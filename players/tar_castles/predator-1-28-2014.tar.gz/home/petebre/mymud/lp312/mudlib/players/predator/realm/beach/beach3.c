inherit "room/room";
object snd_castle;

init() {
   ::init();
   add_action("north","north");
   add_action("search","search");
   add_action("swim","swim");
   add_action("build","build");
   add_action("dig","dig");
   add_action("detect","detect");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A beach";
   
   long_desc="You are on a beach.  The ocean stretches out to the north.\n"+
   "The atmosphere is so carefree it makes you feel like going swimming or\n"+
   "just sitting down and building a sand castle.\n";
   
   items=({"beach","It`s a lovely beach",
         "ocean","It stretches out for as far as you can see",
         "atmosphere","It soothes you"});
   dest_dir=({"/players/predator/realm/beach/beach4","east",
         "/players/predator/realm/beach/beach2","west"});
}

search() {
   write("You look around carefully but find nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}

dig() {
   if(!present("shovel", this_player())) {
      write("It could help if you had something to dig with.\n");
      say(capitalize(this_player()->query_real_name())+" gives you a stupid grin.\n");
      return 1;
   }
   write("You randomly pick a site to dig and before long you uncover a large hole.\n"+
      "You find nothing, however, and being the good citizen that you are, cover\n"+
      "the hole back up.\n");
   say(capitalize(this_player()->query_real_name())+" digs a hole and covers it back up.\n");
}

build(str) {
   if(!str) {
      write("What would you wish to build?\n");
   }
   
   if(str!= "castle" && str!= "sand castle") {
      write("You don`t know how to build a "+str+".\n");
      return 1;
   }
   
   write("You get down on your hands and knees and before long a magnificent\n"+
      "sand castle lies before you.\n");
   say(capitalize(this_player()->query_real_name())+" builds a wonderful sand castle.\n");
   
   snd_castle=clone_object("/players/predator/object/snd_castle");
   move_object(snd_castle, this_object());
   return 1;
}

detect() {
   write("You walk around slowly, moving the metal detector in front of you.\n"+
      "Suddenly the needle jumps to the other side of the meter.  You have found\n"+
      "something!\n");
   say(capitalize(this_player()->query_real_name())+" begins moving around the\n"+
      "area slowly.  Suddenly "+this_player()->query_real_name()+" looks down at the\n"+
      "meter on "+this_player()->query_possessive()+" metal detector.\n\n\n"+
      capitalize(this_player()->query_real_name())+" shouts: yippeeee!!!\n");
   call_out("burrow",1);
}


burrow() {
if(dig) {
