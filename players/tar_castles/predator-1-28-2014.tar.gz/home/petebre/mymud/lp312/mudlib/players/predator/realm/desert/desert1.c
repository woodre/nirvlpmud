inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("enter","enter");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Nomad Camp";
   
   long_desc="You have entered a desert-plain which is looks like the desert except it seems\n"+
   "to be cooler.  There is a tent here and a tall palm that stretches over it.\n"+
   "You feel tranquility in this area.\n\n";
   
   items=({"desert","It seems just like the desert except it`s cooler",
         "plain","It seems just like the desert except it`s cooler",
         "desert-plain","It seems just like the desert except it`s cooler",
         "tent","It looks like the only establishment in this area",
         "palm","The tall palm rises over the tent.  It looks too tall to climb"});
   
   dest_dir=({"/players/predator/realm/desert/desert2","east"});
}

search() {
   write("You carefully scan the area but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}

enter(str) {
   if(!str) {
      write("Enter what.\n");
      return 1;
   }
   
   else if(str != "tent") {
      write("Enter what?\n");
      return 1;
   }
   
   else if(str == "tent") {
      write("You open the flap, duck, and enter the tent.\n");
      this_player()->move_player("into the tent#/players/predator/realm/desert/dsrt_tent");
      return 1;
   }
}
