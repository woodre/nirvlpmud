inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A Desert Pass";
   
   long_desc="The pass turs west (if you came from the north) or north (if you came from\n"+
   "the west).  To your east and south are mountains that impede any passage in\n"+
   "those directions.  The pass continues north and west.\n\n";
   
   items=({"pass","The pass continues to the north and west",
         "mountains","The mountains on your east and west impede progress in those directions"});
   
   dest_dir=({"players/predator/realm/desert/desert20","north",
         "players/predator/realm/desert/desert25","west"});
}

search() { 
   write("You look carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}
