inherit "obj/treasure";
reset(arg) {
if(!arg) {
set_id("hi");
set_short("A million coins");
set_long("hi.\n");
set_weight(1);
set_value(0);
}
}
init() {
add_action("hi","hi");
}
hi() {
shout(
"VVV          VVVAAA       MMM           MMMPPPPPPPPPPPPPSSSSSSSSSSSSS\n"+
"  VVV      VVVAAA AAA     MMMM         MMMMPPP       PPPSSSSSSSSSSSSS\n"+
"   VVV    VVVAAA   AAA    MMM MM     MM MMMPPP       PPPSSSSSS       \n"+
"    VVV  VVVAAA     AAA   MMM  MM   MM  MMMPPPPPPPPPPPPPSSSSSSSSSSSSS\n"+
"     VVVVVVAAAAAAAAAAAAA  MMM   MM MM   MMMPPPP                SSSSSS\n"+
"      VVVVAAAAAAAAAAAAAAA MMM    MMM    MMMPPPP         SSSSSSSSSSSSS\n"+
"       VVAAA           AAAMMM     M     MMMPPPP         SSSSSSSSSSSSS\n");
return 1;
}
