inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   call_out("buffet1",0,this_player());
   call_out("buffet2",5,this_player());
   call_out("buffet3",10,this_player());
   call_out("buffet4",15,this_player());
   call_out("wake",20,this_player());
   call_out("move",20,this_player());
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="In a River";
   
   long_desc="You are caught in a raging river.\n\n";
   
   items=({"river","The river is quite fierce, and it`s all you can do to stay above water"});
}

search() {
   write("You try to search the murky depths but between gasping for breath and\n"+
      "fighting for your life you find it impossible.\n");
   return 1;
}

buffet1(obj) {
   tell_object(obj, "You are buffeted around by the tremendous current.\n\n");
   return 1;
}

buffet2(obj) {
   tell_object(obj, "The current is so strong it sucks you down a couple of times but you manage\n"+
      "to make it back up.\n\n");
   return 1;
}

buffet3(obj) {
   tell_object(obj, "*** BANG ***  You hit your head hard against a heavy boulder.\n\n");
   return 1;
}

buffet4(obj) {
   tell_object(obj, "You slowly lose conscienceness...You can feel your body being dragged along\n"+
      "by the current.\n\n");
   return 1;
}

wake(obj) {
   tell_object(obj, "When you finally awake, you are in a strange place.  You wonder how you got\n"+
      "here.\n\n");
   return 1;
}

move(obj) {
   move_object(obj, "/players/predator/realm/desert/dcave_enter");
   return 1;
}
