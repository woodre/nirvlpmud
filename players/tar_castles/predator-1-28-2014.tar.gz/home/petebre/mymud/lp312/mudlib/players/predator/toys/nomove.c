id(str) {
   return str == "nomover";
}

short() { 
   return 0;
}

long() {
   return 0;
}

get() { 
   return 1;
}

drop() {
   return 1;
}

init() {
   add_action("not","north");
   add_action("not","east");
   add_action("not","south");
   add_action("not","west");
   add_action("not","northeast");
   add_action("not","northwest");
   add_action("not","southeast");
   add_action("not","southwest");
}

not() {
   write("Forget it pal, You're not moving.\n");
   return 1;
}
