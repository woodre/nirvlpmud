inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(0);
   
short_desc="Entrance of The Dragon Caves";
   
long_desc="You are in a large cavern.  The size of this room is so immense\n"+
"that no amount of light you could bring in here would light the whole\n"+
"area.  You can hear a stream nearby but the sound of it echoing off the\n"+
"walls disorients its location.  You notice a small tunnel leading south.\n\n";
   
items=({"cavern","It's a huge room, larger than any you`ve ever seen",
"room","Room, cavern, same thing",
"area","Room, area, cavern, same thing",
"stream","You can hear it but you can`t seem to locate it",
"walls","The only one you can see is the one surrounding the tunnel leading south",
"tunnel","Other than teleportation, it seems to be the only way out of this room"});
   
   dest_dir=({"/players/predator/realm/desert/dcave3.c","south"});
}

search() {
write("From what you can see, you notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
