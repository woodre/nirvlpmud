inherit "room/room";
object guilder;

reset(arg) {
   if(arg) return;

   set_light(1);

   short_desc="Guild Room";

   long_desc= "The Guild Room of Nirvana's Super Guild.\n\n";

   if(!present("guilder", find_object("/room/church"))) {
     move_object(clone_object("/players/predator/guild_monster"),                      "/room/church");
   }
   if(!present("guilder", find_object("room/shop"))) {
   move_object(clone_object("/players/predator/guild_monster"), "room/shop");
   }
}
