inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   
   set_id("key");
   set_short("A yellow key");
   set_alias("yellow key");
   set_long("This key is made completely from amber.  It almost seems to have a faint glow\n"+
      "emitting from its center.  You note that it must be very valuable.\n");
   set_weight(1);
   set_value(2500);
}
