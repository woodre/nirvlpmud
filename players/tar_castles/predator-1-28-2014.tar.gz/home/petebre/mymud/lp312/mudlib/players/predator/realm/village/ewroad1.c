#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short("A path in a forest");
    set_long(
        "The path darkens as it heads west into the forest...\n"+
        "West goes deeper into the forest while east heads back to\n"+
        "the safety of the town.  The forest is dark and forbidding,\n"+
        "and the trees rise high into the sky...\n"+
        "\nThere is a sign in the middle of the road...\n"
        );
    set_items(([
        "path" :
        "A dusty path leading east and west.\n",
        "trees" :
        "Tall trees line the dark forest to the west...\n",
        "sign" :
        "<>==============================<>\n"+
        "|| A note about this area -     ||\n"+
        "|| Exits are not shown, to know ||\n"+
        "|| where to go, you have to     ||\n"+
        "|| read the description.        ||\n"+
        "|| Type <help_realm> to get a   ||\n"+
        "|| list of what is different    ||\n"+
        "|| here.  Hope you like it. ;>  ||\n"+
        "||                              ||\n"+
        "||                     -Reflex  ||\n"+
        "<>==============================<>\n",
        ]));
    set_sounds(([
        "default" :
        "It is completely silent here, very forbidding...\n",
        ]));
    set_smells(([
        "default" :
        "You smell mildew and wetness in the air.\n",
        "trees" :
        "You smell bark and dirt.\n",
        ]));
    set_chat_frequency(30);
    load_chats(({
        "The breeze ruffles your hair.\n",
        "The trees creak.\n",
        "The bushes rustle briefly...\n",
        }));
    set_exits(([
        "west" : "/players/predator/realm/village/ewroad2",
        "east" : "/room/orc_dump",
        ]));
    set_light(1);
    replace_program(ROOM);
}

init() {
   ::init();
   add_action("help_realm","help_realm");
}

help_realm() {
   write(
        "<>--------------------------------------------------<>\n"+
        "   This realm is different than most.  There are a    \n"+
        "   few things that might help you in your quest...    \n"+
        "<>--------------------------------------------------<>\n"+
        "   Commands -                                         \n"+
        "                                                      \n"+
        "   Smell:                                             \n"+
        "   Description - Use this to smell your environment.  \n"+
        "   Usage - 'smell' or 'smell <item>'                  \n"+
        "                                                      \n"+
        "   Listen:                                            \n"+
        "   Description - Listen to sounds around you.         \n"+
        "   Usage - 'listen' or 'listen <sound>'               \n"+
        "                                                      \n"+
        "   Search:                                            \n"+
        "   Description - Search the room or a specific item.  \n"+
        "   Usage - 'search' or 'search <item>'                \n"+
        "<>--------------------------------------------------<>\n"+
        "   Credits -                                          \n"+
        "                                                      \n"+
        "   Many thanks to Predator who originally coded this  \n"+
        "   realm.  Thanks to Mythos and Boltar for allowing   \n"+
        "   me to update and revamp it.                        \n"+
        "<>--------------------------------------------------<>\n"
        );
   return 1;
}
