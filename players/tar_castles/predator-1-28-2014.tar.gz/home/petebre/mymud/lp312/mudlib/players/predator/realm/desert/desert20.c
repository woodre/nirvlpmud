inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A Desert Pass";
   
   long_desc="The path continues north and south.  To the south, you notice a bend in the\n"+
   "pass.  To the north lies the entrance of this pass.  The mountains still\n"+
   "surround you and restrict passage to the east and west.\n\n";
   
   items=({"pass","The pass continues to the south",
         "bend","The path changes direction to go west",
         "entrance","The entrance of the pass is to the north",
         "mountains","The mountains on your east and west impede progress in those directions"});
   
   dest_dir=({"players/predator/realm/desert/desert15","north",
         "players/predator/realm/desert/desert26","south"});
}

search() { 
   write("You look carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}
