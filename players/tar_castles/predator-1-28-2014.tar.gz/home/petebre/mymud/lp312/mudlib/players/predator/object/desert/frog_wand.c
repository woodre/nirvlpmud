inherit "obj/treasure";
int charge;

reset(arg) {
   if(arg) return;
   
   set_id("wand");
   set_alias("green");
   set_short("A small green wand.");
   set_long("A small green wand.  It has abilities to interfere with a person's DNA,\n"+
      "particularly where strength is concerned.  You notice some writing on it.\n"+
      "At the top is a small picture of a frog.\n");
   set_weight(3);
   set_value(300 + charge * random(5000));
}

init() {
   add_action("read","read");
   add_action("curse","frogilize");
}

read(str) {
   if(str == "wand" || str == "green wand") {
      write("The words read: This wand may be used to frogilize an entity. Use with caution.\n");
      say(capitalize(this_player()->query_name())+" reads an old wand.\n");
      return 1;
   }
}

curse(str) {
   string who;
   charge = 1
   who = find_living(str);
   
   if(charge == 0) {
      write("The wands humms faintly but nothing happens.\n");
      say(capitalize(this_player()->query_name())+" fiddles with an old wand but nothing happens.\n");
      return 1;
   }
   
   if(charge > 0) {
      if(!who) {
         write("There is no such entity to frogilize.\n");
         return 1;
      }
      
      if(who->query_level > 19) {
         write("The frog wand humms for a second, then turns and shoots a green ray into you!\n");
         charge --;
         tell_object(frooggee, capitalize(this_player()->query_name())+" just tried to frog you.\n");
         return 1;
      }
      
      if(who->query_frog()) 
         write("You point the wand at the sky as a green ray shoots forth and\n"+
         "defrogilizes "+capitalize(who->query_name())+".\n");
         tell_object(who, "You are hit with a green ray of light!\n");
      else
         write("You point the wand at the sky as a green ray shoots forth and\n"+
         "frogilizes "+capitalize(tfoggee->query_name())+".\n");
         tell_object(who, "You are hit with a green ray of light!\n");
      who->frog_curse(!froggee->query_frog());
      charge --;
      return 1;
   }
}
