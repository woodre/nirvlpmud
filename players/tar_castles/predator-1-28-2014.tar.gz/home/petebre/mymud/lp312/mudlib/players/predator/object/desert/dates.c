inherit "obj/food";

reset(arg) {
   set_name("dates");
   set_alias("dates");
   set_short("Some dates");
   set_long("These are some dates.  They look like ordinary dates.\n");
   set_weight(1);
set_value(275);
}

init() {
   add_action("eat","eat");
}

eat(str) {
   if(!str) {
      write("Eat what.\n");
      return 1;
   }
   
   else if(str == "dates" && str == "some dates") {
      return 0;
   }
   
   write("You pick the dates off the stem and eat them.  Yum yum!\n");
   say(capitalize(this_player()->query_name())+ " eats some dates.\n");
   this_player()->add_hit_point(7);
   this_player()->add_spell_point(7);
   
   move_object(clone_object("/players/predator/object/desert/date_stem"), this_player());
   destruct(this_object());
   return 1;
}
