inherit "obj/treasure";
int charge;

reset(arg) {
   if(arg) return;
   set_alias("peace pipe");
   set_value(400 + 2000 * charge);
   set_weight(2);
   charge = 2;
}

id(str) { return str == "pipe" || str == "peace pipe"; }
short() { return "A Bedouin's peace pipe"; }
long() {
   write("This is an Bedouin's peace pipe.  It's long frame is intricately marked.\n");
   return 1;
}

init() {
   ::init();
   add_action("smoke","smoke");
}

smoke(str) {
   if(charge == 0) {
      write("The pipe is empty.  You can not smoke an empty pipe.\n");
      return 1;
   }
   
   if(!str) { return 0; }
   else if(str != "pipe" && str != "peace pipe") { return 0; }
   while(charge > 0) {
      charge --;
      write("You take a deep drag from the pipe.  It makes you feel good inside.\n");
      say(capitalize(this_player()->query_name())+" takes a whiff from "+this_player()->query_possessive()+" pipe.\n");
      this_player()->add_hit_point(75);
      this_player()->add_spell_point(75);
      return 1;
   }
}
