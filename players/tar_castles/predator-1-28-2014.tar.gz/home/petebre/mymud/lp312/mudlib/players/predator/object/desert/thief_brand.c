inherit "obj/treasure";

init() {
   ::init();
   add_action("brand","brand");
}

brand(str) {
   object brandee;
   int branlev;
   brandee = present(str, environment(this_player());
      branlev = brandee->query_level();
      
      if(!str) {
         write("Try branding someone.\n");
         return 1;
         return 1;
      
      if(!brandee) {
         write("Thallt person is not here for you to brand.\n")
         return 1;
         return 1;
      
      if(this_player()->query_level() > branlev + 5) {
         write("You just don't have the heart to do that.\n");
         return 1;
         return 1;
         
         write("You sneak real close to "+brandee+" and when "+brandee->query_pronoun()+" isn't looking\n"+
            "you shove the brand into "+brandee->query_possessive()+" forehead.  The brand becomes\n"+
            "disfigured.\n");
         say(capitalize(this_player()->query_name())+" sneaks up real close to"+brandee+" and brands "+brandee->query_possessive+" forehead!\n");
         tell_object(brandee, write("When you're not looking "+capitalize(this_player()->query_name())+" sneaks up and brands you!\n"));
         return 1;
         return 1;
