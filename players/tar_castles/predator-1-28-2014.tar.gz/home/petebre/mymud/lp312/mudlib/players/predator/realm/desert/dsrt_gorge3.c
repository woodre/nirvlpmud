inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Valley Gorge";
   
   long_desc="You have reached a bridge that spans the river.  The shadow you kept noticing\n"+
   "is still there, and it fills you with a wondrous apprehension.  The bridge\n"+
   "goes east and the rest of the gorge is to the north.\n\n";
   
   items=({"gorge","It's very narrow and is surrounded by a cliff on one side and a river\n"+
         "on the other",
         "cliff","It sure looks high",
         "river","The river flows under the bridge, and although it is no less wild, it\n"+
         "does seem calmer than it was farther north",
         "bridge","The bridge is made entirely of wood, and it is the only way across this river\n"+
         "for as far as you can see.  You notice a shadowlike figure pacing back and\n"+
         "forth across it",
         "shadow","As you stare at the form you realize that it must be a guard of some sorts\n"+
         "patrolling the bridge",
         "figure","As you stare at the form you realize that it must be a guard of some sorts\n"+
         "patrolling the bridge",
         "shadowlike figure","As you stare at the form you realize that it must be a guard of some sorts\n"+
         "patrolling the bridge"});
   
   dest_dir=({"/players/predator/realm/desert/dsrt_gorge2","north",
         "/players/predator/realm/desert/dsrt_bridge","east"});
}

search() {
   write("You look around carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
