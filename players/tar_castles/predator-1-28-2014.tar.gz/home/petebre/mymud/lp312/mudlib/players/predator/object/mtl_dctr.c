inherit "obj/treasure";
string instructions, label;

reset(arg) {
   if(arg) return;
   
   set_id("detector");
   set_alias("metal detector");
   set_short("A metal detector");
   set_weight(1);
   set_long("This metal detector seems to use solar energy to operate.  Thus\n"+
      "you see that you could only use it where it`s sunny.  As you look at it\n"+
      "your heart thumps with the anticipation of finding a treasure!\n"+
      "There is a label on the side giving the instructions on usage.\n");
   set_value(750);
}

init() {
   add_action("read_instructions","read");
}

read(str) {
   if(!str) {
      write("Read what?");
      return 1;
   }
   
   if(str == instructions || str == label) {
      write("Thank you for purchasing this metal detector.  This metal detector\n"+
         "is not intended for usage anywhere but on beaches.  The manufacturers\n"+
         "will not be held liable for any complications arising from usage on a\n"+
         "non-beach area.  To activate this machine, simply type `detect' and we\n"+
         "hope that you will find a treasure.\n");
      say(capitalize(this_player()->query_real_name())+" looks at "+this_player()->query_possessive()+" metal detector.\n");
      return 1;
   }
}
