inherit "obj/monster";

reset(arg) {
  if(arg) return;

  set_name("monster");
  set_alias("desert monster");
  set_short("A desert monster of the guild");
  set_long("This is a desert guild monster.  For 5 coins he will join you into"+
     "Nirvana's Super\nGuild!  To join, type `join guild'.  And yes, you may "+
     "still be a member of your other guild.\n");
  set_level(19);
  set_hp(10000):
  set_wc(80);
  set_ac(40);
  set_al(1000);
  set_ep(1800000);
}

init() {
   ::init();
   add_action("join"  ,"join");
}

join(str) {
   object cape;
   if(str == "guild") {
      if(this_player()->query_money() < 5) {
         write("You are too poor.\n");
         return 1;
      }

      write("You pay 5 coins for a cape.\n");
      say(this_player()->query_name()+" buys a cape of the super guild.\n");
      this_player()->add_money(-5);
      cape = clone_object("/players/predator/guild");
      move_object(cape, this_player());
      return 1;
   }
}
