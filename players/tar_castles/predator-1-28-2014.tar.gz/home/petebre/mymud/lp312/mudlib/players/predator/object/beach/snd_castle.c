inherit "obj/treasure";
string castle;

reset(arg) {
   if(arg) return;
   
   set_id("castle");
   set_short("A sand castle");
   set_long("         -<={{|                                     -<={{|\n"+
      "              |                                          |\n"+
      "           [__|__]                                    [__|__]\n"+
      "           [     ]                                    [     ]\n"+
      "           [ ___ ]                                    [ ___ ]\n"+
      "           [ | | ]                                    [ | | ]\n"+
      "          [ .!.!. ]                                  [ .!.!. ]\n"+
      "       [__[_______]__]                            [__[_______]__]\n"+
      "       [             ]                            [             ]\n"+
      "       [  ===   ===  ]                            [  ===   ===  ]\n"+
      "       [  # #   # #  ]                            [  # #   # #  ]\n"+
      "       [  ===   ===  ]                            [  ===   ===  ]\n"+
      "       [             ]                            [             ]\n"+
      
      " [~~]__[~~]__[~~]__[~~]__[~~]__[~~]__[~~]__[~~]__[~~]__[~~]__[~~]__[~~]\n"+
      " [                                                                    ]\n"+
      " [          ##                                             ##         ]\n"+
      " [         #  #                  ######                   #  #        ]\n"+
      " [         #  #                ##  !!  ##                 #  #        ]\n"+
      " [        <====>             ##    !!    ##              <====>       ]\n"+
      " [                          ##     !!     ##                          ]\n"+
      " [                          ##     !!     ##                          ]\n"+
      " [                          ##     !!     ##                          ]\n"+
      " [.._.._.._.._.._.._.._.._..##.....!!.....##.._.._.._.._.._.._.._.._..]\n");
   set_value(750);
}

init() {
   ::init();
   add_action("get","get");
   add_action("get","take");
}

get(str) {
   if(!str) {
      write("Get what?\n");
      return 1;
   }
   
   if(str == "castle") {
      write("As you attempt to pick up the sand castle it crumbles and falls to the ground.\n");
      say(capitalize(this_player()->query_real_name())+" just destroyed the sand castle.\n");
      destruct(this_object());
      return 1;
   }
}
