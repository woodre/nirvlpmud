inherit "room/room";

init() {
   ::init();
   call_out("wheee", 0,this_player());
   call_out("land", 5,this_player());
   call_out("lie", 8,this_player());
   call_out("move", 8,this_player());
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Big fall";
   
   long_desc="You are falling through the air.\n\n";
   
   items=({"air","How do you expect to see the air.."});
}

search() {
   write("And what the hell do you expect to find while you`re falling off a cliff?\n");
   return 1;
}

wheee(obj) {
   tell_object(obj, "A\n"+
      " A\n"+
      "  A\n"+
      "   A\n"+
      "    A\n"+
      "     A\n"+
      "      A\n"+
      "       A\n"+
      "        A\n"+
      "         A\n"+
      "          A\n"+
      "           A\n"+
      "            A\n"+
      "             I\n"+
      "              I\n"+
      "               I\n"+
      "                I\n"+
      "                 I\n"+
      "                  I\n"+
      "                   I\n"+
      "                    I\n"+
      "                     I\n"+
      "                      Y\n"+
      "                       Y\n"+
      "                        Y\n"+
      "                         Y\n"+
      "                          Y\n"+
      "                           Y\n"+
      "                            Y\n"+
      "                             Y\n"+
      "                              Y\n"+
      "                               Y\n"+
      "                                Y\n"+
      "                                 E\n"+
      "                                  E\n"+
      "                                   E\n"+
      "                                    E\n"+
      "                                     E\n"+
      "                                      E\n"+
      "                                       E\n"+
      "                                        E\n"+
      "                                         E\n"+
      "                                          E\n"+
      "                                           E\n"+
      "                                            E\n"+
      "                                             E\n"+
      "                                              E\n"+
      "                                               E\n"+
      "                                                E\n"+
      "                                                 E\n"+
      "                                                  E\n"+
      "                                                   E\n"+
      "                                                    E\n"+
      "                                                     E\n"+
      "                                                      E\n"+
      "                                                       E\n"+
      "                                                        E\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"+
      "                          ***** SPLAT!!!! *****\n\n\n\n\n");
   return 1;
}

land(obj) {
   tell_object(obj, "You slam in to a pile of rocks at the bottom of the cliff.  Fortunately, you\n"+
      "bounce off them onto a patch of grass where your fall is mostly stopped.\n\n");
   return 1;
}

lie(obj) {
   tell_object(obj, "Ok...maybe you misjudged that 10 feet.  Looking back it now seems more\n"+
      "like 30.  Boy you`re lucky you didn`t get yourself killed.\n");
   return 1;
}


move(obj) {
   move_object(obj,"/players/predator/realm/desert/dsrt_gorge1");
   
   return 1;
}
