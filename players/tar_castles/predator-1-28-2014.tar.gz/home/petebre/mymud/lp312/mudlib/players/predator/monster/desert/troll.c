inherit "obj/monster";

reset(arg) {
   ::reset(arg);
   if(!arg) {
      set_level(5);
      set_hp(400);
      set_wc(10);
      set_ac(5);
      set_al(-300);
      set_name("troll");
      set_short("A troll");
      set_long("This troll doesn't look like he wishes you to cross his bridge.\n");
   }
}
