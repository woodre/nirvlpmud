inherit "obj/food";

reset(arg) {
   set_name("dessert");
   set_alt_name("desert dessert");
   set_alias("Desert dessert");
   set_short("A desert dessert");
   set_long("This is a delicious desert dessert.  You feel drawn to eat it.\n");
   set_weight(1);
}

init() {
   add_action("eat","eat");
}

eat(str) {
   if(!str) {
      write("Eat what.\n");
      return 1;
   }
   
   else if(str!= "dessert" && str!= "desert dessert") {
      write("Eat what?\n");
      return 1;
   }
   
   write("You whip out a delicous desert dessert and ravenously gobble it up.\n");
   say(capitalize(this_player()->query_real_name())+" summons a delicious desert dessert.\n");
   this_player()->add_hit_point(60);
   this_player()->add_spell_point(60);
   destruct(this_object());
   return 1;
}
