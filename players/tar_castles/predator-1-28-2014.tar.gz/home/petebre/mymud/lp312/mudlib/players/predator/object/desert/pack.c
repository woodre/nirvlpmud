#define MAX_WEIGHT     350000
int local_weight;

long() {
   write("This is a sturdy leather backpack.\n");
   if (first_inventory(this_object()))
      write("You can see something in it.\n");
   else
      write("It is empty.\n");
}

reset(arg) {
   if (arg)
      return;
   local_weight = 0;
}

query_weight() {
   return 1;
}

add_weight(w) {
   if (local_weight + w > MAX_WEIGHT)
      return 0;
   local_weight += w;
   return 1;
}

short() {
   return "A leather backpack";
}

id(str) {
   return str == "backpack";
}

query_value() {
   return 225;
}

can_put_and_get() { return 1; }

get() {
   return 1;
}

prevent_insert() {
   if (local_weight > 0) {
      write("You can't when there are things in the bag.\n");
      return 1;
   }
   return 0;
}
