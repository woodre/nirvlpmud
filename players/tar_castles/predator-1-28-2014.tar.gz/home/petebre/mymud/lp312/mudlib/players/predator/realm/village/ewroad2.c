#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
inherit ROOM;

    void create() {
        ::create();

    set_short("A road along the sea");
    set_long(
        "The road continues west...\n"+
        "To the north you can see the road is following the curve of\n"+
	"the sea, while to the south you can see the thick forest.\n"+
	"A ditch runs along the southern side of the road, and to the\n"+
	"east the road heads into the forest.  To the west you can\n"+
	"barely make out a town through the trees...\n"
        );
    set_items(([
        "road" :
        "A dusty path leading east and west.\n",
        "forest" :
        "Tall trees line the dark forest to the west...\n",
	"sea" :
	"Breakers sweep in on the shore and slowly recede.\n",
	"ditch" : 
	"This ditch is deep, you don't want to try your luck getting\n"+
	"across it.\n",
        ]));
    set_sounds(([
        "default" :
        "You hear the breakers in the distance.\n",
        ]));
    set_smells(([
        "default" :
        "Salt water mixed with the smells of the forest.\n",
        ]));
    set_chat_frequency(30);
    load_chats(({
        "The breeze ruffles your hair.\n",
        "The trees creak.\n",
        "The bushes rustle briefly...\n",
	"A seagull sails overhead.\n",
        }));
    set_exits(([
        "west" : "/players/predator/realm/village/ewroad3",
        "east" : "/players/predator/realm/village/ewroad1",
        ]));
    set_light(1);
    replace_program(ROOM);
}
