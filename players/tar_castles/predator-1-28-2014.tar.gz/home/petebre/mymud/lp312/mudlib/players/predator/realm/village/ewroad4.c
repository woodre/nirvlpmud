inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="An east-west road";
   
   long_desc="You are very close to the town and you can see most of the\n"+
   "buildings to the southeast.  The forest has thinned to what one could\n"+
   "term a grove, but it still retains its foreboding aura.  To the northwest\n"+
   "you can now see a pier, or wharf, that juts out into the ocean.  Far\n"+
   "off in the distance to the north you think you can see a castle, but\n"+
   "you`re not sure if it`s real or your imagination.\n\n";
   
   items=({"town","You can see it clearly now, with the housing and\n"+
         "restaurants closest to you and the other parts farther to the south",
         "buildings","The buildings that you can see are mostly restaurants\n"+
         "and houses, although the south there are many more",
         "houses","A house is a house.  They do look pretty nice, however",
         "restaurants","They look pretty inviting",
         "forest","It has thinned considerably from the start of the road",
         "grove","It`s not really a grove, but you could call it that",
         "pier","It looks like an interesting place.  It juts out into the ocean",
         "wharf","It looks like an interesting place.  It juts out into the ocean",
         "ocean","It`s stretches out, seemingly past the horizon..",
         "castle","It must have been your imagination because when you stare\n"+
         "in that direction now, you can`t see it anymore"});
   
   dest_dir=({"/players/predator/realm/village/ewroad5", "west",
         "/players/predator/realm/village/ewroad3", "east"});
}

search() {
   
   write("You look around carefully examining everything you see, but find\n"+
      "nothing unusual.\n");
   return 1;
   
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
