earmuffs off
earplugs out
block
te on
muffles off
