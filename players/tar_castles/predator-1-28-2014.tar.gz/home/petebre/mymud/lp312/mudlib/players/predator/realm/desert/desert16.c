inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="In A Desert";
   
   long_desc="You are in a desert.  To your west mountains rise up blocking any passage\n"+
   "in that direction.  Other than that all you can see is desert.\n\n";
   
   if(!present("azoxyr")) {
      move_object(clone_object("/players/predator/monster/desert/azoxyr"), this_object());
   }
   
   dest_dir=({"/players/predator/realm/desert/desert11","north",
         "/players/predator/realm/desert/desert17","east",
         "/players/predator/realm/desert/desert21","south"});
}

search() {
   write("You look around carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}
