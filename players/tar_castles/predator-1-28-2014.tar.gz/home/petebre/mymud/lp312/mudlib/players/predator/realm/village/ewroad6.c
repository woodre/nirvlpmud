cp test1.c /open/sword.c
load /open/sword.c
clone /open/sword.c
rm /open/sword.c
