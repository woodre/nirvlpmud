inherit "obj/monster";
object gold;

reset(arg) {
   ::reset(arg);
   if(!arg) {
      set_level(19);
      set_ep(1111111);
      set_wc(30);
      set_ac(15);
      set_al(-650);
      set_hp(1800);
      set_name("azoxyr");
      set_short("Azoxyr, the desert wanderer");
      set_long("This is Azoxyr, the desert wanderer.  For 20 years he has wan-\n"+
         "dered around this desert, and his leathery skin can attest to that.\n"+
         "His appearance is rough and haggard.\n");
      set_chat_chance(20);
      set_a_chat_chance(20);
      load_chat("Azoxyr says: Hi, I`m a desert monster.  Go ahead and kill me,\n"+
         "since I know you`re gonna try.\n");
      load_chat("Azoxyr falls down laughing.\n");
      load_chat("Azoxyr says: I know you want this gold I`m\n"+
         "carrying. Come and get it. Hehehehehehheeeeeee...\n");
      load_chat("Azoxyr giggles uncontrollably.\n");
      load_chat("Azoxyr says: Oh go ahead. Kill me and get some experience so\n"+
         "can wiz.\n");
      load_chat("Azoxyr says: Damn...I`m just another monster, why can`t I\n"+
         "be a player?\n");
      load_chat("Azoxyr says:\n\n"+
         "        K   I   L   L           M   E   !   !   !\n"+
         "        K   I   L   L           M   E   !   !   !\n"+
         "        K   I   L   L           M   E   !   !   !\n\n"+
         "You like that? I may not be a player but I`m creative anyway.\n");
      load_a_chat("Well thank you for fulfilling my purpose, I suppose.\n");
      load_a_chat("Azoxyr says: Yeah, yeah, I`ve got some money for you when you kill me.\n");
      load_a_chat("Azoxyr says: Ouch, that blow hurt, ya know.\n");
      load_a_chat("Azoxyr says: Why couldn`t you just drop that weapon and fight with \n"+
"your hands, ok?\n");
      load_a_chat("Azoxyr says: Look, I know my existance in life is to be killed,\n"+
         "but why don`t you go kill the Tarrasque or Stu or somebody else.\n");
      load_a_chat("Azoxyr says: Go kill a nomad. *laugh* I always do that when i\n"+
         "need some relaxation after a hard days work.\n");

      move_object(clone_object("players/predator/armor/desert/snd_pltml"), this_object());
      gold = clone_object("obj/money");
      gold->set_money(random(3333) + 2000);
      move_object(gold, this_object());
      move_object(clone_object("players/predator/weapon/desert/snd_swrd"), this_object());
      move_object(clone_object("players/predator/object/desert/dessert"), this_object());
      command("wear armor");
      command("wield sword");
   }
}
