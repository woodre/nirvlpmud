inherit "obj/weapon";
int thrown;

reset(arg) {
   if(arg) return;
   
   set_class(21);
   set_name("axe");
   set_short("An axe");
   set_long("A battle axe.\n");
   set_weight(4);
   set_value(5000);
   set_hit_func(this_object());
}

weapon_hit(attacker) {
   int num;
   num = 5;
   if(num > 3) {
      thrown = 0;
      return 1;
   }
}

init() {
   ::init();
   add_action("throw"   ,"throw");
}

throw(str) {
   string who;
   object target;
   
   if(!str || sscanf(str, "axe at %s", target) != 1) {
      write("Throw the axe at someone.\n");
      return 1;
   }
   
   target = present(find_living(who), environment(this_player()));
   if(!target) {
      write("No such person or monster.\n");
      return 1;
   }
   
   if(thrown == 1) {
      write("You arm is very weak from throwing it last time.\n");
      return 1;
   }
   
   write("You hurl the axe at your opponent.\n");
   say(this_player()->query_name()+" throws an axe right at "+who+".\n");
   thrown = 1;
   return 1;
}
