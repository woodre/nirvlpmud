inherit "obj/treasure";

reset(arg) {
   if(!arg) {
      
      set_id("cape");
      set_short("A super cape (worn)");
      set_long("This is a super flying cape! Type `Help me cape!' for "+
         "a list\nof super abilities!\n");
      set_weight(0);
      set_value(1);
   }
}

init() {
   ::init();

   add_action("ninja_kick"      ,"ninjakick");
   add_action("super_people"    ,"superpeople");
   add_action("summon"          ,"summon");
   add_action("guild_line"      ,"gl");
   add_action("super_shoot"     ,"super");
   add_action("cape_help"     ,"Help");
   add_action("false_shout"     ,"false");
}

ninja_kick(str) {
object target;
target = present(str, environment(this_player()));
if(target == this_player()) {
   write("You would super ninja kick yourself?!?\n");
   return 1;
}

if(!target) {
   write("There is no such person by that name in this room.\n");
   return 1;
}

write("You run up to "+capitalize(str)+" and use your special flying ninja "+
   "boot\nmanuever.  Smack!!! You smash the monster hard!\n"+
   capitalize(str)+" died.\n"+
   "Ok.\n");
   say(this_player()->query_name()+" whacks "+capitalize(str)+" with a "+
      "super ninja kick!\n");
   tell_object(target, this_player()->query_name()+" smashes you with a super "+
      "ninja kick!\n\n"+
      "You die.\n"+
      "You have a strange feeling.\n"+
      "You can see your dead body from above.\n");
   return 1;
}
super_people() {
      write(
         "-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-\n"+
         "            THE SUPER GUILD OF NIRVANA!!\n\n"+
         "    NAME              PRETITLE          LEVEL       SEX\n"+
         "  Superman      Lord of supper, it's     18        Enjoyable\n"+
         "  Guildmaster   Hackster the             14        Disgusting\n"+
         "  Encarnage     Marriage is scary        9         Ruff 'n Tuff\n"+
         "  Wallono       I'm not a homo!          9         Like, tubular\n"+
         "  Cube          The cube of DEATH!!      5         Male?\n"+
         "  Aspernoisipherousnessity               3.563     Whatever...\n"+
         "-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*-=*=-\n");
   return 1;
}

summon(str) {
object target;
target = find_living(str);
if(!target) {
   write("No such person.\n");
   return 1;
}

if(target->query_level() > 20) {
   write("Uh, that person is a wizard...you don't want to do that.\n");
   return 1;
}

write("You call upon your superpowers and summon "+capitalize(str)+"!\n"+
   "Ooooooops, "+capitalize(str)+" was too powerful for you and got away.\n");
tell_object(target, this_player()->query_name()+" summons you!!!\n"+
   "Oh well, you were too powerful and got away.\n");
   return 1;
}

guild_line(str) {
if(!str) {
   write("Send what to guildmembers?\n");
   return 1;
}

write(this_player()->query_name()+": <guildline>: "+str+"\n");
return 1;
}

super_shoot(str) {
string who;
object target;

if(!str || sscanf(str, "shoot %s", who) != 1) {
   write("Super shoot someone.\n");
   return 1;
}

target = find_living(who);
if(!target) {
   write("There is no such person like that!\n");
   return 1;
}

if(target->query_level() > 20) {
   write("Uh, that person is a wizard...you don't want to do that.\n");
   return 1;
}

write("A bolt streaks forth from your eye and flies across the sky\n"+
   "to do justice to "+capitalize(who)+".\n"+
   capitalize(who)+" died.\n"+
   "Ok.\n");
tell_object(target, "A green shaft of light strikes you in the duodenum!!\n"+
   "\nYou almost die.\n"+
   "You come close to having a strange feeling.\n"+
   "You nearly see your dead body from above, BUT YOU DON'T!\n");
   return 1;
}

false_shout(str) {
if(!str) return 0;
write("You shout: "+str+"\n");
shout("The super guild of nirvana is the greatest!!!\n");
return 1;
}

cape_help(str) {
   if(str == "me cape!") {
      write(
       "-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-\n"+
       "\n"+
       "  Spell:          Cost:       Level:       What the hell it does:\n"+
       "\n"+
       "  ninjakick       40 sp's       15         Kicks the monsters fuck-\n"+
       "                                           ing head off.  Monster\n"+
       "                                           must be present.\n"+
       "  superpeople     0 sp's        -3.7       Show who else belongs\n"+
       "                                           to this super guild!\n"+
       "  summon <person> 2.4 sp's     14          Summon whoever you want!\n"+
       "                                           One of my favorites is\n"+
       "                                           summoning the tarrasque\n"+
       "                                           to the church!\n"+
       "  gl <message>   0 sp's        3 1/8       Send a message to all\n"+
       "                                           other members!\n"+
       "  super shoot <person>          16         Shoot anyone or anything\n"+
       "                                           from anywhere on the mud!\n"+
       "  Help me cape!   80 sp's       19         Display our help message!\n"+
       "-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-=*=-\n");
      return 1;
   }
}
