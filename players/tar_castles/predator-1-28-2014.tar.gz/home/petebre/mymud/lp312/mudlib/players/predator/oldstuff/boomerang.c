inherit "obj/treasure";

reset(arg) {
   if(!arg) {
      
      set_id("boomerang");
      set_alias("wooden boomerang");
      set_short("A wooden boomerang");
      set_long("An elliptical boomerang.  It looks to be weighted just right.\n");
      set_weight(2);
      set_value(800);
   }
}

init() {
   add_action("throw"  ,"throw");
}

throw(str) {
   string who;
   object target;
   
   if(!str) {
      write("Try throwing the boomering at something.\n");
      return 1;
   }
   
   sscanf(str, "throw boomerang at %s", who);
   if(sscanf(str, "throw boomerang at %s", who) != 1) {
      write("Try throwing the boomerang at something.\n");
      return 1;
   }
   
   target = present(who, environment(this_player()));
   if(!who) {
      write("There is no such thing here.\n");
      return 1;
   }
   
   write("You hurl the boomerang at "+capitalize(who)+" with all you might.\n");
   say(this_player()->query_name()+" throws the boomerang at "+capitalize(who)+".\n");
   call_other(this_player(), "attacked_by", who);
   call_other(this_player(), "attack", who);
   call_other(who, "add_hit_point", -30);
   call_out("comeback", 90 + random(60));
   destruct(this_object());
   return 1;
}


comeback() {
   write("The boomerang comes back into your hand.\n");
   say(this_player()->query_name()+"'s boomerang comes back.\n");
   move_object(clone_object("/players/predator/boomerang"),  this_player());
   return 1;
}
