inherit "obj/armor";

reset(arg) {
   if(arg) return;
   set_name("platemail");
   set_alias("ruby platemail");
   set_type("armor");
   set_short("Ruby platemail");
   set_long("This piece of ruby platemail looks very valuable.  It s
      "the particles of sand look like light collectors.  The sand seems fused\n"+
      "together, thus forming the platemail.\n");
   set_ac(4);
   set_value(2150);
   set_weight(6);
   set_arm_light(1);
}
