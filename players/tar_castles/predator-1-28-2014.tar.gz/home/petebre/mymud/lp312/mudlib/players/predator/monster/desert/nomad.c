inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(!arg) {
      int num;
      set_level(13);
      set_ep(300000);
      set_hp(400);
      set_wc(13);
      set_ac(9);
      set_al(100);
      set_name("nomad");
      set_short("A nomad");
      set_long("This nomad has spent his life here in the desert.  He is\n"+
         "very knowledgeable in the ways of survival.  As you look at him he\n"+
         "turns to look at you and you can see the wisdom in his eyes.\n");
      set_chat_chance(10);
      set_a_chat_chance(10);
      load_chat("A nomad looks you over carefully and sighs to himself.\n");
      load_chat("You hear a nomad mutter to himself: Shit, I'm a dead man...\n");
      load_chat("The nomad says: Hi, I don't suppose you might be friendly?\n");
      load_a_chat("The nomad sighs and says: I was afraid this would happen.\n");
      load_a_chat("The nomad says: We're a peaceble folk, don`t kill us.\n");
      load_a_chat("The nomad says: Damn...look at my hp's...damn damn damn.\n");
      gold = clone_object("obj/money");
      gold->set_money(random(9) + 190);
      move_object(gold, this_object());
      
      num = random(3);
      
      if(num==0) {
         move_object(clone_object("players/predator/object/desert/nmd_ptn"), this_object());
      }
      
      else if(num==1) {
         move_object(clone_object("players/predator/object/desert/nmd_ptn"), this_object());
         move_object(clone_object("players/predator/armor/desert/nmd_clk"), this_object());
         command("wear cloak");
      }
      
      else if(num==2) {
         move_object(clone_object("players/predator/object/desert/nmd_ptn"), this_object());
         move_object(clone_object("players/predator/object/desert/nmd_ptn"), this_object());
         move_object(clone_object("players/predator/armor/desert/nmd_clk"), this_object());
         command("wear cloak");
      }
   }
}
