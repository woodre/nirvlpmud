inherit "obj/weapon";

reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("sword");
   set_alias("sand sword");
   set_short("A sand sword");
   set_long("This sand sword looks like it`s made of many particles of sand.\n"+
      "Upon further examination, you see that at certain times the particles\n"+
      "seem to arrange themselves into five separate swords.\n");
   set_class(100);
   set_hit_func(this_object());
   set_weight(5);
   set_value(3250);
}

weapon_hit(attacker) {
   if (random(60) > 1) {
      write("The sword scatters into five of itself and plunges into your opponents heart!!\n");
      say("The sand sword suddenly becomes five of itself and they plunge\n"+
         "themselves into their opponent`s heart!!\n");
      return 68;
   }
}
