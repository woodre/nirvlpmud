inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="A Dragon Cave Lair";
   
   long_desc="You enter a fair sized cavern.  The first thing you notice is the horrible\n"+
   "smell that surrounds you.  The walls are covered with some sort of luminous\n"+
   "substance that spreads an eerie glow about the room.\n\n";
   
   items=({"cavern","The cavern is a fair sized one, but not as large as the one you saw\n"+
         "at the entrance of these caves",
         "smell","How can you examine a smell",
         "walls","These walls actually appear hewn, and not natural like the walls in the \n"+
         "other parts of the caves.  There is a luminous substance that sticks to them\n"+
         "and provides the faint glow that lights thiis room",
         "luminous substance","Whatever it is, it sticks to the walls and provides light",
         "substance","Whatever it is, it sticks to the walls and provides light",
         "glow","It seems to represent the atmosphere of this place"});
   
   dest_dir=({"/players/predator/realm/desert/dcave25.c","east"});
}

search() {
   write("From what you can see, you notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
