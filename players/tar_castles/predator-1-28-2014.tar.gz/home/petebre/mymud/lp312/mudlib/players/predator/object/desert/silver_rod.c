inherit "obj/treasure";
int wiz_level;

reset(arg) {
   if(!arg) {
      
      set_id("rod");
      set_alias("silver rod");
      set_short("A silver rod");
      set_long("A small silver rod.  There is an inscription on the side.\n");
      set_value(1385);
      set_weight(2);
      wiz_level = 20;
   }
}

init() {
   add_action("read"   ,"read");
   add_action("summon" ,"lightbring");
}

read(str) {
   if(str == "inscription" || str == "rod") {
      write("The inscription reads:\n"+
         "            To change another's destiny, `lightbring' them.\n");
      return 1;
   }
}

summon(str) {
   string who, who1;
   who1 = this_player();
   who = find_living(str);
   
   if(!who) {
      write("A bolt of light shoots forth, looking for its target but comes\n"+
         "empty handed.\n");
      return 1;
   }
   
   if(who->query_level() > wiz_level) {
      write("The rod glows for a moment then suddenly explodes.\n");
       tell_object(who, "You realize "+capitalize(this_player()->query_real_name())+" has tried to summon you.\n");
      destruct(this_object());
      return 1;
   }
   
   write("As you say the words the rod begins to gleam, then suddenly shoots out\n"+
      "a bolt of light which drags "+capitalize(who->query_name())+" to you.\n"+
      "The silver rod vanishes.\n");
   tell_object(who, "A bolt of light suddenly overwhelms you and you realize that "+capitalize(this_player()->query_name())+"\n"+
      "has summoned you.\n");
    say(capitalize(this_player()->query_name())+" brings in "+who()->query_name()+" on a beam of light!\n");
   move_object(who, environment(who1));
   destruct(this_object());
   return 1;
   
}
