inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(0);
   
   short_desc="Dragon Caves";
   
   long_desc="This is a small passagway.  The walls are damp and every so often water\n"+
   "drips down.  You notice a tunnel leading north and another leading south.\n\n";
   
   items=({"passagway","It`s very dark and damp",
         "walls","The walls are cold and clammy to the touch",
         "water","It`s quiet annoying when it drips on you",
         "tunnel","Other than teleportaion, the tunnels seem the only way out of this cave"});
   
   dest_dir=({"/players/predator/realm/desert/dcave1","north",
         "/players/predator/realm/desert/dcave12","south"});
}

search() {
   write("From what you can see, you notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
