inherit "room/room";
int noblanket;

init() {
   ::init();
   add_action("search","search");
   add_action("out","exit");
   add_action("out","out");
   add_action("out","leave");
}

reset(arg) {
   if(arg) return;
   
   noblanket = 0;
   set_light(1);
   
   short_desc="In A Bedouin Tent";
   
   long_desc="You have entered a bedouin tent.  It is stuffy in here and smoke wisps hang\n"+
   "in the air.  The walls of the tent are decorated with strange symbols and\n"+
   "signs and every so often you notice a peephole of light shining through the\n"+
   "the old fabric that this tent is made of.\n\n";
   
   items=({"tent","This tent is fairly old, and it looks like it's seen good use",
         "wisps","They float about lazily like clouds in the air",
         "walls","They have a plethora of symbols and wierd signs etched in them",
         "symbols","They are mostly indiscernable.  However, you notice one that means wisdom",
         "signs","The signs that adorn the tent look very old, and you recognize none of them",
         "light","You can see small dots of light peeking through the old fabric",
         "fabric","The fabric looks like some sort of mixture between camel skin and leather"});
   
   if(!present("mage")) {
      move_object(clone_object("/players/predator/monster/desert/mage"), this_object());
   }
   
   dest_dir=({"/players/predator/realm/desert/desert1","out"});
}

search() {
   int charge;
   charge = 1;
   
   if(present("mage")) {
      write("The mage won't allow you to search his tent.\n");
      say("The mage stops "+capitalize(this_player()->query_name())+" from searching the tent.\n");
      return 1;
   }
   
   while(charge > 0 && noblanket == 0) {
write("You look around carefully and find an old blanket.\n");
      say(capitalize(this_player()->query_name())+" finds an old blanket.\n");
      move_object(clone_object("/players/predator/object/desert/blanket"), this_object());
      charge --;
      noblanket = 1;
      return 1;
   }
   
   if(noblanket == 1) {
      write("You search the tent but find nothing else.\n");
      say(capitalize(this_player()->query_name())+" searches the tent again.\n");
      return 1;
   }
}

out() {
   write("You pull open the flap and leave the tent.\n");
   call_other(this_player(), "move_player", "the tent#/players/predator/realm/desert/desert1");
   return 1;
}
