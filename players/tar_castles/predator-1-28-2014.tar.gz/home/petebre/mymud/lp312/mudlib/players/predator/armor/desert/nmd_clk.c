inherit "obj/armor";

reset(arg) {
if(arg) return;
set_name("cloak");
set_alias("nomad's cloak");
set_type("misc");
set_short("A nomad's cloak");
set_long("The cloak looks like it was made to last out heavy sand storms.\n"+
"It also looks like it`s seen a lot of use.\n");
set_ac(1);
set_value(400);
set_weight(1);
}
