inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("enter","enter");
   add_action("jump","jump");
   add_action("dive","dive");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="Valley Gorge";
   
   long_desc="You are further along the gorge.  The cliff and river still encompass you,\n"+
   "however, and the sound of the water crashing against the rocks is almost\n"+
   "deafening.  To your southeast a bridge becomes visible and it appears that\n"+
   "the `road' you`re on ends there.\n\n";
   
   items=({"gorge","It's very narrow and is surrounded by a cliff on one side and a river\n"+
         "on the other",
         "cliff","It sure looks high",
         "river","The current of the river is very strong, and you wonder if you could enter\n"+
         "it without drowning",
         "water","It makes a frightening crash as it pummels the rocks on it`s way down the stream",
         "bridge","You see a bridge that spans the river to your immediate southeast.  As you\n"+
         "peer closer, you think you see a dark shape pacing the bridge",
         "shape","Maybe it's your imagination but it sure seems real",
         "road","The road is the same thing as the gorge"});
   
   dest_dir=({"/players/predator/realm/desert/dsrt_gorge1","north",
         "/players/predator/realm/desert/dsrt_gorge3","south"});
}

search() {
   write("You look around carefully but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}

jump() {
   write("Nah...after your experience with the cliff you decide not to take anymore\n"+
      "jumps for a while.\n");
   return 1;
}

dive() {
   write("The river is too shallow for you to dive into it.  You might hit your head.\n");
   return 1;
}

enter(str) {
   if(!str) {
      write("Enter what.\n");
      return 1;
   }
   
   else if(str != "river") {
      write("Enter what?\n");
      return 1;
   }
   
   else if(str == "river") {
      write("You scramble down the bank and plunge into the raging torrent.\n\n");
      call_other(this_player(), "move_player", "into the stream#/players/predator/realm/desert/dsrt_river");
      return 1;
   }
}
