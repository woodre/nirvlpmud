inherit "room/room";

init() {
   ::init();
   add_action("search","search");
   add_action("drink","drink");
   add_action("climb","climb");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="An Oasis";
   
   long_desc="You have entered an oasis.  It is much shadier and cooler than that hot desert\n"+
   "which is now to your east.  There is a waterhole here, and some palm trees.\n"+
   "The shade is quite relaxing, and the cool air refreshes you.\n\n";
   
   items=({"oasis","It is a nice place",
         "desert","The desert is to your east",
         "waterhole","The water looks cool and clear.  Must be from an underground stream",
         "water","It looks cool and clear",
         "stream","If it's underground, you wouldn't be able to see it",
         "trees","The shade they provide is very nice.  One of them even looks climbable",
         "palm trees","The shade they provid is very nice.  One of them even looks climbable",
         "air","It's there, but you can't see it",
         "shade","The shade is very relaxing"});
   
   dest_dir=({"/players/predator/realm/desert/desert9","east"});
   
   if(!present("camel")) {
      move_object(clone_object("/players/predator/monster/desert/camel"), this_object());
   }
}

search() {
   write("You look around carefully but find nothing unusual.\n");
   say(capitalize(this_player()->query_name())+" searches the area.\n");
   return 1;
}

drink(str) {
   if(!str) {
      return 0;
   }
   
   else if(str != "water" || str != "from waterhole") {
      return 0;
   }
   
   else if(str == "water" && str == "from waterhole") {
      write("You kneel down and drink from the waterhole.  You feel refreshed.\n");
      say(capitalize(this_player()->query_name())+" drinks from the watherhole.\n");
      this_player()->add_hit_point(random(2));
      return 1;
   }
}

climb(str) {
   if(!str) {
      return 0;
   }
   
   else if(str != "tree") {
      return 0;
   }
   
   else if(str == "tree" || str == "palm tree") {
      write("With a running start you jump on the tree and shimmy up the rest of the way.\n");
      call_other(this_player(), "move_player", "up the tree#players/predator/realm/desert/dsrt_palm");
      return 1;
   }
}
