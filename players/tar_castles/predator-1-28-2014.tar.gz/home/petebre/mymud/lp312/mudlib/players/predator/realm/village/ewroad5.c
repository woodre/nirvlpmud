inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) {
   if(arg) return;
   
   set_light(1);
   
   short_desc="An east-west road";
   
   long_desc="This is the road just east of the major crossroads in this\n"+
   "There is no more forest, and no more dunes.  To the north is the\n"+
   "ocean, and the town lies to the south.  To the northwest\n"+
   "you can now see a pier, or wharf, that juts out into the ocean.  Far\n"+
   "off in the distance to the north you think you can see a castle, but\n"+
   "you`re not sure if it`s real or your imagination.\n\n";
   
   items=({"town","Now you can see the town fully.  To your almost\n"+
         "immediate southwest is the ritzy part of the town, with all the\n"+
         "restaurants, classy bars, and places like that.  To the west of that\n"+
         "is the housing district.  To the south of the houses you think you see\n"+
         "the steeple of a church but everything beyond that is pretty much\n"+
         "obstructed by the buildings closest to you",
         "road","You`re on a road that`s just east of a major crossroads",
         "crossroads","The road turns to go in four directions: north, east\n"+
         "south, and west",
         "bars","They look classy",
         "classy bars","They look classy",
         "housing district","You can see some big houses that look rather nice",
         "district","You can see some big houses that look rather nice",
         "steeple","It`s white, tall, and has a bell at the top",
         "bell","It reflects the sun that shines through the town",
         "top","It`s the top of the steeple",
         "buildings","There`s the restaurants, bars, etc...",
         "forest","It has virtually disappeared",
         "dunes","They`re no more.  Go east if you want to see them again",
         "pier","It looks like an interesting place.  It juts out into the ocean",
         "wharf","It looks like an interesting place.  It juts out into the ocean",
         "ocean","It`s stretches out, seemingly past the horizon..",
         "castle","It must have been your imagination becase when you stare in\n"+
         "that direction now, you can`t see it anymore"});
   
   dest_dir=({"/players/predator/realm/village/xroad1", "west",
         "/players/predator/realm/village/ewroad4", "east"});
}

search() {
   
   write("You look around carefully examining everything you see, but find\n"+
      "nothing unusual.\n");
   return 1;
   
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
