inherit "room/room";

init() {
   ::init();
   add_action("search","search");
}

reset(arg) { 
   if(arg) return;
   
   set_light(1);
   
   short_desc="By an Oasis";
   
   long_desc="You can now see an oasis to your west.  The road is harder, and not made out\n"+
   "of sand, like the road to the east.  Your north and south are blocked by\n"+
   "treacherous looking mountains.  The oasis looks refreshing.\n\n";
   
   items=({"oasis","The oasis looks very cool and refreshing",
         "road","The road is now made up of a sand-soil mixture, not just pure sand",
         "mixture","68.349% sand, 31.651% soil",
         "mountaisn","They block any passage to the north and south"});
   
   dest_dir=({"/players/predator/realm/desert/desert10","east",
         "/players/predator/realm/desert/desert8","west"});
}

search() {
   write("You carefully look over the area but notice nothing unusual.\n");
   say(capitalize(this_player()->query_real_name())+" searches the area.\n");
   return 1;
}
