id(str) {
   return str == "thievesnobuyorselldevice";
}

short() { 
   return 0;
}

long() {
   return 0;
}

get() { 
   return 1;
}

drop() {
   return 1;
}

init() {
   add_action("buy_item","buy");
   add_action("sell_item","sell");
}

sell_item(str) {
   object sellthing;
   sellthing = present(str, this_player());
   
   if(!str) {
      write("You may not buy or sell with a thief's brand on your forehead.\n");
      return 1;
   }
   
   if(!sellthing) {
      write("You can't sell what you do not possess.  (You couldn't sell it even if you\n"+
         "you had it.)\n");
      return 1;
   }
   
   write("The shopkeeper takes one look at the thief's brand on your forehead and\n"+
      "says, `No way Jose!  I don't sell to thieves!\n");
   return 1;
}

buy_item(str) {
   write("The shopkeeper looks at the thief's brand on your forehead and says roughly\n"+
      "`Yeah right!  I'll bet you stole that!  No way am I going to buy that so get\n"+
      "outta here now!'\n");
   return 1;
}
