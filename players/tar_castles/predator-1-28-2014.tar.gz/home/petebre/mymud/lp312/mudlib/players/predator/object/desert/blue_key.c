inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   
   set_id("key");
   set_alias("blue key");
   set_short("A blue key");
   set_long("This blue key seems to have been carved from nothing but aquamarine.  As\n"+
      "look at it you notice that light bends around it.  It looks very valuable.\n");
   set_weight(1);
   set_value(2500);
}
