earmuffs on
earplugs in
te off
block
muffles on
