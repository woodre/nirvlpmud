inherit "obj/weapon";
int die, attacker, pain;
reset(arg) {
::reset(arg);
        if(!arg) {
set_name("dildo");
set_class(18);
                set_value(5000);
                set_weight(3);
                set_alias("dildo");
set_short("A two foot long double headed dildo");
set_long(
"I bet you look kinda silly wielding a 2 foot long dildo, eh?\n");
set_hit_func(this_object());
}
}
weapon_hit(attacker)
{
write("You bat your opponent over the head HARD.\n");
return 7;
}
