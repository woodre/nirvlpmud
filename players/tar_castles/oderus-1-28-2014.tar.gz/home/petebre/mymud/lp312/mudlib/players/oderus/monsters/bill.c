inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "bill" );
set_alias("bill");
set_short("Retarded Bill");
set_long("He is about 30 years old and snuggling a Bigbird doll. How cute.\n");
     set_level(18);
     set_ac(15);
     set_wc(26);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(10);
     set_a_chat_chance(10);
load_chat("Retarded Bill sings 'Can you tell me how to get, how to get to Sesame Street?'\n");
load_chat("Retarded Bill drools on your shoe.\n");
load_chat("Retarded Bill giggles, 'I like little girls! He,he,he!'\n");
money = (1000);
   }
}

