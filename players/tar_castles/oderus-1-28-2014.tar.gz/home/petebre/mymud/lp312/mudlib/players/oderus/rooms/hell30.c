inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("therapy room 1");
   long_desc=
"This is the office of Henry Platter. Judging from the cleanliness and\n" +
"organization of the room, you are quite sure he is seriously anal retentive.\n" +
"Henry sits at his desk conducting a therpy session with Joe Normal.\n";
  if(!present("henry",this_object()))
    move_object(clone_object("players/oderus/monsters/henry"),this_object());
  if(!present("normal",this_object()))
    move_object(clone_object("players/oderus/monsters/normal"),this_object());
   items=
   ({
"desk","Oh my God! Is that a piece of gum stuck to the desk? Henry will freak!",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell25","north",
   });
}
