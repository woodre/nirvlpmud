inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hannibals dungeon");
   long_desc=
"You climb down into the dungeon of Hannibal Lechter. The walls are solid\n" +
"concrete. Rats and other vermin scurry about the floor.\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/secret2","west",
"players/oderus/rooms/hell36","up",
   });
}
