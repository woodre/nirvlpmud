inherit "obj/monster";

reset(arg) {
	object money;
   ::reset(arg);
   if (!arg) {
object treasure;
treasure = clone_object("players/oderus/obj/turd.c");
move_object(treasure, this_object());
set_name( "bucksatan" );
set_alias("bucksatan");
set_short("Bucksatan the pink dragon slayer");
set_long("Bucksatan is punk as fuck. You can tell by the shit in his hand that\n" +
"he is obviously a GG Allin follower. His kid Christbait cowers behind him.\n");
     set_level(17);
     set_ac(14);
     set_wc(24);
     set_hp(425);
     set_al(-200);
     set_aggressive(0);
set_chat_chance(25);
     set_a_chat_chance(25);
load_chat("Bucksatan throws shit across the room ala GG Allin\n");
load_chat("Bucksatan 'exclaims don't kill me, kill Pigface!'\n");
load_chat("Bucksatan bends Christbait over and screws him up the ass!\n");
load_chat("Bucksatan says 'The clash rock hard!!'\n");
load_chat("Bucksatan offers you a lemon head.\n");
     money = (950);
   }
}
