inherit "obj/monster";

reset(arg) {
	object money;
   ::reset(arg);
   if (!arg) {
set_name( "mormal" );
set_alias("normal");
set_short("Joe Normal");
set_long("Joe looks very hyper. His hands are shaking and he is chain smoking\n" +
"very cheap cigarettes.\n");
     set_level(5);
     set_ac(5);
     set_wc(9);
     set_hp(75);
     set_al(-800);
     set_aggressive(0);
set_chat_chance(30);
     set_a_chat_chance(30);
load_chat("Joe says 'My mother didn't love me enough'\n");
load_chat("Joe says 'And then on my sixth birthday, she was gone'\n");
load_chat("Joe puts his face into his arms and begins to weep\n");
load_chat("Joe takes a long hard drag from his cigarette.\n");
     money = (1000);
   }
}
