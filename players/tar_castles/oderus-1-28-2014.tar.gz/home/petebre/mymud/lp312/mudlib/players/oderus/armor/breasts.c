inherit"obj/armor";
reset(arg) {
set_name("breasts");
set_alias("breasts");
set_short("A nice set of Breasts");
set_long("A nice bouncy set of fake breasts you can strap on your chest\n");
set_ac(1);
set_type("armor");
set_weight(1);
set_value(100);
}
