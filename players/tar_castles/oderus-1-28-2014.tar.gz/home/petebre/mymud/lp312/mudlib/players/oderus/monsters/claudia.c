inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "claudia" );
set_alias("claudia");
set_short("Claudia the virgin school girl");
set_long("Claudia looks to be anything BUT a virgin school girl. Her 5 sons have\n"
+ "aged her face and body tremendously.\n");
     set_level(18);
     set_ac(15);
     set_wc(26);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(35);
     set_a_chat_chance(35);
load_chat("Claudia asks you to have sex, type 'sex yes' to have sex with her.\n");
load_chat("Claudia says 'Fuck me you big dildo!'\n");
     money = (1000);
   }
}

