inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("small room with a safe in the corner");
   long_desc=
"This is a small storage room. There isn't much of interest except a small\n" +
"safe sitting up against the wall opposite the doorway.\n";
extra_reset();
   items=
   ({
"safe","It's a small iron safe. You might be able to open it if you know the\n" +
"right combination to 'enter'",
"floor","The floor doesn't seem to be to happy to have you standing on it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell16","east",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/obj/safe");
if(!present("safe", this_object())){
move_object(monster,this_object());
return;
}
}
