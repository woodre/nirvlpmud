inherit "obj/monster";

reset(arg) {
	object money;
   ::reset(arg);
   if (!arg) {
set_name( "ruth" );
set_alias("ruth");
set_short("Doctor Ruth");
set_long("This is the world renowned sex therapist Dr. Ruth. She bounces excitedly\n" +
"in her chair as she chats with her patient about his sex life.\n");
     set_level(14);
     set_ac(11);
     set_wc(18);
     set_hp(210);
     set_al(-800);
     set_aggressive(0);
set_chat_chance(15);
     set_a_chat_chance(15);
load_chat("Dr. Ruth says 'how frequently do you have sex?'\n");
load_chat("Dr. Ruth bounces about in her chair.\n");
load_chat("Dr. Ruth says 'Have you ever tried anal sex?'\n");
load_chat("Dr. Ruth says 'How does your wife feel about that?'\n");
     money = (850);
   }
}
