inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("north of therapy room two");
long_desc="You are in a long white corridor. To the south is a door with something\n" +
"written on it. The hall looks to continue for a ways east.\n";
   items=
   ({
"door","Room 2- Shrink: Doctor Ruth",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell27","east",
"players/oderus/rooms/hell31","south",
"players/oderus/rooms/hell25","west",
   });
}
