inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "monti" );
set_alias("monti");
set_short("Monti the death mosher");
set_long("Monti is a LARGE metal head. He seems to be missing his front tooth!'.\n");
     set_level(4);
     set_ac(4);
     set_wc(10);
     set_hp(60);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(75);
     set_a_chat_chance(75);
load_chat("Monti does the Monti mosh allover the room!\n");
load_chat("Monti says 'Do you have $3 I could borrow?\n");
load_chat("Monti says 'GharblehrghughhhhH!!! Gghrrrriise!!\n");
load_chat("Monti says 'Do you have a tack I could slice my wrists with?\n");
load_chat("Monti says 'Lori is the soul killer!!\n");
     money = (24);
   }
}

