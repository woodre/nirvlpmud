inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hannibal eckters room");
   long_desc=
"You have found the room of Hannibal 'The Cannibal' Eckter! He sits in a\n" +
"huge cage, paitning a picture of you. Around him are all the essentials\n" +
"required for the living environment of a psychotic genius.\n";
extra_reset();
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/secret22","west",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/monsters/exa1");
if(!present("monti", this_object())){
move_object(monster,this_object());
return;
}
}
