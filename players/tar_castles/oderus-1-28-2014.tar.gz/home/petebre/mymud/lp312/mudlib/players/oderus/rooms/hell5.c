inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("Hall of fame.");
   long_desc=
"Within this hallway are some of the mighty characters who fought alongside\n" +
"Oderus as he adventured on the many quests required to become a Wizard. Do\n" +
"not take ANY of these hardy adventurers to be an easy kill!\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell20","west",
"players/oderus/rooms/hell1","northeast",
   });
}
