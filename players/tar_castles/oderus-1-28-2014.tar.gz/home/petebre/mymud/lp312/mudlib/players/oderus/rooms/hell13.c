inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hall of statues");
   long_desc=
"This is the home of the mighty Doppleganger warrior BUCKSATAN! The walls\n"
+ "appear to have been papered with centerfolds from various skin mags\n"
+ "including 'Bottoms Up', 'Get On a Big Cow', and 'Babes in chains'.\n";
extra_reset();
   items=
   ({
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell12","west",
"players/oderus/rooms/hell14","east",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/monsters/bucksatan");
if(!present("bucksatan", this_object())){
move_object(monster,this_object());
return;
}
}
