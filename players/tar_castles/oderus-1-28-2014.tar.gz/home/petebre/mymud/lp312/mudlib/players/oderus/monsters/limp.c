inherit "obj/monster";

reset(arg) {
	object money;
   ::reset(arg);
   if (!arg) {
set_name( "limp" );
set_alias("limp");
set_short("Dick Limp");
set_long("This is Dick Limp, one of Dr. Ruths' patients. Your curious mind makes you\n" +
"really want to know what his sexual problems could POSSIBLY be.\n");
     set_level(14);
     set_ac(11);
     set_wc(18);
     set_hp(210);
     set_al(-800);
     set_aggressive(0);
set_chat_chance(10);
     set_a_chat_chance(10);
load_chat("Dick says 'Well... I'm just not as young as I used to be.'\n");
load_chat("Dick says 'My wife has gained so much weight over the years.'\n");
load_chat("Dick says 'Well, occasionally I masturbate to episodes of Charles in Charge.'\n");
     money = (850);
   }
}
