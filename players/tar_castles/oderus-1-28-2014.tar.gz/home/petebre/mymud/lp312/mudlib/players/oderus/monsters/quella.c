inherit "obj/monster";

reset(arg) {
	object money;
   ::reset(arg);
   if (!arg) {
set_name( "quella" );
set_alias("quella");
set_short("<> <> <> Quella <> <> <>");
set_long("This is Quella the mage. She is one of the most powerful of the Morrisville\n" +
"crew, perhaps second only to the wizard Oderus himself.\n");
     set_level(14);
     set_ac(11);
     set_wc(18);
     set_hp(210);
     set_al(-800);
     set_aggressive(0);
set_chat_chance(10);
     set_a_chat_chance(10);
load_chat("Quella says 'You just go ahead and....'\n");
     money = (850);
   }
}
