inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("entrance to Hell-O");
   long_desc=
"You climb down a very shaky old rope ladder into the underground castle of\n"
+ "Hell-O. There are passageways leading to the west and east. The rope ladder\n"
+ "also continues downward, but you are beginning to think maybe the rope ladder\n"
+ "isn't that safe at all.\n";
   dest_dir=
   ({
"players/oderus/rooms/hell1","down",
"players/oderus/rooms/novelty","east",
"players/oderus/rooms/shop","west",
"room/giant_path","up",
   });
}
