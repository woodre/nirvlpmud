inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "kira" );
set_alias("kira");
set_short("Kira the young recruit");
set_long("Kira is the latest addition to the Morrisville riot Grrrls.\n");
     set_level(11);
     set_ac(9);
     set_wc(15);
     set_hp(60);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(75);
     set_a_chat_chance(75);
     money = (500);
   }
}
