inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "doctor" );
set_alias("doctor");
set_short("A maniacal doctor");
set_long("This doctor does NOT look like someone you would want to have your life\n" +
"in the hands of.\n");
     set_level(6);
     set_ac(5);
     set_wc(10);
     set_hp(90);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(75);
     set_a_chat_chance(75);
     money = (250);
   }
}

