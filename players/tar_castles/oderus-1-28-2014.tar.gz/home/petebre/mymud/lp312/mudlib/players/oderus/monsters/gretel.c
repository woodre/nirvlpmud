inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "gretel" );
set_alias("gretel");
set_short("Gretel");
set_long("This girl took too much LSD. Now she has no brain left and can't feed herself.\n" +
"She is in a strait-jacket and can't play with the toys.\n");
     set_level(18);
     set_ac(15);
     set_wc(26);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(10);
     set_a_chat_chance(10);
load_chat("Gretel screams, 'I want to play with the toys!'\n");
load_chat("Gretel screams, 'I vacuumed out my head, jumping from bed to bed, my name\n" +
"is Gretel!!'\n");
load_chat("Gretel screams, 'Feed me!'\n");
load_chat("Gretel screams, 'I have got a crotch that talks!'\n");
load_chat("Gretel screams, 'He,he,he! Handsome! Gretel! Handsome! Gretel!'\n");
money = (1000);
   }
}

