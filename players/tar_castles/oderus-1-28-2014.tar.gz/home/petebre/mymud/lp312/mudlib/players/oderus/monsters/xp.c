inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "beast" );
set_alias("beast");
set_short("Beast fodder");
set_long("Monti is a LARGE metal head. He seems to be missing his front tooth!'.\n");
     set_level(75);
     set_ac(1);
     set_wc(100);
     set_hp(20);
     set_al(5000);
     set_aggressive(1);
set_chat_chance(75);
     set_a_chat_chance(75);
     money = (60000);
   }
}

