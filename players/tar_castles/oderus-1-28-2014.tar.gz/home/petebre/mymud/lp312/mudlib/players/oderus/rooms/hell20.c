inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hall of fame");
   long_desc=
"This is the room of the powerful alchemist Sado. This is were he plots his\n" +
"next viscious attack (on the complaint board).\n";
extra_reset();
   items=
   ({
   });
   dest_dir=
   ({
"players/oderus/rooms/hell21","south",
"players/oderus/rooms/hell5","east",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/monsters/sado");
if(!present("sado", this_object())){
move_object(monster,this_object());
return;
}
}
