inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("Retard room.");
   long_desc=
"Welcome to the Retard Room! This place is full of brain damaged rejects who's\n" +
"parents dumped them at the hospital. A t.v. blaring in the corner of the\n" +
"room is turned on to Sesame Street. Various toys litter the floor..... \n" +
"although the people here look a little too old for toys.\n";
  if(!present("bill",this_object()))
    move_object(clone_object("players/oderus/monsters/bill"),this_object());
  if(!present("courtney",this_object()))
    move_object(clone_object("players/oderus/monsters/courtney"),this_object());
  if(!present("rebel",this_object()))
    move_object(clone_object("players/oderus/monsters/rebel"),this_object());
  if(!present("gretel",this_object()))
    move_object(clone_object("players/oderus/monsters/gretel"),this_object());
  if(!present("idiot",this_object()))
    move_object(clone_object("players/oderus/monsters/idiot"),this_object());
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell3","northwest",
   });
}
