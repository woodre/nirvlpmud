inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("therapy room 2");
   long_desc=
"This is the office of the world reknown sex therapist Doctor Ruth. Her patient\n" +
"Dick Limp is seated on the couch, and Dr. Ruth sits in a chair behind her desk.\n";
  if(!present("ruth",this_object()))
    move_object(clone_object("players/oderus/monsters/ruth"),this_object());
  if(!present("limp",this_object()))
    move_object(clone_object("players/oderus/monsters/limp"),this_object());
   items=
   ({
   });
   dest_dir=
   ({
"players/oderus/rooms/hell26","north",
   });
}
