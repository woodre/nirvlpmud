inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "rebel" );
set_alias("rebel");
set_short("Rich the Rebel");
set_long("This zit faced dork is trying to look cool in a leather jacket. It doesn't\n" +
"work! He also seems to be making a lot of phone calls, and terrorizing you\n" +
"with his sexual advances.\n");
     set_level(18);
     set_ac(15);
     set_wc(26);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(10);
     set_a_chat_chance(10);
load_chat("Rich pulls a pair of boxers from his pocket and stutter 'I st-st-stole this\n" +
"fr-fr-from the men's laundry r-r-room!'\n");
load_chat("Rich pretends to call one of his 'friends' on the portable phone.\n");
load_chat("Rich squeezes your shoulder and says, 'W-O-O, Woo!!'\n");
load_chat("Rich stutters, 'I have l-l-lots of fr-fr-friends! I have all their ph-ph-phone\n" +
"n-n-numbers on my c-c-computer!'\n");
money = (1000);
   }
}

