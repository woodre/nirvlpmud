inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hannibals dungeon");
   long_desc=
"You are wandering through a series of vermin infested concrete walls. Somewhere\n" +
"in this place is Hannibal Lechter and it is your job to find him.\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/secret3","west",
"players/oderus/rooms/secret1","east",
   });
}
