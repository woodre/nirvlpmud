inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc=("hannibal lechters room");
   long_desc=
"You enter a room with a great big cell in the center. There is classical\n" +
"music filling the air and Hannibal sits quietly painting a picture.\n";
extra_reset();
   items=
   ({
"floor","The floor doesn't seem to be to happy to have you standing on it",
   });
   dest_dir=
   ({
"players/oderus/rooms/secret22","west",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/obj/cell");
if(!present("cell", this_object())){
move_object(monster,this_object());
return;
}
}
init() {
::init();
add_action("west","west");
}

west() {
if(present("hannibal", this_object())) {
if(this_player()->query_hp() > 45) {
write("Hannibal doesn't let you past!\n");
return 1;
}
}
this_player()->move_player("west#players/oderus/rooms/secret22.c");
return 1;
}
realm() { return "NT"; }
