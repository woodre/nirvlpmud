inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hall of statues");
long_desc= "This is the headquarters of the Morrisville RIOT GRRRLS!! For those of you\n" +
"not in the know, its a feminist group of 'womyn' who are into punk rock.\n";
  if(!present("claudia",this_object()))
    move_object(clone_object("players/oderus/monsters/claudia"),this_object());
  if(!present("elonna",this_object()))
    move_object(clone_object("players/oderus/monsters/elonna"),this_object());
  if(!present("kira",this_object()))
    move_object(clone_object("players/oderus/monsters/kira"),this_object());
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell13","west",
"players/oderus/rooms/hell15","east",
   });
}
