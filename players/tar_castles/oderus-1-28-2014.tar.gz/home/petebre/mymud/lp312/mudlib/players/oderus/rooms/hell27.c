inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("north of therapy room three");
long_desc="You are in a long white corridor. To the south is a door with something\n" +
"written on it. The hall looks to continue for a ways east.\n";
   items=
   ({
"door","Room 3- Shrink: Sigmund Freud",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell28","east",
"players/oderus/rooms/hell32","south",
"players/oderus/rooms/hell26","west",
   });
}
