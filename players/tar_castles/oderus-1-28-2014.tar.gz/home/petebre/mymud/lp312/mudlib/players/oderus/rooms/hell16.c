inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("Boring passageway through the mental ward");
long_desc="This is a pretty boring passageway through the mental ward. The passage\n" +
"continues south and there is also a doorway to the west.\n";
   items=
   ({
   });
   dest_dir=
   ({
"players/oderus/rooms/hell3","north",
"players/oderus/rooms/hell35","south",
"players/oderus/rooms/hell37","west",
   });
}
