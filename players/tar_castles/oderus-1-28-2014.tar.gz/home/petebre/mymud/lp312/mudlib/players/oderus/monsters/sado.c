inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "sado" );
set_alias("sado");
set_short("Sado the Alchemist");
set_long("Sado is the proudest of the once powerful alchemists guild. Some say he\n" +
"has stooped to guessing wizzes passwords and setting himself up with unlimited\n" +
"coins and heals, but this has never been proven.\n");
     set_level(4);
     set_ac(4);
     set_wc(10);
     set_hp(60);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(25);
     set_a_chat_chance(25);
     money = (24);
   }
}

