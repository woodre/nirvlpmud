inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("entrance to correctional facility");
   long_desc=
"This is the entrance to a huge cement fortress commonly known as the Hell-O\n" +
"Correctional Facility. Some of the most famous and dangerous criminals of\n" +
"all time are rumored to be locked up in this place.\n";
  if(!present("guard",this_object()))
    move_object(clone_object("players/oderus/monsters/guard"),this_object());
  if(!present("guard 2",this_object()))
    move_object(clone_object("players/oderus/monsters/guard"),this_object());
  if(!present("guard",this_object()))
    move_object(clone_object("players/oderus/monsters/guard"),this_object());
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell1","south",
"players/oderus/rooms/hell19","north",
   });
}
