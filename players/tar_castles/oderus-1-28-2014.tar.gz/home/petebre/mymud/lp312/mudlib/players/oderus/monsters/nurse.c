inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "nurse" );
set_alias("nurse");
set_short("A typical nurse");
set_long("She looks like a typical nurse, like you would see in an episode of\n" +
"Doogie Howser.\n");
     set_level(4);
     set_ac(4);
     set_wc(8);
     set_hp(60);
     set_al(500);
     set_aggressive(0);
set_chat_chance(75);
     set_a_chat_chance(75);
     money = (150);
   }
}

