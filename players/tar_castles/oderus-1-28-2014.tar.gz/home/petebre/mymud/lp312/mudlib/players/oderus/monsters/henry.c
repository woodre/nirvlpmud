inherit "obj/monster";

reset(arg) {
	object money;
   ::reset(arg);
   if (!arg) {
set_name( "henry" );
set_alias("henry");
set_short("Henry 'brain' Platter");
set_long("He sits taking occasional drags off of an old wooden pipe. His inquisitive\n" +
"eyes and tone of voice almost put you in a trance like state.\n");
     set_level(9);
     set_ac(7);
     set_wc(13);
     set_hp(135);
     set_al(-800);
     set_aggressive(0);
set_chat_chance(25);
     set_a_chat_chance(25);
load_chat("Henry says 'why do you think that?'\n");
load_chat("Henry takes a hit off of his pipe.\n");
load_chat("Henry says' and how does this make you feel?'\n");
     money = (400);
   }
}
