inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "piggy" );
set_alias("piggy");
set_short("Miss Piggy");
set_long("This is a very attractive porker. She seems to be very vain'.\n");
     set_level(4);
     set_ac(4);
     set_wc(10);
     set_hp(60);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(75);
     set_a_chat_chance(75);
load_chat("Miss Piggy says 'I'm the star of this show!'\n");
     money = (24);
   }
}

