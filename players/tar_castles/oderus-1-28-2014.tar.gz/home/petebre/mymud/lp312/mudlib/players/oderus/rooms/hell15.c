inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hall of statues");
   long_desc=
"This is the room of Quella the mage. Standing in here, you get the feeling\n" +
"of being in a Holiday Inn or something. The very practical Quella doesn't\n" +
"seem to require room decorations of any sort.\n";
extra_reset();
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell14","west",
"players/oderus/rooms/hell18","east",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/monsters/quella");
if(!present("quella", this_object())){
move_object(monster,this_object());
return;
}
}
