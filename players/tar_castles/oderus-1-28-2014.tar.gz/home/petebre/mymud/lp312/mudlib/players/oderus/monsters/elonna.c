inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "elonna" );
set_alias("elonna");
set_short("Elonna the temptress");
set_long("Elonna is the oldest of the crew. She has long red hair and bell bottoms\n"
+ "but dont even think about calling her a hippy! This vuluptuous chic doesn't\n"
+ "put up with any shit.\n");
     set_level(18);
     set_ac(15);
     set_wc(26);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(35);
     set_a_chat_chance(35);
load_chat("Elonna says 'Sandman killed me again, the fucker!'\n");
load_chat("Elonna says 'I think Ken Doll is sooooo hunky!'\n");
load_chat("Elonna says 'Have ya read the new issue of SASSY? Belly makes me sick.'\n");
     money = (1000);
   }
}

