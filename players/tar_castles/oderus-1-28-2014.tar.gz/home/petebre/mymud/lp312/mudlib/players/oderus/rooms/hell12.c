inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hall of statues");
   long_desc=
"You have come to the room of the mighty newbie slayer, PIGFACE, whos favorite\n"
+ "pastimes include- fooling newbies into going to the arena and slaughtering\n"
+ "them and stealing the treasure off of other players kills. The room is a\n"
+ "total pig stye (what else!).\n";
extra_reset();
items=
   ({
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell11","west",
"players/oderus/rooms/hell13","east",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/monsters/pigface");
if(!present("pigface", this_object())){
move_object(monster,this_object());
return;
}
}
