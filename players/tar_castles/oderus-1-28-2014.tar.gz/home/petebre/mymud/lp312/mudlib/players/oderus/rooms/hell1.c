inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("bottom of the pit");
   long_desc=
"You reach the bottom of the pit. As you look around you are astounded\n"
+ "by the many corridors that branch off in all directions.\n"
+ "There is a large sign in the middle of the room.\n";
items=({
"sign","SOUTH - The Happy House.\n"
+ "NORTH - Hell-O Correctional Facility.\n"
+ "WEST  - Shady Hills.\n"
+ "EAST  - Antarctica.\n",
});
dest_dir=
   ({
"players/oderus/rooms/hell5","southwest",
"players/oderus/rooms/hell33","west",
"players/oderus/rooms/hell7","northwest",
"players/oderus/rooms/hell8","north",
"players/oderus/rooms/hell9","northeast",
"players/oderus/rooms/hell10","east",
"players/oderus/rooms/hell11","southeast",
"players/oderus/rooms/hell2","south",
"players/oderus/rooms/enter1","up",
   });
}
