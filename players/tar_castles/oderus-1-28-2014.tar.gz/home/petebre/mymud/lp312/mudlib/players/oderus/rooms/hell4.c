inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("corridor to therapy rooms");
long_desc="You are in a long white corridor to the rooms in which doctors analyze\n" +
"and terrorize their patients with whats known as 'therapy'. You cringe\n" +
"as you picture the daily activity in these rooms.\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell25","east",
"players/oderus/rooms/hell3","west",
   });
}
