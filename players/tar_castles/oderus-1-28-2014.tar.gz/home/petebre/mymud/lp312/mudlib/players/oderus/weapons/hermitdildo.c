inherit "obj/weapon";
int die, attacker, pain;
reset(arg) {
::reset(arg);
        if(!arg) {
set_name("dildo");
set_class(10);
                set_value(1000);
                set_weight(2);
                set_alias("dildo");
set_short("A curvy hermit dildo");
set_long(
"I bet you look kinda silly wielding a hermit dildo, eh?\n");
set_hit_func(this_object());
}
}
weapon_hit(attacker)
{
write("You bat your opponent over the head HARD.\n");
return 7;
}
