inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("End of boring passageway");
long_desc="The boring passageway continues to the east and there is also a doorway\n" +
"to the west. This place could really use some paintings or something.\n";
   items=
   ({
   });
   dest_dir=
   ({
"players/oderus/rooms/hell16","north",
"players/oderus/rooms/hell38","east",
"players/oderus/rooms/hell36","west",
   });
}
