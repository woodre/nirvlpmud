
reset(arg) {
set_light(1);
    }

short() {
return "Adult Toyland";
}

init() {
    add_action("move");
add_verb( "west");
    add_action("order");
    add_verb("buy");
}

move() {
    object ob;

call_other(this_player(),"move_player","west#players/oderus/rooms/enter1");
    return 1;
}

long() {
write("What are you doing in here you pervert? Does you mother know you come to\n") +
write("sleezy places like this?! The walls are lined with various sized dildos\n") +
write("and other mysterious sex objects, many of which you can't even imagine the\n") +
write("the intended use.  There is a large list of items for sale on the wall.\n");
write("                  ----------------------------------\n");
write("                  Items for sale here:\n");
write("                  ----------------------------------\n");
write("\n");
write("        [1] ");
write("Anal intruder                         : 100 coins\n");
write("        [2] ");
write("Vibrator                              : 250 coins\n");
write("        [3] ");
write("Vibrator attachments                  : 250 coins\n");
write("        [4] ");
write("Spiked dildo                          : 700 coins\n");
write("        [5] ");
write("Hermit dildo                          : 1000 coins\n");
write("        [6] ");
write("Two foot long dildo                   : 2000 coins\n");
write("        [7] ");
write("Two foot long-double headed dildo     : 5000 coins\n");
write("        [8] ");
write("Sex Doll                              : 2500 coins\n");
write("        [9] ");
write("Artificial Breasts                    : 1000 coins\n");
write("\n");
write("                  ----------------------------------\n");
write("Please buy by the numbers.\n");
write("The only obvious exit is: west\n");
}
order(str) {
int y;
object ob;
int price;
string pathname;
string name;
if(!str) return 0;
if(sscanf(str,"%d",y)!=1) {
write("Buy what?\n");
return 1;
}
if(y==1) {
price = 100;
pathname = "players/bismarck/castle/amulet";
name = "An obsidian amulet";
}
if(y==2) {
price = 250;
pathname = "players/bismarck/castle/boots";
name = "Fighter boots";
}
if(y==3) {
price = 250;
pathname = "players/bismarck/castle/gloves";
name = "Leather gloves";
}
if(y==4) {
price = 700;
pathname = "players/oderus/weapons/spikeddildo";
name = "A spiked dildo";
}
if(y==5) {
price = 1000;
pathname = "players/oderus/weapons/hermitdildo";
name = "A hermit dildo";
}
if (y==6){
price = 2000;
pathname= "players/oderus/weapons/dildo";
name = "Two foot long dildo";
}
if(y==7){
price = 5000;

pathname = "players/oderus/weapons/doubledildo";
name = "Two foot long-double headed dildo";
}
if(y==8){
price = 2500;
pathname = "players/bismarck/castle/db3";
name = "Deathblade [+2]";
}
if(y==9){
price = 1000;
pathname = "players/bismarck/castle/breastplate";
name = "Black chainmail";
}
if(y>9){
write("DUH! Hello! The numbers don't go that high!");
write("\n");
return 1;
}

if(y<0){
write("DUH! Hello! Do you see any negative numbers on this list?");
write("\n");
return 1;
}
if (this_player()->query_money() < price) {
write("Sorry but we don't take credit here");
write("\n");
return 1;
}
call_other(this_player(),"add_money",-price);
ob = clone_object(pathname);
move_object(ob,this_player());
write("You sicko! What are you going to do with a "+name+"?\n");
say(this_player()->query_name()+" bought "+name+".\n");
return 1;
}
