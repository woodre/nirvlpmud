inherit "obj/weapon";
int die, attacker, pain;
reset(arg) {
::reset(arg);
        if(!arg) {
set_name("dildo");
set_class(10);
                set_value(700);
                set_weight(2);
                set_alias("dildo");
set_short("A spiked dildo");
set_long(
"I bet you look kinda silly wielding a spiked dildo, eh?\n");
set_hit_func(this_object());
}
}
weapon_hit(attacker)
{
write("You bat your opponent over the head HARD.\n");
return 0;
}
