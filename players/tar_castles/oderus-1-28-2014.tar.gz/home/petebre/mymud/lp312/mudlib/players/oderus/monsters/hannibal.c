inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "hannibal" );
set_alias("hannibal");
set_short("Hannibal Lechter");
set_long("Hannibal is a very scholarly looking older man. You have trouble picturing\n" +
"him doing any of the things that he is locked in this cell for. BE WARY of\n" +
"him and do not be tricked. He is an extremely brilliant and dangerous man.\n");
     set_level(35);
     set_ac(4);
     set_wc(10);
     set_hp(60);
     set_al(-500);
     set_aggressive(1);
set_chat_chance(15);
     set_a_chat_chance(15);
load_chat("Hannibal bites at your face!\n");
load_chat("Hannibal says 'Mmmmmmm I love the taste of living flesh'\n");
     money = (0);
   }
}

