inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "spewburger" );
set_alias("spewburger");
set_short("Spewburger who ran from a fight with Kat");
set_long("Spewburger is possibly the bravest [or stupidest] of the Morrisville crew.\n" +
"As of late, he has picked up the habit of antagonizing 19th lvl. characters\n" +
"untill they chase him around and kill him. He is not entirely stable.\n");
     set_level(4);
     set_ac(4);
     set_wc(10);
     set_hp(60);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(25);
     set_a_chat_chance(25);
load_chat("Spewburger says 'Turn on your player kill, pansy!'.\n");
load_chat("Spewburger offers you a spewburger.\n");
load_chat("Spewburger tries to beam you up to the enterprise.\n");
load_chat("Spewburger says 'Kat killed me once, but never again!!'\n");
     money = (24);
   }
}

