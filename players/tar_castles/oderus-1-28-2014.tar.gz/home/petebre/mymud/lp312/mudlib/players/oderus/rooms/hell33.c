inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("long black corridor");
   long_desc=
"You are in a long black corridor leading to the Shaddy Hills retirement\n"
+ "home. Your nose quivers at the scent of old people and lysol.\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell1","east",
"players/oderus/rooms/hell37","west",
   });
}
