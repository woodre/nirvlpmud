inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("hall of statues");
   long_desc=
"This is the room of that wacky, loveable, Spewburger! On one side of the room\n" +
"is the stove on which he fries up his infamous spewburgers. Maybe you should\n" +
"give one a try.\n";
extra_reset();
   items=
   ({
"stove","Looking closer you see a truly GROTESQUE 'spewburger' frying on a pan",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell15","west",
   });
}
extra_reset(){
object monster;
monster=clone_object("players/oderus/monsters/spewburger");
if(!present("spewburger", this_object())){
move_object(monster,this_object());
return;
}
}
