inherit "obj/monster.c";
reset(arg) {
   ::reset(arg);
   if(!arg) {
      object weapon, armor;
      weapon = clone_object("players/sandman/WEAPONS/pike");
      armor = clone_object("players/sandman/ARMORS/sh_cloak");
      move_object(weapon, this_object());
      move_object(armor, this_object());
      set_name("shadow guard");
      set_alias("guard");
      set_short("Shadow Guard");
      set_long("A shadowy servant of the cuckoo's evil designs.\n");
      set_ac(9);
      set_wc(15);
      set_race("wraith");
      set_level(11);
      set_hp(165);
      set_al(-200);
      set_chat_chance(10);
      load_chat("The shadow howls menicingly.\n");
      load_chat("Shadow guard draws its weapon.\n");
      set_a_chat_chance(15);
      load_a_chat("Guard gibbers inchoherently and swings at you!\n");
   }
}
