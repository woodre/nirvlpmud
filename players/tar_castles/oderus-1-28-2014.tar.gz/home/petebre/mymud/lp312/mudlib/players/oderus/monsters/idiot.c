inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "idiot" );
set_alias("idiot");
set_short("the Idiot");
set_long("Idiot was born this was. He's the ugliest, wierdest looking guy you have\n" +
"ever seen! Probably schizophrenic too! He whines a lot.\n");
     set_level(18);
     set_ac(15);
     set_wc(26);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(10);
     set_a_chat_chance(10);
load_chat("Idiot whines, 'I'm an idiot, and I don't give a shit!'\n");
load_chat("Idiot whines, 'A shiiiit! A shiiiit!'\n");
load_chat("Idiot whines, 'I can't read or write or tie my shoes!'\n");
load_chat("Idiot whines, 'It doesn't bother me when the people stare!'\n");
load_chat("Idiot whines, 'My mind is blank and I get confused!'\n");
load_chat("Idiot whines, 'Cause I can't think with a blown out fuse!'\n");
money = (1000);
   }
}

