inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("Entrance to Morrisville hall of fame");
   long_desc=
"This is the entrance to the Morrisville mudders hall of fame. Within this\n" +
"hallway reside some of the most infamous Nirvana characters alive.\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell1","northwest",
"players/oderus/rooms/hell12","east",
   });
}
