inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "courtney" );
set_alias("courtney");
set_short("Courtney Love");
set_long("This is the punk-rock retard girl, Courtney Love. She's butt-ugly, despite\n" +
"the nose job. So kill her! Her gravely-scratchy voice annoys you too!\n");
     set_level(18);
     set_ac(15);
     set_wc(26);
     set_hp(450);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(10);
     set_a_chat_chance(10);
load_chat("Courtney screeches, 'Do ya really think I look like a man in drag?! How come\n" +
"everyone thinks that'\n");
load_chat("Courtney screeches, 'I'm not just famous because I married Kurt Cobain!\n" +
"People like my music too!'\n");
load_chat("Courtney makes a desperate attempt to sing. You cover your ears.\n");
load_chat("Courtney screeches, 'Madonna and I are best friends! I'm going to the music\n" +
"awards with her!'\n");
load_chat("Courtney pops a zit.\n");
load_chat("Courtney screeches, 'I am soooooo alternative!'\n");
money = (1000);
   }
}

