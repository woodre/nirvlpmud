inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if (!arg) {
set_name( "guard" );
set_alias("guard");
set_short("A security guard");
set_long("This is one of the security guards hired to search the visitors before\n" +
"they enter the facility.\n");
     set_level(6);
     set_ac(5);
     set_wc(10);
     set_hp(90);
     set_al(-500);
     set_aggressive(0);
set_chat_chance(15);
     set_a_chat_chance(15);
load_chat("The guard checks your belongings very haphazardly and motions you to pass.\n");
     money = (250);
   }
}

