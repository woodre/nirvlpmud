inherit "obj/monster";

reset(arg) {
	object money;
   ::reset(arg);
   if (!arg) {
set_name( "pigface" );
set_alias("pigface");
set_short("Pigface the newbie slayer");
set_long("Pigface is a very large and grotesque human/pig half breed. You\n" +
"are quite startled to see that she is pregnant.\n");
     set_level(19);
     set_ac(16);
     set_wc(28);
     set_hp(475);
     set_al(-800);
     set_aggressive(1);
set_chat_chance(40);
     set_a_chat_chance(40);
load_chat("Pigface says 'hey newbie, follow me and I'll show ya the arena!\n");
load_chat("Pigface wines at you like a pig.\n");
load_chat("Pigface says 'Vulture is a pansey! I could wip his ass!\n");
load_chat("Pigface says 'Give me some coins! I have to store my shit!\n");
load_chat("Pigface says 'have you seen Fugazi or Joe Camel around?\n");
     money = (2000);
   }
}
