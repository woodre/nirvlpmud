inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("therapy room 3");
   long_desc=
"This is the office of the world famous father of Psychoanalysis Sigmund Freud.\n" +
"His position has been left open since the day he was fired after various\n" +
"lengthy demonstrations held by local feminist groups.\n";
   items=
({
"desk","As you look at the desk of Freud you can't help but think about your childhood",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell27","north",
   });
}
