inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("reception area");
   long_desc=
"This is the mental health center reception area. There is an extremely\n"
+ "cluttered desk in the center of the room. Doctors and nurses scurry about\n"
+ "in all directions.\n";
  if(!present("doctor",this_object()))
    move_object(clone_object("players/oderus/monsters/doctor"),this_object());
  if(!present("doctor 2",this_object()))
    move_object(clone_object("players/oderus/monsters/doctor"),this_object());
  if(!present("nurse",this_object()))
    move_object(clone_object("players/oderus/monsters/nurse"),this_object());
  if(!present("nurse 2",this_object()))
    move_object(clone_object("players/oderus/monsters/nurse"),this_object());
  if(!present("nurse 3",this_object()))
    move_object(clone_object("players/oderus/monsters/nurse"),this_object());
   items=
   ({
     "desk","A page reading 'The Red-Rabbit rides at Dawn' catches your attention",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell2","north",
"players/oderus/rooms/hell16","south",
"players/oderus/rooms/hell40","southeast",
"players/oderus/rooms/hell17","west",
"players/oderus/rooms/hell4","east",
   });
}
