inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=("north of therapy room three");
long_desc="The hallway continues to the East. Is there no end?!\n";
   items=
   ({
"hallway","What are you looking at?",
   });
   dest_dir=
   ({
"players/oderus/rooms/hell27","west",
"players/oderus/rooms/hell28","east",
   });
}
