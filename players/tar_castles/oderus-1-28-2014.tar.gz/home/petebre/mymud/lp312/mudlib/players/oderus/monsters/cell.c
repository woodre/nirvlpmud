id(str) { return str == "cell" || str == "cell"; }
object hannibal;
short() { return "A cell containing the psychotic genuis Hannibal Lechter"; }
long() {
write("This huge cell is the current residence of the psychotic genius Hannibal\n"+
"Lechter. The cell contains all of the living essentials of a mad man. It looks\n"+
"like you could 'unlock' the cell if you had the right key.\n");
	}
get() { return 0; }
query_weight() { return 1; }
query_value() { return 400; }

init() {
	add_action("unlock","unlock");
	}

unlock(str) {
if(!present("key",this_player())) return 0;
	if(!str) return 0;
	if(str=="cell") {
write("You unlock the cell and Hannibal Leaps out!\n");
say((this_player()->query_name())+"unlocks the cell and Hannibal leaps out!\n");
hannibal=clone_object("players/oderus/monsters/hannibal.c");
move_object(hannibal,environment(this_player()));
	destruct(this_object());
	return 1;
	}
return 0;
}
