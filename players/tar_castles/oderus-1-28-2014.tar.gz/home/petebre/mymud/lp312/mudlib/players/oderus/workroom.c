inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
short_desc=("Oderus' Workroom");
   long_desc=
"Oderus sure is a lazy bastard! This place hasn't been cleaned\n" +
"in over 1,000,000,000 years!\n";
   items=
   ({
     "footprints","Several sets of footprints heading northwest",
     "forest","The forest seems to possess an unearthly vibrance to it",
   });
   dest_dir=
   ({
"room/church","church",
   });
}
