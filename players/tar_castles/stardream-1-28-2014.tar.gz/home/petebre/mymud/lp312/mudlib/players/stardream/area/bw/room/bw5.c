#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);
  
  set_short("A Boardwalk");
set_long("\
  The sand dusted path continues off to the east and west.  To the\n\
north lies a small store, freshly painted in an effort to make it\n\
more aesthetically pleasing for the tourist crowd.  In the windows\n\
large glass cases display a various assortment of jewels and hand\n\
crafted jewelry.  The sign above the store reads: Soulmates Jewelry.\n\
To the south, lies an enticing beach with immaculate white sand and\n\
sparkling blue water.\n");

  add_exit(BWROOMS+"jewel", "enter");
  add_exit(BEACHROOMS+"b4", "south");
  add_exit(BWROOMS+"bw6", "east");
add_exit(BWROOMS+"bw4", "west");
  add_exit(BEACHROOMS+"b3", "southwest");
  add_exit(BEACHROOMS+"b5", "southeast");

add_item("sand","\
Granular white sand");
add_item("path","\
A wooden boardwalk dusted lightly with sand, upon closer examination\n\
you can see that a plank is loose");
add_item("sign","\
A large sign displayed across the top of the store, perhaps you could\n\
read it\n");
add_item("beach","\
A beautiful sandy beach");
add_item("water","\
Crystal clear blue water");
add_item("store","\
A small jewelry store, freshly painted, with large glass windows\n\
displaying jewelry and jewels in glass cases");
add_item("crowd","\
People walking along the beach and boardwalk");
add_item("windows","\
Large glass windows lining the front of the store");
add_item("cases","\
Glass cases displaying various types of jewels and jewelry");
add_item("jewels","\
Rare and precious gems of all varieties and sizes");
add_item("jewelry","\
Various types of beautiful and unique jewelry");
add_item("paint", "\
A fresh coat of paint covering the exterior of the store");
   
    set_chance(2);
add_msg("A bird lands casually on the roof of the store.");
add_msg("\
Women walk casually by, gazing longingly at the jewelry in the\n\
storefront windows.");
add_msg("A bee buzzes past your head. BZzzZZzz.");
add_msg("A seagull swoops low to pick up a piece of food.");
add_msg("A couple leaves the store.");
add_msg("The soft wind blows sand up onto the boardwalk.");
add_msg("\
You hear a tiny bell ring as people enter and leave the store.");
  
  
add_smell("main", "\
You can smell the salt from the ocean lingering in the air.");
add_smell("air","The air smells of salt water");
add_smell("water", "The water smells salty.");

add_listen("main", "A tiny bell rings as people enter the store.");
add_listen("bell", "ding! ding! ding!");
  
add_exit_msg("enter", ({
  "A tiny bell rings as you open the door and enter the store.\n",
  "opens the door and walks into the store to the north.\n" }));
  add_exit_msg("east", ({
    "You continue down the boardwalk.\n",
    "walks further down the boardwalk.\n" }));
  add_exit_msg("west", ({
    "You walk back towards the boardwalk entrance.\n",
    "walks back towards the boardwalk entrance.\n" }));
  add_exit_msg("south", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southeast", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southwest", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
}

