#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);
  
  set_short("A Boardwalk");
set_long("\
    The boardwalk continues off to the east and west, curving ever so\n\
  slightly to accommodate the curvature of the ocean shore.  To the north\n\
is a large fish market.  In the windows you can see an enormous variety\n\
  of fresh fish cuts in cases filled with ice.  Across the top of the\n\
  store a sign reads: 'Seafood Stop'.  To the south the path is open to an\n\
  alluring beach of pure white sand and sparkling blue waters.\n");  

add_exit(BWROOMS+"seafood", "enter");
add_exit(BEACHROOMS+"b7", "south");
add_exit(BWROOMS+"bw9", "east");
add_exit(BWROOMS+"bw7", "west");
add_exit(BEACHROOMS+"b6", "southwest");
add_exit(BEACHROOMS+"b8", "southeast");

  add_item("boardwalk","\
  A wide wooden path made of wooden planks.  One of the planks appears\n\
  to be damaged");
  add_item("planks","\
  Wooden boards laid down to create the boardwalk");  
  add_item("plank","\
  This plank appears to be loose");
  add_item("path","\
  A wooden boardwalk dusted lightly with sand");
  add_item("beach","\
  A beautiful sandy beach");
  add_item("sand","\
  Granular white sand");
  add_item("water","\
  Crystal blue ocean water");
  add_item("shore","\
  A beautiful ocean shore where the ocean meets the white sand");
  add_item("fish","\
  Various types of fish of every variety and different cuts");
  add_item("market","\
  A small fish market");
  add_item("windows","\
  Large windows displaying various cuts of fish");
  add_item("cuts","\
  Various cuts of different types of fish");
  add_item("cases","\
  Glass cases filled with ice to chill the fish");
  add_item("ice","\
  Water... thats frozen");
  add_item("store","\
  A fish market");
  add_item("sign","\
  A large sign across the top of the building");
  
   set_chance(2);
  add_msg("Birds flock around the shop searching for food.");
  add_msg("A seagull hops around on the boardwalk looking for food.");
  add_msg("A woman walks out of the store carrying a packaged fish.");
  add_msg("A seagull swoops low to pick up a piece of food.");
  add_msg("A small kid runs past nearly bumping into you.");
  add_msg("A piece of newspaper blows past.");
  add_msg("\
  You hear a tiny bell ring as people enter and leave the store.");
  
  add_smell("main", "\
  You can smell the salt from the ocean lingering in the air.");
  add_smell("air","The air smells of salt water");
  add_smell("water", "The water smells salty.");

  add_listen("main", "A tiny bell rings as people enter the store.");
  add_listen("bell", "ding! ding! ding!");
  
  add_exit_msg("enter", ({
    "A tiny bell rings as you open the door and enter the store.\n",
"opens the door and walks into the store to the north.\n" }));
  add_exit_msg("east", ({
    "You continue down the boardwalk.\n",
    "walks further down the boardwalk.\n" }));
  add_exit_msg("west", ({
    "You walk back towards the boardwalk entrance.\n",
    "walks back towards the boardwalk entrance.\n", }));
  add_exit_msg("south", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southwest", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southeast", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
}

