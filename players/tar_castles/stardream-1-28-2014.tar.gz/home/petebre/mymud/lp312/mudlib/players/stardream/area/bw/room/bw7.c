#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);
  
  set_short("A Boardwalk");
  set_long("\
    The boardwalk curves back to the southwest and continues off to the\n\
  east.  The path is barred directly to the west by a lonesome vacant\n\
  store.  To the north is a small store that looks more like a hut than\n\
  a shop.  The roof is covered with large palm tree leaves, and the walls\n\
  are lined with sticks of bamboo, sealed with what appears to be a brown\n\
  muddy substance.  Across the top of the store a sign displays in funky\n\
lettering: 'Snack Shack'.  To the south lies the stunning beach and\n\
  ocean shore.\n");

  add_exit(BWROOMS+"snack", "enter");
  add_exit(BEACHROOMS+"b6", "south");
  add_exit(BWROOMS+"bw8", "east");
  add_exit(BEACHROOMS+"b7", "southeast");
  add_exit(BWROOMS+"bw6", "southwest");
  

add_item("boardwalk","\
  A wide wooden path lined with stores");
  add_item("beach","\
  A beautiful sandy beach");
  add_item("shore","\
  Where the white sandy beach meets the crystal blue ocean");  
  add_item("ocean","\
  Beautiful crystal blue water that extends far of into the distance");
  add_item("vacant store","\
  A desolate vacant store");
  add_item("store","\
  A small hut like shop that sells various snacks and drinks");
  add_item("hut","\
  A small hut like shop that sells various snacks and drinks");
  add_item("roof","\
  The roof is covered with dried palm tree leaves");
  add_item("leaves","\
  Dried palm tree leaves that cover the roof of the hut");
  add_item("bamboo","\
  Sticks of bamboo sealed together with a thick mud like substance");
  add_item("walls","\
  The walls are covered with sticks of bamboo and a thick mud like\n\
  substance");
  add_item("sticks","\
  Sticks of bamboo");
  add_item("mud","\
  A thick muddy substance used to seal the sticks of bamboo together");
  add_item("substance","\
  A thick muddy substance used to seal the sticks of bamboo together");
  add_item("sign","\
  A large sign across the top of the hut with the words 'Snack Shack'\n\
  written in funky lettering");
  add_item("lettering","\
  Funky looking writing on the sign above the shop");
  
     set_chance(2);
  add_msg("A seagull hops along the boardwalk, looking for food.");
  add_msg("A bee buzzes past your ear... BzzZZzzz.");
  add_msg("A row of ants marches past carrying a piece of candy.");
  add_msg("A seagull swoops low to pick up a piece of food.");
  add_msg("A seagull lands on the roof of the hut.");
  add_msg("An empty potato chip bag blows past.");
  add_msg("An empty soda can rolls past.");
  
  add_smell("main", "\
  The smell of hotdogs and beer fills the air.");
  add_smell("air","The air smells of hotdogs and beer");
  add_smell("hotdogs", "\
The distinct scent of freshly cooked hotdogs makes you salivate and\n\
  your tummy rumble.");
  add_smell("beer", "MmmMmm... Beer!");

  add_listen("main", "\
  You can hear people talking amongst themselves near the shop.");
  add_listen("people", "\
  The people laugh and chat idly as they eat their snacks.");
  
  add_exit_msg("enter", ({
    "You enter the 'Snack Shack' to get some food.\n",
    "enters the 'Snack Shack.\n" }));
  add_exit_msg("southwest", ({
    "You walk back towards the boardwalk entrance.\n",
    "walks back towards the boardwalk entrance.\n", }));
  add_exit_msg("south", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southeast", ({
    "You step off the boardwalk onto the sandy beach.\n",
"steps onto the sandy beach.\n"}));
  add_exit_msg("east", ({
    "You continue down the boardwalk.\n",
    "walks further down the boardwalk.\n" }));
}
