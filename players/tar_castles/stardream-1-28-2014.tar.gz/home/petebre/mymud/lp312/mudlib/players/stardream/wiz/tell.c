#include "/players/wocket/closed/ansi.h"
inherit "/players/wocket/std/wiztell.c";

reset(arg){
  if(arg) return;
  owner = "stardream";
  cap_owner = "Stardream";
  color = HIC;
  extra_look = "Stardream is the ultraMack";
}

