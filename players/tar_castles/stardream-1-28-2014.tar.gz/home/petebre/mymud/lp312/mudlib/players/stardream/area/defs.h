#include "../defs.h"

#define BEACHDIR    AREA+"beach/"
#define BEACHROOMS (BEACHDIR+"room/")
#define BEACHNPCS  (BEACHDIR+"npcs/")
#define BEACHOBJS  (BEACHDIR+"obj/")

#define BWDIR      AREA+"bw/"
#define BWROOMS (BWDIR+"room/")
#define BWNPCS  (BWDIR+"npcs/")
#define BWOBJS  (BWDIR+"obj/")

#define PIERDIR    AREA+"pier/"
#define PIERROOMS (PIERDIR+"room/")
#define PIERNPCS  (PIERDIR+"npcs/")
#define PIEROBJS  (PIERDIR+"obj/")

#define SHOREDIR   AREA+"shore/"
#define SHOREROOMS (SHOREDIR+"room/")
#define SHORENPCS  (SHOREDIR+"npcs/")
#define SHOREOBJS  (SHOREDIR+"obj/")

#define SURFDIR    AREA+"surf/"
#define SURFROOMS (SURFDIR+"room/")
#define SURFNPCS  (SURFDIR+"npcs/")
#define SURFOBJS  (SURFDIR+"obj/")

#define W1DIR      AREA+"w1/"
#define W1ROOMS (W1DIR+"room/")
#define W1NPCS  (W1DIR+"npcs/")
#define W1OBJS  (W1DIR+"obj/")

#define W2DIR      AREA+"w2/"
#define W2ROOMS (W2DIR+"room/")
#define W2NPCS  (W2DIR+"npcs/")
#define W2OBJS  (W2DIR+"obj/")

#define W3DIR      AREA+"w3/"
#define W3ROOMS (W3DIR+"room/")
#define W3NPCS  (W3DIR+"npcs/")
#define W3OBJS  (W3DIR+"obj/")

#define W4DIR      AREA+"w4/"
#define W4ROOMS (W4DIR+"room/")
#define W4NPCS  (W4DIR+"npcs/")
#define W4OBJS  (W4DIR+"obj/")
