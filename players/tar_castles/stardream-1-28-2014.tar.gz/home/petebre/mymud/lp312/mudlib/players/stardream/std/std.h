/*
 * Inherit often doesn't work properly if the string it
 * it is using has been concatenated.. no idea why.
 */

#define ARMOR    "/players/stardream/std/armor"
#define OBJ      "/players/stardream/std/obj"
#define WEAPON   "/players/stardream/std/weapon"

#define NPC       "/players/stardream/std/npc"
#define AIR_NPC   "/players/stardream/std/air_npc"
#define LAND_NPC  "/players/stardream/std/land_npc"
#define WATER_NPC "/players/stardream/std/water_npc"

#define ROOM     "/players/stardream/std/room"
#define LAND     "/players/stardream/std/land"
#define BEACH    "/players/stardream/std/beach"
#define SURF     "/players/stardream/std/surf"
#define WATER    "/players/stardream/std/water"

#define TREASURE OBJ
