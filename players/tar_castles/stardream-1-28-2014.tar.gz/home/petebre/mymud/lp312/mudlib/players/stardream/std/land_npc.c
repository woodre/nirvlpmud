inherit "/players/stardream/std/npc";
int query_stardream_land_npc() { return 1; }
