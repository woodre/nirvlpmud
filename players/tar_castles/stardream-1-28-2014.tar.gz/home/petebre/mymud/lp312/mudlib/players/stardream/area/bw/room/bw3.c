#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);
  
  set_short("A Boardwalk");
  set_long("\
  The boardwalk continues off to the east, various stores can be seen\n\
lining the northern side of the path, most in much better repair than\n\
the desolate store to the west.  The northern border of the path is\n\
blocked by a row of tall palm trees that loom overhead, giving some\n\
shade from the scorching sun.  To the south the boardwalk is open to\n\
an alluring beach of white sand.\n");        

  add_exit(BEACHROOMS+"b2", "south");
  add_exit(BWROOMS+"bw4", "east");
  add_exit(BWROOMS+"bw2", "west");
  add_exit(BEACHROOMS+"b1", "southwest");
  add_exit(BEACHROOMS+"b3", "southeast");

add_item("boardwalk","\
A wide wooden path lined with stores.");
add_item("stores","\
Various stores lining the northern side of the path.");
add_item("path","\
A wooden boardwalk dusted lightly with sand.");
add_item("store","\
A vacant, rundown store.");
add_item("border","\
A row of tall trees lines the northern border of the path.");
add_item("row","\
Tall palm trees lining the path.");
add_item("trees","\
Tall palm trees which loom overhead providing shade.");
add_item("tree","\
The tall palm tree looks like it might be fun to climb.");
add_item("shade","\
Cover provided from the sun by the tall palm trees.");
add_item("sun","\
You really shouldn't look at the sun, it will damage your eyes.");
add_item("beach","\
A beautiful sandy beach.");
add_item("sand","\
Granular white sand.");
  /*
   *Add in the ability to climb the tree... possibly place an
   *item in the top of the tree, maybe just make it do nothing
   */
  
  set_chance(2);
add_msg("A seagull flies past overhead.");
add_msg("A large bird lands in the trees overhead.");
add_msg("A bee buzzes quickly past your head.");
add_msg("An empty soda can rolls past.");
add_msg("The palm trees sway in the breeze.");
add_msg("The soft wind blows sand up onto the boardwalk.");
add_msg("The gentle breeze feels nice here in the shade.");
  
  
add_smell("main", "\
You can smell the salt from the ocean lingering in the air.");
add_smell("air","The air smells of salt water");
add_smell("water", "The water smells salty.");

add_listen("main", "You hear people walking on the boardwalk.");
add_listen(({"peeps","people"}), "The people talk amongst themselves");
  
add_exit_msg("east", ({
  "You continue down the boardwalk.\n",
  "walks further down the boardwalk.\n" }));
add_exit_msg("west", ({
  "You walk back towards the boardwalk entrance.\n",
  "walks back towards the boardwalk entrance.\n"}));
add_exit_msg("south", ({
  "You step off the boardwalk onto the sandy beach.\n",
  "steps onto the sandy beach.\n"}));
add_exit_msg("southeast", ({
  "You step off the boardwalk onto the sandy beach.\n",
  "steps onto the sandy beach.\n"}));
add_exit_msg("southwest", ({
  "You step off the boardwalk onto the sandy beach.\n",
  "steps onto the sandy beach.\n"}));
}