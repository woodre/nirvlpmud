inherit "/players/vertebraker/closed/std/monster";
int query_stardream_npc() { return 1; }
