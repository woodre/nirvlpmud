#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);
  
  set_short("A Boardwalk");
  set_long("\
    The sand dusted wooden path continues to the east and west.  To the\n\
  west you can just make out the entrance of the path as well as a run\n\
  down old store.  Just to the east you can see more stores lining the\n\
  northern side of the path, most in good repair.  The store before you\n\
  to the north appears to have been renovated recently.  The large\n\
  storefront windows encompass nearly the whole store, and are lined with\n\
  glass shelves, displaying a multitude of souvenirs and gifts as well\n\
  as some much needed beach necessities.  Across the top of the building\n\
  a sign reads: Souvenirs n' Such.  To the south lies a beautiful beach.\n");

  add_exit(BWROOMS+"gen", "enter");
  add_exit(BEACHROOMS+"b3", "south");
  add_exit(BWROOMS+"bw5", "east");
  add_exit(BWROOMS+"bw3", "west");
  add_exit(BEACHROOMS+"b2", "southwest");
  add_exit(BEACHROOMS+"b4", "southeast");
  
  add_item("path","\
  A wooden boardwalk dusted lightly with sand.");
  add_item("entrance","\
  The entrance to the boardwalk path.");
  add_item("store","\
  A small store which sells souvenirs as well as various other\n\
  necessities");
  add_item("windows","\
  Large glass windows that line the front of the store, displaying\n\
  various souvenirs, gifts, and beach necessities.");
  add_item("shelves","\
  Long glass shelves lining the windows of the store, displaying\n\
  various items");
  add_item("stores","\
  Various stores lining the northern side of the path.");
  add_item("beach","\
  A beautiful sandy beach.");
  add_item("sand","\
  Granular white sand.");
  add_item("souvenirs","\
  T-shirts, mugs, shot-glasses, shells, postcards, as well as many\n\
  other collectable items.");
  add_item("gifts","\
  Various souvenirs you can give to friends and family as gifts.");
  add_item("necessities","\
  Items such as towels, bathing suits, flip flops, sunglasses, and\n\
  sunscreen.");
  add_item("sign","\
  A large sign that reads: Souvenirs n' Such.");
  
   set_chance(2);
  add_msg("A seagull flies past overhead.");
  add_msg("\
People walk casually down the boardwalk, pausing to look at the\n\
  items in the store.");
  add_msg("\
  An kid roller-blading down the boardwalk nearly knocks you over.");
  add_msg("A row of ants marches past carrying a potato chip.");
  add_msg("A woman leaves the store carrying a large bag of souvenirs.");
  add_msg("The soft wind blows sand up onto the boardwalk.");
  add_msg("\
  You hear a tiny bell ring as people enter and leave the store.");
  
  
  add_smell("main", "\
  You can smell the salt from the ocean lingering in the air.");
add_smell("air","The air smells of salt water");
  add_smell("water", "The water smells salty.");

  add_listen("main", "A tiny bell rings as people enter the store.");
  add_listen("bell", "ding! ding! ding!");
  
  add_exit_msg("enter", ({
    "A tiny bell rings as you open the door and enter the store.\n",
"opens the door and walks into the store to the north.\n" }));
  add_exit_msg("east", ({
    "You continue down the boardwalk.\n",
    "walks further down the boardwalk.\n" }));
  add_exit_msg("west", ({
    "You walk back towards the boardwalk entrance.\n",
    "walks back towards the boardwalk entrance.\n", }));
  add_exit_msg("south", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southeast", ({
"  .You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southwest", ({
"You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
}
