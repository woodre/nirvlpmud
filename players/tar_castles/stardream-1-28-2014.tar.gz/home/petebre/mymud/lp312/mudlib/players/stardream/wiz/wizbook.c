inherit "/obj/wizbook";
