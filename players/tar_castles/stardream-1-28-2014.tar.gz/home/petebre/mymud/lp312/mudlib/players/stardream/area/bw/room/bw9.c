#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);

  set_short("A Boardwalk");
  set_long("\
    The sand dusted path continues towards the west, but begins to curve\n\
  back towards the southeast in order to follow the curvature of the\n\
  shoreline.  Lining the northern border of the boardwalk are several\n\
  very large palm trees, providing shade for people to escape the\n\
  overwhelming heat of the sun.  To the east the path is barred by a\n\
  small building, forcing you to follow the path to the southeast.  To\n\
  the southwest the path is open to the white sandy beach.\n");

  add_exit(BEACHROOMS+"b8", "south");
  add_exit(BWROOMS+"bw8", "west");
  add_exit(BWROOMS+"bw10", "southeast");
  add_exit(BEACHROOMS+"b7", "southwest");

  add_item("sand","\
  Granular white sand");
  add_item("path","\
  A wooden boardwalk dusted lightly with sand");
  add_item("boardwalk","\
  A wide wooden path lined with stores");
  add_item("beach","\
  A beautiful sandy beach");
  add_item("curvature","\
  The way the shoreline curves");
  add_item("shoreline","\
  Where the ocean meets the sand");
  add_item("border","\
  A border of large palm trees");
  add_item("trees","\
  Large palm trees that provide shade from the sun");
  add_item("shade","\
  A cool place out of the sun");
  add_item("sun","\
  Didn't your mother ever tell you not to look at the sun?!");
  add_item("building","\
  A small store");
  
  set_chance(2);
  add_msg("The palm trees sway gracdefully in the breeze.");
  add_msg("A tiny lizard runs across the boardwalk and up a tree.");
  add_msg("Several birds land in the trees above.");
  add_msg("Bird droppings fall nearby.");
  add_msg("A boy walking his dog pass by.");
  add_msg("The breeze picks up, blowing sand up onto the boardwalk.");
  add_msg("A mosquito lands on your arm.");
  
  add_smell("main", "\
  The air smells faintly of fish and salt water.");
  add_smell("air","The air smells of fish and salt water");
  add_smell("water", "The water smells salty.");
  add_smell("fish","It smells like... fish...");

  add_listen("main", "\
  You can hear the ocean waves crash down upon the sand.");
  add_listen("waves", "\
  The waves make a thunder as they crash down upon the sand");
  
  add_exit_msg("southeast", ({
    "You continue down the boardwalk.\n",
    "walks further down the boardwalk.\n" }));
  add_exit_msg("west", ({
    "You walk back towards the boardwalk entrance.\n",
    "walks back towards the boardwalk entrance.\n", }));
  add_exit_msg("south", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southwest", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
}
