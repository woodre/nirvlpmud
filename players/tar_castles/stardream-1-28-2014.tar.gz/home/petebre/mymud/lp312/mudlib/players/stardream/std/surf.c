inherit "/players/stardream/std/beach";
int query_stardream_surf() { return 1; }
