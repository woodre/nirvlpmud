inherit "/obj/armor";
int query_stardream_armor() {return 1; }
