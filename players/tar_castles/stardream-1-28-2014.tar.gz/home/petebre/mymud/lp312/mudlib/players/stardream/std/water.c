inherit "/players/stardream/std/room";
int query_stardream_water() { return 1; }
int is_water() { return 1; }
