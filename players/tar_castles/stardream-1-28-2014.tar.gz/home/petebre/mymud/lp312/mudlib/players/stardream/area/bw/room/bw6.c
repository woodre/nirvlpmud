#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);
  set_short("A Boardwalk");
  set_long("\
    The boardwalk continues to the west and northeast, curving\n\
  dramatically in a northeastern direction in order to follow the\n\
  ocean's natural shoreline.  To the north lies a vacant store, boarded\n\
  up, with several signs nailed to the boarded windows and door.  To the\n\
  east and south the path opens up to the beautiful beach.  Just off to\n\
  the southeast the shoreline curves up towards the boardwalk, bringing\n\
  the tide in close to the path.\n");  

  add_exit(BEACHROOMS+"b5", "south");  
  add_exit(BEACHROOMS+"b6", "east");
  add_exit(BWROOMS+"bw5", "west");
  add_exit(BWROOMS+"bw7", "northeast");
  add_exit(SHOREROOMS+"sh4", "southeast");
  add_exit(BEACHROOMS+"b4", "southwest");
  
  add_item("boardwalk","\
  A wide wooden path lined with stores.  A section of the wooden planks\n\
  appears to be damaged here");
  add_item("planks","\
  One of the wooden planks has been damaged and has come loose");
  add_item("beach","\
  A beautiful sandy beach");
  add_item("path","\
  A wooden boardwalk dusted lightly with sand");
  add_item("ocean","\
  A stunning ocean of crystal blue water and rolling waves");
  add_item("shoreline","\
  A stunning shoreline where white sand meets the crystal blue ocean");
  add_item("store","\
  A boarded up store that has been left vacant");
  add_item("boards","\
  Long boards nailed over the windows and door of the store");
  add_item("signs","\
  Signs nailed to the windows and doors.  Perhaps you could 'read' them");
  add_item("windows","\
  Windows that have been boarded up to prevent trespassing");
  add_item("door","\
  The door has been boarded up");
  add_item("tide","\
  Rolling ocean waves that crash down onto the white sand");
  /*
   *Ability to move plank, find a random item beneath the plank.
   *Add in read signs.
   */

     set_chance(2);
  add_msg("A seagull hops along the boardwalk, looking for food.");
  add_msg("An old man riding a bike passes by.");
  add_msg("\
  Several teenage girls in bikinis pass by giggling amongst themselves.");
  add_msg("A seagull swoops low to pick up a piece of food.");
  add_msg("A flock of birds passes by overhead.");
  add_msg("An empty potato chip bag blows past.");
  add_msg("\
  A few flecks of sand dust up into your face, temporarily blinding\n\
  you for a few seconds.");
  
  add_smell("main", "\
  You can smell the salt from the ocean lingering in the air.");
  add_smell("air","The air smells of salt water");
  add_smell("water", "The water smells salty.");

  add_listen("main", "You can hear the ocean in the distance.");
  add_listen("ocean", "\
  The waves make a loud thunder as they crash down upon the sand");
  
  add_exit_msg("northeast", ({
    "You continue down the boardwalk.\n",
    "walks further down the boardwalk.\n" }));
  add_exit_msg("west", ({
    "You walk back towards the boardwalk entrance.\n",
    "walks back towards the boardwalk entrance.\n" }));
  add_exit_msg("south", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("southeast", ({
    "You begin walking towards the ocean shore.\n",
    "begins walking towards the ocean shore.\n"}));
  add_exit_msg("southwest", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));
  add_exit_msg("east", ({
    "You step off the boardwalk onto the sandy beach.\n",
    "steps onto the sandy beach.\n"}));

}