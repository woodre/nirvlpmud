inherit "/players/stardream/std/room";
int query_stardream_land() { return 1; }
