#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);

  set_short("A Beach");
  set_long("\
  The white sand sinks softly beneath your feet as you walk across\n\
the rolling sand dunes that span the beach.  To the north you can see\n\
a wide boardwalk that extends off into the distance.  The beach\n\
continues far off into the distance to the east, but just to the west\n\
you can see the beach ends abrubptly due to some large rocks that bar\n\
the way.  The large rocks curve around to the south side of the beach,\n\
blocking passage in that direction as well.\n");  

  add_exit(BWROOMS+"bw3", "north");
  add_exit(BEACHROOMS+"b3", "east");
  add_exit(BEACHROOMS+"b1", "west");
  add_exit(BWROOMS+"bw4", "northeast");
  add_exit(BWROOMS+"bw2", "northwest"); 
  
  add_item("sand","\
  Granular white sand");
  add_item("feet","\
  They're your feet, you should know what they look like");
  add_item("dunes","\
  Rolling hills of sand");
  add_item("beach","\
  A beautiful sandy beach");
  add_item("boardwalk","\
  A wide wooden path lined with stores");
  add_item("rocks","\
  Enormous jagged rocks");

  
  set_chance(2);
  add_msg("A little girl in a diaper waddles by carrying a shovel and pail");
  add_msg("A little crab scuttles by.  What the...?");
  add_msg("Several large birds pass by overhead.");
  add_msg("Birds squalk as they fly overhead.");
  add_msg("A frisbee flys past you.");
  add_msg("A young couple passes by, walking hand in hand.");
  add_listen("main", "\
  You can hear the ocean waves crashing down upon the rocks nearby.");
  add_listen("waves", "\
  The waves make a giant thundering sound as they crash down upon the rocks.");
  add_smell("main","\
  You can smell the ocean air.");
  add_smell("air","The air smells of salt water.");
  add_smell("salt","It smells like salt....");
  add_smell("ocean","The ocean smells of salt water.");
  
  add_exit_msg("north", ({
  "You step back onto the boardwalk.\n",
  "steps back onto the boardwalk to the north.\n"}));
  add_exit_msg("east", ({
  "You continue down the beach, the soft sand sinking beneath your feet.\n",
  "continues down the beach to the east.\n" }));
  add_exit_msg("west", ({
  "You continue down the beach, the soft sand sinking beneath your feet.\n",
  "continues down the beach to the west.\n"}));
  add_exit_msg("northeast", ({
  "You step back onto the boardwalk.\n",
  "steps back onto the boardwalk to the northeast.\n"}));
  add_exit_msg("northwest", ({
  "You step back onto the boardwalk.\n",
  "steps back onto the boardwalk to the northwest.\n"}));
}
  