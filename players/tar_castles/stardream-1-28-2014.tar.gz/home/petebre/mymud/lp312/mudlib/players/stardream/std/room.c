inherit "/players/vertebraker/closed/std/room";
