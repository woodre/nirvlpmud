inherit "/obj/treasure";
int query_stardream_object() {return 1; }
