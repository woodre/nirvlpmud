inherit "/players/stardream/std/land";
int query_stardream_beach() { return 1; }
