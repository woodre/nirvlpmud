inherit "/players/stardream/std/npc";
int query_stardream_air_npc() { return 1; }
