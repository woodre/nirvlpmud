#include <ansi.h>

#define ROOTDIR     "/players/stardream/"

#define AREA        ROOTDIR+"area/"
#define CLOSED      ROOTDIR+"closed/"
#define DOCDIR      ROOTDIR+"doc/"
#define LOGDIR      ROOTDIR+"log/"
#define OPEN        ROOTDIR+"open/"
#define STDDIR      ROOTDIR+"std/"
#define WIZDIR      ROOTDIR+"wiz/"

#include "std/std.h"
