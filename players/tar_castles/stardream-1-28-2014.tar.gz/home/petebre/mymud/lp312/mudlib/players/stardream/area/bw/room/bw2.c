#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);

set_short("A Boardwalk");
set_long("\
  A wide wooden path sparsely covered in sand leads off into the\n\
distance to the east.  To the west you can see palm trees lining the\n\
entrance to the boardwalk.  To the north is a small run down shop that\n\
appears to be closed due to disrepair and neglect.  The windows are\n\
boarded up and where the door once was lies a huge piece of ply-wood\n\
with several signs nailed to the pseudo-door.  To the south, the path\n\
opens up to a stunning beach of pure white sand.\n");  

  add_exit(BWROOMS+"bw3", "east");
  add_exit(BWROOMS+"bw1", "west");
  add_exit(BEACHROOMS+"b1", "south");
  add_exit(BEACHROOMS+"b2", "southeast");
     
add_item("path","\
A wooden boardwalk dusted lightly with sand");
add_item("trees","\
Tall palm trees which loom overhead providing shade");
add_item("boardwalk","\
A wide wooden path lined with stores");
add_item("beach","\
A beautiful sandy beach");
add_item("sand","\
Granular white sand");
add_item("shop","\
A small run down shop");
add_item("windows","\
Boards are nailed over the old broken windows");
add_item("boards","\
Long wooden boards nailed over the windows");
add_item("ply-wood","\
A large piece of ply-wood made of pressed wood, nailed over the door");
add_item("signs","\
Large signs nailed to the pseudo-door, perhaps you could 'read' them");
add_item("pseudo-door","\
A large piece of ply-wood nailed over the door, it appears to have\n\
been pried loose recently.  Perhaps you could find a way into the\n\
vacant building.");
  /*
   *Add in later -
   *Move board and enter building, search building, random chance
   *of finding different items or nothing as well as signs that
   *can be read.
   */
  
set_chance(2);
add_msg("A flock of birds flies past overhead.");
add_msg("\
A seagull swoops down to grab a piece of trash from the boardwalk.");
add_msg("Seagull droppings fall nearby.");
add_msg("An empty soda can rolls past.");
add_msg("The scorching sun beats down upon you.");
add_msg("The soft wind blows sand up onto the boardwalk.");
add_msg("The wind picks up, blowing sand up into the air.");
  
  
add_smell("main", "\
You can smell the salt from the ocean lingering in the air.");
add_smell("air","The air smells of salt water");
add_smell("water", "The water smells salty.");

add_listen("main", "You hear seagulls squawking overhead.");
add_listen(({"seagulls","gulls"}), "SQUAWK SQUAWK");
  
  
add_exit_msg("east", ({
"You continue down the boardwalk.\n",
"walks further down the boardwalk.\n"}));
add_exit_msg("west", ({
"You walk back towards the boardwalk entrance.\n",
"walks back towards the boardwalk entrance.\n"}));
add_exit_msg("south", ({
"You step off the boardwalk onto the sandy beach.\n",
"steps onto the sandy beach.\n"}));
add_exit_msg("southeast", ({
"You step off the boardwalk onto the sandy beach.\n",
"steps onto the sandy beach.\n"}));
}
