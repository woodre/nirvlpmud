#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);

  set_short("A beach");
  set_long("\
  A stunning beach with soft white rolling sand dunes which span far\n\
off into the distance.  To the north you can see the busy boardwalk\n\
lined with stores.  To the south you can see the rolling tide crashing\n\
down upon the soft white sand.  To the east and west the beach\n\
stretches as far as the eye can see.\n");
  
  
  add_exit(BWROOMS+"bw4", "north");
  add_exit(SHOREROOMS+"sh1", "south");
  add_exit(BEACHROOMS+"b4", "east");
  add_exit(BEACHROOMS+"b2", "west");
  add_exit(BWROOMS+"bw5", "northeast");
  add_exit(BWROOMS+"bw3", "northwest");
  
  
  add_item("sand","\
  Granular white sand");
  add_item("dunes","\
  Rolling hills of sand");
  add_item("beach","\
  A beautiful sandy beach");
  add_item("boardwalk","\
  A wide wooden path lined with stores");
  add_item("stores","\
  Small stores that line the boardwalk");
  add_item("tide","\
  Rolling waves that crash down upon the sand");
  add_item("waves","\
  Rolling ocean water");
  add_item("water","\
  Salty wet stuff, what more do you want?!?");
  add_item("stuff","\
  In this case, stuff happens to refer to ocean water");
  add_item("ocean","\
  A beautiful blue sea");
  add_item("sea","\
  A beautiful blue ocean");
  add_item("eye","\
  Its your eye, how are you gonna look at it?!?");
   
  set_chance(1);
  add_msg("A soft breeze blows sand up on your feet.");
  add_msg("Several large birds pass by overhead.");
  add_msg("A mosquito hovers nearby waiting to catch you of guard.");
  add_msg("A little bird lands nearby searching for food.");
  add_msg("A young woman walks down the beach talking on her cell phone.");
  add_msg("You hear birds squawking in the distance.");
  add_listen("main", "\
  You can hear the ocean waves crashing into the shore nearby.");
  add_listen("waves", "\
  The waves make a soft rumbling sound as they crash down upon the sand.");
  add_listen("birds", "\
  You can hear birds squawking off in the distance.");
  add_smell("main","\
  You can smell the ocean air.");
  add_smell("air","The air smells of salt water.");
  add_smell("salt","It smells like salt....");
  add_smell("ocean","The ocean smells of salt water.");
  
  add_exit_msg("north", ({
  "You step back onto the boardwalk.\n",
  "steps back onto the boardwalk to the north.\n"}));
  add_exit_msg("east", ({
  "You continue down the beach, the soft sand sinking beneath your feet.\n",
  "continues down the beach to the east.\n" }));
  add_exit_msg("west", ({
  "You continue down the beach, the soft sand sinking beneath your feet.\n",
  "continues down the beach to the west.\n"}));
  add_exit_msg("northeast", ({
  "You step back onto the boardwalk.\n",
  "steps back onto the boardwalk to the northeast.\n"}));
  add_exit_msg("northwest", ({
  "You step back onto the boardwalk.\n",
  "steps back onto the boardwalk to the northwest.\n"}));
  add_exit_msg("south", ({
  "You head towards the ocean shore.\n",
  "walks towards the ocean shore to the south.\n"}));
}