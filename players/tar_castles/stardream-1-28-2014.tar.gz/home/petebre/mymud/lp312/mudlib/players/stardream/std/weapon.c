inherit "/obj/weapon";
int query_stardream_weapon() {return 1; }
