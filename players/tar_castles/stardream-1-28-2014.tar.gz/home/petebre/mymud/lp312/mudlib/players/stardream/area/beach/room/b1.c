#include "../defs.h"

inherit LAND;

void reset(int arg)
{
  ::reset(arg);
  if(arg) return;
  set_light(1);
  
set_short("A beach");
set_long("\
  Before you lies a stunning beach with glittering white sand and\n\
soft rolling sand dunes.  To the north the boardwalk lines the length\n\
of the beach, which extends far off to the east.  To the west and south\n\
lies a natural rocky barrier, barring passage in both directions.  In\n\
the distance, you can hear the sound of waves crashing down upon the\n\
jagged rocks.\n"); 

add_exit(BWROOMS+"bw2", "north");
add_exit(BEACHROOMS+"b2", "east");
add_exit(BWROOMS+"bw3", "northeast");

add_item("beach","\
A beautiful sandy beach");
add_item("boardwalk","\
A wide wooden path lined with stores");
add_item("sand","\
Granular white sand");
add_item("dunes","\
Rolling hills of sand");
add_item("barrier","\
Large rocks prevent further passage to the west and south");
add_item("rocks","\
Enormous jagged rocks");
add_item("waves","\
Crystal blue ocean waves");

set_chance(2);
  add_msg("A little crab scuttles by.  What the...?");
  add_msg("Several large birds pass by overhead.");
  add_msg("A mosquito hovers nearby waiting to catch you of guard.");
  add_msg("A little bird hops past looking for food.");
  add_msg("A soft breeze blows sand gently across the beach.");
  add_msg("A large dog runs past chasing a ball.");
  add_msg("A seagull squawks overhead.");
  
  add_smell("main", "\
  You can smell the ocean air.");
  add_smell("air","The air smells of salt water.");
  add_smell("salt","\
  It smells like salt....");
  add_smell("ocean","The ocean smells of salt water.");
  add_listen("main", "\
  You can hear the ocean waves crashing down upon the rocks nearby.");
  add_listen("waves", "\
  The waves make a giant thundering sound as they crash down upon\n\
  the rocks.");
  
  add_exit_msg("northeast", ({
    "You step back onto the boardwalk.\n",
    "steps back onto the boardwalk to the northeast.\n"}));
  add_exit_msg("north", ({
  "You step back onto the boardwalk.\n",
  "steps back onto the boardwalk to the north.\n"}));
  add_exit_msg("east", ({
  "You continue down the beach, the soft sand sinking beneath your feet.\n",
  "continues down the beach to the east.\n" }));
}
