inherit "/players/stardream/std/npc";
int query_stardream_water_npc() { return 1; }
