inherit "/players/mizan/closed/FuzzyBeast.c";
reset(arg){
object gold,beer;
  int me;
   if(arg) return;
  me = random(3);
set_name("hippy");
   set_race("human");
set_alias("person");
  short_desc=({
"A dirty hippy",
 "A smiling hippy",
 "A hippy with glazed eyes",
 "A wannabe hippy",
 "A dancing hippy",
 "A smiling hippy",
"A half-naked hippy",
"A stoned hippy",
"An old hippy",
   });
  long_desc=({
"This is a die hard music fan of the hippy variety.\n"+
"His eyes are the deepest bloodshot red.\n",
"With a long beard and strange, circular sunglasses,\n"+
"this hippy somewhat resembles a mix between John Lennon and Charles Manson.\n",
"A hippy in a tye died shirt sits on the ground here,\n"+
"He exhales a puff of smoke as he flashes a goofy smile.\n",
    "I bet you could kick him where the sun doesnt shine, and nothing would\n"+
    "happen...\n",
"The hippy closes and eyes and bobs their head to each side slowly\n"+
"his long dread locks fall over his face as he sways to and fro\n",
  });
  ::reset(arg);
add_money(random(200)+600);
set_hp(210 + 24*me);
set_al(-20);
set_wc(11 + 2*me);
   set_ac(7 + me);
   set_chat_chance (5);
   load_chat("The guy dances wildly.\n");
  load_chat("The guy falls into a trance with the beat.\n");
  load_chat("The guy seems to be lost in his own little world.\n");
   set_a_chat_chance(20);
   load_a_chat("The guy punches you in the belly.\n");
   load_a_chat("The guy punches your nose.\n");
   if (random(10)<=2) {
beer=clone_object("/players/xiu/tour/items/beer.c");
move_object(beer,this_object());
   }
}

#include "/players/mythos/amon/hb_ag.h"
