inherit "obj/armor";
#include "/players/fred/ansi.h";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
set_name("chef's hat");
  set_alias("hat");
set_short("A"+YELLOW+" beaded"+BOLD+GRN+" hemp "+NORM+"Necklace");
set_long("A gawdy hemp necklace with a ying yang bead attatched.\n");
set_type("necklace");
  set_ac(1);
  set_weight(1);
  set_value(50);
}
