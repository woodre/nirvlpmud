inherit "obj/armor";
#include "/players/fred/ansi.h";

reset(arg)
{
  ::reset(arg);
  if(arg) return;
set_name("pants");
set_alias("camo");
set_short("Ripped "+GREEN+"camoflage"+NORM+" pants");
set_long("A pair of tattered but comfy camoflage pants. \n");
set_type("pants");
  set_ac(1);
  set_weight(1);
  set_value(50);
}
