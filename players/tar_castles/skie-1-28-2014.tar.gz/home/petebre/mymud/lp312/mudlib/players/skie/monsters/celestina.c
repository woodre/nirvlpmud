inherit"/obj/monster.c";

void reset(status arg)
{
  ::reset(arg);
  if(arg) return;


  set_name("celestina");
  set_race("creature");
  set_short("The demigoddess celestina");
  set_long(
  "The demigoddess celestina is here wearing\n"+
  "a robe than glitters with elemental magic.\n");

  add_money(350);
  set_level(8);
  set_hp(120);
  set_al(0);
  set_ac(7);
  set_wc(12);
  set_aggressive(0);
  set_chance(30);
  set_spell_dam(15);
  set_spell_mess1(
  "The goddess cast a elemental spell!\n");

  set_spell_mess2(
  "Your body shudders as the elemental magic travels thru it!\n");
}
