inherit "room/room";

reset(arg) {
   set_light(1);
   short_desc=""
   lond_desc="";
   dest_dir=({ "/players/yaeger/rooms/...", "north...."});
   items"({ "bar", "laberlaber", "couch", "laberlaber",});
}
init() {
::init();
   add_action("verb","command");
}
