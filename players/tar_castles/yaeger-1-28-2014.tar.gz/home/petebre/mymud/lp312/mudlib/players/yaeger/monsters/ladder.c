inherit "/obj/treasure";

string str,gender,str2;

reset(arg) {
  if (arg) return 1;
  this_object()->set_id("ladder");
  this_object()->set_short("A wooden ladder");
  this_object()->set_long("A wooden ladder. Have you never seen a ladder?\nIt is just an ordinary ladder that you can use to climb out of holes.\n");
  this_object()->set_value(2);
  this_object()->set_weight(4);
  return 1;
}

init() {
  add_action("climb","climb");
}

climb(str) {
  if(str!="ladder") {return 0;}
  if(environment(this_object())==this_player()) {
  write("You can't climb a ladder you are carrying!\n");
  str=call_other(this_player(),"query_name");
  gender=call_other(this_player(),"query_gender_string");
  if(gender=="neuter"){str2="it";}
  if(gender=="male"){str2="he";}
  if(gender=="female"){str2="she";}
  say(str+" tries foolishly to climb a ladder "+str2+" is carrying!\n");
  return 1;
  }
  write("The old wooden ladder crumbles to dust under your weight.\n");
  str=call_other(this_player(),"query_name");
  say("The old wooden ladder crumbles to dust under "+str+"'s weight.\n");
  call_other(environment(this_object()),"hoch_mit",this_player());
  destruct(this_object());
  return 1;
}
