inherit "room/room";

reset(arg) {
   set_light(1);
   short_desc="Yaeger's livingroom";
   long_desc="What a nice place. It looks great everywhere are the signs\n"+
             "of riches and good taste. There is a great couch located in\n"+
             "in the middle of the room and a great bar besides the wall.\n"+
             "Maybe you can get a drink from it?\n";
   dest_dir=({ "players/yaeger/workroom.c", "south"});
   items=({
    "bar","Its a really great bar, it looks like you can order drinks here like:\n"+
          "Meiselweizen\nHefeweise\nPils\nCobacobana",
   "couch","Great a couch to relax and sit down",
});
}
init(){
::init();
   add_action("order","order");
   add_action("sit","sit");
}
order(str){
   if(str=="maiselweizen"){
     write("You order a origin german Maiselweizen and pull it down.\n"+
           "It tast very well and after a while you burp.\n");
   return 1;
   }
   if(str=="hefeweise"){
      write("You order a origin german Hefeweisbier and drink it fast.\n"+
           "But you remember you have drinking it too fast, it tasted\n"+
           "to barm and you get the feeling that you have to go to\n"+
           "toilett very fast.\n");
   return 1;
   }
   if(str=="pils"){
     write("You order a Pils and get a good cold Becks. After you\n"+
           "drink it you burp and thought about to order another one\n");
   return 1;
   }
   if(str=="cobacobana"){
     write("Ordered a Cobacobana you are surprised that you only get\n"+
              "a glass of water. And it really tasted like water when you\n"+
              "drink it.\n");
   return 1;
   }
return 0;
}
sit(str){
   if(str=="down"){
     write("You sit down on this relaxing couch and feel great.\n");
   return 1;
}
write("Try sit down.\n");
return 1;
}
