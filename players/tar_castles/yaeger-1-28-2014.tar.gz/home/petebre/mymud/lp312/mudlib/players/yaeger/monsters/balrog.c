
inherit "/players/yaeger/mydefs/mymonster";
object whip,la;

reset(arg) {
  ::reset(arg);
  if (arg) return 1;
  this_object()->set_name("Balrog");
  this_object()->set_alias("balrog");
  this_object()->set_short("The Balrog");
  this_object()->set_long("The dreaded Balrog is a large and powerful fire demon!\n");
  this_object()->set_race("demon");
  this_object()->set_level(23);
  this_object()->set_al(-1000);
  this_object()->set_hp(750);
  experience=2000000;
  this_object()->set_ep(2000000);
  this_object()->set_wc(35);
  this_object()->set_ac(15);
  this_object()->set_chance(35);
  this_object()->set_spell_dam(35);
  this_object()->set_spell_mess1("The Balrog casts a spell!");
  this_object()->set_spell_mess2("The Balrog engulfs you with flames!");
  this_object()->set_aggressive(1);
  this_object()->add_money(2000+random(3000));
	whip = clone_object("/players/yaeger/monsters/whip");
la = clone_object("/players/yaeger/monsters/ladder");
  transfer(whip,this_object());
  transfer(la,this_object());
  return 1;
}

