inherit "/obj/weapon";

reset(arg) {
::reset(arg);
if(arg) return 1;
set_name("wand");
set_class(200);
set_short("Wand of wizzardhood");
set_long("A wand of wizzardhood.\n Till now there are the following commands added:\n"+
   "-wtrans: transport a player to a location (wtrans <player> <location>\n");
set_value(0);
set_weight(0);
return 1;
}

init() {
   add_action("do_trans","wtrans");
}
do_trans(str) {
  string str1,str2;
  object obj1,obj2;
  if(!str) {
     write("wtrans <object> <location> to transfer a specified object.\n");
     return 1;
  }
  if(sscanf(str,"%s %s",str1,str2) !=2) {
     write("Missing parameter <location>\n");
     return 1;
  }
  obj1=environment()->parse_list(str1);
  if(!obj1)obj1=environment()->parse_list("/"+str1);
  if(!obj1)obj1=environment()->parse_list("@"+str1);
  if(!obj1)write("Source object '"+str1+"' not found.\n");
  obj2=environment()->parse_list(str2);
  if(!obj2)obj2=environment()->parse_list("/"+str2);
  if(!obj2)obj2=environment()->parse_list("@"+str2);
  if(!obj2)write("Source object '"+str2+"' not found.\n");
  if(!obj1 || !obj2) return 1;
  move_object(obj1,obj2);
  write("OK.\n");
  return 1;
}

