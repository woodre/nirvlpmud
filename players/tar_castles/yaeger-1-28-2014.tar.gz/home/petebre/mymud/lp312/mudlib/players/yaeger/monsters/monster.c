inherit "obj/monster.c";

reset(arg) {
	::reset(arg);
	if(!arg) {
	set_name("monster");
	set_alias("m");
	set_short("monster");
	set_long("A monster");
	set_ac(10);
	set_wc(0);
	set_level(50);
	set_hp(500);
	}
}
