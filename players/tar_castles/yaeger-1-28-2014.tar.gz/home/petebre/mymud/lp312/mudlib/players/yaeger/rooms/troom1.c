inherit "room/room";
int rs;
object ro;

reset(arg) {
   rs = 0;
   set_light(1);
   short_desc="Entryroom of Tower";
   long_desc="A great room. It looks like the room wasnt used since years.\n"+
	     "The dust is nearly 2 feet high and nowhere are footprints.\n"+
	     "There is a stairway in the southeast corner of the room,\n"+
	     "a robe in the northwest corner and a sign on the west wall.\n";
     dest_dir=({ "players/yaeger/rooms/troom2.c", "up" });
   items=({"robe", "This robe looks very old and dirty, it is stitched very\n"+
	   "often",
	   "stairway", "A very old stairway never used since years.",
           "dust", "The dust of years feets high. There can be something\n"+
          "under it\n",
	   "sign", "A very old sign, maybe you can read it when it is \n"+
	   "cleaned",
	});
}
init() {
::init();
   add_action("search", "search");
   add_action("clean", "clean");
   add_action("get", "get");
   add_action("inser", "inser");
   add_action("read", "read");
}
search(str){
      if(str == "dust"){
        write("You search the dust and feel like a hustler, but find nothing.\n");
        return 1;
        }
}
read(str){
	if(str == "sign"){
		if(rs == 0){
		write("You can't read this sign now its too dirty.\n");
		return 1;
		}
		if(rs == 1){
		write("To leave this tower you have to find the secred\n"+
		"elevator book and do what is writen in it, or you have\n"+
		"to insert 1000 gold coins in this slot.\n");
		return 1;
		}
	return 1;
	}
	return 0;
}
clean(str){
	if(str == "sign"){
	if(rs == 0){
		rs = 1;
		write("You clean the sign and find a slot and a writing on it.\n");
		return 1;
		}
	if(rs == 1){
		write("The sign is clean, why clean it again?\n");
		return 1;
		}
	return 1;
	}
	return 0;
}
get(str){
	if(str == "robe"){
		write("You get the old dirty robe, are ya shure to wear it?\n");
		ro=clone_object("/players/yaeger/objects/drobe");
		move_object(ro,this_player());
		return 1;
		}
	return 0;
}
inser(str){
	if(str == "1000 coins"){
		write("You insert 1000 coins to leave the tower, mad guy!\n");
		call_other(this_player(),"add_money",-1000);
		call_other(this_player(),"move_player","leave#/room/plane12");
		return 1;
		}
	write("You have to inser 1000 coins");
	return 1;
}
