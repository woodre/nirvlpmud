inherit "room/room";
int a;
object stone;

reset(arg) {
	a = 0;
	set_light(1);
	short_desc="Stairway to hell";
	long_desc="After a long way you enter the first landing now.\n"+
		"There is a window in the wall and looking upstairs you \n"+
		"you recognize that one stair looks dangerous.\n";
	dest_dir=({ "players/yaeger/rooms/troom2.c", "down",
		"players/yaeger/rooms/troom4.c", "up" });
	items=({
		"window", "Its a window to the west, maybe you can look out it?\n",
		"stair", "A very dangerous looking stair. You think you should\n"+
			"examine it\n",
});
}
init(){
::init();
	add_action("examine", "examine");
	add_action("up", "up");
	add_action("get", "get");
	add_action("look", "look");
}

examine(str) {
	if(str == "stair") {
		if(a == 1) {
			write("Upps someone fixed it bevor.\n");
			return 1;
			}
		write("There is a stone under the stairplate, it looks like\n"+
			"you have to get the stone to fix the stairplate.\n");
		return 1;
		}
	return 0;
}
get(str) {
	if(str == "stone") {
		if(a == 1) {
			write("Someone did it bevor, sorry.\n");
			return 1;
			}
		write("You get the stone fixing the plate. The stairway is\n"+
			"save now.\n");
		stone = clone_object("players/yaeger/objects/stone");
		move_object(stone, this_player());
		a=1;
		return 1;
		}
	return 0;
}
look(str) {
	if(str == "out") {
		write("You lean out of the window and recognize the frish air.\n"+
			"There is a great forest in the distance. Everywhere you see\n"+
			"adventures searching for treasure and adventure.\n");
		return 1;
		}
	return 0;
}

up() {
	if(a == 0) {
		write("You step on this dangerous looking stair and........\n"+
			"fall down the whole stairway breaking some of your bones.\n");
		call_other(this_player(),"move_player","downstairs#/players/yaeger/rooms/troom1.c");
		this_player()->hit_player(10);
		return 1;
		}
	return 0;
}
