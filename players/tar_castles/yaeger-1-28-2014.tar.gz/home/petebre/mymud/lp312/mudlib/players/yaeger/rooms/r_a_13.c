inherit "room/room";

reset(arg) {
	set_light(1);
	short_desc="
	";
	long_desc="
	";
	dest_dir=({
	"/players/yaeger/rooms/exit.c", "south",
	"/players/yaeger/rooms/r_a_12.c", "west",
	"/players/yaeger/rooms/r_a_14.c", "east",
	"/players/yaeger/rooms/r_b_13.c", "north",
	});
	items=({
	"spiderweb", "It looks like a piece of the great spiderweb in the south.\n",
	});
}

init() {
::init();
	add_action("smell","smell");
	add_action("listen","listen");
}


smell(str) {
	if (str) return;
	write ("You smell only fresess and flowers.\n Only from the south\n"+
		"there is a terrible smell full of rotten corpses.\n");
return 0;
}

listen(str) {
	if (str) return;
	write("From the south you hear the sound of danger and glory.\n"+
		"From north, west and east there is only silence.\n");
return 0;
}
