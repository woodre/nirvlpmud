inherit "obj/treasure";

reset(arg) {
if(arg) return;
set_alias("stone");
set_short("A stone");
set_long("A simple stone.\n");
set_value(2);
}

