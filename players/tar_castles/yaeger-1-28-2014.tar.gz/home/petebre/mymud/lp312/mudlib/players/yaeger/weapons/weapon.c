inherit "obj/weapon.c";

reset(arg) {
	set_name("test_weapon");
	set_alias("weapon");
	set_short("Only a test weapon");
	set_long("A weapon coded for testing");
	set_class(20);
	set_weight(1);
	set_value(0);
	set_hit_func(this_object());
}

weapon_hit(attacker) {
	if(random(100) > 10) {
		write("The test weapon slaps your opppnent\n");
		return 1;
	}
	return 0;
}
