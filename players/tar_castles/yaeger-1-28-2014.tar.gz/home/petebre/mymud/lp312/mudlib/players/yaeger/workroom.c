string name;
short() {return "A nice looking woman's bedroom.\n";}
long() { 
write("Upps what a nice bedroom here. The middle of the room is reserved\n"+
"for a large french bed, it looks like this woman didnt life alone.\n"+
"At one side of the room is a great wardrobe located, maybe she is not\n"+
"poor?!. A make-up table stands at the opponent wall, full of utensils\n"+
"women needs.\n\n"+
"The obvious exit is only north.\n");
}

init() {
   add_action("north"); add_verb("north");
   add_action("church"); add_verb("church");
   add_action("shop"); add_verb("shop");
   add_action("guild"); add_verb("guild");
}
church() {

    this_player()->move_player("church#room/church");
    return 1;

}

shop() {
    this_player()->move_player("shop#room/shop");
    return 1;
}
pub() {
   this_player()->move_player("pub#room/pub2");
   return 1;
}
guild() {
     this_player()->move_player("guild#players/grimm/guild");
     return 1;
}
north() {
      this_player()->move_player("livingroom#players/yaeger/rooms/livingroom");
      return 1;
}
reset(arg) {
    if(!arg)
    set_light(1);
}

im_daemons() { return 1; }
