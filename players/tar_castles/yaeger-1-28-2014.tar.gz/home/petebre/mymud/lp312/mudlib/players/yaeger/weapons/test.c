inherit"/obj/weapon";

int ch,dam;
object ob;


reset(arg) {
   ::reset(arg);
   if (arg) return 1;
   set_name("wand");
   set_alias("wand of fireballs");
   set_short("A wand of fireballs");
   set_class(4);
   set_weight(1);
   set_value(1000);

   set_long("A wand of fireballs. Type 'wfire' to activate, 'charges' for\nthe remaining number of charges.\n\nYou can recharge it if you are of ufficient level.\n");
   ch=20;
   return 1;
}

init() {
   add_action("wfire","wfire");
   add_action("charges","charges");
   add_action("recharge","recharge");
}

wfire(str) {
   if(!str) {
   write("At whom ?\n");
   return 1;
}
   ob = present(lower_case(str), environment(this_player()));
   if (!ob || !living(ob)) {
      write("At whom ?\n");
      return 1;
   }
   if (query_ip_number(ob)&&query_ip_number(this_player())) {
      write("You won't use this wand against a fellow player !\n");
      destruct(this_object());
      return 1;
   }
   write("You point the wand of fireballs at "+ob->query_name()+"\n");
   write(ob->query_name()+" is hit by a ball of flames !\n");
   dam=random(409);
   ob->hit_player(dam);
   ch -= 1;
   this_object()->set_value(ch*50);

   if(ch==0) {
   write("All charges are used up! The wand crumbles to dust.\n");
      destruct(this_object());
      return 1;
    }
return 1;
}

charges() {
   write("The wand of fireballs has "+ch+"charges left.\n");
   return 1;
}
recharge(str) {
   if(str!="wand") return 0;
   if(this_player()->query_level()<15) {
      write("You are not high enough level.\n");
      write("You must be able to cast fireballs to recharge this wand.\n");
      return 1;
   }
   if(this_player()->query_sp()<40) {
      write("Too low on power.\n");
      return 1;
   }
   this_player()->restore_spell_points(-40);
   ch +=1;
   if(ch>20) {
      write("The wand can't hold that much energy!\n");
      write("You are caught in a blast of fire!\n");
      say(this_player()->query_name()+" is caught in a large ball of fire!\n");
      this_player()->add_hp(-40);
      destruct(this_object());
      return 1;
   }
   write("OK.\n");
   return 1;
}
