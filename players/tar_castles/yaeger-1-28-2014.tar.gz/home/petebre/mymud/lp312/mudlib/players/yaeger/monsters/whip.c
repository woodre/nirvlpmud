inherit "obj/weapon";
string enemy;
reset(arg) {
  ::reset(arg);
  set_name("whip");
  set_alias("balrog's whip");
  set_short("Balrog's Whip");
  set_alt_name("Whip");
  set_long("The cruel whip of the Balrog.\n"+"It is glowing with a dark evil light.\n"+"It seems to be a very powerful weapon.\n");
  set_class(21);
  set_weight(3);
  set_light(1);
  set_value(4000);
  set_hit_func(this_object());
}
weapon_hit(attacker)
{

enemy=call_other(attacker,"query_name");
if(enemy == "balrog"||call_other(attacker,"id","balrog")) 
  {
  write("The Balrog can't be killed with his whip!\n");
  write("The whip explodes in your hand!\n");
  this_player()->reduce_hit_point(202);
  destruct(this_object());
  return 1;
}
if(call_other(attacker,"query_ac",0)>7||call_other(attacker,"query_alignment",0)>700)
  {
  write("You hit "+enemy+" like the Balrog himself would!\n");
  write("The whip is glowing...\n");
  call_other(environment(), "add_alignment", -35);
  return 25;
}
if(call_other(attacker,"query_ac",0)>4||call_other(attacker,"query_alignment",0)>400)
  {
  write("You hit "+enemy+" like a demon!\n");
  write("The whip is glowing...\n");
  call_other(environment(), "add_alignment", -25);
  return 15;
}
if(call_other(attacker,"query_ac",0)>1||call_other(attacker,"query_alignment",0)>100)
  {
  write("You hit "+enemy+" evilly!\n");
  write("The whip is glowing...\n");
  call_other(environment(), "add_alignment", -15);
  return 5;
}
return 0;
}

wield(str) {
  ::wield(str);
  if(wielded) {
    wielded_by->add_alignment(-500);
    tell_object(wielded_by, "You feel the dark power of the Balrog fill your soul!\n");
  }
  return 1;
}
