
inherit "room/room";

reset(arg){
     set_light(1);
     short_desc="Stairway";
     long_desc="You walk up this very long stairway, it seams it will never ends.\n"+
          "The dust is feet high too.The walls are made of nature stones\n"+
          "and seams to be very tough.\n";
     dest_dir=({ "players/yaeger/rooms/troom1.c", "down",
                 "players/yaeger/rooms/troom3.c", "up" });
     items=({
             "wall", "Made for centurys they are versolid",
             "stairway", "A very old and weather-beaten stairway",
             "dust", "The normal dust of centurys, maybe someone lost\n"+
             "something under it?",
          });
}
init(){
     ::init();
          add_action("search", "search");
}

search(str){
     if(str == "dust"){
          write("You search the dust and feel like a hustler, but find nothing.\n");
          return 1;
          }
     return 0;
}
