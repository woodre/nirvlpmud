inherit "obj/armor";
reset(arg){
::reset(arg);
if(arg) return;
set_name("dirty stitched robe");
set_alias("robe");
set_alias("dirty robe");
set_short("Dirty stitched robe");
set_long("A very old stitched and dirty robe.\n");
set_weight(2);
set_value(10);
set_ac(1);
set_type("misc");
}
