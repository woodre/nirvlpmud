
inherit "obj/monster";

reset(arg)
{
	object gold;
	::reset(arg);
	if(arg) return;
	set_name("m");
	set_race("");
	set_alias("");
	set_short("A testmonster");
	set_level(50);
	set_hp(0);
	set_al(-200);
	set_wc(0);
	set_ac(0);
		gold=clone_object("obj/money");
		gold->set_money(1000);

		move_object(gold,this_object());
}
