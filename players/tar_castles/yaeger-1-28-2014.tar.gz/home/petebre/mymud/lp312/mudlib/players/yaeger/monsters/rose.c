id(str) { return str == "rose"; }
reset() {}

long() { write("A magic red rose.\n"); }

short() { return "A red rose" ; }

init() {
	add_action("rose"); add_verb("rose");
    add_action("drop_object"); add_verb("drop");
}

rose(arg) {
	write("You are smelling roses.\n");
    call_other(this_player(),"heal_self",350);
    return 1;
}

get() {return 1; }


query_weight() { return 0; }


drop_object(str) {
    if (!str || !id(str))
        return 0;
	write(" The rose runs away.\n");
    destruct(this_object());
    return 1;
}
