/*
** GSM Cybernetics[tm] Optical Implant
**
** This is the beginnings of an actually useful item, which if I ever
** figure out what the hell I am doing, could evolve into a type of
** guild object...
**
** Dodger 15 FEB 94
*/

#include <ansi.h>
#include "/players/dodger/dfun/userdefs.h"
inherit "obj/treasure";

reset(arg) {
             string long_desc;
long_desc = "You search for a reflective surface with which to examine your eye...\nHey!!  Neato!!  It ALMOST matches your other eye!!  You notice a small metal\ntab set near your eyebrow.  Squinting carefully at it you can just make out\nthe tiny lettering on it...'OPTIONS'.\n";
             if (arg) return;
             set_id("sensor");
set_short("DATIX Cyberware[tm] Tactical Sensor (implanted)");
set_long(long_desc);
             set_value(1000);
             return 1;
           }
init() {
         ::init();
         add_action("info","options");
         add_action("stat","tscan");
       }

eval(str) {
            if (str <= 2 )  return "Insignificant";
if (str <= 4 ) return "Puny";
if (str <= 6 ) return "Weak";
if (str <= 8 ) return "Moderate";
if (str <= 10 ) return "Average";
if (str <= 12 ) return "Considerable";
if (str <= 14 ) return "Strong";
if (str <= 16 ) return "Powerful";
if (str <= 18 ) return "Mighty";
return "Deadly";
          }

eval_life(str) {
                 int rel_life;
                 int subj_life,player_life;
                  player_life = USER->query_hp();
                 rel_life = str - player_life;
                 if ( rel_life >= 150 ) return "Far Superior to ";
                 if ( rel_life >= 100 ) return "Much Stronger than ";
                 if ( rel_life >= 50  ) return "Stronger than ";
                 if ( rel_life == 0 ) return "Equal to ";
                 if ( rel_life <= 50  ) return "Weaker than ";
                 if ( rel_life <= 100 ) return "Much Weaker than ";
                 if ( rel_life <= 150 ) return "Way Inferior to ";
               }
info() {
         cat("/players/dodger/help/scanner");
         return 1;
       }

stat(str) {
            object subject;
string name,say_to_room,ac,say_to_subject,wc,hp,level,report;
string pk,ht,wt;
            if (!str) return;
            subject = present(str,environment(USER));
/*
** Line below is the change necessary for a complete MUD-scan.  8)
**
            subject = find_living(str);
**
*/
            if (!subject) return;
/*
if (subject->query_level() > 19) { return; }
*/
say_to_room = "\nYou hear a high pitched whine as a thin red particle beam shoots out\nfrom "+NAME+"'s eye, and traces small, rectangular, grid-like patterns\nover "+subject->query_name()+"'s body...\n"+PROMPT;
say_to_subject = "\nA thin red particle beam suddenly shoots from "+NAME+"'s eye, and\npenetrates your skull!!  You stand transfixed in awe, as the beam\nquickly scans your entire body...your skin tingles all over...\n"+PROMPT;
name = capitalize(subject->query_name());
ac = eval((subject->query_ac()*2));
wc = eval(subject->query_wc());
hp = eval_life(subject->query_hp())+"yours.";
level = subject->query_level();
pk = "";
if ((subject->query_pl_k())==1) { pk = "<<PLAYER KILLER>>"; }
write("\n"+"   "+BLINK+RED+BACKSTR+"##"+NORMAL+"   --- SUBJECT: "+name+"\n"+
        "   "+BLINK+RED+BACKSTR+"##"+NORMAL+"   --- Level: "+level+"\n"+
        " "+BLINK+RED+BACKSTR+"######"+NORMAL+"   --- Attack: "+wc+"\n"+
        ""+BLINK+RED+BACKSTR+"# #### #"+NORMAL+"   --- Defense: "+ac+"\n"+
        ""+BLINK+RED+BACKSTR+"#  ##  #"+NORMAL+"\n"+
        "  "+BLINK+RED+BACKSTR+"#  #"+NORMAL+"\n"+
        "  "+BLINK+RED+BACKSTR+"#  #"+NORMAL+"   --- Lifeforce: "+hp+"\n"+
        "  "+BLINK+RED+BACKSTR+"#  #"+NORMAL+"\n"+
        " "+BLINK+RED+BACKSTR+"##  ##"+NORMAL+"   "+pk+"\n\n");
if (subject != USER) {
   tell_object(subject,say_to_subject);
   say(say_to_room,subject);
                     }
            return 1;
          }
