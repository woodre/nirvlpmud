/*
** Crystal Ball
**
** Returns room desc of indicated living object, using command
** "seek [creature]".
**
** Dodger 06 MAR 94
*/

#include <ansi.h>
inherit "obj/treasure";

reset(arg) {
   if (arg) return;
   set_id("ball");
   set_short("A crystal ball");
   set_weight(10);
   set_value(1500);
   return 1;
   }

init() {
   ::init();
   add_action("seek","seek");
   return 1;
   }

seek(str) {
   object ob,obp,obs,room;

   write(
   "You peer intently into the cloudy interior of the crystal ball...\n"
   );
   write(
   "The turquoise and amber mists within begin to swirl violently with the\n"+
   "strength of your concentration... A dull, yellow light glows from the\n"+
   "center of the sphere, and radiates slowly out to the surface...\n"+
   "The mists eventually scatter, revealing...\n\n"+BOLD+CYAN+BACKSTR
   );
   if (!str) {
      write("Seek WHAT?\n");
      return 1;
      }
   ob = find_living(str);
   if (!ob) {
      write(NORMAL+"Nothing...\n\nThe crystal ball grows cloudy once more...\n");
      return 1;
      }
   room = environment(ob);
   call_other(room,"long",0);
   obp = first_inventory(room);
   while (obp) {
      obs = next_inventory(obp);
if (obp->short()) write (obp->short()+"\n");
      obp = obs;
      }
   write("\n"+NORMAL+"The crystal ball grows cloudy once more...\n");
   return 1;
}
