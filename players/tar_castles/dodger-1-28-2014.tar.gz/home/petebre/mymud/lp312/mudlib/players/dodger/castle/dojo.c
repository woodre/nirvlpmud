/*
** Japanese Training Dojo
**
** This is a small room for testing weapons, mainly.  User can summon
** a moderate-level creature to attack here...
**
** Dodger 03 MAR 94
*/

#include "std.h"
#include "/players/dodger/dfun/mons.c"
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
#define DOJO "players/dodger/castle/dojo"

extra_reset() {
   object statue;
   statue = clone_object("obj/treasure");
   statue->set_id("statue");
   statue->set_short("An ivory statue of Peng-San");
   statue->set_weight(10);
   statue->set_value(5000);

   move_object(statue,this_object());
   return 1;
   }
extra_init() {
   add_action("duel","duel");
   return 1;
   }

TWO_EXIT("players/dodger/workroom","suite",
         "players/dodger/rose_garden","rose",
"A Japanese-styled Training Dojo",
"   You hear the soft sound of Oriental panflutes, and gently trickling water as\n"+
"you gaze in awe around this small, serene setting.  Various ancient tapestries\n"+
"depicting mighty Samurai, Dragons, and the Disciples of Peng-San line the thin,\n"+
"but sturdy bamboo walls.  Small white candles, carefully placed along the floor\n"+
"beneath each of the faded tapestries, give the room its soft, peaceful glow.  A\n"+
"simple threaded straw mat, some three feet wide, runs from the entry way to a\n"+
"small ivory statue of Peng-San, seated on a small pedestal, in the center of a\n"+
"white marble fountain.\n",
1)
