watch() {
          string time;
   time = BOLD+WHITE+ctime()+BACKSTR;
write("//==========================\\\\"+"\n");
write("|| "+time+NORMAL+" ||"+"\n");
write("\\\\==========================//"+"\n");
          return 1;
        }
