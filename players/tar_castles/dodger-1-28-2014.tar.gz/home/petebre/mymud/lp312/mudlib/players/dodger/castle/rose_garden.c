

inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "The Count's Rose Gardens";
    no_castle_flag = 0;
    long_desc = 
        "   Light breezes carry a pleasant, fresh scent to your nostrils, as you wander\n"
        + "happily inside the shady courtyard of Count Almaviva's splendid rose gardens.  A\n"
        + "small cobblestone path winds among the richly soiled plots, whose sturdy wooden\n"
        + "trellises support some of the largest, and most beautiful bushes of white, red,\n"
        + "and pink roses you have ever seen...in full bloom, no less!!  In the center of\n"
        + "this courtyard, in a small, round plot of its own, sits a most extraordinary\n"
        + "young (and very pampered) rose bush, whose blooms look so perfect that you \n"
        + "can't help but feel a strong urge to 'pick' one...\n";
    dest_dir = 
        ({
        "/players/dodger/dojo", "north",
        "/players/dodger/workroom", "south",
        });
}

query_light() {
    return 1;
}
query_room_maker() {
    return 101;
}

/*
    remove the comments around the "room is modified()" code
    below to prevent changes you have done to this room to
    to be lost by using the room maker
*/
/*
room_is_modified() {
    return 1;
}
*/

/*
 make your additions below this comment, do NOT remove this comment
--END-ROOM-MAKER-CODE--
*/

