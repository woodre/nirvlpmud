/*
** Shielded Workworm
**
** This is a modified shielded workroom by an unknown author (Pavlik?).
** It allows for control of roomshield.
**
*/

#include "std.h"

#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
#undef EXTRA_INIT
#define EXTRA_INIT extra_init();
#define OWNER find_player("dodger")
#define VISITOR this_player()

status shield_status;

extra_reset(arg) {
                   if(arg) { return; }
                   shield_status = 0;
                 }

extra_init() {
      if(security_check(VISITOR)) {
      if(VISITOR==OWNER) {
      add_action("set_login_location","login");
add_action("shield_control","shield");
      }
   }
}


security_check(intruder) {
string intruder_name;
   if(intruder==OWNER) { return 1; }
   if(shield_status == 1) {
   write("Please knock, first!\n");
      if(OWNER){
         intruder_name = intruder->query_name();
         tell_object(OWNER, capitalize(intruder_name)
            + " just tried to enter your workroom.\n");
      }
      move_object(intruder, "room/void");
      call_other(intruder,"command","look");
      return 0;
   }
   if(intruder->is_invis() == 1) {
      call_other(intruder,"command","vis");
   }
   return 1;
}

shield_control(str) {
if (!str) { write("Usage: shield [on/off].\n"); }
   if ( str == "on" ) { write("Room shield activated.\n");
shield_status = 1;}
   if ( str == "off" ) { write("Room shield deactivated.\n");
shield_status = 0;}
                         return 1; }

set_login_location(str) {
string who, where;
object target;
   if(!str) return 0;
if(sscanf(str,"%s at %s",who,where) != 2) {
write("Usage: login [player] at [room/loc].\n");
return 1;
   }
   target = find_player(who);
   if(!target) {
      write("Cannot find "+capitalize(who)+"\n");
      return 1;
   }
   if(where == "none") {
      target->set_home(0);
      write("Starting location cleared.\n");
      return 1;
   }
   if(!find_object(where)) {
      write("invalid location.\n");
      return 1;
   }
   write("Starting location set to "+where+"\n");
   target->set_home(where);
   return 1;
}

valid_read(str) { return call_other(this_player(),"valid_read",str); }

THREE_EXIT(
"room/shop","Shop",
"room/church","Church",
"room/post","Post",
"Dodger's Office Suite",
"   This comfortably-furnished office suite is situated on the corner of the\n"+
"twenty-sixth floor of a magnificent highrise tower, located in the midst of\n"+
"downtown San Francisco's burgeoning financial district.  Heavily polished oak\n"+
"panelling covers the walls on all sides, save for the eastern wall, which is\n"+
"a large, tinted-grey window, commanding a majestic view of the entire East Bay.\n"+
"The room is unfurnished, with the exception of a small marble-topped liquor\n"+
"cabinet, which is set against the western wall.\n",
1)

