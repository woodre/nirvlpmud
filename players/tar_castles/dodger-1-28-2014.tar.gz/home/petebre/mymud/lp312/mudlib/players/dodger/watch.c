#include <ansi.h>
inherit "obj/treasure";
#define ME this_player()

reset(arg) {
   if (arg) return;
   set_id("watch");
   set_alias("wristwatch");
   set_value(500);
   set_short("A Dodgex[tm] wristwatch");
   }

init() {
   ::init();
   add_action("time","time");
   }

time(str) {
   string time,date_string;
   date_string = ctime();
   time = extract(date_string,11,18);
write("  /========\\"+"\n");
write(" /==DODGEX==\\"+"\n");
write("//==========\\\\"+"\n");
write("||/        \\||]"+"\n");
write("|| "+BOLD+WHITE+time+BACKSTR+NORMAL+" ||"+"\n");
write("||\\        /||]"+"\n");
write("\\\\==========//"+"\n");
write(" \\==========/"+"\n");
write("  \\========/"+"\n");
   return 1;
   }
