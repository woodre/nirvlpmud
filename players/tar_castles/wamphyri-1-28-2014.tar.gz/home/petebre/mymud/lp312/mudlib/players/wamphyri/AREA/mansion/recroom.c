inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(1);
  short_desc = "Rec room";
  long_desc =
"The room is shrouded in mist and strange light.  Through the mist you\n"+
"notice numerous shadowy figures moving about.  One figure near the\n"+
"back seems to be more solid than the rest.  A strange glow is coming\n"+
"from the floor near the solid figure.  Above you in the corner you notice\n"+
"a small ladder leading to the attic.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/landing", "north",
     "/players/wamphyri/mansion/study", "west",
     "/players/wamphyri/mansion/attic1", "up"
     });

items=({
     "mist", "The mist engulfs the entire room",
     "strange light", "Shinning throughout the mist you cant tell where the\n"
     +"light is coming from",
     "light", "Shinning throughout the mist you cant tell where the\n"
     +"light is coming from",
    "ladder", "A small wooden ladder leading to the attic above",
    "shadowy figures", "Whenever you get close enough to see one of the\n"
    +"figures they fade out of existence",
     "figures", "Whenever you get close enough to see one of the\n"
     +"figures they fade out of existence",
     "strange glow", "The strange glow seems to be floating above the floor\n"
     +"in a shifting pattern",
     "glow", "The strange glow seems to be floating above the floor\n"
     +"in a shifting pattern",
    });

move_object(clone_object("/players/wamphyri/mansion/creatures/444d.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/spirit.c"),
this_object());
}
