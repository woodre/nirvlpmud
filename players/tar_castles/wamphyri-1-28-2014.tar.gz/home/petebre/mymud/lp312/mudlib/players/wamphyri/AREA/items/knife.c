/* Thanks to Saber for the help with this (from his examples) */
 inherit "obj/weapon.c";
#include "/players/wamphyri/closed/ansi.h"

 reset(arg) {
    ::reset(arg);
    if (arg) return;

     set_name("Na Laetha Geal M'oige");
     set_alias("bagh nakh");
      set_short("A bagh nakh");
        set_long("It is a bagh nakh.  A small dagger with a set of\n"+
                "brass knuckles with spikes.  A series of rings\n"+
                 "with spikes fit over the bearer's fingers.  Spikes\n"+
                 "stick outward from each knuckle when a fist is\n"+
                 "formed.  There seem to be runes etched in blood\n"+
                "along the blade.\n");
      set_read("This blade is named 'Na Laetha Geal M'oige'.\n");
       set_class(10);
    set_weight(2);
    set_value(500);
    set_hit_func(this_object());
}

weapon_hit(attacker){

int banana;
banana = random(11);

if(banana > 8)   {

    say("Na Laetha Geal M'oige "+BLU+"flares"+NORM+" greatly as it draws the "+RED+"blood"+NORM+" of its foe.\n");

       write("Na Laetha Geal M'oige "+BLU+"flares"+NORM+" as it plunges "+RED+"deep\n"+
          NORM+"into your foe.\n");

return 5;

    }
    return;
}
