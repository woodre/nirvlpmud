id(str) { return str == "example"; }
get() { return 1; }
drop() { destruct(this_object()); }
short() { return "An example"; }
long() { write("Type \"example_cmds\".\n"); }
init() {
add_action("cmds","example_cmds");
add_action("test1","test1");
add_action("test2","test2");
add_action("test3","ls");
}
cmds() { write("test1   test2   test3\n");return 1; }
test1() {
  write("This function is called, executed, but has a return of 0.\n");
  return 0;
}
test2() {
  write("This function is called, executed, and has a return of 1.\n");
  return 1;
}
test3() {
  write("Something happens in this function.\n");
  return 0;
}
