inherit "obj/monster";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  object banana, orange;
  if(arg)
    return;
  ::reset(arg);
  set_name("Gelugon");
  set_alias("Gelugon");
  set_short("A gelugon");
set_long("Before you stands one of the most powerful of the baatezu.\n"+
"The gelugon looks alien, with a 12-foot insectlike body,\n"+
"claws on its hands and feet, and sharp pincers at the mouth.\n"+
"Its head bulges with multifaceted eyes and a long, thick\n"+
"tail covered with razor-sharp spikes snakes out of its back.\n"+
"This wholly unnatural creature radiates cold evil.\n");
  load_chat("The Tower has fallen.  The Nephandi are almost upon us.\n");
  load_chat("You shiver as Lord Gilmore stares into your soul.\n");
  load_chat("Lord Gilmore intones:\n"+
             "\t I speak the secreat language.\n"+
             "\t I know the meanings of numbers.\n"+
             "\t I perceive more subtle truths\n"+
             "\t than your unsophisticated mind can fathom.\n");
  load_chat("Lord Gilmore asks: Are you a Nephandus?\n");
  load_chat("Lord Gilmore weeps over his lost Chantry.\n");
  load_chat("Lord Gilmore searches for Nephandi to destroy.\n");
  set_chat_chance(10);
  load_a_chat("Lord Gilmore chants a formulae as he draws a pentacle in the air\n"
                    +"with his sword.\n");
  load_a_chat("A hurricane blast blows you into the wall.\n");
  load_a_chat("Flames shoot out of Lord Gilmores hands.\n");
  set_a_chat_chance(10);
  set_spell_mess1("Reality bends between the two combatants.\n");
  set_spell_mess2("Lord Gilmore casts a sheet of lightning on you.\n");
  set_spell_dam(20+random(25));
  set_chance(8);
  set_heal(4,15);
  set_level(20);
  set_hp(500+random(58));
  set_wc(28+random(5));
  set_ac(13+random(5));
  set_al(0);
  add_money(800+random(1000));
  set_race("demon");
  set_gender("male");
  banana = clone_object("/players/wamphyri/mansion/items/sword.c");
  move_object(banana,this_object());
  orange = clone_object("/players/wamphyri/mansion/items/amulet.c");
  move_object(orange,this_object());
  }
id(str) { return str == "gelugon" || str == "Gelugon" ; }
