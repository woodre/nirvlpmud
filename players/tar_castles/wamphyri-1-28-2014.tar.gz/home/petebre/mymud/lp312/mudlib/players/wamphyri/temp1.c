#include "/players/wamphyri/closed/ansi.h"
reset (arg) { if(arg || root()) return;
find_player("sleepwalker")->set_title("the Serpent of Larn");
destruct(this_object());
}
