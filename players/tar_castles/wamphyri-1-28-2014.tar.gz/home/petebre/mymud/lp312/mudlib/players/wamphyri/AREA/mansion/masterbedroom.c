inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(1);
  short_desc = "The master bedroom";
  long_desc =
"In the middle of the room sits a large king size waterbed.  As you move\n"+
"into the room you blink as you realize your now standing next to the\n"+
"waterbed.  Distance doesn't seem to exist in this room, whenever you\n"+
"move towards anything you suddenly realize your already standing next\n"+
"to it.  You can't shake the feeling that there is someone in the room with\n"+
"you.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/closet", "north",
     "/players/wamphyri/mansion/deck", "south",
     "/players/wamphyri/mansion/landing", "west"
     });

items=({
     "waterbed", "It is an extremely large top of the line waterbed",
  });

move_object(clone_object("/players/wamphyri/mansion/creatures/correspondence.c"),
this_object());
}
