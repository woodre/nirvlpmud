#include "/players/wamphyri/closed/ansi.h"
reset (arg) { if(arg || root()) return;
find_player("wampy")->set_title("the Vampiric Test Character");
destruct(this_object());
}
