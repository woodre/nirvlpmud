inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
if(arg)
     return ;
  set_light(0);
short_desc = "dark room";
long_desc = 
"This seems to be a smaller room but you cant be sure because it is\n"+
"completely covered in darkness.  The darkness seems almost\n"+
"supernatural.  A deep laughter comes from the deep corners of the\n"+
"room and seems to echo in your mind.\n";
dest_dir=
   ({
     "/players/wamphyri/mansion/crypt", "north"
});

items=({
     "corners", "It is too dark, you cannot make out anything.",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/Dracula.c"),
this_object());
}

 realm() { return "NT";
}

init() {
  ::init();
  add_action("check_north","north",1);
}
check_north() {
 
  if(present("maltet")) {
    write("Shadows swirl around you and block your path.\n");
    return 1;
  } else
    return 0;
}
