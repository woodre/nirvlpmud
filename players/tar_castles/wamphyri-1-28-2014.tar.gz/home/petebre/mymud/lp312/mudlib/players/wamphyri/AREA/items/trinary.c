/* Thanks to Saber for help with this */
inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

    set_id("trinary deck");
    set_short("Trinary deck");
      set_long("It is a Virtual Adepts Trinary deck.  Adepts\n"+
             "work their arcane technomagick with advanced\n"+
              "computers called Trinary units.  Where most\n"+
              "systems work only with 'yes' and 'no', Trinary\n"+
               "decks understand 'maybe.'\n");
    set_weight(3);
   set_value(900);
}
