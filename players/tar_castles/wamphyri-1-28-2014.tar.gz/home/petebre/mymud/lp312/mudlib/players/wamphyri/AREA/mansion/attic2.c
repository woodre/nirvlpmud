inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   if(arg) return ;
   move_object(clone_object("/players/wamphyri/AREA/messengers/mansion/010.c"), this_object());
   move_object(clone_object("/players/wamphyri/AREA/creatures/mansion/gelugon.c"), this_object());

  set_light(0);
  short_desc = "a dark room";
  long_desc =
"You have moved deeper into the attic, it is completely pitch black here.\n"+
"Nothing is at all visible and you have trouble making out the slightest\n"+
"feature of the room.  You think you can see something to the west, some\n"+
"type of slight glow.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/attic1", "north",
     "/players/wamphyri/mansion/attic3", "west"
     });

items=({
     "messenger", "There is no messenger here",
     "010", "There is no 010 here",
   });

}
