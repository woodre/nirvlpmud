inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   if(arg)
     return ;
  set_light(1);
   short_desc = "The basement";
  long_desc =
"You stand upon the cold concrete floor of the basement.  A murky half\n"+
"light spills down the stairs from the kitchen above. In one corner you\n"+
"notice a few chairs and one large couch with a small table in between\n"+
"them. You can hear what sounds like bubbling and  eerie laughter coming\n"+
"from the closed door to the south. Through the eastern door you can\n"+
"make out the faint sound of glasses clinking together. Currently the room\n"+
"is empty of beings, but smoke is drifting from the candle as if it was\n"+
"just extinguished.\n";
dest_dir=
   ({
     "/players/wamphyri/mansion/kitchen", "up",
     "/players/wamphyri/mansion/workshop", "south",
     "/players/wamphyri/mansion/winecellar", "east"
     });

items=({
     "table", "Sitting on the table is a large candlestick and a number of books",
     "candlestick", "It looks as if this candlestick has been here for a long\n"
     +"time. The wax has streamed down the candle and has formed a small\n"
     +"pool around the base of the candlestick.  Somebody has most likely\n"
     +"just left the room because there is still smoke drifting up from the\n"
     +"just extinguished candle",
     "books", "There are three books here.  You wonder where they came\n"
     +"from",
     "chairs", "Looking at the couch and the chairs they seem to be brand\n"
     +"new and very comfortable.  It also looks as if they are used quite often",
     "couch", "Looking at the couch and the chairs they seem to be brand\n"
     +"new and very comfortable. It also looks as if they are used quite often",
     "door", "There is two doors leading from the room.  One is to the south\n"
     +"and you can hear what sounds like bubbling and an eerie laughter\n"
     +"coming from behind it.  The sound of clinking glass can be heard\n"
     +"behind the door to the east",
     "doors", "There is two doors leading from the room.  One is to the south\n"
     +"and you can hear what sounds like bubbling and an eerie laughter\n"
     +"coming from behind it.  The sound of clinking glass can be heard\n"
     +"behind the door to the east",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/6666.c"),
this_object());
}
