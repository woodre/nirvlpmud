inherit "obj/monster";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  object banana, orange;
  if(arg)
    return;
  ::reset(arg);
  set_name("Lord Edward Gilmore");
  set_alias("Lord Gilmore");
  set_short("Lord Gilmore");
  set_long("Before you stands Lord Edward Gilmore.  He seems to be lost\n"+
                "in memory.  He was the 27th Chancellor of the Fors Collegis\n"+
                "Mercuris on the Horizon Realm Mus.  After its destruction he\n"+
                "hopes to rebuild a Chantry here in this Horizon Realm.  But it\n"+
                "seems that a great many mages have gathered here, most with\n"+
                "the same purpose.  He is not sure how easy it will be to make\n"+
                "it his own.\n");

  load_chat("The Tower has fallen.  The Nephandi are almost upon us.\n");
  load_chat("You shiver as Lord Gilmore stares into your soul.\n");
  load_chat("Lord Gilmore intones:\n"+
             "\t I speak the secreat language.\n"+
             "\t I know the meanings of numbers.\n"+
             "\t I perceive more subtle truths\n"+
             "\t than your unsophisticated mind can fathom.\n");
  load_chat("Lord Gilmore asks: Are you a Nephandus?\n");
  load_chat("Lord Gilmore weeps over his lost Chantry.\n");
  load_chat("Lord Gilmore searches for Nephandi to destroy.\n");
  set_chat_chance(30);
  load_a_chat("Lord Gilmore chants a formulae as he draws a pentacle in the air\n"
                    +"with his sword.\n");
  load_a_chat("A hurricane blast blows you into the wall.\n");
  load_a_chat("Flames shoot out of Lord Gilmores hands.\n");
  set_a_chat_chance(10);
  set_spell_mess1("Reality bends between the two combatants.\n");
  set_spell_mess2("Lord Gilmore casts a sheet of lightning on you.\n");
  set_spell_dam(20+random(25));
  set_chance(8);
  set_level(20);
  set_hp(500+random(58));
  set_wc(28+random(5));
  set_ac(13+random(5));
  set_al(0);
  add_money(800+random(1000));
  set_race("human");
  set_gender("male");
  banana = clone_object("/players/wamphyri/mansion/items/sword.c");
  move_object(banana,this_object());
  orange = clone_object("/players/wamphyri/mansion/items/amulet.c");
  move_object(orange,this_object());
  }
id(str) { return str == "gilmore" || str == "lord gilmore" || str == "edward" ; }
