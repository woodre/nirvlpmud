/* Thanks to Saber for the help with this (from his examples) */
 inherit "obj/weapon.c";
#include "/players/wamphyri/closed/ansi.h"

 reset(arg) {
    ::reset(arg);
    if (arg) return;

    set_name("Cow");
    set_alias("cow");
    set_short("A cow");
    set_long("This is a cow.\n");
    set_class(101);
    set_weight(0);
    set_value(0);
    set_hit_func(this_object());
}

weapon_hit(attacker){

int banana;
banana = random(11);

if(banana > 2)    {

  say("The cow "+GRN+"moos"+NORM+" wildly as it crushes its foe.\n");

    write("Your foe screams as the cow tramples over him.\n");

return 100;

    }
    return;
}
