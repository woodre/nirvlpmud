inherit "obj/monster";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   object weapon, armor;
   if(arg)
     return;
   ::reset(arg);
   set_name("mummy");
   set_alias("an ancient mummy");
  set_short("An ancient mummy");
   set_long("This mummy looks to be thousands of years old.\n");
  load_chat("The mummy moans.\n");
   set_chat_chance(5);
   load_a_chat("The mummy groans.\n");
   set_a_chat_chance(10);
   set_spell_mess1(RED+"The mummy hits you with a "+GRN+"crushing blow.\n"+NORM);
   set_spell_mess2("The mummy swings but misses.\n");
   set_spell_dam(10);
   set_chance(5);
   set_level(19);
   set_hp(475);
   set_wc(28);
   set_ac(16);
   set_al(-100);
   set_gender("male");
/*weapon = clone_object("/players/wamphyri/blah.c");
   move_object(weapon, this_object());
   armor = clone_object("/players/wamphyri/halb.c");
   move_object(armor, this_object()); */
 }
id(str) { return str == "mummy" || str == "an ancient mummy"; }
