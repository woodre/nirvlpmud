inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(1);
  short_desc = "Bedroom";
  long_desc =
"The bedroom you've entered is covered in a light layer of snow.  The\n"+
"snow is stirred by a light breeze blowing through the room.  There\n"+
"doesnt seem to be any visible source of the wind.  In the center of the\n"+
"room is a life sized statue of a powerfully built man.  His eyes appear to\n"+
"be made of intense flame.\n",

dest_dir=
   ({
     "/players/wamphyri/mansion/study", "south",
     "/players/wamphyri/mansion/landing", "east"
     });

items=({
     "snow", "It is only a light layer of snow and looks extremely fresh",
     "room", "It looks like a normal single bedroom except for the snow\n"
     +"covering everything",
     "statue", "The statue seems almost alive.  You can feel the flames from\n"
     +"his eyes from across the room",
     "flames", "His eyes seem to sear right into your soul",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/888h.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/forces.c"),
this_object());
}
