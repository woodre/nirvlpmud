inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   if(arg)
     return ;
set_light(1);
short_desc = "A large wine cellar";
 long_desc =
"As you enter what you could call a wine cellar you are completely\n"+
"baffled.  It looks as if this room has been turned into a makeshift library.\n"+
"Along with the wine racks, you would expect to see in the average wine\n"+
"cellar there is also book shelves.  There must be thousands of books\n"+
"along side the thousands of wine bottles. There are a number of couches\n"+
"and chairs scattered around the room too.  Candles are in abundance in\n"+
"the room, filling the entire room with a murky half light. You dont think\n"+
"it would be possible to read comfortably with this light. It seems obvious\n"+
"that a number of people have been, judging by the books lying open on\n"+
"the chairs and couches. There doesnt seem to be any other exits besides\n"+
"the one you came in by.\n";
dest_dir=
   ({
     "/players/wamphyri/mansion/basement", "west"
   });

items=({
    "wine racks", "There are quite a few wine racks here in the room.  Most\n"
    +"of them appear to be quite normal but in the far back corner you notice\n"
     +"but in the far back corner you notice one that appears a little different.\n"
     +"Maybe if you 'search'ed it you could discover what exactly is\n"
     +"different about it",
    "book shelves", "The shear amount of books in this room stun you.  Your\n"
     +"beginning to wonder where they all came from as you realize there\n"
     +"must be close to a million books here",
    "shelves", "The shear amount of books in this room stun you.  Your\n"
     +"beginning to wonder where they all came from as you realize there\n"
     +"must be close to a million books here",
    "books", "The shear amount of books in this room stun you.  Your\n"
     +"beginning to wonder where they all came from as you realize there\n"
     +"must be close to a million books here",
    "couches", "There is enough furniture here to comfortably fit fifteen\n"
     +"people and it all looks well used",
    "chairs", "There is enough furniture here to comfortably fit fifteen\n"
     +"people and it all looks well used",
    "candles", "Tall and short, fat and skinny there is every imaginable kind\n"
     +"of candle here.  They range in size, shape, color, everything.  And\n"
     +"they are all burning steadily.  The room is filled with a murky kind\n"
     +"of half light by them",
   });

}

init() {
  ::init();
add_action("search", "search");
}
search() {
  write("You move aside the bookshelf and move into the next room.\n");
   this_player()->move_player("into the bookshelf#players/wamphyri/mansion/crypt");
return 1;

move_object(clone_object("/players/wamphyri/mansion/creatures/vampire1.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vampire2.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vampire3.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vampire4.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/5555.c"),
this_object());
}
