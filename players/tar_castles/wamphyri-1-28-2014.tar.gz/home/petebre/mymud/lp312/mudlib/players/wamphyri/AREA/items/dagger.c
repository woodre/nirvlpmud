/* Thanks to Saber for the help with this (from his examples) */
 inherit "obj/weapon.c";
#include "/players/wamphyri/closed/ansi.h"

 reset(arg) {
    ::reset(arg);
    if (arg) return;

    set_name("Deireadh");
      set_alias("tanto");
     set_short("A black tanto");
     set_long("A sharp, black japanese tanto.  You can see what looks like\n"+
           "writing along the blade.\n");
     set_read("This blade is named 'Deireadh'.\n");
    set_class(10);
    set_weight(2);
    set_value(500);
    set_hit_func(this_object());
}

weapon_hit(attacker){

int banana;
banana = random(11);

if(banana > 8)   {

  say("Deireadh "+RED+"slashes"+NORM+" through its foes defenses.\n");

    write("Your foe screams in anger and pain as Deireadh "+RED+"slashes\n"+
          NORM+"into them.\n");

return 5;

    }
    return;
}
