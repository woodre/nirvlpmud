/* Thanks to Saber for help with this */
inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

    set_id("mask");
    set_short("Eagle mask");
     set_long("An ancient mask of a giant eagle.  It was carved\n"+
                "to honor the great spirit of the Eagle.  It is\n"+
                 "an object of power in the hands of a Dreamspeaker.\n");
     set_weight(1);
    set_value(600);
}
