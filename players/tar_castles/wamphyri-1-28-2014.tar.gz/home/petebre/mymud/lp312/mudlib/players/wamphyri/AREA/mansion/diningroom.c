inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
set_light(1);
short_desc = "An old dining room";
long_desc =
"You have entered a large dining room, running the length of the house.\n"+
"An extremely large table takes up the majority of the room. It is large\n"+
"enough to seat approximately twenty people. Only a dark eerie light is let\n"+
"in through the large windows, which cover three of the walls. The light\n"+
"barley permeates the room through grime covered window panes,\n"+
"cracked beyond recognition. This room actually seems to be in working\n"+
"order, if you ignore the windows, with hardly any dust at all.  In fact, on\n"+
"the other side of the room, there are five places set at the table. There are\n"+
"two exists from this room, one is the set of double doors, leading to the\n"+
"foyer, and the other is the single door, leading to the kitchen.\n",

dest_dir=
   ({
     "/players/wamphyri/mansion/foyer", "west",
     "/players/wamphyri/mansion/kitchen", "northwest"
     });

items=({
     "dust", "There doesnt seem to be much of it here",
     "table", "It is a very large exquisite table, with intricately carved legs and\n"
     +"matching chairs.  One end of the table seems to have had recent use is\n"
     +"completely dust free.  The same dust free side also has five places set\n"
     +"for dinner",
     "legs", "These intricately carved legs look like the souls of the dead\n"
     +"flying their way to heaven",
     "windows", "Very large windows which would give an excellent view if\n"
     +"not for the cracks and grime on them",
     "doors", "There are two different doors, one is the set of double doors\n"
     +"leading to the foyer, which seem to be run down, and the other is a\n"
     +"single door leading to the kitchen and seems to have gotten a lot of\n"
     +"recent use",
     "door", "There are two different doors, one is the set of double doors\n"
     +"leading to the foyer, which seem to be run down, and the other is a\n"
     +"single door leading to the kitchen and seems to have gotten a lot of\n"
     +"recent use",

   });

move_object(clone_object("/players/wamphyri/mansion/creatures/food1.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/food2.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/food3.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/food4.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/222.c"),
this_object());
}
