/* Thanks to Saber for this code, and all of his Examples... */
inherit "obj/armor";
#include "/players/wamphyri/closed/ansi.h"

reset(arg){
   ::reset(arg);

     set_name("A small amulet");
    set_short("A small amulet");
   set_alias("amulet");
    set_long("A small, blue amulet.  There is a bright jewel in the center.\n");
    set_ac(1);
    set_type("amulet");
   set_weight(1);
   set_value(200);
}
