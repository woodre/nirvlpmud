/* Thanks to Saber for help with this */
inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

      set_id("ring");
      set_short("A gold ring");
      set_long("It is a finely crafted gold ring.  You see something\n"+
                "enscribed on the inside.\n");
     set_weight(1);
     set_read("To my love Arkady, Jane.\n");
     set_value(800);
}
