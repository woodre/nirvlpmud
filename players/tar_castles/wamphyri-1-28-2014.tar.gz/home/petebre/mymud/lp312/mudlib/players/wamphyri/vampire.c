#include "/players/wamphyri/closed/ansi.h"
reset (arg) { if(arg || root()) return;
find_player("wamphyri")->set_guild_name("vampire");
destruct(this_object());
}
