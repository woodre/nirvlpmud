/* Thanks to Saber for help with this */
inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

     set_id("feather");
       set_short("An Eagle's feather");
        set_long("It is a large feather from the wing of a bald\n"+
              "eagle.  It is valuable in many mystic circles.\n");
     set_weight(1);
     set_value(300);
}
