inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
set_light(1);
short_desc = "Second story landing";
long_desc =
"The second story seems different from the main floor.  The air here seems\n"+
"slightly less oppressive.  It is almost as if youve walked back in time.  A\n"+
"large tapestry covers one wall, while a glass case with a wakizashi in it\n"+
"stands against another.  The room seems to be of an ancient Roman style\n"+
"architecture.  As you explore your strange surroundings you notice four\n"+
"closed doors leading from the room.  You hear strange unidentifiable\n"+
"noises coming from throughout the room.  They seem to be coming from\n"+
"no where and everywhere at the same time.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/foyer", "down",
     "/players/wamphyri/mansion/bathroom", "north",
     "/players/wamphyri/mansion/recroom", "south",
     "/players/wamphyri/mansion/masterbedroom", "east",
     "/players/wamphyri/mansion/bedroom", "west"
     });

items=({
    "glass case", "There is an exquisite wakizashi sitting in it",
    "case", "There is an exquisite wakizashi sitting in it",
    "wakizashi", "A short samurai sword from the second century A.D.",
    "tapestry", "An ancient samurai battle is in progress in front of you on the\n"
    +"large tapestry",
    "room", "Large white marble columns sit in each of the four corners",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/111a.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/time.c"),
this_object());
}
