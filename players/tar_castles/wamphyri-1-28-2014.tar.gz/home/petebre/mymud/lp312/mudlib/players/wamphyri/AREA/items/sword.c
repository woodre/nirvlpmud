/* Thanks to Saber for the help with this (from his examples) */
 inherit "obj/weapon.c";
#include "/players/wamphyri/closed/ansi.h"

 reset(arg) {
    ::reset(arg);
    if (arg) return;

    set_name("Athair Ar Neamh");
    set_alias("sword");
    set_short("An ancient sword");
    set_long("A long blade, perfect in every detail.  There seem to be\n"+
           "words of power inscribed along its length.\n");
     set_read("This sword is named 'Athair Ar Neamh'.\n");
    set_class(15);
    set_weight(2);
    set_value(700);
    set_hit_func(this_object());
}

weapon_hit(attacker){

int banana;
banana = random(11);

if(banana > 8)   {

  say("Athair Ar Neamh "+BLU+"glows"+NORM+" a bright blue as it carves through\n"+
      "its foe.\n");

    write("Your foe screams as Athair Ar Neamh carves a bright "+BLU+"blue\n"+
          NORM+"trail through them.\n");

return 5;

    }
    return;
}
