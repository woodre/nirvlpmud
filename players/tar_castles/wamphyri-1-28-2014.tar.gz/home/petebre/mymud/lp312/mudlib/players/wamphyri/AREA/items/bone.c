/* Thanks to Saber for the help with this (from his examples) */
 inherit "obj/weapon.c";
#include "/players/wamphyri/closed/ansi.h"

 reset(arg) {
    ::reset(arg);
    if (arg) return;

    set_name("Lothlorien");
    set_alias("bone");
     set_short("A large thigh bone");
     set_long("A large thigh bone.  It seems very old, and there seem\n"+
           "to be runes inscribed along its length.\n");
     set_read("This bone is to be called 'Lothlorien'.\n");
    set_class(15);
    set_weight(2);
    set_value(700);
    set_hit_func(this_object());
}

weapon_hit(attacker){

int banana;
banana = random(11);

if(banana > 8)   {

  say("Lothlorien "+GRN+"flashes"+NORM+" brightly as it connects with its foe.\n");

    write("Your foe screams as you mercilessly pound them with\n"+
             "Lothlorien.\n");

return 5;

    }
    return;
}
