inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(0);
  short_desc = "dark room";
  long_desc =
"There seems to be a strange shadow moving throughout the room.  As\n"+
"you move closer to where you last saw it, it seems to dart away to the far\n"+
"side of the room.  The room is so dark that the shadow darting through\n"+
 "the room is all you can make out.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/attic2", "east"
     });

items=({
     "shadow", "It only appears for a second at a time, so you havent been\n"
     +"able to make any of its features out yet",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/110.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/wraith2.c"),
this_object());
}
