inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(1);
  short_desc = "An outside deck";
  long_desc =
"As you step outside onto the wooden deck, you notice that the wood is\n"+
"alive.  It is as if the wood naturally grew into this shape, large branches\n"+
"extend out of the deck to form chairs and a small table.  Life seems to\n"+
"teem here.  A shadowy figure sits on the far side of the table, you can't\n"+
"quite make out any of his features.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/masterbedroom", "north",
     });

items=({
     "table", "It is a small table with four chairs around it.  There is a branch\n"
     +"extending from the center of it forming a canopy of leaves over the\n"
     +"table",
     "chairs", "They are very simple and comfortable looking chairs",
     "canopy", "The canopy of leaves forms a natural umbrella over the table",
     "leaves", "The canopy of leaves forms a natural umbrella over the table",
     "wood", "Everything on the deck seems to be made of the same\n"
     +"continuous living organism",
     "branches", "Everything seems to be made of the living branches of the wood",
     "figure", "He seems to be a natural part of the deck",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/life.c"),
this_object());
}
