inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
set_light(1);
short_desc = "Run-down kitchen";
long_desc =
"You have entered what appears to have once been the kitchen. There is\n"+
"dust and cobwebs everywhere. The room is in a serious state of disrepair\n"+
"and the majority of things in the room are un-repairable. Only three things\n"+
"actually seem to be in working order. There is the refrigerator, a small\n"+
"door to the left of the refrigerator that looks as if it leads down into the\n"+
"basement, and a large sliding glass door that leads out to what looks like\n"+
"a patio. You notice some kind of strange smell and noises coming from\n"+
"the refrigerator.  There is also three other doors in the room, one leading\n"+
"to the living room, one to the foyer, and one to the dining room.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/diningroom", "southeast",
     "/players/wamphyri/mansion/basement", "down",
     "/players/wamphyri/mansion/livingroom", "southwest",
     "/players/wamphyri/mansion/foyer", "south",
     "/players/wamphyri/mansion/patio", "north"
     });

items=({
     "dust", "There is a massive amount of dust covering everything except\n"
     +"the refrigerator",
     "refrigerator", "It is a very large and old refrigerator that seems to have\n"
     +"been used a lot recently.  There is some kind of unnatural smell and\n"
     +"some strange noises coming from inside the refrigerator.  You could\n"
     +"probably open the refrigerator if you wanted to",
     "cobwebs", "There is a massive amount of dust covering everything\n"
     +"except the refrigerator",
     "patio", "It is a nice sized patio that looks as if it is being over run by\n"
     +"the forest",
     "doors", "There are five doors in the room.  The ones leading into the\n"
     +"dining room, the basement, and the sliding door leading to the patio\n"
     +"all seem to have had recent use.  While the one leading to the living\n"
     +"room and the one leading to the foyer dont seem to have been used\n"
     +"in a long time",
     "door", "There are five doors in the room.  The ones leading into the\n"
     +"dining room, the basement, and the sliding door leading to the patio\n"
     +"all seem to have had recent use.  While the one leading to the living\n"
     +"room and the one leading to the foyer dont seem to have been used\n"
     +"in a long time",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/555.c"),
this_object());
}
