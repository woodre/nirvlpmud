/* i'd like to thank Saber for his examples... */
inherit "obj/armor";
#include "/players/wamphyri/closed/ansi.h"

reset(arg){
   ::reset(arg);

    set_name("Lem's Robes");
    set_short("Master Joro's Sash");
    set_alias("sash");
      set_long("It is a white silk sash, made by the revered elder of the\n"+
                "Akashic Brotherhood, Master Joro, in 16th century Kyoto.\n");
   set_ac(4);
   set_weight(3);
    set_value(700);
}
