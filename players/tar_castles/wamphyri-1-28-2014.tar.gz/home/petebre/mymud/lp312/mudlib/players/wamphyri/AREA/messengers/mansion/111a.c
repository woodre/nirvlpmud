inherit "obj/monster";
reset(arg) {
  object weapon, armor;
  if(arg)
    return;
  ::reset(arg);
  set_name("111a");
  set_alias("messenger");
  set_short(0);
  set_long("Im invisible so dont look at me.\n");
  load_chat("You hear sounds of battle.\n");
  load_chat("The low moan of the dying reaches your ears.\n");
  load_chat("You hear the slow whistle of thousands of arrows being\n"
                  +"released.\n");
  load_chat("The sound of blades clashing ring throughout the room.\n"); 
  set_chat_chance(20);
  set_level(20);
  set_hp(1500);
  set_wc(20);
  set_ac(10);
  set_al(0);
  set_gender("male");
}
