inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(1);
  short_desc = "A bathroom";
  long_desc =
"Upon entering the bathroom you immediately reel from the chaotic\n"+
"feeling you get from the surroundings.  Everything in the room looks as\n"+
"if it was dropped as soon as its use was over.  As you stare at the chaotic\n"+
"mess you start to think that maybe it isnt as random as you thought it\n"+
"was.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/landing", "south",
     "/players/wamphyri/mansion/closet", "east"
     });

items=({
     "messenger", "There is no messenger here",
     "777g", "There is 777g no here",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/entropy.c"),
this_object());
}
