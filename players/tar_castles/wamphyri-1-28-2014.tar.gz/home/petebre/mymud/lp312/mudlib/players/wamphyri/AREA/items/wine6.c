/* Thanks to Wizardchild, Saber, and Llew for help with this */
#define sandman this_player()->query_name()
int full,morpheus,death;

id(str) {
   return str == "bottle" || str == "wine";
}

short() { return "A bottle of wine"; }

long() {
   write("It is a black bottle of ancient wine.  It\n"+
     "seems to be full of blood.  The words 'Death Brand'\n"+
    "are written on the side of the bottle.  Perhaps\n"+
    "you could 'drink' the blood to heal yourself.\n");
        }

reset(arg) {
   if(arg)
    return;
  death = 0;
  morpheus = 1;
    }

drink(str) {
   if(str != "blood" && str != "bottle" && str != "wine")
      return 0;
  if(death < 1) {
   if(!call_other(this_player(), "drink_alcohol", 14)) return 0;

  write("The blood burns as it goes down.\n");
   say(sandman+" finishes the bottle off.\n");

  death = death + 1;
  morpheus = morpheus - 1;
  call_other(this_player(), "heal_self", 25);
  return 1;
    }

if(death == 1) {
  write("The bottle is empty.\n");
   return 1;
    }
    }

init() {
  add_action("drink"); add_verb("drink");
   }

query_weight()  { return 1; }
get()    { return 1; }
query_save_flag() { return 1; }
query_value()   { return 500; }
