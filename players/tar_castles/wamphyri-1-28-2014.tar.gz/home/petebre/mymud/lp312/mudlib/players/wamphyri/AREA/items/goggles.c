/* Thanks to Saber for this code, and all of his Examples... */
inherit "obj/armor";
#include "/players/wamphyri/closed/ansi.h"

reset(arg){
   ::reset(arg);

    set_name("Spirit Goggles");
    set_short("A pair of Spirit Goggles");
   set_alias("goggles");
    set_long("These sturdy goggles, allow a mystick to peer into the Umbra.\n");
    set_ac(1);
    set_type("helmet");
   set_weight(1);
   set_value(700);
}
