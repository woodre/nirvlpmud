/* Thanks to Saber for help with this */
inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

    set_id("guitar");
   set_short("A fender stratocaster");
    set_long("It is a well used classic style electric guitar.  On one\n"+
             "end you can see a scrawled autograph from an unknown star.\n");
   set_weight(2);
   set_value(900);
}
