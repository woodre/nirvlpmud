inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   if(arg) return;
   move_object(clone_object("/players/wamphyri/AREA/messengers/mansion/333.c"), this_object());

set_light(1);
short_desc = "The foyer";
long_desc =
"You have entered the foyer of this dark and deserted home.  Dust covers\n"+
"every surface in the current room that you are in.  There is a dark creaky\n"+
"staircase leading up to the second level in front of you.  Next to the\n"+
"staircase is a murky hallway leading north, towards the back of the house.\n"+
"There looks to be a set of old oak double doors leading to the east.  To\n"+
"the west is a large living room, with what looks like, from here, a grand\n"+
"piano sitting in the corner.\n";

dest_dir=
   ({
     "/players/wamphyri/AREA/mansion/kitchen", "north",
     "/players/wamphyri/AREA/mansion/livingroom", "west",
     "/players/wamphyri/AREA/mansion/diningroom", "east",
     "/players/wamphyri/AREA/mansion/landing", "up",
     "/room/eastroad5", "out"
     });

items=({
    "dust", "There is an inch of dark dust covering everything in the room.\n"
    +"But you think you can make out what looks like a carpet under the\n"
    +"dust",
    "carpet", "The carpet has a complex maze like structure sewn into it",
    "staircase", "Leading up to the second floor, you cant quite make out\n"
    +"anything up there.  On the wall next to the staircase you see some\n"
    +"paintings",
    "paintings", "The large paintings depict many different scenes",
    "hallway", "Half way down the hallway is a small table with a book on it",
    "book", "You could probably read the book",
    "doors", "They seem to be run down, but still useable",
    "piano", "It is a large grand piano, that seems to be brand new and may\n"
    +"have even been played recently",
   });
}
