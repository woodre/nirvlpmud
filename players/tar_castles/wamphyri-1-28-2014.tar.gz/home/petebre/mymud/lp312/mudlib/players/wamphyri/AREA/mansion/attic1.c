inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   if(arg) return ;
   move_object(clone_object("/players/wamphyri/AREA/messengers/mansion/101.c"), this_object());

set_light(1);
  short_desc = "a murky room";
  long_desc =
"After coming up the dark staircase into the attic, you start to feel\n"+
"suffocated by the close quarters and the huge amount of dust and\n"+
"cobwebs.  The overpowering smell of rotting wood reaches your nose\n"+
"as you move deeper into the room.\n";

dest_dir=
   ({
     "/players/wamphyri/AREA/mansion/attic2", "south",
     "/players/wamphyri/AREA/mansion/recroom", "down",
     });

items=({
     "staircase", "It leads down to the lit room below",
     "dust", "There is dust everywhere, covering every surface",
     "cobwebs", "The cobwebs are gigantic, covering the entire room",
   });

}
