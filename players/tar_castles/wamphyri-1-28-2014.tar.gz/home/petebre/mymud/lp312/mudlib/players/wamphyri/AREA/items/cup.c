/* Thanks to Wizardchild, Saber, and Llew for help with this */
#define sandman this_player()->query_name()
int full,morpheus,death;

id(str) { return str == "goblet"; }

short() { return "A large goblet"; }

long() {
   write("It is a large goblet, made of black oak.  It\n"+
    "seems to be full of blood.  Perhaps you could\n"+
    "'drink' the blood to heal yourself.\n");
        }

reset(arg) {
   if(arg)
    return;
  death = 0;
  morpheus = 1;
    }

drink(str) {
   if(str != "blood" && str != "goblet")
      return 0;
  if(death < 1) {
   if(!call_other(this_player(), "drink_alcohol", 14)) return 0;

  write("You feel refreashed.\n");
     say(sandman+" drinks the whole goblet in one gulp.\n");

  death = death + 1;
  morpheus = morpheus - 1;
  call_other(this_player(), "heal_self", 25);
  return 1;
    }

if(death == 1) {
  write("The goblet is empty.\n");
   return 1;
    }
    }

init() {
  add_action("drink"); add_verb("drink");
   }

query_weight()  { return 1; }
get()    { return 1; }
query_save_flag() { return 1; }
query_value()   { return 500; }
