/* Thanks to Wizardchild and Llew for their help with this*/
inherit "obj/monster";
#include "/players/wamphyri/closed/ansi.h"

int lightcount;

reset(arg) {
  object banana;
  if(arg)
    return;
  ::reset(arg);
  set_name("Maltet");
  set_alias("Maltet");
  set_short("Maltet");
  set_long("You have finally arrived at the source of the evil in this\n"+
                "mansion.  He stands before you like a fallen angel.  He towers\n"+
                "above you, seemingly filling the entire room.  Shadows dance\n"+
                "about him, it is as if he has cloaked himself in the darkest of\n"+
                "nights.  You feel your soul weaken under his intense gaze.\n");

  load_chat("A black light issues forth from Maltet's eyes enveloping the room.\n");
  load_chat("Maltet asks: Have you come for your death mortal?\n");
  load_chat("A harsh breeze blows through the room.\n");
  set_chat_chance(15);
  load_a_chat("Maltet tears through your chest with his talons.\n");
  load_a_chat("Maltet grips your arm in a death-like grip.\n");
  set_a_chat_chance(20);
  set_spell_mess1("The two combatants exchange furious blows.\n");
  set_spell_mess2("Maltet snaps your bones with hardly any effort.\n");
  set_spell_dam(20+random(25));
  set_chance(8);
  set_level(25);
  set_hp(620+random(620));
  set_wc(30+random(7));
  set_ac(16+random(6));
  set_al(0);
  add_money(3300+random(1000));
  set_race("human");
  set_gender("male");
  banana = clone_object("/players/wamphyri/AREA/items/cloak.c");
  move_object(banana,this_object());
}
id(str) { return str == "maltet" || str == "maltet" || str == "maltet" ; }

stop_fight() {
   if(this_player() && this_player() != this_object()) {
      lightcount=1;
      attacker_ob=alt_attacker_ob;
      alt_attacker_ob=0;
   }   
   if(!attacker_ob->query_interactive() && !attacker_ob->query_npc()) {
      attacker_ob = alt_attacker_ob;
      alt_attacker_ob = 0;
   }
}

ht() {
   ::heart_beat();
   if(!random(8)) boom();
   if(lightcount) {
      if(lightcount==4) {
         lightning(lowest_player());
         lightcount=0;
      }
      else lightcount++;
   }
}

init() {
   ::init();
    if(environment()) attack_object(lowest_player());
}

lowest_player() {
   object roominv;
   object target;
   int x;
   roominv=all_inventory(environment());
   for(x=0;x<sizeof(roominv);x++) {
      if(roominv[x] != this_object()) {
         if(!target) roominv[x] = target;
         else {
            if(roominv[x]->query_mhp() < target->query_mhp()) roominv[x]=target;
         }
      }
   }
   if(target) return target;
}

lightning(target) {
   if(target) {
      attack_object(target);
      say("You hear a loud crack as Maltet breaks "+target->query_name()+"'s back.",target);
      tell_object(target,"You feel intense pain as Maltet snaps your back in two.");
      target->hit_player(50);
   }
}

boom() {
   object all_attackers, ai;
   int x;
   for(x=0,ai=all_inventory(environment());x<sizeof(ai);x++)  {
      if(ai[x]->query_attack() == this_object()) {
         all_attackers+=ai[x];
      }
   }
   tell_room(environment(),"Room message");
   for(x=0;x<sizeof(all_attackers);x++) {
      if(objectp(all_attackers[x])) {
         all_attackers[x]->hit_player(32);
         tell_object(all_attackers[x],"Message to guy getting hit");
         say("Message to all others",all_attackers[x]);
      }
   }
}
