inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   if(arg)
     return ;
  set_light(1);
  short_desc = "a dark crypt";
  long_desc =
"Youve entered an extremely dark crypt, with only a few scattered candles\n"+
"giving any illumination at all.  Deep shadows cover the enormous room.\n"+
"cant be sure but you think the crypt takes up one entire side of the house.\n"+
"You can make out shadowy figures moving around the fringes of the light,\n"+
"never coming close enough for you to make out any features.  As you move\n"+
"deeper into the room, you find beds, coffins, and mats along the walls.  In\n"+
"the far south of the crypt you see what looks like two giant stone gargoyles.\n";
dest_dir=
   ({
     "/players/wamphyri/mansion/evil", "south",
     "/players/wamphyri/mansion/winecellar", "east"
});

items=({
     "gargoyles", "The large ornate gargoyles look very realistic.  Between them you see what \n "
     +"looks like a doorway leading south.",
     "candles", "The only light in the crypt comes from the very few candles scattered around \n"
     +"the room high in the wall.",
     "shadows", "The shadows seem to bulge and move towards you.",
     "figures", "For some reason you seem to feel menaced by these shadowy figures.",
     "coffins", "All of them look as if they are well used.",
     "beds", "All of them look as if they are well used.",
     "mats", "All of them look as if they are well used.",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/vamp1.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vamp2.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vamp3.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vamp4.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vamp5.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/vamp6.c"),
this_object());
}

init() {
  ::init();
  add_action("check_south","south",1);
}
check_south() {

  if(present("oxychilus")) {
    write("A figure steps from the shadows and blocks your path.\n");
    return 1;
  } else
    return 0;
}
