inherit "obj/monster";
reset(arg) {
  object weapon, armor;
  if(arg)
    return;
  ::reset(arg);
  set_name("666");
   set_alias("messenger");
  set_short(0);
  set_long("Dont look its evil.\n");
  load_chat("Lightning crashes.\n");
  set_chat_chance(30);
  set_level(20);
  set_hp(1500);
  set_wc(20);
  set_ac(10);
  set_al(0);
  set_gender("male");
}
