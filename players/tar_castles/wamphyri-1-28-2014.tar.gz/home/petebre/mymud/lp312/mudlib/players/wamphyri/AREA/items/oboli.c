/* Thanks to Saber for help with this */
inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

    set_id("oboli");
   set_short("A few oboli");
    set_long("Oboli are the deathcoins forged in the city of Stygia.\n");
    set_weight(1);
    set_value(250);
}
