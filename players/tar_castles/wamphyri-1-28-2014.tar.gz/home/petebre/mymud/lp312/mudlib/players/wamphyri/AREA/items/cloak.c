/* thanks to Llew for his help... */
inherit "obj/armor";
 
reset(arg){
   ::reset(arg);
    set_light(-3);
    set_name("Cloak");
    set_short("Cloak");
    set_alias("cloak");
    set_long("The cloak\n"+
                   "of his size.  top to bottom in dark blood red\n"+
                   "runes.  The hing, you might be able to read them.\n");
    set_ac(2);
    set_type("misc");
    set_save_flag(1);
    set_weight(3);
    set_value(2500);
}
init() {
  ::init();
  add_action("read_cloak","read");
}
read_cloak(str) {
  if(!id(str)) return 0;
  write("The cloak says twinkies can be hazardous to your health.\n");
  return 1;
}
