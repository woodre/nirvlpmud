reset () {
int i;
i = find_player("wamphyri")->set_attrib("str", 90);
if (i) write(i+"\n");
destruct(this_object());
}
