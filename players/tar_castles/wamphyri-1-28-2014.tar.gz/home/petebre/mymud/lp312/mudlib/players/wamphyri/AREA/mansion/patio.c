inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
set_light(1);
short_desc = "A patio";
long_desc =
"You are now at the back of the house on the patio. High above you is the\n"+
"moon and the night sky. The forest which surrounds the entire back of\n"+
"the house and continues out much further, is slowly creeping across the\n"+
"patio towards the house itself.  Through the tree tops the wind is blowing\n"+
"quite strongly and some unidentifiable odor is being brought to your nose\n"+
"from the forest. Most of the patio furniture out here has been destroyed\n"+
"by what you assume is wild animals. A lonely sounding howl comes from\n"+
"deep within the forest reverberating in your ears until that is all you can\n"+
"hear.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/kitchen", "south",
     "/players/wamphyri/mansion/forest/trail", "enter"
     });

items=({
     "patio", "Your basic backyard concrete patio, except this one is slowly\n"
     +"being absorbed into the wilderness",
     "furniture", "All the furniture here on the patio looks as if it was\n"
     +"shredded into pieces by some wild animal",
     "forest", "It looks to be a wild and dangerous place.  It is slowly\n"
     +"encroaching upon the house as if it wants to reclaim the land\n"
     +"the house rests upon.  You could probably enter the forest\n"
     +"if you dared to discover what is making the howling noises",
     "moon", "High above you in the center of the sky sits the fullest\n"
     +"moon you have ever seen",
     "night", "It is a dark fearsome night out.  A storm seems to be\n"
     +"building on the horizon",
     "storm", "A giant lightning and wind storm seems to be\n"
     +"headed right this way",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/666.c"),
this_object());
}
