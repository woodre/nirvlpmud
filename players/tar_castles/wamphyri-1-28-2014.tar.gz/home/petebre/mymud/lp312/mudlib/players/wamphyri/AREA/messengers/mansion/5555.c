inherit "obj/monster";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  object weapon, armor;
  if(arg)
    return;
  ::reset(arg);
  set_name("666");
   set_alias("messenger");
  set_short(0);
  set_long(GRN+"...\n"+NORM);
   load_chat("You hear some talking behind one of the wine racks.\n");
   set_chat_chance(15);
  set_level(1);
  set_hp(1500);
  set_wc(20);
  set_ac(10);
  set_al(0);
  set_gender("male");
}
