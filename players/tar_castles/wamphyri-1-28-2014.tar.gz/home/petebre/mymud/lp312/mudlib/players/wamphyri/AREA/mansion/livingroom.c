inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
   if(arg) return;
   move_object(clone_object("/players/wamphyri/AREA/messengers/mansion/444.c"), this_object());
   move_object(clone_object("/players/wamphyri/AREA/creatures/mansion/coffin.c"), this_object());

set_light(1);
short_desc = "Livingroom";
long_desc =
"This room is quite huge, and bends around the corner taking up this wing\n"+
"of the house.  A very large grand piano looms in one corner of the room.\n"+
"Dust and cobwebs seem to be everywhere, another unused room in this\n"+
"once beautiful house.  There is a dilapidated couch and a set of chairs\n"+
"surrounding a small glass coffee table which has also seen better days.\n"+
"The windows along the wall are all painted over with black paint and do\n"+
"not allow in any light.  Near the back of the room is a door leading into\n"+
"the kitchen and a good sized table.  It looks as if informal meals were\n"+
"once held here at this table, but know it is in an advanced state of\n"+
"disrepair.  A large fireplace attracts your eye to the center of one wall.\n"+
"A nice sized fire is steadily buring away.  It looks as if this fire was\n"+
"only recently lit.  Through the open doorway you can see into the foyer and\n"+
"the front door, this is the only other exit from the room besides the door\n"+
"leading into the kitchen.\n";

dest_dir=
   ({
     "/players/wamphyri/AREA/mansion/kitchen", "northeast",
     "/players/wamphyri/AREA/mansion/foyer", "east",
     });

items=({
     "dust", "The dust is in evidence here, everywhere except on the piano.\n"
     +"With the many corners and with the large size, the cobwebs have\n"
     +"gotten quite large",
     "couch", "All the furniture in this room has not been used in years and\n"
     +"isnt in any condition to be actually used in their rightful manner",
     "cobwebs", "The dust is in evidence here, everywhere except on the\n"
     +"piano.  With the many corners and with the large size, the cobwebs\n"
     +"have gotten quite large",
     "chairs", "All the furniture in this room has not been used in years and\n"
     +"isnt in any condition to be actually used in their rightful manner",
     "table", "All the furniture in this room has not been used in years and\n"
     +"isnt in any condition to be actually used in their rightful manner",
     "fireplace", "It is a very old, wood burning fireplace and there are\n"
     +"several large logs in it now burning away",
     "windows", "The windows look as if they have been painted over\n"
     +"with black paint recently.  Someone or something must not want\n"
     +"any light in this room",
     "piano", "It is a very large beautiful grand piano, which is strangely\n"
     +"clear of dust.  The top is closed and you could easily lift it if you\n"
     +"wanted to",
     "paint", "The windows look as if they have been painted over with\n"
     +"black paint recently.  Someone or something must not want any\n"
     +"light in this room",
     "doors", "There is only one door in this room, near the back.  It lnd looks as if it has been in use recently",
   });
}
