#include "/players/wamphyri/closed/ansi.h"
#include "std.h"
#define NAME "wamphyri"
 int shield;
init() {
  add_action("on"); add_verb("on");
  add_action("post"); add_verb("post");
  add_action("off"); add_verb("off");
  add_action("church"); add_verb("church");
  add_action("west"); add_verb("west");
  add_action("east"); add_verb("east");
  set_light( 1);
  if(this_player()->query_real_name() != NAME && shield == 1) {
  write("You are engulfed by a dark mist and carried away.\n");
  this_player()->move_player("off the shields#room/church");
  }
 }
static on() {
   shield = 1;
   write("mist activated.\n");
   return 1;
   }
static off() {
   if (call_other(this_player(), "query_real_name", 0) != NAME) {
  write("You are not allowed to do that!!!!!!!\n");
    return 1;
    }
   shield = 0;
   write("mist deactivated.\n");
   return 1;
   }

short () {
     return "a dark "+RED+"crypt"+GRN+"..."+NORM;
  }
 long() {
 write("mist is at " + shield + "\n");
 write(""+
           "You have entered a dark ancient crypt. In the center of the room\n"+
           "are a pair of lavishly decorated stone sarcophagi. They seem to\n"+
           "be made of fine, black marble and are heavier and more rounded\n"+
           "than traditional coffins. All in all, giving the room a look\n"+
           "that reminds you of a mausoleum. Runes have been inlaid with\n"+
           "silver across their surfaces. A covered iron lamp hangs from the\n"+
           "ceiling on a fairly thick chain. Like a stilled pendulum it\n"+
           "dangles over the center of the room. Near one of the sarcophagi\n"+
           "stands an elegantly carved, soft bed crafted of a strange black\n"+
           "metal and white ivory.\n");
  }
west() {
  call_other(this_player(), "move_player", "west#room/adv_inner.c");
  return 1;
  }
 church() {
   object mobj;
 move_object(this_player(), "room/church");
   return 1;
  }
post(){
  object mobj;
move_object(this_player(), "room/post");
   return 1;
  }
east()  {
  object mobj;
move_object(this_player(), "players/nooneelse/black/guild_lower_hall");
   return 1;
  }
