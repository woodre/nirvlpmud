/* Thanks to Saber for help with this */
inherit "obj/treasure";

reset(arg)  {
  if(arg) return;

    set_id("Kitab al Alacir");
   set_short("the Kitab al Alacir");
     set_long("A copy of the Kitab al Alacir.  It is a treatise which\n"+
              "contains two parts: the first tells that everything is\n"+
              "made up of a single Essence called Ether.  The second\n"+
               "part contains an ontological discussion of reality\n"+
               "and discusses how this single Essence was\n"+
               "differentiated throughout creation.\n");
    set_weight(1);
   set_value(200);
}
id(str) { return str == "treatise" || str == "Kitab al Alacir" || str == "kitab al alacir" ; }
