inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(1);
  short_desc = "A large walk-in closet";
  long_desc =
"Light spills in through a large skylight set in the ceiling.  There are\n"+
"hundreds of different types of clothes hanging in this closet.  They\n"+
"all seem to be shifting in shape, style, color, and material right before\n"+
"your eyes.  Objects appear and disappear randomly throughout the room.\n"+
"Its as if the items are made out of nothing and then return to the same.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/masterbedroom", "south",
     "/players/wamphyri/mansion/bathroom", "west"
     });

items=({
     "skylight", "It is a very large skylight and it seems to draw in more light\n"
     +"than a normal skylight would",
     "clothes", "You cant even begin to guess how many clothes there are in here",
     "objects", "Every type of object appears all throughout the room.  They\n"
     +"appear and disappear so fast you dont have time to get any of them",
  });

move_object(clone_object("/players/wamphyri/mansion/creatures/matter.c"),
this_object());
}
