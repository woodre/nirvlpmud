inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
set_light(1);
short_desc = "Workshop";
long_desc =
"You have entered what appears to be the dark laboratory of a mad\n"+
"scientist.  There is a huge work bench covering half of one side of the\n"+
"room.  There is cauldrons and glass beakers all over the bench top.\n"+
"Strange bubbling liquids travel from beaker to beaker through a huge\n"+
"network of tubes.  Along the walls are dusty shelves with all kinds of jars\n"+
"and specimens.  A giant operating table sits on the floor.  Strapped to the\n"+
"top of it is large humanoid shaped being.  There doesnt seem to be any\n"+
"one or anything else in the room.\n";

dest_dir=
   ({
     "/players/wamphyri/mansion/basement", "north"
     });

items=({
    "bench", "The large bench covers the far wall and is covered in beakers\n"
    +"and tubes",
    "cauldrons", "Something seems to be brewing inside its murky depths",
    "liquids", "They are of all different colors and intensities ",
     "jars", "The jars house what looks like failed experiments and dead\n"
    +"specimens",
    "specimens", "The specimens look like they were used in past\n"
    +"experiments and have been discarded",
    "operating table", "The large creature strapped to the table seems to\n"
    +"be groaning and moving slightly",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/mad.c"),
this_object());
move_object(clone_object("/players/wamphyri/mansion/creatures/7777.c"),
this_object());
}
