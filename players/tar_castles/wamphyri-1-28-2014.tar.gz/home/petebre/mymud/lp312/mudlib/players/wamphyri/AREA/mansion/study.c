inherit "room/room";
#include "/players/wamphyri/closed/ansi.h"
reset(arg) {
  if(arg)
     return ;
  set_light(1);
  short_desc = "The study";
  long_desc =
"The study is dimly lit by a small table lamp on the large desk.  A huge\n"+
"collection of books line the walls.  Out of the corner of your eye you\n"+
"notice someone sitting behind the desk.  As you turn to see who it is\n"+
"there doesnt seem to be anyone there any more.  You could have sworn\n"+
"there was someone there a second ago though.\n",

dest_dir=
   ({
     "/players/wamphyri/mansion/bedroom", "north",
     "/players/wamphyri/mansion/recroom", "east"
     });

items=({
     "books", "Many of the books have to do with the mind",
     "lamp", "The lamp lights only a small circle in the center of the desk",
     "desk", "You cant make out anything on the desk at all",
   });

move_object(clone_object("/players/wamphyri/mansion/creatures/mind.c"),
this_object());
}
