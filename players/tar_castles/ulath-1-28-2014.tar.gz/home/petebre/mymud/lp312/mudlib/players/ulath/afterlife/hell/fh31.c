#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The wailing of the souls seems to lessen here in the outer "+
      "corner of this realm. The angry skies and the lifeless "+
      "dust bring memory back of where this is though, and destroys any though "+
      "of peace or harmony.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh32.c","south",
      "/players/ulath/afterlife/hell/fh41.c","east",
   });
}

realm() { return "NT"; }

