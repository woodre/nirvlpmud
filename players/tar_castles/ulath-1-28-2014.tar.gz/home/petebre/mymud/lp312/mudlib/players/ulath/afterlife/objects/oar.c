#include "/players/ulath/closed/ansi.h"
inherit "/obj/weapon";

reset(arg) {
   ::reset(arg);
   if(arg) return;

   set_name("The Pole of Charon");
   set_alias("pole");
   set_alt_name("oar");
   set_long("This is the pole Charon uses to pole across the River\n"+
            "Acheron. He also uses it to swat at souls who won't get\n"+
            "on the raft.\n");
   set_class(18);
   set_weight(4);
   set_value(2500);
   set_hit_func(this_object());

}

weapon_hit(attacker) {
   if(!random(7)) {
   tell_object(attacker,
               HIY+"          W H A M ! !"+NORM+"\n"+
               wielded_by->query_real_name()+" smacks you with their oar.\n");
   tell_object(wielded_by,
               HIY+"          W H A M ! !"+NORM+"\n"+
               "You smack "+attacker->query_real_name()+" with your oar.\n");
   say(        HIY+"          W H A M ! !"+NORM+"\n"+
               wielded_by->query_real_name()+" smacks "+attacker->query_real_name()+" with their oar.\n",attacker);
   attacker->hit_player(7+random(6));
   }
}
