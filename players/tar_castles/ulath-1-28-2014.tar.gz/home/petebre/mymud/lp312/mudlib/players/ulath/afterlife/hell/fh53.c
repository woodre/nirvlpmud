#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   A small, path is visible here, slowly climbing the plateau, although "+
      "it is not accessible from here. The dismal plain continues to the east, but "+
      "far off in the distance a river can be seen. Off to the south, the plains end "+
      "in an abrupt cliff edge.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh50.c","north",
      "/players/ulath/afterlife/hell/fh54.c","south",
      "/players/ulath/afterlife/hell/fh63.c","east",
    });
}

realm() { return "NT"; }

