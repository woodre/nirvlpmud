#include "/players/ulath/closed/ansi.h"

inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=BOLD+"The Heavenly Boulevard"+NORM;
   long_desc=
      "  Marble pillars line the entryway to the huge mansions on either "+
      "side of the golden street. Huge, mahogany doors open up welcoming "+
      "the deserving souls into their eternal reward.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/heaven/h43.c","north",
      "/players/ulath/afterlife/heaven/h41.c","south",
   });
}
realm() { return "NT"; }
