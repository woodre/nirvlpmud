#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   A small track winds its way between the plateau face and the cliff "+
      "that rings the realm. It looks treacherous, but passable. The plains "+
      "continue on the other side.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh31.c","west",
      "/players/ulath/afterlife/hell/fh51.c","east",
   });
}

realm() { return "NT"; }

