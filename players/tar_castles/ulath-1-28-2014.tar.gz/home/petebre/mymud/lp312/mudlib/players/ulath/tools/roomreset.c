inherit "obj/treasure";

reset(arg) {
  if(arg)return;
  set_id("reseter");
  set_short("Room fixer");
  set_long("A room reseter.  If you'd like to update the room you're in type\n"+
    "res here (arg).  Arg being either 0 or 1 as needed.\n"+
    "If another room type  res (path) (arg).  Path is file name of the room,\n"+
    "arg same as above, or type res (player) (arg) to update a room with that\n"+
    "player in it.  Be careful with using 0 as arg as it will dest some\n"+
   "objects and send players to the void.\n");
  set_weight(1);
  set_value(0);
}

init() {
  ::init();
  add_action("res","res");
}

res(str) {
  string where;
  int num;
  if(!str || sscanf(str,"%s %d",where,num) != 2 || this_player()->query_level() < 20) return 0;
  if(where == "here") {
    environment(this_player())->reset(num);
    write("Environment reset to "+num+".\n");
    return 1;
  }
  if(find_player(where)) {
    tell_object(find_player(where),"The rooms you're in has been reset by "+this_player()->query_name()+".\n");
    environment(find_player(where))->reset(num);
    write("The environment of "+capitalize(where)+" has been reset to "+num+".\n");
    return 1;
  }
  if(find_object(where)) {
    find_object(where)->reset(num);
    write("The room, "+where+", has been reset to "+num+".\n");
    return 1;
  }
  write("Where would you like to update?\n");
  return 1;
}
