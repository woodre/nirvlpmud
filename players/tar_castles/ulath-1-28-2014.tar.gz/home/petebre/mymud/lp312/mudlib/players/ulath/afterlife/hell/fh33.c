#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The dark, lifeless plain halts in a steep cliff that rings the "+
      "center of this realm.  Dark angry clouds swirl around the top, obsuring "+
      "the plateau's top from view. The resounding cries of the tormented continue "+
      "unabated.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh30.c","north",
      "/players/ulath/afterlife/hell/fh34.c","south",
      "/players/ulath/afterlife/hell/fh23.c","west",
   });
}

realm() { return "NT"; }

