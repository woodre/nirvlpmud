#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The shrouded heights of the cliff start to curve around to the east. "+
      "The roiling clouds rush in and swirl around the top of the plateau. The "+
      "lifeless plains continue in all other directions.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh31.c","north",
      "/players/ulath/afterlife/hell/fh30.c","south",
      "/players/ulath/afterlife/hell/fh22.c","west",
   });
}

realm() { return "NT"; }

