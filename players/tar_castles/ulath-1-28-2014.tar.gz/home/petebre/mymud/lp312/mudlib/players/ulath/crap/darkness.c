#include "/players/llew/closed/ansi.h"
#define NQC room

inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=BOLD+BLK+"Darkness"+NORM;
   long_desc=
      "   Darkness. Its shroud envelops the entire area, it grasps\n"+
      "at the lowest reaches of the Soul, triggering Man's primal\n"+
      "fear of all things that exist in its Domain. Foul creatures\n"+
      "and horrific deeds come to the forefront of Thought, and \n"+
      "instincts of survival are triggered.\n"+
      "   Darkness is the last remnant of the void before Creation took\n"+
      "form and order. The chaos of this period held only uncomprehending\n"+
      "darkness of the borderless void, and the creatures that now are\n"+
      "forced to hide from the searing Light. This Light, the first act\n"+
      "of Creation, drove back the Darkness, causing the creatures to\n"+
      "retreat to caverns, forests, and other shadowy areas. For this\n"+
      "reason, these creatures despise all things that exist in the Light\n"+
      "and all should be wary that cross into the realm of Darkness.\n"+ 
      "   A spark, a tiny Light, burns just on the edges of vision.\n"+
      "Attempts to trace its source prove futile, as though something\n"+
      "was teasing or taunting. The small bit of Hope is gone as the\n"+
      "Light fades to Shadow. The encompassing Darkness pushes down like\n"+
      "a heavy weight, threatening to crush the Soul and the Mind, like an\n"+
      "egg trapped in a vice. As all resistance is exstinguished, you\n"+
      "are forced to go down...\n";
   dest_dir=({
      "/players/ulath/darkness/darkness2.c","down",  
      "/players/ulath/workroom.c","out",
   });
}

realm() { return "NT"; }

