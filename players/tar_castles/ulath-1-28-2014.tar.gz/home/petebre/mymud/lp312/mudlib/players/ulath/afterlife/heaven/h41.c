#include "/players/ulath/closed/ansi.h"

inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=BOLD+"The Heavenly Boulevard"+NORM;
   long_desc=
      "Large, majestic palaces line either side of the broad street "+
      "that travels into Heaven. To the south the wide gates of Heaven "+
      "stand open and willing to let people come and go as they please. "+
      "Off in the distance a large staircase can be seen rising up into "+
      "the sky.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/heaven/h42.c","north",
      "/players/ulath/afterlife/heaven_gate.c","south",
   });
}
realm() { return "NT"; }
