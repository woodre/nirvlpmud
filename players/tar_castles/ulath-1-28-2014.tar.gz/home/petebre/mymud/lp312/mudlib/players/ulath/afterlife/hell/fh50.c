#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c"; 

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   A steep, dusty trail switches back scaling the heights of the plateau, "+
      "disappearing into the clouds.  The barren plains continue in all other directions. "+
      "A mist descends out of the thick clouds swirling around the top of the plateau "+
      "although the air is still and dry.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh52.c","north",
      "/players/ulath/afterlife/hell/fh53.c","south",
      "/players/ulath/afterlife/hell/fh60.c","east",
      "/players/ulath/afterlife/hell/fh40.c","west",
    });
}

realm() { return "NT"; }

