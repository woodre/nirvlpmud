#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room";
int exit;

reset(arg) {
   object ob;
   int i;
   if(arg) return;
   ob = clone_object("/players/ulath/afterlife/monsters/death.c");
   i = transfer(ob, "/players/ulath/afterlife/throne.c");
   set_light(1);
   short_desc="A "+BOLD+BLK+"Haunted"+NORM+" Crypt";
   long_desc=
      "   This crypt is dark and deathly quiet. Nothing stirs, "+
      "not even the air . The smells of dust and decay permeate "+
      "the atmosphere. Footsteps of those whom have come before, "+
      "litter the floor, but none are fresh. At the back of the room "+
      "on a large, raised dias is an ornate throne. Tapestries decorate "+
      "the walls to the left and right of the throne.  On the left are "+
      "dark, horrifying scenes of death and torture. On the right are "+
      "bright vivid scenes of happiness and bliss. ";
   long_desc=format(long_desc,65);
}

init() {
   ::init();
   add_action("east","east");
}

realm() { return "NT"; }

new_exit() {
   if(present("dead_death_ob")) {
      dest_dir=({
         "/players/ulath/purgatory.c" , "east"
      });
   exit = 1;
   return 1;
   }
}

east() {
   if(exit) {
      this_player()->move_player("east#players/ulath/afterlife/purgatory");
      return 1;
   }
}
