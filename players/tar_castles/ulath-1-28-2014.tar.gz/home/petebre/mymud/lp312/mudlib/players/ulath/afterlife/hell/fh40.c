#include "/players/ulath/closed/ansi.h"
#define NQC room
inherit "room/room.c";

reset(arg) {
   object ob;
   int i,x,y;
   if(arg) return;
   set_light(1);
   x = (random(3) + 2);
   for(y = 0;y <= x;y++) { 
      ob = clone_object("/players/ulath/afterlife/monsters/angel.c");
      i = transfer(ob, "/players/ulath/afterlife/hell/fh40.c");
   }
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
     "   A giant rock spire towers above the path here. No wind blows across "+
     "the top of this plateau, and the wailing is diminished at this height. "+
     "The Angels that come here are forced to prostrate themselves "+
     "before it.  Choosing neither side, neither rebellious to God nor faithful "+
     "to Him, they bow down before this trivial idol.";
   long_desc=format(long_desc,65);
   items=({
      "spire" , "A monolith of unworked stone" ,
   });
   dest_dir=({
      "/players/ulath/afterlife/hell/fh50.c" , "east",  
   });
}

realm() { return "NT"; }


