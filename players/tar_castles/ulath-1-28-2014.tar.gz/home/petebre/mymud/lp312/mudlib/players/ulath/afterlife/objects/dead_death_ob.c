inherit "obj/treasure";

reset(arg) {
   if(arg)return;
   set_id("dead_death_ob");
}
