#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   A steep cliff face climbs into the clouds, blocking the way. The clouds swirl "+
      "around the top obscuring the view. The dusty plains extend in all "+
      "other directions. The terrible shrieks rebound off the sheer cliff, magnifying "+
      "the sound till it is deafening.";
   long_desc=format(long_desc,65); 
   dest_dir=({
      "/players/ulath/afterlife/hell/fh32.c","north",
      "/players/ulath/afterlife/hell/fh33.c","south",
      "/players/ulath/afterlife/hell/fh20.c","west",
   });
}

realm() { return "NT"; }

