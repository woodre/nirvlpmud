#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The violent skies roil about the cliffs rising into the skies. "+
      "A small path winds its way up the cliffs, although there is no access "+
      "to it from here.  The chorus of wretched souls, echoes off the cliffs "+
      "amplifying the sound many times over, to a deafening volume.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh51.c","north",
      "/players/ulath/afterlife/hell/fh50.c","south",
      "/players/ulath/afterlife/hell/fh62.c","east",
    });
}

realm() { return "NT"; }

