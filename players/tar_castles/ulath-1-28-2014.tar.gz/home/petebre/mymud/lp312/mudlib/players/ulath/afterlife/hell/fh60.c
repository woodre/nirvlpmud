#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c";

reset(arg) {
   object ob;
   int i;
   if(arg) return;
   ob = clone_object("/players/ulath/afterlife/monsters/lost_soul");
   move_object(ob,this_object());
   ob->be_a_leader(0,random(4)+1);
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   A river can be seen to the east, black and slowly making its way to "+
      "its desolute destination. The flat terrain stretches west to a steep plateau, "+
      "and north or south it ends in lofty cliffs.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh62.c","north",
      "/players/ulath/afterlife/hell/fh63.c","south",
      "/players/ulath/afterlife/hell/fh50.c","west",
      "/players/ulath/afterlife/hell/fh70.c","east",
   });
}

realm() { return "NT"; }

