#include "/players/llew/closed/ansi.h"
inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if(arg) return;

   set_name("The Great Refuser");
   set_alt_name("refuser");
   set_level(17);
   set_long("This decrepit shade stands in abject silence.\n"+
            "Hunched over by the weight of his lack of commitment, \n"+
            "you long to hurry away from this wretched being. He wears\n"+
            "garmets of the Clergy, and you think he is the Pope Celestine\n"+
            "V, who abdicated in 1294 only five months into his papacy, \n"+
            "when political pressure proved too much for him. His cowardice\n"+  
            "sickens you.\n");
   set_race("shade");
   set_wc(20);
   set_ac(17);
   set_hp(400+random(75));
   set_al(0);
}
