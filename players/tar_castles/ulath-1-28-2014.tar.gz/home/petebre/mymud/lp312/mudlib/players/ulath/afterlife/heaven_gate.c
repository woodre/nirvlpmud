#include "/players/ulath/closed/ansi.h"

inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=BOLD+"The Gate to Heaven"+NORM;
   long_desc=
   " The majestic Gate to Heaven looms high overhead. Covered in gold "+
   "and gems it is a beatiful work of superb craftsmanship. A wide road "+
   "paved in gold heads into the capitol of the forces of Light.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/heaven/h41.c","north",
   });
}
realm() { return "NT"; }
 
