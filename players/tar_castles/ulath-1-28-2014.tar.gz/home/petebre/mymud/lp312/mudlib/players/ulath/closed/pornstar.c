#include <ansi.h>
inherit "/obj/treasure";

string pronoun;
string myname;

short() { return "Porn Star"; }

long() { 
   write("A large, star made of sequins and glitter.\n"+
         "Type 'pstar' for a list of commands.\n");  
}

id(str) { return str == "pstar"; }

init() {
   add_action("pstar" , "pstar");
   add_action("remove" , "remove");
   add_action("dress" , "dress");
   add_action("fsuck" , "fsuck");
   add_action("nibble" , "nibble");
   add_action("tease" , "tease");
}

pstar() {
   write("remove <who> <what>\n"+
         "dress\n"+
         "fsuck <who>\n"+
         "nibble <who> <where>\n");
   return 1;
}

remove(str) {
   string who, what;
   object plyr;
   myname = capitalize(this_player()->query_real_name());
   if(!str) {
      write("Remove what? 'shirt, pants, bra, boxers, panties' \n");
      return 1;
   }
   if(sscanf(str,"%s %s",who,what) != 2) {
      write("Remove <who>'s <what>.\n");
      return 1;
   }
   if(!present(who,environment(this_player()))) {
      write("You can't remove clothing from afar!\n");
      return 1;
   }
   plyr = find_living(who);
   get_gender();
   switch(what) {
   case "shirt":	remove_shirt(who,plyr); break;
   case "pants":	remove_pants(who,plyr); break;
   case "bra":		remove_bra(who,plyr); break;
   case "panties":	remove_panties(who,plyr); break;
   case "boxers":	remove_boxers(who,plyr); break;
   default:		write("Remove what? 'shirt, pants, bra' \n");
   }
   return 1;
}   

dress() {
   get_gender();
   myname = capitalize(this_player()->query_real_name());
   write("You quickly locate all your clothing and get dressed.\n");
   say(myname+" quickly locates all "+pronoun+" clothing and gets dressed.\n");
   destruct(present(this_player()->query_real_name()+" shirt", environment(this_player())));
   destruct(present(this_player()->query_real_name()+" pants", environment(this_player())));
   destruct(present(this_player()->query_real_name()+" bra", environment(this_player())));
   destruct(present(this_player()->query_real_name()+" boxers", environment(this_player())));
   destruct(present(this_player()->query_real_name()+" panties", environment(this_player())));
   return 1;
}

fsuck(str) {
   object plyr;
   if(!str) {
      write("Suck who's finger?\n");
      return 1;
   }
   plyr = find_living(str);
   myname = capitalize(this_player()->query_real_name());
   get_gender();
   if(!present(str,environment(this_player()))) {
      write("That player must be present!\n");
      return 1;
   }
   if(plyr == this_player()) {
      write("Its really not as fun by yourself.\n");
      return 1;
   }
   write("You gently take "+capitalize(str)+"'s finger, slide it into your mouth, and begin to suck on it.\n");	 
   tell_object(plyr, myname+" gently takes your finger, slides it into "+pronoun+" mouth, and begins to suck on it.\n");
   say(myname+" gently takes "+capitalize(str)+"'s finger, slides into "+pronoun+" mouth, and begins to suck on it.\n", plyr);
   return 1;
}

nibble(str) {
   string who, what;   
   object plyr;
   if(!str) {
      write("Usage 'nibble <who> <where>'\n");
      return 1;
   }
   if(sscanf(str,"%s %s",who,what) != 2) {
      write("Usage 'nibble <who> <where>'\n");
      return 1;
   }
   if(!present(who,environment(this_player()))) {
      write("That person must be present!\n");
      return 1;
   }
   plyr = find_living(who);
   if(plyr == this_player()) {
      write("Its really not as fun by yourself.\n");
      return 1;
   }
   myname = capitalize(this_player()->query_real_name());
   write("You lightly nibble "+capitalize(who)+" on the "+what+".\n");
   tell_object(plyr, myname+" lightly nibbles on your "+what+".\n");
   say(myname+" lightly nibbles "+capitalize(who)+" on the "+what+".\n", plyr);
   return 1;
}

tease(str) {
   string who, what;
   object plyr;
   if(!str) {
      write("Usage 'tease <who> <where>'\n");
      return 1;
   }
   if(sscanf(str,"%s %s",who,what) != 2) {
      write("Usage 'tease <who> <where>'\n");
      return 1;
   }
   if(!present(who,environment(this_player()))) {
      write("That person must be present!\n");
      return 1;
   }
   plyr = find_living(who);
   if(plyr == this_player()) {
      write("Its really not as fun by yourself.\n");
      return 1;
   }
   myname = capitalize(this_player()->query_real_name());
   get_gender();
   write("You run your hands up and down "+capitalize(who)+"'s "+what+", teasing and exciting them.\n");
   tell_object(plyr, myname+" runs "+pronoun+" hands up and down your "+what+", teasing and exciting you.\n");
   say(myname+" runs "+pronoun+" hands up and down "+capitalize(who)+"'s "+what+", teasing and exciting them.\n");
   return 1;
}

get_gender() {
   if(this_player()->query_gender() == "male") {
      pronoun = "his";
      return 1;
   }
   if(this_player()->query_gender() == "female") {
      pronoun = "her";
      return 1;
   }
   else {
      pronoun = "its";
      return 1;
   }
}

remove_shirt(who,plyr) {
   if(present(who+" shirt",environment(plyr))) {
      write(capitalize(pronoun)+" shirt is already off!\n");
      return 1;
   }
   move_object(clone_object("/players/ulath/closed/invis_shirt"),environment(plyr));
   present("invis_shirt",environment(plyr))->set_id(who+" shirt");
   write("You hastily unbutton "+capitalize(who)+"'s shirt and fling it into the distance.\n");  
   tell_object(plyr, myname+" hastily unbuttons your shirt and flings it into the distance.\n");
   say(myname+" hastily unbuttons "+capitalize(who)+"'s shirt and flings it into the distance.\n", plyr);
   return 1;

}

remove_pants(who,plyr) {
   if(present(who+" pants",environment(plyr))) {
      write(capitalize(pronoun)+" pants are already off!\n");
      return 1;
   }
   move_object(clone_object("/players/ulath/closed/invis_pants"),environment(plyr));
   present("invis_pants",environment(plyr))->set_id(who+" pants");
   write("You undo "+capitalize(who)+"'s pants and throw them over your shoulder.\n");
   tell_object(plyr, myname+" undoes your pants and throws them over "+pronoun+" shoulder.\n");
   say(myname+" undoes "+capitalize(who)+"'s pants and throws them over "+pronoun+" shoulder.\n", plyr);
   return 1;
}

remove_bra(who,plyr) {
   int x;
   x = random(3);
   if(plyr->query_gender() != "female") {
      write("Only women wear that type of undergarment!\n");
      return 1;
   }
   if(present(who+" bra",environment(plyr))) {
      write("Her bra is already off!\n");
      return 1;
   }
   if(!present(who+" shirt",environment(plyr))) {
      write("Her shirt is not off!\n");
      return 1;
   }
   if(!x) {
      write("You are unable to undo the clasp.\n");
      tell_object(plyr, myname+" is unable to undo the clasp of your bra.\n");
      say(myname+" is unable to undo the clasp of "+capitalize(who)+"'s bra.\n", plyr);
      return 1;
   }
   if(x) {
      move_object(clone_object("/players/ulath/closed/invis_bra"),environment(plyr));
      present("invis_bra",environment(plyr))->set_id(who+" bra");
      write("You deftly unhook the clasp and twirl the bra on your finger.\n");
      tell_object(plyr, myname+" deftly unhooks the clasp of your bra and twirls it around "+pronoun+" finger.\n");
      say(myname+" deftly unhooks the clasp of "+capitalize(who)+"'s bra and twirls it around "+pronoun+" finger.\n", plyr);
      return 1;
   }
}

remove_panties(who,plyr) {
   if(find_player(who)->query_gender() != "female") {
      write("Only women wear that type of undergarment!\n");
      return 1;
   }
   if(present(who+" panties",environment(plyr))) {
      write("Her panties are already off!\n");
      return 1;
   }
   if(!present(who+" pants",environment(plyr))) {
      write("Her pants are not off!\n");
      return 1;
   } 
   move_object(clone_object("/players/ulath/closed/invis_panties"),environment(plyr));
   present("invis_panties",environment(plyr))->set_id(who+" panties");
   write("You tear off "+capitalize(who)+"'s panties and fling them off into the distance.\n");
   tell_object(plyr, myname+" tears off your panties and flings them into the distance.\n");
   say(myname+" tears off "+capitalize(who)+"'s panties and flings them off into the distance.\n", plyr);
   return 1;
}

remove_boxers(who,plyr) {
   if(find_player(who)->query_gender() != "male") {
      write("Only men wear that type of undergarment!\n");
      return 1;
   }
   if(present(who+" boxers",environment(plyr))) {
      write("His boxers are already off!\n");
      return 1;
   }
   if(!present(who+" pants",environment(plyr))) {
      write("His pants are not off!\n");
      return 1;
   } 
   move_object(clone_object("/players/ulath/closed/invis_boxers"),environment(plyr));
   present("invis_boxers",environment(plyr))->set_id(who+" boxers");
   write("You pull off "+capitalize(who)+"'s boxers and fling them across the room.\n");
   tell_object(plyr, myname+" pulls off your boxers and flings them across the room.\n");
   say(myname+" pulls off "+capitalize(who)+"'s boxers and flings them across the room.\n", plyr);
   return 1;
}

