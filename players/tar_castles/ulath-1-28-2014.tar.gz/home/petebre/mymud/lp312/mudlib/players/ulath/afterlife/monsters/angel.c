#include "/players/ulath/closed/ansi.h"
inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if(arg) return;

   set_name("An Angel");
   set_level(16);
   set_alt_name("angel");
   set_long("This creature resembles the beautiful angels you have heard\n"+
      "about, but it seems to have withered. The feathers in its\n"+
      "wings are gray and falling out. Its body, though well muscled,\n"+
      "looks sickly and frail. The eyes are sunken into the skull, and\n"+
      "dully stare at nothing for long periods of time.\n\n"+
      "   This Angel, along with its forsaken brethren here, refused to\n"+
      "choose a side in 'The Great Conflict' when Lucifer's pride caused\n"+
      "him to rebel against God. Heaven turned them away, and Hell will \n"+
      "not grant them dominion, so they are powerless and trapped in the \n"+
      "void between Heaven and Hell.\n");
   set_race("angel");
   set_wc(20+random(5));
   set_ac(13);
   set_hp(350+random(100));
   set_al(0);
   set_chat_chance(3);
   load_chat("The Angel bows before the statue.\n");
   load_chat("The Angel weeps in sorrow for its fate.\n");
   set_a_chat_chance(12);
   load_a_chat("The Angel smiles sadly.\n");
   load_a_chat("Wailing resounds throughout the area.\n");
   set_chance(10);
   set_spell_mess1("The Angel beats his attacker with his wings...\n");
   set_spell_mess2("The Angel beats you with his wings...\n");
   set_spell_dam(random(20));
}

