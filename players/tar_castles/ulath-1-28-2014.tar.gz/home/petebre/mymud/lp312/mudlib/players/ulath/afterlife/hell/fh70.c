#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c";

reset(arg) {
   object ob;
   int i;
   if(arg) return;
   set_light(1);
   ob = clone_object("/players/ulath/afterlife/monsters/charon.c");
   i = transfer(ob, "/players/ulath/afterlife/hell/fh70.c");
   short_desc="The Shores of the River "+BOLD+BLK+"Acheron"+NORM;
   long_desc="  The black, murky waters of the River Acheron, "+
             "lazily churn around the outer ring of Hell. There "+
             "is a large boat here used by Charon to row the damned "+
             "across the river. The dismal souls wait in a long line "+
             "for their turn to take the ride across the River of Sorrows.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh60.c","west", 
   });
   items=({
      "river","The River Acheron seperates the Outskirts from 'Hell Proper.'\n"+
              "It churns in a circular motion around the First Circle of Hell",
   });
}

init() {
   add_action("cross","cross");
}

cross() {
   write("You wade across the river and end up elsewhere.\n");
   move_object(this_player(), "/players/ulath/afterlife/throne.c");
   return 1;
}




realm() { return "NT"; }