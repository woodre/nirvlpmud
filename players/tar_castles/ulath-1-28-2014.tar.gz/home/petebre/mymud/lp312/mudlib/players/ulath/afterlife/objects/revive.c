#include "/players/ulath/closed/ansi.h"
inherit "obj/treasure";

int delay;
string align, afterlife;
object ob;
object corpse;

reset(arg) {
   if(arg) return;
   set_id("revive"); 
}

init() {
   ::init();
   ob = this_player();
   if(!(ob->query_ghost())) destruct(this_object());
   align();
   task();
}

drop() { return 1; }

task() { 
   switch(delay) {
   case 0:
      tell_room("/players/ulath/afterlife/throne" , BOLD+BLK+"Death"+NORM+" grasps "+capitalize(ob->query_real_name())+"'s disembodied soul...\n");   
      tell_object(ob, BOLD+BLK+"Death"+NORM+" grasps your disembodied soul...\n");
      ++delay;
      call_out("task",1,);
      break;
   case 1:
      tell_room("/players/ulath/afterlife/throne" , BOLD+BLK+"Death"+NORM+" traces "+capitalize(ob->query_real_name())+"'s soul with the Orb of Judgement...\n");
      tell_object(ob, BOLD+BLK+"Death"+NORM+" traces your soul with the Orb of Judgment...\n");
      ++delay;
      call_out("task",1);
      break;
   case 2:
      tell_object(ob, BOLD+BLK+"Death"+NORM+" says, \" I have judged your soul as balanced towards "+align+".\"\n");
      tell_object(ob, "I have a task for you, if you wish to redeem your life.\n");
      ++delay;
      call_out("task",1);
      break;
   case 3:
      tell_object(ob, BOLD+BLK+"Death"+NORM+" continues, \"There is an imbalance in the Powers of Good and Evil, and\n"+
          "you are the Chosen to put it right.\"\n");
      ++delay;
      call_out("task",1);
      break;
   case 4:
      tell_object(ob, "Go now into "+afterlife+" and destroy the powers that reside there. May Fate be on your side.\n");
      ++delay;
      call_out("task",1);
      break;
   case 5:
      ++delay;
      if(environment(environment(this_object()))) {
         corpse = present("corpse",environment(environment(this_object())));
      }
      destination();
      destruct(this_object());
      break;
   }
   return;
}

align() {
   int temp;
   temp = this_player()->query_alignment();
   if(temp > 100) { 
      align = "good";
      afterlife = HIR+"Hell"+NORM;
   }
   if(temp <= 100 && temp >= -100) {
      align = "neutral";
      afterlife = "Purgatory";
   }
   if(temp < -100) {
      align = "evil";
      afterlife = BOLD+"Heaven"+NORM;
   }
   return ;
}


destination() {
   if(align == "good") {
      move_object(ob, "/players/ulath/afterlife/hell_gate");
   }
   if(align == "evil") {
      move_object(ob, "/players/ulath/afterlife/heaven_gate");
   }
   if(align == "neutral") {
      move_object(ob, "/players/ulath/afterlife/purgatory");
   } 
   tell_object(ob, BOLD+BLK+"Death"+NORM+" has moved you to "+afterlife+".\n");
   tell_room("/players/ulath/afterlife/throne", capitalize(ob->query_real_name())+" goes to "+afterlife+".\n", );
   tell_object(ob, "Your corpse materializes in front of you.\n");
   move_object(corpse, environment(ob));
   ob->remove_ghost();
   return;
}
   
