#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c";

reset(arg) {
   object ob;
   int i;
   if(arg) return;
   ob = clone_object("/players/ulath/afterlife/monsters/lost_soul");
   move_object(ob,this_object());
   ob->be_a_leader(0,random(5)+1);

   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The grey, dusty terrain stretches out as far as the "+
      "lighting allows to be seen.  The dark sky is filled with fast moving "+
      "clouds rushing towards a pillar of land thrusting out of the earth.  Although "+
      "there is no wind, the clouds race with a life of their own.  The wailing "+
      "that permeates the area heightens in intensity and volume, crying out to "+
      "those souls not yet lost.";     
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh22.c","north",
      "/players/ulath/afterlife/hell/fh23.c","south",
      "/players/ulath/afterlife/hell/fh1.c","west",
      "/players/ulath/afterlife/hell/fh30.c","east",
   });
}

realm() { return "NT"; }

