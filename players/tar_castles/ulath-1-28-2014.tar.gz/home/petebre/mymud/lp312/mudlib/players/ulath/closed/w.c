#include <ansi.h>
inherit "/obj/treasure";

reset(arg) {
   if(arg) return;
   set_id("wizwho");
   set_long("A who of wizards. Usage is 'wwho'.\n");
   set_weight(1);
   set_value(0);
}

init() {
   ::init();
   add_action("wwho","wwho");
}

wwho() {
   object list;
   int i,level;
   string name,txt;

   if(this_player()->query_level() < 21) {
      write("Only wizzes can use this, sorry.");
      destruct(this_object());
      return 1;
   }
   list = users();
   txt = "Name       \t\t\tLevel\n";
   for(i=0;i<sizeof(list);i++) {
      level = list[i]->query_level();
      if(level >= 20) {
         name = extract(list[i]->query_real_name()+"          ",0,10);
         txt += capitalize(name)+"\t\t\t"+level;
         if(in_editor(list[i])) txt += "\t\t"+HIM+"ED"+NORM;
         if(!interactive(list[i])) txt += "\t\t"+HIR+"DC"+NORM;
         if(query_idle(list[i]) > 120) txt += "\t\t"+HIY+"Idle"+NORM;
         txt += "\n";
      }
   }
   write(txt);
   return 1;
}
               
