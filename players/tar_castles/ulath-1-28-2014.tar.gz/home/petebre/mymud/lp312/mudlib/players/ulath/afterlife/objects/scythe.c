#include "/players/ulath/closed/ansi.h"
inherit "/obj/weapon";

reset(arg) {
   ::reset(arg);
   if(arg) return;

   set_name(BOLD+BLK+"Death"+NORM+"'s Scythe");
   set_alias("scythe");
   set_long("A large scythe, that Death wields to reap the souls\n"+
            "of mortals whose time is up. Its extremely powerful\n"+
            "and longs to bite into mortal flesh.\n");
   set_class(19);
   set_save_flag(0);
   set_weight(6);
   set_value(3000);
   set_save_flag(1);
   set_hit_func(this_object());

}

weapon_hit(attacker) {
   if(!random(10)) {
   tell_object(attacker,
               "You hear the Wailing of Souls as the Scythe rends your flesh.\n"+
           HIB+"                    ANGUISH\n"+NORM+
               "               racks your mind and body!\n");
   tell_object(wielded_by,"The Scythe wails in "+HIB+"ANGUISH"+NORM+" as it decimates it foe!\n");
   say("The room is filled with an eerie wailing as the Scythe cuts into "+attacker->query_name()+"'s flesh.\n",attacker);
   attacker->heal_self(-10);
   }
}
