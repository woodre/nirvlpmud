#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   A black, slowly moving river meanders along to some dismal destination "+
      "off to the east. The cliffs surrounding this area, curve around, and block "+
      "the path both to the south and to the east.  The plains head back to the west "+
      "and north.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh60.c","north",
      "/players/ulath/afterlife/hell/fh53.c","west",
   });
}

realm() { return "NT"; }

