inherit "obj/treasure";

reset(arg) {
   if(arg)return;
   set_id("invis_shirt");
}
