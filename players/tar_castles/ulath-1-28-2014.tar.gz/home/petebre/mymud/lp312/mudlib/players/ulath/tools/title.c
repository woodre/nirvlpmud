#include "/players/llew/closed/ansi.h"

reset(arg) {
   if(arg) return;
   find_player("jim")->set_title(HIR+"is Ulath's test char"+NORM);
   }
