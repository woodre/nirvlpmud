#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The earth plummets away into a dark chasm.  Thick, choking smoke "+
      "rises out of the chasm, obsuring anything beyond the cliff face. The "+
      "red clouds in the sky mix with the black smoke, and red lightning strikes "+
      "illuminating the darkness for the briefest instant.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh32.c","east",
      "/players/ulath/afterlife/hell/fh20.c","south",
   });
}

realm() { return "NT"; }

