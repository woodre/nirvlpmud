#include "/players/ulath/closed/ansi.h"
inherit "/obj/monster";

reset(arg) {
   ::reset(arg);
   if(arg) return;

   move_object(clone_object("/players/ulath/afterlife/objects/oar"),this_object());
   set_name(RED+"Charon"+NORM);
   set_alt_name("charon");
   set_level(20);
   set_long(RED+"Charon"+NORM+" is the ferry man for the first river that flows in Hell.\n"+
            "He poles across the murky depths, sending the damned souls\n"+
            "to their eternal fates. An old grizzled looking man, this demon\n"+
            "has wheels of flame about his eyes, and they seem to burn through\n"+
            "all that he stares upon. His pole he uses to swat those souls who\n"+
            "are unwilling to cross.\n");
   set_race("demon");
   init_command("wield oar");
   set_wc(28+random(5));
   set_ac(10+random(6));
   set_hp(450+random(150));
   set_al(-1000);
   set_chat_chance(7);
   load_chat(RED+"Charon"+NORM+" swats at the souls on the shore with his oar.\n");
   load_chat(RED+"Charon"+NORM+" glares at you with his fiery eyes.\n");
   load_chat(RED+"Charon"+NORM+" says: \'You can cross the River here.\'\n");
   load_chat("A great wailing reverberates throughout the area.\n");
   set_a_chat_chance(10);
   load_a_chat(RED+"Charon"+NORM+"'s eyes burn through you.\n");
   load_a_chat(RED+"Charon"+NORM+" says: \'You do not belong here.\'\n");   
}
