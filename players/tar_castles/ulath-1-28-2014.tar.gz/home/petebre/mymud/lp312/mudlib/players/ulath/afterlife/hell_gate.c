#include "/players/ulath/closed/ansi.h"

inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc=HIR+"The Gates of  H E L L"+NORM;
   long_desc="   The Gates of Hell stand wide, inviting, like some giant beast's maw. "+
             "There is a large sign above the iron wrought gates. All is dark behind "+
             "the gate, and nothing can be seen within. A path runs through the gates "+
             "and leads further into this Realm.";
   long_desc=format(long_desc, 65);
   items=({
            "sign" , "An old, wooden sign that is written in dark, red, crusted over blood",
            "gate" , "The gates of Hell, are interestingly spread wide open, almost as an\n"+
                     "invitation for those willing to enter",
            "path" , "A dirt path, that has many footprints heading into, but not out of\n"+
                     "this foreboding area",
   });
   dest_dir=({
            "/players/ulath/afterlife/hell/fh1.c" , "east" ,
  });
}

init() {
   ::init();
   add_action("read","read");
}

read(str) {
   if(!str || str != "sign") {
      notify_fail("Read what?\n");
      return 0;
   }
   else {
      say(capitalize(this_player()->query_real_name())+" reads the sign.\n", this_player());
      write("     THROUGH ME YOU ENTER INTO THE CITY OF WOES,\n"+
            "       THROUGH ME YOU ENTER INTO ETERNAL PAIN,\n"+
            "     THROUGH ME YOU ENTER THE POPULATION OF LOSS.\n\n"+
            "     JUSTICE MOVED MY HIGH MAKER, IN POWER DIVINE,\n"+
            "      WISDOM SUPREME, LOVE PRIMAL. NO THINGS WERE\n"+
            "        BEFORE ME NOT ETERNAL; ETERNAL I REMAIN.\n\n"+
            "         ABANDON ALL HOPE, YOU WHO ENTER HERE.\n\n");
   return 1;
   }
}

realm() { return "NT"; }
