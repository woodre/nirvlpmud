#include "/players/llew/closed/ansi.h"

inherit "room/room";

reset(arg) {
   object ob;
   int i;
   if(arg) return 0;

   ob = clone_object("/players/llew/Other/monsters/blob.c");
   i = transfer(ob,"/players/ulath/test.c");
   set_light(1);
   short_desc="A Battle Ground";
   long_desc=
      "A large battle ground where Ulath tests his monsters.\n";
   dest_dir=({
      "/players/ulath/workroom.c" , "north" });
}
             
realm() { return "PK"; }