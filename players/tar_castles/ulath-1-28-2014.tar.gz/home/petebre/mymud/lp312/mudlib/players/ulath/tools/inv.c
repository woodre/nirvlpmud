short() { return "A inventory lister"; }
long() { write("Type 'invlist <player>'.\n"); return 1; }
get() { return 1; }
drop() { destruct(this_object()); }
id(str) { return str == "lister"; }
init() { add_action("invlist", "invlist"); }
invlist(str) {
  string who;
  int so,x;
  object *allinv;
  if(this_player()->query_level() < 21) destruct(this_object());
  if(!str) return 0;
  who = str;
  if(!find_player(who)) {
    write("player not found.\n");
    return 1;
  }
   allinv=all_inventory(find_player(who));
   for(x=0,so=sizeof(allinv);x<so;x++) {
      write(allinv[x]);
      if(allinv[x]->short()) write(" Short: "+allinv[x]->short()+".\n");
      else if(allinv[x]->query_name()) write(allinv[x]->query_name()+".\n");
      else if(allinv[x]->id()) write(allinv[x]->id()+".\n");
      else write("INVIS.\n");
   }
   return 1;
}


