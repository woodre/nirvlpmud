#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c";

reset(arg) {
   object ob;
   if(arg) return;
   ob = clone_object("/players/ulath/afterlife/monsters/lost_soul");
   move_object(ob,this_object());
   ob->be_a_leader(0,random(5)+1);

   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The crevice continues here, beginning to curve towards the north. "+
      "The wailing is not as deafening here, but it still continues unabated. "+
      "The dismal plains continue to the north, and follow the edge of the plateau "+
      "back towards the west.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh53.c","north",
      "/players/ulath/afterlife/hell/fh44.c","west",
    });
}

realm() { return "NT"; }

