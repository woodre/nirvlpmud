#include "/players/ulath/closed/ansi.h"
inherit "/obj/monster";

object friends;
object lead_by;
int people_count;
int temp_age;
int leader;


reset(arg) {
   ::reset(arg);
   if(arg) return;
   
   people_count = 0;
   friends = ({});
   temp_age = 0;
   leader = 0;

   set_name("A Shade");
   set_level(16);
   set_alt_name("shade");
   set_long("This lost soul, is truly a disgusting sight. Its pale skin is galled\n"+
            "by wasps and flies, with blood trickling down its face, mingling with\n"+
            "tears for harvest underfoot by writhing maggots.\n\n"+
            "   Its blood is shed for the maggots and the filth underfoot because\n"+
            "it refused to rally to a cause while still alive.\n\n");
   set_race("shade"); 
   set_wc(20);
   set_ac(13);
   set_hp(275+random(75));
   set_al(0);
   set_chat_chance(3);
   load_chat("The Shade moans in agony.\n");
   load_chat("The Lost Soul longs to cross the river.\n");
   set_a_chat_chance(12);
   load_a_chat("The Shades rally around their banner...\n");
   load_a_chat("The Shade's skin flakes off in chunks...\n");
   load_a_chat("The maggots eat up the ichor from the battle.\n");
   load_a_chat("Wailing resounds throughout the area.\n");
   set_chance(10);
   set_spell_mess1("The flies and wasps attack...\n");
   set_spell_mess2("The flies and wasps bite and sting you.\n");
   set_spell_dam(random(20));
   set_dead_ob(this_object());
   call_out("random_move",50+random(20));    
}

heart_beat() {
   ::heart_beat();
   if(find_call_out("random_move") == -1 && leader) call_out("random_move",60+random(30));
   if(attacker_ob && !leader) lead_by->help_fight(this_object());
   if(attacker_ob && !leader) lead_by->help_fight(this_object());
   if(attacker_ob && leader) help_fight(this_object());
}

random_move() {
   object exits;
   int i;
   if(!leader) return;
   if(age > temp_age) {
      temp_age = age;
      people_count = 0;
   }   
   else people_count++;  
   if(!attacker_ob ) {
      exits = environment()->query_dest_dir();
      i = random(sizeof(exits)/2)*2;
      tell_room(environment(),"The Lost Soul with the banner heads "+exits[i+1]+".\n");
      move_object(this_object(),exits[i]);
      tell_room(environment(),"A line of Shades enters.\n");
      lead_on();
   }
   if(people_count < 8) call_out("random_move",60+random(30));
   return 1;
}

be_a_leader(n,amm) {
   int x;
   if(n) {
      friends = filter_array(n,"is_object",this_object());
      for(x=0;x<sizeof(friends);x++) {
         friends[x]->lead_by(this_object());
      }
   }
   else {
      for(x=0;x<amm;x++) {
         object soul_guy;
         soul_guy = clone_object("/players/ulath/afterlife/monsters/lost_soul");
         move_object(soul_guy,environment());
         friends += ({soul_guy});
         soul_guy->lead_by(this_object());
      }
   leader = 1;
   }
}

lead_on() {
   int x;
   friends = filter_array(friends,"is_object",this_object());
   for(x=0;x<sizeof(friends);x++) {
      friends[x]->move_to_leader(this_object());
   }
}

is_object(ob) {
   if(ob == this_object()) return 0;
   return objectp(ob);
}

move_to_leader(ob) {
   say("The Lost Soul leaves, trailing after another soul.\n");
   move_object(this_object(),environment(ob));
}

monster_died() {
   tell_room(environment(),"The Lost Soul fades to oblivion.\n");
   destruct(present("corpse"));
   if(leader) {
      friends = filter_array(friends,"is_object",this_object());
      if(sizeof(friends)) {
         friends[0]->be_a_leader(friends);
      }
      else {
         /* make a banner or something */
      }
   }
}

lead_by(ob) {
   lead_by = ob;
}

help_fight(ob) {
   int x;
   if(!attacker_ob) {
      attack_object(ob->query_attack());
   }
   friends = filter_array(friends,"is_object",this_object());
   for(x=0;x<sizeof(friends);x++) {
      if(!friends[x]->query_attack()) {
         friends[x]->attack_object(ob->query_attack());
      }
   }
}

