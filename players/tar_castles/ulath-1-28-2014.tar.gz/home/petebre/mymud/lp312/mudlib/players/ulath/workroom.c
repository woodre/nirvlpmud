#define owner "ulath"
#include "/players/llew/closed/ansi.h"

inherit "room/room";
int shield, notin;

reset(arg) {
   if(arg) return 0;
   move_object(clone_object("/players/llew/Other/misc/obituary.c"));
   set_light(2);
   shield = 1;
   short_desc="The Pit of "+HIR+"HELL"+NORM;
   long_desc= 
      "   The deepest, darkest pit of Hell. Flames reach for the sky, ever burning, "+
      "ever consuming, but never quenched.  The heat rolls off in waves, lapping at the "+
      "charred walls of stone.  Thick, black smoke billows from the flames, choking "+
      "those unfortunate enough to be here.";
   long_desc=format(long_desc,65);

   dest_dir=({
      "/room/church" , "church",
      "/room/post"   , "post" ,
      "/room/shop"   , "shop" ,
      "/room/adv_inner" , "board" ,
      "/players/ulath/test.c" , "south" ,
   });
}

init() {
   ::init();
   add_action("on","on");
   add_action("off","off");
   add_action("out","out");
   
   if(this_player()->query_real_name() != owner && shield == 1) {
      write("You are turned away by the endless "+HIR+"Fire"+NORM+"\n");
      if (notin == 1) {
         write(capitalize(owner)+" is not in or on another job right now, please leave a\n");
         write("message at the post office.\n");
      }
      this_player()->move_player("off the shields#/room/church");
   }
}
 
static on() {
   if (shield == 1) {
      write("The shield is already activated.\n");
      return 1;
   }
   shield = 1;
   write("shields activated.\n");
   return 1;
}
   
static off() {
   if(this_player()->query_real_name() != owner) {
      write("You can not do that.\n");
      return 1;
   }
   if(shield == 0) {
      write("The shields are already deactivated.\n");
      return 1;
   }
   shield = 0;
   notin = 0;
   write("shields deactivated.\n");
   return 1;
}
   
out() {
   shield = 1;
   notin = 1;
   write("shields on, out message on.\n");
   return 1;
}

   
