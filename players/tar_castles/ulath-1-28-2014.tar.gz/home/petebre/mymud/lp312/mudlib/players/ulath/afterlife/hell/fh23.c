#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The dusty plain plummets into the bowels of the earth. Dark smoke rolls "+
      "out of the chasm. Bright red lightning flashes in the sky, out of the "+
      "angry clouds. The tumult of voices imbued with rage and despair is all that can be heard.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh20.c","north",
      "/players/ulath/afterlife/hell/fh33.c","east",
   });
}

realm() { return "NT"; }

