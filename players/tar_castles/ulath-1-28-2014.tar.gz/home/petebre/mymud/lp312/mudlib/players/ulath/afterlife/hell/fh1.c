#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   A great plain stretches as far as the eye can see.  The light is dim "+
      "obscuring sight at great distances.  A wailing as of many voices in "+
      "desperate anguish, resounds throughout this area.  The spirits "+
      "here long for any other fate than the one that they have recieved.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell_gate.c","west",
      "/players/ulath/afterlife/hell/fh20.c" ,"east",
   });
}

realm() { return "NT"; }

