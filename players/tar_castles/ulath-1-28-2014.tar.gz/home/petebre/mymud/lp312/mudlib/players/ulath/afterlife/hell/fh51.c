#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The barren, lifeless plains extend out from the small pathway that "+
      "travels around the north side of the plateau.  The chorus of woe is lessened, "+
      "but the lifeless terrain allows no mistaking where this horrible place is.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh52.c","south",
      "/players/ulath/afterlife/hell/fh41.c","west",
    });
}

realm() { return "NT"; }

