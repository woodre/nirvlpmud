#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The furthest corners of this dismal plain, seem to be less opressive as "+
      "the surrounding terrain. Perhaps they are closer to the World of the Living, "+
      "or the power that resides here is weaker here. The ravine that rings the "+
      "area still continues along here, headed off towards the east.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh33.c","north",
      "/players/ulath/afterlife/hell/fh44.c","east",
   });
}

realm() { return "NT"; }

