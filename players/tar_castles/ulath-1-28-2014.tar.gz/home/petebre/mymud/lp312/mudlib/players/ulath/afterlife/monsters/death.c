/* Make sure combat stops after the second death */
/* Raise AC and WC to justify lowering of HP */

#include "/players/ulath/closed/ansi.h"
inherit "obj/monster";

int attack;

reset(arg) {
   ::reset(arg);
   if(arg) return;

   move_object(clone_object("/players/ulath/afterlife/objects/scythe"),this_object());
   set_name(BOLD+BLK+"Death"+NORM);
   set_level(20);
   set_alt_name("death");
   set_long("  Death's hulking form rests in the throne, eyeing you.\n"+
            "His skeletal hands finger his Scythe, as he eyes\n"+
            "his Orb of Judgement and seems to look into your Soul.\n"+
            "  The Incarnation of Death is a foreboding figure cloaked in a\n"+
            "dark robe. His facial features are shrouded by his dark hood, but\n"+
            "his hands are skeletal, and a cold chill makes the hair\n"+
            "on the back of your neck stand on end. His Scythe is huge and\n"+
            "extremely sharp, ready to reap the souls of those on his list.\n"+
            "He then uses the Orb of Judgement to assertain the soul's destination\n"+
            "for the eternal afterlife. Is it your time yet?\n");
   set_race("avatar");
   init_command("wield scythe"); 
   set_wc(40);
   set_ac(14);
   set_hp(450+random(100)); 
   set_al(0);
   set_dead_ob(this_object());
   set_chat_chance(6);
   load_chat(BOLD+BLK+"Death"+NORM+" stares into your soul.\n");
   load_chat("A chilled breeze blows by.\n");
   load_chat(BOLD+BLK+"Death"+NORM+" says, \"I shall Judge you like all the others.\"\n");
   set_a_chat_chance(15);
   load_a_chat(BOLD+BLK+"Death"+NORM+" cleaves through your flesh with his Scythe.\n");
   load_a_chat(BOLD+BLK+"Death"+NORM+" says, \"You are next on my list.\"\n");
   set_chance(20);
   set_spell_mess1(BOLD+BLK+"Death"+NORM+" reaches into his attacker's soul with a skeletal hand.");
   set_spell_mess2(BOLD+BLK+"Death"+NORM+" reaches into your soul...");
   set_spell_dam(20+random(35));
}

monster_died() {
   tell_room(environment(), name+" collapses down into dust.\n");
   tell_room(environment(), "A door in the east wall opens.\n");
   move_object(clone_object("/players/ulath/afterlife/objects/dead_death_ob.c"),environment(this_object())); 
   environment(this_object())->new_exit();
}

heart_beat() {
   object corpse;
   ::heart_beat();
   if(attacker_ob) {
      ++attack;
   }
   if(attack >= 10) {
      if(attacker_ob->is_player()) {
         stop_hunter();
         attack = 0;
         tell_room(environment(), capitalize(attacker_ob->query_real_name())+" died.\n");
         tell_room(environment(), name+" swings his scythe in one great blow, smiting his foe.\n");
         attacker_ob->second_life();
         corpse = clone_object("obj/corpse");
         corpse->set_name(attacker_ob->query_real_name());
         corpse->set_corpse_level(attacker_ob->query_level());
         move_object(corpse, environment(this_object()));
         attacker_ob->transfer_all_to(corpse);
         if(attacker_ob->query_ghost()) {
            move_object(clone_object("/players/ulath/afterlife/objects/revive.c"), attacker_ob);
         }
      }
      if(!attacker_ob->is_player()) {
         tell_room(environment(), name+" smites the souless creature in one blow!\n");
         attacker_ob->hit_player(attacker_ob->query_hp()+50);
      }  
   }
   if((attacker_ob->query_hp()*100)/(attacker_ob->query_mhp()) <= 20) {
      attacker_ob->hit_player(attacker_ob->query_hp()+50);
      tell_room(environment(), name+" DESTROYS HIS FOE'S WEAKENED BODY!\n");
   }
}   


