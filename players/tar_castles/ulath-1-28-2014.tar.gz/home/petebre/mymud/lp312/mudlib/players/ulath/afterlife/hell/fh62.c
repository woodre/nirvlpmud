#include "/players/ulath/closed/ansi.h"
#define NQC room

inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
       "   The cliffs plunge off the plain into the depths. To the east a river "+
       "can be seen lazily making its way along the edge of this terrible realm. "+ 
       "The plains stretch to the south, and to the west.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh60.c","south",
      "/players/ulath/afterlife/hell/fh52.c","west",
   });
}

realm() { return "NT"; }

