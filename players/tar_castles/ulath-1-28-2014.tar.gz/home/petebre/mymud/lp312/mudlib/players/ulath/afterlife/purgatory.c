#include "/players/ulath/closed/ansi.h"

inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="Purgatory";
   long_desc="     Purgatory.     ";
   long_desc=format(long_desc,65);
   dest_dir=({ 
      "/players/ulath/afterlife/hell_gate.c" , "down" ,
      "/players/ulath/afterlife/heaven_gate.c" , "up" ,
   });
}
