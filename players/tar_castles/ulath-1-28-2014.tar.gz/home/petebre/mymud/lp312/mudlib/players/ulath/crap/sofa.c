#include "/players/llew/closed/ansi.h"
inherit "obj/monster";

reset(arg) {   
   object gold;
   ::reset(arg);
   if(arg) return;
   set_name("Sofa");
   set_level(15);
   set_wc(17);
   set_ac(10);
   set_hp(225);
   gold=clone_object("obj/money");
   gold->set_money(750+random(200));
   move_object(gold,this_object());
   set_alias("sofa");
   set_long("A brown, floral couch.  It flobbles about, gesturing wildly with its\n"+
            "paired cushions of destruction.  The earth tone floral pattern rages\n"+
            "right out of the 70s and appears very menancing.\n");
   set_al(-750);
   set_chat_chance(3);
   load_chat("The sofa flubs about.\n");
   load_chat("The sofa waves its cushions menacingly.\n");
   load_chat("The sofa ponders the existence of intelligent life.\n");
   set_a_chat_chance(8);
   load_a_chat("The sofa pins you between its cushions.\n");
   load_a_chat("The sofa smacks you with an arm.\n"); 
   set_race("furniture");
   set_can_kill(1);
   set_chance(12);
   set_spell_mess1("The sofa hops into the air, and comes down on its attacker crushing them!\n");
   set_spell_mess2("The sofa hops into the air, and lands on you, crushing you!\n");
   set_spell_dam(15+random(20));
}

init() {
   ::init();
   add_action("sit","sit");
}

heart_beat() {
   ::heart_beat();
   if(attacker_ob) {
      already_fight = 0;
      attack();
   }
}

sit(str) {
   if(!str || str != "sofa") {
      notify_fail("Sit on what?\n");
      return 0;
   }
   if(str == "sofa") {
      write("The sofa rages at almost being sat upon!\n");
      attack_object(this_player());
      return 1;
   }
}

