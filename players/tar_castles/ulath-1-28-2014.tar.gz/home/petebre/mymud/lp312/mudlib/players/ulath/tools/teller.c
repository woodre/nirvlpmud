#include <ansi.h>
inherit "/obj/treasure";

string color;

short() { 
   return "Ulath's Teller"; 
}

long() { 
   write("    A teller. 'wt <msg>' to tell, 'wte <msg>' to emote. \n"+
         "    'ws <msg>' to say. 'wse <msg>' to local emote.\n"+
         "    'wh <msg>' to bullhorn at a person.\n");  
}

id(str) { 
   return str == "teller"; 
}


init() {
   add_action("wiz_tell" , "wt");
   add_action("wiz_mote" , "wte");
   add_action("wiz_say"  , "ws");
   add_action("wiz_emote", "wse");
   add_action("wiz_horn" , "wh");
}

wiz_tell(str) {
   object plyr;
   string who, what, myname;
   color = HIR;
   if(!str) { 
      write("Tell what?\n"); 
      return 1; 
   }
   if(sscanf(str,"%s %s",who,what) != 2) {
      write("Tell <who> <what>.\n"); 
      return 1; 
   }
   plyr = find_living(who);
   myname = capitalize(this_player()->query_real_name());
   if(!plyr) { 
      write(capitalize(who)+" is not online now.\n");
      return 1; 
   }
   tell_object(plyr, myname+" whispers to you: "+color+what+NORM+"\n");
   write("You whisper to "+capitalize(who)+": "+color+what+NORM+"\n");
   find_player(who)->add_tellhistory(myname+" whispers to you: "+what+"\n");
   return 1;
}

wiz_mote(str) {
   object plyr;
   string who, what, myname;
   choose_color();
   if(!str) {
      write("Umote what?\n");
      return 1;
   }
   if(sscanf(str,"%s %s",who,what) != 2) {   
      write("Emote <who> <what>?\n");
      return 1;
   }
   plyr = find_living(who);   
   myname = capitalize(this_player()->query_real_name());
   if(!plyr) {
      write(capitalize(who) +" is not online now.\n");
      return 1;
   }
   tell_object(plyr, "(u-mote) "+color+myname+" "+what+NORM+"\n");
   write("You emote to "+capitalize(who)+": "+color+myname+" "+what+NORM+"\n");
   return 1;
}

wiz_horn(str) {
   object plyr;
   string who, what, myname;
   if(!str) {
      write("Bullhorn what?\n");
      return 1;
   }
   if(sscanf(str,"%s %s",who,what) != 2) {
      write("Bullhorn <who> <what>?\n");
      return 1;
   }
   plyr = find_living(who);
   myname = capitalize(this_player()->query_real_name());
   if(!plyr) {
      write(capitalize(who) +"is not online now.\n");
      return 1;
   }
   choose_color();
   tell_room(environment(plyr), myname+"'s booming voice yells: "+color+"\""+what+"\""+NORM+"\n");
   write("You bullhorn at "+capitalize(who)+": "+color+"\""+what+"\""+NORM+"\n");
   return 1;
}
 
wiz_say(str) {
   string myname;
   choose_color();
   if(!str) {
      write("Say what?\n");
      return 1;
   }
   myname = capitalize(this_player()->query_real_name());
   say(color+myname+" says, \""+str+"\""+NORM+"\n");
   write(color+"You say, \""+str+"\""+NORM+"\n");
   return 1;
}

wiz_emote(str) {
   string myname;
   if(!str) {
      write("Emote what?\n");
      return 1;
   }
   choose_color();
   myname = capitalize(this_player()->query_real_name());  
   say(color+myname+" "+str+NORM+"\n");
   write(color+myname+" "+str+NORM+"\n");
   return 1;
}

choose_color() {
   int blah;
   blah = random(13);
   switch(blah) {
   case 0:	color = RED; break;
   case 1:      color = GRN; break;
   case 2:      color = YEL; break;
   case 3:	color = BLU; break;
   case 4:	color = MAG; break;
   case 5:	color = CYN; break;
   case 6:      color = HIR; break;
   case 7:	color = HIG; break;
   case 8:	color = HIY; break;
   case 9:	color = HIB; break;
   case 10:	color = HIM; break;
   case 11:	color = HIC; break;
   case 12:     color = HIW; break;
   }
   return 1;
}


   
