#include "/players/ulath/closed/ansi.h"
#define NQC room


inherit "room/room.c";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="The Outskirts of "+HIR+"Hell"+NORM;
   long_desc=
      "   The southern end of the steep plateau juts out of earth, reaching for the "+
      "roiling skies. To the south, a deep rent is struck in the ground, that forms "+
      "the border all around this realm.";
   long_desc=format(long_desc,65);
   dest_dir=({
      "/players/ulath/afterlife/hell/fh34.c","west",
      "/players/ulath/afterlife/hell/fh54.c","east",
   });
}

realm() { return "NT"; }

