/* Wabbit south of 4 */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
FOUR_EXIT(MY_PATH+"wabbit4","north",
         MY_PATH+"wabbit3","east",
         MY_PATH+"wabbit3","south",
         MY_PATH+"wabbit1s","west",
         "Green Basin",
         "  Moving in the grass forest is difficult . You have to hack a\n"+
         "way through the head height grass which frequently gets in your\n"+
         "face . An uneasy feeling comes to you as there is no telling what\n"+
         "might be behind the thick tall grass ... Just be careful . \n",1)

more_reset () {
  no_exits = 1 ;
}
