/* Squirrel north 3 */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 , mon2 , mon3 ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"squirrel2n","east",
         MY_PATH+"squirrel3","south",
         "Willow trees",
         "  The most remarkable thing happening here is the playful chases\n"+
         "of the furry squirrels . Almost magical , these small animals run\n"+
         "not only with lightning speed , but also with mystical color \n"+
         "trails behind their oversize tails . Together with the sound of \n"+
         "rushing water , a whisetling wind and the green leaves of many \n"+
         "willows , these furry creatures make the most wonderful memory\n"+
         "you have had since your childhood ...\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  return ;
}
