/* Overland 3 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland4","east",
         MY_PATH+"_LOW/raven1","west",
         "Dagger Rock",
         "  You are travelling on a road next to Esgalduin . The road is\n"+
         "difficult to follow due to the elevation of Dagger Range to your\n"+
         "north and east . Rocky terrain and gusty winds added more \n"+
         "hazards to travellers . Looking upon the Dagger Range , you see\n"+
         "miles and miles of pine trees and a number of snowy peaks .\n",1)

more_reset () {}
