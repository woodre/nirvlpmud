/* Raven 3 north */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

object mon1 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"raven1n","east",
         MY_PATH+"raven3s","south",
         "Rocky bank",
         "  You have found a huge nest behind a fifteen feet tall boulder .\n"+
         "More rocks and boulders are here surrounded by more bushes .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/raven") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
