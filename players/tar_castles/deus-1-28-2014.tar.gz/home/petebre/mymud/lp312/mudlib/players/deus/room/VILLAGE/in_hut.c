#include "room.h"
#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"village2","out",
         "An old stone farm house",
         "  Carefully , you have entered the stone hut . The house seems\n"+
         "unoccupied . Infact , the windows , doors and roof of this hut\n"+
         "are long gone and the walls are mostly covered with moss , ivy\n"+
         "and other plants of the wild .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/orc2") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
