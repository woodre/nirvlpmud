/* Overland 2 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"_LOW/raven3","east",
         MY_PATH+"overland1","west",
         "South of Esgalduin",
         "  You are travelling on a road next to Esgalduin . Thou the road\n"+
         "twists and turns a lot , it stays close to the river and is not \n"+
         "too difficult to follow . Willow trees are abundant in this area .\n"+
         "You can see part of the river to your north in between trees .\n",1)

more_reset () {}
