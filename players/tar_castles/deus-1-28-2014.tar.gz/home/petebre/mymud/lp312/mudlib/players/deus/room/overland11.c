/* Overland 11 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland12","north",
         MY_PATH+"overland10","south",
         "Sherrardswood",
         "  You are at the edge of the forest of Sherrardswood . It is \n"+
         "the south-west boundary of Exeton . The forest is a mixture of\n"+
         "apple trees and oak trees . The undergrowth here has been \n"+
         "cleared somewhat leaving a distinct path which you can follow .\n"+
         "Both directions of the path lead you out of the small forest .\n",1)

more_reset () {}
