/* home3 */
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island25","out",
         "Guards House",
         "  Old armours and war banners decorate the inside of this house.\n"+
         "The house itself is long in shape with beds placed against one\n"+
         "side -- much like the way they do in hospitals.  Thick pieces of\n"+
         "cloth are used for windows and doors.\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
