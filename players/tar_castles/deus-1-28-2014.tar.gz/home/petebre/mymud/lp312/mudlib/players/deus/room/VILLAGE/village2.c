/* Village 2 */
#include "room.h"
#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"village1","north",
         MY_PATH+"village3","south",
         "Village",
         "  The fields around this area are long deserted . Looking south \n"+
         "you see the ruin of the village . A small climb north following \n"+
         "the road will take you to the top of a small knoll .\n",1)

more_reset () {
  call_other ("/players/deus/obj/hut","reset",0) ;
  call_other ("/players/deus/obj/well","reset",0) ;
}
