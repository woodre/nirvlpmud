/* Wabbit 5 */
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"_LOW/wabbit4","east",
         MY_PATH+"overland9","west",
         "Green Basin",
         "  It seems like you have finally reached the western end of this\n"+
         "huge basin . Twelve feet tall grass suround you and shut out most\n"+
         "of the sun light . The gound is very soft , making it difficiult \n"+
         "to walk . Even standing still is proven difficult here .\n",1)

more_reset () {}

more_init () {
  add_action ("search") ;
  add_verb ("search") ;
  add_action ("north") ;
  add_verb ("north") ;
  add_action ("south") ;
  add_verb ("south") ;
}

search (str) {
  if (str=="grass") {
    write ("You have found a path leading north and south .\n") ;
    say (this_player()->query_name()+" found something .\n") ;
    return 1 ;
  } ;
  if (!str) {
    write ("What do you want to search ?\n") ;
    return 1 ;
  } ;
  return 0 ;
}

north () {
  write ("You walked over the long grass . \n") ;
  call_other(this_player(),"move_player","north#"+MY_PATH+"_LOW/wabbit3") ;
  return 1 ;
}

south () {
  write ("You walked over the long grass .\n") ;
  call_other(this_player(),"move_player","south#"+MY_PATH+"_LOW/wabbit3") ;
  return 1 ;
}
