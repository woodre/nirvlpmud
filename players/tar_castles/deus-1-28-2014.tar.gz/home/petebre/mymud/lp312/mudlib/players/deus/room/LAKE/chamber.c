/* Chamber */
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island25","out",
         "Council Chamber",
         "  You have entered into the council chamber of the town.  This is\n"+
         "a large hall big enough to hold upto thirty or so people.  A\n"+
         "medium size round table is placed in one side of the room close\n"+
         "to the window. Eight high back chairs are placed around this\n"+
         "solid oak table.  A cloth map is hung on the wall next to the\n"+
         "distinctively larger chair.\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
