#include "room.h"
#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"village5","up",
         "A wine cellar",
         "  You found yourself in the wine cellar of the house . There are\n"+
         "a few broken barrels laying around . A pile of human bones is\n"+
         "also found in one corner .\n",0)

more_reset () {}
