/* Raven 3 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"_LOW/raven2","east",
         MY_PATH+"overland2","west",
         "Rocky bank",
         "  Echoes of rushing water are loud and clear here . The entire \n"+
         "place is covered with rocks and huge boulders . The climb west of\n"+
         "here will bring you up to a cliff . The road also continues east\n"+
         "into a patch of grassy area . With the exception of some bushes\n"+
         "and ivy north and south of you , there is not much growing on \n"+
         "these lose rocks and pebbles .\n",1)

more_reset () {}
