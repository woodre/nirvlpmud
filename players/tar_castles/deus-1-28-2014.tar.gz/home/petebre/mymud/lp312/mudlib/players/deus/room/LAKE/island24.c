/*ISLAND 24*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island25","west",
         MY_PATH+"island23","east",
         "East Street",
         "  This is part of the town center.  The south side of the street\n"+
         "is a residance of some sort.  Across the street is the local bar\n"+
         "filled with people and activities.  The eastern end of the street\n"+
         "stretches further and the west end of the street turns south.\n",1)

more_reset () {}
