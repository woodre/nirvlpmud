/*ISLAND 3*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island2","east",
         MY_PATH+"island4","west",
         "Hilly Trail",
         "  You are on a hilly trail of the island.  While the eastern\n"+
         "path can take you back towards the pier.  The path also continues\n"+
         "west towards higher grounds of the island where many pine trees\n"+
         "can be seen.\n",1)

more_reset () {}
