/* Squirrel 2 */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"squirrel1","east",
         MY_PATH+"squirrel3","west",
         "South of Esgalduin",
         "  Bushes and ivy covers most of this area . Few willow trees are\n"+
         "standing north-west of where you are . Rocky bank of Esgalduin \n"+
         "is close to a hundred yards away . A steep climb east is seen \n"+
         "from here . The westerly road will take you down stream .\n"+
         "Some big boulders are also seen south of here .\n",1)


more_reset () {}
