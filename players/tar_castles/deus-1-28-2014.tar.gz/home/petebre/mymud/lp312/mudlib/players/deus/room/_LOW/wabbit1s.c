/* Wabbit south of 1 */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
FOUR_EXIT(MY_PATH+"wabbit3","north",
         MY_PATH+"wabbit3","east",
         MY_PATH+"wabbit1n","south",
         MY_PATH+"wabbit3","west",
         "Green Basin",
         "  Looking all around , you realize that you have entered a huge\n"+
         "area of long grass . Most of them are as tall as you are . The \n"+
         "wind is blowing hard , making progress difficult . Whatever you\n"+
         "do , just don't get lost here ... \n",1)

more_reset () {
  no_exits = 1 ;
}
