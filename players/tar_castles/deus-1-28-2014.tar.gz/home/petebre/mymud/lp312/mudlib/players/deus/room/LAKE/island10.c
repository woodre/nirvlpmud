/*ISLAND 10*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island11","north",
         MY_PATH+"island1","south",
         "Red Cliff",
         "  You have come to an area at the bottom of the cliff.  Looking\n"+
         "upon the sheer face of the cliff, you can see that the cliff is\n"+
         "made up of red and brown rocks.  To your west is a thick forest\n"+
         "with many tall pine trees.  The path south takes you back on the\n"+
         "rocky beach where the path north is climbing steadly up and\n"+
         "around the cliff.\n",1)

more_reset () {}
