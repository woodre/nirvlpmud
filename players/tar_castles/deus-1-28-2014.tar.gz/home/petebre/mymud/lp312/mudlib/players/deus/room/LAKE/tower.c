/* Tower */
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island21","down",
         "Top of Tower",
         "  Slowly and carefully , you climb up the watch tower.  As you\n"+
         "look through the opening , you are able to see the top of the\n"+
         "ridges north and south of the tower.  You deduced that the\n"+
         "tower functions as a lookout or outpost for the town to warn\n"+
         "the people of approaching enemy.  From here , guards would be\n"+
         "able to spot anyone comming over the ridges immediately.\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
