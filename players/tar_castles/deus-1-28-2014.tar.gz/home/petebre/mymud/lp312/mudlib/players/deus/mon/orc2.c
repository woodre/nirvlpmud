/* A level 2 orc with money */
inherit "/obj/monster.talk" ;
object treasure ;

reset (arg) {
  if (!arg) {
    set_name("orc") ;
    set_level(2) ;
    set_alias("orc") ;
    set_race("orc") ;
    set_short("An ugly orc") ;
    set_long("  Speaking of ugly , you are probably looking at the most\n"+
    "ugly creature that dwells this part of the land.  If his teeth ain't\n"+
    "disgusting enough, the bad breath and smell are going to get you.\n") ;
    set_hp(15) ;
    set_al(-500) ;
    set_wc(5) ;
    set_ac(5) ;
    set_aggressive(1) ;
    set_move_at_reset() ;
    set_whimpy() ;
    set_chat_chance (5) ;
    load_chat("Who are you?  You know you should have left when you have a chance!\n") ;
    set_a_chat_chance(10) ;
    load_a_chat("Hardheaad will be please when I take your corpse back.\n") ;
    load_a_chat("I woder if your blood is worth anything to Shadowlord...\n") ;
    load_a_chat("I am going to cut you up! Ha HA ha ha!\n") ;
  } ;
  if (!present("coins",this_object())) {
    treasure = clone_object("/obj/money.c") ;
    treasure -> set_money(60) ;
    move_object(treasure,this_object()) ;
  } ;
  :: reset(arg) ;
}
