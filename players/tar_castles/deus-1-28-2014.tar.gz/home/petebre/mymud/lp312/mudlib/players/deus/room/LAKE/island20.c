/*ISLAND 20*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island21","west",
         MY_PATH+"island1","east",
         "Top Of Ridge",
         "  This is the top of a ridge that divides the rocky beach from\n"+
         "the valley west of here.  The pine trees are thicker in that\n"+
         "valley than those growing east between the beach and here.  The\n"+
         "desendings both east and west do not look too difficult.\n",1)

more_reset () {}
