/*ISLAND 1*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
FOUR_EXIT(MY_PATH+"island20","west",
         MY_PATH+"island10","north",
         MY_PATH+"island0","east",
         MY_PATH+"island2","south",
         "Rocky Beach",
         "  The path has taken you to a cross road.  The way east takes\n"+
         "you back out to the pier on the lake. To your west situates \n"+
         "light pine forest.  The path going north and south is generally\n"+
         "following the beach.  While going north will take you closer to\n"+
         "a cliff, you cannot tell where the southern trail is leading as\n"+
         "it turns out of sight behind the fishing boats and some huge\n"+
         "boulders.\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
