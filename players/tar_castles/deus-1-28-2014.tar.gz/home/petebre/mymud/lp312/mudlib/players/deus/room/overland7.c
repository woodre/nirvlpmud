/* Overland 7 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland6","up",
         MY_PATH+"overland8","south",
         "Southern Drop",
         "  The name Southern Drop is given to this place due to its rapid \n"+
         "descend from the ranges north and east of here . As you have \n"+
         "expected , the name fits this place very well . Looking for the\n"+
         "right directions is most difficult and you frequently have to \n"+
         "back track as you reach dead ends and encounter rock slides .\n"+
         "A small stream is found west of you , disappearing into the deep \n"+
         "gloomy valley below . This is a very dangerous area indeed ...\n",1)

more_reset () {}
