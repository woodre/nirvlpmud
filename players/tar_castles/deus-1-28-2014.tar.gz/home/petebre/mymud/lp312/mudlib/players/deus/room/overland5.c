/* Overland 5 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland4","down",
         MY_PATH+"LAKE/shore1","south",
         "Lake Euston",
         "  To the west , you see the calm water of Lake Euston . A small \n"+
         "number of fishing boats are also seen snailing across the surface\n"+
         "of Euston . Situating on the shore south of you , there is the \n"+
         "pier of those fishermen . Occasion laughter of children can \n"+
         "be distinguished from the screeching of lake gulls . Mountain \n"+
         "ranges beyond a pine forest is to your east . Northern end of the\n"+
         "lake stops at the foot of another range . But beyond that ,\n"+
         "you cannot see from here .\n",1)

more_reset () {}
