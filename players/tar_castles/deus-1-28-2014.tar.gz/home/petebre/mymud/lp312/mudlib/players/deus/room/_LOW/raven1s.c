/* Raven 1 south */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

object mon1 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"raven1","north",
         MY_PATH+"raven3s","west",
         "South of Road",
         "  Going off the road , you have found the place where the ravens \n"+
         "geather . The smell of birds' droppings and rotten corpses makes \n"+
         "you sick . This place is totally disgusting ... \n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/raven") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
