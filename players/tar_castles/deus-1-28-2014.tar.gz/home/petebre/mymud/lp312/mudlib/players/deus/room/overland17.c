/* Overland 17 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland1","east",
         MY_PATH+"_LOW/squirrel1","west",
         "South of Esgalduin",
         "  Many miles of travel has brought you close to the mid-point \n"+
         "of the Esgalduin . You find yourself in a light forest made up\n"+
         "of willow trees which provide some good cover for the weather .\n"+
         "The area is flat , thou you have to clear the path in order to \n"+
         "press on . The river is calm in this part of its course , but \n"+
         "the dark cold water suggests that it is fairly deep . It is \n"+
         "not too wise to try and cross the river here .\n",1)

more_reset () {}
