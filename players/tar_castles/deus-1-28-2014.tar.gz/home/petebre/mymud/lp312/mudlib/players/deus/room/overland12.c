/* Overland 12 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"VILLAGE/village7","north",
         MY_PATH+"overland11","south",
         "Bushes",
         "  Many bushes have grown here along the sides of the road . The\n"+
         "southern side of the area begins to take shape of a forest . \n"+
         "Trees in the northern part of this area have been cleared .\n"+
         "Infact , it seems that there was logging around the area .\n"+
         "Thou you cannot see beyond the turn of the road north of here ,\n"+
         "there is little doubt that somebody must be -- or have been --\n"+
         "living near that area .\n",1)

more_reset () {}
/*
//TWO_EXIT(MY_PATH+"VILLAGE/village7","north",
*/
