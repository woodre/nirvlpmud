/* Overland 16 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"_LOW/squirrel3","east",
         MY_PATH+"overland15","west",
         "Point North",
         "  You are standing on top of the North Point cliff . Below you \n"+
         "runs the Esgalduin , making its way down to the Bay of Heros .\n"+
         "This cliff is the north most area of Exeton , hence the name\n"+
         "North Point is given to it . The road you are on goes east and\n"+
         "west . It leads downwards to somewhat lower grounds of the river\n"+
         "bank . Big boulders and rocks prevent you from going south . Ivy\n"+
         "and moss cover the entire area holding the soil together .\n",1)

more_reset () {}
