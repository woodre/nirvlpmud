/*ISLAND 4*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island3","east",
         MY_PATH+"island5","west",
         "Hilly Trail",
         "  Following the trail , you come to the highest summit of the\n"+
         "surrounding hills.  Fair amount of pine trees have grown here\n"+
         "which gives you some coverage from the chilly wind.  However ,\n"+
         "the same trees are blocking most of the view out.  Looking back\n"+
         "and forth along the trail , you see that the western trail leads\n"+
         "down into the valleys , while the eastern trail takes you across\n"+
         "this stretch of hills.\n",1)

more_reset () {}
