#undef DEST
#define DEST "room/eastroad5"
inherit "/players/deus/class/connect.c" ;

init() {
  add_action("my_get") ; add_verb ("get") ;
  add_action("my_get") ; add_verb("take") ;
  add_action("my_get") ; add_verb("search") ;
  add_action("examine") ; add_verb("exa") ;
  add_action("examine") ; add_verb("examine") ;
  add_action("enter") ; add_verb("peek");
}

reset(arg) {
object open_note ;

  if (!arg) {
    set_id("orb") ;
    set_alias("Orb") ;
    set_short("A crystal Orb") ;
    set_long("A large clear crystal orb ...\n"+
      "How strange that such a valuable item lays here ?\n"+
/* This added to help people figure out how to get in. -Snow 3/00 */
     "Perhaps someone dropped it accidentally.\n"+
     "You feel a compelling urge to 'peek orb'.\n");
    set_get_msg("Your hand passes through the orb!\n") ;
    set_ex_msg("Looking closer, you see some blury images.\n"+
      "They are being projected from within the orb.\n"+
     "Perhaps if you 'peek orb', all will become clear.\n");
    set_destin("x#/players/deus/room/overland14.c") ;
    move_object(this_object(), DEST);
  } ;
  return 1;
}

enter (str) {
object per ;

  per = this_player() ;
/* This area needs serious work. -Snow 3/00 */
write("This area closed for repairs.\n"); return 1;
  if (::enter(str)) {
    tell_object(per,"You suddently without reason get a bad head ache.\n");
    return 1 ;
  } ;
  return 0 ;
}
