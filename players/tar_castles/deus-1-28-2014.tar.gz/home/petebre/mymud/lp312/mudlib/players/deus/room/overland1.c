/* Overland 1 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland2","east",
         MY_PATH+"overland17","west",
         "Crossing",
         "  You are on the southern bank of the river Esgalduin . The\n"+
         "river marks the natural border of Exeton and Sheraton . \n"+
         "Sound of rushing water can be heard clearly at this point .\n"+
         "Willow trees are growing along this side of the bank to as\n"+
         "far as the eyes can see .\n"+
         "A light breez brushes your cheek gently just like the soft hands\n"+
         "of your beloved one ... \n",1)

more_reset () {}
