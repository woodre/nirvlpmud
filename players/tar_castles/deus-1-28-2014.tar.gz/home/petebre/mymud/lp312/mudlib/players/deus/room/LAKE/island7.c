/*ISLAND 7*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island6","out",
         "In Shed",
         "  You are totally captured by the flickering light and the smell\n"+
         "of incense while you make your entrance.  Even with your acute\n"+
         "eyes , you cannot tell what is supporting the light source , \n"+
         "only that it is unsually bright , yet dim at the same time.  It\n"+
         "is floating gracefully in middle of the room and zapping out\n"+
         "waves after waves of light rays.  The light is as bright as ,\n"+
         "if not brighter than white hot metal.  All is but darkness and \n"+
         "quiet to you in this room -- not that you can see or hear much\n"+
         "anyways.\n",1)

more_reset () {}
