/* Raven 3 south */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

object mon1 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"raven3n","north",
         MY_PATH+"raven1s","east",
         "South of road",
         "  As you have expected , you have found more ivy and bushes \n"+
         "behind a large rock . There are also a lot of feathers and \n"+
         "droppings all over the floor . It is totally disgusting to say\n"+
         "the lease .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/raven") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
