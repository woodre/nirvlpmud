/* Raven 1 north */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

object mon1 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"raven1","south",
         MY_PATH+"raven3n","west",
         "Willow trees",
         "  This is a small area immediate south of Esgalduin . \n"+
         "It is a geathering place for the ravens near by as you can tell \n"+
         "from the mess . Plenty of bushes and willow trees are here .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/raven") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
