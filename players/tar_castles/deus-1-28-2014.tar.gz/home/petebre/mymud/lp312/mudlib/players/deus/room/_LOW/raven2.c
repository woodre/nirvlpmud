/* Raven 2 */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"raven1","east",
         MY_PATH+"raven3","west",
         "South of Esgalduin",
         "  Green grass and few willow trees are found around your path .\n"+
         "The bank of Esgalduin is some fifty yards away north of you . \n"+
         "Some bushes and ivy are growing next to both sides of the road .\n"+
         "Leading east and west , you can deduce from the long grass that\n"+ 
         "this road is not used frequently . Willow trees are thinker to \n"+
         "the east . To your west , the area seems rugged and bare .\n",1)

more_reset () {}
