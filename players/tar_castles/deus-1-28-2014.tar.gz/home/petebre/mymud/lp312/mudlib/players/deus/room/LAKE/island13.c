/*ISLAND 13*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island12","east",
         "Sealed Mine",
         "  Upon entering this part of the mine , you see a magical seal\n"+
         "blocking the passage west.  You may however retrace your way back\n"+
         "to the entrance east.\n",0)

more_reset () {}
