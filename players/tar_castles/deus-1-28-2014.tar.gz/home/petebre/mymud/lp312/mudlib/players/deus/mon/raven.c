/* Raven , calling reset with 3 as arg will give you a fire raven */
inherit "/obj/monster.talk" ;
object treasure ;

reset (arg) {
  if (!arg) {
    set_name("raven") ;
    set_level(1) ;
    set_alias("rav") ;
    set_race("bird") ;
    set_short("A black raven") ;
    set_long("You are looking at a giantic raven -- human size . A very \n"+
      "common dweller of Shearton and Exeton -- perhaps a bit too common \n"+
      "to occur natually ... \n") ;
    set_hp(15) ;
    set_al(-200) ;
    set_wc(5) ;
    set_ac(5) ;
    set_aggressive(1) ;
    set_move_at_reset() ;
    set_whimpy() ;
    set_spell_mess1("A red hot fire-ball flew across the room ") ;
    set_spell_mess2("BOOM ! You are hit by a point blank fire-ball  , ouch !");
    set_chance (5) ;
    set_spell_dam (15) ;
    set_chat_chance (5) ;
    load_chat("Squawk ! Squawk !\n") ;
    set_a_chat_chance(5) ;
    load_a_chat("Ha ha ha hah ! The Shadowlord will rise again ...\n") ;
  } ;
  if (random(20) == 0 || arg == 3) {
    set_spell_dam (40) ;
    set_short ("A fire raven") ;
    set_long("Thou unbelieveable , you find youself a fire raven ! \n") ;
  } ;
  if (!present("feather",this_object())) {
    treasure = clone_object("/players/deus/obj/feather.c") ;
    move_object(treasure,this_object()) ;
    if ((this_object()->short() == "A fire raven") && (random (10) > 4)) {
      treasure->set_long("This is a rear fire raven feather !\n") ;
    } ;
    treasure->set_value(30) ;
  } ;
  :: reset(arg) ;
}
