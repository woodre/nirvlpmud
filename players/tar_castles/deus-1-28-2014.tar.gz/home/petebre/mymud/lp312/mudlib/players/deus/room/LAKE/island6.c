/*ISLAND 6*/
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island5","north",
         "End of Trail",
         "  This seems to be a dead end.  As you look , you discover that\n"+
         "a large amount of bushes and golden grass are growing in this\n"+
         "area.  Tall pine trees are also seen further behind the bushes\n"+
         "and surrounding this semi-cleared hillside.  Come to think \n"+
         "about it , you notice that you are standing in the middle of an \n"+
          "opened area with only one escape -- should you be ambushed...\n",1)

more_init () {
  add_action ("search") ;  add_verb ("search") ;
  add_action ("enter") ;  add_verb ("enter") ;
}

search (str) {
  if (str=="bushes") {
    write ("You have found a shed hiden behind the bushes.\n") ;
    say (this_player()->query_name()+" found something .\n") ;
    return 1 ;
  } ;
  if (!str) {
    write ("What do you want to search ?\n") ;
    return 1 ;
  } ;
  return 0 ;
}

enter (str) {
  if (str == "shed") {
  write ("You struggle throught a couple of bushes and entered the shed.\n");
  call_other(this_player(),"move_player","into the shed#"+MY_PATH+"island7") ;
  return 1 ;
  } ;
  write ("What do you want to enter ?\n") ;
  return 1 ;
}

more_reset() {}
