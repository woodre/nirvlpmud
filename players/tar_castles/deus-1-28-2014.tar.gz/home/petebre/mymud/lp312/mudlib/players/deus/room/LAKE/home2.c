/* home2 */
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island24","out",
         "Merchants' Residance",
         "  Thou the merchants in this town are not very rich , they do\n"+
         "own a small house.  By the look of things , it seems like this\n"+
         "place is also used as a warehouse for a shop.  It is filled with\n"+
         "case upon case of items , all stacked up against the wall.\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
