/* Overland 4 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland5","up",
         MY_PATH+"overland3","west",
         "CLiff of Blade",
         "  This is the bottom of the Cliff of Blade . The cliff itself \n"+
         "prevents you from travelling north-east . A river joins the road\n"+
         "leaving this area in a westerly direction . The southward road \n"+
         "leads you over a small range , away from the highest peaks of \n"+
         "the Dagger Range . Large number of pine trees are here .\n",1)

more_reset () {}
