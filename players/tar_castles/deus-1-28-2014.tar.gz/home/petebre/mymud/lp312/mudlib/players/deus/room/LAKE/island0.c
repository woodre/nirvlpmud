/*ISLAND 0*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 , mon2 , mon3 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island1","west",
         "Pier",
         "  You have reached the pier of the island.  The wind is\n"+
         "exceptionally strong and chilly here in the midle of the lake.\n"+
         "A foot path is leaing west into a thin wood of pine.  As you\n"+
         "glance across the rocky terrain, you see several beached\n"+
         "fishing boats.\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  return ;
}
