/* Shore 3 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 , mon2 , mon3 ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"LAKE/shore2","north",
         MY_PATH+"overland6","south",
         "Shore of Euston",
         "  After walking some distance on the fine , white sand along the\n"+
         "shore or Euston , the pier like structure is still some distance\n"+
         "north of you . Activities are limited to those fishing boats \n"+
         "that is moving slowly on the lake . Occasion gusts of wind kick\n"+
         "up the sand , making it difficult to look further ahead .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  return ;
}
