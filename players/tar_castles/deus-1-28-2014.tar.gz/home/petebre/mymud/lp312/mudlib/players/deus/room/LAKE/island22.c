/*ISLAND 22*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island23","west",
         MY_PATH+"island21","east",
         "East End",
         "  As you gaze upon the heavy gates of the town entrance , you\n"+
         "realise that you have come to the north-eastern entrance of \n"+
         "Lake Town.  Looking around , you deduced that this is a young\n"+
         "and small town.  Several houses are still under construction.\n"+
         "The street is very well paved and uncomfortably clean...\n",1)

more_reset () {}
