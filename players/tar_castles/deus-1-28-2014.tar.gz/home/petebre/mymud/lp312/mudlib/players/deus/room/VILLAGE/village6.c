/* Village 6 */
#include "room.h"
#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"village5","north",
         MY_PATH+"village7","south",
         "Outskirt of village",
         "  A few acres of deserted fields are seen in this area . To your\n"+
         "north , you can see an abandoned market place . More fields are\n"+
         "located to your south away from the village . \n",1)

more_reset () {
}
