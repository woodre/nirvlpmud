/* Fog Room */
/* This is a tempory room for connection use . I am using it to filter out
parts of my area until they are ready .
*/
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object stone ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland13","north",
         MY_PATH+"overland12","south",
         "A think fog",
         "  You have come to a thick layer of fog . Visibility is very low\n"+
         "indeed . There is nothing you can do here except to leave .\n",1)
more_reset () {}
