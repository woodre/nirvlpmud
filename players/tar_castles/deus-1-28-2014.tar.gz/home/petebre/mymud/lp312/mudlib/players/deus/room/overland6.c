/* Overland 6 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"LAKE/shore3","north",
         MY_PATH+"overland7","down",
         "Lake Euston",
         "  Long hours of travel have bought you to the southern end of \n"+
         "Lake Euston . The last few peaks of Dagger Range are to your east\n"+
         "behind a thick pine forest . A structure of some kind is located \n"+
         "on the shore of the lake north of you . Looking carefully , the \n"+
         "lake is long and thin . It is bounded by mountain ranges .\n"+
         "Calm water stretches out to the horizon and lays motionless \n"+
         "to your west .\n",1)

more_reset () {}
