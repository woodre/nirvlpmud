/* squirrel 1 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland17","east",
         MY_PATH+"_LOW/squirrel2","west",
         "Plateau",
         "  The road here twists and turns quite a bit but it still follows\n"+
         "its east-west direction . A steady climb east leads to a forest\n"+
         "of some kind while going down hill westward will take you away\n"+
         "from mid course of Esgalduin . The actual river is found some\n"+
         "distance north and below the rocky plateau . Ivy and bushes are\n"+
         "all around you and on both sides of the road .\n",1)

more_reset () {}
