/* Wabbit 3 */
#define SAY(MSG) tell_room(environment(player),MSG);
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

object mon1 , mon2 , mon3 , mon4 , mon5 ;
int trap_type ;
object player ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"wabbit2","east",
         MY_PATH+"wabbit4","west",
         "Green Basin",
         "  Fresh air and green grass surround you as you step further into\n"+
         "the basin which covers most of Exeton . Beyond the southern \n"+
         "bound lays a large area of wasteland . Most of those who fled \n"+
         "south have died there because of the inhabitable terrain and \n"+
         "climate . Green Basin is north bounded by steep valleys of the \n"+
         "Lockleys Mountains . It is also well known that lots of wabbits\n"+
         "are living in the basin bacause of the Golden grass that grow \n"+
         "here . So may be if you search carefully , you can find some of \n"+
         "these wabbits . \n",1)

more_init () {
  add_action ("north") ;
  add_verb ("north") ;
  add_action ("south") ;
  add_verb ("south") ;
  add_action ("search") ;
  add_verb ("search") ;
  add_action ("pray") ;
  add_verb ("pray") ;
}

search (str) {
  if (str=="grass") {
    write ("You have found a path leading north and south .\n") ;
    say (this_player()->query_name()+" found something .\n") ;
    return 1 ;
  } ;
  if (!str) {
    write ("What do you want to search ?\n") ;
    return 1 ;
  } ;
  return 0 ;
}

north () {
  write ("You walked over the long grass .\n") ;
  call_other(this_player(),"move_player","north#"+MY_PATH+"wabbit3n") ;
  return 1 ;
}

south () {
  write ("You walked over the long grass .\n") ;
  call_other(this_player(),"move_player","south#"+MY_PATH+"wabbit3s") ;
  return 1 ;
}

pray () {
  player = this_player() ;
  write ("Nothing happenes .\n") ;
  call_out ("wave1",15) ;
  return 1 ;
}

wave1 () {
  SAY ("Wait ! The ground is shak-ak-aking .\n") ;
  SAY ("The world is fall-all-all-ing apart !!! \n") ;
  SAY ("Run everyone ! Run ! Run !\n") ;
  call_out ("wave2",15) ;
}

wave2 () {
  SAY ("Fools ! So you think you can destory me huh ? \n") ;
  SAY ("Let me show you the way to hell then ! \n") ;
  SAY ("Ha HA HA ha ! Ha HA HA ha !\n") ;
  SAY ("Now I will have your blood !\n") ;

tell_object (player,"You felt a search of power going through your helpless "+
"body .\n"+
"Just when you think you are about to die , \n"+
"A more powerful devine intervension overcame you and swept you "+
"away .\n"+
"Whatever happened , you are sure glad that you live to tell about it .\n") ;
call_other (player,"move_player","x#"+"/room/church") ;
/* call_other (player,"move_player","d#"+MY_PATH+"FORTRESS/chamber1") ;
// move everyone in the same room too 
*/
}

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  if (!mon4 || (environment(mon4)!=this_object())) {
    mon4 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon4 , this_object() ) ;
  } ;
  if (!mon5 || (environment(mon5)!=this_object())) {
    mon5 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon5 , this_object() ) ;
  } ;
  return ;
}
