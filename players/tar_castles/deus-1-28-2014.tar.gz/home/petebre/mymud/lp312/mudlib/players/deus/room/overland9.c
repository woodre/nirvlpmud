/* Overland 9 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"_LOW/wabbit3","east",
         MY_PATH+"overland10","west",
         "Green Basin",
         "  This is the western end of the Green Basin . Judging by the \n"+
         "name alone , you already expect some large area of green grass .\n"+
         "But what you see is just radiculus ! The grass field stretches so\n"+
         "far east that it cannot be seperated from the horizon . Distance\n"+
         "between the sides are so great that you cannot see both of them \n"+
         "without turning your head .\n",1)

more_reset () {}
