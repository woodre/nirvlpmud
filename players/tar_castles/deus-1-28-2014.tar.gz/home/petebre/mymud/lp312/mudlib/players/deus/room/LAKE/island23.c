/*ISLAND 23*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island24","west",
         MY_PATH+"island22","east",
         "East Street",
         "  This is the eastern center of lake town.  The street is\n"+
         "connected -- west -- with the center of the town where a bar is\n"+
         "seen.  A shop can also been seen right next door to the bar on\n"+
         "the northern side of this street.  A house with long brick wall\n"+
         "occupies the other side of this street.  East end of the street\n"+
         "opens up to the town gates east of here.\n",1)

more_reset () {
/* the connector of home1 */
/* connector of shop */
}
