/* A workroom will be as soon as I figure what to do with it .*/
inherit "/room/room.c";
int unlock_stat ;
string person ;
lock(str) {
  if (str == "room" || str == "door") {
    tell_room(this_object(),"Click!\n");
    unlock_stat = 0;
    return 1 ;
  }
  else {
    return 0 ;
  }
}
unlock(str) {
  if (str == "door" || str == "room"){
    tell_room(this_object(),"Clock!\n");
    unlock_stat = 1;
    return 1 ;
  }
  else {
    return 0;
  }
}

init(){
  :: init();
person = this_player()->query_real_name() ;
tell_room(this_object(),person+"\n");
if (person == "deus") {
   tell_room(this_object(),"Welcome\n");
  add_action("lock");
  add_verb("lock");
  add_action("unlock");
  add_verb("unlock");
}
else if (!unlock_stat) {
  tell_room(this_object(),"Intruder alert!\n");
  this_player()->move_player("d#/room/church") ;
}
}
long() {
  write("A simple wizard workroom.\n");
  write("From the mess , you can tell that it belongs to Deus.\n");
}

short() {
  return "Workroom of Deus" ;
}

reset(arg) {
  if (arg) {
    return 1 ;
  } ;
  unlock_stat = 1 ;
  set_light(1);
}
