#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"village3","backup",
         "Fireplace",
         "  Smells of burned ashes and black tar fill the air of this \n"+
         "confining area . It is difficult for you to even turn around \n"+
         "since only your upper torsal is in the room and you are on your\n"+
         "knees . With no sense of direction and a pair of dirty hands, it\n"+
         "is alloying that you are stuck in this position . Standing up is\n"+
         "impossible and much worse if you want to look around .\n",0)

more_init () {
  add_action("move") ; add_verb("backup") ;
  add_action("how_to") ; add_verb("leave") ;
  add_action("how_to") ; add_verb("exit") ;
  add_action("what") ; add_verb("back") ;
  add_action("cannot") ; add_verb("stand") ;
}

more_reset () {no_exits = 1 ;}

move() {
  call_other("/players/deus/obj/burned.c","leave",0) ;
  write ("You are releaved that you got out of that stupid place!\n") ;
  ::move("backup") ;
  return 1 ;
}

how_to() {
  write ("Well , just how do you intend to do that ?\n") ;
  return 1 ;
}

what() {
  write ("Back ? What about it ? It is stuck ...\n") ;
  return 1 ;
}

cannot() {
  write ("Stand ? The head room is too low to stand .\n") ;
  return 1 ;
}
