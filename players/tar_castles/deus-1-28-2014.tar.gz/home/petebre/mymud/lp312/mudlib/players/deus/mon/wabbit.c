/* This file contains the definition of a monster called wabbit . To create one
   just include the file and call the function _make .
*/
inherit "/obj/monster.talk" ;

reset (arg) {
  if (!arg) {
    set_name("Wabbit") ;
    set_level(1) ;
    set_alias("wab") ;
    set_race("wabbit") ;
    set_short("A small hunting wabbit") ;
    set_long("This small animal is a member of the rabbit family .\n"+
    "It is the great great great great grand children of the one , the only\n"+
    "BUGS BUNNY   the magificiant ! Be warned if you are to mess with him .\n"+
    "Sorry people , I know it is way out of context but it is some  thing \n"+
    "I wanted to do for a long time . I promise not to do it again ...\n") ;
    set_hp(15) ;
    set_al(100) ;
    set_wc(5) ;
    set_ac(3) ;
    set_move_at_reset() ;
    set_whimpy() ;
    set_spell_mess1("Acme safe ! CRUNCH !") ;
    set_spell_mess2("You are hit by the ACME safe ."+
      "Wabbit smirks : I lost more hunters than way you know ...\n") ;
    set_chance (5) ;
    set_spell_dam (5) ;
    set_chat_chance (5) ;
    load_chat("Wabbit says : Eh , whatsup ?\n") ;
    load_chat("Wabbit yells : Gradpap ! A stranger is here for you !\n") ;
    set_a_chat_chance(5) ;
    load_a_chat("Wabbit says : Of course you konw this means war ...\n") ;
  } ;
  :: reset(0) ;
}
