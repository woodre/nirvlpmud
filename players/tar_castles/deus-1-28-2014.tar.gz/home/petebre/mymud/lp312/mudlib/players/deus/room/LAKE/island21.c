/*ISLAND 21*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island22","north",
         MY_PATH+"island20","south",
         "Watch Tower",
         "  At the bottom of a deep valley , you find yourself in a thick\n"+
         "pine forest.  The trees around are over thirty feet tall and \n"+
         "cover most of the sky in the area.  By the side of the road ,\n"+
         "you discover a wood build tower.  The road itself is part of a\n"+
         "zig-zag with the north end turning west and the south end \n"+
         "turning sharply east\n",1)

more_reset () {}
