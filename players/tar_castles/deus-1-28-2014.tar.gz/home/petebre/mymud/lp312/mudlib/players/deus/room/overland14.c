/* Overland 14 */
/* This is the main entrance to my area -- a landing pad of the transport .
*/
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland15","north",
         MY_PATH+"overland13","south",
         "Clearing",
         "  Looking all over , you find youself standing in the exact\n"+
         "center of a circle of huge boulders . Faint light rays lit the\n"+
         "southern part of the area , casting long and gloomy shadows of \n"+
         "the boulders on the floor . Looking closely for exits , you find\n"+
         "two distinctive gaps between some of the boulders . One leads \n"+
         "south towards the strange light , the other opens north into a \n"+
         "pitch of total darkness .\n",1)
more_reset () {
  if (!present("stone",this_object())) {
    call_other ("/players/deus/obj/stone" , "reset") ;
/*
    stone->set_one_ring () ;
*/
  } ;
  return ;
}
