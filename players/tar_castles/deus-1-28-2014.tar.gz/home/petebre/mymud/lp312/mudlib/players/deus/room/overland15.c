/* Overland 15 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland16","east",
         MY_PATH+"overland13","south",
         "Sandy Bank",
         "  You have reached the delta of Esgalduin . At this point the \n"+
         "river opens up and flows rapidly into the Bay of Heros north-west\n"+
         "of here . It is quite impossible to cross the river at this point\n"+
         "thou you may want to go up stream a bit and try there . Fine \n"+
         "white sand is everywhere . A strange feeling about castles\n"+
         "fortresses and buckets passes your thought ...\n",1)

more_reset () {}
