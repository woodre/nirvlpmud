/* Overland 10 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland11","north",
         MY_PATH+"overland9","east",
         "Bushes",
         "  The road turns away from the think oak forest south and west \n"+
         "of you . Looking eastward , the trees begin to thin out a bit .\n"+
         "The road that way seems easier to travel on as it slopes gently\n"+
         "down in that direction . The path north will take you into the \n"+
         "rim of a light forest of oak and apple trees . \n",1)

more_reset () {}
