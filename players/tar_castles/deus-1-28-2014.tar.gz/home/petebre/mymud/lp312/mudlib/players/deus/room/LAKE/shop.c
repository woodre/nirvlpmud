/* Shop */
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island23","out",
         "Yenta's Exeortic Goodies",
         "  This is the local general shop.  Looking around , you see all\n"+
         "kinds of items scatered around the place.  The items are not\n"+
         "displayed in any particular fashion or order , that makes it \n"+
         "difficult to find something , perhaps the shopkeep can help.\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
}
