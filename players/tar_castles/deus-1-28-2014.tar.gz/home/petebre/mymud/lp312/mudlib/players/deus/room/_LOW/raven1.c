/* Raven 1 */
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

object mon1 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland3","east",
         MY_PATH+"_LOW/raven2","west",
         "South of Esgalduin",
         "  You are at the edge of a willow forest which is located east\n"+
         "of you . The river north of you is some distance away . You can\n"+
         "make out some movements in the bushes close to the river . At \n"+
         "the same time , you also heard some noises comming out of the \n"+
         "rocks south of here . It could be an ambush ... \n",1)

more_init () {
  add_action ("search") ;
  add_verb ("search") ;
  add_action ("north") ;
  add_verb ("north") ;
  add_action ("south") ;
  add_verb ("south") ;
}

search (str) {
  if (str=="bushes" || str=="rocks") {
    write ("You have found a path leading north and south .\n") ;
    say (this_player()->query_name()+" found something .\n") ;
    return 1 ;
  } ;
  if (!str) {
    write ("What do you want to search ?\n") ;
    return 1 ;
  } ;
  return 0 ;
}

north () {
  write ("You struggled through a couple of bushes . \n") ;
  call_other(this_player(),"move_player","north#"+MY_PATH+"_LOW/raven1n") ;
  return 1 ;
}

south () {
  write ("You walked around the rocks .\n") ;
  call_other(this_player(),"move_player","south#"+MY_PATH+"_LOW/raven1s") ;
  return 1 ;
}

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/raven") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
