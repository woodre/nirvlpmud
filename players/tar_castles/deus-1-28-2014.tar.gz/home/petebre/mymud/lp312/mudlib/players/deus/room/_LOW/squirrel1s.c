/* squirrel 1 south */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"squirrel2s","west",
         "Bushes and Ivy",
         "  Following a small slope , you climbed down to a grass basin .\n"+
         "There is a special glow in the air that you can feel . A warm \n"+
         "breez and some music like sound captured you attention . But to\n"+
         "your dismay , you cannot locate the source for these strange and\n"+
         "wonderful feelings ... May be it is not meant to be disturbed .\n",1)

more_reset () {}
