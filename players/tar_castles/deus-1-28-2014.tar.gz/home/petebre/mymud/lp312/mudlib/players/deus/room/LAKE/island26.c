/*ISLAND 26*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island25","north",
         MY_PATH+"island5","south",
         "South End",
         "  You have come to the south-west entrance of the lake town.\n"+
         "Thou not very wide , the street is clean and well paved by round\n"+
         "pebbles and rocks.  Some houses can be seen north of here -- \n"+
         "further up the north end of the street.  The street ends at the\n"+
         "boundary of town which is marked by tall gates and walls.  A\n"+
         "narrow road continues outside these open gates into a light pine\n"+
         "forest of the valley.\n",1)

more_reset () {}
