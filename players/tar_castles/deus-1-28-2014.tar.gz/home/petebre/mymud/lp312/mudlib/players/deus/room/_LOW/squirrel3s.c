/* Squirrel 3 south */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"squirrel3","north",
         MY_PATH+"squirrel2s","east",
         "South of road",
         "  Going off the road , you find a small patch of Golden grass .\n"+
         "The area is surrounged by small bushes and ivy . Steep valleys to\n"+
         "the south-east and sout-west isolated this area from the rest of\n"+
         "a deeper valley in that general direction . Thou nothing too \n"+
         "interesting is happening here , it provides a nice resting place \n"+
         "for those who have long journeys ahead .\n",1)

more_reset () {}
