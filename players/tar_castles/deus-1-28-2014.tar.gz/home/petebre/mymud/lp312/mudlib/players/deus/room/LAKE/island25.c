/*ISLAND 25*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island24","north",
         MY_PATH+"island26","south",
         "South Street",
         "  This is the southern end of the town center.  East side of \n"+
         "the street is housed.  An archway is found on the western \n"+
         "side of this street.  Smell of food and laughter are comming \n"+
         "from the north end of the street as it turns east , you can\n"+
         "also see a bronce fountain further south down the street.\n",1)

more_reset () {}
