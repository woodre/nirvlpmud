/* Bar */
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
FIVE_EXIT(MY_PATH+"island23","out",
          MY_PATH+"bar0","bar",
          MY_PATH+"bar1","table1",
          MY_PATH+"bar2","table2",
          MY_PATH+"bar3","table3",
         "Serpent's Head",
         "  This dimly lit place seems to be the local bar.  The\n"+
         "place is fairly clean.  A four sided fireplace seperated this\n"+
         "room into the bar and three sections each with a table.  Size\n"+
         "of this establishment suggests that it is the main attraction of\n"+
         "this dull little town.  As a matter of fact , this may be the\n"+
         "biggest bar in the whole of Narvana.\n",1)

more_init () {
  add_action ("check") ; add_verb ("check") ;
  add_action ("address") ; add_verb ("add") ;
}

more_reset () {
/* a sign */
}

check (str) {
  return 1 ;
}

address (str) {
  return 1 ;
}
