/* Village 4 */
#include "room.h"
#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"village3","north",
         MY_PATH+"village5","south",
         "Village Square",
         "  This is a small square of the village . It would have been a \n"+
         "busy place for the villagers . However , a pile of ashes and \n"+
         "skulls in the center of the square has told you what happened in\n"+
         "the last gathering some years ago ...\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/orc2") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
