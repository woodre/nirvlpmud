/* Squirrel 2 north */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"squirrel1n","east",
         MY_PATH+"squirrel3n","west",
         "Higher bank of Esgalduin",
         "  This is the area between the river and the road . More bushes\n"+
         "and ivy grow here on the rocky floor . The bank of the river is\n"+
         "some fifteen feet above the water which flows at a moderate \n"+
         "speed . It is a quiet and peaceful area .\n",1)

more_reset () {}
