/*ISLAND 12*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island13","west",
         MY_PATH+"island11","out",
         "Iron Mine",
         "  You found yourself in an old iron mine.  The iron ore is very\n"+
         "rich here , yet the mine seems abandoned.  Equipments are laying\n"+
         "around -- as if the miners left in a panic.  Listening carefully\n"+
         "you can hear some noises comming from the back of these empty\n"+
         "caves , perhaps it is just echoes of the wind ...\n",0)

more_reset () {}
