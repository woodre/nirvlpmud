/* Overland 8 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland7","north",
         MY_PATH+"_LOW/wabbit3","west",
         "Green Basin",
         "  Acres upon acres of green grass are found to your west . You \n"+
         "have reached the eastern side of the Green Basin . Green as jade \n"+
         "the grass is almost waist height , making your progress slow and \n"+
         "tedious . A mild wind is sweeping across the grass , causing the\n"+
         "stems to wave with a rhythm . Their color changes into different\n"+
         "shades of green and bright yellow as the wind blows .\n",1)

more_reset () {}
