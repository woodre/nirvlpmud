/* level 3 / 4 troll */
inherit "/obj/monster.talk" ;
object treasure ;

reset (arg) {
  if (!arg) {
    set_name("troll") ;
    set_level(3) ;
    set_alias("tro") ;
    set_race("troll") ;
    set_short("A ten foot tall troll") ;
    set_long("A huge troll with muscular arms is looking back at you\n"+
"with a pair of dead fish like eyes.  Unless you want to mess with him\n"+
"it is advisable that you get your butt out as quickly as you can!\n") ;
    set_hp(45) ;
    set_al(-750) ;
    set_wc(7) ;
    set_ac(4) ;
    set_aggressive(1) ;
    set_chat_chance (5) ;
    load_chat("Rooar ! Arroor !\n") ;
    set_a_chat_chance(10) ;
    load_a_chat("Rooar ! Rooar ! Rooar !\n") ;
    load_a_chat("Rooar ! Arroor !\n") ;
  } ;
  if (random(20) == 0 || arg == 3) {
    set_level (4) ;
    set_hp (60) ;
    set_wc (8) ;
    set_short ("A twelve feet tall troll") ;
  } ;
  if (!present("coins",this_object())) {
    treasure = clone_object("/obj/money.c") ;
    move_object(treasure,this_object()) ;
    treasure->set_money(100) ;
  } ;
  :: reset(arg) ;
}
