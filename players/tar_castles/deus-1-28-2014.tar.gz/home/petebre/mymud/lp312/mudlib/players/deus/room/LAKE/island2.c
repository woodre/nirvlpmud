/*ISLAND 2*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island1","north",
         MY_PATH+"island3","south",
         "Rocky Beach",
         "  Big boulders and fishing boats lay here on the beach.  The\n"+
         "path south turns west and up as it leaves the area.  To the\n"+
         "north , you notice a wooden pier stretching out into the lake.\n"+
         "However , you can barely see the foggy lake.  Still further\n"+
         "north sit the dark rocks at the bottom of a steep cliff. \n",1)

more_reset () {}
