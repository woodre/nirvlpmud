/* Bar0 */
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
FOUR_EXIT(MY_PATH+"bar","door",
          MY_PATH+"bar1","table1",
          MY_PATH+"bar2","table2",
          MY_PATH+"bar3","table3",
         "The Bar",
         "  Looking at the shelves behind the bar , you found all sorts of\n"+
         "beverages.  Occasionally , the peephole behind the shelves opens\n"+
         "up and some mysterious person hands out an order of food for \n"+
         "serving.  There is a menu here.\n",1)

more_init () {
  add_action ("check") ; add_verb ("check") ;
  add_action ("address") ; add_verb ("add") ;
}

more_reset () {
/* a sign */
/* a menu */
/* Quen */
}

check (str) {
  return 1 ;
}

address (str) {
  return 1 ;
}
