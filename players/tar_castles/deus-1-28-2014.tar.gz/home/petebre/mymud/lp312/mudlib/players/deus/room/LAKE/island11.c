/*ISLAND 11*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"island12","mine",
         MY_PATH+"island10","south",
         "Upon Red Cliff",
         "  Standing atop of the cliff , you can bearly see the eastern\n"+
         "coast of this island.  A thick layer of fog is covering the dark\n"+
         "lake like a large blanket.  Except for a mine entrance several\n"+
         "yards to yuor north , the only other exit is to your south which\n"+
         "is leading downwards to the coast.  It is running along the edge\n"+
         "of a pine forest.\n",1)

more_reset () {
}
