/* Wabbit 4 */
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

object mon1 , mon2 , mon3 , mon4 , mon5 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"wabbit3","east",
         MY_PATH+"wabbit2","west",
         "Green Basin",
         "  Moving in the grass forest is difficult . You have to hack a\n"+
         "way through the head height grass which frequently gets in your\n"+
         "face . An uneasy feeling comes to you as there is no telling what\n"+
         "might be behind the thick tall grass ... Just be careful . \n",1)

more_init () {
  add_action ("search") ;
  add_verb ("search") ;
  add_action ("north") ;
  add_verb ("north") ;
  add_action ("south") ;
  add_verb ("south") ;
}

search (str) {
  if (str=="grass") {
    write ("You have found a path leading north and south .\n") ;
    say (this_player()->query_name()+" found something .\n") ;
    return 1 ;
  } ;
  if (!str) {
    write ("What do you want to search ?\n") ;
    return 1 ;
  } ;
  return 0 ;
}

north () {
  write ("You walked over the long grass . \n") ;
  call_other(this_player(),"move_player","north#"+MY_PATH+"wabbit4n") ;
  return 1 ;
}

south () {
  write ("You walked over the long grass .\n") ;
  call_other(this_player(),"move_player","south#"+MY_PATH+"wabbit3") ;
  return 1 ;
}

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  if (!mon4 || (environment(mon4)!=this_object())) {
    mon4 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon4 , this_object() ) ;
  } ;
  if (!mon5 || (environment(mon5)!=this_object())) {
    mon5 = clone_object ("/players/deus/mon/wabbit") ;
    move_object ( mon5 , this_object() ) ;
  } ;
  return ;
}
