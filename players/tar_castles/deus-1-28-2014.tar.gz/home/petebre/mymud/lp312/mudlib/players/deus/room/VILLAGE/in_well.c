#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"village2","climb",
         "Dry well",
         "  The moment you landed in the bottom of this dry well , you\n"+
         "began to feel a presence . Although you see nobody in this dimly\n"+
         "lit room , you are certain that you are being watched and that\n"+
         "this is a trap ! Looking up to the mouth of the well , it hits\n"+
         "you that climbing back up is not going to be easy if at all\n"+
         "possible .\n",0)

more_init () {
  add_action("move") ; add_verb("climb") ;
}

move(str) {
  write ("You are releaved that you got out of that stupid place!\n") ;
  ::move("climb") ;
  return 1 ;
}

more_reset () {
  no_exits = 1 ;
  if (!mon1) {
    mon1 = clone_object ("/players/deus/mon/troll3.c") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
