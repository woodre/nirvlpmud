/* A general purpose strap of paper */
string msg ;

init () {
  add_action ("w_msg") ;
  add_verb ("read") ;
}

short() {
  return "A strap of paper" ;
}

long() {
  write ("This is a small piece of paper -- like the ones you find in \n") ;
  write ("fortune cookies .\n") ;
  write ("Something is written on it too ...\n") ;
}

id(str) {
  if ( str == "paper" ) {return 1 ;}
  if ( str == short()) {return 1 ;}
  return 0 ;
}

w_msg (str) {
  if (id(str)) {
    if (environment() == this_player ()) {
      write ("\n"+msg+"\n") ;
      return 1 ; }
    write ("It is kind of hard to read the fine script.\n") ;
    write ("May be you need glasses or something. \n") ;
    return 1 ;
  } ;
}

query_weight() {return 0;}

get() {return 1;}

set_msg (str) {
  msg = str ;
}
