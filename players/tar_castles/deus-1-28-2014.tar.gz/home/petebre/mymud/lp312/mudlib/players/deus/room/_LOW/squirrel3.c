/* Squirrel 3 */
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();
#undef EXTRA_INIT
#define EXTRA_INIT more_init();
#include "/players/deus/room/room.h"

string query_zone () ;
string query_trap_here () ;

object mon1 , mon2 , mon3 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"_LOW/squirrel2","east",
         MY_PATH+"overland16","west",
         "South of Esgalduin",
         "  By the side of the river Esgalduin , this road is going in a \n"+
         "east-west direction . Looking north , you see a number of willow\n"+
         "trees linning the bank of Esgalduin about eighty yards away . \n"+
         "Bushes and ivy are also found next to the sides of the road . \n"+
         "In between these plants , you can ocassionally get a glimpse of\n"+
         "some shifting shadows . Infact , there are many furry squirrels\n"+
         "running around the area , but you must search carefully if you \n"+
         "really want to take a closer look .\n",1)

more_init () {
  add_action ("search") ;
  add_verb ("search") ;
  add_action ("north") ;
  add_verb ("north") ;
  add_action ("south") ;
  add_verb ("south") ;
}

search (str) {
  if (str=="bushes" || str=="ivy") {
    write ("You have found a path leading north and south .\n") ;
    say (this_player()->query_name()+" found something .\n") ;
    return 1 ;
  } ;
  if (!str) {
    write ("What do you want to search ?\n") ;
    return 1 ;
  } ;
  return 0 ;
}

north () {
  write ("You struggled through a couple of bushes . \n") ;
  call_other(this_player(),"move_player","north#"+MY_PATH+"_LOW/squirrel3n") ;
  return 1 ;
}

south () {
  write ("You moved the ivy aside and walked through .\n") ;
  call_other(this_player(),"move_player","south#"+MY_PATH+"_LOW/squirrel3s") ;
  return 1 ;
}

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  return ;
}
