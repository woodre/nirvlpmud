/* Shore 2 */
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 , mon2 , mon3 ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"shore1","north",
         MY_PATH+"shore3","south",
         "Shore of Euston",
         "  You are half way along the eastern shore of Euston . Looking\n"+
         "west , you now see an island some distance in the middle of the\n"+
         "lake . A chilly wind is blowing in from the same direction .\n"+
         "The shore continues to stretch north and south for another \n"+
         "mile or so .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  return ;
}
