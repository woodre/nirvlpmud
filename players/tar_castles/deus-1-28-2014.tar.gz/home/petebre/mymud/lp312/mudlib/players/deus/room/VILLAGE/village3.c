/* Village 3 */
#include "room.h"
#define MY_PATH "/players/deus/room/VILLAGE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"village2","north",
         MY_PATH+"village4","south",
         "Village",
         "  You are on a north-south road going through the village . Some\n"+
         "burn down houses are here . Only stumps of some pillars are \n"+
         "left . This does not seem like the work of normal bandits or \n"+
         "rogues for it is not necessary to burn everything down ...\n",1)

more_reset () {
  call_other ("/players/deus/obj/burned","reset",0) ;
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/orc2") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  return ;
}
