/* Village 7 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"VILLAGE/village6","north",
         MY_PATH+"overland12","south",
         "Outskirt of village",
         "  You have reached the outer rim of a small village . The road\n"+
         "north will take you closer into this village . Trees are thicker\n"+
         "to your south where the road disappears into a small forest .\n",1)

more_reset () {
}
