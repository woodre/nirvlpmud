/*ISLAND 5*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
THREE_EXIT(MY_PATH+"island26","north",
         MY_PATH+"island4","east",
         MY_PATH+"island6","south",
         "Fork of Trail",
         "  The trail opens up to a fork.  The northern trail is singed\n"+
         "and leading into the lower valleys.  A small foot path turns\n"+
         "south and disappears behind some bushes.  The trail east climbs\n"+
         "sharply over some hilly terrain further than you can see.\n",1)

more_reset () {}
