/*
set_id(str)		where str is identifier of the object
set_alias(str)		where str is alternative identifier of object
set_short(str)		where str is name and identifier of the object
set_long(str)		where str is a long description of the object
set_get_msg(str)	where str is a message if player tries to get it
			Do not mix this up with the lfun get which returns 1
			for items that can be picked up . This is considered
			a player command and returns 1 for the successful
			execution of the function .
set_ex_msg(str)		where str is the extra message when the object is
			examined .
			if this is not called , then long description is used
set_mov_msg(str)	where str is a message for player using this connection
set_destin(str)		where str is argument string used for in move_player
			function call .

	To inherit this class , you must also add_verb for examine , exa ,
  get and take , after the corresponding add_action .  You may use the
  origional init and reset defined in this file . That is done by ::init()
  and ::reset(arg) . You may also redefine some of the functions here .
  the file that inherits this object must also define a macro DEST for the
  original reset to work . Object inheriting this class is desinged to be
  loaded by calling reset with 0 hence instead of clonning .

*/
string ident ;
string alias ;
string short_desc ;
string long_desc ;
string get_desc ;
string ex_desc ;
string mov_desc ;
string destin ;

id(str) {
  if (str == ident || str == alias || str == short_desc)
    return 1;
}

short() {
  if(short_desc=="portal")
    return "a portal" ;
  return short_desc ;
}

long() {
  if(!long_desc) {
    write ("There is a strange portal fading in and out of existance.\n") ;
    return 1 ;
   } ;
   write (long_desc) ;
   return 1 ;
}

my_get(str) {
  if (id(str)) {
    if (!get_desc) {
      write("You feel statics and sparks as you approaches "+short()+".\n");
      return 1 ;
    } ;
    write(get_desc);
    return 1 ;
  } ;
}

enter (str) {
object per ;
  if (id(str)) {
    per = this_player() ;
    if(!mov_desc) 
      write("You entered "+short()+".\n") ;
    else
      write(mov_desc);
    this_player()->move_player(destin) ;
    return 1 ;
  } ;
  return 0 ;
}

examine(str) {
  if(!(id(str))) {
    return 0 ; } ;
  if (!ex_desc) {
    long () ;
    return 1 ;
  } ;
  write (ex_desc) ;
  return 1 ;
}

is_castle() {return 1;}

set_id(str) {
  ident = str ;
  return 1 ;
}

set_alias(str) {
  alias = str ;
  return 1 ;
}

set_short(str) {
  short_desc = str ;
  return 1 ;
}

set_long(str) {
  long_desc = str ;
  return 1 ;
}

set_get_msg(str) {
  get_desc = str ;
  return 1 ;
}

set_ex_msg(str) {
  ex_desc = str ;
  return 1 ;
}

set_mov_msg(str) {
  mov_desc = str ;
  return 1 ;
}

set_destin(str) {
  destin = str ;
  return 1 ;
}

init () {
  add_action("my_get") ; add_verb ("get") ;
  add_action("my_get") ; add_verb ("take") ;
  add_action("examine") ; add_verb ("exa") ;
  add_action("examine") ; add_verb ("search") ;
  add_action("examine") ; add_verb ("examine") ;
  add_action("enter") ; add_verb ("enter") ;
}

reset(arg) {
  if (!arg) {
    set_id("portal") ;
    set_short("portal") ;
    set_alias("portal") ;
    set_destin("x#/players/deus/room/overland14.c") ;
    move_object(this_object(),  "/players/deus/workroom.c");
  } ;
  return 1 ;
}
