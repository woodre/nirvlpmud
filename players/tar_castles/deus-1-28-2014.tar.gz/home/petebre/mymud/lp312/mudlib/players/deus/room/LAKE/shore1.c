/* Shore 1 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 , mon2 , mon3 ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland5","north",
         MY_PATH+"LAKE/shore2","south",
         "Shore of Euston",
         "  You are on the eastern shore of Euston . The sand here is\n"+
         "fine , soft and white as snow . The sound of childern is very\n"+
         "clear here , but you can't see any of them . The pier is still\n"+
         "some distance south from here , there does not seem to be any \n"+
         "activity there neither .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  return ;
}
