/* This is a lake gull . It is pretty strong and gives a fight when disturbed

*/
inherit "/obj/monster.talk" ;
object treasure ;

reset (arg) {
  if (!arg) {
    set_name("gull") ;
    set_level(1) ;
    set_alias("gul") ;
    set_race("bird") ;
    set_short("A big white bird") ;
    set_long("This big flyer is a lake gull . A few grey and black feathers\n"+
      "are seen on its back and along the fifteen feet wing span . \n") ;
    set_hp(15) ;
    set_al(100) ;
    set_wc(2) ;
    set_ac(10) ;
    set_move_at_reset() ;
    set_whimpy() ;
    set_spell_mess1("Squawk ! Squawk !") ;
    set_spell_mess2("Lucky it is not a dragon -- you only got a "+
      "beak , two claws but no tail whip . ") ;
    set_chance (5) ;
    set_spell_dam (20) ;
    set_chat_chance (5) ;
    load_chat("The lake gull walks cautiously by you , looking for food .\n");
    load_chat("Movements startled the lake gull and it quickly flies away.\n");
    set_a_chat_chance(5) ;
    load_a_chat("Hey , why don't you pick on someone of your own size ?\n") ;
  } ;
  if (!present("feather",this_object())) {
    treasure = clone_object ("players/deus/obj/feather.c") ;
    move_object (treasure,this_object()) ;
  } ;
  :: reset(0) ;
}
