/* This is a NPC dog named Henry */
inherit "/obj/monster" ;
object tag ;

reset (arg) {
  if (!arg) {
    set_name("puppy") ;
    set_level(1) ;
    set_race("dog") ;
    set_alias("henry") ;
    set_short("A white puppy approx. nine months old") ;
    set_long("A friendly looking puppy that is strangely familiar to you .\n"+
    "You cannot determine when or where you have seen it before ...\n"+
    "Thou it is not leashed , there is a collar around its neck .\n") ;
    set_hp(15) ;
    set_al(100) ;
    set_wc(5) ;
    set_ac(5) ;
    set_whimpy() ;
  } ;
  if (!present("collar",this_object())) {
    tag = clone_object("/players/deus/obj/collar.c") ;
    move_object(tag,this_object()) ;
  } ;
  :: reset(0) ;
}
