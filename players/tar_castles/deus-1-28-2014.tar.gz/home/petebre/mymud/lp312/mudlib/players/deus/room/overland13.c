/* Overland 13 */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland15","north",
         MY_PATH+"VILLAGE/village1","south",
         "Bushes",
         "  Tall bushes and small trees line both side of the road which \n"+
         "winds north and south . To your south the road is wider thou it \n"+
         "still seems unused . The northern view is however obscured by \n"+
         "taller trees and the turn of the road .\n",1)

more_reset () {}
/*
//         MY_PATH+"VILLAGE/village1","south",
*/
