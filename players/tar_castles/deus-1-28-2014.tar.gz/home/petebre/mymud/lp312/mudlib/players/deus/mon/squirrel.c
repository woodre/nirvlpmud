/* A furry squirrel */
inherit "/obj/monster.talk" ;

reset (arg) {
  if (!arg) {
    set_name("Squirrel") ;
    set_level(1) ;
    set_alias("squ") ;
    set_race("squirrel") ;
    set_short("A furry squirrel") ;
    set_long("You see a furry squirrel with a oversize red long tail . \n") ;
    set_hp(15) ;
    set_al(100) ;
    set_wc(5) ;
    set_ac(3) ;
    set_move_at_reset() ;
    set_whimpy() ;
    set_spell_mess1("Someone got nailed by a big acorn ! Ouch !") ;
    set_spell_mess2("A giant acorn flew by and smashed your face in !") ;
    set_chance (5) ;
    set_spell_dam (10) ;
    set_chat_chance (5) ;
    load_chat("The squirrel waves its tail and spins frantically about .\n") ;
    set_a_chat_chance(5) ;
    load_a_chat("Humm , it is virtuous to hurt harmless animals ?\n") ;
  } ;
  :: reset(arg) ;
}
