/* Squirrel 2 south */
#include "room.h"
#define MY_PATH "/players/deus/room/_LOW/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

object mon1 , mon2 , mon3 , mon4 , mon5 ;
int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"squirrel1s","east",
         MY_PATH+"squirrel3s","west",
         "Big Rock",
         "  Behind the big boulders , you find a small patch of Golden \n"+
         "grass . The name is given to this plant because of the bright\n"+
         "orange and yellow tips . They wave in the wind like glittering \n"+
         "gold under the sun .\n",1)

more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon1 , this_object() ) ;
  } ;
  if (!mon2 || (environment(mon2)!=this_object())) {
    mon2 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon2 , this_object() ) ;
  } ;
  if (!mon3 || (environment(mon3)!=this_object())) {
    mon3 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon3 , this_object() ) ;
  } ;
  if (!mon4 || (environment(mon4)!=this_object())) {
    mon4 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon4 , this_object() ) ;
  } ;
  if (!mon5 || (environment(mon5)!=this_object())) {
    mon5 = clone_object ("/players/deus/mon/squirrel") ;
    move_object ( mon5 , this_object() ) ;
  } ;
  return ;
}
