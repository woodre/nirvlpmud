/* Village 1 -- the outter rim of the small destoryed settlement */
#include "room.h"
#define MY_PATH "/players/deus/room/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
TWO_EXIT(MY_PATH+"overland13","north",
         MY_PATH+"VILLAGE/village2","south",
         "Outskirt of village",
         "  This is the outer rim of some small settlement . To the south\n"+
         "there is an old well and some fields . Remains of a stone hut is\n"+
         "within your sight in the same direction . The wood north of a\n"+
         "green knoll can also be located from here . There is however no\n"+
         "sign of activity at all .\n",1)

more_reset () {}
