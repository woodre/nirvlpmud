/* fortress 1 */
#include "room.h"
#define MY_PATH "/players/deus/room/FORTRESS/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"fortress2","north",
         "Courtyard",
         "  Deep inside the fortress of Mordof , you have now reached the\n"+
         "strong hold of his .  Surrounded by heavy gates and gloomy walls\n"+
         "you stand in this courtyard infront of the dreaded tower of none\n"+
         "but the Shadowlord himself .  Dead ahead and high above lays \n"+
         "your destiny ...\n",1)

more_reset () {}
