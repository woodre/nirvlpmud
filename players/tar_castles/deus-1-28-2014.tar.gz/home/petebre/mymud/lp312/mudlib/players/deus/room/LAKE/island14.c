/*ISLAND 14*/
#include "room.h"
#define MY_PATH "/players/deus/room/LAKE/"
#undef EXTRA_RESET
#define EXTRA_RESET more_reset();

string query_zone () ;
string query_trap_here () ;

int trap_type ;
object mon1 ;

query_zone () { return "deus" ; }
ONE_EXIT(MY_PATH+"island13","east",
         "Deep Mine",
         "  After a long and narrow passage , the path opens up to a caven\n"+
         "with a large underground pool.  Darkness , cold air and strange\n"+
         "noises sends chills down your spine.  Looking all around , you \n"+
         "can only make out the entrance to this caven located east of you\n"+
         "-- probably the only exit and escape route for this area.\n",0)
more_reset () {
  if (!mon1 || (environment(mon1)!=this_object())) {
    mon1 = clone_object ("/players/deus/mon/gull") ;
    move_object ( mon1 , this_object() ) ;
  } ;
}
