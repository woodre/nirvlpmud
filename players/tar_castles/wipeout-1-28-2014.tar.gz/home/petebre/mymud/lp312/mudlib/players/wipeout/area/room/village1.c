/* File: /players/wipeout/area/room/village1.c
   Author: Wipeout@Nirvana
   Copyright(c) 2006 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 11/26/06 */
   
#include <ansi.h>
inherit "/room/room.c";

reset(arg){
object woman;
int i;
if(arg)return;
set_light(1);
long_desc=
"	As you enter the village, your arrival provides for mixed feelings\n\
by the inhabitants.  While the children curiously examine you, the\n\
bulky women suspiciously eye your every move.  You seem to be walking\n\
along an unpaved dirt road, with rows of teepees lining either side.\n\
You may enter the nearest teepee walk further north down the road, or\n\
leave this place.\n";

items=({
"children",
"Children wander here and there, playing a form of soccer.",
"women",
"The women are wearing simple attire, and eye you suspiciously while\n\
tending to their duties.\n",
"road",
"A worn dirt road.\n",
"teepee",
"A simple wood-supported structure that is covered in painted animal\n\
hide.  It has a hole in the top that is emitting smoke.\n"
});

woman=clone_object("/players/wipeout/area/npc/woman1.c");

for(i=0;i<3;i++)
{
	move_object(move_object(clone_object("/players/wipeout/area/npc/woman1.c"),this_object()));
}	

dest_dir=({
	"/players/wipeout/area/room/teepee1","teepee",
	"/players/wipeout/area/room/village2","north",
	"/players/wipeout/area/room/outside","leave",
	});
}
	
short(){
	return "An Indian Village";
}
