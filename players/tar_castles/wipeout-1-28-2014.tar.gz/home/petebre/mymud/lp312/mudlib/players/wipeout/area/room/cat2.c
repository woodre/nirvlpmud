/* File: /players/wipeout/areas/catacomb/cat2.c
   Author: Wipeout@Nirvana
   Copyright(c) 2006 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 11/26/06 */
   
#include <ansi.h>
inherit "/room/room.c";

reset(arg){
object skeleton;
int i;
if(arg)return;
set_light(0);
long_desc=
"	As you manage your way down the slippery stairway, you feel an\n\
uneasy presence.  The room you have entered has no source\n\
of light, save the glow of the stairs and further down the tunnel,\n\
but the watery muck that somewhat constrains your movement\n\
still remains.  You feel a ripple in the water, and sense you are\n\
not alone.  You may either attempt to climb the stairs or walk further\n\
down the tunnel to the north.\n";
items=({
  "muck",
  "A gooey mud-like substance that has sunk into your boots.\n",
  "stairs",
  "Slippery stairs from the place you came.\n"
});

skeleton=clone_object("/players/wipeout/area/npc/skeleton1.c");

for(i=0;i<2;i++)
{
	move_object(move_object(clone_object("/players/wipeout/area/npc/skeleton1.c"),this_object()));
}

dest_dir=({
  "/players/wipeout/area/room/catacomb1","climb",
  "/players/wipeout/area/room/catacomb3a","north"
});

short_desc = "The "+HIK+"Catacomb"+NORM;
} 