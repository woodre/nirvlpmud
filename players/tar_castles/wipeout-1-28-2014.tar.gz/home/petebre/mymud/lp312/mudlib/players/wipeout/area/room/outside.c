/* File: /players/wipeout/areas/native/outside
Author: Wipeout@Nirvana
   Copyright(c) 2006 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 11/26/06 
*/
   
#include <ansi.h>
inherit "/room/room.c";	

void reset(int arg){
if(arg)return;
set_light(1);
long_desc=
"	You are on the outskirts of a Comanche Indian camp, a tribe of fierce\n\
warriors and diplomatic traders located on the Southern Plains.  You see\n\
the women working on buffalo skins, tanning and finishing them out to\n\
be buffalo robes, but notice a lack of men.  You notice numerous\n\
amounts of teepees, each equipped with their own drying wrack.\n\
The smell of raw meat permeates in the air, while you hear the\n\
dull hum of a working village.\n";

items=({
"women",
"Several groups of tediously working individuals dressed in simple\n\
hide clothing.  You would probably be better off not bothering them",
"skins",
"Skins from the hides of freshly slain buffalo",
"teepee",
"Cone-shaped shelters with various symbols painted upon them.  Created\n\
out of stretched hide, the teepee makes for a very good shelter",
"wrack",
"Wracks attatched to the teepees are used for drying various meats into\n\
edible strips"
});

dest_dir=({
	"/players/wipeout/area/room/village1","enter"
	});
}
	

cmd_smell(str){
	write("Your mouth waters with the smell of rare meat.\n");
	return 1;
	}

	
short(){
return "Outside an Indian Village";
}