/* File: /players/wipeout/area/room/catacomb3.c
   Author: Wipeout@Nirvana
   Copyright(c) 2006 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 5/21/07 */

   
#include <ansi.h>

inherit "/room/room.c";


void reset(int arg){
if(arg) return;
set_light(1);

long_desc=
"   The disgusting muck is getting deeper the further in you walk.\n\
The only source of light is the "+GRN+"green"+NORM+" torch that continues\n\
to burn on an unknown source. Like the entrance, there are hooks\n\
and chains attached to various parts of the slimy walls that hold\n\
skeletal remains aloft.  Despite their emptiness, they radiate with\n\
a strange aura that is not to be underestimated.  You may go back to\n\
where you came or walk further down the tunnel.\n";


items=({
	"torch",
	"A foot long post with a cup-like attachment on top that is holding a\n\
	green flame that seems to be fueled by unknown reagants in the atmosphere.\n",
	"remains",
	"The skeletal structures of previously living human beings.\n\
	They seem a bit more lively than one might presume...\n"
	});
	
	dest_dir=({
	"/players/wipeout/area/room/catacomb4","north",
	"/players/wipeout/area/room/catacomb2","south"
	});
	}
	
	cmd_smell(str){
	write("Your nostrils sting with the odor of decaying flesh.\n");
	return 1;
	}
	cmd_listen(str){
	write("You hear the slow drip of water, as well\n"+
	"as a dull hum all around you.\n");
	return 1;
	}
	/*add_action("cmd_smell","smell");
	add_action("cmd_listen","listen");
	*/
	
	short(){
		
	return "The "+HIK+"Dark"+NORM+" Catacomb";
	}
	