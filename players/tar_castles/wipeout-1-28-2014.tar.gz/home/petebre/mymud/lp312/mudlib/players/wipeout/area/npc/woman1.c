/* File: /players/wipeout/areas/npc
   Author: Wipeout@Nirvana
   Copyright(c) 2006 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 11/26/06 
   Notes: creation based off of /open/angel/bat.c*/

   
#include <ansi.h>  
inherit "/obj/monster";


void reset(int arg)
{
object armor;
::reset(arg);

if(arg)
	return;

set_name ("A Comanche woman");
set_short ("A Comanche woman");
set_race ("woman");
set_long ("This is the typical Comanche woman.  She wears a primitive loin cloth\n\
and a "+CYN+"turquoise"+NORM+" necklace.  She seems a bit uneasy.\n");
set_level(4);
set_ac(3);
set_wc(8);
set_al(0);
set_hp(55+random(10));
set_gender("female");
set_dead_ob(this_object());
set_aggressive(0);
set_chat_chance(5);
 load_chat("The woman slices some meat.\n");
 load_chat("The woman eyes you suspiciously.\n");
armor=clone_object("/players/wipeout/area/obj/tneck.c");
move_object(armor,this_object());
}
monster_died()
{
say("Woman dies.");
}

