/* File: /players/wipeout/areas/npc
   Author: Wipeout@Nirvana
   Copyright(c) 2006 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 11/26/06 
*/

#include <ansi.h>  
inherit "/obj/monster";


void reset(int arg)
{
object weapon;
::reset(arg);

if(arg)
	return;

set_name ("skeleton");
set_short ("A "+HIK+"Dark"+NORM+" Skeleton");
set_race ("skeleton");
set_long ("This is a "+HIK+"dark"+NORM+"-boned skeleton. There is a fiery "+GRN+"green\n\
glow"+NORM+" emitted from it's round eyes, and it has the look of a killer.\n");
set_level(20);
set_ac(17);
set_wc(30);
set_al(-500);
set_hp(490+random(10));
set_gender("skeleton");
set_dead_ob(this_object());
set_aggressive(1);
weapon=clone_object("/players/wipeout/area/obj/sksword.c");
move_object(weapon,this_object());

}
monster_died()
{
say("As the skeleton drops to the ground, he crumbles to a pile of bones.");
}

