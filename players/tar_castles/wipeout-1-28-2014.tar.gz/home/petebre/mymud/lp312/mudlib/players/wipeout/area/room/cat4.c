/* File: /players/wipeout/area/room/cat4.c
   Author: Wipeout@Nirvana
   Copyright(c) 2007 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 5/21/07 */

   
#include <ansi.h>

inherit "/room/room.c";


void reset(int arg){
if(arg) return;
set_light(1);

long_desc=
"   The stair set has emerged into a somewhat open tunnel, \n\
lit with the same "+GRN+"green"+NORM+"torches. This tunnel is lined with\n\
stone doors that seem somewhat dormant.  Despite the floors and walls\n\
somewhat cleaner, a rancid stench stings the nostrils.  You may either\n\
go into the main section of the tunnel or back down the stairs.\n";


items=({
	"torch",
	"A foot long post with a cup-like attachment on top that is holding a\n\
	green flame that seems to be fueled by unknown reagants in the atmosphere.\n",
	"doors",
	"Why don't you move closer?\n"
	});
	
	dest_dir=({
	"/players/wipeout/area/room/catacomb5","north",
	"/players/wipeout/area/room/catacomb3","south"
	});
	}
	
	
	short(){
		
	return "The "+HIK+"Dark"+NORM+" Catacomb";
	}
	