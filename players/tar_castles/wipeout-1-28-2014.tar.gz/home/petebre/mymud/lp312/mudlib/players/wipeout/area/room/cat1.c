/* File: /players/wipeout/area/room/catacomb1.c
   Author: Wipeout@Nirvana
   Copyright(c) 2006 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 11/22/06 */

   
#include <ansi.h>

inherit "/room/room.c";


void reset(int arg){
if(arg) return;
set_light(1);

long_desc=
"  As you enter this dank catacomb, your boots fill up with a watery\n\
muck.  The eerie "+GRN+"green"+NORM+" glow emitted from the torches on the\n\
slimy walls sends a chill down your vertibrae.  There are hooks\n\
and chains attached to various parts of the slimy walls that constrain\n\
the skeletal remains from grasping your soul.  You get the feeling that\n\
you are not alone in this place.There is a dark stairway leading down to\n\
the northwest, and a narrow passage leading putside the catacomb.\n";

items=({
	"torch",
	"A foot long post with a cup-like attachment on top that is holding a\n\
	green flame that seems to be fueled by unknown reagants in the atmosphere.\n",
	"torches",
	"A foot long post with a cup-like attachment on top that is holding a\n\
	green flame that seems to be fueled by unknown reagants in the atmosphere.\n",
	"remains",
	"The skeletal structures of previously living human beings.\n\
	They seem a bit more lively than one might presume...\n"
	});
	
	dest_dir=({
	"/players/wipeout/area/room/catacomb2","northwest",
	"/players/wipeout/area/room/catacomb0","exit"
	});
	}
	
	cmd_smell(str){
	write("Your nostrils sting with the odor of decaying flesh.\n");
	return 1;
	}
	cmd_listen(str){
	write("You hear the slow drip of water, as well\n"+
	"as a dull hum all around you.\n");
	return 1;
	}
	/*add_action("cmd_smell","smell");
	add_action("cmd_listen","listen");
	*/
	
	short(){
		
	return "The entrance of a "+HIK+"Dark"+NORM+" Catacomb";
	}
	