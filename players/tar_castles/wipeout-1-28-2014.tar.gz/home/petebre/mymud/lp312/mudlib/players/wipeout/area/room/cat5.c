/* File: /players/wipeout/area/room/cat5.c
   Author: Wipeout@Nirvana
   Copyright(c) 2007 Wipeout (Bradley McArthur)
   			All Rights Reserved
   Source: 5/21/07 */

   
#include <ansi.h>

inherit "/room/room.c";


void reset(int arg){
if(arg) return;
set_light(1);

long_desc=
"  This is a very clean cut tunnel, for both the ceiling and the floor\n\
are carved quite evenly.  There are stone doors, to the west and east,\n\
and though very dense, seem to be levitating, and thus, easy to move.\n\
The stench of decaying flesh is flooding your nostrils.  You may\n\
go back to where you came or enter one of the doors.\n";


items=({
	"doors",
	"These are very dense stone doors.  The have a blue glow.\n"
	});
	
	dest_dir=({
	"/players/wipeout/area/room/catacomb6","west",
	"/players/wipeout/area/room/catacomb7","east",
	"/players/wipeout/area/room/catacomb4","south"
	});
	}
	
	
	short(){
		
	return "The "+HIK+"Dark"+NORM+" Catacomb";
	}
	