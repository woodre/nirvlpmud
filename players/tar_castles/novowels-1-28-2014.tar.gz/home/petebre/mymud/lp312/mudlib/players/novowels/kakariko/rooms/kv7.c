      /* Kakariko Village */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This is the eastern edge of Kakariko Village.  A stone path   \n"+
 " runs north to south, leading along the edge of a small pond.    \n"+
 " To the west, the path widens into a large clear area.  Directly \n"+
 " off the path is a small one-room house, but the yard in front   \n"+
 " of it is wildly choked with weeds and brush. \n";

items=({
 "pond","A serene pond blocks your movement to the east",
 "path","White and blue stones make a path running north-south",
 "house","A small brownish house, it is in a state of disrepair",
 "yard","The yard is a veritable jungle.  The weeds completely block the house",
 "weeds","The weeds don't look particularly tough.. One slash and they would be down",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv4","north",
 "/players/novowels/kakariko/rooms/kv6","west",
 "/players/novowels/kakariko/rooms/kv10","south",
             });  

  }   }