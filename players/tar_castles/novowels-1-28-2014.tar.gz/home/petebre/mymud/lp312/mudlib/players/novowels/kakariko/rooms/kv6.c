      /* center of kak vill! */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   The cobblestone paths converge and expand here, paving the    \n"+
 " whole central section of the village.  There is a small wooden  \n"+
 " stand set up in the center of the paved area and wooden benches \n"+
 " are arranged in front of it.  Along the eastern edge of the     \n"+
 " pavement is a smallish fenced-in area that contains a large     \n"+
 " weathervane. \n";

items=({
 "path","The paths become one large paved area",
 "area","The area is paved",
 "benches","Wooden benches set up in rows",
 "stand","A small wooden stand set up in front of some benches",
 "fence","A short, square stone fence",
 "weathervane","A tall weathervane with a statue of a bird on it\n",
 "bird","An extremely lifelike carving of a bird on top of the weathervane",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv9","south",
 "/players/novowels/kakariko/rooms/kv5","west",
 "/players/novowels/kakariko/rooms/kv7","east",
             });  

  }   }