      /* old lady 'n swifty here */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This is the lower center of Kakariko Village.  A stone path    \n"+
 " runs east to west, leading directly from one side of the village \n"+
 " to the other.  Directly to the north of the path is a tidy, well \n"+
 " kept yard containing a small house.  There is a well-swept sandy \n"+
 " patch right in front of the door to the house.  Behind the house \n"+
 " is a large paved area. \n";

items=({
 "path","The path travels in a straight line, east to west",
 "house","The house is small but tidy looking",
 "patch","A clean, sandy patch directly in front of the house",
 "door","The thick wooden door is unlocked, and swings open at a touch",
 "area","A large paved area off to the north",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv6","north",
 "/players/novowels/kakariko/rooms/kv10","east",
 "/players/novowels/kakariko/rooms/kv8","west",
             });  

  }   }