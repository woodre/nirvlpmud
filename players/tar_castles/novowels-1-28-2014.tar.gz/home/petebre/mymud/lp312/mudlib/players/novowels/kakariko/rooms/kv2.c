      /* Still to add: tree thing */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This corner of the village is mostly empty.  There are no    \n"+
 " houses, and the paths are clean but not well-traveled.  There  \n"+
 " is a dropoff to the south, but a gradual slope has been beaten \n"+
 " down making a path.  An old crumbling stone well sits next to  \n"+
 " the path.  The trees thin out to the north, making a small     \n"+
 " indent into the thick woods.\n";

items=({
 "ground","The ground is covered with tufts of green grass",
 "grass","The grass is somewhat overgrown in this section of town",
 "path","A path beaten down through the cliff face.  It leads south",
 "well","A crumbling old well made of grey stone.  It appears to be dry",
 "trees","The forest to the north is thick with trees, there is a small indent between the trees",
 "forest","A forest to the north.  It is filled with trees and covered in mist",
 "indent","It leads north",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv0","north",
 "/players/novowels/kakariko/rooms/kv5","south",
 "/players/novowels/kakariko/rooms/kv3","east",
             });  

  }   }