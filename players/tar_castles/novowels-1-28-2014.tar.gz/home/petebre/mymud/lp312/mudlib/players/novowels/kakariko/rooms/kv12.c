      /* sw corner of KV */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This is the southwestern corner of Kakariko village.  Thick \n"+
 " woods frame the corner of the village.  A white cobblestone   \n"+
 " path leads north and east, framing a small shack within a     \n"+
 " fenced-in yard.  The fence runs lateral to the path behind the  \n"+
 " shack and yard. \n";

items=({
 "woods","The woods frame the corner of the village",
 "path","A white cobblestone path makes a 90 degree turn here, leading north and east",
 "fence","A wooden fence runs lateral to the eastern path",
 "shack","A small white shack.  You could enter it",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv8","north",
 "/players/novowels/kakariko/rooms/kv13","east",
              });  

  }   }