      /* add pub entrance */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   South-central Kakariko village.  This whole section of town \n"+
 " is taken up by a large building that stretches from here to   \n"+
 " the north.  A white cobblestone path runs east-west in front  \n"+
 " of the entrance.  Trees grow thickly to the south, blocking   \n"+
 " that way. \n";

items=({
 "building","This is the largest building in town, there is a banner over the door",
 "banner","\n\t The Duck's Down \n\t\t Kakariko Pub\n",
 "path","A white cobblestone path runs east-west",
 "trees","Thick forest blocks the way south",

        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv14","east",
 "/players/novowels/kakariko/rooms/kv12","west",
              });  

  }   }