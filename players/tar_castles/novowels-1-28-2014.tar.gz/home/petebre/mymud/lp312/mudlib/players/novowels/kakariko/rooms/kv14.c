      /* add a tree foo! */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This is the southeast corner of Kakariko Village.  A sturdy  \n"+
 " wooden archway frames the way out of the village to the south. \n"+
 " Two cobblestone paths skirt the area, before splitting off and \n"+
 " leading to the north and west.  There is a very large building \n"+
 " to the west, and thick forest blocks the way east. \n";

items=({
 "archway","A sturdy wooden archway extends over the paths",
 "path","There is a path heading west and a path heading north",
 "paths","Cobblestone paths circle the area",
 "building","You can see a very large building to the west",
 "forest","The trees to the east grow so close together you can't get through",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv10","north",
 "/players/novowels/kakariko/rooms/kv13","west",
 "/players/novowels/kakariko/rooms/kv16","south",
              });  

  }   }