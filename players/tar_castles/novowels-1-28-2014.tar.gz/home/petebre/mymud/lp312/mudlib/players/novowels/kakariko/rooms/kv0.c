      /* Eventually will be the entrance to the Lost Woods. */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Hyrule";
 long_desc=
 "   The trees thin out some, creating a small indentation into     \n"+
 " the woods.  The trees grow together thickly to either side,      \n"+
 " blocking off all directions except to the south.  A thick grey   \n"+
 " mist seeps down from the northern woods and casts the view       \n"+
 " north into an unnatural darkness.    \n";

items=({
 "forest","The trees of the forest grow thickly together",
 "trees","Large, sturdy trees topped with green leaves",
 "leaves","The leaves are a dark green, and the trees are thick with them",
 "ground","The ground is covered with tufts of green grass",
 "grass","The grass is not exceedingly high, but it is very green",
 "mist","The mist permeates all of the forest to the north.  It almost seems solid",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv2","south",
             });  

  }   }