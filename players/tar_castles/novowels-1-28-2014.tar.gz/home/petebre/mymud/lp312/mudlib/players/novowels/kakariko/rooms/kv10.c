      /* add a tree and a sign */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   The eastern edge of Kakariko Village.  This is a 4-way    \n"+
 " intersection leading through a small break between the pond \n"+
 " to the northeast and the forest to the southeast, along the \n"+
 " edge of the village leading north-south, and through the    \n"+
 " center of the village going east-west. \n";

items=({
 "paths","The paths branch off into all four cardinal directions",
 "pond","A serene pond to the northeast keeps you from going in that direction",
 "forest","The forest to the southeast keeps you from going in that direction",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv7","north",
 "/players/novowels/kakariko/rooms/kv14","south",
 "/players/novowels/kakariko/rooms/kv11","east",
 "/players/novowels/kakariko/rooms/kv9","west",
             });  

  }   }