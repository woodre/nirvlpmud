      /* Still to add: tree shit, readable sign */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   The northeastern corner of Kakariko Village, and the portal    \n"+
 " between the town and the rest of the kingdom of Hyrule.  A white \n"+
 " cobblestone path starts here and heads southward.  There is a    \n"+
 " large house off to the west, and a pond to the east.  The path   \n"+
 " south leads deeper into the town. \n";

items=({
 "pond","A deep pond blocks movement to the east",
 "ground","Except for the stone path, the ground is covered with green grass",
 "grass","The grass is well tended and very green",
 "path","A white stone path that starts near the archway and heads south",
 "archway","A sturdy looking wooden archway over the path to the north",
 "house","You can see the eastward wall of a large house",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv1","north",
 "/players/novowels/kakariko/rooms/kv7","south",
 "/players/novowels/kakariko/rooms/kv3","west",
             });  

  }   }