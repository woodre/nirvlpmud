/* A chicken! */

#include <ansi.h>
inherit "/obj/monster";

reset(arg){ 
    if(arg) return;
	::reset(arg);

set_name("chicken");
set_alias("fowl");
set_short("A chicken");
set_race("bird");
set_long(
  "A fairly large specimen of chicken, with bright white feathers and a \n"+
  "dark yellow beak.  The useless wings on the chicken flap as it hops \n"+
  "around in the grass, clucking and pecking at the ground. \n\n");

set_level(5);
set_ac(20);
set_wc(10);
set_hp(random(20)+75);
set_al(0);
set_aggressive(0);

set_chat_chance(5);
 load_chat("The chickens clucks loudly. \n");

set_a_chat_chance(15);
 load_a_chat("The chicken runs around in a panic! \n");

set_chance(10);
set_spell_dam(random(10)+5);
 set_spell_mess1("The chicken pecks its opponent angrily!");
 set_spell_mess2("The chicken pecks you angrily!");

           }


