      /* flower garden section.  weed the garden for random shit? */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This is the western edge of Kakariko Village.  A stone path   \n"+
 " runs north to south, leading along the fringe of a thick forest \n"+
 " to the west.  The path branches off east here, making a 'T'     \n"+
 " intersection.  In the crook of the 'T' is a large flowerbed     \n"+
 " surrounded by a low wooden fence. \n";

items=({
 "path","The path makes a 'T' intersection here, leading north, south, and east",
 "forest","The forest to the west is so thick as to to be impassable",
 "flowerbed","Patches of flowers that have yet to come into bloom",
 "flowers","Flowers sown in rows.  They are not blooming yet",
 "fence","A low wooden fence more for aesthetics than to keep anyone out",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv9","east",
 "/players/novowels/kakariko/rooms/kv5","north",
 "/players/novowels/kakariko/rooms/kv12","south",
             });  

  }   }