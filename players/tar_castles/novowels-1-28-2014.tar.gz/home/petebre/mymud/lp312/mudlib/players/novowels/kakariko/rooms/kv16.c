      /* (c) Novowels */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Hyrule";
 long_desc=
 "   You are just south of Kakariko Village.  This section of     \n"+
 " Hyrule is full of hills and cliffs.  Trees dot the landscape   \n"+
 " sporadically, except to the east where it is heavily forested. \n"+
 " The ground rises and falls gradually enough to make movement   \n"+
 " fairly easy, although the only places to go seem to be two     \n"+
 " smallish buildings to the west and southwest. \n";

items=({
 "village","Kakariko Village is north of here",
 "hills","Rolling hills to the south and west",
 "cliffs","Some of the hills end in sharp dropoffs, making travel too far from here hazardous",
 "trees","A few lone trees grow in various places",
 "forest","A thick forest blocks your way east",
 "buildings","There's a small building to the west and another to the southwest",
 "ground","Rolling hills covered in green grass",
 "grass","Thick grass covers the ground",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv14","north",
 "/players/novowels/kakariko/rooms/kv15","west",
 "/players/novowels/kakariko/rooms/kv17","southwest",
              });  

  }   }