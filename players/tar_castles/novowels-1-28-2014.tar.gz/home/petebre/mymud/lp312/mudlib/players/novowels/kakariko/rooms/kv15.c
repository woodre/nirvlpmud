      /* library here */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Hyrule";
 long_desc=
 "   The ground is ridged and bumpy, creating crevices and cliffs \n"+
 " that make traversing the area difficult.  A wooden building    \n"+
 " sits in a relatively clear area atop a small hill and keeps    \n"+
 " you from going west.  Trees keep you from moving north and a   \n"+
 " dropoff keeps you from moving south.  The only direction clear \n"+
 " is to the east.  \n";

items=({
 "ground","The ground rises and falls haphazardly around here",
 "crevices","Deep gouges in the ground makes you watch where you step",
 "cliffs","The ground rises up in places from 3 to 10 feet high",
 "hill","A smallish hill on the western edge of the area.  There's a building on it",
 "building","A simple, rustic wooden building.  You could enter it",
 "dropoff","The ground drops sharply away to the south.  There's no way around it",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv16","east",
              });  

  }   }