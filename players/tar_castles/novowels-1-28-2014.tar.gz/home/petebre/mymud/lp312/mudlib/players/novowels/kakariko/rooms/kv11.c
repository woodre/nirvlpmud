      /* smithy cabin, etc */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   You are in a small yard outside Kakariko Village.  There is   \n"+
 " a sturdy-looking log cabin here, with smoke billowing out of    \n"+
 " its chimney.  Logs are piled up against the side of the cabin,  \n"+
 " and there is a stone well in the corner of the yard.  A garden  \n"+
 " is fenced off along the southern edge, which turns into a thick \n"+
 " woods. \n";

items=({
 "cabin","A sturdy-looking log cabin",
 "chimney","Puffs of white smoke drift lazily from the chimney",
 "smoke","The smoke drifts away in the wind..",
 "logs","A pile of logs set up against the wall of the cabin -- firewood most likely",
 "well","A stone well in the corner of the yard.  It looks like it has been used recently",
 "woods","Thick woods to the south.  They are impassable",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv10","west",
             });  

  }   }