      /* Still to add: house entrance, etc */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This is the west side of Kakariko Village.  Cobblestone paths \n"+
 " lead north, south, and east.  A thick hedge of bushes frames a  \n"+
 " well-kept yard and a simple house.  To the east of the hedge,   \n"+
 " you can see a fully paved section of the town.  A thick line of \n"+
 " trees block any movement to the west.\n";

items=({
 "ground","Except for the stone paths, the ground is covered with green grass",
 "grass","The grass is well tended and it is very green",
 "path","Stone paths that head north, south, and east",
 "house","A small, simple house.  You could enter it",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv6","east",
 "/players/novowels/kakariko/rooms/kv2","north",
 "/players/novowels/kakariko/rooms/kv8","south",
             });  

  }   }