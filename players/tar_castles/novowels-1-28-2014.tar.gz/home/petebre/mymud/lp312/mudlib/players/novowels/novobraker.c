        /* Test monster, just learning what shit does...   */

#include <ansi.h>
inherit "/obj/monster";
int z;

reset(arg)  {
     ::reset(arg);
     if(!arg) {

set_name("novobraker");
set_alias("novo");
set_short(" "+HIK+"-----------------"+NORM+" Novobraker : Eater of "+HIK+"Worlds"+NORM+" ( "+HIW+"-"+NORM+"fused"+HIW+"-"+NORM+" )");
set_race("human");
set_long("A fusion of Novowels and Vertebraker \n\n"+
         "  Half Novowels and half Vertebraker, Novobraker combines \n"+
         "  the best- and worst- qualities of both.  Half the time \n"+
         "  Novobraker speaks so swiftly that you can't even respond, \n"+
         "  and the other half all he says is 'heh.'  \n\n")+

set_level(28);
set_ac(25);
set_wc(75);
set_hp(10000);
set_al(-10000);                   /*alignment                              */
set_aggressive(0);                /*0 not, 1 is                            */
set_chat_chance(10);              /*chance per heartbeat load_chat messages*/
set_a_chat_chance(15);            /*combat chat chance                     */

load_chat("Novobraker goes: Heh. \n");
load_chat("Novobraker says: ... \n");
load_chat("Novobraker says: wtf. \n");
load_chat("Novobraker says: heh:) \n");
load_chat("Novobraker says: heh, laf \n");
load_chat("Novobraker nogs that shit. \n");
load_chat("Novobraker says: nog:) \n");
load_chat("Novobraker says: uh... \n"); 
load_chat("Novobraker imprisons you. \n");

load_a_chat("Novobraker screams: huzzawuzzah wah! \n");
load_a_chat("Novobraker says: oh no! \n");

set_chance(15);

set_spell_dam(random(100)+250);
set_spell_mess1("        "+HBMAG+"You sense a spacial displacement."+NORM);
set_spell_mess2("        "+HBMAG+"You sense a spacial displacement."+NORM);

     }
}

