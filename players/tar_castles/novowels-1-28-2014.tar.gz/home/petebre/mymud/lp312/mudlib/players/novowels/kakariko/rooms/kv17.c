      /* do the ldesc, bitch! */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Hyrule";
 long_desc=
 "   This is a small plateau.  The ground drops away sharply to \n"+
 " the south, and a cliff rises above you to the north.  There  \n"+
 " is a small house built up against the cliff face.  A wooden \n"+
 " fence blocks you from going west around it. \n";

items=({
 "plateau","A small flat area, it contains a small house and fence",
 "ground","The ground is full of grass, it drops away sharply to the south",
 "cliff","The ground rises up into a sheer wall to the north",
 "house","A small house built into the cliff face.  You could enter it",
 "fence","A fence is built between the dropoff and the house, it blocks you from going around the house",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv16","northeast",
              });  

  }   }