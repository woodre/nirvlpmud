      /* Still to add: house entering thing */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Kakariko Village";
 long_desc=
 "   This section of the town is dominated by a single house that    \n"+
 " sits up against the northern forest.  To the south, the ground    \n"+
 " drops down sharply creating a sheer cliff that is about ten feet  \n"+
 " high.  A sturdy fence has been erected, presumably to keep people \n"+
 " from falling off the edge.  The path going east-west is clear. \n";

items=({
 "sky","The sky is clear, and the sun is shining",
 "ground","Except for a simple dirt path, the ground is covered thickly with green grass",
 "grass","The grass is well trimmed and tended to here",
 "path","A simple beaten path extends from east to west, running in front of the door to the house",
 "house","The house is large.  You can enter it",
 "door","A thick wooden door to the house.  It is unlocked",
 "cliff","A sheer drop of about 10 feet",
 "fence","A fence keeps you from the edge of the dropoff",
 "forest","The forest to the north is too thick to enter here",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv4","east",
 "/players/novowels/kakariko/rooms/kv2","west",
             });  

  }   }