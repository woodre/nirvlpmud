      /* Entrance to Kakariko Village. */

      /* still to add:  sign
                        chicken
                        guard
                        hut      */

inherit "room/room";

reset(arg){

 if(!arg){

 set_light(1);
 short_desc="Hyrule";
 long_desc=
 "   You are in a wide open clearing surrounded by trees.  There \n"+
 " is a thick forest covered in mist to the north and west.  Up  \n"+
 " against the fringe of trees stands a single brightly colored  \n"+
 " hut.  A simple dirt path leads southward.  There is a large   \n"+
 " wooden archway over the path.\n";

items=({
 "forest","The forest is so thick you can't even squeeze between the trunks",
 "trees","Large, wide trees topped with green leaves",
 "leaves","The leaves you can make out are large and a dark green",
 "ground","Except for the dirt path, the ground is covered with green grass",
 "grass","The green grass is trimmed and lush",
 "path","A simple dirt path goes from the arch to the hut, and off to the west",
 "archway","A sturdy looking wooden archway rises over the path leading south",
 "hut","A small hut nestled up against the trees to the northwest",
        });

    dest_dir=({
 "/players/novowels/kakariko/rooms/kv4","south",
             });  

  }   }