/* A bee */

#include <ansi.h>
inherit "/obj/monster";

reset(arg){ 
    if(arg) return;
	::reset(arg);

set_name("bee");
set_alias("bug");
set_short("A small bee");
set_race("insect");
set_long(
  "A small flying insect with yellow and black stripes.  The bee emits \n"+
  "a loud buzzing sound as it flies erratically around you.  Although \n"+
  "small, the bee has a nasty looking stinger. \n\n");

set_level(1);
set_ac(10);
set_wc(5);
set_hp(random(10)+50);
set_al(0);
set_aggressive(0);

set_chat_chance(5);
 load_chat("The bee buzzes around the room.\n");

set_chance(10);
set_spell_dam(20);
 set_spell_mess1("The bee stings its opponent viciously!");
 set_spell_mess2("The bee stings you viciously!");

           }


