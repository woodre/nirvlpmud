inherit "obj/monster";
object weapon;
reset(arg) {
::reset(arg);
if(arg) return;
set_name("zombie");
set_race("zombie");
set_alias("monster");
set_short("A wandering Zombie");
set_long("This is a ghastly misshapen figure\n"+
	"enslaved by evil magic.  Perhaps you\n"+
	"should set it free.\n");
set_level(5);
set_hp(100);
set_al(-200);
set_wc(12);
set_ac(3);
weapon=clone_object("/players/kirkion/boneclub");
move_object(weapon, this_object());
}
