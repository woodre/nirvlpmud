oks.. please leave your kwand.bak as it is and do not make a wiz tool
basically put the rule is until one is level 60 one may not have a wiztrool
please use the /obj/wiz_tool.c
if you have any complaints, talk to me.
- Mythos
