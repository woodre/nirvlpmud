inherit "obj/weapon";
reset(arg){
::reset(arg);
if(arg) return;
set_id("boneclub");
set_alias("club");
set_short("A bone club");
set_long("Its a bone club of ghastly origin, judging by its appearance\n"+
	"it was probably once an appendage of some poor adventurer that\n"+
	"prey to these foul creatures.\n");
set_class(12);
set_weight(4);
set_value(750);
}
