inherit "room/room";
reset(arg) {
if (!arg) {
	set_light(1);
	short_desc = "Enterance";
long_desc=
"You arrive in a darker part of the wood.  Dark eyes circle around\n" +
"just out of your range of sight.  Two large wolves are in the process\n"+
"of ripping apart a freshly fallen rabbit.  From the howling off in the\n"+
"distance more wolves grow ever closer by the second.\n"+
"\n";
dest_dir = ({
"players/kirkion/workroom.c","north"
});
}
}
