inherit "obj/armor";
reset (arg){
if(arg) return;
set_name("shield");
set_long("This is the legendary shield of the undead king Igwulv");
set_short("Lich shield");
set_value(1500);
set_weight(1);
set_ac(3);
set_arm_light(1);
set_type("shield");
}
