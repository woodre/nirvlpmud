/*****************************************************************************
 *      File:                   krista.c
 *      Function:               mob for acs area. drops badge for money
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
if(!present("badge"), this_object())
  {
    move_object(clone_object("/players/highlander/areas/acs/armors/badge.c"), this_object());
  }
  
  ::reset(arg);
  if(arg) return;
  set_name("Krista");
  set_alt_name("agent");
  set_alias("krista");
  set_race("human");
  set_short("Krista");
  set_long(
  "Krista is a Tier 2 Tech for Apple Inc.  She helps customers with\n"+
"problems they may have with thier Apple products.  She is very good\n"+
"at her job.  Krista is wearing a hot looking blue jean skirt and white\n"+
"lace strapped blouse.  Her makeup is put on in a conservative yet tasteful\n"+
"manner. On her left arm is a pentacle tattoo, on her right is the name of\n"+
"a person\n");
  set_level(17);
  set_hp(500 + random (100));
  set_ac(16 + random (9));
  set_wc(27 + random (9));
  set_al(-500);
  set_chat_chance(5);
  load_chat(query_name()+" says, \Hello, Can I get your product's serial\n"+ 
 "number please?\n");
  load_chat(query_name()+" says, \"Isabel is my daughter's name.\n");
  load_chat(query_name()+" says, \"I am sorry your having problems with\n"+ 
 "your Iphone4.\n");
}
