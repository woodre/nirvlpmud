/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 *
 * - Earwax 9/28/05: Fixed typos, changed path of entrance to AREA
 *                   Added ANSI, and colorized it a little, as well.
 */

#define NAME "Highlander"
#define DEST "room/sea"
#define ENTRANCE "/players/highlander/areas/ace/<blahblah.c"
#include <ansi.h>

id(str) { return str == "castle"; }

short() {
    return "Castle of " +NAME; }

long() {
    write(NAME+"'s castle is not open yet.\n");
}

init() {
    add_action("enter"); add_verb("enter");
}

enter() {
  write("The castle is not open yet.\n");
  return 1;
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
}
is_castle() {return 1;}
