/*****************************************************************************
 *      File:                   mark.c
 *      Function:               high level boss for acs area
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
if(!present("phone"), this_object())
  {
    move_object(clone_object("/players/highlander/areas/acs/weapons/iphone.c"), this_object());
  }
  
  ::reset(arg);
  if(arg) return;
  set_name("Mark");
  set_alt_name("OM");
  set_alias("mark");
  set_race("human");
  set_short("Mark");
  set_aggressive(1);
  set_long(
 "Mark is the operations manager for Apple Inc..  He is\n"+
"responsible for the day to day operation of the entire\n"+
"Apple branch located in the ACS.  He oversees all projects\n"+
"and it's employees.  He is a man that appears to command much respect.\n");
  set_level(22);
  set_hp(1500 + random (250));
  set_ac(30 + random (5));
  set_wc(46 + random (5));
  set_aggressive(1);
  set_al(-1000);
  add_money(10000 + random (2000));
  set_chat_chance(5);
  set_a_chat_chance (15);
  load_chat("Mark asks How are you today?\n");
  load_chat("Mark asks Have you signed up for your overtime yet?\n");
  
  load_a_chat("Mark says Now your a dead man.\n");
  load_a_chat("Mark says Your fired!\n");

  add_spell("electrified",
    "\n$HM$ ~$HC$    You were just zapped from the Iphone\n"+
    "$HM$ ~$N$$C$          ------  -----   ------- \n"+
    "$HM$ ~$N$$C$               /  |   |   |      |\n"+
    "$HM$ ~$N$$C$              /   |   |   |      |\n"+
    "$HM$ ~$N$$C$             /    |---|   |------|\n"+
    "$HM$ ~$N$$C$            /     |   |   |\n"+
    "$HM$ ~$N$$C$           /      |   |   |\n"+
    "$HM$ ~$N$$C$          ------  |   |   |$N$\n"+
    "$HM$ ~$HC$              OUCH THAT HURT!!!\n\n$N$",
/* Rumplemintz addition here */
    "$HM$ ~$N$$HC$#CMN# electrifies #CTN#!\n$N$",
    25,"20d3+15",0,0);
/* Commenting out this stuff
  set_chance(25);
  set_spell_dam(15 + random(60));
*/
}
