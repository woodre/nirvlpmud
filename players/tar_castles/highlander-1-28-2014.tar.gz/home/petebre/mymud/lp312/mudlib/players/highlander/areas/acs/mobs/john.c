/*****************************************************************************
 *      File:                   john.c
 *      Function:               mob for acs area. drops badge for money
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
if(!present("badge"), this_object())
  {
    move_object(clone_object("/players/highlander/areas/acs/armors/badge.c"), this_object());
  }
  
  ::reset(arg);
  if(arg) return;
  set_name("John");
  set_alt_name("agent");
  set_alias("john");
  set_race("human");
  set_short("John");
  set_long(
  "John is an agent for Apple Inc.  He works in the telesales\n"+
"department which handles accounts for small to medium businesses.\n"+
"John is a handsome looking gentleman in his 30s.  He is wearing\n"+
"a SlipKnot t-shirt and a pair of blue jeans.\n");

  set_level(17);
  set_hp(500 + random (100));
  set_ac(16 + random (9));
  set_wc(27 + random (9));
  set_al(-500);
  set_chat_chance(5);
  load_chat(query_name()+" says, \Hello, I would like to outline why you need\n"+ 
 "the new Iphone 4.\n");
  load_chat(query_name()+" says, \"Can I help you today?\n");
  load_chat(query_name()+" says, \"I am going to refund you the cost of your\n"+ 
 "first month charges.\n");
}
