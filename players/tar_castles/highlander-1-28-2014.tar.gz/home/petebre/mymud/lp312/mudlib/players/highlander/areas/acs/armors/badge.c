

/*****************************************************************************
 *		File:                   badge.c
 *		Function:               Security Badges that can be returned to Mike
 *								the Security Guard for money.
 *		Author(s):              Highlander@Nirvana
 *		Copyright:              Copyright (c) 2011 Highlander
 *		                        All Rights Reserved.
 *		Source:                 2/18/2011
 *		Notes:
 *		Change History:			[2/19/2011] [Sparrow] Added init() containing
 *									add_action() for returning badge for money
 *								[2/19/2011] [Sparrow] Added correct headers
 *								[2/19/2011] [Sparrow] Added returnMe() method
 *									which controls badge return.
 ****************************************************************************/

inherit "obj/armor";

reset(arg){
   ::reset(arg);

   set_name("badge");
   set_short("security badge");
   set_alias("money_badge");
   set_long("\
A security badge that is required to enter and work\n\
here at ACS. Maybe you could 'return' to security for reward\n");
   set_type("amulet");
   set_ac(0);
   set_weight(1);
   set_value(0);

}

/* the init() method allows you to add commands to an object */
init() {
	if (!this_object()) return;
	/* this adds the command return which triggers the function returnMe */
	add_action("returnMe", "return");
}

/*************************************************************
* 	Method:			returnMe()
*	Input:			string
*	Output:			void
*	Description:	This method checks to see if Mike the Security
*					guard is in the same room as the player holding
*					the badge. If so it removes the badge from the
*					player and adds 3000-3999 coins to the player.
*	Author:			Sparrow
*
**************************************************************/
int returnMe(string what) {
	/* Make sure the player typed 'return badge' and nothing else */
	if((!what) || !(what == "badge")) {
		/* incorrect arguement to method */
		write("What would you like to return?\n");
		return 1;
	}
	if(what == "badge") {
		/* correct arguement to method, check to see if mike is in the room */
		if(present("Mike", environment(this_player()))) {
			/* mike is in room, send messages */
			write("Mike snatches the badge out of your hands and angrily"+
				"hands you some money.\n");
			say("Mike snatches the badge out of "+this_player()->query_name()+
				"'s hands and angrily offers a reward.\n");
			/* add money to player */
			this_player()->add_money(3000+random(1000));
			/* destruct this object */
			destruct(this_object());
			return 1;
		}
		else {
			/* mike isnt here */
			write("You need to find Mike the Security Guard to return this badge.\n");
		return 1; } } }
	


query_save_flag() { return 1; }

