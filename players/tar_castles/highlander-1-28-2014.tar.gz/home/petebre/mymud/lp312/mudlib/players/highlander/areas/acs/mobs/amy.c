/*****************************************************************************
 *      File:                   amy.c	
 *      Function:               mob for acs area drops badge for coins
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
if(!present("amulet"), this_object())
  {
    move_object(clone_object("/players/highlander/areas/acs/armors/badge.c"), this_object());
  }
  
  ::reset(arg);
  if(arg) return;
  set_name("Amy");
  set_alt_name("agent");
  set_alias("amy");
  set_race("human");
  set_short("Amy");
  set_long(
  "Amy is an agent for Sprint.  She works in the CAM\n"+
"department which handles account modifications.  Amy\n"+
"is a nice looking woman in her mid 20s.  She has on a\n"+
"nice looking green dress and wears her hair in a pony\n"+
"tail.\n");
  set_level(17);
  set_hp(500 + random (100));
  set_ac(16 + random (9));
  set_wc(27 + random (9));
  set_al(-500);
  set_chat_chance(5);
  load_chat(query_name()+" says, \Hello, thank you for calling Sprint.\"\n");
  load_chat(query_name()+" says, \"Can I help you today?\n");
  load_chat(query_name()+" says, \"I am sorry, all charges are valid.\"\n");
}
