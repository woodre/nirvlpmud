/*****************************************************************************
 *      File:                   stacie.c
 *      Function:               high level boss for acs area
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
 /* weapon for om. -H */
if(!present("phone"), this_object())
  {
    move_object(clone_object("/players/highlander/areas/acs/weapons/blackberry.c"), this_object());
  }
  
  ::reset(arg);
  if(arg) return;
  set_name("Stacie");
  set_alt_name("OM");
  set_alias("stacie");
  set_race("human");
  set_short("Stacie");
  set_aggressive(1);
  set_long(
 "Stacie is the operations manager for Sprint/Nextel.  She is\n"+
"responsible for the day to day operation of the entire\n"+
"Sprint branch located in this ACS. She oversees all projects\n"+
"and it's employees. She is a woman that appears to command much respect.\n");
 /* Played with values a bit to get xp where i wanted it. done for both oms. -H */
  set_level(22);
  set_hp(1500 + random (250));
  set_ac(30 + random (5));
  set_wc(46 + random (5));
  set_aggressive(1);
  set_al(-1000);
  add_money(10000 + random(2000));
  set_chat_chance(5);
  set_a_chat_chance (15);
  load_chat("Stacie asks How are you today?\n");
  load_chat("Stacie asks Have you signed up for your overtime yet?\n");
  
  load_a_chat("Stacie says Now your a dead man.\n");
  load_a_chat("Stacie says Your fired!\n");
 /* spells are listed below for both oms. -H */
  add_spell("electrified",
    "\n$HM$ ~$HC$    You were just zapped from the Blackberry\n"+
    "$HM$ ~$N$$C$          ------  -----   ------- \n"+
    "$HM$ ~$N$$C$               /  |   |   |      |\n"+
    "$HM$ ~$N$$C$              /   |   |   |      |\n"+
    "$HM$ ~$N$$C$             /    |---|   |------|\n"+
    "$HM$ ~$N$$C$            /     |   |   |\n"+
    "$HM$ ~$N$$C$           /      |   |   |\n"+
    "$HM$ ~$N$$C$          ------  |   |   |$N$\n"+
    "$HM$ ~$HC$              OUCH THAT HURT!!!\n\n$N$",
/* Rumplemintz addition here */
    "$HM$ ~$N$$HC$#CMN# electrifies #CTN#!\n$N$",
    25,"20d3+15",0,0);
/* Commenting out this stuff
  set_chance(25);
  set_spell_dam(15 + random(60));
*/
}