/*****************************************************************************
 *      File:                   mike.c
 *      Function:               mob for acs area. rewards players for badges
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
  
  ::reset(arg);
  if(arg) return;
  set_name("Mike");
  set_alt_name("guard");
  set_race("human");
  set_short("Security Guard");
  set_long("\
  Mike is the Head Security Guard for ACS\n\
It would be a big mistake to try to fight him!\n");
  set_level(10);
  set_hp(400 + random (100));
  set_ac(15 + random (9));
  set_wc(26 + random (9));
  set_al(0);

  set_chat_chance(5);
  load_chat(query_name()+" says, \"Welcome to ACS. May I help you?\"\n");
  load_chat(query_name()+" says, \"Do you have anything you would like\n"+
 "to turn in?\n");
  
}
