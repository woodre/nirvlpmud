/*****************************************************************************
 *      File:                   linda.c
 *      Function:               mob for acs area. drops badge for money
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
/* way for players to get coins after kill.  Same for all agents cause I aint doing this 6 times. -H */
if(!present("badge"), this_object())
  {
    move_object(clone_object("/players/highlander/areas/acs/armors/badge.c"), this_object());
  }
  
  ::reset(arg);
  if(arg) return;
  set_name("Linda");
  set_alt_name("agent");
  set_alias("linda");
  set_race("human");
  set_short("Linda");
  set_long(
  "Linda is an agent for Sprint.  She works in the CAM\n"+
"department which handles account modifications.  Linda\n"+
"is an older looking woman in her mid 40s.  She has on a\n"+
"nice blouse and skirt combo.\n");
/* all values based on monster.guide + Angel code for examples on modifiers. Same for all 6 agents. */
  set_level(17);
  set_hp(500 + random (100));
  set_ac(16 + random (9));
  set_wc(27 + random (9));
  set_al(-500);
  set_chat_chance(5);
  load_chat(query_name()+" says, \Hello, thank you for calling Sprint.\"\n");
  load_chat(query_name()+" says, \"Can I help you today?\n");
  load_chat(query_name()+" says, \"I am going to refund you the cost of those\n"+
 "text messages.\"\n");
}
