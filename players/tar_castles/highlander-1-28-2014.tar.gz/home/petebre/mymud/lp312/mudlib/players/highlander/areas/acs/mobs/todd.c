/*****************************************************************************
 *      File:                   todd.c
 *      Function:               midlevel boss for acs area
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                  random clone
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
  
  ::reset(arg);
  if(arg) return;
  set_name("Todd");
  set_alt_name("recruiter");
  set_alias("todd");
  set_race("human");
  set_short("Todd");
  set_long("\
 Todd is the recruiter for this ACS.  He is the person\n\
that will call you if he thinks you can do the job.\n");
 /* values based on monster.guide with modifiers added. */
  set_level(18);
  set_hp(750 + random (250));
  set_ac(15 + random (5));
  set_wc(22 + random (5));
  set_al(-1000);
  add_money(random(2000)+2000);
  set_chat_chance(5);
  set_a_chat_chance (15);
  load_chat("Todd asks How are you today?\n");
  load_chat("Todd asks Would you like a job?\n");
  
  load_a_chat("Todd asks How is attacking me going to get you hired?\n");
  load_a_chat("Todd says I'm sorry. Your not right for this position!\n");

  /* spell for both supervisors and recruiter as well as tester should she pop. */
  add_spell("paperclip","#TN# launches a paperclip."+
    "\n$HM$ ~$HC$             You were just hit by a paperclip\n"+
    "$HM$ ~$N$$C$          *------------------------- \n"+
    "$HM$ ~$N$$C$         *\n"+
    "$HM$ ~$N$$C$        *     *-----------------------------*  \n"+
    "$HM$ ~$N$$C$        *    *---------                      *\n"+
    "$HM$ ~$N$$C$        *                                    *\n"+
    "$HM$ ~$N$$C$         *----------------------------------* $N$\n"+
    "$HM$ ~$HC$                   OUCH THAT HURT!!!\n\n$N$",
    "$HM$ ~$HC$     Todd launches a paperclip!\n",
50, "25d3", 0,0);
}
