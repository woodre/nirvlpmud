/*****************************************************************************
 *      File:                   scott.c
 *      Function:               midlevel boss for acs area
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
  
  ::reset(arg);
  if(arg) return;
  set_name("Scott");
  set_alt_name("supervisor");
  set_alias("scott");
  set_race("human");
  set_short("Scott");
  set_long(
 "Scott is a supervisor for Apple Inc..  He has several agents\n"+
"that he is responsible for. Scott is 6\'6\" and wieghts\n"+
"about 215 lbs.  He has a military crew cut and blue eyes\n"+
"that seem to send you in a cold shiver as he gazes\n"+
"at you. He always wears a black suit and tie.  I can\n"+
"guarantee that this will not be an easy fight should you\n"+
"choose to attack him.\n");
  set_level(18);
  set_hp(750 + random (250));
  set_ac(17 + random (5));
  set_wc(25 + random (5));
  set_al(-1000);
  add_money(random(4000)+2000);
  set_chat_chance(5);
  set_a_chat_chance (15);
  load_chat("Scott asks How are you today?\n");
  load_chat("Scott asks How many APPs have you sold this month?\n");
  
  load_a_chat("Scott says Now your a dead man.\n");
  load_a_chat("Scott says Your fired!\n");

  add_spell("paperclip","#TN# launches a paperclip."+
    "\n$HM$ ~$HC$             You were just hit by a paperclip\n"+
    "$HM$ ~$N$$C$          *------------------------- \n"+
    "$HM$ ~$N$$C$         *\n"+
    "$HM$ ~$N$$C$        *     *-----------------------------*  \n"+
    "$HM$ ~$N$$C$        *    *---------                      *\n"+
    "$HM$ ~$N$$C$        *                                    *\n"+
    "$HM$ ~$N$$C$         *----------------------------------* $N$\n"+
    "$HM$ ~$HC$                   OUCH THAT HURT!!!\n\n$N$",
    "$HM$ ~$HC$     Scott launches a paperclip!\n",
50, "25d3", 0,0);
}
