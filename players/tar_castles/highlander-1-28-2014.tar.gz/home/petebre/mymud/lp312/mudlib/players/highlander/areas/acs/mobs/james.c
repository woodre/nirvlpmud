/*****************************************************************************
 *      File:                   james.c
 *      Function:               mob for acs area. drops badge for money
 *      Author(s):              Highlander@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                 
 *      Change History:         
 ****************************************************************************/
inherit "/obj/monster";

#include "/sys/lib.h"

reset(arg)
{
if(!present("badge"), this_object())
  {
    move_object(clone_object("/players/highlander/areas/acs/armors/badge.c"), this_object());
  }
  
  ::reset(arg);
  if(arg) return;
  set_name("James");
  set_alt_name("agent");
  set_alias("james");
  set_race("human");
  set_short("James");
  set_long(
  "James is a Tier 1 Tech for Apple Inc.  He help customers with\n"+
"problems they may have with thier Apple products.  He is very good\n"+
"at his job.  James is wearing a nice looking dress shirt, tie, and slacks\n");

  set_level(17);
  set_hp(500 + random (100));
  set_ac(16 + random (9));
  set_wc(27 + random (9));
  set_al(-500);
  set_chat_chance(5);
  load_chat(query_name()+" says, \Hello, Can I get your product's serial number\n"+
 "please?\n");
  load_chat(query_name()+" says, \"Can I help you today?\n");
  load_chat(query_name()+" says, \"I am sorry your having problems with your\n"+
 "Iphone4.\n");
}
