/*****************************************************************************
 *      File:                   iphone.c
 *      Function:               weapon for apple om
 *      Author(s):              Highlander@Nirvana Sparrow@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                  clones on apple om
 *      Change History:         
 ****************************************************************************/
#include <ansi.h> /* for color -H */
inherit "obj/weapon.c";

 reset(arg) {
    ::reset(arg);
    if (arg) return;
    set_name("iphone4");
    set_alias("phone");
    /* Yes the weapon is a cell phone -H */
    set_short("An Apple Iphone4");
    set_long("A cell phone made by Apple Inc. for AT&T. It is made of a high\n"+
 "quality metal and plastic alloy that allows it to be able to withstand the\n"+
 "occasional dropping on a soft surface such as a rug, carpet, or grass.\n"+
 "The display consists of a mixture of glass and plastic that allows it to\n"+
 "sense when it is being touched on purpose and not on accident that would\n"+
 "cause it's battery to run down on a quicker basis.\n");
    set_class(17);
    /* Added wieght to justify higher WC */
    set_weight(3);
    /* pretty expensive little bugger eh? Not a big deal -H */
    set_value(7500);
    /* you had your closing brace backwards here -S */    
 }
 
 /* weapon specials */  
 weapon_hit(object attacker) {
    /* initalize variables */
    int w;
    string wielderName, targetName; /* we need these names for our spam */
    w = random(100);
    if(w < 38) { /* 38% chance of special going off */
        wielderName = environment()->query_name(); /* get the name of our owner */
        targetName = attacker->query_name(); /* get the name of our attacker */
        say(wielderName+"'s Iphone4 zaps "+targetName+" with a powerful bolt of electricity.\n");
        write("Your Iphone4 zapped "+targetName+" with a bolt of electricty.\n");
        return 3+random(5); /* deal 3-7 extra damage */
    }
    return;
 }
