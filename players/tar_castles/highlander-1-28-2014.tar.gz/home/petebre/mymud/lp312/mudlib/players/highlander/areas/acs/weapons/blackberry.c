/*****************************************************************************
 *      File:                   blackberry.c
 *      Function:               weapon for sprint om
 *      Author(s):              Highlander@Nirvana Sparrow@Nirvana
 *      Copyright:              Copyright (c) 2011 Highlander 
 *                              All Rights Reserved.
 *      Source:                 2/24/2011
 *      Notes:                  clones on sprint om
 *      Change History:         
 ****************************************************************************/
#include <ansi.h> /* you gotta include this if you want any color -H */
inherit "obj/weapon.c";

 reset(arg) {
    ::reset(arg);
    if (arg) return;
    set_name("blackberry");
    set_alias("phone");
    set_short("A Sprint Blackberry");
    set_long("A cell phone made by Research In Motion for Sprint. It is made\n"+
 "up from a high qualty, lightwieght metal alloy that will alow it to\n"+
 "withstand the occasional drop on a soft surface. The display is a small\n"+
 "glass and plastic combo that allows it to withstand the occasional scratch\n"+
 "or drop.  Under the display, in the middle, is what appears to be a small\n"+
 "white, plastic ball with several buttons to either side. Under that are the\n"+
 "buttons one would use to make a phone call or send a text message.\n"); 
    set_class(17);
    /* wieght is used to justify higher WC */
    set_weight(3);
    /* pretty expensive little bugger eh? Not a big deal -S */
    set_value(7500);
    /* you had your closing brace backwards here -S */    
 }
 
 /* Weapon special -H */  
 weapon_hit(object attacker) {
    /* initalize variables */
    int w;
    string wielderName, targetName; /* we need these names for our spam */
    w = random(100);
    if(w < 38) { /* 38% chance of special going off */
        wielderName = environment()->query_name(); /* get the name of our owner */
        targetName = attacker->query_name(); /* get the name of our attacker */
        say(wielderName+"'s Blackberry zaps "+targetName+" with a powerful bolt of electricity.\n");
        write("Your Blackberry zapped "+targetName+" with a bolt of electricty.\n");
        return 3+random(5); /* deal 3-7 extra damage */
    }
    return;
 }
