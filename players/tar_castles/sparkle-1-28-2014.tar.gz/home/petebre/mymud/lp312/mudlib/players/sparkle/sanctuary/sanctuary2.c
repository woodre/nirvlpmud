inherit "room/room";
#include <ansi.h>

reset(arg){
      if(arg) return;
          
     short_desc=("A Dirt Path");
     long_desc=
       "    A wide path appears to open up dividing the forest trees.\n"+
       "This path seems to lead deeper into the Sanctuary, where one\n"+
       "might just be able to observe some of the creatures that\n"+
       "cohabitate here. Light shines through the treetops exposing\n"+
       "the way down the path.\n";
       items = ({
       "path","A path that seems to magically appear",
       "treetops","Large pine trees appear to lean across the forest path",
       "moonlight","Bright rays of light seem to illuminate the way",
});
set_light(1);
     dest_dir = ({
       "/players/sparkle/sanctuary/sanctuary1.c","south", /* lets you walk back to sanctuary entrance */
       "/players/sparkle/sanctuary/waterfall.c","west",/*lets you enter waterfall room */
});
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing special.\n");
  say(this_player()->query_name()+" searches around for something.\n");
  return 1;
}
