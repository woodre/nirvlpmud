inherit "room/room";
#include <ansi.h>

reset(arg){
      if(arg) return;
          
     short_desc=("Deep Inside Cavern");
     long_desc=
       "    Darkness fills the cavern and a slight sense of uneasiness\n"+
       "abounds. The sounds of flapping wings and high-pitch shrills is\n"+
       "all to be heard here. There seems to be movement in the room but\n"+
       "where the sounds come from cannot be determined. The floor of \n"+
       "this cavern is slippery, as if wet with some substance. Looking\n"+
       "around, a feeling of fear overtakes as it is realized blood\n"+
       "covers the walls as if a mighty massacre has taken place here.\n";
       items = ({
       "walls","Dark red blood covers every wall of the cavern",
       "floor","A thick red substance flows across the floor",
       "blood","It cannot be determined if the blood is human or beast",
       "opening","A small hole that one might could crawl through",
});
set_light(1);
     dest_dir = ({
       "/players/sparkle/sanctuary/behindwaterfall.c","crawl", /* lets you walk back to behind the waterfall */
});
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing special.\n");
  say(this_player()->query_name()+" searches around for something.\n");
  return 1;
}
