inherit "room/room";
#include <ansi.h>

reset(arg){
      if(arg) return;
          
     short_desc=("The Waterfall");
     long_desc=
       "    The trees open up and beauty overtakes the forest here. A\n"+
       "beautiful waterfall flows into a sparkling lake where the forest\n"+
       "creatures must come to play. Near the water, tiny prints can be\n"+
       "seen everywhere. The rocks near the waterfall seem to be placed\n"+
       "perfectly as if they were speaking in some way. The wind whistles\n"+
       "through the trees, playing a soft melody unheard before.\n";
       items = ({
       "water","The water sparkles brightly in the sun",
       "waterfall","A small cavern appears to be hidden behind the waterfall",
       "rocks","Rocks seem to form a direct path through the waterfall",
       "prints","Small footprints that seem to play around the water",
       "trees","The trees sway in the wind and seem to whistle a melody",
       "lake","A large lake where the animals come to drink and play",
});
set_light(1);
     dest_dir = ({
       "/players/sparkle/sanctuary/behindwaterfall.c","enter", /* lets you enter the cavern */
       "/players/sparkle/sanctuary/sanctuary2.c","east", /* lets you walk back into woods */
});
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing special.\n");
  say(this_player()->query_name()+" searches around for something.\n");
  return 1;
}
