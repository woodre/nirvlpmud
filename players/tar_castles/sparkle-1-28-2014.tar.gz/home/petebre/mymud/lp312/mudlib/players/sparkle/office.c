inherit "room/room";
#include "/players/sparkle/ansi.h"

reset(arg){
      if(arg) return;
          
     short_desc=("Sparkle's Study");
     long_desc=
       "     This is the study of the infamous wizard, Sparkle. Many\n"+
       "famous books fill the shelves on the west wall, as she loves\n"+
       "to read and learn about interesting things and places. On the\n"+
       "west wall is her desk that is filled with many papers showing\n"+
       "how much time Sparkle is putting into her ideas and writings.\n"+
       "The huge chandelier hanging above was a gift from a very dear\n"+
       "friend and has been passed down through many generations.\n";
     items = ({
       "chandelier","A gift from Khrell, a dear friend that motivates Sparkle to achieve her dreams.",
});
set_light(1);
     dest_dir = ({
       "/players/sparkle/workroom.c","north", /* lets you walk back to your workroom  */
});
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing special.\n");
  say(this_player()->query_name()+" searches around for something.\n");
  return 1;
}
