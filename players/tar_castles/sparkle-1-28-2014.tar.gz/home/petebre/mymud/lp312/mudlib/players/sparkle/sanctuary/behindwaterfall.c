inherit "room/room";
#include <ansi.h>

reset(arg){
      if(arg) return;
          
     short_desc=("Behind the Waterfall");
     long_desc=
       "    The sounds of the water crashing against the rocks in this\n"+
       "dark cavern brings a sense of peace. The dim light that passes\n"+
       "through the waterfall projects brightly colored shadows on the\n"+
       "walls that seem to dance all around. There seems to be a small\n"+
       "opening in the west wall that one might could crawl through and\n"+
       "noises can be heard coming from inside.\n";
       items = ({
       "water","The water cascades from above the entrance to the cavern",
       "walls","The walls are dark and covered in a moss-like substance",
       "shadows","Beautiful shadows move across the walls as if dancing",
       "opening","A small hole that one might could crawl through",
});
set_light(1);
     dest_dir = ({
       "/players/sparkle/sanctuary/waterfall.c","out", /* lets you enter the waterfall room */
       "/players/sparkle/sanctuary/deepcavern.c","crawl", /* lets you crawl into cavern */
});
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing special.\n");
  say(this_player()->query_name()+" searches around for something.\n");
  return 1;
}
