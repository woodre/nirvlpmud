inherit "room/room";
#include <ansi.h>

reset(arg){
      if(arg) return;
          
     short_desc=("Sparkle's Exotic Gifts");
     long_desc=
       "    A well-lit room filled with exotic gifts of all kinds that\n"+
       "are sure to please even the youngest visitor. Here one can\n"+
       "purchase fun items that will aid in always remembering a trip\n"+
       "to the Sanctuary of Mythical Creatures\n";
       items = ({
       "room","Bright and colorful, this room seems very inviting",
       "gifts","Please speak to the clerk to see what gifts are in stock",
});
set_light(1);
     dest_dir = ({
       "/players/sparkle/sanctuary/sanctuary1.c","east", /* lets you walk back to sanctuary entrance */
});
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing special.\n");
  say(this_player()->query_name()+" searches around for something.\n");
  return 1;
}
