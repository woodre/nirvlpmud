inherit "room/room";
#include <ansi.h>

reset(arg){
      if(arg) return;
          
     short_desc=("Sanctuary Entrance");
     long_desc=
       "    A deep voice bellows, Welcome to the Sanctuary of Mythical\n"+
       "Creatures. Looking around, it cannot be determined where the\n"+
       "voice comes from. A large sign can be seen above the forest\n"+
       "path, held by two huge pillars. Trees surround the path and\n"+
       "seem to be dancing in the breeze.\n";
       items = ({
       "sign","Please do NOT feed the creatures. Enter at your own risk",
       "trees","Large pine trees appear to lean across the forest path",
       "pillars","Exquisite marble pillars used to hold up a sign",
});
set_light(1);
     dest_dir = ({
       "/players/sparkle/workroom.c","east", /* lets you walk back to your workroom  */
       "/players/sparkle/sanctuary/sanctuary2.c","north", /* lets you walk further into sanctuary */
       "/players/sparkle/sanctuary/giftshop.c","west", /* lets you walk into the gift shop */
});
}

init() {
  ::init();
  add_action("Search","search");
}

Search(str) {
if(!str) { write("Search what?\n"); return 1; }
  write("You search the "+str+" but find nothing special.\n");
  say(this_player()->query_name()+" searches around for something.\n");
  return 1;
}
