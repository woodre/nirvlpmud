inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("bible");
  set_class(10);
  set_short("The Holy Bible");
  set_long("This bible is empowered by the force of the Almighty.\n");
  set_value(250);
  set_weight(3);
  
set_hit_func(this_object());
}
