inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Vill Road 3 (w, s)";
  long_desc = 
  "Under Contrux\n";
  dest_dir =({
  "players/static/WATER/vill_road2", "west",
  "players/static/WATER/vill_road4", "south"
  });
  }
}

