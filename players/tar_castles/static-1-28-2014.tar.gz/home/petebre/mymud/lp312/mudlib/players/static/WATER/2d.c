inherit	"room/room";

reset(arg) { 
  if(!present("water guardian"))
  move_object(clone_object("players/static/MONSTER/water_guardian"),
    this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Water 2D (s, w)";
  long_desc = 
  "   You squeeze into the pipe...\n"+
  "YECH!  It is disgusting down here... The sewage is very ranky.\n"+
  "You cover your mouth, as not to puke, and look around.\n"+
  "You see a dismal exit towards the west.\n";
  dest_dir =({
  "players/static/WATER/3d", "south"
  });
  }
}


init() {
::init();

   add_action("go_west", "west");
   add_action("go_west", "w");

}


go_west() {

if (present("water guardian")) {
   write("Guardian says: you have no business in there!\n");
   return 1;
}

   call_other(this_player(), "move_player",
      "east#players/static/WATER/2c");
   return 1;
}
