inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Ice Patch (n, e)";
  long_desc = 
  "   You have left the town.  The air seems to have chilled down a\n"+
  "considerable amount.  The road is made of gravel, not in the best of\n"+
  "shape either.  A small patch of ice has formed on the road.\n";
  dest_dir = ({
  "players/static/room/road5", "north",
  "players/static/ICE/ice_patch2", "east"
  });
  }
}
