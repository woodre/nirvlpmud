inherit "obj/monster";

reset(arg) {
	object money, weapon;
     ::reset(arg);
     if(!arg) {
          set_name("dragon");
          set_level(25);
          set_hp(300);
          set_al(0);
          set_short("Striped Dragon");
	set_long("This dragon is enormous, towering of you by three times your height.\n"+
	"Be WARNED: this guy is DANGEROUS!\n");
          set_aggressive(0);
          set_wc(50);
          set_ac(13);
          money=clone_object("obj/money");
          weapon=clone_object("players/static/WEAPON/striped_sword.c.c");
          money->set_money(1000+random(500));
          move_object(money, this_object());
          move_object(weapon, this_object());
}
}
