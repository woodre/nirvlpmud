
inherit "obj/monster.talk";

reset(arg) {
  ::reset(arg);
  if(!arg) {
   set_name("dragon");
   set_alias("devil dragon");
   set_level(20);
   set_hp(500);
   set_al(-500);
   set_short("Devil Dragon");
   set_long(
   "This is Devilock's Dragon.  He was disappointed when he used\n"+
   "his magic to create this pet.  Devil dragon is not as fierce as\n"+
   "his master wanted him to be.  However he is quite protective.\n");
   set_aggressive(0);
   set_wc(30);
   set_ac(17);

set_chat_chance(20);

load_chat("Devil Dragon tries to bite you.\n");
}
}
