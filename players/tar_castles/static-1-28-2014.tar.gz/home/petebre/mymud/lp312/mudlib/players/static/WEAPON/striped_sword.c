inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("sword");
  set_class(18);
  set_short("a sword");
   set_long("This sword looks pretty normal.\n");
  set_value(800);
  set_weight(0);
  
set_hit_func(this_object());
}
weapon_hit(attacker) {
int i;
i=random(10);
if ( i > 5 ) {

    write("A striped laser flies out of your sword striking your oppponent!\n");
  return 10;
  }
   return 2;
}
