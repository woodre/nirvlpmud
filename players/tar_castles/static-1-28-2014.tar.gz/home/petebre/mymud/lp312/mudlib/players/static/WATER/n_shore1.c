inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "N Shore 1 (w, s)";
  long_desc = 
  "UNDER CONSTRUX\n";
  dest_dir =({
  "players/static/WATER/1d", "south",
  "players/static/WATER/n_shore2", "west"
  });
  }
}
