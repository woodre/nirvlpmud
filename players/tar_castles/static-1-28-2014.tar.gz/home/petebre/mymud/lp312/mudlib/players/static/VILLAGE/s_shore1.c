inherit	"room/room";

reset(arg) { 
  if(!present("crab")) make_monsters();
  if(!arg) {
  set_light(1);
  short_desc = "Beach (n, s)";
  long_desc = 
  "Under Contrux\n";
  dest_dir =({
  "players/static/WATER/3c", "north",
  "players/static/VILLAGE/entrance", "east"
  });
  }
}

make_monsters() {
object crab;
int i;

for(i=0; i<5; i++) {
crab = clone_object("players/static/MONSTER/crab");
move_object(crab, this_object());
}

return 1;
}
