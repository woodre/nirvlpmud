inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Water 3A (n, e)";
  long_desc = 
  "   There is quite a pull underneath you.  You are sucked under\n"+
  "water and grasp frantically for anything to pull you up.  The\n"+
  "harder you try, the more it pulls.  As you are about to give up\n"+
  "hope and plunge to the bottom of the sea, you suddenly are floating\n"+
  "effortlessly in the now calm water.\n";
  dest_dir =({
  "players/static/WATER/2a", "north",
  "players/static/WATER/3b", "east"
  });
  }
}
