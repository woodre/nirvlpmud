inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("flamethrower");
  set_class(20);
  set_short("Flamethrower");
  set_long("An incredibly deadly weapon.  The power of fire can harm\n"+
  "even the mightiest of beings.\n");
  set_value(875);
  set_weight(5);

  set_hit_func(this_object());

}

weapon_hit(attacker) {
int i;

i = random (100);
if (i > 50) {
   write(attacker->query_name()+ " is scorched by flames.\n");
   say(this_player()->query_name()+" shoots flames onto "+
   attacker->query_name()+".\n");
   if (i > 75) {
   write("You are burnt by the backfire of the flames.\n");
   this_player()->hit_player(random(5));
   }

   return 10;
}

return 0;
}

