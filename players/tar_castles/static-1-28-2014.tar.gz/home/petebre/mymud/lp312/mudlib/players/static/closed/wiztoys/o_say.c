/*
     Other-say code courtesy of Magnum and Mindai - use it but dont abuse it!
*/

inherit "obj/treasure";

reset(arg) {
  if (arg) return;
  name = "other-sayer";
  short_desc = "The Other-Sayer";
  long_desc = "This is a code-tester.  Use 'osay <player> <message>'.\n";
  call_other(this_player(), "set_heart_beat", 1);
 }

init() {
::init();
  add_action("osay", "osay");
 }

osay(str) {
  string friend, msg;
  object friend_obj;
  if(sscanf(str, "%s %s", friend, msg) != 2) return 0;
  friend_obj = find_player(friend);
  if(!friend_obj) {
    write("They are not on.\n");
    return 1;
   }
  other_say(friend_obj, msg);
  return 1;
 }

other_say(to_obj, msg) {
  object env, inv;
  env = environment(to_obj);
  inv = first_inventory(env);
  while (inv) {
    if(inv != to_obj) {
      tell_object(inv, msg + "\n");
     }
    inv = next_inventory(inv);
   }
  return 1;
 }

heart_beat() {
  command(find_player("static"), "burp");
  write("You have an other-sayer.\n");
  return 1;
}
