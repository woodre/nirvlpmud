inherit "obj/treasure";
object a;

reset(arg)
{
  if (arg) return;
  set_id("trump");
  set_short("Ultratrump");
  set_long("This is the ultratrump.\n"+
    "Usage : trump [plyr/monster]"+
   "           trump (jst try it)\n");
  set_weight(0);
  set_value(0);
}

init()
{
   a = users();
   add_action("trump_to", "trump");
}



trump_to(str) {
  int i;

  if (str) {
  object ob;
  ob = find_living(str);
  if(!ob) {
     write("Could not locate '"+str+"'.\n");
     return 1;
  }

  move_object(this_player(), environment(ob));
  write("Ok.\n");
  return 1;
}


  for (i=0; i<sizeof(a); i++) {
  if (i<10)
     write("  "+i+": "+a[i]->query_real_name()+"\n");
  else
     write(" " +i+": "+a[i]->query_real_name()+"\n");
  }

  write("Trump > ");

  input_to("lookup");
  return 1;
}


lookup(t) {
  int num;

  sscanf(t, "%d", num);

  if (num>sizeof(a) || num<0) {
  write("Index out of range.\n");
  return 1;
  }

  move_object(this_player(), environment(a[num]));
  write("Ok.\n");
return 1;
}
