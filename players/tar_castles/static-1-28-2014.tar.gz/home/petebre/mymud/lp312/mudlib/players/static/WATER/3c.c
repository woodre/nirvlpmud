inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Water 3C (s, e, w)";
  long_desc = 
  "UNDER CONSTRUX\n";
  dest_dir =({
  "players/static/WATER/3b", "west",
  "players/static/WATER/beach", "south",
  "players/static/WATER/3d", "east"
  });
  }
}
