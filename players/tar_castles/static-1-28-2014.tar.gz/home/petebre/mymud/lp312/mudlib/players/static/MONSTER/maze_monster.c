
inherit "obj/monster";

reset(arg) {
     object key;
     ::reset(arg);
     if(!arg) {
  set_name("monster");
  set_level(17);
  set_hp(425);
  set_al(-200);
  set_short("The Maze Monster");
  set_long("You attempt to take a closer look at this creature, but it moves\n"+
    "away.  Its face seemed very strange, a deformed maze-like pattern.  For\n"+
    "a minute there, it seemed that you were becoming part of him.\n");
  set_aggressive(1);
  set_wc(24);
  set_ac(14);
  set_chance(35);
  set_spell_mess2("Maze monster makes a scary face at you!\n");
  set_spell_dam(10);
  key=clone_object("players/static/obj/maze_key");
  move_object(key, this_object());
}
}
