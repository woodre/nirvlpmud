inherit "obj/treasure";

reset(arg)
{
    if (arg) return;
    set_id("barbell");
    set_short("A 2000 lb. barbell");
    set_long("This barbell looks vey heavy.  It must be worth a lot.\n");
    set_weight(3);
    set_value(900);
}
