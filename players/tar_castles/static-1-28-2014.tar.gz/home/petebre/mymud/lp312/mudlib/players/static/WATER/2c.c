inherit	"room/room";

reset(arg) { 
  if(!present("water demon"))
  move_object(clone_object("players/static/MONSTER/water_demon"),
    this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Water 2D (s, w)";
  long_desc = 
  "   You enter through the gate.\n"+
  "This looks like an entrance to an abandoned cavern.\n"+
  "The air is musty and you can barely breathe in his small area.\n"+
  "You can see an opening to your west.\n";
  dest_dir =({
  "players/static/WATER/3d", "south"
  });
  }
}


init() {
::init();

   add_action("go_west", "west");
   add_action("go_west", "w");

}


go_west() {

if (present("water demon")) {
   write("Demon growls at you.\n");
   write("Demon bursts: you are not getting in there while I am alive!\n");
   return 1;
}

   call_other(this_player(), "move_player",
      "east#players/static/WATER/2b");
   return 1;
}
