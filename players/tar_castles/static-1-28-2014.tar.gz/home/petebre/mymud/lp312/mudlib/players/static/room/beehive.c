inherit	"room/room";

reset(arg) { 
  if(!arg) {
  move_object(clone_object("players/static/obj/honey"), this_object());
  set_light(1);
  short_desc = "An enormous beehive";
  long_desc = 
   "   You are in an oversized bee hive.  Luckily, the queen bee is\n"+
   "not around to prevent you from stealing the honey.  The bees\n"+
   "worked so hard producing it...\n";
  dest_dir =({"players/static/room/bees", "out"});
  }
}
