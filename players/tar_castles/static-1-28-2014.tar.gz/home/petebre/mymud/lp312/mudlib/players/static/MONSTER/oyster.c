
inherit "obj/monster";
object treasure;

reset(arg) {
     ::reset(arg);
     if(!arg) {
  set_name("oyster");
  set_level(12);
  set_hp(180);
  set_al(200);
  set_short("Giant oyster");
  set_long("This is the most enormous oyster you have ever seen!\n"+
  "It seems pretty calm, but you bet it will guard its treasure with\n"+
  "its life.\n");
  set_aggressive(0);
  set_wc(16);
  set_ac(9);

  treasure = clone_object("obj/treasure");
  call_other(treasure, "set_id", "pearl");
  call_other(treasure, "set_short", "Giant Pearl");
  call_other(treasure, "set_long",
  "A magnificent pearl that shines a snowy white.\n");
  call_other(treasure, "set_weight", 2);
  call_other(treasure, "set_value", 1500);

  move_object(treasure, this_object());
}
}
