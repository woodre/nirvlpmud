inherit "obj/treasure";

reset(arg)
{
    if (arg) return;
    set_id("fish scales");
    set_alias("scales");
    set_short("Fish scales");
    set_long("A set of fish scales... nice and shiny...\n");
    set_weight(0);
    set_value(50);
}
