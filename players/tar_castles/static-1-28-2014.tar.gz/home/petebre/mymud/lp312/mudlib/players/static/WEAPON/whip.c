inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("whip");
  set_class(10);
  set_short("A thick leather whip");
  set_long("This whip looks like it was used against wild animals,\n"+
    "especially lions.\n");
  set_value(250);
  set_weight(2);
  
set_hit_func(this_object());
}
