init() {
   add_action("rub_ring", "point");
       }
id(str) {
   return str == "ring"; 
        }
get() {return 1;}
drop() {return 0; }
short() {
    return "Snake ring";
        }
long() {
   write("This is an ancient riing.\n"+
   "It will protect you if you are become in need.\n"+
   "Just type 'point ring at <attacker>'\n");
     return 1; 
       }
reset(arg) {
   if(arg) return;
           }
rub_ring(str) {
   object victim, owner;
   string who;
   sscanf(str, "ring at %s", who);
   owner = this_player();
   if(!str) {
    write("Usage : point ring at [monster]\n");
      return 1; }
if(who==owner) {
   write("What? Attack yourself?\n");
   return 1;
               }
if(!victim || !living(victim)) {
  write("You can't cast on that\n");
  return 1; }
if(victim->query_npc()==0 && victim->query_pl_k()==0) {
   write("That player doesn't have pk set!\n");
   return 1;
          }
if(victim->query_npc()==0 && owner->query_pl_k()==0) {
  write("You do not have pk set!\n");
  return 1;
   }
if(environment(owner) == environment(victim)) {
  write("The ring flies off of your hand and turns into three giant\n"+
  "snakes.  Each of them sink its fangs into "+who+"\n"+
  "The snakes then vanish from view.\n");
say (owner->query_name()+" points the Snake ring at "+str+".\n"+
   "Three tremendous snakes materialize and bite into "+who+".\n"+
   "The snakes disappear once they're done with their fanging.\n");
victim->attacked_by(owner);
victim->hit_player(50);

tell_object(victim, "A great cone of wind and fire drop from\n" +
                    "the heavens to engulf you\n");
destruct(this_object());
return 1; 
}
}
