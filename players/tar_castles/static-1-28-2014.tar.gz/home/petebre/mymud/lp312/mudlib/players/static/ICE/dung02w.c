inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Dungeon";
  long_desc = 
  "  Gee, this dungeon doesn't look that scary after all.  Why,\n"+
  "you could put a bed down here and call it a guest room.\n";
  dest_dir = ({
  "players/static/ICE/dung01", "east",
  "players/static/ICE/dung03w", "north"
  });
  }
}

realm() {
return("NT");
}
