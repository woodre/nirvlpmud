inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("sword");
  set_class(18);
  set_short("Sword of Damnation");
  set_long("A sword of magical possibilties against evil monsters.\n"+
  "It will may need to drain some power out of you to strike.\n");
  set_value(800);
  set_weight(3);
  
set_hit_func(this_object());
}
weapon_hit(attacker) {
if (call_other(attacker, "query_alignment") < 0 &&
   call_other(this_player(), "query_sp") > 5 ) {
int i;
i=random(10);
if ( i > 2 ) {
   write("You strike this foul beast with the power of Damnation!\n");
   call_other(this_player(), "add_spell_point", -2);
  return 19;
  }
   return 2;
  }
  return 0;
}
