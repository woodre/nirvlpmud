inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Ice Trail 2 (n, e, w)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/trail1", "north",
  "players/static/ICE/ice_jungle", "west",
  "players/static/ICE/trail3", "east"
  });
  }
}
