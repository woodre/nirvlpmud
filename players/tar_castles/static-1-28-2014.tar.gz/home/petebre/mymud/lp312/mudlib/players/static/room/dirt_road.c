inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Dirt Road";
  long_desc = 
"  You travel along a very unused dirt road.  It is very strange to\n"+
"see such little activity.  No footprints are to be found in what\n"+
"seems a quite formiddable area.\n";
  dest_dir =({"players/static/room/cool", "north",
   "players/static/room/bridge", "south",
   });
  }
}
