
inherit "obj/monster";

reset(arg) {
  object fangs;
     ::reset(arg);
     if(!arg) {
  set_name("maze serpent");
  set_alias("serpent");
  set_level(13);
  set_hp(195);
  set_al(-50);
  set_short("A serpent");
  set_long("   A vicious serpent who seems to be guarding the room to\n"+
    "the west.  It is very angered that you even got this far!\n");
  set_aggressive(1);
  set_wc(20);
  set_ac(10);
  set_ac(17);
  fangs=clone_object("players/static/WEAPON/fangs");
  move_object(fangs, this_object());
}
}
