inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 12e (ne, sw)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas10e", "northeast",
  "players/static/ICE/cas13", "southwest"
  });
  }
}
