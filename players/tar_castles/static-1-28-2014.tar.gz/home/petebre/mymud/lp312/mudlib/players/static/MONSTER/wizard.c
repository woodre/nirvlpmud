inherit "obj/monster.talk";

reset(arg){
::reset(arg);
if (!arg) {
  set_name("ice wizard");
  set_alias("wizard");
  set_short("Frozen Ice Wizard");
  set_long(
  "This wizard has been frozen by an evil wizard.  He could sure use\n"+
  "your help.  It must not be too fun being a popsicle.\n");
  set_aggressive(0);
  set_level(15);
  set_hp(225);
  set_wc(20);
  set_ac(12);
  set_al(500);
  set_chat_chance(25);
  load_chat("Ice wizard shivers.\n");
  }
}
  catch_tell(str) {
    object from;
    string a;
    from = this_player();
    if(!from) return;
    if (sscanf(str, "%s melts wizard.", a) == 1) {
    object ob;
       ob = present("staff", from);
      if(!ob || !call_other(ob, "id", "staff of melting"))
      return;
    destruct(ob);
    remove_chat("Ice wizard shivers.\n");
    set_short("Unfrozen Ice Wizard");
    set_long("Someone has had the kindness to free the wizard from\n"+
    "its entrapment.\n");
    write("\nPower emanates out of the staff.\n");
    write("The ice surrounding the wizard melts away.\n");
    tell_object(from, "The ice wizard smiles at you.\n"+
    "Ice wizard says: Thank you!  I am forever grateful to you honor.\n"+
  "To reward you for such kindness, here is a magical ointment.\n");
    move_object(clone_object("players/static/obj/ointment"), from);
    write("Ice wizard gives ointment to "+a+".\n");
    return 1; }
  return 1;
}
