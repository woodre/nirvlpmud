inherit	"room/room";

reset(arg) { 
  if(!present("lobster"))
    move_object(clone_object("players/static/MONSTER/lobster"),
    this_object());

  if(!present("jellyfish")) make_monsters();
  if(!arg) {
  set_light(1);
  short_desc = "Water 1C (e, w)";
  long_desc = 
  "   The water is shallow here.  You can almost stand on your feet.\n"+
  "There is land towards the south.\n";
  dest_dir =({
  "players/static/WATER/1d", "east",
  "players/static/WATER/1b", "west"
  });
  }
}

make_monsters() {

int i;
object monster;

for (i=0; i<5; i++) {
monster = clone_object("players/static/MONSTER/invis_jellyfish");
move_object(monster,this_object());
}

return 1;
}
