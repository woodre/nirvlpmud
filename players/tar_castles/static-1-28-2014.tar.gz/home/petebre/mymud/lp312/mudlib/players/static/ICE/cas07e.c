inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 07e (n, w)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas08e", "west",
  "players/static/ICE/cas06e", "north"
  });
  }
}
