inherit	"room/room";

reset(arg) { 
  if(!present("bee")) make_bees();
  if(!present("beehive"))  
     move_object(clone_object("players/static/obj/beehive"), this_object());
  if(!arg) {
  set_light(1);
  short_desc = "N Shore 3";
  long_desc =
"   UNDER CONSTRUX\n";

  dest_dir =({
  "players/static/WATER/n_shore2", "south"
  });
  }
}

init() {

  ::init();
    add_action("enter_hive", "enter");
}

enter_hive(str) {

if(present("bee")) {
   write("Bee won't let you into its hive.\n");
   return 1;
}

   call_other(this_player(), "move_player",
     "into hive#players/static/WATER/beehive");
   return 1;
}


make_bees() {

object bee;
int i;

for (i=0; i<7; i++) {
   bee = clone_object("players/static/MONSTER/bee");
   move_object(bee, this_object());
   }

return 1;
}
