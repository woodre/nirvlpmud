inherit	"room/room";

reset(arg) { 
  if(!present("sofa")) {
  move_object(clone_object("players/static/obj/sofa"), this_object());
  }
  if(!arg) {
  set_light(1);
  short_desc = "Living Room";
  long_desc = 
"  This is a modern living room.  You see comfortable sofas and a\n"+
"reclining lazyboy chair.  The walls are painted a light green, while\n"+
"the floor is covered with a light pink rug.  Not exactly pretty, but\n"+
"it does give the room a sense of playfulness.\n";

  dest_dir = ({
  "players/static/HOUSE/patio", "north",
  "players/static/HOUSE/kitchen", "south",
  "players/static/HOUSE/study", "east",
   "players/static/HOUSE/entrance", "leave"});
  }
}
