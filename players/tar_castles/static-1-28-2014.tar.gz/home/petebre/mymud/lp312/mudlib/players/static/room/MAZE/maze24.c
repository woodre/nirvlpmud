inherit	"room/room";

reset(arg) { 
  if(!present("maze monster")){
    move_object(clone_object("players/static/MONSTER/maze_monster"),this_object());
  }
  if(!arg) {
  set_light(1);
  short_desc = "Lair of the Maze Monster";
  long_desc =
  "   This is the den of some monster.  It must have eaten through the eastern\n"+
  "wall, and made its lair.  You see sharred remains of adventurers to either\n"+
  "side of the lair.  This does not seem to be a pretty place.\n";

  dest_dir =({"players/static/room/MAZE/maze23", "east"});
  }
}
realm() { return "NT"; }
