inherit "obj/monster.talk";

reset(arg){
::reset(arg);
if (!arg) {
  set_name("ice king");
  set_alias("king");
  set_short("Ice King");
  set_long("   The king does not look happy.  Help him!\n");
  set_aggressive(0);
  set_level(15);
  set_hp(250);
  set_wc(20);
  set_ac(12);
  set_al(500);
  }
}
  catch_tell(str) {
    object from;
    string a;
   if (sscanf(str, "%s arrives.", a) == 1) {
    from = find_living(lower_case(a));
    write("Ice king says: Thank you for freeing me, oh brave one!\n"+
    "  Now I must free the rest of my kingdom before I return to my throne.\n"+
    "\n"+
    "Ice king sighs.\n"+"\n"+
    "Ice king says: alas, I am no match for the magic that has frozen the\n"+
    "  Ice Wizard.\n"+"\n"+
    "Ice king hands you a staff.\n"+
    "Ice king says: Journey out to find the missing piece of the staff.\n"+
    "  Good luck, and Goodbye.\n");
    move_object(clone_object("players/static/obj/plain_staff"), from);
   destruct(this_object());
    return 1; }
  return 1;
}
