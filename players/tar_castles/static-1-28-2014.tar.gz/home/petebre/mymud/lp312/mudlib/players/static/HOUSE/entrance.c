#include "std.h"
int door_is_open, door_is_locked;
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
extra_reset(){
  door_is_open=0; door_is_locked=1;
if(!present("mat")) {
  move_object(clone_object("players/static/obj/welcome_mat"), this_object());
}
}

#undef EXTRA_LONG
#define EXTRA_LONG\
    if (str == "door") {\
	if (door_is_open) {\
	    write("The door is open.\n");\
	    return;\
	}\
	write("The door is closed.\n");\
	return;\
    }

#undef EXTRA_INIT
#define EXTRA_INIT\
    add_action("open"); add_verb("open");\
    add_action("unlock"); add_verb("unlock");\
    add_action("search_mat"); add_verb("lift");\
    add_action("search_mat"); add_verb("search");\
    add_action("search_mat"); add_verb("move");\
    add_action("enter_house"); add_verb("enter");
  ONE_EXIT("players/static/room/road1", "west",
    "House entrance",
 "   You are outside a small house.  The house looks quite modern,\n"+
"and recently painted.  It looks as though no one is home right now.\n"+
"What a shame.  The people who live here are probably friendly, and\n"+
"would most definitely let someone as nice as you into their home --\n"+
"as long as you clean your feet on their bright pink welcome mat.\n",
 1)
id(str) {
  return str == "door";
}

search_mat(str) {
object key;
if (str != "mat") return 1;
key = present("house key", this_player());
if (key) return 1;
  write("You find a key hidden under the mat.\n");
  key = clone_object("players/static/obj/house_key");
  move_object(key, this_player());
  return 1;
}
open(str) {
    if (str && str != "door")
	return 0;
    if (door_is_open)
	return 0;
    if (door_is_locked) {
	write("The door is locked.\n");
	return 1;
    }
    door_is_open = 1;
    write("Ok.\n");
    say(call_other(this_player(), "query_name") + " opened the door.\n");
    return 1;
}

unlock(str) {
    if (str && str != "door")
	return 0;
    if (door_is_open || !door_is_locked)
	return 0;
    if (!present("house key", this_player())) {
	if (present("key", this_player()))
	    write("You don't have the right key.\n");
	else
	    write("You need a key.\n");
	return 1;
    }
    door_is_locked = 0;
    write("ok.\n");
    say(call_other(this_player(), "query_name") + " unlocked the door.\n");
    return 1;
}

enter_house() {
    if (!door_is_open) {
	write("The door is closed.\n");
	return 1;
    }
  call_other(this_player(), "move_player",
    "into house#players/static/HOUSE/living_room");
    return 1;
}

query_door() {
    return !door_is_open;
}

open_door_inside() {
    door_is_locked = 0;
    door_is_open = 1;
}
