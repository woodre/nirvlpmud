inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Vill Road 2 (e, w)";
  long_desc = 
  "Under Contrux\n";
  dest_dir =({
  "players/static/WATER/vill_road1", "west",
  "players/static/WATER/vill_road3", "east"
  });
  }
}

