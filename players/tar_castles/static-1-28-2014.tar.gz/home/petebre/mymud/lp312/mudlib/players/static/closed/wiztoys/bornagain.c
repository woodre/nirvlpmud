init(){
  if(call_other(this_player(),"query_real_name") == "static"){
  }
     add_action("birth", "birth");
}


reset(arg){

   if(arg)
     return;
}

birth(str)
{
string who;
object ob;
if(!str) return 0;
if(sscanf(str, "%s", who) !=1) return 0;
ob=find_living(who);
if(!ob) {
  write("Could not find '"+str+"'\n");
  return 1;
  }
call_other(ob, "child_birth");
write("Ok.\n");
return 1;
}


id(str){
  return str == "string";
}
 short(){
return "A life string";
}

long(){
  
  write("A Life String\n"+
   "Usage: birth [player]\n");
}

get(){

  if(this_player() && this_player()->query_level() < 21)
     destruct(this_object());
     return 1;

}

drop () {
  write("The string turns black then crumbles as you drop it.\n");
  destruct(this_object());
  return 1;
}
