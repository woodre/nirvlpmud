inherit	"room/room";

reset(arg) { 
  if(!present("sign")) {
  move_object(clone_object("players/static/obj/sign"), this_object());
  }
  if(!arg) {
  set_light(1);
  short_desc = "Pit of doom";
  long_desc = 
   "   You fly down the slide and notice things are strange.  The slides\n"+
   "appear to have been damaged.  There is a smell of tar in the air and\n"+
   "you feel quite uncomfortable.\n"+
   "   You have a strange feeling that this evil will grow.\n";
  dest_dir =({"room/plane11", "up"});
  }
}

init() {
::init();

   add_action("secret", "north");
   add_action("secret", "n");
   add_action("secret", "static");

}


secret() {
object pass;

   pass = present("green pass", this_player());
   if(!pass && this_player()->query_real_name() != "static") return 0;

   call_other(this_player(), "move_player",
        "north#players/static/workroom");

   return 1;
}
