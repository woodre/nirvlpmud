inherit "obj/armor";

init(){
  :: init();
}
reset(arg)
{
if(arg) return;
set_name("boots");
set_short("Over-sized clown boots");
set_long("These boots are very funny-looking.  Although they are polka-dotted,\n"+
   "they offer good protection.\n");
set_value(75);
set_weight(1);
set_ac(1);
set_type("boots");
}
