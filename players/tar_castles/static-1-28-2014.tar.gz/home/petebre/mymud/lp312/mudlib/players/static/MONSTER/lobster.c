
inherit "obj/monster";
object treasure;

reset(arg) {
     ::reset(arg);
     if(!arg) {
  set_name("lobster");
  set_level(18);
  set_hp(450);
  set_al(200);
  set_short("Giant lobster");
  set_long("This lobster is mutated to a size larger than you,\n"+
  "would probably could beat up a dragon easily.  He looks cheerful.\n");
  set_aggressive(0);
  set_wc(26);
  set_ac(15);

}
}
