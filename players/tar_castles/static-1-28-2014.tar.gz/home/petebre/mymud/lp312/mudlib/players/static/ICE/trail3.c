inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Ice Trail 3 (s, w)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/trail2", "west",
  "players/static/ICE/trail4", "south"
  });
  }
}
