inherit "obj/monster.talk";

reset(arg) {
     object money, shield, weapon;
     ::reset(arg);
     if(!arg) {
          set_name("dragon");
          set_level(19);
          set_hp(475);
          set_al(500);
          set_short("Pink Dragon");
          set_long("An enormous winged creature.  It is rather peaceful and\n"+
          "good, but extremely deadly if attacked.\n");
          set_aggressive(0);
          set_wc(28);
          set_ac(16);
          money=clone_object("obj/money");
          shield=clone_object("players/static/ARMOR/shield.c");
          weapon=clone_object("players/static/WEAPON/damnation.c");
          money->set_money(1000+random(500));
          move_object(money, this_object());
          move_object(shield, this_object());
          move_object(weapon, this_object());
          set_chat_chance(75);
          load_chat("Pink Dragon says: only NEWBIES are allowed south of here.\n");
}
}
