inherit	"room/room";

reset(arg) { 
  if(!present("picture")) {
  move_object(clone_object("players/static/obj/picture2"), this_object());
  }
  if(!arg) {
  set_light(1);
  short_desc = "Entrance to the Grand Maze";
  long_desc =
"   This is the entrance to some sort of Maze.  Looks pretty creepy...\n"+
"Do you really think you are ready for such a thing?  It is hopeless...\n"+
"Many, many people have tried this maze (you can see their bones\n"+
"laying on the ground below you.  Well, make up your mind of what to\n"+
"do...\n";

  dest_dir =({"players/static/room/MAZE/maze1", "south"
     });
  }
}
realm() { return "NT"; }
