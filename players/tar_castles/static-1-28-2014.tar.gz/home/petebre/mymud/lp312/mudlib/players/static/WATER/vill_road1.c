inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Vill road 1";
  long_desc = 
"   You are approaching a village.  It doesn't seem like a very big\n"+
"village at that, but something tells you there is something of\n"+
"vital importance here.\n";
  dest_dir =({
  "players/static/WATER/s_shore1", "west",
  "players/static/WATER/vill_road2", "east"
  });
  }
}

