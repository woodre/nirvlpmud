inherit	"room/room";

reset(arg) { 
  if(!present("kirk")) 
  move_object(clone_object("players/static/MONSTER/kirk"),
     this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Trail 4 (e, w)";
  long_desc = 
  "UNDER CONTRUX\n";
  dest_dir = ({
  "players/static/room/trail3", "west",
  "players/static/room/trail5", "east"
  });
  }
}
