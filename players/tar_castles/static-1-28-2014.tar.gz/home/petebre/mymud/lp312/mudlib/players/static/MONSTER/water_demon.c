
inherit "obj/monster";

reset(arg) {
  object weapon, money;
  ::reset(arg);
     if(!arg) {
  set_name("water demon");
  set_alias("demon");
  set_level(15);
  set_hp(250);
  set_al(-300);
  set_short("Water demon");
  set_long("This is a demon.  Demons don't like anyone.\n");
  set_aggressive(1);
  set_wc(20);
  set_ac(12);

  weapon = clone_object("players/static/WEAPON/sting_ray.c");
  money = clone_object("obj/money");
  money->set_money(500);

  move_object(weapon, this_object());
  move_object(money, this_object());
}
}
