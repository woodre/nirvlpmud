inherit	"room/room";

reset(arg) { 
  if(!present("statue")) 
  move_object(clone_object("players/static/obj/snake_statue"),
     this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Snake Shrine (n)";
  long_desc = 
  "   This is the worshipping grounds where the Snake god is worshipped.\n"+
  "Rituals that seem bizarre to humans are held here.  This place is\n"+
  "much off limits to the common people of the lands.\n";
  dest_dir = ({
  "players/static/room/snake_hall", "south"
  });
  }
}
