inherit "obj/treasure";

reset(arg)
{
  if (arg) return;
  set_id("horn");
  set_short("Horn of blasting");
  set_long("This nifty little toy makes it look like everyone shouts something.\n"+
     "  Usage : ashout [str]\n");
  set_weight(0);
  set_value(0);
}

init()
{
   add_action("all_shout", "ashout");
}



all_shout(str) {

   object a;
   int i;
   string plyr;

   if(!str) {
   write("Usage : ashout [str]\n");
   return 1;
   }

   a = users();

   while (i < sizeof(a)) {
   plyr = capitalize(a[i]->query_real_name());
   write(plyr + " shouts: "+str+"\n\n");
   shout(plyr + " shouts: "+str+"\n\n");
   i += 1;
   }

write("Done.\n");
return 1;
}
