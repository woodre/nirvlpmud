inherit	"room/room";

int shield, anchor;
reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Somewhere you're not";
  long_desc = 
"  You are standing within a slaying ground.  The scent of rotten\n"+
"corpses paints the air with colorful fragrance.  Static has\n"+
"been away for a while, and renegades have taken over her workroom.\n"+
"'They will not do this again!' she says.  Soon this section of\n"+
"the universe will be back in order.  But until then, someone find\n"+
"a tulip.\n";

  dest_dir =({
  "players/static/room/cool", "south",
  "room/church", "church",
  "room/adv_guild", "guild",
  "room/post", "post",
  "room/shop", "shop",
  "players/static/testroom", "testroom"
  });
  shield = 1;
  }
}

init() {
  ::init();
  add_action("set_shield", "shield");
  add_action("set_anchor", "anchor");
  add_action("invite_living", "invite");
  add_action("eject", "eject");
  check();
}

heart_beat() {

object me;

me = find_living("static");

if(!me) return 1;

me = present("static");

if(me) return 1;

me = find_living("static");
move_object(me, this_object());
}
exit() {
  say(this_player()->query_real_name()+" just left the room.\n");

}

static set_shield(str) {
  if(this_player()->query_real_name() != "static") { return 1; }
  if(!str) {
  string shld;
  shld = "off";
  if (shield) shld = "on";
  write("<< Shields are currently "+shld+" >>\n");
  return 1;
  }

  if(str == "on") {
    write("You turn the shields on.\n");
    say("You feel a magical force field surround the room.\n");
    shield = 1;
    return 1;
    }

  if(str == "off") {
    write("You turn the shields off.\n");
    say("The magical force field disappears.\n");
    shield = 0;
    return 1;
    }
  write("Usage : shield [on/off]\n");
  return 1;
}

static set_anchor(str) {

if(!str) {
  string anc;
  anc = "off";
  if (anchor) anc = "on";
  write("<< Anchor is "+anc+" >>\n");
  return 1;
  }

  if (str == "on") {
  anchor = 1;
  set_heart_beat(1);
  write("You put the anchor on.\n");
  return 1;
  }

  if (str == "off") {
  anchor = 0;
  write("You turn the anchor off.\n");
  set_heart_beat(0);
  return 1;
  }

  write("Usage : anchor [on/off]\n");
  return 1;
}

check() {
if (shield && this_player()->query_real_name() != "static") {
  write("You bounce off a powerful force field guarding the room.\n");
  say(this_player()->query_real_name()+" just attempted to enter.\n");
  move_object(this_player(), "/room/church");
  return 1;
  }

  say(this_player()->query_real_name()+" enters the room.\n");
  return 1;
}

static invite_living(str) {
int temp;
  object ob;
   if(this_player()->query_real_name() != "static") return 1;
  ob = find_living(str);
  if(!ob) { write("Could not find '+"+str+"'.\n"); return 1; }
  temp = shield;
  shield = 0;
  tell_object(ob, "You are magically transferred somewhere.\n");
  tell_room(this_object(), ob->query_name()+" arrives in a puff of smoke.\n");
  move_object(ob, environment(this_player()));
  shield = temp;
  return 1;
}

static eject(str) {
object ob;

if(this_player()->query_real_name() != "static") return 1;

ob = present(str);
if(!ob) {
   write("Could not find '"+str+"'.\n");
   return 1;
   }

move_object(ob, "room/church");
tell_object(this_player(), str+" has been ejected.\n");

return 1;
}
