inherit "obj/treasure";

reset(arg) {
if(arg) return;

  set_id("wiz tool");
  set_alias("tool");
  set_short("A wiz tool");
  set_long("A very helpful wiztool...\n"+
  "Commands :\n"+"\n"+
  "  hdir --> cd /players"+this_player()->query_real_name()+"\n"+
  "  wdir --> cd /players/yourname/WEAPON\n"+
  "  mdir --> cd /players/yourname/MONSTER\n"+
  "  adir --> cd /players/yourname/ARMOR\n"+
  "  odir --> cd /players/yourname/OBJ\n"+
  "  rdir --> cd /players/yourname/ROOM\n");

  set_weight(0);
  set_value(0);

}

init() {

   add_action("home_dir",     "hdir");
   add_action("weapon_dir",   "wdir");
   add_action("armor_dir",    "adir");
   add_action("monster_dir",  "mdir");
   add_action("object_dir",   "odir");
   add_action("room_dir",     "rdir");
 }


home_dir() {

  command ("cd ~", this_player());
 
return 1;
}

