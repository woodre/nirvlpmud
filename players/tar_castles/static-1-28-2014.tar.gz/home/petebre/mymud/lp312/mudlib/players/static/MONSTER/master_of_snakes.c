
inherit"obj/monster";
reset(arg) {
object wand;
::reset(arg);
if(arg) return;
set_name("master of snakes");
set_alias("master");
set_short("Master of Snakes");
set_long(
"This is the mighty ruler of snakes.  Legend has it that he was\n"+
"bitten by a radioactive snake when he was young.  He has since\n"+
"assimilated into their kingdom.\n");
set_level(15);
set_hp(225);
set_wc(20);
set_aggressive(0);
set_ac(12);
wand = clone_object("players/static/obj/wand_of_snakes");
move_object(wand, this_object());
}

init() {
::init();

add_action("kill_this_guy", "kill");

}



kill_this_guy(str) {

object snake, statue;
int i;

if (str != "master") return;

statue = present("snake statue", environment(this_player()));
if(statue) return;
say("The Snake Master summons snakes to protect him!\n");

for (i=0; i<5; i++) {

snake = clone_object("players/static/MONSTER/guardian_snake");
move_object(snake, environment(this_object()));
}

say("He then retreats south...\n");
move_object(this_object(), "players/static/room/snake_altar");
return 1;
}
