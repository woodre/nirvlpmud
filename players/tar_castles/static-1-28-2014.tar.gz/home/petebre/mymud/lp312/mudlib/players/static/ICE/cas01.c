inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 01 (s, e, w, leave)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas02", "south",
  "players/static/ICE/cas04w", "west",
  "players/static/ICE/cas04e", "east",
  "players/static/ICE/castle_entrance", "leave"
  });
  }
}
