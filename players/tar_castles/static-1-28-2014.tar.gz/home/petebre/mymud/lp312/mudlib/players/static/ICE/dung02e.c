inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Dungeon";
  long_desc = 
  "   You are in a light green room.  It is illuminated by a similarly\n"+
  "green light.  You can hear hissing sounds to the north.\n";
  dest_dir = ({
  "players/static/ICE/dung01", "west",
  "players/static/ICE/dung03e", "north"
  });
  }
}

realm() {
return("NT");
}
