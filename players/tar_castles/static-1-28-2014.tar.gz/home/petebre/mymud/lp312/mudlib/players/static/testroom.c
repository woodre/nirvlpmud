   inherit "room/room";
      reset(arg) {
         if(arg) return;
   short_desc = "Test Room";
    long_desc = "  This is the room where Static tests all her\n"+
               "weapons, armors, and monsters.  It's dangerous\n"+
               "in this small place.\n";
   set_light(1);
   dest_dir =
  ({
    "players/static/workroom", "workroom",
    "room/church", "down" });
}
