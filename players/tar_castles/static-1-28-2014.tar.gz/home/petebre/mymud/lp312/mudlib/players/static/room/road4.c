inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Road 4";
  long_desc = 
"  The lights turn an electric white color here.  Many a drunken\n"+
"fellow lay on the street.  This is obviously not the rich section\n"+
"of town.\n"+
"You hear loud noises from the west.\n";

  dest_dir =({"players/static/room/road3", "north",
    "players/static/room/takeout", "west",
    "players/static/room/road5", "south"});
  }
}
