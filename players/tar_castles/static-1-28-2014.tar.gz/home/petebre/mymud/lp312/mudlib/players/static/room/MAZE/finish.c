inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Final Room in MAZE";
  long_desc = 
   "   You have reached the end of the Grand MAZE!\n";

  dest_dir =({"players/static/room/MAZE/maze1", "south"});
  }
}
realm() { return "NT"; }
