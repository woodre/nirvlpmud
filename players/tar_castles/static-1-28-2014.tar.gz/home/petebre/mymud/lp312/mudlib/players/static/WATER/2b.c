inherit	"room/room";

reset(arg) { 
  if(!present("water elemental"))
  move_object(clone_object("players/static/MONSTER/water_elemental"),
  this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Water 2B (s)";
  long_desc = 
  "   There is a lot of energy here.  You can feel the force of the\n"+
  "bonding of the elements of water.  It is almost like you are in\n"+
  "a vacuum.\n";
  dest_dir =({
  "players/static/WATER/3b", "south"
  });
  }
}
