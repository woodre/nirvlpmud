inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Ice Patch 2 (s, w)";
  long_desc = 
  "   The air has grown even colder.  You can no longer see the\n"+
  "gravel of which the road is formed.  You are standing on a solid\n"+
  "sheet of ice.\n";
  dest_dir = ({
  "players/static/ICE/ice_patch", "west",
  "players/static/ICE/frozen_pond", "south"
  });
  }
}
