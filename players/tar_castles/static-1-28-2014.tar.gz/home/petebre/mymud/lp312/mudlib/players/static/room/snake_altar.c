inherit	"room/room";

reset(arg) { 
  if(!present("statue")) 
  move_object(clone_object("players/static/obj/snake_statue"),
     this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Snake Altar";
  long_desc = 
  "   This is the evil church of the Snake.  The magical power\n"+
  "present makes it impossible to fight in this place, which they\n"+
  "deem solemn and holy.\n";
  dest_dir = ({
  "players/static/room/snake_hall", "north"
  });
  }
}


