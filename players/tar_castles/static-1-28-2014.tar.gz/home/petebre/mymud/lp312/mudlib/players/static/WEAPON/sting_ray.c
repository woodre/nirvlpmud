inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("sting ray");
  set_alias("ray");
  set_class(15);
  set_short("Sting ray");
  set_long("A ray used for stinging a victim.\n");
  set_value(400);
  set_weight(2);

  set_hit_func(this_object());

}

weapon_hit(attacker) {
int i;

i = random (100);
if (i > 75) {
   write(attacker->query_name()+ " is stung by your ray!\n");
   say(this_player()->query_name()+" strikes "+attacker->query_name()+
   " with the sting ray.\n");
   return 6;
}

return 0;
}

