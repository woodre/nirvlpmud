inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Ice Trail 4 (n, w)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/trail3", "north",
  "players/static/ICE/trail5", "west"
  });
  }
}
