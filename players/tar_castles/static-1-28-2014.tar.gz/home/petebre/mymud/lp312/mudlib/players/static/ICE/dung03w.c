inherit	"room/room";

reset(arg) { 
  if(!present("dragon"))
  move_object(clone_object("players/static/MONSTER/devil_dragon"),
  this_object());

  if(!arg) {
  set_light(1);
  short_desc = "Dungeon";
  long_desc = 
  "   Well, I guess its not that safe down here.  This room is a darkened\n"+
  "black.  You can bet this isnt the guest room.\n"+
  "To the north, you see a keeping chamber.\n";
  dest_dir = ({
  "players/static/ICE/dung02w", "south"
  });
  }
}


init() {
::init();
add_action("go_north", "north");
add_action("go_north", "n");
}

go_north() {

object dragon;

dragon = present("dragon");

if(dragon) {
   write("Dragon scowls at you as you try to pass.\n");
   return 1;
}

call_other(this_player(), "move_player",
  "north#players/static/ICE/dung04w.c");
  return 1;
}

realm() {
return("NT");
}
