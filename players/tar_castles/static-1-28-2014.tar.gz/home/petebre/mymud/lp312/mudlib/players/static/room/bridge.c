inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Crystal bridge";
  long_desc = 
"   You are standing on top of a medium-sized ridge.  It is made of\n"+
"crystalline steel.  You can see right through it!  Down below, you\n"+
"see a clear river.  The water looks pretty deep.  Deep enough to dive\n"+
"into.\n";

  dest_dir =({
  "players/static/room/dirt_road", "north",
  "players/static/room/road1", "south"
  });
  }
}

init() {
  ::init();
add_action("dive", "dive");
add_action("dive", "down");
add_action("dive", "d");
}


dive() {
  say(this_player()->query_name()+" dives off the bridge.\n");
  write("You perfrom a magnificent swan dive.\n");
  write("Your are even amazed by yourself as you make this glorious dive.\n"+
  "Upon hitting the water, you feel invigorated.  You swim a little ways\n"+
  "to where the water is not as deep.\n\n");
  call_other(this_player(), "move_player",
    "performing a swan dive#players/static/WATER/under_bridge");
    return 1;
}
