inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Stairs (s, d)";
  long_desc = 
  "   You are at the entrance to the dungeon.  It looks dark down there.\n"+
  "Already, your spine tingles at the thought of what could be down there.\n";
  dest_dir = ({
  "players/static/ICE/dung01", "down",
  "players/static/ICE/cas11", "south"
  });
  }
}

realm() {
return("NT");
}
