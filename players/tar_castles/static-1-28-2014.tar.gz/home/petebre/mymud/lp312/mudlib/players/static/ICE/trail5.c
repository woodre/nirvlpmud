inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Ice Trail 5 (s, e)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/trail4", "east",
  "players/static/ICE/castle_entrance", "south"
  });
  }
}
