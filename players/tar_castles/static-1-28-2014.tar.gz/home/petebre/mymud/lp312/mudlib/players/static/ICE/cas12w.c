inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 12w (nw, se)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas10w", "northwest",
  "players/static/ICE/cas13", "southeast"
  });
  }
}
