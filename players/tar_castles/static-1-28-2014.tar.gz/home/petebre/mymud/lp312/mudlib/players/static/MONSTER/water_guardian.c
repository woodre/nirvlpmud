
inherit "obj/monster";

reset(arg) {
  object armor, money;
  ::reset(arg);
     if(!arg) {
  set_name("water guardian");
  set_alias("guardian");
  set_level(18);
  set_hp(450);
  set_al(-300);
  set_short("Water guardian");
  set_long("This guardian has eyes that are glowing a fire red.\n"+
  "He seems quite angry, he must do his job... he hates it.\n");
  set_aggressive(0);
  set_wc(26);
  set_ac(15);

  armor = clone_object("players/static/ARMOR/water_weave");
  money = clone_object("obj/money");
  money->set_money(500);

  move_object(armor, this_object());
  move_object(money, this_object());
}
}
