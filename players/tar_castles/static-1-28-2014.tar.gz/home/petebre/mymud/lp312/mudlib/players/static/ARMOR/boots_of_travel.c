inherit "obj/armor";

init(){
  :: init();
}
reset(arg)
{
if(arg) return;
  set_name("boots of travel");
  set_alias("boots");
  set_short("Boots of Travel");
  set_long("These boots shine ith a magical aura.  They same to\n"+
  "be as light as air and may carry you wit them.\n");
  set_value(100);
  set_weight(1);
  set_ac(1);
set_type("boots");
}
