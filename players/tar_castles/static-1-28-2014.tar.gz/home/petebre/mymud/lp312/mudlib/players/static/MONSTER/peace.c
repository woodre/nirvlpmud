
inherit "obj/monster";

reset(arg) {
  object soul;
  ::reset(arg);
  if(!arg) {
   set_name("peace");
   set_level(1);
   set_hp(1);
   set_al(0);
   set_short("Peace");
  set_long("This is an android of Peace.\n");
   set_aggressive(0);
   set_wc(20);
   set_ac(0);
soul = clone_object("obj/soul");
   move_object(soul, this_object());
}
}
