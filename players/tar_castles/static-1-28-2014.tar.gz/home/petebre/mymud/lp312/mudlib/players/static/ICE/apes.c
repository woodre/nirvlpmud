inherit	"room/room";

reset(arg) { 
  if(!present("white ape")) make_monsters();
  if(!arg) {
  set_light(1);
  short_desc = "White Apes (n)";
  long_desc = 
  "   An isolated section of the jungle.  Here is the home of the White ape.\n"+
  "They do not enjoy visitors, and are usually very hostile towards them.\n"+
  "The apes usually spend most of their time arguing and feasting.\n";
  dest_dir = ({
  "players/static/ICE/ice_jungle", "north"
  });
  }
}

make_monsters() {

object ape;
int i;

for (i=0; i<4; i++) {
   ape = clone_object("players/static/MONSTER/white_ape");
   move_object(ape, this_object());
   }

}
