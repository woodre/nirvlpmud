#define NAME "Static"
#define DEST "room/plane11"

id(str) { return str == "slide" || str == "waterslide"; }

short() {
     return "A Gigantic Waterslide (with a chute leading DOWN)";
}

long() {
    write("A very long waterslide.  It would be extremely pleasurable\n"+
          "to ride 'down' it.\n");
}

init() {
    add_action("down", "down");
}

down() {
    write("You jump into the slide head-first!\n");
    this_player()->move_player("slide#players/static/room/cool");
    return 1;
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
/*
    clone_object("players/static/closed/toy.c");
    clone_object("players/static/obj/enhancer.c");
    clone_object("players/static/obj/green_pass.c");
 */
}

is_castle() { return 1; }
