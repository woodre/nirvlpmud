
inherit "obj/monster";

reset(arg) {
     ::reset(arg);
     if(!arg) {
  set_name("guardian snake");
  set_alias("snake");
  set_level(10);
  set_hp(150);
  set_al(-50);
  set_short("Guardian snake");
  set_long(
  "This snake is called upon to serve a fellow member of the snake\n"+
  "family.  It will protect its master obediently.\n");
  set_aggressive(1);
  set_wc(14);
  set_ac(8);
}
}
