inherit "obj/armor";

init(){
  :: init();
}
reset(arg)
{
if(arg) return;
set_name("shield");
set_short("Pink Shield");
set_long("The shield from a Pink Dragon.\n");
set_value(100);
set_weight(1);
set_ac(1);
set_type("shield");
}
