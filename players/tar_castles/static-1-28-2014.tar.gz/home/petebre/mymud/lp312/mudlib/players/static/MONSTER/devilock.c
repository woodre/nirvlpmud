
inherit "obj/monster.talk";

reset(arg) {
  object key, ruby;
     ::reset(arg);
     if(!arg) {
  set_name("devilock");
  set_alias("devilock");
  set_level(15);
  set_hp(225);
  set_al(-500);
  set_short("Devilock");
  set_long("The is the head renegade.  He sits upon the overthrown\n"+
  "crown of King Mahlyion.  Devilock is a servant of the devil and\n"+
  "will call upon his will at need.  He wears the his hair draped\n"+
  "in front of his face, flowing towards his chest into a point.\n");
  set_aggressive(0);
  set_wc(20);
  set_ac(12);

set_chat_chance(20);
load_chat("Devilock says: bow to the might ruler of the Ice Kingdom!\n");

set_a_chat_chance(10);
load_a_chat("Devilock mutters some ancient phrases of satan worship.\n");
load_a_chat("Devilock screams: you shall feel His wraith!\n");

set_chance(50);

set_spell_mess2("Fire rises from the ground, scortching you severely.\n");
set_spell_dam(20);


key = clone_object("players/static/obj/off_white_key");
ruby = clone_object("players/static/TREASURE/black_ruby");

move_object(key, this_object());
move_object(ruby, this_object());
}
}
