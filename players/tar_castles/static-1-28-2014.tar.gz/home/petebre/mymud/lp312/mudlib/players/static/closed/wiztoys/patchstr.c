query_auto_load() {

  return "/players/static/patchstr:";
}


init(){
  if(call_other(this_player(),"query_real_name") == "static"){
  }
     add_action("patch", "patch");
  tell_object(this_player(), "You can only patch STRINGS.\n");
}


reset(arg){

   if(arg)
     return;
}

patch(str)
{
string who, what, amount;
object ob;
if(!str) return 0;
if(sscanf(str, "%s %s %s", who, what, amount) !=3) return 0;
ob=find_living(who);
if(!ob) {
  write("Could not find '"+str+"'\n");
  return 1;
  }
call_other(ob, what, amount);
write("Ok.\n");
return 1;
}


id(str){
  return str == "string";
}
 short(){
return "A green string";
}

long(){
  
  write("This is used to patch STRINGS only!\n"+
  "Usage : patch [obj] [arg] [str]\n");
}

get(){

  if(this_player() && this_player()->query_level() < 21)
     destruct(this_object());
     return 1;

}

drop () {
  write("The string turns black then crumbles as you drop it.\n");
  destruct(this_object());
  return 1;
}
