#include "std.h"
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
extra_reset(){
monster();
}

monster() {
int i;
  if(!present("bee")) {
  while(i<5) {
  move_object(clone_object("players/static/MONSTER/bee"), this_object());
  i++;
  }
  }
}
#undef EXTRA_INIT
#define EXTRA_INIT\
    add_action("enter"); add_verb("enter");
    TWO_EXIT("players/static/room/MAZE/maze21", "north",
    "players/static/room/MAZE/maze23", "west",
   "Killer bees (s)",
   "   You have reached the end of the trail.  This is the entrance to\n"+
   "the hive of the killer bee.  But, defending the bees will defend\n"+
   "their territory to the death.\n"+
   "A Giant beehive (so big you could enter it!)\n", 1)
enter(str) {
   if(str != ("beehive")) return 0;
   if (present("bee")) {
write("Bee won't let you into its hive.\n");
	return 1;
    }
    call_other(this_player(), "move_player", "beehive#players/static/room/beehive");
    return 1;
}

