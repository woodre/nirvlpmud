inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Vill Road 4 (n, in)";
  long_desc = 
  "   You are standing outside of a thatched hut.  There is a brightly\n"+
  "painted sign here:\n"+
  "\n"+
  "<-><-><-><-><-><-><-><-><-><-><-><-><-><-><-><->\n"+
  "<->                                          <->\n"+
  "<->  QUARINTINE AREA!                        <->\n"+
  "<->  Please leave, we do not want you to     <->\n"+
  "<->  acquire the curse our leader has        <->\n"+
  "<->  our leader has been damned.             <->\n"+
  "<->                                          <->\n"+
  "<-><-><-><-><-><-><-><-><-><-><-><-><-><-><-><->\n"+"\n"+
  "   You hear laughter coming from inside the hut.  This sign could\n"+
  "just be a joke.  Sounds lively inside...\n";
  dest_dir =({
  "players/static/WATER/vill_road3", "north",
  "players/static/WATER/kuru_hut", "in"
  });
  }
}

