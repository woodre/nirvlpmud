inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Kitchen";
  long_desc = 
"   This is a well-equipped kitchen: featuring a gas-burning stove,\n"+
"solar-powered dishwasher,  economy-efficient refrigerator.It is\n"+
"very clean --  someone must have cleaned it recently...\n"+
"The stove is painted a bright red!  Whomever owns this house, must be\n"+
"color blind or someone crazy enough to be friends with Static.\n"+
"   You see some stairs that probably lead down to a basement.\n";

  dest_dir = ({
  "players/static/HOUSE/living_room", "north",
  "players/static/HOUSE/basement", "down"
  });
  }
}
