inherit	"room/room";

reset(arg) { 
  if(!present("picture")) {
  move_object(clone_object("players/static/obj/picture"), this_object());
  }
  if(!arg) {
  set_light(1);
  short_desc = "Study";
  long_desc = 
"   You are in a study.  In the corner is an interesing lamp.  It\n"+
"is a shade of light green, casting bright light.  There is a desk here,\n"+
"which seems to get a lot of usage.  Many a book are laying on the\n"+
"desk.  Most of them are of the topic of astronomy.  Also, in his\n"+
"room, a poignant picture is hanging upon the wall.\n";
  dest_dir = ({
  "players/static/HOUSE/living_room", "west",
  });
  }
}
