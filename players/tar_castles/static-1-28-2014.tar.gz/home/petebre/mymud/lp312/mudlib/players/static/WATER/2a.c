inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Water 2A (n, s)";
  long_desc = 
   "   You are swimming in water that is quite deep.  It is a wonder\n"+
   "how you can swim with all the equipment that you are carrying.\n"+
   "There is a strong current pulling from the east, but you dare not\n"+
   "go that way for fear of becoming stuck.\n";
  dest_dir =({
  "players/static/WATER/1a", "north",
  "players/static/WATER/3a", "south"
  });
  }
}
