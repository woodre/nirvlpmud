inherit "obj/treasure";

reset(arg)
{
    if (arg) return;
    set_id("guide");
    set_short("PMRC guide");
    set_long("The official PMRC booklet of censorship.\n"+
    "Rule #1: Suppress freedom of speech\n"+
    "Rule #2: Find anyone who disobeys Rule #1 and make their lives miserable"+
    "\n"+"Rule #3: Convert the entire planet to law abiding Christians\n");
    set_weight(1);
    set_value(500);
}
