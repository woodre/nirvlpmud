inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Under the bridge";
  long_desc = 
   "   You are wading in the stream.  The water seems to go on for ever.\n"+
   "Luckily, there is a foothold.  There is a steel rung ladder here.\n";
  dest_dir =({
  "players/static/room/bridge", "up",
  "players/static/WATER/1a", "east"
  });
  }
}
