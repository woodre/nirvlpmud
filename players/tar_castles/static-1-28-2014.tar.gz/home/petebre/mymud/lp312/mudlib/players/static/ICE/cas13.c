inherit	"room/room";

reset(arg) { 

  if(!present("devilock"))
  move_object(clone_object("players/static/MONSTER/devilock"),
     this_object());

  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 13 (nw, ne)";
  long_desc = 
  "   You are in the throne room.  An elegant curtain is hung on the\n"+
  "stone wall.  It is very peaceful in here, allowing the king to\n"+
  "think and make important decisions about his kingdom.\n";
  dest_dir = ({
  "players/static/ICE/cas12w", "northwest",
  "players/static/ICE/cas12e", "northeast"
  });
  }
}
