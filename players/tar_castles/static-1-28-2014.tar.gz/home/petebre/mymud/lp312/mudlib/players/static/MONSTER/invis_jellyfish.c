
inherit "obj/monster";

reset(arg) {
     ::reset(arg);
     if(!arg) {
       set_name("jellyfish");
       set_short("");
       set_long("This is an invisible jellyfish.\n");
       set_level(3);
       set_hp(45);
       set_al(-50);
       set_aggressive(1);
       set_wc(7);
       set_ac(4);
}
}
