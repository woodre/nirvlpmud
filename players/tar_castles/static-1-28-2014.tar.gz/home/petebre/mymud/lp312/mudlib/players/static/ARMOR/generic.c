inherit "obj/armor";

init(){
  :: init();
}
reset(arg)
{
if(arg) return;
set_name("armor");
set_short("Nameless Armor");
set_long("Haven't thought of a name yet.\n");
set_value(100);
set_weight(0);
set_ac(4);
set_type("armor");
}
