inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("fangs");
  set_class(13);
  set_short("Serpent fangs");
  set_long("These fangs seem to be deadly.\n");
  set_value(300);
  set_weight(3);
}
