inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Water 1D (n, s, w)";
  long_desc = 
"  This part of the river is very scummy. The odor is from toxic\n"+
"waste.  There is an enormous aount of rubbage here.  You can see\n"+
"the pipe from which the garbage is coming to the south.  Pollution\n"+
"has been a major problem on a distant planet called Earth... maybe\n"+
"you have heard of it?  And do you dare enter the pipe?\n";
  dest_dir =({
  "players/static/WATER/1c", "west",
  "players/static/WATER/2d", "pipe",
  "players/static/WATER/n_shore1", "north"
  });
  }
}

init() {
int i;
::init();

   for (i=0; i<5; i++) {
   command("puke", this_player());
   }
}
