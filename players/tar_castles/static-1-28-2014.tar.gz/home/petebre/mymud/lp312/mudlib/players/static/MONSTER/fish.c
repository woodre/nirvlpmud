
inherit "obj/monster.talk";

reset(arg) {
  object treasure;
  ::reset(arg);
  if(!arg) {
   set_name("fish");
   set_level(3);
   set_hp(45);
   set_al(100);
   set_short("Friendly fish");
   set_long("These fish are very cute.  They swim along in schools\n"+
   "and play together all day long.  They have no worries...\n");
   set_aggressive(0);
   set_wc(7);
   set_ac(4);
   set_chat_chance(20);
   load_chat("Fish blows bubbles.\n");
   load_chat("Fish smiles at you.\n");
   load_chat("Fish says: beware dark caves!\n");
  treasure = clone_object("players/static/TREASURE/fish_scales");
   move_object(treasure, this_object());
}
}
