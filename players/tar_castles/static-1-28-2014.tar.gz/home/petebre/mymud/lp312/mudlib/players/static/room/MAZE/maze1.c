inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "In the Grand Maze";
  long_desc =
   "   You are in the Grand Maze.  Everything looks the same.\n";

  dest_dir =({"players/static/room/MAZE/entrance", "north",
    "players/static/room/MAZE/maze2", "south"});
  }
}
realm() { return "NT"; }
