inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Trail 1 (e, w)";
  long_desc = 
"   You are traveling along a barely used trail.  One wonders what or\n"+
"who he might find here.  The trees grow tall and fair and the air\n"+
"becomes dry.\n";
  dest_dir = ({
  "players/static/room/road5", "west",
  "players/static/room/trail2", "east"
  });
  }
}
