#include "std.h"
int door_is_open, door_is_locked;
#undef EXTRA_RESET
#define EXTRA_RESET extra_reset();
extra_reset(){
  door_is_open=0; door_is_locked=1;
}

#undef EXTRA_LONG
#define EXTRA_LONG\
    if (str == "door") {\
	if (door_is_open) {\
	    write("The door is open.\n");\
	    return;\
	}\
	write("The door is closed.\n");\
	return;\
    }

#undef EXTRA_INIT
#define EXTRA_INIT\
    add_action("open"); add_verb("open");\
    add_action("unlock"); add_verb("unlock");\
    add_action("south"); add_verb("south");
    TWO_EXIT("players/static/room/MAZE/maze21", "north",
    "players/static/room/MAZE/maze23", "west",
   "Maze Door",
"   You seem to have reached the end of this maze!\n"+
"This room looks magical in a very weird kind of way.  To the south,\n"+
"there is an enormous gold door.\n", 1)
id(str) {
  return str == "door";
}

open(str) {
    if (str && str != "door")
	return 0;
    if (door_is_open)
	return 0;
    if (door_is_locked) {
	write("The door is locked.\n");
	return 1;
    }
    door_is_open = 1;
    write("Ok.\n");
    say(call_other(this_player(), "query_name") + " opened the door.\n");
    return 1;
}

unlock(str) {
    if (str && str != "door")
	return 0;
    if (door_is_open || !door_is_locked)
	return 0;
    if (!present("maze key", this_player())) {
	if (present("key", this_player()))
	    write("You don't have the right key.\n");
	else
	    write("You need a key.\n");
	return 1;
    }
    door_is_locked = 0;
    write("ok.\n");
    say(call_other(this_player(), "query_name") + " unlocked the door.\n");
    return 1;
}

south() {
    if (!door_is_open) {
	write("The door is closed.\n");
	return 1;
    }
    call_other(this_player(), "move_player", "south#players/static/room/MAZE/final");
    return 1;
}

query_door() {
    return !door_is_open;
}

open_door_inside() {
    door_is_locked = 0;
    door_is_open = 1;
}
realm() {
  return "NT";
}
