inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 08e (s, w, e)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas07e", "east",
  "players/static/ICE/cas03", "west",
  "players/static/ICE/cas09e", "south"
  });
  }
}
