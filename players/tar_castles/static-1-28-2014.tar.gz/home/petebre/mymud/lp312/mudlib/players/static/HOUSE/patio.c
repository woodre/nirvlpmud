inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Patio";
  long_desc = 
"   This a patio.  The fresh air feels wonderful.  There is a rocking\n"+
"chair and a bench here for one to relax upon.  During the day, it\n"+
"would be wonderful to sip lemonade under the hot sun.  And at night,\n"+
"you can imagine just laying here with your loved one, gazing at the stars.\n";

  dest_dir = ({
  "players/static/HOUSE/living_room", "south",
  });
  }
}
