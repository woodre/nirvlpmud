inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Road 1";
  long_desc = 
"   You are travelling on a well-lit road.  Street lamps on either\n"+
"side of the road are old-fashioned.  This road seems to be going\n"+
"nowhere, however, it is great traveling on it...\n";

  dest_dir =({"players/static/room/bridge", "north",
    "players/static/HOUSE/entrance", "east",
    "players/static/room/road2", "south"});
  }
}
