
inherit "obj/monster.talk";

reset(arg) {
     object money;
     ::reset(arg);
     if(!arg) {
          set_name("head looter");
          set_alias("looter");
          set_level(11);
        set_hp(220);
          set_al(-159);
          set_aggressive(0);
  set_wc(15);
  set_ac(9);
          money=clone_object("obj/money");
          money->set_money(350);
          move_object(money, this_object());
}
}
