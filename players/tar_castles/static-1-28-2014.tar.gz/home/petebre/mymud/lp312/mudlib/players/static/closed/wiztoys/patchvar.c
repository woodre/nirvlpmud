query_auto_load() {

  return "/players/static/patch2:";
}


init(){
     add_action("patch", "patch");
}


reset(arg){

   if(arg)
     return;
write("Variable fixer.\n");
}

patch(str)
{
string who, what, amount;
object ob;
if(!str) return 0;
if(sscanf(str, "%s %s %d", who, what, amount) !=3) return 0;
ob=find_living(who);
if(!ob) return 0;
if(!living(ob)) return 0;
call_other(ob, what, amount);
write("Ok.\n");
return 1;
}

id(str){
  return str == "wire";
}
 short(){
  return "A curly piece of wire";
}

long(){
  
  write("A charged piece of wire..\n"+
    "Let's u : patch <player> <command> <value>\n"+
    "ONLY VARIABLES CAN BE PATCHED!\n");
}

extra_look(){
   return("Coolerooz!\n");
   return 1;
}
get(){

  if(this_player() && this_player()->query_level() < 21)
     destruct(this_object());
     return 1;

}

