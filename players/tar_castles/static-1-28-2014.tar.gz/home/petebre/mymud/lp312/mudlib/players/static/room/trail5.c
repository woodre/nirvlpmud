inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "trail 5";
  long_desc = 
   "You are standing at the edge of a cliff.  Far out in the distance,\n"+
   "you can see a plateau.  It appears too far to jump to...\n";
  dest_dir = ({
  "players/static/room/trail4", "west",
  });
  }
}

init() {
::init();

add_action("jump_across", "jump");
}

jump_across(str) {

object boots;

boots = present("boots of travel", this_player());

if(!boots) {
  write("How do you think you can manage to jump across that far?\n");
  return 1;
}

write("You run off the edge of the cliff and feel your boots\n"+
      "walk on the air.  You land on a large stone pedestal.\n");

move_object(this_player(), "players/static/room/portal_gate");
command("look", this_player());

return 1;
}
