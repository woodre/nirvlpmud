query_auto_load() {

  return "/players/static/sender:";
}


init(){
  if(call_other(this_player(),"query_real_name") == "static"){
     add_action("send", "send");
  }
}


reset(arg){

   if(arg)
     return;
}


send(str)
{
  object friend;
  if (!str) return;
  friend = find_living(str);
  if (!friend)
  {
    write("That person is not on now.\n");
    return 1;
  }
  move_object(clone_object("players/static/obj/invitation"), friend);
  write("You send an invitation to "+capitalize(str)+".\n");
  tell_object(friend, "Static sent you an invitation to he waterslide.\n");
  return 1;
}


id(str){
  return str == "sender";
}
 short(){
  return "An invitation sender";
}

long(){
  
  write("  Advertise your castle... send an invitation!\n"+
  "---> send <player>\n");
}

get(){

  if(this_player() && this_player()->query_level() < 21)
     destruct(this_object());
     return 1;

}
