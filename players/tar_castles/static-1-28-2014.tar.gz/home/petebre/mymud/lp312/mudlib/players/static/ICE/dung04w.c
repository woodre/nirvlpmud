inherit	"room/room";

reset(arg) { 
  if(!present("king"))
  move_object(clone_object("players/static/MONSTER/ice_king"),
  this_object());

  if(!arg) {
  set_light(1);
  short_desc = "Dungeon";
  long_desc = 
  "  This is a keeping chamber for traitors to the kingdom.\n";
  dest_dir = ({
  "players/static/ICE/dung03w", "south"
  });
  }
}

realm() {
return("NT");
}
