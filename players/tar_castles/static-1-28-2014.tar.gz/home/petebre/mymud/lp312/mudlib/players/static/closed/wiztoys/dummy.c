
inherit "obj/monster.talk";

reset(arg) {
  ::reset(arg);
  if(!arg) {
   set_name("dummy");
   set_level(70);
   set_hp(1);
   set_al(0);
   set_short("A Crash-Test Dummy");
   set_long("This magical creature is very hurt.\n");
   set_aggressive(0);
   set_wc(0);
   set_ac(0);
}
}
