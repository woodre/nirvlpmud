inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Road 5 (n, s, e)";
  long_desc = 
"   You are approaching the outskirts of this small town.  In the\n"+
"eastern horizon, you can see for a many miles.  Barren territory,\n"+
"all to be claimed...  And far to the south, you can see a giant white\n"+
"fortress.\n";

  dest_dir =({"players/static/room/road4", "north",
    "players/static/room/trail1", "east",
    "players/static/ICE/ice_patch", "south"});
  }
}
