inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Trail 3 (e, w)";
  long_desc = 
  "UNDER CONTRUX\n";
  dest_dir = ({
  "players/static/room/trail2", "west",
  "players/static/room/trail4", "east"
  });
  }
}
