
inherit "obj/monster";

reset(arg) {
  object money;
     ::reset(arg);
     if(!arg) {
  set_name("water serpent");
  set_alias("serpent");
  set_level(13);
  set_hp(195);
  set_al(-50);
  set_short("Water serpent");
  set_long("This serpents home is the water.  It loves to swim in\n"+
  "clear water... and doesn't take fond of visitors.\n");
  set_aggressive(1);
  set_wc(20);
  set_ac(17);
  set_ac(10);
  money = clone_object("obj/money");
  money->set_money(10+random(30));
  move_object(money, this_object());
}
}
