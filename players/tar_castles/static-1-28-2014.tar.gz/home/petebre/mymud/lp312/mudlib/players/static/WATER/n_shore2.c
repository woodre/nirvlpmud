inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "N Shore 2 (n, e)";
  long_desc = 
  "UNDER CONSTRUX\n";
  dest_dir =({
  "players/static/WATER/n_shore1", "east",
  "players/static/WATER/n_shore3", "north"
  });
  }
}
