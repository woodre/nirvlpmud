inherit "obj/monster.talk";

reset(arg){
::reset(arg);
if (!arg) {
  set_name("kirk");
  set_short("Kirk of Platonia");
  set_long("Kirk is a nomad traveler.  He may seem a little greedy,\n"+
  "but everyone has their needs.  He's the type of a guy who likes\n"+
  "to roam around...\n");
  set_aggressive(0);
  set_level(10);
  set_hp(150);
  set_wc(14);
  set_ac(8);
  set_al(-200);
  set_chat_chance(35);
  load_chat("Kirk says: Bring me the Rude sword from Newbie land!\n"+
  "Kirk says: I don't care how you get it! Just give it to me!\n"+
  "           Because I've got something for you.\n"+"\n"+
  "Kirk grins.\n");
  set_a_chat_chance(30);
  load_a_chat("Kirk hits you very hard.\n");
  }
}
  catch_tell(str) {
    object from, boots;
    string who, what;
    from = this_player();
    if(!from) return;
    if (sscanf(str, "%s gives %s to Kirk.", who, what) == 2) {
    object ob;
    ob = present("rude sword", this_object());
    if (!ob){
    ob = first_inventory(this_object());
    if(!ob) return 1;
    tell_object(this_player(), "I do not want this "+what+"!\n");
    move_object(ob, environment(this_object()));
    tell_room(environment(this_object()), "Kirk drops "+what+".\n");
    return 1;
    }

    tell_object(this_player(), "Kirk growls: You stupid fool!  Now you shall die!\n");
    command("wield sword", this_object());
    tell_room(environment(this_object()), "As kirk wields his sword, he "+
       "drops something.\n");
    boots = clone_object("players/static/ARMOR/boots_of_travel");
    move_object(boots, environment(this_object()));
    from->attacked_by(this_object());
   return 1;
}
}

