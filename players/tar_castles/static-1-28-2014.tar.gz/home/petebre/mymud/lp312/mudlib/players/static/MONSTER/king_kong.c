
inherit "obj/monster";

reset(arg) {
  object money;
     ::reset(arg);
  if(!arg) {
  set_name("king kong");
  set_alias("kong");
  set_level(20);
  set_hp(500);
  set_al(500);
  set_short("King Kong");
  set_long("An over-sized hairy ape.  His hobbies include stomping on cities\n"+
    "and kidnapping young females.\n");
  set_aggressive(0);
  set_wc(30);
  set_ac(17);
  money=clone_object("obj/money");
  money->set_money(3000+random(500));
  move_object(money, this_object());
}
}
