
inherit"obj/monster";
reset(arg) {
object money;
::reset(arg);
if(arg) return;
set_name("white ape");
set_alias("ape");
set_short("White ape");
set_long(
"An angry ape with fierce eyes that glow a crystal white.\n");
set_level(20);
set_race("ape");
set_hp(200);
set_wc(30);
set_aggressive(1);
set_ac(17);
money = clone_object("obj/money");
money->set_money(200);
move_object(money, this_object());
}
