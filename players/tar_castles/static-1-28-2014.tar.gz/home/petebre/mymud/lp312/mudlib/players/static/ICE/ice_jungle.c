inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Ice Jungle (n, s, e)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
   "players/static/ICE/lair1", "north",
   "players/static/ICE/apes", "south",
   "players/static/ICE/trail2", "east"
  });
  }
}
