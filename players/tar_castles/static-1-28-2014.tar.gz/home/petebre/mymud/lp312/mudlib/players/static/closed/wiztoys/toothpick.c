inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("toothpick");
  set_class(1000);
  set_alias("toothpick");
  set_short("A small toothpick");
  set_long("A teeny-tiny toothpick that looks harmless.\n");
  set_value(20000);
  set_weight(5);
  
set_hit_func(this_object());
}

weapon_hit(attacker) {
write("The toothpick magically transforms into a bolt of lightning!\n"+
   attacker->query_name()+" is fried to a crisp.\n");
say(this_player()->query_name()+"'s toothpick transforms into a bolt"+
    " of lightning, frying "+attacker->query_name()+" to a crisp.\n"+
    "It then turns back into a toothpick.\n");
return 10000;
   }
drop() {
  destruct(this_object());
  return 1;
}
