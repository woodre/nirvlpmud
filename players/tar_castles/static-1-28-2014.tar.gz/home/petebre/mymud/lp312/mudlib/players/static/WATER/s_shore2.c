inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "S shore 2";
  long_desc = 
  "   The path westward becomes obstructed by overgrown foliage.\n"+
  "You've never seen one before, but this looks like a jungle.\n";
  dest_dir =({
  "players/static/WATER/s_shore1", "east"
  });
  }
}

