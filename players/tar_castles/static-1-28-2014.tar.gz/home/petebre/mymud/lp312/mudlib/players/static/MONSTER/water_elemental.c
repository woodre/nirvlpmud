
inherit "obj/monster";

reset(arg) {
  object weapon, money;
  ::reset(arg);
     if(!arg) {
  set_name("water elemental");
  set_alias("elemental");
  set_level(25);
  set_al(-300);
  set_short("Water Elemental");
  set_long("This is an evil water elemental.  It loves to torment\n"+
  "the sea.\n");
  set_aggressive(1);
  set_wc(40);
  set_ac(22);

  weapon = clone_object("players/static/WEAPON/flame_thrower.c");
  money = clone_object("obj/money");
  money->set_money(1000);

  move_object(weapon, this_object());
  move_object(money, this_object());
}
}
