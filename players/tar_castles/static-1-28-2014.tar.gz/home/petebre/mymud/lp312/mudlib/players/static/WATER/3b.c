inherit	"room/room";

reset(arg) { 
  if(!present("oyster"))
      move_object(clone_object("players/static/MONSTER/oyster"),
      this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Water 3B (e, w)";
  long_desc = 
  "   The water here is calm.  You feel safe here.  There is a buoy\n"+
  "here marked fifteen.\n";
  dest_dir =({
  "players/static/WATER/3c", "east",
  "players/static/WATER/3a", "west"
  });
  }
}
