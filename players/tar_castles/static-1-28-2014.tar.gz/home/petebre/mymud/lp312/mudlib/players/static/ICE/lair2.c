inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "White Dragon Lair 2 (s)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/lair1", "south"
  });
  }
}
