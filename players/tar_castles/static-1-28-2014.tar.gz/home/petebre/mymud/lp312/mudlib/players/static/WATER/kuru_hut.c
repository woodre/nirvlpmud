inherit	"room/room";

reset(arg) { 
  if(!present("kuru"))
  move_object(clone_object("players/static/MONSTER/kuru"),
    this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Kuru Hut (out)";
  long_desc = 
  "   You see a bed.\n";
  dest_dir =({
  "players/static/WATER/vill_road4", "out"
  });
  }
}

