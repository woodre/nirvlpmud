inherit	"room/room";

reset(arg) { 
  if(!present("master")) 
  move_object(clone_object("players/static/MONSTER/master_of_snakes"),
     this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Snake Hall";
  long_desc = 
  "  This is the solemn hall of the Snakes.  Kingdoms will have their\n"+
  "kings.  Princes need their Princesses.  Snakes need their peace.\n"+
  "There is green light to the south.\n";
  dest_dir = ({
  "players/static/room/snake_ent", "west"
  });
  }
}

init() {
::init();

add_action("go_south", "south");

}

go_south() {
object monster;

monster = present("master", environment(this_player()));
if(monster) {
   write("Master of snakes won't let you back there!\n");
   return 1;
}

monster = present("snake", environment(this_player()));
if(monster) {
   write("Snake won't let you back there!\n");
   return 1;
}

call_other(this_player(), "move_player",
       "south#players/static/room/snake_altar");
return 1;
}
