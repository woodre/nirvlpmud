inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "S Shore";
  long_desc = 
   "  You are standing at the southern shore.  Not much is particularly\n"+
   "interesting about this area.  To the east, you can see some signs\n"+
   "of a civilization.\n";
  dest_dir =({
  "players/static/WATER/beach", "north",
  "players/static/WATER/s_shore2", "west",
  "players/static/WATER/vill_road1", "east"
  });
  }
}

