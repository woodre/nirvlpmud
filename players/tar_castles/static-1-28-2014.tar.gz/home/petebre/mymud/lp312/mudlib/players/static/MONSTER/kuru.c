inherit "obj/monster.talk";

reset(arg){
::reset(arg);
if (!arg) {
  set_name("kuru");
  set_short("Kuru");
  set_long("  This man needs help.  He is cursed with the disease of his\n"+
    "name: Kuru.  If he keeps on laughing, he will die.\n");
  set_aggressive(0);
  set_level(15);
  set_hp(250);
  set_wc(20);
  set_ac(12);
  set_al(500);
  set_chat_chance(65);
  load_chat("Kuru laughs uncontrollably, he can't seem to stop!\n");
  }
}
  catch_tell(str) {
    object from;
    string a;
    string b;
    from = this_player();
    if(!from) return;
    if (sscanf(str, "%s cures Kuru.", a) == 1) {
    object ob;
      ob = present ("kuru ointment", from);
      if(!ob)
      return;
    destruct(ob);
     tell_room(environment(this_object()),
    "Kuru stops laughing!\n"+
    "He is cured!\n");

    tell_object(from,
    "Kuru says: Thank you brave adventurer, I am finally cured of\n"+
    "that wretched disease.  Here is a map directing you to buried\n"+
    "treasure.  Thank you once again!\n\n"+
    "Congratulatons!  You have solved the quest!\n");

    remove_chat("Kuru laughs uncontrollably, he can't seem to stop!\n");
    return 1; }
  return 1;
}
