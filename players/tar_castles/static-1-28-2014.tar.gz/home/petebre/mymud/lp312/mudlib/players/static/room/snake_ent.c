inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Snake entrance";
  long_desc = 
   "   This seems to be the entrance to some sort of sacred shrine.\n"+
   "You can hear hissing noises coming from the east.\n";
  dest_dir = ({
  "players/static/room/trail2", "north",
  "players/static/room/snake_hall", "east"
  });
  }
}

