inherit	"room/room";

reset(arg) { 
  if(!present("silent snake")) make_monsters();

  if(!arg) {
  set_light(1);
  short_desc = "Dungeon";
  long_desc = 
  "This is a lair.  The walls are covered with paintings of snakes.\n"+
  "You feel strange magical presence in here.\n";
  dest_dir = ({
  "players/static/ICE/dung02e", "south"
  });
  }
}


init() {
::init();
add_action("go_north", "north");
add_action("go_north", "n");
}

go_north() {

object snake;

snake = present("silent snake");

if(snake) {
   write("The snakes stare into your eyes and convince you not to enter.\n");
   return 1;
}

call_other(this_player(), "move_player",
  "north#players/static/ICE/dung04e.c");
  return 1;
}


make_monsters() {

object snake;
int i;

for (i=0; i<13; i++) {

snake = clone_object("players/static/obj/silent_snake");
move_object(snake, this_object());

}

}
realm() {
return("NT");
}
