
inherit "obj/monster";

reset(arg) {
     ::reset(arg);
     if(!arg) {
       set_name("bee");
       set_level(10);
       set_hp(150);
       set_al(-50);
       set_short("Killer bee");
       set_long("A very large yellow-jacket.  It is very angry that you\n"+
   "dare come near it's hive, for it's honey is quite valuable.\n");
       set_aggressive(1);
       set_wc(14);
       set_ac(8);
}
}
