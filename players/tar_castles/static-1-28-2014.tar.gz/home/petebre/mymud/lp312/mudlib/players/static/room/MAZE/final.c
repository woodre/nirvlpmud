inherit	"room/room";

reset(arg) { 
  if(!present("parchment"))
      move_object(clone_object("players/static/obj/parchment"),
        this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Final Room of the Grand Maze";
  long_desc = 
  "   Congratulations!  You have gone through the Grand Maze.\n"+
  "\n"+
  "   This is a magical vault.  Whomever built this maze went through\n"+
  "great lengths to prevent you from getting into this vault.  But,\n"+
  "you have conquered its power.  Take what this person has hidden.\n"+
  "   As you turn around, you notice that the entrance to this room\n"+
  "has disappeared, and has been replaced by a portal.\n";
  dest_dir = ({"room/church", "portal"});
  }
}
realm() { return "NT"; }
