inherit	"room/room";

reset(arg) { 
  if(!present("fish")) make_monsters();
  if(!arg) {
  set_light(1);
  short_desc = "Water 1A (w, e, n)";
  long_desc = 
   "   The sun shines on the lake.  You can see your reflection of yourself\n"+
   "in the water.  So perfect... a crystal clear image.  This water is indeed\n"+
   "pure.  You can see your toes in this shallow portion of the lake.\n";
  dest_dir =({
  "players/static/WATER/under_bridge", "west",
  "players/static/WATER/2a", "south",
  "players/static/WATER/1b", "east"
  });
  }
}

make_monsters() {
object fish;
int i;

for(i=0; i<5; i++) {
fish = clone_object("players/static/MONSTER/fish");
move_object(fish, this_object());
}

return 1;
}
