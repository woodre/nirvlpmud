inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 08w (s, w, e)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas07w", "west",
  "players/static/ICE/cas03", "east",
  "players/static/ICE/cas09w", "south"
  });
  }
}
