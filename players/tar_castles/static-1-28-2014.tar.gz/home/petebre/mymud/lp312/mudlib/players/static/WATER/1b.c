inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Water 1B (n, e, w)";
  long_desc = 
  "  This water feels creepy.  You are being stung by many underwater\n"+
  "animals.  As you turn to look, you realize that they are the unseen.\n"+
  "You still feel the prickling of their feet.  As you scope at this section\n"+
"of the river, you hear hissing sounds from a cave that is north of\n"+
"you.  You gaze at the water as the invisible creatures flood to\n"+
"the east.\n";
  dest_dir =({
  "players/static/WATER/1a", "west",
  "players/static/WATER/cave1", "north",
  "players/static/WATER/1c", "east"
  });
  }
}
