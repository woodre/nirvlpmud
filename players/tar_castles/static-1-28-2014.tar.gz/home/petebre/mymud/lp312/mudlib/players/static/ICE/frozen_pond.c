inherit	"room/room";

reset(arg) { 
  if(!present("fisherman"))
  move_object(clone_object("players/static/MONSTER/fisherman"), this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Frozen Pond (n, w)";
  long_desc = 
  "   You are standing right on top of a pond.  Good thing it is\n"+
  "frozen over -- you would've been playing Jacque Cousteau.\n";
  dest_dir = ({
  "players/static/ICE/ice_patch2", "north",
  "players/static/ICE/trail1", "west"
  });
  }
}
