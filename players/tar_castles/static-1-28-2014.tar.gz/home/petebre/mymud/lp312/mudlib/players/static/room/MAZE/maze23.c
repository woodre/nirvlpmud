inherit	"room/room";

reset(arg) { 
  if(!present("maze serpent")) { make_serpents(); }
  if(!arg) {
  set_light(1);
  short_desc = "The Maze Serpents";
  long_desc =
"   There are many, many serpents hre!  They seem to be coming out\n"+
"of the walls.  A large, gaping hole is broken into the western wall.\n"+
"You hear growling sounds coming out of that hole.\n";

  dest_dir =({"players/static/room/MAZE/maze22", "east"
  });
  }
}

init() {

  ::init();
    add_action("go_west", "west");
}

go_west() {
   if (present("maze serpent")) {
      write("You try to go west, but are stopped by a serpent.\n");
      say(this_player()->query_name()+" is tries to go west, but is"+
         "stopped by a serpent.\n");
      return 1;
   }
   call_other(this_player(), "move_player",
      "west#players/static/room/MAZE/maze24");
   return 1;
}

make_serpents(){
object serpent;
int i;
for(i=0; i<7; i++) {
  serpent = clone_object("players/static/MONSTER/maze_serpent");
  move_object(serpent, this_object());
  }
return 1;
}
realm() { return "NT"; }
