inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Dungeon (u, w, e)";
  long_desc = 
  "   It is very creepy down here.  You think that you would see bones\n"+
  "and decayed bodies down here.  But you don't... The king must not have\n"+
  "had to use the dungeon that much.\n";
  dest_dir = ({
  "players/static/ICE/stairs", "up",
  "players/static/ICE/dung02w", "west",
  "players/static/ICE/dung02e", "east"
  });
  }
}

realm() {
return("NT");
}
