
inherit "obj/monster.talk";

reset(arg) {
  ::reset(arg);
  if(!arg) {
   set_name("sand crab");
   set_alias("crab");
   set_level(6);
   set_hp(90);
   set_al(100);
   set_short("Sand crab");
   set_long("The crab is a fine animal.  He spends most of his time digging\n"+
   "into the sand and playing with little kids' shovels and pails.\n");
   set_aggressive(0);
   set_wc(10);
   set_ac(5);
}
}
