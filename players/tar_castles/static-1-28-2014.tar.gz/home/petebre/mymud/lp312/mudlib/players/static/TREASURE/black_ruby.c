inherit "obj/treasure";

reset(arg)
{
    if (arg) return;
    set_id("ruby");
    set_short("Black ruby");
   set_long("This ruby emmanates of evil power and greed.  Best to sell\n"+
   "it to some unfortunate shopkeeper.\n");
    set_weight(1);
    set_value(900);
}
