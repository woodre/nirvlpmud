inherit	"room/room";

reset(arg) { 
  if(!present("master")) 
  move_object(clone_object("players/static/MONSTER/master_of_snakes"),
     this_object());
  if(!arg) {
  set_light(1);
  short_desc = "Snake Hall (n, s)";
  long_desc = 
  "  This is the solemn hall of the Snakes.  Kingdoms will have their\n"+
  "kings.  Princes need their Princesses.  Snakes need their peace.\n"+
  "You can see an altar to the south.\n";
  dest_dir = ({
  "players/static/room/snake_entrance", "north"
  });
  }
}

init() {
::init();

add_action("go_south", "south");
add_action("do_kill", "kill");

}


go_south() {
object master, snake;

master = present("master");
if (master) {
   write("The Snake Master won't let you inside there.\n");
   return 1;
  }

snake = present("snake");
if (snake) {
   write("A snake hisses at you as you try to pass.\n");
   return 1;
 }

   call_other(this_player(),
   "move_player", "south#players/static/room/snake_altar");
   return 1;
}


do_kill(str) {

object master;

master = present("master");
if (master) {
   write("Master screams as you attempt to fight him!\n"+
      "He summons some snakes and leaves south.\n");
   say("Master screams!!!\n"+
       "Snakes materialize!!\n"+
       "Master leaves south.\n");
   move_object(master, "players/static/room/snake_altar");
   return 1;
}

return 1;
}
