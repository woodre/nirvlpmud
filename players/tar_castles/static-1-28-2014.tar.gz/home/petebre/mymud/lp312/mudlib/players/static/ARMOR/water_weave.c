inherit "obj/armor";

init(){
  :: init();
}
reset(arg)
{
if(arg) return;

set_name("weave");
set_alias("armor");
set_short("Water weave");
set_long("This armor is magically formed of woven strands of water.\n");
set_value(700);
set_weight(3);
set_ac(3);
set_type("armor");

}
