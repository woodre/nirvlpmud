inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Room 03 (n, w, e)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas02", "north",
  "players/static/ICE/cas08w", "west",
  "players/static/ICE/cas08e", "east"
  });
  }
}
