inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castle Entrance (n, enter)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/trail5", "north",
  "players/static/ICE/cas01", "enter"
  });
  }
}
