inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Castlw Room 10e (n, e, se)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/cas09w", "north",
  "players/static/ICE/cas11", "east",
  "players/static/ICE/cas12w", "southeast"
  });
  }
}
