inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Trail 2";
  long_desc = 
   "   You travel along the somewhat deserted trail for quite a foot.\n"+
   "As you are about to declare to yourself that this path is going\n"+
   "nowhere, you notice a ritual ground towards the south.\n";
  dest_dir = ({
  "players/static/room/trail1", "west",
  "players/static/room/trail3", "east",
  "players/static/room/snake_ent", "south"
  });
  }
}
