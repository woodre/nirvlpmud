inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "White Dragon Lair 1 (n, s)";
  long_desc = 
  "UNDER CONSTRUX.\n";
  dest_dir = ({
  "players/static/ICE/lair2", "north",
  "players/static/ICE/ice_jungle", "south"
  });
  }
}
