inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Road 2";
  long_desc = 
"   You continue down the road.  The fresh air is quite exhilarating.\n"+
"The street lamps at this section are green.\n"+
"You can see a shop to your west.\n";

  dest_dir =({"players/static/room/road1", "north",
    "players/static/room/shop", "west",
    "players/static/room/road3", "south"});
  }
}
