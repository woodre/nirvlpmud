
inherit "obj/monster.talk";
object treasure;

reset(arg) {
     ::reset(arg);
     if(!arg) {
  set_name("fisherman");
  set_level(10);
  set_hp(100);
  set_al(0);
  set_short("An ice fisherman");
  set_long("This guy is ice-fishing.  He hs drilled a hole into\n"+
  "the ice and stuck his line through.\n");
  set_aggressive(0);
  set_wc(14);
  set_ac(8);

set_chat_chance(40);
load_chat("Ice fisherman says: I'm goin to catch me some trout!\n");

treasure = clone_object("obj/treasure");
treasure->set_id("fishing pole");
treasure->set_alias("pole");
treasure->set_short("fishing pole");
treasure->set_weight(1);
treasure->set_value(400);
 move_object(treasure, this_object());
}
}
