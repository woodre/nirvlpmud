inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Road 3";
  long_desc = 
"  You are in the center of the city.  Cobblestone are arranged\n"+
"geometrically to make a square.  It looks like this is the place\n"+
"merchants would do their business.\n";

  dest_dir =({"players/static/room/road2", "north",
    "players/static/room/road4", "south"});
  }
}
