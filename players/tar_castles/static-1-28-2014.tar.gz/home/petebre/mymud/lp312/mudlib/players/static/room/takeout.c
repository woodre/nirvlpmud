
reset(arg) {
    if (arg) return;
    set_light( 1);
}

short() {
  return "The Fast Lane";
}

init() {
    add_action("move");
    add_verb( "east");
    add_action("order");
    add_verb("order");
    add_action("order");
    add_verb("buy");
    add_action("look");
    add_verb("look");
}

move() {
   call_other(this_player(), "move_player",
     "east#players/static/room/road4");
     return 1;
}

long() {
  write("You are in an underground shop.  It seems as though the\n"+
  "owners somehow broke into the heavens and stole the lightning from\n"+
  "the clouds.  They have since bottled at and now are mass-marketing\n"+
  "their thievery.  It is rumored that these drinks are very magical.\n"+
"\n");
  write("You can order:\n\n");
    write("     Bolt of lightning   : 10000 coins\n\n");
    write("The only obvious exit is to " +  "east" + ".\n");
}

order(str)
{
    object drink;
    string name, short_desc, mess;
    int value, cost, strength, heal;

    if (!str) {
       write("Order what ?\n");
       return 1;
    }
  if (str == "bolt" || str == "lightning") {
	name = "bolt";
	short_desc = "Bolt of lightning";
mess = "A bolt of lightning strikes from the sky!";
	heal = 200;
	value = 1000;
	strength = 15;
    } else {
    write("We only sell lightning bolts.n");
       return 1;
    }
    if (call_other(this_player(), "query_money", 0) < value) {
        write("That costs " + value + " gold coins, which you don't have.\n");
	return 1;
    }
  if(this_player()->query_level() < 10) {
    write("This drink would be too strong for you.\n"+
      "Try the cocktail lounge until you are a higher level.\n");
    return 1;
}
    drink = clone_object("obj/drink");
    if (!call_other(this_player(), "add_weight",
	call_other(drink, "query_weight"))) {
	write("You can't carry more.\n");
	destruct(drink);
	return 1;
    }
    if (!call_other(drink, "set_value", name + "#" + short_desc + "#" + mess +
	"#" + heal + "#" + value + "#" + strength)) {
	write("Error in creating drink.\n");
	destruct(drink);
	return 1;
    }
    call_other(drink, "set_pub");
    move_object(drink, this_player());
    call_other(this_player(), "add_money", - value);
    write("You pay " + value + " for a " + name + ".\n");
    say(call_other(this_player(), "query_name", 0) + " orders a " +
	name + ".\n");
    return 1;
}
