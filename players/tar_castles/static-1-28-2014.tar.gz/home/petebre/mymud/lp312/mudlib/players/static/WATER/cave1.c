inherit	"room/room";

reset(arg) { 
  if(!present("water serpent")) { make_serpents(); }
  if(!arg) {
  set_light(0);
  short_desc = "Cave 1 (n, s)";
  long_desc =
  "   You are in a cave.  The walls are covered with grime.  The\n"+
  "air is nothing but musty.  To the north, you can see a passageway.\n";
  dest_dir =({
  "players/static/WATER/1b", "south"
  });
  }
}

init() {

  ::init();
    add_action("north_cave", "enter");
    add_action("enter_cave", "n");
}

enter_cave() {
   if (present("water serpent")) {
      write("You try to go north, but are stopped by a serpent.\n");
      say(this_player()->query_name()+" is tries to go west, but is"+
         "stopped by a serpent.\n");
      return 1;
   }
   call_other(this_player(), "move_player",
      "north#players/static/WATER/cave2");
   return 1;
}

make_serpents(){
object serpent;
int i;
for(i=0; i<8; i++) {
  serpent = clone_object("players/static/MONSTER/water_serpent");
  move_object(serpent, this_object());
  }
return 1;
}
