inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Hallway";
  long_desc = 

  dest_dir = ({
  "players/static/HOUSE/patio", "north",
  "players/static/HOUSE/kitchen", "south",
  "players/static/HOUSE/study", "east",
   "players/static/HOUSE/entrance", "leave"});
  }
}
