inherit	"room/room";

reset(arg) { 
 if(!present("smurf")) {
  move_object(clone_object("players/static/obj/ice_crystal"),
    this_object());
 }
  if(!arg) {
  set_light(1);
  short_desc = "A Blue Hut";
  long_desc = 
   "   You are floating high above the mud.  It is mighty serene\n"+
   "up in these clouds.  You feel at ease, no tension.  Your feet\n"+
   "are delivered a massage by the white puffs withunder them.\n"+
"   To leave this eternal peace, there is a waterslide here; leading\n"+
"down, of course.\n";
  dest_dir =({"players/static/room/cool", "down"});
  }
}
