
reset(arg) {
    if (arg) return;
    set_light( 1);
}

short() {
    return "Waterslide cocktail lounge";
}

init() {
    add_action("move");
    add_verb( "east");
    add_action("order");
    add_verb("order");
    add_action("order");
    add_verb("buy");
}

move() {
    object ob;

    call_other(this_player(), "move_player",  "east" + "#" + "players/static/room/path1");
    return 1;
}

long() {
    write("Welcome to the Waterslide Cocktail Lounge!\n");
    write("You can order drinks here.\n\n");
    write("Cherry Coke              :  10 coins\n");
    write("Cup of tea               :  20 coins\n");
    write("Purple Ice               : 180 coins\n");
    write("Pink flame               : 250 coins\n\n");
    write("Drinks for those who are watching their alcohol usage:\n\n");
    write("Koolaid (no alcohol)     : 600 coins\n");
    write("Kiwi Strawberry Cocktail : 450 coins\n");
    write("\n");
    write("The only obvious exit is east.\n");
}

order(str)
{
    string name, short_desc, mess;
    int value, cost, strength, heal;

    if (!str) {
       write("Order what ?\n");
       return 1;
    }
    if (str == "coke") {
	mess = "Now that was refreshing";
	heal = 5;
        value = 10;
	strength = 1;
    }
    else if (str == "ice" || str == "purple ice") {
mess = "Your tongue turns purple as your throat freezes";
	heal = 10;
        value = 180;
        strength = 7;
    } else if (str == "flame" || str == "pink flame") {
mess = "A teeny-tiny pink demon throws fire down your throat";
	heal = 25;
        value = 250;
        strength = 14;
    } else if (str == "cocktail") {
mess = "You order a kiwi-strawberry cocktail... it's like tasting heaven";
heal = 30;
strength = 9;
value = 450;
    } else if (str == "koolaid") {
mess = "Koolaid Koolers make it kooler!";
heal = 10;
strength = 0;
value = 600;
    } else if (str == "tea" || str == "cup of tea") {
mess = "Wowsers! That sobered you up a little";
	heal = 0;
	value = 20;
	strength = -2;
    } else {
       write("The bartender says: What do you want?\n");
       return 1;
    }
    if (call_other(this_player(), "query_money", 0) < value) {
        write("That costs " + value + " gold coins, which you don't have.\n");
	return 1;
    }
    cost = value;
    if (strength > (call_other(this_player(), "query_level") + 2)) {
	if (strength > (call_other(this_player(), "query_level") + 5)) {
	    /* This drink is *much* too strong for the player */
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and immediately throws it up.\n");
	    write("You order a " + str + ", try to drink it, and throw up.\n");
	} else {
	    say(call_other(this_player(), "query_name", 0) + " orders a " +
		str + ", and spews it all over you!\n");
	    write("You order a " + str + ", try to drink it, and sputter it all over the room!\n");
	}
	call_other(this_player(), "add_money", - cost);
	return 1;
    }
    if (!call_other(this_player(), "drink_alcohol", strength)) {
	write("The bartender says: I think you've had enough.\n");
	say(call_other(this_player(), "query_name", 0) + " asks for a " +
		str + " but the bartender refuses.\n");

	return 1;
    }
    write("You pay " + cost + " coins for a " + str + ".\n");
    say(call_other(this_player(), "query_name", 0) + " orders a " + str + ".\n");
    call_other(this_player(), "add_money", - cost);
    call_other(this_player(), "heal_self", heal);
    write(mess + ".\n");
    return 1;
}
