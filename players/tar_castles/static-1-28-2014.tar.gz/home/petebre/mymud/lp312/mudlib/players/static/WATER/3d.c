inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Water 3D (w)";
  long_desc = 
  "   This is the end of the river.  You can see something to the\n"+
  "north, however the current is too strong to allow you to swim\n"+
  "that way.\n";
  dest_dir =({
  "players/static/WATER/3c", "west"
  });
  }
}
