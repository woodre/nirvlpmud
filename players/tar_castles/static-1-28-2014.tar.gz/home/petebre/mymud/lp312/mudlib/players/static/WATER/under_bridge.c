inherit	"room/room";

reset(arg) { 
  if(!arg) {
  set_light(1);
  short_desc = "Under the bridge";
  long_desc = 
   "   You are wading in the stream.  It seems to go on for ever.\n"+
"The water here is shallow enough to stand in.  It feels wonderful,\n"+
"to be in this liquid mass.  However, you get the strange feeling that\n"+
"you weren't quite invited.  Well, that's alright -- there is a steel\n"+
"rung ladder leading back up to the bridge.\n";
  dest_dir =({
  "players/static/room/bridge", "up",
  "players/static/WATER/1a", "east"
  });
  }
}
