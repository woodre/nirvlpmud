inherit "obj/weapon";

init() {
  ::init();
}

reset(arg) {
  set_name("staff");
  set_class(0);
  set_short("Green Staff");
  set_long("   A powerful staff of destruction.\n");
  set_value(0);
  set_weight(0);
  
set_hit_func(this_object());
}

weapon_hit(attacker) {
int damage, ac_monster;
damage = attacker->query_mhp();
ac_monster = attacker->query_ac();
write("You touch the staff to "+attacker->query_name()+"'s head.\n");
say(this_player()->query_name()+" touches the staff to "+
attacker->query_name()+"'s head.\n");
call_other(attacker, "heal_self", -damage);
return (100000000);
   }
drop() {
  write("A green demon appears and grabs the staff as you drop it.\n");
write("The demon then disappears.\n");
  destruct(this_object());
  return 1;
}
