inherit "obj/monster";
object dart;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("imp");
   set_alias("imp");
   set_short("A Devilish Imp");
   set_long("This is a small elfin creature about 2 feet tall with red skin.\n");
   set_level(10);
   set_hp(150);
   set_al(-500);
   set_aggressive(1);
   set_wc(14);
   set_ac(8);
   set_a_chat_chance(30);
   load_a_chat("The Imp jumps at you!\n");
   set_chance(35);
   
   set_spell_mess1("The Imp fires a dart at his attacker!\n");
   set_spell_mess2("You are hit by an Imp's dart!\n")
   set_spell_dam(20);
   dart=clone_object("/players/asmithrune/weapons/dart");
   if(!present("dart",this_object())) {
      move_object(dart,this_object());
      move_object(dart,this_object());
      move_object(dart,this_object());
   }
