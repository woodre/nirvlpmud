inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("elf");
   set_alias("elf");
   set_short("A Drow Elf");
   set_long("The normally furious elf seems happy and gay, very unusual....\n");
   set_level(9);
   set_al(100);
   set_hp(135);
   set_wc(13);
   set_ac(7);
   set_chat_chance(30);
   load_chat("The Elf looks at you and sniffs, then giggles.\n");
   set_a_chat_chance(30);
   load_a_chat("The Elf runs around you and giggles manically.\n");
   gold=clone_object("obj/money");
   gold->set_money(random(200)+75);
   move_object(gold,this_object());
}
