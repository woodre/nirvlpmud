inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("cart");
   set_alias("cart");
   set_short("A man pulling a cart, selling something.");
   set_long("You see a ragged-looking man pulling a rickety wooden\n"+
      "cart.  The cart contains all sorts of things he has picked"+
      "up along the way.  Perhaps if you ask him he will tell you"+
      "what he has for sale.");
   set_level(20);
   set_al(100);
   set_hp(750);
   set_wc(1);
   set_ac(20);
   set_chat_chance(30);
   load_chat("The man stops his cart and inspects something on the ground.\n");
   set_a_chat_chance(30);
   load_a_chat("The man pulling a cart calls 'Stuffs for sale'!\n");
}
