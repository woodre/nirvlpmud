inherit "room/room";
reset(arg) {
   if(!present("ghost")) {
      move_object(clone_object("/players/asmithrune/monsters/ghost"),this_object());
   }
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You have entered a room that looks like it was inhabited for\n"+
   "quite some time.  A bed made from rocks sits in a corner.  Sitting\n"+
   "on it is a very pale ghost.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave26","south"});
}
