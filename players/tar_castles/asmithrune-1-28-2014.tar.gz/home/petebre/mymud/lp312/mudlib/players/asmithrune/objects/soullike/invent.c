inherit "obj/treasure";
int totvalu;
int length;
int wc,ac;
int weight,valu;
object next,ob;
string name;
int i,namelen,spacelen;

reset(arg) {
   if(arg) return;
   set_short("An Inventory Display");
   set_alias("display");
   set_long("This is an Inventory Display Unit.  When\n"+
      "you type the command 'I', it gives you\n"+
      "a very informative inventory dispaly.\n");
   set_weight(1);
   set_value(5);
}
init() {
   add_action("I","I");
}

I() {
   totvalu=0;
   write("\n");
   write("Your Inventory:\n");
   for(i=0;i<37;i++) {
      write("=-");
   }
   write("\n");
   write("Name");
   for(i=0;i<35;i++) {
      write(" ");
   }
   write("Value\tWeight");
   for(i=0;i<9;i++) {
      write(" ");
   }
   write("Type\n");
   for(i=0;i<75;i++) {
      write("=");
   }
   write("\n");
   ob = first_inventory(this_player());
   while(ob) {
      weight = ob->query_weight();
      next = next_inventory(ob);
      name = ob->short();
      valu = ob->query_value();
      if(ob->short()) {
         namelen = strlen(name);
         spacelen = 40-namelen;
         write(name);
         for(i=0;i<spacelen;i++) {
            write(" ");
         }
         write(valu);
         write("\t");
         if(weight==0 || weight == 1) {
            write("Light");
            length=5;
         }
         if(weight==2 || weight == 3) {
            length=8;
            write("Moderate");
         }
         if(weight == 4 || weight == 5) {
            write("Heavy");
            length=5;
         }
         if(weight==6 || weight == 7) {
            write("Very Heavy");
            length=10;
         }
         if(weight>7) {
            write("Lead Weight");
            length=11;
         }
         for(i=0;i<(15-length);i++) {
            write(" ");
         }
         wc = ob->weapon_class();
         ac = ob->armor_class();
         if(wc>0) {
            write("Weapon\n");
         }
         if(ac>0) {
            write("Armour\n");
         }
         if(!wc>0 && !ac>0) {
            write("Item\n");
         }
         }
      totvalu=totvalu+valu;
      ob = next;
   }
   write("\nTotal Value: "+totvalu+".\n");
   return 1;
}
