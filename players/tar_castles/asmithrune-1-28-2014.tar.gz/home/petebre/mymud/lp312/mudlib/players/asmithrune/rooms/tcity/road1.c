#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon"
#define Op "players/asmithrune/obj"

inherit "room/room";

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A dirt road going through a forest";
      long_desc=
"\n"+
"As you enter the forest, you begin to peer all about,\n"+
"expecting it to be dark.  However, there are numerous\n"+
"openings in the canopy above to allow light to filter down.\n"+
"Small woodland creatures scurry about, doing what they do,\n"+
"while around you the forest is alive with the sounds of birds.\n"+
"There is a large tree to your west with a small door in\n"+
"it's base and a small path goes through the trees to the\n"+
"east.  The road continues north through the forest,\n"+
"or out to a field to the south.  Another path leads\n"+
"to the northwest.\n";
      items = ({
"door","A small, wooden door set into the base of the tree",
"road","This is a road going through the forest.  It runs north and south",
"path","This is a small path going to the northwest or the east",
            });
      dest_dir=({
RP+"tcity/road2","north",
"/players/asmithrune/workroom","south",
RP+"tcity/btree1","west",
RP+"tcity/path3","east",
RP+"tcity/path1","northwest",
            });
   }
}
