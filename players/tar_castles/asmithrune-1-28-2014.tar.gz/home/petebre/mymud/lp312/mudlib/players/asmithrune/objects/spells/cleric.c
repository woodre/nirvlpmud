inherit "obj/treasure";
object tobj;
int i;

reset(arg) {
   if(arg) return;
   set_short("A Bandage");
   set_alias("bandage");
   set_id("bandage");
   set_long("This is a slightly dirty bandage.\n");
   set_weight(0);
   set_value(0);
}

drop() {
   return 1;
}

get() {
   return 0;
}
init() {
   set_heart_beat(1);
}

heart_beat() {
   i++;
   tobj = this_player();
   if(i == 10) {
      tell_object(tobj,"The bandage disapates.");
      destruct(this_object());
      return 1;
   }
   else {
      tell_object(tobj,"The bandage helps you gain some strength.");
      this_player()->add_hit_point(3);
      this_player()->add_spell_point(3);
      return 1;
   }
}
