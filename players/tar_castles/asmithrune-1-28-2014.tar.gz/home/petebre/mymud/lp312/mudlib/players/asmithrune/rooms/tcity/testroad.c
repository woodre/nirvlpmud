#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon"
#define Op "players/asmithrune/obj"

inherit "room/room";

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A dirt road going through a forest";
      long_desc=
      "\n"+
      "As you enter the forest, you begin to peer all about,\n"+
      "expecting it to be dark.  However, there are numerous\n"+
      "openings in the canopy above to allow light to filter down.\n"+
      "Small woodland creatures scurry about, doing what they do,\n"+
      "while around you the forest is alive with the sounds of birds.\n"+
      "There is a large tree to your west with a small door in\n"+
      "it's base and a small path goes through the trees to the\n"+
      "east.  The road continues north through the forest,\n"+
      "or out to a field to the south.  Another path leads\n"+
      "to the northwest.\n";
      items = ({
            "door","A small, wooden door set into the base of the tree",
            "road","This is a road going through the forest.  It runs north and south",
            "path","This is a small path going to the northwest or the east",
});
      dest_dir=({
            RP+"tcity/road2","north",
            "/players/asmithrune/workroom","south",
            RP+"tcity/btree1","west",
            RP+"tcity/path3","east",
            RP+"tcity/path1","northwest",
});
   }
   if(!present("guard",this_object())) {
      object ob,ob2;
      
      ob2 =clone_object("/obj/monster.c");
      call_other(ob2,"set_name","guard");
      call_other(ob2,"set_short","An Elven Guard");
      call_other(ob2,"set_race","elf");
      call_other(ob2,"set_long","This is one of the merchant's many guards.\n"+
         "He is dressed regally, in fine cloth and garb. He caries his\n"+
         "sword with deadly care.\n");
      call_other(ob2,"set_level",8);
      call_other(ob2,"set_al",200);
      call_other(ob2,"set_aggressive",0);
      call_other(ob2,"set_chat_chance",30);
      call_other(ob2,"set_a_chat_chance",30);
      call_other(ob2,"load_chat","The Elven Guard looks at you closely.\n");
      call_other(ob2,"load_a_chat","The Guard steps back and looks at the situation.\n");
      call_other(ob2,"init_command","wield sword");
      ob=clone_object("obj/weapon");
      call_other(ob,"set_name","long sword");
      call_other(ob,"set_alias","sword");
      call_other(ob,"set_short","An Elvish Long Sword");
      call_other(ob,"set_alt_name","elvis long sword");
      call_other(ob,"set_long","This is a finely crafted steel long sword.\n"+
         "It feels exceptionally lite\n");
      call_other(ob,"set_read","'Elvanilara'");
      call_other(ob,"set_class",11);
      call_other(ob,"set_weight",2);
      call_other(ob,"set_value",500);
      call_other(ob,"set_hit_fun",this_object());
      move_object(ob,ob2);
      move_object(ob2,this_object());
      call_other(ob2,"wield","sword");
   }
}
