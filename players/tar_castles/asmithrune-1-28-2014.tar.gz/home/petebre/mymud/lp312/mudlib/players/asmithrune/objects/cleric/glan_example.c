

int silence, banished, magelevel, guild_exp, level, power, begin;
int m, a, s, p;
get() {
   return 1;
}

string mage;


reset(arg) {
   if(!magelevel)
      magelevel = this_player()->query_attrib("int");
   
   if (this_player() && this_player()->query_guild_exp() == 0) {
      this_player()->add_guild_exp(1);
      return 1;
   }
   begin = 0;
   if (arg)
      return;
}

set_magelevel(m) {magelevel = m; }
set_guild_exp(a) {guild_exp = a; }

set_power(p) {power = p;}
query_power() { return power; }
query_magelevel() {return magelevel;}
query_guild_exp() {return guild_exp;}

set_silence(s) {silence = s; }
query_silence() {return silence;}



id(str) {return str == "books"; }

query_auto_load() {
   return "players/glaendor/GUILD/books:"+magelevel+"#"+guild_exp;
}

drop() {
   return 1;
}

short() {return "Death Robes (worn)\nBooks and ancient scrolls";}

long() {
   write("These are the robes of an aspiring mage.  Their voluminous\n");
   write("folds contain the books for Necromancers.\n");
   write("                                    Shade\n");
   write("                                     Spells\n");
   write("                                    Black Sorcery\n");
   write("                                                          \n");
   write("For more info, type 'scrolls' !!!!\n");
   write("or {scrolls <clairvoyance>}.\n");
}

init() {
   string me;
   me = this_player()->query_real_name();
   add_action("mage_announce","ma");
   add_action("logged_on","mages");
   add_action("abandon","abandon");
   add_action("logged_on","nwho");
   add_action("not_mage","mi");
   add_action("not_mage","fi");
   add_action("not_mage","sh");
   add_action("power","power");
   add_action("emote_room","emote");
   add_action("echo_room","echo");
   add_action("shout_cheap","shout");
   add_action("silence","silence");
   add_action("flick_bic","flick");
   add_action("mage_stages","stages");
   add_action("teleport","teleport");
   add_action("fireball","not_mage");
   add_action("shock","not_mage");
   add_action("mm","magic_missile");
   add_action("missile","not_mage");
   add_action("sphere","sphere");
   add_action("firedart","firedart");
   add_action("gas","gas");
   add_action("death","death");
   add_action("vamp","vamp");
   add_action("flame","flame");
   add_action("dart","dart");
   add_action("damn","damn");
   add_action("far","far");
   add_action("gasall","gasall");
   add_action("deathall","deathall");
   add_action("ghoul","ghoul");
   add_action("see","see");
   add_action("wear","wear");
   add_action("midas","midas");
   add_action("convey","convey");
   add_action("scrolls","scrolls");
   add_action("know","know");
   add_action("midas","midas");
   add_action("risk","risk");
   add_action("see","see");
   
   set_heart_beat(1);
}

convey() {
   move_object(clone_object("players/glaendor/GUILD/books"),this_player());
   write("Conveying a new set of books to you...\n");
   destruct(this_object());
   return 1;
}

power() {
   if(power == 0) {
      write("Vitality and Spellpower will be displayed.\n");
      power = 1;
      set_heart_beat(1);
      return 1;
   } else
      power = 0;
   write("Vitality and Spellpower display will cease.\n");
   return 1;
}

heart_beat() {
   
   string me;
   me = this_player()->query_real_name();
   if(power == 1) {
      int hps, sps;
      hps = find_player(me)->query_hp();
      sps = find_player(me)->query_sp();
      tell_object(find_player(me), "HP>> "+hps+"      SP>> "+sps+"\n");
   }
   
}


scrolls(str) {
   
   if(!str) {
      cat("/players/glaendor/GUILD/HELP");
      return 1;
   }
   
   if(str == "spells") {
      cat("/players/glaendor/GUILD/CLAIR");
      return 1;
   }
   
   if(str == "sorcery" || str == "black sorcery" || str == "black") {
      cat("/players/glaendor/GUILD/SORCERY");
      return 1;
   }
   
   if(str == "shade") {
      cat("/players/glaendor/GUILD/SHADE");
      return 1;
   }
}


abandon() {
   write("You abandon the way of the Necromancer.\n");
   this_player()->set_guild_exp(0);
   destruct(this_object());
   return 1;
}


ghoul() {
   
   
   
   if(this_player()->query_attrib("int") < 15) {
      write("You are not intelligent enough.\n");
      return 1;
   }
   
   if(present("ghoul", environment(this_player()))) {
      write("There already is a ghoul here.\n");
      return 1;
   }
   
   move_object(clone_object("players/glaendor/monsters/ghoul"), environment(this_player()));
   this_player()->add_spell_point(-100);
   
   return 1;
}

not_mage() {
   write("Not a Necromancer Spell.\n");
   return 1;
}


wear() {
   write("Necromancer's don't wear armor.\n");
   return 1;
}


mage_stages() {
   string title;
   
   if(this_player()->query_attrib("int") == 1) {title = "the Virus";}
   if(this_player()->query_attrib("int") == 2) {title = "the Fungus";}
   if(this_player()->query_attrib("int") == 3) {title = "the Slime Mold";}
   if(this_player()->query_attrib("int") == 4) {title = "the Furry Mushroom";}
   if(this_player()->query_attrib("int") == 5) {title = "the Scorpion";}
   if(this_player()->query_attrib("int") == 6) {title = "the Adder";}
   if(this_player()->query_attrib("int") == 7) {title = "the Vulture";}
   
   if(this_player()->query_attrib("int") == 8) {title = "the Gravedigger";}
   if(this_player()->query_attrib("int") == 9) {title = "the Graverobber";}
   if(this_player()->query_attrib("int") == 10) {title = "the Initiate of Dark Arts";}
   if(this_player()->query_attrib("int") == 11) {title = "the Student of the Dark Arts";}
   if(this_player()->query_attrib("int") == 12) {title = "the small Necromancer";}
   if(this_player()->query_attrib("int") == 13) {title = "the Necromancer";}
   if(this_player()->query_attrib("int") == 14) {title = "the Great Necromancer";}
   if(this_player()->query_attrib("int") == 15) {title = "the Ghoul Master";}
   if(this_player()->query_attrib("int") == 16) {title = "the Ruler of the Sidhe";}
   
   if(this_player()->query_attrib("int") == 17) {title = "the Ruler of the Night Realms";}
   if(this_player()->query_attrib("int") == 18) {title = "the Commander of Death Dragons";}
if(this_player()->query_attrib("int") == 19) {title = "the Grand Master Necromancer";}
   if(this_player()->query_attrib("int") == 20) {title = "the Lord High Necromancer";}
   if(this_player()->query_attrib("int") < 1) {title = "the tiny Necromancer";}
   if(this_player()->query_attrib("int") > 20) {title = "the Deathlord";}
   
   call_other(this_player(),"set_title", title);
   write("Go forth, "+this_player()->short()+" and kick ass!\n");
   return 1;
}

silence(str) {
   
   if(!str) {
      write("Correct use is:  silence <yes/no>\n");
      return 1;
   }
   if(str == "yes") {
      if(silence == 1) {
         write("You are already enjoying the golden sound of silence.\n");
         return 1;
      }  else
         silence = 1;
      write("You are now enjoying the golden sound of silence.\n");
      return 1;
   }
   if(str == "no") {
      if(silence == 0) {
         write("You weren't silencing.\n");
         return 1;
      } else
         silence = 0;
      write("You are ready to listen to your fellow mages whine some more.\n");
      return 1;
   }
}

know(str) {
   string who;
   object mas, vamp, ass, cle, mag;
   
   if(!str) {
      write("Use as follows:  know <player>.\n");
      return 1;
   }
   if(this_player()->query_attrib("int") < 10) {
      write("The Shade tells you:  You need to be more intelligent to learn use this spell.\n");
      return 1;
   }
   
   who = str;
   
   if(!find_player(who)) {
      write("The Shade says "+capitalize(who)+" isn't in our domain.\n");
      return 1;
   }
   this_player()->add_spell_point(-10);
   
   mas = present("seal",find_player(who));
   vamp = present("fangs",find_player(who));
   ass = present("license",find_player(who));
   cle = present("robes",find_player(who));
   mag = present("books",find_player(who));
   
   if(mas) {
      write("The Shade tells you:  "+capitalize(who)+" is a wimpy mason!\n");
      return 1;
   }
   
   if(vamp) {
      write("The Shade tells you:  "+capitalize(who)+" is a bloodsucking vampire!\n");
      return 1;
   }
   
   if(ass) {
      write("The Shade tells you:  Watch your ass, "+capitalize(who)+" is an assassin!\n");
      return 1;
   }
   
   if(cle) {
      write("The Shade tells you:  "+capitalize(who)+" wants to be a priest!?\n");
      return 1;
   }
   
   if(mag) {
      write("The Shade tells you:  "+capitalize(who)+" is a fellow mage, you twit!\n");
      return 1;
   }
   if(!mas || !vamp || !ass || !cle || !mag) {
      
      write(capitalize(who)+" is probably an independent!\n");
      return 1;
   }
}

risk(str) {
   string what;
   
   if(!str) {
      write("The Shade tells you:  WHOM shall I assess for you?\n");
      return 1;
   }
   
   if(sscanf(str, "%s", what) != 1) {
      write("The Shade tells you:  I judge one thing at a time!\n");
      return 1;
   }
   
   if(call_other(this_player(),"query_spell_point") < 5) {
      write("The Shade tells you:  You don't have enough spell points.\n");
      return 1;
   }
   
   if(this_player()->query_attrib("int") < 16) {
      write("The Shade tells you:  You need to be more intelligent to use this spell.\n");
      return 1;
   }
   
   if(!find_living(what) || !present(find_living(what), environment(this_player()))) {
      write("The Shade tells you:  "+capitalize(what)+" is not here!\n");
      return 1;
   }
   
   if(call_other(find_living(what),"query_wc") > 40) {
      write("The Shade tells you:  "+capitalize(what)+" is armed with the power of a god!\n");
      call_other(this_player(), "add_spell_point", -10);
      return 1;
   }
   
   if(call_other(find_living(what),"query_wc") > 30) {
      write("The Shade tells you:  "+capitalize(what)+" is armed with the power of a lesser god!\n");
      call_other(this_player(),"add_spell_point", -10);
      return 1;
   }
   
   if(call_other(find_living(what),"query_wc") > 24) {
      write("The Shade tells you:  "+capitalize(what)+" is armed with the power of a demi-god!\n");
      call_other(this_player(),"add_spell_point", -10);
      return 1;
   }
   
   if(call_other(find_living(what), "query_wz") > 19) {
      write("The Shade tells you:  "+capitalize(what)+" is armed with a mighty weapon!\n");
      call_other(this_player(),"add_spell_point", -10);
      return 1;
   }
   
   if(call_other(find_living(what), "query_wc") > 15) {
      write("The Shade tells you:  "+capitalize(what)+" is armed with a very good weapon!\n");
      call_other(this_player(),"add_spell_point", -10);
      return 1;
   }
   
   if(call_other(find_living(what), "query_wc") > 11) {
      write("The Shade tells you:  "+capitalize(what)+" is armed with a good weapon!\n");
      call_other(this_player(),"add_spell_point", -10);
      return 1;
   }
   
   if(call_other(find_living(what), "query_wc") > 5) {
      write("The Shade tells you:  "+capitalize(what)+" isn't well-armed.\n");
      call_other(this_player(),"add_spell_point", -10);
      return 1;
   }
   
   else
      write("The Shade tells you:  "+capitalize(what)+" probably isn't armed at all.\n");
   call_other(this_player(),"add_spell_point", -10);
   return 1;
}


midas() {
   
    int amt;
   object body;
   
   body = present("corpse",environment(this_player()));
   if(!body) {
      write("You can't perform the midas touch without the proper material.\n");
      return 1;
   }
   if(this_player()->query_attrib("int") < 12) {
      write("The Shade tells you:  You need to be more intelligent to perform this spell.\n");
      return 1;
   }
   
     amt=random(50) + 50;
   if(this_player()->query_spell_point() < 5) {
      write("You need more spell points to perform the midas touch.\n");
      return 1;
   }
   
write("You perform the midas touch on a corpse, and pocket "+amt+" coins.\n");
   say(capitalize(this_player()->query_real_name())+" turns a corpse into gold pieces and pockets the coins.\n");
   
   destruct(body);
this_player()->add_spell_point(-5);
this_player()->add_money(amt);
   return 1;
}


see(str) {
   string who;
   
   if(!str || sscanf(str, "%s", who) !=1) {
      write("The Shade tells you:  You must ask for sight through another's eyes.\n");
      return 1;
   }
   
   if(this_player()->query_spell_point() < 10) {
      write("You are too low on power.\n");
      write("The Shade tells you:  You need more spell points.\n");
      return 1;
   }
   if(this_player()->query_attrib("int") < 14) {
      write("The Shade tells you:  You need to be more intelligent to use this spell.\n");
      return 1;
   }
   
   if(!find_player(who)) {
      write("The Shade tells you:  "+capitalize(who)+" is outside of this domain.\n");
      return 1;
   }
   
   if(find_player(who)->query_level() > 20) {
      write("The Shade tells you:  You are not permitted to see through wizards.\n");
      return 1;
   }
   
   call_other(this_player(), "add_spell_point", -10);
   write("The Shade tells you:  Look throught the eyes of "+capitalize(who)+":\n");
   write(call_other(find_player(who), "look") + "\n");
   return 1;
}

mage_announce(str) {
   object ob, guild, mage;
   int i;
   string me;
   me = this_player();
   mage = this_object();
   if(!str) {
      write("Announce what?\n");
      return 1;
   }
   ob = users();
   for( i = 0; i < sizeof(ob); i++) {
      guild = present("books", ob[i]);
      if(guild && guild->query_silence() == 0) {
         tell_object(ob[i], me->query_name()+" ##Necro##:  "+str+"\n");
       }
   }
   return 1;
}


logged_on() {
   object list, guild;
   int i, rank;
   string silent;
   
   list = users();
   write("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
   write("Level:\tName:        \t\n");
   write("_____\t______________\t\n");
   for ( i = 0; i < sizeof(list); i++) {
      guild = present("books", list[i]);
      if(guild) {
         string name;
         name = list[i]->query_name();
         name = capitalize(name);
         if(strlen(name) < 8)
            name = name + "\t";
         rank = list[i]->query_attrib("int");
         if(guild->query_silence() == 0) { silent = "";}
         if(guild->query_silence() == 1) {silent = "(silent)";}
         write(rank+"\t"+name+"\t"+silent+"\n");
        }
   }
   write("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
   return 1;
}

echo_to(str)
{
   object ob;
   string who;
   string msg;
   if(!str || sscanf(str,"%s %s",who,msg)!=2) {
      write("Echoto what?\n");
      return 1;
   }
   if(this_player()->query_attrib("int") < 17) {
      write("The Shade tells you:  You need to be more intelligent to use this spell.\n");
      return 1;
   }
   ob = find_living(lower_case(who));
   if(!ob) {
      write("That player isn't on right now.\n");
      return 1;
   }
   if(ob->query_level() > 21) {
      write("The Shade tells you:  You may NOT echoto wizards.\n");
      return 1;
   }
   tell_object(ob,msg + "\n");
   write("You echo to "+ob+": "+msg +"\n");
   this_player()->add_spell_point(-40);
   return 1;
}

echo_room(str)
{
   if(!str) {
      write("Echo what?\n");
      return 1;
   }
   say(str + "\n");
   this_player()->add_spell_point(-5);
   write("You echo: "+str+"\n");
   return 1;
}

emote_room(str) {
   if(!str) {
      write("Emote what?\n");
      return 1;
   }
   say(capitalize(this_player()->query_real_name())+ " "+str+"\n");
   write("You emote: "+str+"\n");
   return 1;
}

shout_cheap(str) {
   if(!str) {
      write("Shout what?\n");
      return 1;
   }
   shout(capitalize(this_player()->query_real_name()) + " shouts: "+str+"\n");
   write("You shout: "+str+"\n");
   return 1;
}

teleport(str) {
   string me, who;
   object old, guild, dest3;
   old = environment(this_player());
   me = this_player()->query_real_name();
   
   if(sscanf(str,"%s",who) != 1) {
      write("You are supposed to:  teleport <player>\n");
      return 1;
   }
   if(call_other(this_player(),"query_spell_point") < 50) {
      write("You need more spell points.\n");
      return 1;
   }
   if(this_player()->query_attrib("int") < 19) {
      write("The Shade tells you:  You need to be more intelligent to use this spell.\n");
      return 1;
   }
   if(find_player(who)->query_level() > 20) {
      write("You are not allowed to teleport to a wizard.\n");
      return 1;
   }
if(environment(find_player(who))->realm()=="NT") {
    write("The Shade tells you:  You cannot teleport to that location.\n");
    return 1;
    }

if(environment(find_player(me))->realm()=="NT") {
    write("The Shade tells you:  You cannot teleport out of that location.\n");
    return 1;
    }

   dest3 = environment(find_player(who));
   tell_room(old, capitalize(me)+" shimmers out of existance.\n");
   tell_room(dest3, capitalize(me)+" unfolds space and stands before you.\n");
call_other(this_player(),"add_spell_point", -50);
   move_object(this_player(), dest3);
   return 1;
}

summon(str) {
   string me, who;
   object old, guild, dest3;
   old = environment(this_player());
   me  = this_player()->query_real_name();
   
   if(sscanf(str,"%s",who) !=1) {
      write("You are supposed to:  summon <player>\n");
      return 1;
   }
   if(this_player()->query_attrib("int") < 20) {
      write("The Shade tells you:  You need to be more intelligent to use this spell.\n");
      return 1;
   }
   if(call_other(this_player(),"query_spell_point") < 60) {
      write("You need more spell points.\n");
      return 1;
   }
   
   if(find_player(who)->query_level() > 20) {
      write("You are not allowed to summon a wizard!\n");
      return 1;
   }
   dest3 = environment(find_player(who));
   tell_room(dest3, capitalize(who)+" is sucked up by a hyperspace wormhole.\n");
   move_object(find_living(who),environment(this_player()));
   tell_room(old, capitalize(who)+" is spit out by "+capitalize(me)+"'s hyperspace wormhole.\n");
   call_other(this_player(),"add_spell_point",-50);
   return 1;
}

damn(str) {
string me, who;
object hell, target;
hell = "players/glaendor/HELL/doom";
me = this_player()->query_real_name();

if(sscanf(str,"%s",who) !=1) {
write("The Shade tells you:  Whom do you seek to damn?\n");
return 1;
       }
if(this_player()->query_attrib("int") < 15) {
 write("The Shade tells you:  You need to be more intelligent to use this spell.\n");
 return 1;
        }

if(!this_player()->query_attack()) {
write("The Shade tells you:  You aren't under attack!\n");
return 1;
}

if(!present(who),environment(this_player())) {
write("The Shade tells you:  "+who+" isn't there.\n");
return 1;

    }

    target = present(who, environment(this_player()));
    if(!target){
    write("The Shade tells you:  "+who+" isn't there.\n");
    return 1;
    }
tell_room(environment(this_player()), capitalize(who)+" is sent straight to hell!\n");
 
move_object(target,hell);
return 1;
     }









death(str) {
   object victim;
   int hurt;
   
   if(!str) { write("Glaurung tells you:  Whom do I death?\n");
      return 1;
   }
   
   if(this_player()->query_attrib("int") < 18) {
      write("The Shade tells you:  You need more spell points for this spell.\n");
      return 1;
   }
   
   if(this_player()->query_spell_point() < 100) {
      write("The Shade tells you:  You need more spell points for this spell.\n");
      return 1;
   }
   victim = present(str, environment(this_player()));
   if(!victim) {
      write("Glaurung tells you:  I do not see "+str+" in your vicinity.\n");
      return 1;
   }
   
   if(victim->query_npc() == 0) {
      write("Glaurung tells you:  I cannot attack "+capitalize(str)+" .\n");
      return 1;
   }
hurt = 100;
   this_player()->spell_object(victim, "death", hurt, 100);
   shout("Glaurung the Death Dragon flies overhead.\n");
   tell_object(victim, this_player()->query_name()+" has summoned Glauurung the Death Dragon against you!\n");
   tell_room(environment(this_player()),
      this_player()->query_name()+" ordered Glaurung the Death Dragon to breathe death gas at "+str+"!\n");
   return 1;
}
vamp(str) {
   object victim;
   int hurt;
   if (!str) {write("There is no "+str+" present.\n");
      return 1;
   }
   if(this_player()->query_attrib("int") < 9) {
      write("The Shade tells you:  You need to be more intelligent to drain.\n");
      return 1;
   }
   
   if(this_player()->query_spell_point() < 40) {
      write("The Shade tells you:  You need to have more spell points.\n");
      return 1;
   }
   
   victim = present(str, environment(this_player()));
   if(!victim) { write("There is no "+str+" present.\n");
      return 1;
   }
   if(victim->query_npc() == 0) {
      write("You are not allowed to drain "+capitalize(str)+".\n");
      return 1;
   }
   hurt = 15 + random(10);
   this_player()->spell_object(victim, "vamp", hurt, 40);
   tell_object(victim, this_player()->query_name()+" drains you of your life force!\n");
   say(this_player()->query_name()+" drains life force from "+capitalize(str)+".\n");
   this_player()->add_hit_point(hurt);
   return 1;
}
dart(str) {
   object victim;
   int hurt;
   if(!str) {write("Dart who??\n");
      return 1;
   }
   if(this_player()->query_spell_point()<10) {
      write("The Shade tells you:  You need more spell points.\n");
      return 1;
   }
   
   
   victim = present(str, environment(this_player()));
   if(!victim) {write("There is no "+str+" here.\n");
      return 1;
   }
   
   if(victim->query_npc() == 0) {
      write("You are not allowed to dart "+capitalize(str)+".\n");
      return 1;
   }
   
   victim->hit_player(20);
this_player()->add_spell_point(-20);
   
   tell_object(victim, this_player()->query_name()+" casts a death dart at you!\n");
   say(this_player()->query_name()+" casts a death dart at "+capitalize(str)+".\n");
   write("You cast a death dart at "+capitalize(str)+".\n");
   if(victim && !victim->query_attack()){
      victim->attack_object(this_player());
   }
   return 1;
   
}


flame(){
   object next;
   object victim;
   
   if(this_player()->query_attrib("int") < 11) { 
      write("The Shade tells you:  You need to be more intelligent to use this spell.\n");
      return 1;
   }
   
   if(this_player()->query_spell_point() < 20) {
      write("The Shade tells you:  You need more spell points.\n");
      return 1;
   }
   victim = first_inventory(environment(this_player()));
   while(victim) {
      next = next_inventory(victim);
      if(living(victim) && victim->query_npc() == 1 && victim->query_name() != "ghoul") {
         victim->hit_player(20);
       this_player()->add_spell_point(-20);
         write("You blast a soul with black fire!\n");
         say(capitalize(this_player()->query_name())+" blasts someone's soul with black fire!\n");
         if(victim && !victim->query_attack()) {
            victim->attack_object(this_player());
         }
         }
      victim = next;
   }
   return 1;
}


