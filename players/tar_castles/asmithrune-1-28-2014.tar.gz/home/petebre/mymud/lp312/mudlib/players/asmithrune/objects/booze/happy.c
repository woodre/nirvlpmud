int full;

id(str) {
   if (str == "brew" && full)
      return 1;
   return str == "bottle";
}

short() {
   if (full)
      return "bottle of brew";
   return "empty bottle of brew";
}

/* The shop only buys empty bottles ! */

query_value()
{
   if (!full) return 10;
   return 0;
}

long() {
   write(short() + ".\n");
}

reset(arg) {
   if (arg)
      return;
   full = 1;
}

drink(str)
{
   if (str && str != "brew" && str != "from bottle")
      return 0;
   if (!full)
      return 0;
   else {
      call_other(this_player(), "drink_alcohol",6);
      call_other(this_player(),"heal_self",5);
      write("You drink the Happy Brew and feel HAPPY, HAPPY, HAPPY!\n");
      say(this_player()->query_real_name()+" drinks the Happy Brew and looks HAPPY, HAPPY, HAPPY!\n");
      full = 0;
      return 1;
   }
   return 1;
}

init() {
   add_action("drink"); add_verb("drink");
}

get() {
   return 1;
}

query_weight() {
   return 1;
}
