object button;
object phone;
object plane;
object eye;
reset(arg) {
   if(!arg) {
      set_light(1);
   }
}
init() {
   add_action("east","east");
   add_action("buy","buy");
   add_action("list","list");
   add_action("info","info");
}
east() {
   write("The shopkeeper bids you farewell and a good day.\n");
   this_player()->move_player("east#players/asmithrune/rooms/castle/keepgrd/keep6");
   return 1;
}
list() {
   write("The EndCastle Speciality Shop has these items for sale:\n");
   write("\n"+
      "1|| Paper Airplane          20 Gold Pieces\n"+
      "2|| Handy-Dandy Phone       100 Gold Pieces\n"+
      "3|| Eye of Bazubel          1000 Gold Pieces\n"+
      "4|| Customizeable Button    25 Gold Pieces\n"+
      "\n"+
      "For information regarding the items, type info <number>.\n");
   return 1;
}
info(string str) {
   if(str == "1") {
      write("Have you a message to send fast?  Something\n"+
         "that has just got to get to that person NOW!,\n"+
         "but you've run out of spell points?  Well, here is\n"+
         "the answer to your prayer.  This airplane allows\n"+
         "you to write a message and send it to anyone on the MUD.\n"+
         "A must for the busy player!\n");
      return 1;
   }
   if(str == "2") {
      write("Tired of writing a person's LOOONNNGG name when\n"+
         "doing tells.  Tired of writing tell at all?  This\n"+
         "item is for you.  This allows you to simply type contell\n"+
         "<players name>, and then on type re <message>.  A must\n"+
         "for the gabby player.\n");
      return 1;
   }
   if(str == "3") {
      write("This is a magical device captured from the demon\n"+
         "of Bazubel.  It allows you to transport to a magical shop\n"+
         "from anywhere on the MUD, then back to the spot you left.\n"+
         "The prices in the shop are very competive too.\n");
      return 1;
   }
   if(str == "4") {
      write("This is a button that allows you to write the\n"+
         "message that it reads.  A must for any player thinking\n"+
         "of his or her looks.\n");
      return 1;
   }
   else {
      write("Help on which item?\n");
      return 1;
   }
}
buy(string str) {
   if(str == "1" || str == "airplane") {
      if(this_player()->query_money()>19) {
         write("The shop keeper takes your money and\n"+
            "hands you a paper airplane.\n");
         plane=clone_object("/players/asmithrune/objects/paperii");
         move_object(plane,this_player());
         this_player()->add_money(-20);
         return 1;
      }
      else {
         write("You don't have enough money, the shopkeeper says.\n");
         return 1;
      }
   }
   if(str == "2" || str == "phone") {
      if(this_player()->query_money()>99) {
         write("The shop keeper, after he takes your money, hands\n"+
            "you a Handy-Dandy phone.\n");
         phone=clone_object("/players/asmithrune/objects/phone");
         move_object(phone,this_player());
         this_player()->add_money(-100);
         return 1;
      }
      else {
         write("You don't have enough money.\n");
         return 1;
      }
   }
   if(str == "3" || str == "eye") {
      if(this_player()->query_money()>999) {
         write("The, smiling, hands you an Eye and takes yor money.\n");
         eye=clone_object("/players/asmithrune/objects/eye");
         move_object(eye,this_player());
         this_player()->add_money(-1000);
         return 1;
      }
      else {
         write("You don't have enough money, sire.\n");
         return 1;
      }
   }
   if(str == "4" || str == "button") {
      if(this_player()->query_money()>24) {
         write("The shop keeper unpins a button from his lapel\n"+
            "and hands it you, taking your money.\n");
         button=clone_object("/players/asmithrune/objects/button");
         move_object(button,this_player());
         this_player()->add_money(-25);
         return 1;
      }
      else {
         write("You don't have enough money.\n");
         return 1;
      }
   }
   else {
      write("What do you wish to buy?\n");
      return 1;
   }
}
long() {
   write("You have entered a small shop.  The sign\n"+
      "above the door reads 'EndCastle Speciality Shop.'\n"+
      "As you enter the shop, a shop keeper runs up to you and\n"+
      "says 'Welcome, welcome.  Come in and look around.\n"+
      "To get a list of sale items, type 'list'.'\n");
}
short() {
   return "EndCastle Speciality Shop";
}
