inherit "obj/treasure";
reset(arg) {
   if(arg) return;
   set_alias("airplane");
   set_short("A Paper Airplane");
   set_long("This is a paper airplane.  There is something written\n"+
      "on it.  Why don't you read it. Then type fly <playername> to fly it to someone.\n"+
      "Then type 'crumple plane' to get rid of the airplane(Let's keep our MUD clean!)\n");
   set_weight(0);
   set_value(0);
}
init() {
   add_action("read","read");
   add_action("fly","fly");
   add_action("crumple","crumple");
}

read(string str) {
   if(str == "airplane") {
      write("Asmithrune's castle is now open(or at least part of it)!!!!\n"+
         "Just head west from the church, until you come to a\n"+
         "'A small path leading into the bushes to the north', then go north!\n"+
         "Filled with many new monsters, a new weapon or two and mucho gold!\n"+
         "Oh yeah, two things.  One, check out the hut on the trail, many neat\n"+
         "things for sale there.  And two, bring a friend, you'll need him/her!"+
"\n"+
         "This just in: New items added to the shop, and a newbie land is open!\n"+
         "\n"+
         "Asmithrune, Master of Dragons.\n");
      return 1;
   }
   else {
      write("Read what?\n");
      return 1;
   }
}
fly(object plob) {
   if(find_living(plob)) {
      write("You send the airplane on it's way.\n");
      tell_object(find_living(plob),"You see a paper airplane fly into the room.  You pick it up.\n");
      tell_object(find_living(plob),"When you pick it up, a note falls out that says,\n"+
         "This is from  "+(capitalize(this_player()->query_real_name()))+".\n");
      move_object(this_object(),find_living(plob));
      return 1;
   }
   else {
      write("That person isn't on the MUD right now.\n");
      return 1;
   }
}
crumple(object obj) {
   if(obj == "airplane"||obj == "plane") {
      write("You crumple the airplane into a little ball, and\n"+
         "throw it into a nearby trash can.\n");
      say(capitalize(this_player()->query_real_name())+" crumples and throws the airplane away.\n");
      destruct(this_object());
      return 1;
   }
   else {
      write("Crumple what?\n");
      return 1;
   }
}
