reset(arg) {
   if(arg) return;
   set_light(1);
}
init() {
   add_action("east","east");
   add_action("west","west");
   add_action("north","north");
   add_action("south","south");
}
east() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/newbie/new2");
   return 1;
}

west() {
   call_other(this_player(),"move_player",
      "west#players/asmithrune/rooms/newbie/new8");
   return 1;
}

north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/newbie/new6");
   return 1;
}

south() {
   call_other(this_player(),"move_player",
      "south#players/asmithrune/rooms/newbie/new7");
   return 1;
}

long() {
   write("As you continue down the path, you\n"+
      "just can't help feeling happier and happier.\n"+
      "Maybe it has to do with the smoke coming from\n"+
      "the west.\n"+
      "     There are four obvious exits: north, south, east, and west.\n");
}
short() {
   return "Newbie Zone";
}
