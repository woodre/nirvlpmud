inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="Pool room I";
   long_desc="You have entered a pool hall.  Wait, a pool hall? Yes,\n"+
   "a pool hall.  Why is it out in the forest?  Cause it is, that's why.\n"+
   "There is the sound of pool to the northwest, and the tinkiling\n"+
   "of money to the southwest. To the northwest there is the sound\n"+
   "or moaning intermixed with moaning?  And to the southeast there\n"+
   "is the sound of straining video games.\n";
   dest_dir=({"/players/asmithrune/rooms/poolhall/out","down",
         "/players/asmithrune/rooms/poolhall/pool1","northwest",
         "/players/asmithrune/rooms/poolhall/videoslut","northeast",
         "/players/asmithrune/rooms/poolhall/change","southwest",
         "/players/asmithrune/rooms/poolhall/oldcorner","southeast"});
}
