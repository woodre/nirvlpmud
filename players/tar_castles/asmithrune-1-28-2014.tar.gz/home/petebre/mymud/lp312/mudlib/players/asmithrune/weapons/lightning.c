inherit "obj/weapon";
int att;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("lightning");
   set_short("A Lightning Sword");
   set_alias("sword");
   set_long("This is a long, thin, blue metal sword.  There is a lightning bolt\n"+
      "inscribed onto the blade.\n");
   set_hit_func(this_object());
   set_class(18);
   set_weight(5);
   set_value(25000);
   call_other(this_object(),"set_save_flag",0);
}
weapon_hit(attacker) {
   att=this_player()->query_attrib("int");
   if(random(125) < att) {
      say("The Lightning Sword glows brightly and shoots a lightning bolt!\n");
      write("The Lightning Sword glows in your hand and shoots a lightning bolt!\n");
      return 5;
   }
}
