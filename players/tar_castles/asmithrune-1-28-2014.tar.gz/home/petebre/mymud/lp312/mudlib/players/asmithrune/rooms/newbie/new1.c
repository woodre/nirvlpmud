reset(arg) {
   if(arg) return;
   set_light(1);
}
init() {
   add_action("east","east");
   add_action("west","west");
}
east() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/trail2");
   return 1;
}

west() {
   if(this_player()->query_level()<6) {
      call_other(this_player(),"move_player",
         "west#players/asmithrune/rooms/newbie/new2");
      return 1;
   }
   else {
      write("You are much too powerful to enter the newbie area.\n"+
         "Please try another area.\n");
      return 1;
   }
}

long() {
   write("You have entered a pleasing part of the forest.\n"+
      "The birds are chirping and the flowers are smiling.  The\n"+
      "flowers are smiling?  Well, if you have to know, this is\n"+
      "a area for the lower level players, and if you are above\n"+
      "level 5, please try another section.\n"+
      "      There are two obvious exits: east and west.\n");
}
short() {
   return "Newbie Zone";
}
