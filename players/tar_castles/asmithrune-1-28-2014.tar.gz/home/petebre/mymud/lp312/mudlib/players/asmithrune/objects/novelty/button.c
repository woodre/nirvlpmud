inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A Button");
   set_alias("button");
   set_long("This is a special button. Type button <message> to\n"+
      "change what it reads.\n");
   set_weight(0);
   set_value(0);
}
init() {
   add_action("button","button");
}

button(string str) {
   set_short("A button that says: "+(str));
   write("The button now says: "+(str)+".\n");
   return 1;
}
