inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="Here the trail turns to the east.  To the\n"+
   "northeast, you can see a mighty keep, rising above\n"+
   "the trees.\n";
   dest_dir=({"players/asmithrune/rooms/trail17","east",
         "players/asmithrune/rooms/trail15","south"});
}
