inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="Finally you can see the castle clearly.  You\n"+
   "have to go northeast to enter the courtyard of the castle,\n"+
   "or the trail continues east.\n";
   dest_dir=({"players/asmithrune/rooms/trail18","east",
         "players/asmithrune/rooms/castle/cas1","northeast",
         "players/asmithrune/rooms/trail16","west"});
}
