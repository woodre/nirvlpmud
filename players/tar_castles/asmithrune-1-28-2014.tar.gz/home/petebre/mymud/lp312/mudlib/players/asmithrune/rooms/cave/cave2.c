inherit "room/room";
reset(arg) {
   if(!present("aurumvorax")) {
      move_object(clone_object("/players/asmithrune/monsters/aurum"),this_object());
   }
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="As you continue down the tunnel, you notice a beautiful\n"+
   "glow.  The glow turns out to be a magnificent, gold coated, monster sitting\n"+
   "on the cave floor.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave3","south",
         "/players/asmithrune/rooms/cave/cave23","east",
         "/players/asmithrune/rooms/cave/cave1","north"});
}
