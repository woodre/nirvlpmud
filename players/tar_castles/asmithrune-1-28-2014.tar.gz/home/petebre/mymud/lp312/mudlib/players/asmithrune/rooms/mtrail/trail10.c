inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Path";
   long_desc="Here the path turns west and you can see a keep to\n"+
   "the northwest.  The trees are begining to look more dark and\n"+
   "ominious.  The path continues to the west.\n";
   dest_dir=({"/players/asmithrune/rooms/trail18","west",
         "/players/asmithrune/rooms/trail9","south"});
}
