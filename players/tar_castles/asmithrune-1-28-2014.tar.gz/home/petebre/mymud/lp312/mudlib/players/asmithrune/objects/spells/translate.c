translate(int num) {
   int total;
   if(!num) {
      write("How much do you wish to translate?\n");
      return 1;
   }
   if(num>this_player()->query_hit_point()) {
      write("You do not have that many hit points.\n");
      return 1;
   }
   write("You join hands and mutter a slight prayer.  When you\n"+
      "are finished, your body feels drained, but your\n"+
      "mind is refreshed.\n");
   say(this_player()->query_name()+" joins hands and mutters a prayer.\n"+
      "A soft humming fills the room.\n");
   total = num*(8/10);
   this_player()->add_spell_point(-num);
   this_player()->add_hit_point(total);
   return 1;
}
