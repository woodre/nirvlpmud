inherit "obj/monster";
object gold;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("galeb");
   set_alias("galeb");
   set_short("A Galeb Durh");
   set_long("This is a large creature made of rock.  He is mean\n"+
      "and nasty so watch out.\n");
   set_level(25);
   set_al(-1000);
   set_hp(750);
   set_wc(36);
   set_ac(22);
   set_a_chat_chance(30);
   load_a_chat("The Galeb Durh rushes into you and throws you up against the wall!!!!\n");
   gold=clone_object("obj/money");
   gold->set_money(random(1500)+1000);
   move_object(gold,this_object());
}
