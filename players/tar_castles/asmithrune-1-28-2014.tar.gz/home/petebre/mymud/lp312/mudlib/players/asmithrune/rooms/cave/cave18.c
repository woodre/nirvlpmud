inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You head up the tunnel and begin to hear strange noises\n"+
   "in the runnels ahead.  They sound like laughter and snickering.\n"+
   "The tunnel turns east here.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave1","south",
         "/players/asmithrune/rooms/cave/cave19","east"});
}
