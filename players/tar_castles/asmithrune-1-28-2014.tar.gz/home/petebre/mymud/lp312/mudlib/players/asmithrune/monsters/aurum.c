inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("aurumvorax");
   set_alias("aurumvorax");
   set_short("A Aurumvorax");
   set_long("This is a large badger like creature with a shinny gold\n"+
      "coat.\n");
   set_level(13);
   set_hp(195);
   set_al(200);
   set_wc(17);
   set_ac(10);
   set_aggressive(1);
   set_chat_chance(35);
   load_chat("The Aurumvorax paces around the room.\n");
   load_chat("The Aurumvorax snarls at you.\n");
   set_a_chat_chance(40);
   load_a_chat("The Aurumvorax leaps at you!\n");
   load_a_chat("The Aurumvorax grabs you with its claws!\n");
   gold=clone_object("obj/money");
   gold->set_money(random(500)+300);
   move_object(gold,this_object());
}
