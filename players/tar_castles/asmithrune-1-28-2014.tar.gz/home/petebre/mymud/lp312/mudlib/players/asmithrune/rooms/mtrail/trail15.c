inherit "room/room";
int i;
reset(arg) {
   if(!present("ettercap")) {
      object etter;
      while(i<3) {
         i += 1;
         etter=(clone_object("players/asmithrune/monsters/ettercap"));
         move_object(etter,this_object());
      }
   }
   if(arg) return;
   set_light(1);
   short_desc=="A Trail";
   long_desc="You have entered a small clearing, and you\n"+
   "finally know where the horrible smell is coming from.\n"+
   "Three Ettercaps have set up camp here and they are lookin\n"+
   "at you with hungry eyes.  The trail continues north.\n";
   dest_dir=({"players/asmithrune/rooms/trail16","north",
         "players/asmithrune/rooms/trail14","south"});
}
