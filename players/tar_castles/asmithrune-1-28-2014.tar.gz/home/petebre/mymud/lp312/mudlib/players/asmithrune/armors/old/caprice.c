inherit "obj/armor";

reset(arg) {
   ::reset(arg);
   set_name("caprice");
   set_alias("armor");
   set_short("A Sandworm Caprice");
   call_other(this_object(),"set_save_flag",0);
   set_long("This is the shell and skin of the ferocious Sandworm.\n");
   set_ac(5);
   set_weight(5);
   set_value(100000);
}
