inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Path";
   long_desc="You start to walk along the rock path, and you notice\n"+
   "how well kept and free of debries the path is.  You also notice that\n"+
   "that all the animal noises in the forest have stopped.  The path\n"+
   "continues north.\n";
   dest_dir=({"/players/asmithrune/rooms/trail7","north",
         "/players/asmithrune/rooms/trail4","south"});
}
