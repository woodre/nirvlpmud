int ogre;
object ogr;
reset(arg) {
   string me;
   if(!arg) {
      set_light(1);
   }
   ogre = 0;
}
init() {
   add_action("south","south");
   add_action("challenge","challenge");
}
south() {
   call_other(this_player(),"move_player",
      "south#players/asmithrune/rooms/castle/keepgrd/keep9");
   return 1;
}
challenge(string str) {
   if(str == "ogre") {
      if(ogre == 0) {
         ogre = 1;
         write("As you call out your challenge to the Ogre, he  bellows\n"+
            "his acceptance.\n");
         ogr = (clone_object("/players/asmithrune/monsters/mongrel.c"));
         move_object(ogr,environment(this_player()));
         return 1;
      }
      else {
         not_here();
         return 1;
      }
   }
}
not_here() {
   write("The Arena Master yells 'He isn't working today!\n");
   return 1;
}
long() {
   write("As you enter the doorway, your attention is\n"+
      "first drawn to the large stained glass skylight above you.\n"+
      "It's patterns reflect the magical battles fought and won\n"+
      "over the generations by the masters of this castle.\nThere are many fine wall hangings and\npaintings along the walls.  The hallway\n"+
      "continues on to the north.\n"+
      "      There are two obvious exits: north and south\n");
}
short()
{
   return "Main Keep Entry";
}
