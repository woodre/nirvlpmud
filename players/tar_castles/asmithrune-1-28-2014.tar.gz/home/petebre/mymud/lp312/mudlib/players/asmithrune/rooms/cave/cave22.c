inherit "room/room";
int i;
reset(arg) {
   if(!present("mongrel")) {
      while(i<6) {
         i += 1;
         move_object(clone_object("/players/asmithrune/monsters/mongrel"),this_object());
      }
   }
   if(!present("king")) {
      move_object(clone_object("players/asmithrune/monsters/mongrelking"),this_object());
   }
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You have finally found the lair of the king of these\n"+
   "odorious beasties.  The king sits atop a throne of\n"+
   "offfal and garbage glaring at you.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave21","west"});
}
