reset(arg) {
   string me;
   if(!arg) {
      set_light(1);
   }
}
init() {
   add_action("north","north");
   add_action("south","south");
}
north() {
   call_other(this_player(),"move_player",
      "noth#players/asmithrune/rooms/trail2");
   return 1;
}
south() {
   call_other(this_player(),"move_player",
      "south#room/forest1");
   return 1;
}
long()
{
   write("After a long walk, the trail finally emerges\n"+
      "into a respectable path.  The trail continues north.\n"+
      "A small chapel sits to the east.\n"+
      "	   There are three obvious exits: north,south and east.\n");
}
short()
{
   return "A Trail";
}
