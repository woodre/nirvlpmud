int full;

id(str) {
   if (str == "tea" && full)
      return 1;
   return str == "bottle";
}

short() {
   if (full)
      return "bottle of english tea";
   return "empty bottle of english tea";
}

/* The shop only buys empty bottles ! */

query_value()
{
   if (!full) return 10;
   return 0;
}

long() {
   write(short() + ".\n");
}

reset(arg) {
   if (arg)
      return;
   full = 1;
}

drink(str)
{
   if (str && str != "tea" && str != "from bottle")
      return 0;
   if (!full)
      return 0;
   else {
      this_player()->drink_alcohol(-6);
      write("You sip the tea, and feel more awake.\n");
      say(this_player()->query_real_name()+" sips a bottle of english tea.\n");
      full =0;
      return 1;
   }
}

init() {
   add_action("drink"); add_verb("drink");
}

get() {
   return 1;
}

query_weight() {
   return 1;
}
