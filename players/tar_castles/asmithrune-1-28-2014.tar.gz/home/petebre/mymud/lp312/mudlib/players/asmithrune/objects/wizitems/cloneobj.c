inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A Clone Object");
   set_alias("cloneobj");
   set_long("A info object, type info <object> for info.\n");
   set_weight(0);
   set_value(0);
}
init() {
   add_action("cloneit","cloneit");
}

cloneit(string what)
{
   object wsoul;
   int fsize;
   
   fsize=0;
   
   fsize=file_size(what+".c");
   if(fsize==-1) {
      write("Error..can't find file\n");
      return(1);
   }
   if(fsize==-2) {
      write("Error..can't clone a directory\n");
      return(1);
   }
   if(wsoul=present("wiz_soul")) {
      wsoul->clone(what);
      write(what+" has been cloned.\n");
      return(1);
   }
   return(1);
}
