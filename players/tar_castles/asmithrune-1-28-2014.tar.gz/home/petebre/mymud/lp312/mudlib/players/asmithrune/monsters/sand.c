inherit "obj/monster";
object caprice;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   if(arg) return;
   set_name("worm");
   set_alias("sandworm");
   set_short("A Sandworm");
   set_long("This is a huge worm, about 20 feet long, and with a 6 foot round mouth with millions of teeth.\n");
   set_level(35);
   set_hp(2000);
   set_al(0);
   set_wc(60);
   set_ac(32);
   set_chat_chance(30);
   load_chat("The Sandworm dives beneath the sand.\n");
   load_chat("The Sandworm surfaces.\n");
   set_a_chat_chance(30);
   load_a_chat("The Sandworm dives into the sand benath you feet, and jumps up!\n");
   set_chance(30);
   set_spell_mess1("You see the Sandworm swallow it's attacker!\n");
   set_spell_mess2("The Sandworm swallows you!\n");
   set_spell_dam(30);
   if(!present("caprice",this_object())) {
      caprice=clone_object("/players/asmithrune/armors/caprice");
      move_object(caprice,this_object());
   }
}
