inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="The the trail turns once again, this time heading north.\n"+
   "The trees, although lush adnd green, are not as tall as you might expect.\n";
   dest_dir=({"/players/asmithrune/rooms/trail13","north",
         "/players/asmithrune/rooms/trail11","east"});
}
