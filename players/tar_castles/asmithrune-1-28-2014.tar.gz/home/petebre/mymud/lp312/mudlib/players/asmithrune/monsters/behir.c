inherit "obj/monster";
object key;
reset(arg) {
   ::reset(arg);
   set_name("behir");
   set_alias("behir");
   set_short("A Fierce Behir");
   set_long("This is a fierce monster, maybe fierce than the great\n"+
      "dragon, Bahumat.  He is a long, snake like monster, with many legs\n"+
      "and a large head with many teeth.  He is the protector of the\n"+
      "legendary Lightning Sword.\n");
   set_level(30);
   set_hp(1500);
   set_al(-3000);
   set_wc(50);
   set_ac(27);
   set_chat_chance(30);
   load_chat("The Behir raps itself around a stone column.\n");
   set_a_chat_chance(30);
   load_a_chat("The Behir laughs at your puny attempt at conquest!\n");
   set_chance(40);
   set_spell_mess1("The Behir arches its back and fires a lightnign bolt at its attackers!!\n");
   set_spell_mess2("The Behir fires a lightning bolt at you!!!!\n");
   set_spell_dam(60);
   key=clone_object("/players/asmithrune/objects/keys/sokey");
   move_object(key,this_object());
}
