inherit "obj/treasure";
object home;

reset(arg) {
   if(arg) return;
   set_short("An Eye of Bazuble");
   set_id("mageye");
   set_alias("eye");
   set_long("This is a magic eye.  Just type 'eye look' and\n"+
      "you will go to a shop that is only useable by\n"+
      "holders of an eye.  Then, just type 'eye back' and\n"+
      "you are back where you were before!\n"+
      "Because of the magic involved, each movement will cost 5 sp.\n");
   set_weight(1);
   set_value(1000);
}

init() {
   add_action("eye_look","eye");
}

eye_look(str) {
   if(str == "look") {
      home=environment(this_player());
      say("You see a gigantic eye appear, swallow "+(capitalize(this_player()->query_real_name()))+" up, close, and disappear!\n");
      move_object(this_player(),"/players/asmithrune/rooms/eyeshop/shop");
      write("The eye opens up and expands, sucking you in.  You emerge at the shop.\n");
      say("You see "+(capitalize(this_player()->query_real_name()))+" step out of a gigantic eye!\n");
      this_player()->add_sp(-5);
      return 1;
   }
   if(str== "back") {
      say("You see a gigantic eye swallow "+(capitalize(this_player()->query_real_name()))+", close and disappear!\n");
      move_object(this_player(),home);
      write("You step back into the eye and it closes taking you back where you where.\n");
      this_player()->add_sp(-5);
      say("You see "+(capitalize(this_player()->query_real_name()))+" step out of a gigantic eye, which closes and disappears!\n");
   }
   return 1;
}
