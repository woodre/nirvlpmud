#define RP "players/asmithrune/room/"

inherit "room/room";

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc="A dirt road going out of a forest";
      long_desc=
      "\n"+
      "The road continues to the north, eventually leaving the forest.\n"+
      "The terrain begins to turn flatter, with a scattering of small trees. \n"+
      "The vegitation is mostly prairie grass and small bushes.  You can see\n"+
      "a huge mountian off in the distance to the northeast.\n";
      items=({
            "mountain","Huge and looming, it looks over the entire land",
            });
      dest_dir=({
            RP+"mountain/road1","north",
            RP+"tcity/road5","south",
            });
   }
}
