inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="Talent Store";
   long_desc="This store WILL sell talents.  Check\n"+
   "back later.\n";
   dest_dir=({"/players/asmithrune/rooms/castle/keepgrd/keep6","west"});
}
