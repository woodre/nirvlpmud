inherit "obj/monster";
object obj;
object gold;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_heart_beat(1);
   set_name("mongrel");
   set_alias("man");
   set_short("A Mongrel Man");
   set_long("This little thing is part orc, part goblin, part\n"+
      "troll, part crab, and part something you can't quite\n"+
      "identify.  Looks like a wizard  who was on acid's creation.\n");
   set_level(11);
   set_hp(165);
   set_al(-100);
   set_wc(15);
   set_ac(9);
   set_aggressive(0);
}
hear_beat() {
   if(!present(obj->query_attack())) {
      move_object(this_object(),environment(obj->query_attack()));
      write("The Mongrel Man follows you!");
      return 1;
   }
}
