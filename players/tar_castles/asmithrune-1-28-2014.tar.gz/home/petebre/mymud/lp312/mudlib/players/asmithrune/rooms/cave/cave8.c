inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="As you walk down the cave, you notice that the\n"+
   "floor is smooth, as if worn down by something.  You also\n"+
   "notice the tunnel seems to be getting dryer.  The tunnel\n"+
   "continues north.\n";
   dest_dir=({"players/asmithrune/rooms/cave/cave9","north",
         "players/asmithrune/rooms/cave/cave7","south"});
}
