inherit "obj/weapon.c";

#define TPN this_player()->query_name()
#define TPL this_player()->query_level()
#define MN attacker->query_name()

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("");
   set_alias("");
   set_short("");
   set_long("");
   set_class( );
   set_weight( );
   set_value( );
   /* set_read("");
   set_hit_func(this_object()); */
}

/* weapon_hit(attacker) {
   return;
}
*/

