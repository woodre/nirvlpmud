int i;
reset(arg) {
   if(arg)
      set_light(0);
   if(!present("mongrel")) {
      while(i<4) {
         i += 1;
         move_object(clone_object("players/asmithrune/monsters/mongrel"),this_object());
      }
   }
}
init() {
   add_action("south","south");
   add_action("west","west");
}
south() {
   if(!present("mongrel")) {
      call_other(this_player(),"move_player",
         "south#players/asmithrune/rooms/cave/cave20");
      return 1;
   }
   else {
      write("The Mongrel Men stop you.\n");
      return 1;
   }
}
west() {
   call_other(this_player(),"move_player",
      "west#players/asmithrune/rooms/cave/cave18");
   return 1;
}
long()
{
   write("You have found the begining of the lair of\n"+
      "disgusting beasts.  There are four of them here squabiling\n"+
      "over a piece of garbage.  The tunnel continues south.\n");
}
short()
{
   return "A Cave";
}
