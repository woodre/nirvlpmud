inherit "room/room";
reset(arg) {
   if(!present("behir")) {
      move_object(clone_object("/players/asmithrune/monsters/behir"),this_object());
   }
   if(!present("chest")) {
      move_object(clone_object("/players/asmithrune/objects/chests/chest3"),this_object());
   }
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You have finally found the source of the breathing\n"+
   "noises you have heard on your long journey through the\n"+
   "caves.  This room is about 40ft square, and filled with stone colums.  There is also a large\n"+
   "stone chest sitting in the corner.  However there is also a\n"+
   "fierce Behir guarding it.  Can you face the challange?\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave16","west"});
}
