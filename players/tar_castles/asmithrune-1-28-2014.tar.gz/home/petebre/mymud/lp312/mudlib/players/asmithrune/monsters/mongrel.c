inherit "obj/monster";
object gold;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("mongrel");
   set_alias("man");
   set_short("A Mongrel Man");
   set_long("This little thing is part orc, part goblin, part\n"+
      "troll, part crab, and part something you can't quite\n"+
      "identify.  Looks like a wizard  who was on acid's creation.\n");
   set_level(11);
   set_hp(165);
   set_al(-100);
   set_wc(15);
   set_ac(9);
   set_aggressive(1);
   set_chat_chance(30);
   load_chat("The Mongrel Man looks at you and mews softly.\n");
   load_chat("The Mongrel Man scratches itself.\n");
   set_a_chat_chance(20);
   load_a_chat("The Mongrel Man flees in terror but is pulled back by\n"+
      "his friends!\n");
   gold=clone_object("obj/money");
   gold->set_money(50);
   move_object(gold,this_object());
}
