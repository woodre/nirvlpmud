inherit "obj/monster";
object key;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("ghost");
   set_alias("ghost");
   set_short("A Ghost of a Adventurer");
   set_long("This is the ghost of some poor adventurer who\n"+
      "got lost in the caves and perished.  He doesn't look happy.\n");
   set_level(20);
   set_hp(500);
   set_al(0);
   set_wc(30);
   set_ac(17);
   set_chat_chance(30);
   load_chat("The Ghost looks at you with envy.\n");
   set_a_chat_chance(30);
   load_a_chat("The Ghost swirls around you.\n");
   set_chance(40);
   set_spell_mess1("The Ghost shrieks with anger!\n");
   set_spell_mess2("The Ghost shrieks and you feel weaker!\n");
   set_spell_dam(25);
   key=clone_object("/players/asmithrune/objects/keys/wokey");
   move_object(key,this_object());
}
