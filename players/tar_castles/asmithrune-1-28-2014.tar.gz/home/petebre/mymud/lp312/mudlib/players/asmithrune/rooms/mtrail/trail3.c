inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A trail";
   long_desc="Here the trail begins to enter a forest.  The trees\n"+
   "are tall and full of leaves.  The path has turned from sand into\n"+
   "leaves and grass.  The trail continues east from here.\n";
   dest_dir=({"/players/asmithrune/rooms/trail4","east",
         "/players/asmithrune/rooms/trail2","west"});
}
