inherit "obj/treasure";
object sword;

reset(arg) {
   if(arg) return;
   set_short("A Large Stone Chest");
   set_alias("chest");
   set_long("This is a large stone chest.\n");
   set_weight(1000);
   set_value(0);
}
init() {
   add_action("open","open");
}

open(string str) {
   if(str == "chest") {
      if(!present("behir",environment(this_object()))) {
         if(present("stonekey",this_player())) {
            write("You use your key to unlock the chest.  As you open\n"+
               "it, a large blue sword flies into your hand.\n");
            sword=clone_object("players/asmithrune/weapons/lightning");
            move_object(sword,this_player());
            destruct(this_object());
            return 1;
         }
         else {
            write("You do not have the key.\n");
            return 1;
         }
      }
      else {
         write("The Behir stops you from opening the chest.\n");
         return 1;
      }
   }
   else {
      write("Open what?\n");
      return 1;
   }
   
}
