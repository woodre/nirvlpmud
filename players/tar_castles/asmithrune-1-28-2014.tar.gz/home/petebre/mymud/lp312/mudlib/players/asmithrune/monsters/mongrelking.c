inherit "obj/monster";
object stave;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("king");
   set_alias("king");
   set_short("A Mongrel King");
   set_long("This is the king of these infarious little beastie.\n"+
      "He looks exactly like them, only bigger.");
   set_level(21);
   set_hp(600);
   set_al(-100);
   set_aggressive(1);
   set_wc(32);
   set_ac(18);
   set_chat_chance(30);
   load_chat("The Mongrel King farts.\n");
   set_a_chat_chance(20);
   load_a_chat("The Mongrel King waves his staff!\n");
   set_chance(30);
   set_spell_mess1("The King smaches the stave on the ground and see his opponent quiver!\n");
   set_spell_mess2("The King smashes his stave on the ground and you feel the effects!\n");
   set_spell_dam(20);
/*
   stave=clone_object("players/asmithrune/weapons/stave");
   if(!present("stave",this_object())) {
      move_object(stave,this_object());
   }
    file doent exist  - mythos <8-19-1999>
*/
}
