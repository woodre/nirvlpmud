reset(arg) {
   if(!present("gorgimera")) {
      move_object(clone_object("/players/asmithrune/monsters/gorga"),this_object());
   }
   if(arg) return;
   set_light(0);
}
init() {
   add_action("east","east");
   add_action("north","north");
}
east() {
   if(!present("gorgimera")) {
      call_other(this_player(),"move_player",
         "east#players/asmithrune/rooms/cave/cave16");
      return 1;
   }
   else {
      write("The Gorgimera stops you.\n");
      return 1;
   }
}
north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/cave/cave14");
   return 1;
}
long() {
   write("You travel down the tunnels for quite a ways.\n"+
      "Each step makes the tunnel hotter and the breathing louder.\n"+
      "You finally enter a room and are confronted by a beast that\n"+
      "that appears to be from Hell itself.  It is part\n"+
      "bull,dragon, and lion.  The tunnel turns east here.\n"+
      "     There are two obvious exits: east and north.\n");
}
short() {
   return "A Cave";
}
