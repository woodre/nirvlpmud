inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon"
#define Op "players/asmithrune/obj"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A dirt road going through a forest";
      long_desc=
"\n"+
"You continue on the dirt road until you tire.  You sit\n"+
"down to rest and notice a path to the east.  Looking around further,\n"+
"the road continues north and south but you are surrounded\n"+
"on all other sides by trees.  Glancing up, you ponder the\n"+
"blue sky for a moment.   You decide to move on.\n";
      items = ({
"sky","A beautiful blue sky with small, fluffy white clouds",
"path","A small path goes through the forest to the east",
"road","A road through the forest made from dirt.  It goes north and south",
            });
      dest_dir=({
RP+"tcity/road5","north",
RP+"tcity/road4","south",
RP+"tcity/path6","east",
            });
   }
}
