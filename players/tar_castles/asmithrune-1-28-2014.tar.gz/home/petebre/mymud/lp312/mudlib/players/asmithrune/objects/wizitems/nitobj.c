inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A NIT Object");
   set_alias("nitobj");
   set_long("A info object, type info <object> for info.\n");
   set_long("A no-idle-timeout object, type  keepon  to activate.\n");
   set_value(0);
}
init() {
   add_action("keepon","keepon");
}

keepon() {
   call_other(this_player(),"set_noidlequit","");
   write("Idle-safe\n");
   return(1);
}
