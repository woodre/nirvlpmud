inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon/"
#define Op "players/asmithrune/obj/"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A small path through the grass";
      long_desc=
"\n"+
"This appears to be a normal animal track trough the grass.\n"+
"It's width varies from foot to foot and it curves slowly to the\n"+
"west. The grasses alongside the path are about 6ft tall.\n";
      items = ({
"path","The path winds through the grasses and is covered in small footprints",
            });
      dest_dir=({
RP+"giantcastle/trail3","southeast",
            });
   }
}
