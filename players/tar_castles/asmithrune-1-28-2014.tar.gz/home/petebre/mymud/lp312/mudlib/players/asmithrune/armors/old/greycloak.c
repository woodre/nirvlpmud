inherit "obj/armor";

reset(arg) {
   ::reset(arg);
   set_name("grey cloak");
   set_alias("cloak");
   set_type("helmet");
   set_short("A grey cloak with a hood");
   set_long("This is a grey hooded cloak.  It has a clasp at the neck,\n"+
      "but otherwise is open.  It is slightly dusty.\n");
   set_ac(1);
   set_weight(10);
   set_value(0);
}

init() {
   ::init();
   add_action("clasp_cloak","clasp");
}

clasp_cloak(string what) {
   if(!what) {
      write("Clasp what?\n");
      return 1;
   }
   if(what == "cloak") {
      int wear;
      wear = this_object()->query_worn();
      if(wear) {
         write("You clasp the cloak tight around your neck.\n");
         set_ac(2);
         return 1;
      }
      else {
         write("You must wear the cloak first.\n");
         return 1;
      }
   }
   else {
      write("Clasp what?\n");
      return 1;
   }
}
