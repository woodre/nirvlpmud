inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Cave";
   long_desc="As you enter the cave, your senses are overcome.  You\n"+
   "smell the decaying animals that have crawled in here to die.  You\n"+
   "hear the driping of water from the stalagtites in the celing.  You\n"+
   "can't see very much, because even your bright light is muted by this\n"+
   "dank and dreary cave.  There are tunnels leading north, south, and west.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave2","south",
         "/players/asmithrune/rooms/trail5","exit",
         "/players/asmithrune/rooms/cave/cave18","north"});
}
