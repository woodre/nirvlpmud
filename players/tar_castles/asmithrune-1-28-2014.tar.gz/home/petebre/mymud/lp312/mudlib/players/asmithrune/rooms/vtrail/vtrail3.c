inherit "room/room";

#define RP "/players/asmithrune/rooms/"
#define MP "/players/asmithrune/mon/"
#define OB "/players/asmithrune/obj/"

reset(arg) {
   if(!arg) {
      set_light(1);
short_desc = "Trail with a small village to the north and an opening to the east.";
long_desc="The trail continues north and south here.  The village to the north\n"+
"appears to be getting closer.  You also make out a small opening in\n"+
"the trees to the east.\n";
      items = ({
"opening","There is an opening in the trees just big enough for you to squeeze through",
            });
      dest_dir=({
            RP+"vtrail/vtrail3.c","north",
            RP+"htrail/htrail1.c","east",
RP+"vtrail/vtrail1.c","south",
            });
   }
}
