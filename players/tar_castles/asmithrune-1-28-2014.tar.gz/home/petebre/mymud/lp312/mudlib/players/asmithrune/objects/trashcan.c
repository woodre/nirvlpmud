inherit "obj/treasure";
int objweight;

reset(arg) {
   if(arg) return;
   set_short("A trashcan");
   set_alias("trashcan");
   set_long("This is a trashcan.  Type 'trash <item>' to\n"+
      "get rid of something.\m");
   set_weight(1000);
   set_value(0);
}
init() {
   add_action("trash","trash");
}

trash(object obj) {
   if(!obj) {
      write("You must have something to throw away.\n");
      return 1;
   }
   if(present(obj,this_player())) {
      write("You throw away the "+capitalize(obj)+" into the trashcan.\n"+
         "You feel better knowing the MUD will be clean.\n");
      say(capitalize(this_player()->query_real_name())+" throws something into the trashcan.\n");
      objweight=obj->query_weight();
      destruct(obj,this_player());
      this_player()->add_weight(-objweight);
      return 1;
   }
   else {
      write("You have no "+capitalize(obj)+"!\n");
      return 1;
   }
}
