inherit "room/room";
reset(arg) {
   if(!present("troll")) {
      move_object(clone_object("/players/asmithrune/monsters/troll"),this_object());
   }
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You have entered the domicile of a cave troll.\n"+
   "There are many bones of past meals(you hope human meals)\n"+
   "scattered across the floor.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave24","north"});
}
