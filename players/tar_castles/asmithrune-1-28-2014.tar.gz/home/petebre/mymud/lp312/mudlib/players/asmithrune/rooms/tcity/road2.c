inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon"
#define Op "players/asmithrune/obj"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A dirt road going through a forest";
      long_desc=
      "\n"+
      "You walk a while upon the road until you see another door\n"+
      "in the base of the tree to the east of you.  As you stand\n"+
      "thinking wether or not to go in, a squrrile runs chattering\n"+
      "by whilst a small song bird comes to rest upon the handle\n"+
      "of the door.  A small path through the trees lies to your\n"+
      "west, while the road coninues to the north and south.  \n";
      items = ({
            "bird","A red song-bird pearches upon the handle of the door,\n"+
            "regarding you with as much interest as you give it",
           "door","A small, wooden door set into the base of the tree",
"road","This is a road made from dirt.  It goes north and south",
"path","This is a path through the trees running either northeast or west",
            });
      dest_dir=({
            RP+"tcity/road3","north",
            RP+"tcity/road1","south",
            RP+"tcity/path1","west",
            RP+"tcity/btree4","east",
            });
   }
}
