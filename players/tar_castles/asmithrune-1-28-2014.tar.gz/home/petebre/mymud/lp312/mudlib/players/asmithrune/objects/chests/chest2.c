inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A Small Metal Chest");
   set_alias("chest");
   set_long("This is a small metal chest.\n");
   set_weight(1000);
   set_value(0);
}
init() {
   add_action("open","open");
}

open(string str) {
   if(str == "chest") {
      if(!present("spectator",environment(this_object()))) {
         if(present("metalkey",this_player())) {
            write("You use your key to unlock the chest.  As you open\n"+
               "it, a small yellow wand flies into your hand.\n");
            return 1;
         }
         else {
            write("You do not have the key.\n");
            return 1;
         }
      }
      else {
         write("The Spectator stops you from opening the chest.\n");
         return 1;
      }
   }
   else {
      write("Open what?\n");
      return 1;
   }
   
}
