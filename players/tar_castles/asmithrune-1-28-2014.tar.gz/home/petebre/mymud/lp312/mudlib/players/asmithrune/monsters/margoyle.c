inherit "obj/monster";
object gold;
reset(arg) {
if(arg) return;
   ::reset(arg);
   set_name("margoyle");
   set_alias("margoyle");
   set_short("A Margoyle");
   set_long("What you thought was part of the cave isn't.  This little beastie\n"+
      "looks just like a demon made of rock.  It should because that is what it is.\n");
   set_aggressive(1);
   set_level(15);
   set_hp(250);
   set_al(-1000);
   set_wc(20);
   set_ac(12);
   set_chat_chance(30);
   load_chat("The Margoyle blends in with the rock.\n");
   set_a_chat_chance(30);
   load_a_chat("The Margoyle swings a spiked arm at you!\n");
   set_chance(25);
   set_spell_mess1("The Margoyle blends in with the rock and leaps at it's victim!\n");
   set_spell_mess2("The Margoyle leaps at you from nowhere!\n");
   set_spell_dam(20);
   gold=clone_object("obj/money");
   gold->set_money(900);
   move_object(gold,this_object());
}
