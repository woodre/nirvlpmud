inherit "obj/armor";

reset(arg) {
   ::reset(arg);
   set_name("skull");
   set_alias("helmet");
   set_type("helmet");
   set_short("A SaberTooth Tiger Skull");
   set_long("The skull of a sabertooth tiger.  It looks heavy.\n");
   set_ac(1);
   set_weight(2);
   set_value(10000);
}
