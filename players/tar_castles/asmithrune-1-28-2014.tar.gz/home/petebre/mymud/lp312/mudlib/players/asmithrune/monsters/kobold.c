inherit "obj/monster";
object gold;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("kobold");
   set_alias("kobold");
   set_short("A Kobold");
   set_long("This Kobold is normal for his kind, except for the smile on his face.\n");
   set_level(9);
   set_al(135);
   set_hp(135);
   set_wc(13);
   set_ac(7);
   set_chat_chance(30);
   load_chat("The Kobold looks at you and winks.\n");
   set_a_chat_chance(30);
   load_a_chat("The Kobold looks at you and grins\n");
   gold=clone_object("obj/money");
   gold->set_money(random(200)+75);
   move_object(gold,this_object());
}
