inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="As yo continue down the tunnel, you come to\n"+
   "a sharp turn in it.  It looks as if the tunnel once continued\n"+
   "to the south, but there was a cave-in.  The tunnel now turns\n"+
   "east.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave5","east",
         "/players/asmithrune/rooms/cave/cave3","north"});
}
