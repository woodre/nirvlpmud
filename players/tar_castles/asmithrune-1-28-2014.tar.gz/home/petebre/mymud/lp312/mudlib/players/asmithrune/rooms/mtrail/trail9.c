inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Path";
   long_desc="As you emerge, breathing heavy, battered, yet victorious, from\n"+
   "your battle with the tangle tree, you see the path continues north,\n"+
   "it is not as well kept as it was.  The shrubs and trees of the forest\n"+
   "are beginning to wander in on the path, and the path it self is no longer\n"+
   "rocks and gravel, but has reverted to it's normal leaves and dirt.  The path\n"+
   "continues north.\n";
   dest_dir=({"/players/asmithrune/rooms/trail10","north",
         "/players/asmithrune/rooms/trail8","south"});
}
