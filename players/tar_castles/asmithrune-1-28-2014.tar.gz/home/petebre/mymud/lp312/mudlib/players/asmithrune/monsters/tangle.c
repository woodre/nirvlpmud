inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   if(arg) return;
   set_name("tangle tree");
   set_alias("tangle");
   set_short("A tangle tree");
   set_long("a huge tree\n");
   set_level(20);
   set_hp(500);
   set_al(-500);
   set_wc(30);
   set_ac(17);
   set_aggressive(1);
   set_chance(30);
   set_spell_mess2("The Tangle Tree spits acid sap at you!\n");
   set_spell_dam(30);
   set_a_chat_chance(30);
   load_a_chat("The tangle tree pulls you toward it's mouth!\n");
   gold=clone_object("obj/money");
   gold->set_money(random(1000)+2000);
   move_object(gold,this_object());
   load_a_chat("The tangle tree raps a tentacle around you!\n");
}
