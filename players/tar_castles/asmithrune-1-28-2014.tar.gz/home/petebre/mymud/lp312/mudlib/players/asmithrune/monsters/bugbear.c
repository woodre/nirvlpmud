inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("bugbear");
   set_alias("bugbear");
   set_short("A Bugbear");
   set_long("This Bugbear has a beautiful pelt of fur, even if it is a bit dirty.\n");
   set_level(8);
   set_al(100);
   set_hp(120);
   set_wc(12);
   set_ac(7);
   set_chat_chance(30);
   load_chat("The Bugbear looks at you and giggles.\n");
   set_a_chat_chance(30);
   load_a_chat("The Bugbear runs his hand through his fur and flicks something at you.\n");
   gold=clone_object("obj/money");
   gold->set_money(random(300)+100);
   move_object(gold,this_object());
}
