inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="As you continue down the tunnel, you notice the beauty of the cave.\n"+
   "How the cave walls shine with a beautiful green light.  The trail continues south.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave4","south",
         "/players/asmithrune/rooms/cave/cave2","north"});
}
