inherit "obj/treasure";
string cname,title,pretitle,alignment;
int level,money,hp,mhp,sp,msp,exp,qpoints,age;
int nextlevel;

reset(arg) {
   if(arg) return;
   set_short("A Score Object");
   set_alias("sco");
   set_long("A score object, type 'sco' for your score.\n");
   set_weight(0);
   set_value(0);
}
init() {
   add_action("sco","sco");
}

sco() {
   money=this_player()->query_money();
   exp=this_player()->query_exp();
   level = this_player()->query_level();
   if(level==1) {
      nextlevel=1014-exp;
   }
   if(level==2) {
      nextlevel=1771-exp;
   }
   if(level==3) {
      nextlevel=2332-exp;
   }
   if(level==4) {
      nextlevel=5885-exp;
   }
   if(level==5) {
      nextlevel=12812-exp;
   }
   if(level==6) {
      nextlevel=26662-exp;
   }
   if(level==7) {
      nextlevel=39993-exp;
   }
   if(level==8) {
      nextlevel=59995-exp;
   }
   if(level==9) {
      nextlevel=90000-exp;
   }
   if(level==10) {
      nextlevel=134998-exp;
   }
   if(level==11) {
      nextlevel=195591-exp;
   }
   if(level==12) {
      nextlevel=295592-exp;
   }
   if(level==13) {
      nextlevel=492294-exp;
   }
   if(level==14) {
      nextlevel=620026-exp;
   }
   if(level==15) {
      nextlevel=820028-exp;
   }
   if(level==16) {
      nextlevel=1040028-exp;
   }
   if(level==17) {
      nextlevel=1367106-exp;
   }
   if(level==18) {
      nextlevel=2000000-exp;
   }
   if(level==19) {
      nextlevel=2500000-exp;
   }
   if(nextlevel>0) {
      write("\n");
      write("Money: "+money+".\n");
      write("Expierence: "+exp+".\n");
      write("Expierence to next level: "+nextlevel+".\n");
      return 1;
   }
   else {
      write("\n");
      write("Money: "+money+".\n");
      write("Expierence: "+exp+".\n");
      write("Expierence to next level: You have enough to advance!\n");
      write("Expierence to spend: "+(-1*nextlevel)+".\n");
      return 1;
   }
}
