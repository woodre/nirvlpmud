inherit "obj/monster";
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("elemental");
   set_alias("water");
   set_short("A Water Elemental");
   set_long("This is a creature from the Elemental Plane of Water, and is made entirely of water.\n");
   set_level(15);
   set_hp(225);
   set_ac(12);
   set_wc(20);
   set_al(0);
   set_aggressive(1);
   set_a_chat_chance(30);
   load_a_chat("The Water Elemental leaps at you!\n");
   set_chance(40);
   set_spell_mess1("The Water Elemental drowns it's attacker!\n");
   set_spell_mess2("The Water Elemental flows over you and you suffocate!\n");
   set_spell_dam(15);
}
