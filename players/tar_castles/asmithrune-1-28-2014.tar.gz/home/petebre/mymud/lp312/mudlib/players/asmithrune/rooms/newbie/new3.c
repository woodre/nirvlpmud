reset(arg) {
   int i;
   if(arg) return;
   set_light(1);
   if(!present("hobbit")) {
      while(i < 5) {
         i = i + 1;
         move_object(clone_object("/players/asmithrune/monsters/hobbit"),this_object());
      }
   }
}
init() {
   add_action("south","south");
}
south() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/newbie/new2");
   return 1;
}

long() {
   write("You have entered a small alcove hidden\n"+
      "in the forest.  All around, prancing and dancing,\n"+
      "are small hobbits, their pipes aglow and their\n"+
      "eyes twinkling.\n"+
      "     There is one obvious exit: south.\n");
}
short() {
   return "Newbie Zone";
}
