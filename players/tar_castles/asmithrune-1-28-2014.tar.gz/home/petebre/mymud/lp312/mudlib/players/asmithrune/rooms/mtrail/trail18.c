inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="You can now see a small path leading to the\n"+
   "to the northwest, or the trail continues to the west.\n";
   dest_dir=({"/players/asmithrune/rooms/castle/cas1","northwest",
         "players/asmithrune/rooms/trail17","west",
         "players/asmithrune/rooms/trail10","east"});
}
