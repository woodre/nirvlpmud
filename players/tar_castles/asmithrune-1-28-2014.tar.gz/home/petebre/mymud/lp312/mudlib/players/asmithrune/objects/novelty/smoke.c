inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A Marlboro Red");
   set_alias("smoke");
   set_long("This is a Marlboro Red cigarrette. Type 'smoke boge' to\n"+
      "smoke it!\n");
   set_weight(0);
   set_value(0);
}

init() {
   add_action("smoke","smoke");
}

smoke(string str) {
   if(!str) {
      write("Smoke what?\n");
      return 1;
   }
   if(str == "boge") {
      write("You light up the Red, and it tastes good:)\n");
      say(capitalize(this_player()->query_real_name())+" lights up a Red.\n");
      destruct(this_object());
      return 1;
   }
   else {
      write("Smoke what?\n");
      return 1;
   }
}
