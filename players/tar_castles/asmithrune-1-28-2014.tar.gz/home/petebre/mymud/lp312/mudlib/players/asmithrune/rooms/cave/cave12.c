inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You continue down the tunnel, and you\n"+
   "can begin to hear some sort of heavy breathing ahead.\n"+
   "You curiosity is peeked and you continue on.\n";
   dest_dir=({"players/asmithrune/rooms/cave/cave13","south",
         "players/asmithrune/rooms/cave/cave11","north"});
}
