inherit "room/room";

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc="Asmithrune's Workroom";
      long_desc=
      "\n"+
      "This is the workroom of the Black King, Asmithrune.\n"+
      "Around you lay the normal trappings of a wizard; the\n"+
      "eye of newt, the toe of dragon.  A slight odor of incense\n"+
      "permeates the air.  A large oak desk with a leather\n"+
      "chair sits in one corner.  Upon the desk lay different pieces of\n"+
      "scientific equipment.\n";
      items=({
            "chair","A large, stuffed, leather chair",
            "desk","A large, ornately carved, oaken desk",
            "toe","This is the scaly, green small toe of a dragon",
            "eye","The eye of knewt seems to stare at you from it's jar",
            "equipment","Various pieces of scientific equipment, including glass beakers\n"+
            "and flasks, are on the table",
            });
      dest_dir=({
            "/room/church","church",
            "/room/shop","shop",
            "/players/asmithrune/room/tcity/road1","road",
});
   }
}
init() {
   ::init();
   add_action("exper_func","experiment");
   add_action("search_func","search");
}

exper_func(){
   write("You experiment with the exquipment, but do\n"+
      "not create anything useful.\n");
   say(this_player()->query_name()+" experiments with the scientific equipment.\n");
   return 1;
}

mas_search_func(string where,string mwhere,string txt,string sobj) {
   if(!where) {
      write("You search your pockets and hair, but don't find anything.\n");
      return;
   }
   if(where == mwhere) {
      write(txt);
      if(sobj) {
         move_object(clone_object(sobj),this_player());
      }
      say(this_player()->query_name()+" searches the "+where+".\n");
   }
   return;
}
search_func(string where) {
   mas_search_func(where,"room","You find a cloak!\n","/players/asmithrune/armors/greycloak");
   return 1;
}


