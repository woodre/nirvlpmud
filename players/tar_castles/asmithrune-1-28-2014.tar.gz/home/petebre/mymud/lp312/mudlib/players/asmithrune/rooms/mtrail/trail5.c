reset(arg) {
   if(!arg) {
      set_light(1);
   }
}
init() {
   add_action("west","west");
   add_action("enter","enter");
   add_action("read","read");
}
west() {
   call_other(this_player(),"move_player",
      "west#players/asmithrune/rooms/trail4");
   return 1;
}
enter() {
   call_other(this_player(),"move_player",
      "enter#players/asmithrune/rooms/cave/cave1");
   return 1;
}
read(string str) {
   if(str == "sign") {
      write("The sign on the rock says:\n"+
         "\n"+
         "'Abandon all hope, ye who enter here.\n"+
         "(Hint:The sign means that if you are not at least 10th level\n"+
         "don't go in the cave.)\n");
      return 1;
   }
   else {
      write("Read what?\n");
      return 1;
   }
}

long()
{
   write("You walk for a while in the forest and eventually\n"+
      "come to  a clearing.  There is a cave here with a large\n"+
      "rock beside it.  There is a sign on the rock.\n"+
      "There are two obvious exits: west, enter\n");
}
short()
{
   return "A Trail";
}
