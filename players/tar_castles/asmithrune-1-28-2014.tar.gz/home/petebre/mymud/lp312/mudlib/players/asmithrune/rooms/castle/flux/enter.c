reset(arg) {
   string me;
   if(!arg) {
      set_light(1);
   }
}
init() {
   add_action("north","north");
   add_action("south","south");
}
north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/castle/flux/fluxa.c");
   return 1;
}
south() {
   call_other(this_player(),"move_player",
      "south#room/forest1");
   return 1;
}
long() {
   write("As you enter the field, your body is torn apart\n"+
      "and rejoined millions upon millions of times.  When you regain\n"+
      "conciousness, you realize that you are far from your homeland.\n"+
      "You lie in a place  full of trees and bushes, somewhat\n"+
      "like you are used to, but yet somehow very different.\n"+
      "A strange path bekons to the north, and the field\n"+
      "waits patiencely behind you to the south.\n"+
      "      There are two obvious exits: north and south.\n");
}
short()
{
   return "Field";
}
