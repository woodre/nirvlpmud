reset(arg) {
   if(!arg)
      set_light(1);
}
init() {
   add_action("north","north");
   add_action("south","south");
   add_action("read","read");
}
north() {
   call_other(this_player(), "move_player",
      "north#players/asmithrune/rooms/trail8");
   return 1;
}
south() {
   call_other(this_player(), "move_player",
      "south#players/asmithrune/rooms/trail6");
   return 1;
}
read(string str) {
   if(str == "sign") {
      write("Carved into the tree, sharp aged writing reads:\n"+
         "'the monster..ahead....is terrible...the tree...is alive....'\n"+
         "\n"+
         "Then the knife mark slides down and off the tree.\n");
      return 1;
   }
   else {
      write("Read what?\n");
      return 1;
   }
}
long() {
   write("You have entered a small clearing with tall trees surrounding it.\n"+
      "Carved into one of the trees, you notice a sign.  And beneath that same\n"+
      "tree, you see a pile of human bones!\n"+
      "          There are two obvious exits: north and south\n");
}
short() {
   return "A Path";
}
