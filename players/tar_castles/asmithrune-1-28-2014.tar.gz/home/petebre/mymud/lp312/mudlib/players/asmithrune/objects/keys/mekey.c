inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A Metal Key");
   set_alias("metalkey");
   set_id("key");
   set_long("A small wooden key.\n");
   set_weight(0);
   set_value(10);
}
