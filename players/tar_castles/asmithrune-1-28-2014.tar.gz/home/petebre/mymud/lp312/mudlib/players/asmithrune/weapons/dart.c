inherit "obj/treasure";
object victim;
reset(arg) {
   if(arg) return;
   set_alias("dart");
   set_short("A Dart");
   set_long("This is a dart.  Type dart <monstername>.\n");
   set_value(100);
   set_weight(2);
}
init() {
   add_action("dart","dart");
}

dart(object obj) {
   if(present(obj,environment(this_player()))) {
      if(find_living(obj)) {
         int ra;
         ra = random(100);
         if(ra>10) {
            write("You throw the dart at the "+(obj)+" and smack it in the face.\n");
            say(capitalize(this_player()->query_real_name())+" fires a dart at "+(obj)+".\n");
find_living(obj)->hit_player(5);
            victim = find_living(obj);
            victim->attacked_by(this_player());
            destruct(this_object());
            return 1;
         }
         else {
            write("The dart flies back at you and hits you!\n");
            say(capitalize(this_player()->query_real_name())+ "is hit by his/her own dart!\n");
            this_player()->hit_player(5);
            destruct(this_object());
            return 1;
         }
      }
   }
}
