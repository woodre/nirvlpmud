reset(arg) {
   if(arg) return;
   set_light(1);
}
init() {
   add_action("east","east");
   add_action("west","west");
   add_action("north","north");
   add_action("south","south");
}
east() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/newbie/new1");
   return 1;
}

west() {
   call_other(this_player(),"move_player",
      "west#players/asmithrune/rooms/newbie/new5");
   return 1;
}

north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/newbie/new3");
   return 1;
}

south() {
   call_other(this_player(),"move_player",
      "south#players/asmithrune/rooms/newbie/new4");
   return 1;
}

long() {
   write("As you continue down the path through the\n"+
      "forest, you can't stop the smile from creeping\n"+
      "across your face.  This place is just SO happy.\n"+
      "     There are four obvious exits: north, south, east, and west.\n");
}
short() {
   return "Newbie Zone";
}
