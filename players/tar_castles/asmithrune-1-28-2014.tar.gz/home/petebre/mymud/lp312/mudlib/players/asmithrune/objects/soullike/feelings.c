inherit "obj/treasure";
string env;
int namelen,spacelen;
object guild;
int i;
object list;

reset(arg) {
   if(arg) return;
   set_short("A Metal Key");
   set_alias("metalkey");
   set_id("key");
   set_long("A small wooden key.\n");
   set_weight(0);
   set_value(10);
}
init() {
   add_action("pray","pray");
   add_action("sende","sende");
   add_action("guildlist","guildlist");
}
sende(string str) {
   if(!str) {
      write("You must emote something.\n");
      return 1;
      
   }
   list = users();
   for(i=0;i<sizeof(list);i++) {
      if(present("robes",list[i])) {
         tell_object(list[i],"(Cleric Emote) "+capitalize(this_player()->query_real_name())+" "+str+"\n");
       }
   }
   return 1;
}
guildlist() {
   object list;
   int i;
   int b;
   int namlen;
   int spacelen;
   write("\n");
   cat("/players/asmithrune/objects/magicitems/clerichead");
   list = users();
   for(i=0; i<sizeof(list);i++) {
      if(present("clericguild",list[i]) && !list[i]->query_invis()) {
         namlen = strlen(list[i]->query_name());
         spacelen = 15-namlen;
if(list[i]->query_level()>9) {
write("@   ["+list[i]->query_level()+"]\t"+list[i]->query_name());
}
if(list[i]->query_level()<10) {
write("@   [0"+list[i]->query_level()+"]\t"+list[i]->query_name());
}
         for(b=0;b<spacelen;b++) {
            write(" ");
         }
         env = environment(list[i])->short();
         namelen = strlen(env);
         spacelen = 48 - namelen;
         write(environment(list[i])->short());
         for(b=0;b<spacelen;b++) {
            write(" ");
         }
         write("@\n");
       }
   }
write("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
   write("\n");
   return 1;
}
