inherit "obj/monster";

object gold;
reset(arg) {
   if(arg)  return;
   ::reset(arg);
   set_name("giant");
   set_alias("giant");
   set_short("A Formorian Giant");
   set_long("This isn't your normal type of giant.  He has an extra leg and\n"+
      "two extra arms.  His body is lumpy and mishapend.\n");
   set_level(15);
   set_hp(225);
   set_al(-1000);
   set_wc(20);
   set_ac(12);
   set_a_chat_chance(30);
   load_a_chat("The Giant swiiiiinnnnnggggggssss his club and hit you!\n");
   gold=clone_object("obj/money");
   gold->set_money(875);
   move_object(gold,this_object());
}
