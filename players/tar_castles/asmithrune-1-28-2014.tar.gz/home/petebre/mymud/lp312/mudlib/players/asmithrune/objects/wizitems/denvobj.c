inherit "obj/treasure";

string global_what;

string store_what(string what) {
   if(what) {
      global_what = what;
   } else {
      if(global_what) {
         what=global_what;
        }
   }
   return(what);
}

reset(arg) {
   if(arg) return;
   set_short("A Development Environment Object");
   set_alias("denvobj");
   set_long("A development environment object.  Type  denv info  for help on usage.\n");
   set_weight(0);
   set_value(0);
}

init() {
   global_what="";
   
   write("Denvobj.c version 1.00...\n");
   add_action("cloneit","cl");
   add_action("cloneit","cloneit");
   add_action("loadit","lo");
   add_action("loadit","loadit");
   add_action("updateit","up");
   add_action("updateit","updateit");
   add_action("makeit","make");
   add_action("editit","ed");
   add_action("denv","denv");
   add_action("check_file","cfile");
   add_action("check_what","cwhat");
}

check_what() {
   write("global_what = "+global_what+"\n");
   return(1);
}
editit(string what) {
   object wsoul;
   int good_file;
   
   good_file=0;
   
   what=store_what(what);
   good_file=check_file(what);
   if(good_file < 0) {
      if(good_file==-1) {
         write("Sorry, the file  "+what+"  cannot be found.\n");
      }
      if(good_file==-2) {
         write("The file  "+what+"  is a directory.\n");
      }
      return(20);
   }
   if(wsoul=present("wiz_soul")) {
      wsoul->edit(what);
      return(1);
   }
   return(30);
}
makeit(string what)
{
   int stage_result;
   
   stage_result=0;
   
   stage_result=loadit(what);
   if(stage_result==1) {
      stage_result=updateit(what);
      if(stage_result==1) {
         stage_result=cloneit(what);
      }
   }
   return(1);
}

int cloneit(string what)
{
   object wsoul;
   int good_file;
   
   good_file=0;
   
   what=store_what(what);
   good_file=check_file(what);
   if(good_file < 0) {
      if(good_file==-1) {
         write("Sorry, the file  "+what+"  cannot be found.\n");
      }
      if(good_file==-2) {
         write("The file  "+what+"  is a directory.\n");
      }
      return(20);
   }
   if(wsoul=present("wiz_soul")) {
      wsoul->clone(what);
      write(what+" has been cloned.\n");
      return(1);
   }
   return(30);
}

int loadit(string what)
{
   object wsoul;
   int good_file;
   
   good_file = 0;
   
   what=store_what(what);
   good_file=check_file(what);
   if(good_file < 0) {
      if(good_file==-1) {
         write("Sorry, the file  "+what+"  cannot be found.\n");
      }
      if(good_file==-2) {
         write("The file  "+what+"  is a directory.\n");
      }
      return(20);
   }
   if(wsoul=present("wiz_soul")) {
      wsoul->load(what);
      write(what+" has been loaded.\n");
      return(1);
   }
   return(30);
}

int updateit(string what)
{
   object wsoul;
   int good_file;
   
   good_file = 0;
   
   what=store_what(what);
   good_file=check_file(what);
   if(good_file < 0) {
      if(good_file==-1) {
         write("Sorry, the file  "+what+"  cannot be found.\n");
      }
      if(good_file==-2) {
         write("The file  "+what+"  is a directory.\n");
      }
      return(20);
   }
   if(wsoul=present("wiz_soul")) {
      wsoul->update(what);
      write(what+" has been updated.\n");
      return(1);
   }
   return(30);
}

denv(string what) {
   if(what == "info") {
      cat("/players/asmithrune/info/denv_info");
   }
   return(1);
}

int check_file(string what) {
   int filesize;
   
   filesize=0;
   
   filesize=file_size(what);
   return(filesize);
}
