inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You turn south and begin to walk, once\n"+
   "again.  You hear a loud stomping to the south.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave29","south",
         "/players/asmithrune/rooms/cave/cave5","north"});
}
