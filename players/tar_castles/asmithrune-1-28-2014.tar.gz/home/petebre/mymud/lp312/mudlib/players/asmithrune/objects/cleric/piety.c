inherit "obj/treasure";
int negpiet;
int piet;
object guild;
int i;
object list;

reset(arg) {
   if(arg) return;
   set_short("A Metal Key");
   set_alias("metalkey");
   set_id("key");
   set_long("A small wooden key.\n");
   set_weight(0);
   set_value(10);
}
init() {
   add_action("pray","pray");
   add_action("sende","sende");
add_action("norobe","norobe");
}
sende(string str) {
   if(!str) {
      write("You must emote something.\n");
      return 1;
      
   }
   list = users();
   for(i=0;i<sizeof(list);i++) {
      if(present("robes",list[i])) {
         tell_object(list[i],"(Cleric Emote) "+capitalize(this_player()->query_real_name())+" "+str+"\n");
       }
   }
   return 1;
}
pray() {
   piet = this_player()->query_attrib("pie");
   negpiet = (-1*piet);
   
   this_player()->raise_piety(negpiet);
   this_player()->raise_piety(20);
   return 1;
}
norobe() {
if(present("clericguild",this_player())) {
