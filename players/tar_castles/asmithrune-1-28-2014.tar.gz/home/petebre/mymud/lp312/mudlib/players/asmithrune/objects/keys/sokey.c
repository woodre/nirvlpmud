inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A Stone Key");
   set_alias("stonekey");
   set_id("key");
   set_long("A small stone key.\n");
   set_weight(0);
   set_value(10);
}
