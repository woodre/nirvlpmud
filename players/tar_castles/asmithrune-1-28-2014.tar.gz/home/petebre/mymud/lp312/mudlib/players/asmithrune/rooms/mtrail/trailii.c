reset(arg) {
   string me;
   if(!arg) {
      set_light(1);
   }
}
init() {
   add_action("north","north");
   add_action("south","south");
}
north() {
   if(find_player("asmithrune")) {
      tell_object(find_player("asmithrune"),"<<<"+(this_player()->query_real_name())+" is entering>>>\n");
   }
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/trail2");
   return 1;
}
south() {
   if(find_player("asmithrune")) {
      tell_object(find_player("asmithrune"),"<<<"+(this_player()->query_real_name())+"is leaving>>>\n");
   }
   call_other(this_player(),"move_player",
      "south#room/forest1");
   return 1;
}
long()
{
   write("After a long walk, the trail finally emerges\n"+
      "into a respectable path.  The trail continues north.\n"+
      "            There are two obvious exits: north and south.\n");
}
short()
{
   return "A Trail";
}
