inherit "obj/treasure";
object strI
;
object tellob;
reset(arg) {
   if(arg) return;
   set_short("A Handy Dandy Phone");
   set_alias("phone");
   set_long("Tired of writing out long names when telling someone\n"+
      "something during a long-distance conversation?  Now, all your\n"+
      "troubles are over!  Just type contell <playername> and then\n"+
      "whenever you want to tell that person something just type\n"+
      "re <message> and that person will get your message!\n"+
      "And just type 'pwho' to find out who the phone is set to.\n");
   set_weight(1);
   set_value(200);
}

init() {
   add_action("contell","contell");
   add_action("re","re");
   add_action("pwho","pwho");
}

contell(object str) {
   if(find_living(str)) {
      strI = capitalize(str);
      write("A long distance link has been set up with "+(strI)+".\n");
      write("Now just use re <message> to tell them something.\n");
      tellob=str;
      return 1;
   }
   else {
      write("That person is not on the MUD right now.  Try again later.\n");
      return 1;
   }
}

re(string str) {
   if(!find_living(tellob)->query_muffled()) {
      if(!in_editor(find_living(tellob))) {
         string strI;
         strI=("<<"+(capitalize(this_player()->query_real_name()))+" via long-distance>> "+(str)+"\n");
         tell_object(find_living(tellob), strI);
         write("You told "+(capitalize(tellob))+":"+(str)+"\n");
         this_player()->add_spell_point(-4);
         return 1;
      }
      else {
         write("That person is edititing.  Try again later.\n");
         return 1;
      }
   }
   else {
      write("That person does not wish to be disturbed.\n");
      return 1;
   }
}
pwho() {
   write("The Phone is set to: "+(capitalize(tellob))+".\n");
   return 1;
}
