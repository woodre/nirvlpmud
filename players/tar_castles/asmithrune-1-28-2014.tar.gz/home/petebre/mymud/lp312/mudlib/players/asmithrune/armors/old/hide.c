inherit "obj/armor";

reset(arg) {
   ::reset(arg);
   set_name("hide");
   set_alias("armor");
   set_short("A SaberTooth Tiger Hide");
   set_long("This is the hide of a mean tiger.  It looks tough.");
   set_ac(4);
   set_weight(6);
   set_value(30000);
}
