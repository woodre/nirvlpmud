inherit "obj/monster";
object shield;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("necromon");
   set_alias("demon");
   set_short("Necromon, the wizard's 'servant'");
   set_long("This is Necromon, the demon servant of the wizard Exterac.\n");
   set_level(25);
   set_hp(1000);
   set_al(-10000);
   set_wc(36);
   set_ac(22);
   set_chat_chance(30);
