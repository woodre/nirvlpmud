inherit "room/room";

#define RP "/players/asmithrune/rooms/"
#define MP "/players/asmithrune/mon/"
#define OB "/players/asmithrune/obj/"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "On a trail through the woods, with a small village to the north.";
      long_desc="You are walking on a narrow, dirt trail that runs north and south\n"+
      "through the woods.  The main road lies to the south and you see\n"+
      "a small village to the north.  A sparrow looks at you oddly as you pass.\n";
      items = ({
           "sparrow","A small sparrow looks at you",
            });
      dest_dir=({
            RP+"vtrail/vtrail2.c","north",
            "/room/church.c","south",
            });
   }
}
