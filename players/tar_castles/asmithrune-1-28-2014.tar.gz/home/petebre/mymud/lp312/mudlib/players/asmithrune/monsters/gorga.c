inherit "obj/monster";
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("gorgimera");
   set_alias("gorgimera");
   set_short("A Gorgimera");
   set_long("This beast is a dragon type creature with two extra\n"+
      "heads, one of a lion and one of a bull.\n");
   set_level(25);
   set_hp(800);
   set_al(-3000);
   set_wc(36);
   set_ac(22);
   set_aggressive(1);
   set_chat_chance(30);
   load_chat("The Gorgimera looks at you...three times.\n");
   set_a_chat_chance(30);
   load_a_chat("The Bull head charges you!\n");
   load_a_chat("The Lion head roars!\n");
   set_chance(40);
   set_spell_mess1("The Dragon head breathes fire around the room!\n");
   set_spell_mess2("The Dragon head breaths fire at you!\n");
   set_spell_dam(40);
}
