inherit "obj/monster";
object gold;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("hobbit");
   set_alias("hobbit");
   set_short("A Happy Hobbit");
   set_long("Although Hobbits are a naturally happy bred, this one seems a bit too happy.\n");
   set_level(8);
   set_al(120);
   set_hp(120);
   set_wc(12);
   set_ac(7);
   set_chat_chance(30);
   load_chat("The Hobbit looks at you and smiles, smiles, SMILES!\n");
   set_a_chat_chance(30);
   load_a_chat("The Hobbit laughs manicly.\n");
   gold=clone_object("obj/money");
   gold->set_money(random(300)+50);
   move_object(gold,this_object());
}
