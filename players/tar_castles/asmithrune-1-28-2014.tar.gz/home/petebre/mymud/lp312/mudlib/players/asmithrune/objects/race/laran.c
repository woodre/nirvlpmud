inherit "obj/treasure";
int cglev;
int nglev;
int minded;
object thinkobj;

#define Name(XXX) call_other(XXX,"query_real_name")
#define Level(XXX) call_other(XXX,"query_level");
reset(arg) {
   if(arg) return;
   set_id("laran");
   set_short("The Gift of Larnus");
   set_long("The Gift of Larnus.\n");
   set_weight(0);
   set_value(0);
}
set_minded(m) {minded = m;}
query_minded() {return minded;}
extra_look() {
   return capitalize(Name(this_player()))+" has the Gift of Larnus.\n";
}
init() {
   ::init();
   add_action("minded","minded");
   add_action("emit","emit");
   add_action("lwho","lwho");
   add_action("promote","promote");
   add_action("think","think");
   add_action("telepath","telepath");
   add_action("harass","harass");
}

look() {
   return ::long();
}
emit(string message) {
   if(this_object()->query_minded()==0) {
      object ob,guild,larnus;
      int i;
      string me;
      me = this_player();
      larnus = this_object();
      if(!message) {
         write("Emit what master?\n");
         return 1;
      }
      ob = users();
      for(i = 0; i < sizeof(ob); i++) {
         guild = present("laran",ob[i]);
         if(guild && guild->query_minded() == 0) {
            tell_object(ob[i],".oO"+(me->query_name())+"Oo. "+message+".\n");
          }
      }
      return 1;
   }
   else {
      write("I am sorry Master, but you can't talk to your fellows while\n"+
         "you are closed minded.\n");
      return 1;
   }
}
lwho() {
   object list, guild;
   int i, lev;
   int glev;
   int namlen, spacelen, b;
   string minded;
   list = users();
   write("============================================\n");
   write("   Larnus Members Currently Logged On\n");
   write("============================================\n");
   write("Name(mindedness)\t[Level] {Guild Level}\n");
   write("--------------------------------------------\n");
   for( i = 0; i < sizeof(list); i++) {
      guild = present("laran",list[i]);
      if(guild) {
         string name;
         name = Name(list[i]);
         namlen = strlen(name);
         spacelen = 15-namlen;
         name = capitalize(name);
         lev = Level(list[i]);
         glev = list[i]->query_guild_rank();
         if(guild->query_minded()==0) {minded = "(Open Minded)";}
         if(guild->query_minded()==1){minded = "(Close Minded)";}
         write(name+" "+(minded));
         for(b = 0;b<spacelen;b++) {
            write(" ");
         }
         write("\t["+(lev)+"] {"+(glev)+"}\n");
       }
   }
   write("============================================\n");
   return 1;
}
promote(int num) {
   if((this_player()->query_level())>20) {
      write("You raise your Guild Level to "+(num)+".\n");
      this_player()->add_guild_rank();
      return 1;
   }
}
minded(str) {
   if(!str) {
      write("Ah, but Master, that is not correct.\n"+
         "The correct way is: minded (open/closed)\n");
      return 1;
   }
   if(str == "closed") {
      if(minded==1) {
         write("But Master, you are already closed minded.\n");
         return 1;
      } 
      else {
         minded = 1;
         write("You are now closed minded, master.\n");
         return 1;
      }
      if(str == "open") {
         if(minded == 0) {
            write("You weren't closed minded, oh master of the universe.\n");
            return 1;
         }
         else {
            minded = 0;
            write("Once again, master, you are now open minded.\n");
            return 1;
         }
      }
   }
}
think(object obj) {
   if(!obj) {
      write("Please, Master, I need a person to set think to.\n");
      return 1;
   }
   if(find_player(obj)) {
      if(!find_player(obj)->in_edit()) {
         if(find_player(obj)->query_level()<50) {
            thinkobj = find_player(obj);
            write("You are now thinking about "+(capitalize(find_player(obj)->query_real_name()))+".\n");
            return 1;
         }
         else {
            write ("You may not think to wizards, sorry Master.\n");
            return 1;
         }
      }
      else {
         write("That person doesn't wish to be disturbed.\n");
         return 1;
      }
   }
   else {
      write("I can't seem to find that player Master.\n");
      return 1;
   }
}
telepath(string str) {
   if(!str) {
      write("I am sorry, but you must telepath something.\n");
      return 1;
   }
   tell_object(thinkobj,capitalize(this_player()->query_real_name())+" thinks to you:"+(str)+".\n");
   write("You think to "+(capitalize(thinkobj))+".\n");
   return 1;
}
harass(object obj) {
if(find_player(obj)) {
write("You may not cast this spell against a player.\n");
return 1;
}
if(present(find_living(obj)),evironment(this_player())) {
if(this_player()->query_spell_point()>9) {
