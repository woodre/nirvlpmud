inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon/"
#define Op "players/asmithrune/obj/"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A trail";
      long_desc=
"\n"+
"A small path heads northwest into the grasslands from here.\n"+
"The main trail continues flatly to the north and south.  A huge\n"+
"moutain lies far to the north.  A castle clearly sits on the moutain's\n"+
"peak.\n";
      items = ({
"castle","It sits on the moutain top far to the north.  Even from\n"+
"this distance, you can see it is huge",
"trail","A trail made from dirt and stones packed down",
"mountain","It lies far to the north, with a seemingly huge castle on it's top",
            });
      dest_dir=({
RP+"giantcastle/trail3","north",
RP+"giantcastle/entrance","south",
RP+"giantcastle/smallpath1","northwest",
            });
   }
}
