object phone;
object paper;
object eye;
object button;
reset(arg) {
   if(!arg)
      set_light(1);
}

init() {
   add_action("out","out");
   add_action("buy","buy");
   add_action("read","read");
   add_action("help","help");
}

out() {
   call_other(this_player(),"move_player",
      "out#players/asmithrune/rooms/trail13");
   return 1;
}

buy(string str) {
   if(str == "1" || str == "phone") {
      write("The old man looks at you and says that will be\n"+
         "100 gold pieces, son.  You hand him the money and\n"+
         "he hands you a Handy Dandy Phone.\n");
      phone=(clone_object("players/asmithrune/objects/phone"));
      move_object(phone,this_player());
      this_player()->add_money(-100);
      return 1;
   }
   if(str == "airplane" || str == "2") {
      write("The old man grubles and hands you a paper\n"+
         "airplane.  He says 'That'll be 25 gold pieces, sonny!', and\n"+
         "takes the money from you.\n");
      paper=(clone_object("/players/asmithrune/objects/paperii"));
      move_object(paper,this_player());
      this_player()->add_money(-25);
      return 1;
   }
   if(str == "eye" || str == "3") {
      write("The old man hops of his stool and says 'You are\n"+
         "a very lucky person.'  He then hands you a eye and\n"+
         "you hand him the gold.  He giggles greedily, and\n"+
         "hops back onto his stool.\n");
      eye=clone_object("players/asmithrune/objects/eye");
      move_object(eye,this_player());
      this_player()->add_money(-1500);
      return 1;
   }
   if(str == "button" || str == "4") {
      write("The old man mutters something under his breath\n"+
         "about players getting mud in his store, and hands you a button.\n"+
         "Before you notice, he takes your money and hops\n"+
         "back on his stool.\n");
      button=clone_object("/players/asmithrune/objects/button");
      move_object(button,this_player());
      this_player()->add_money(-50);
      return 1;
   }
   else {
      write("The old man says 'We ain't got that!\n");
      return 1;
   }
}

read(string str) {
   if(str == "sign") {
      write("Scrawled on a old piece of cow hide is this sign:\n"+
         "Stuffs for salle-\n"+
         "1>Handy Dandy Phone-100 gold pieces.\n"+
         "2>A Paper Airplane-25 gold pieces.\n"+
         "3>A Eye of Bazuble-1500 gold pieces.\n"+
         "4>A Button-50 gold pieces.\n"+
         "\n"+
         "For helps on the stuffs type help <number>\n");
      return 1;
   }
   else {
      write("Read what?\n");
      return 1;
   }
}
help(string str) {
   if(str == "1") {
      write("The Handy Dandy Phone is the latest advancement for\n"+
         "the gabby player.  Ever get tired of tell people with long\n"+
         "names?  Getting tired of just writing 'tell' all the time?\n"+
         "Well, this new thingie can help.  With it just type\n"+
         "contell <playername> and from then on just type re <message> to\n"+
         "tell them anything.  Simplicity at it's best!\n");
      return 1;
   }
   if(str == "2") {
      write("The Paper Airplane is the latest advancement in\n"+
         "long distance communications.  You can write anything\n"+
         "on the plane and then send it flying towards its destination.\n"+
         "A must buy for the busy player.\n");
      return 1;
   }
   if(str == "3") {
      write("Tired of always having to run back to the store after\n"+
         "a long killing spree?  Well, your troubles are over!  With this handy little item, you can go\n"+
         "from where you are to a special store made just for\n"+
         "the holders of the Eye, and then back again!\n"+
         "The store has very competative prices too.\n");
      return 1;
   }
   if(str == "4") {
      write("This is a item that is perfect for the player who is \n"+
         "concious about his or her apperance.  With one command,\n"+
         "this button can be customized to read whatever message you\n"+
         "want.  Niffty huh?\n");
      return 1;
   }
   else {
      write("Help on what?\n");
      return 1;
   }
}

long() {
   write("As you enter the hut, an old man rushes up to you\n"+
      "and days 'If you want to buy anything, read the sign stupid!'.\n"+
      "He then goes and sits on a small stool in the corner.\n"+
      "        There is one obvious exit; out\n");
}
short() {
   return "Hut 1";
}
