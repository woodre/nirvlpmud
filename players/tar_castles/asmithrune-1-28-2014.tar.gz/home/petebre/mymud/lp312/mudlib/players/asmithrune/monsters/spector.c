inherit "obj/monster";
int ra;
object gold;
object key;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("spector");
   set_alias("spector");
   set_short("A Spector");
   set_aggressive(1);
   set_long("This is a magical beast that is use to guard\n"+
      "great treasure.  It is a small sphere with three eye\n"+
      "stalks and it floats above the ground.\n");
   set_level(25);
   set_hp(800);
   set_al(0);
   set_wc(36);
   set_ac(22);
   set_chat_chance(30);
   load_chat("The Spector floats.\n");
   ra=random(100);
   if(ra > 25) {
      set_chance(50);
      set_spell_mess1("The Spector spears it's victim with a death beam!\n");
      set_spell_mess2("The Spector spears you with a death beam!\n");
      set_spell_dam(60);
   }
   if(ra > 25 && ra < 50) {
      set_chance(50);
      set_spell_mess1("The Spector's third eye glows brighty!\n");
      set_spell_mess2("The Spector hits you with a beam of hurt!\n");
      set_spell_dam(40);
   }
   if(ra >50 && ra <75) {
      set_chance(50);
      set_spell_mess1("The Spector casts a lightning bolt at it's tormentor!\n");
      set_spell_mess2("You are hit with a lightning bolt!\n");
      set_spell_dam(50);
   }
   if(ra >75 && ra <100) {
      set_chance(50);
      set_spell_mess1("The Spector's  second eye fires a fireball!\n");
      set_spell_mess2("You are hit bye a fireball!\n");
      set_spell_dam(30);
   }
   gold=clone_object("obj/money");
   gold->set_money(2000);
   move_object(gold, this_object());
   key=clone_object("/players/asmithrune/objects/keys/mekey");
   move_object(key,this_object());
}
