inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon"
#define Op "players/asmithrune/obj"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A dirt road running through the forest";
      long_desc=
"\n"+
"You trudge upon the road awhile, thinking of what you\n"+
"plan to do with your money.  Eventually, you come to another\n"+
"tree with a door in it's base.  The road continues on north\n"+
"and south.  Other than that, trees are on all sides of you.\n";
      items = ({
"road","A dirt road going north and south",
"door","A small wooden door set into the base of a large tree",
"trees","Green and tall, they stretch up to touch the sky",
            });
      dest_dir=({
RP+"tcity/road4","north",
RP+"tcity/road2","south",
RP+"tcity/btree2","west",
            });
   }
}
