inherit "obj/treasure";
object heal;
object sword;

reset(arg) {
   if(arg) return;
   set_short("A Large Wooden Chest");
   set_alias("chest");
   set_long("This is a large wooden chest wrapped in bands of metal.  It is locked.\n");
   set_weight(1000);
   set_value(0);
}
init() {
   add_action("open","open");
   add_action("wish","wish");
}

open(string str) {
   if(str == "chest") {
      if(!present("basilisk",(environment(this_player())))) {
         if(present("woodkey",this_player())) {
            write("As you unlock and open the chest, a huge, ugly monster\n"+
               "rises out of the chest in a cloud of pale smoke.  He says:\n"+
               "'I am a genie(you didn't think we were all handsome did you?).\n"+
               "You have freed me from centuries of imprisonment in this\n"+
               "bloody box.  For that I can give you a wish, but since I am\n"+
               "not a full genie, I only have three types of wishes I\n"+
               "can give you.  They are:\n"+
               "1-6000 gold coins\n"+
               "2-a Heal spell\n"+
               "3-a really nice weapon\n"+
               "\n"+
               "To choose, just type wish <number>.  Thank you again.\n");
            return 1;
         }
         else {
            write("You don't have the key.\n");
            return 1;
         }
      }
      else {
         write("The Basilisk stops you from opening the chest.\n");
         return 1;
      }
   }
   else {
      write("Open what?\n");
      return 1;
   }
}
wish(string str) {
   if(str == "1") {
      write("The genie hands you 6000 coins, and the chest disappears!\n");
      this_player()->add_money(6000);
      destruct(this_object());
      return 1;
   }
   if(str == "2") {
      write("The genie hands you a heal spell, and the chest disappears!\n");
      heal=(clone_object("obj/heal"));
      move_object(heal,this_player());
      destruct(this_object());
      return 1;
   }
   if(str == "3") {
      write("The genie looks at you and says' Hmm..I think you can handle this.'\n"+
         "He then reaches into himself and pulls out a sword.  He then hands\n"+
         "you the sword.  The the chest disappears!\n");
      sword=(clone_object("/players/asmithrune/weapons/ice"));
      move_object(sword,this_player());
      destruct(this_object());
      return 1;
   }
   else {
      write("What was your wish?\n");
      return 1;
   }
}
