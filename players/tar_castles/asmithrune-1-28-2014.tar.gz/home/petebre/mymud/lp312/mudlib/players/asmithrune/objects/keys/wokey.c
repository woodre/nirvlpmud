inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A Wooden Key");
   set_alias("woodkey");
   set_id("key");
   set_long("A large wooden key.\n");
   set_weight(0);
   set_value(10);
}
