inherit "obj/monster";
int i;
object gold;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("witch");
   set_alias("witch");
   set_short("Cassandra Witch");
   set_long("Cassandra Witch is the maker of the nasty liquid, Happy Brew.\n");
   set_level(10);
   set_al(150);
   set_hp(150);
   set_wc(14);
   set_ac(8);
   set_chat_chance(30);
   load_chat("Cassandra looks at you and says 'Would you like a drink, my pretty?'\n");
   set_a_chat_chance(30);
   load_a_chat("The Witch looks at you and cackles gleefully.\n");
}
