inherit "obj/weapon.c";

#define TPN this_player()->query_name()
#define TPL this_player()->query_level()
#define MN attacker->query_name()

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("isword");
   set_alias("sword");
   set_short("A Long Sword, radiating light");
   set_long("This is a rather special long sword.  It seems to\n"+
      "vibrate with an inner-life\n");
   set_class(11+random(4));
   set_weight(25);
   set_value(5000);
   set_read("It has one word written on it: 'feel'\n");
   set_hit_func(this_object());
}

weapon_hit(attacker) {
   int w;
   w = random(TPL);
   if(w > 9 && w<16) {
      say(TPN +" slices into and through a "+MN+"!\n");
      write("You slice through a "+MN+"!\n");
      return 3;
   }
   if(w>15) {
      say(TPN + " spins through the air and hacks a "+MN+"!!\n");
      write("You spin through the air and hack a "+MN+"!!\n");
      return 5;
   }
   return;
}

init() {
   ::init();
   add_action("feel_func","feel");
}

feel_func(string what) {
   if(!what || what != "sword") {
      write ("Feel what!?!\n");
      return 1;
   }
   else {
      write("\n"+
         "This is a rather intelligent sword.  It has many powers.\n");
      return 1;
   }
}
