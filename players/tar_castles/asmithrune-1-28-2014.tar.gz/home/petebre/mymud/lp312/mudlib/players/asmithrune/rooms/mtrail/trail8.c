inherit "room/room";
reset(arg) {
   if(!present("tangle")) {
      move_object(clone_object("/players/asmithrune/monsters/tangle"),this_object());
   }
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="As you walk down the path, you notice how beautiful\n"+
   "the flowers and trees are.  All except one.....\n";
   dest_dir=({"/players/asmithrune/rooms/trail9","north",
         "/players/asmithrune/rooms/trail7","south"});
}
