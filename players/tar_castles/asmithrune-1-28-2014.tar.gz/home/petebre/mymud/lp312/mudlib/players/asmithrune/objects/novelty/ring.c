inherit "obj/treasure";
object list;
int i;
int spousethere;

reset(arg) {
   if(arg) return;
   set_short("A wedding ring from Asmithrune(worn)");
   set_alias("ring");
   set_long("The ring is mad up of two bands of white gold\n"+
      "twisted about a center silver strand.\n");
   set_weight(0);
   set_value(0);
}
init() {
   add_action("goto_spouse","gspouse");
   add_action("spouse_tell","stell");
   add_action("slove","slove");
   add_action("I","I");
   add_action("skiss","skiss");
   add_action("ringhelp","ringhelp");
      list = users();
      for(i=0;i<sizeof(list);i++) {
         if(list[i]->query_real_name()=="asmithrune") {
            spousethere = 1;
          }
}
         if(spousethere == 1) {
            write("Your happy hubby is on the game!\n");
            return 1;
            }
         if(spousethere == 0) {
            write("sadly, your husband is no where to be found.\n");
            return 1;
          }
         }
drop() {
write("Now why would you want to do that?\n");
return 1;
}
get() {
write("You can't get it.\n");
return 1;
}
      extra_look() {
         write("She is married to Asmithrune.\n");
         }
      goto_spouse() {
         if(find_living("asmithrune")) {
            write("You are off to visit your husband.\n");
            move_object(this_player(),environment(find_living("asmithrune")));
            return 1;
            }
         else {
            write("Your hubby isn't on the game.\n");
            return 1;
            }
         }
      
      spouse_tell(string str) {
         if(find_living("asmithrune")) {
            write("You send a message to your husband.\n");
            tell_object(find_living("asmithrune"),"Your wife says: "+str+".\n");
            return 1;
            }
         else {
            write("Your husband isn't on the game.\n");
            return 1;
            }
         }
      I() {
         call_other("/players/asmithrune/objects/magicitems/invent","I");
         return 1;
         }
      slove() {
         if(find_living("asmithrune")) {
            write("You send your love to your husband.\n");
            write("And he returns it.\n");
            tell_object(find_living("asmithrune"),"Your wife sends you her love.\n");
            return 1;
            }
         else {
            write("Your husband isn't on the game.\n");
            return 1;
            }
            }
      ringhelp() {
         cat("/players/asmithrune/objects/ringhelp");
         return 1;
         }
      skiss() {
         if(find_living("asmithrune")) {
            write("You send your husband a kiss.\n");
            tell_object(find_living("asmithrune"),"Your wife sends you a kiss.\n");
            return 1;
            }
         else {
            write("Your husband isn't on the game.\n");
            return 1;
            }
            }
