#define NAME "Asmithrune"
int second;
#define DEST "room/forest1"
/*
* This is just the facade to a castle. If you want to enable the
* "enter" command, move the player to a hall or something (which
   * you have to design yourself).
* The predefined string DEST is where a player should come when he
* leaves the castle.
*
* This file is loaded automatically from "init_file". We have to move
* ourself to where we are supposed to be.
*/

id(str) { return str == "castle"; }

short() {
   return "A slight path leading through the bushes to the north.";
}
is_castle(){return 1;}

long() {
   write("A slight path leads through the bushes to the north.\n");
}

init() {
   add_action("north"); add_verb("north");
   call_out("count",1);
}

north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/trail");
   return 1;
}
count() {
   second ++;
}

reset(arg) {
   if (arg)
      return;
   move_object(this_object(), DEST);
}
query_second() {
   return second;
}
