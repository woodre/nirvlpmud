inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_alias("gem");
   set_short("A Rock Gem");
   set_long("This is a beautiful crystal.  It looks very valuable.\n");
   set_weight(0);
   set_value(1000);
}
