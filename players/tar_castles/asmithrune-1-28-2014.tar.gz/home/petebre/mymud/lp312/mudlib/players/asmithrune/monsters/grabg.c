inherit "obj/monster";
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("grass");
   set_alias("grass");
   set_short("A Patch of Grabbing Grass");
   set_long("This is a patch of carnivorious grass.\n");
   set_level(15);
   set_hp(400);
   set_wc(22);
   set_ac(13);
   set_aggressive(1);
   set_a_chat_chance(30);
   load_a_chat("The Grabbing Grass shivers in hunger!\n");
   set_chance(25);
   set_spell_mess1("The Grabbing Grass grabd it's opponent!\n");
   set_spell_mess2("You are grabed by the Grabbing Grass!\n");
   set_spell_dam(25);
}
