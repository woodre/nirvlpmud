inherit "room/room";
reset(arg) {
   if(!present("basilisk")) {
      move_object(clone_object("/players/asmithrune/monsters/bask"),this_object());
   }
   if(!present("chest")) {
      move_object(clone_object("players/asmithrune/objects/chests/chest"),this_object());
   }
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You have entered a small, squareish room.  There\n"+
   "are many human looking bones scattered across\n"+
   "the floor.  There is also a large chest sitting against\n"+
   "one wall.  However, there is also a large\n"+
   "Basilisk  standing beside it.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave28","north"});
}
