int wcl;
int acl;
int wei;
int valu;
reset(arg) {
   if(arg) return;
   set_light(1);
}
init() {
   add_action("east","east");
   add_action("seer","seer");
}
east() {
   call_other(this_player(), "move_player",
      "east#players/asmithrune/rooms/castle/keepgrd/keep10");
   return 1;
}
seer(object obj) {
   if(present(obj,this_player())) {
      this_player()->add_money(-100);
      write("The seer takes the "+capitalize(obj)+" and looks at it closely\n");
      wcl=obj->query_class();
      acl=query_armor_class(obj);
      wei=query_weight(obj);
      valu=query_value(obj);
      if(!wcl==0) {
         write("It is a weapon: weapon class="+wcl+"\n");
         return 1;
      }
   }
}
long() {
   write("You have come to the main door of the\n"+
      "keep.  The door is about 20 feet tall, and 10 feet\n"+
      "wide, made of pure lead.  It would seem impossible\n"+
      "to move it.  Next to the door is a sign saysing:\n"+
      "'Ring bell to open.'\n"+
      "     There are two obvious exits: north and south\n");
   return 1;
}
short() {
   return "Keep Door(n,s)";
}
