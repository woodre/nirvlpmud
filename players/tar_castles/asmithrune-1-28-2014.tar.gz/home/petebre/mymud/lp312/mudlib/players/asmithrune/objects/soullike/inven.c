inherit "obj/treasure";
int i;
int oblen,spacelen;
int wc,ac;
int weight;

reset(arg) {
   if(arg) return;
   set_short("An Inventory Display");
   set_alias("display");
   set_long("This is an Inventory Display Unit.  When\n"+
      "you type the command 'I', it gives you\n"+
      "a very informative inventory dispaly.\n");
   set_weight(1);
   set_value(5);
}
init() {
   add_action("item","item");
   add_action("weapon","weapon");
   add_action("armor","armor");
}

item() {
   object next;
   object ob;
   string name;
   int weight;
   int valu;
   ob = first_inventory(this_player());
   while(ob) {
      next = next_inventory(ob);
      name = ob->short();
      valu = ob->query_value();
      if(ob->short()) {
         wc=ob->weapon_class();
         ac=ob->armor_class();
         oblen = strlen(name);
         spacelen=40-oblen;
         if(!wc>0 && !ac>0) {
            write(name);
            for(i=0;i<spacelen;i++) {
               write(" ");
            }
            write(valu+"\t");
            what_weight(ob);
            write("\n");
         }
         }
      ob = next;
   }
   return 1;
}
what_weight(object obj) {
   weight=obj->query_weight();
   if(weight==0 || weight==1) {
      write("Low");
   }
   if(weight==2 || weight==3) {
      write("Medium");
   }
   if(weight==4 || weight==5) {
      write("Heavy");
   }
   if(weight==6 || weight==7) {
      write("Very Heavy");
   }
   if(weight>7) {
      write("Lead Ball");
   }
}
weapon() {
   object next,ob;
   int valu;
   string name;
   ob = first_inventory(this_player());
   while(ob) {
      next = next_inventory(this_player());
      valu=ob->query_value();
      if(ob->short()) {
         write("Short\n");
         wc=ob->weapon_class();
         if(wc>0) {
            write("wc\n");
            name=ob->short();
            oblen=strlen(name);
            spacelen=40-oblen;
            write(name);
            for(i=0;i<spacelen;i++) {
               write(" ");
            }
            write(valu+"\t");
            what_weight(ob);
            write("\n");
         }
         ob = next;
         }
      return 1;
   }
}
armor() {
   object next,ob;
   int valu;
   string name;
   ob=first_inventory(this_player());
   while(ob) {
      next = next_inventory(this_player());
      if(ob->short()) {
         valu = ob->query_value();
         ac=ob->armor_class();
write(ac+"\n");
         if(ac>0) {
            oblen=strlen(ob);
            spacelen=40-oblen;
            name=ob->short();
            write(name);
            for(i=0;i<spacelen;i++) {
               write(" ");
            }
            write(valu+"\t");
            what_weight(ob);
            write("\n");
         }
         ob = next;
         }
      return 1;
   }
}
