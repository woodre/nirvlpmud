reset(arg) {
   if(arg)
      set_light(0);
}
init() {
   add_action("west","west");
   add_action("east","east");
}
east() {
      call_other(this_player(),"move_player",
"east#players/asmithrune/rooms/cave/cave17");
      return 1;
   }
west() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/cave/cave15");
   return 1;
}
long() {
   write("You enter a room that, unlike all the others,\n"+
      "is made of stone blocks rather than natural cave rock.  There\n"+
      "is a opening to the east.\n"+
      "     There are two obvious exits: east and west.\n");
}
short() {
   return "A Cave";
}
