int i;
reset(arg) {
   if(arg)
      set_light(0);
   if(!present("mongrel")) {
      while(i<5) {
         i += 1;
         move_object(clone_object("/players/asmithrune/monsters/mongrel"),this_object());
      }
   }
}
init() {
   add_action("east","east");
   add_action("north","north");
}
east() {
   if(!present("mongrel")) {
      call_other(this_player(),"move_player",
         "east#players/asmithrune/rooms/cave/cave21");
      return 1;
   }
   else {
      write("The Mongrel Men stop you.\n");
      return 1;
   }
}
north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/cave/cave19");
   return 1;
}
long() {
   write("You continue to tromp through the lair of these\n"+
      "awful beasts, when you come upon another group.  This time, they are argueing over a\n"+
      "fair(?) mongrel wench.  The tunnel continues to the east.\n"+
      "      There are two obvious exits: east and north.\n");
}
short() {
   return "A Cave";
}
