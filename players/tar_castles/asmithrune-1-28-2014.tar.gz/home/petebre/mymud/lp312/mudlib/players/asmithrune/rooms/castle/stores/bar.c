object booze;
reset(arg) {
   if(arg) return;
   set_light(1);
}
init() {
   add_action("east","east");
   add_action("list","list");
   add_action("buy","buy");
}
east() {
   call_other(this_player(), "move_player",
      "east#players/asmithrune/rooms/castle/keepgrd/keep2");
   return 1;
}
list() {
   write("The EndCastle Bar has these drinks for sale:\n"+
      "\n"+
      "1>Happy Brew          200 Gold Pieces\n"+
      "2>Shot of J.D.        1000 Gold Pieces\n"+
      "3>Full Keg            2000 Gold Pieces\n"+
      "4>English Tea(Sober)  100 Gold Pieces\n"+
      "5>Bitter Tea(Sober)   275 Gold Pieces\n"+
      "\n"+
      "To purchase a drink, just type: buy <name>, or\n"+
      "buy <number>.\n");
   return 1;
}
buy(string str) {
   if(str == "brew" || str == "1") {
      if(this_player()->query_money()>200) {
         write("You purchase a bottle of Happy Brew.\n");
         say(this_player()->query_real_name()+" buys a Happy Brew.\n");
         this_player()->add_money(-200);
         booze=(clone_object("/players/asmithrune/objects/booze/happy"));
         move_object(booze,this_player());
         return 1;
      }
      else {
         write("You don't have enough money.\n");
         return 1;
      }
   }
   if(str == "shot" || str == "2") {
      if(this_player()->query_money()>1000){
         write("You buy a shot of J.D.\n");
         say(this_player()->query_real_name()+ "buys a shot of J.D.\n");
         this_player()->add_money(-1000);
         booze=(clone_object("/players/asmithrune/objects/booze/shot"));
         move_object(booze,this_player());
         return 1;
      }
      else {
         write("You don't have enough money.\n");
         return 1;
      }
   }
   if(str == "keg" || str == "3") {
      if(this_player()->query_money()>2000) {
         write("You buy a keg of beer.\n");
         say(this_player()->query_real_name()+" buys a keg of beer.\n");
         this_player()->add_money(-2000);
         booze=(clone_object("/players/asmithrune/objects/booze/keg"));
         move_object(booze,this_player());
         return 1;
      }
      else {
         write("You don't have enough money.\n");
         return 1;
      }
   }
   if(str == "english tea" || str =="4") {
      if(this_player()->query_money()>100) {
         write("You buy an English Tea.\n");
         say(this_player()->query_real_name()+" buys an English Tea\n");
         this_player()->add_money(-100);
         booze=(clone_object("/players/asmithrune/objects/booze/etea"));
         move_object(booze,this_player());
         return 1;
      }
      else {
         write("You don't have enough money.\n");
         return 1;
      }
   }
   if(str == "bitter tea" || str == "5") {
      if(this_player()->query_money()>275) {
         write("You buy a Bitter Tea.\n");
         say(this_player()->query_real_name()+" buys a Bitter Tea.\n");
         this_player()->add_money(-275);
         booze=(clone_object("/players/asmithrune/objects/booze/btea"));
         move_object(booze, this_player());
         return 1;
      }
      else {
         write("You don't have enough money.\n");
         return 1;
      }
   }
   else {
      write("What do you want?\n");
      return 1;
   }
}
long() {
   write("You have entered the EndCastle Bar.  There are\n"+
      "many patrons sitting and talking at various tables and stools.\n"+
      "As you take a seat, you notice a sign which reads:\n"+
      "'For a list of drinks, type 'list'.'\n"+
      "      There is one obvious exit: east.\n");
   return 1;
}
short() {
   return "EndCastle Bar";
}
