reset(arg) {
   if(!present("spectator")) {
      move_object(clone_object("/players/asmithrune/monsters/spectator"),this_object());
   }
   if(arg) return;
   set_light(0);
}
init() {
   add_action("south","south");
   add_action("north","north");
}
south() {
   if(!present("spectator")) {
      call_other(this_player(),"move_player",
         "south#players/asmithrune/rooms/cave/cave12");
      return 1;
   }
   else {
      write("The Spectator stops you.\n");
      return 1;
   }
}
north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/cave/cave10");
   return 1;
}
long() {
   write("You enter this room, and feel that something is different.\n"+
      "You can't put your finger on it until it comes floating towards you!\n"+
      "           There are two obvious exits: north and south.\n");
}
short() {
   return "A Cave";
}
