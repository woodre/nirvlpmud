inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_id("sign");
   set_alias("newsign");
   set_short("A Newsign(read newsign)");
   set_long("This is a sign.  People usually read them.\n");
   set_weight(1000);
   set_value(0);
}
init() {
   add_action("read","read");
}

read(string str) {
   if(str == "newsign") {
      write("There is now a Newbie area open to the west.\n"+
         "Please, if you are above level 5, please don't enter.\n"+
         "Try some of the other areas!\n");
      return 1;
   }
   else {
      write("Read what?\n");
      return 1;
   }
}
