inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A WHelp Object");
   set_alias("whelpobj");
   set_long("A Wizard Help object.  Type  whelp [what]  to use.\n");
   set_value(0);
}

init() {
   add_action("whelp","whelp");
}

whelp(string what) {
   int filesize;
   int numpaths;
   int counter;
   string *paths;
   
   paths = ({"/doc/efun/","/doc/lfun","/doc/Driver/doc/efun","/doc/Driver/doc/LPC/"});
   
   numpaths=0;
   filesize=0;
   
   numpaths=sizeof(paths);
   
   for(counter=0;counter<numpaths;counter++) {
      filesize = file_size(paths[counter]+what);
      if(filesize > 0) {
         write("'"+what+"' found in "+paths[counter]+"\n");
         cat(paths[counter]+what);
         return(1);
       }
   }
   write("'"+what+"' couldn't be found.\n");
   return(1);
}
