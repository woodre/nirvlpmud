inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You travel down the tunnel, avoiding the stray\n"+
   "bat or two that dive bombs you.  The tunnels here are not very\n"+
   "small, but you begin to feel closed in.  The tunnel continues\n"+
   "east.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave2","west",
         "/players/asmithrune/rooms/cave/cave24","east"});
}
