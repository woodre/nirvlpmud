inherit "obj/weapon";
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("lariat");
   set_short("A Lariat");
   set_alias("lariat");
   set_long("This is a stout rope with w leather handle on each end.\n"+
      "It is made for strangleing.\n");
   set_class(12);
   set_weight(2);
   set_value(100);
}
