inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="As you continue your jouney, you notice\n"+
   "the breathing is getting louder as you travel further south.\n"+
   "You also get the feeling you are being watched.  The tunnel\n"+
   "continues south.\n";
   dest_dir=({"players/asmithrune/rooms/cave/cave15","south",
         "players/asmithrune/rooms/cave/cave13","north"});
}
