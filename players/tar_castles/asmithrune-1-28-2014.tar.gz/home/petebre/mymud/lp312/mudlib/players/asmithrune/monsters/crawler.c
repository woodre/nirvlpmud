inherit "obj/monster";
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("crawler");
   set_alias("crawler");
   set_short("A Cave Crawler");
   
   set_long("This is a slimy looking creature about 3 foot long.\n"+
      "It crawls on all four legs and looks for things to eat...like you!\n");
   set_level(15);
   set_hp(225);
   set_al(-500);
   set_wc(20);
   set_ac(12);
   set_aggressive(1);
   set_a_chat_chance(30);
   load_a_chat("The Crawler crawls all over you, getting slime all over you!\n");
}
