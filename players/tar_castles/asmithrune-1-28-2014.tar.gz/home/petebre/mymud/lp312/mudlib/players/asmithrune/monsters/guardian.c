inherit "obj/monster";
reset(arg) {
   ::reset(arg);
   set_name("guardian");
   set_alias("guardian");
   set_short("A Stone Guardian");
   set_long("This is a golem-like creature, about 7 feet\n"+
      "tall.  He looks tall, mean, and stupid, which he is.\n");
   set_level(20);
   set_aggressive(1);
   set_hp(600);
   set_wc(30);
   set_ac(17);
   set_chat_chance(30);
   load_chat("The Guardian looks around the room slowly, and his eyes focus on you.\n");
   set_a_chat_chance(30);
   load_a_chat("The Guardian crushes you against a wall!\n");
   set_chance(25);
   set_spell_mess1("The Guardian grabs his attacker in a bear-hug!\n");
   set_spell_mess2("The Guardian grabs you in a bear-hug!!!\n");
   set_spell_dam(50);
}
