inherit "room/room";

reset(arg) {
   if(!present("margoyle")) {
      move_object(clone_object("/players/asmithrune/monsters/margoyle"),this_object());
   }
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You continue on your journey through the perilous cave,\n"+
   "when you walk into a room, just a room that looks like all the others.\n"+
   "Until the wall starts to move!\n";
   dest_dir=({"players/asmithrune/rooms/cave/cave8","north",
         "players/asmithrune/rooms/cave/cave6","west"});
}
