inherit "players/bern/room.c";
reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="Crossroads";
   long_desc="You are at a four way crossroad.  To the\n"+
   "north, the road continues onward.  To the east and west\n"+
   "small trails begin.  Or the field is back to\n"+
   "the south.\n";
   dest_dir=({"/players/asmithrune/rooms/castle/flux/fluxk.c","north",
         "/players/asmithrune/rooms/castle/flux/fluxa.c","south",
         "/players/asmithrune/rooms/castle/flux/fluxc.c","west",
         "/players/asmithrune/rooms/castle/flux/fluxg.c","east"});
}
