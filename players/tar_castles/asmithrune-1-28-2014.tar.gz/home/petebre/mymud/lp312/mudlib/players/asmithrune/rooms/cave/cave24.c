inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="Here the tunnel turns to the south.  You\n"+
   "think you hear something to the south, but can't be\n"+
   "sure what it is.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave25","south",
         "/players/asmithrune/rooms/cave/cave23","west"});
}
