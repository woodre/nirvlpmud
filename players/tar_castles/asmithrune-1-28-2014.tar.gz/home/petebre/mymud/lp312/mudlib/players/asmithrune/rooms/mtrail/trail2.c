inherit "room/room";

reset(arg) {
   if(!present("sign")) {
      move_object(clone_object("players/asmithrune/objects/sign"),this_object());
   }
   if(!present("newsign")) {
      move_object(clone_object("/players/asmithrune/objects/newsign"),this_object());
   }
   if(arg) return;
   set_light(1);
   short_desc="A trail";
   long_desc="The trail finally emerges into a respectable path.  It continues\n"+
   "north, or turns east.  But it looks as if a new trail has been forged to the west.\n";
   dest_dir=({"/players/asmithrune/rooms/trail11","north",
         "/players/asmithrune/rooms/trail3","east",
         "/players/asmithrune/rooms/newbie/new1","west",
         "/players/asmithrune/rooms/trail","south"});
}
