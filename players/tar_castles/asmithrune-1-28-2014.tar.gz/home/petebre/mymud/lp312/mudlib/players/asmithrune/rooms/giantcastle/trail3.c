inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon/"
#define Op "players/asmithrune/obj/"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A trail";
      long_desc=
"\n"+
      "The trail continues north and south.  As you sit and rest for a\n"+
      "moment, you notice a small hole in the ground here.  The grass\n"+
      "sways rythmicly in the wind to the east and west, while the castle\n"+
      "lies on the moutain's peak to the north.\n";
      items = ({
            "hole","This is a hole leading into the darkness.  It looks big enough\n"+
            "for you to enter, perhaps",
            "castle","It lies to the north.  You can see that it lies upon it's own\n"+
            "plateau, surrounded on all sides by high cliffs.  The trail continues\n"+
            "to it's entrance",
            "mountain","It looms high to the north",
            "trail","A trail made of packed rocks and dirt",
            });
      dest_dir=({
            RP+"giantcastle/trail4","north",
            RP+"giantcastle/trail2","south",
            });
   }
}
init() {
   ::init();
   add_action("enter_func","enter");
}

enter_func(string dest) {
   if(!dest || dest != "hole") {
      write("Enter what?!\n");
      return 1;
   }
   if(this_player()->query_level()>9) {
      write("You seem big enough to enter, and the dark doesn't scare you\n"+
         "_that_ much.\n");
      move_object(this_player(),"hole#/players/asmithrune/rooms/giantcastle/cave1");
      return 1;
   }
   else {
      write("You aren't big enough to enter, the dark scares you too much.\n");
      return 1;
   }
}
