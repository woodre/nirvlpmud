reset(arg) {
   if(arg) return;
   set_light(1);
   if(!present("witch",this_object())) {
      move_object(clone_object("/players/asmithrune/monsters/witch"),this_object());
   }
}
init() {
   add_action("east","east");
}
east() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/newbie/new5");
   return 1;
}

long() {
   write("You have finally found the source of all\n"+
      "the smoke.  Here is Cassndra Witch, maker of\n"+
      "Happy Brew, a nasty brew which makes the embeder\n"+
      "very happy and very drunk.  She is one nasty woman.\n"+
      "     There is one obvious exit: east.\n");
}
short() {
   return "Newbie Zone";
}
