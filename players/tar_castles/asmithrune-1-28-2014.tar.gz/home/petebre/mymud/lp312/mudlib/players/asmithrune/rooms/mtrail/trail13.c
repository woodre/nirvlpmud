reset(arg) {
   if(!arg)
      set_light(1);
}
init() {
   add_action("north","north");
   add_action("south","south");
   add_action("enter","enter");
}
north() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/trail14");
   return 1;
}
south() {
   call_other(this_player(),"move_player",
      "south#players/asmithrune/rooms/trail12");
   return 1;
}
enter() {
   call_other(this_player(),"move_player",
      "enter#players/asmithrune/rooms/hut/hut1");
   return 1;
}
long() {
   write("As you walk along the trail, you notice that the\n"+
      "forest is unusually quiet.  The bird and animal noises have stopped.\n"+
      "In fact, even the wind isn't going through the trees, even though you\n"+
      "are sure it was very breezy out when you left.  You emerge out\n"+
      "into a small clearing, where a hut sits off to one side.  Or,\n"+
      "the trail continues to the north.\n"+
      "       There are three obvious exits: north, south, and enter\n");
}
short() {
   return "A Trail";
}
