inherit "obj/monster";
object gem;
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("bowler");
   set_alias("bowler");
   set_short("A Bowler");
   set_long("This creature looks like and pretty much is a big rock.\n"+
      "It is big and likes to crush soft things....like you!\n");
   set_level(20);
   set_hp(500);
   set_ac(17);
   set_al(500);
   set_wc(30);
   set_a_chat_chance(35);
   load_a_chat("The Bowler rolls over you!\n");
   set_chance(35);
   set_spell_mess2("The Bowler crushes you!\n");
   set_spell_dam(30);
   gem=clone_object("players/asmithrune/objects/rockgem");
   move_object(gem,this_object());
}
