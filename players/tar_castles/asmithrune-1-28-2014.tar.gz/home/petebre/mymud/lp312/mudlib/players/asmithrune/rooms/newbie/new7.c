reset(arg) {
   int i;
   if(arg) return;
   set_light(1);
   if(!present("elf",this_object())) {
      while(i<4) {
         i = i + 1;
         move_object(clone_object("/players/asmithrune/monsters/elf"),this_object());
      }
   }
}
init() {
   add_action("north","north");
}
north() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/newbie/new5");
   return 1;
}

long() {
   write("You have entered a stronghold of normally\n"+
      "vicious Drow Elves.  But they don't seem to vicious\n"+
      "now.\n"+
      "     There is one obvious exit: north.\n");
}
short() {
   return "Newbie Zone";
}
