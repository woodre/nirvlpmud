inherit "obj/monster";
reset(arg) {
::reset(arg);
if(arg) return;
   set_name("basilisk");
   set_alias("basilisk");
   set_short("A Greater Basilisk");
   set_long("This is a fearsome monster, that looks like a\n"+
      "large lizard  with four legs and an upright fore body.\n");
   set_level(25);
   set_hp(750);
   set_ac(20);
   set_al(-200);
   set_wc(30);
   set_chat_chance(30);
   load_chat("The Basilisk looks at you menaceingly.\n");
   load_chat("The Basilisk  stomps toward you.\n");
   set_a_chat_chance(35);
   load_a_chat("The Basilisk charges you!\n");
   load_a_chat("The Basilisk breaths poison breath at you!\n");
   set_chance(45);
   set_spell_mess1("The Basilsk stares over the room!\n");
   set_spell_mess2("The Basilsk stares right at you!\n");
   set_spell_dam(50);
}
