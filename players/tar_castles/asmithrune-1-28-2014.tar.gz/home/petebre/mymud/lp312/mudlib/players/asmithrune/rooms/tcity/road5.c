#define RP "players/asmithrune/room/"

inherit "room/room";

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A dirt road going through a forest";
      long_desc=
      "\n"+
      "The sound of your feet crunching through the grass is the\n"+
      "only sound upon your ears.  The forest seems to have darkened\n"+
      "slightly.  You come upon yet another door in the base of a tree.\n"+
      "There is a something slightly different about this one, it is\n"+
      "a deep flat black in color.  The road continues as it has, but\n"+
      "you notice a bend in it to the north.  A path leads east into\n"+
      "the forest and the black door is to the west.\n";
      items=({
            "door","A wooden door set into a tree.  It is flat black in color",
            });
      dest_dir=({
            RP+"tcity/road6","north",
            RP+"tcity/road4","south",
            RP+"tcity/btree3","west",
            RP+"tcity/path5","east",
            });
   }
}
