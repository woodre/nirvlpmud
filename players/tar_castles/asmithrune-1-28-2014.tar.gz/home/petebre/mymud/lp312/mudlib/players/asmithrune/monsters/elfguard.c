object ob,ob2;

ob2 =clone_object("/obj/monster.c");
call_other(ob2,"set_name","guard");
call_other(ob2,"set_short","An Elven Guard");
call_other(ob2,"set_race","elf");
call_other(ob2,"set_long","This is one of the merchant's many guards.\n"+
   "He is dressed regally, in fine cloth and garb. He caries his\n"+
   "sword with deadly care.\n");
call_other(ob2,"set_level",8);
call_other(ob2,"set_al",200);
call_other(ob2,"set_aggressive",0);
call_other(ob2,"set_chat_chance",30);
call_other(ob2,"set_a_chat_chance",30);
call_other(ob2,"load_chat","The Elven Guard looks at you closely.\n");
call_other(ob2,"load_a_chat","The Guard steps back looks for an opening in "+attacker+"'s defense.\n");
call_other(ob2,"init_command","wield sword");
ob=clone_object("obj/weapon");
call_other(ob,"set_name","long sword");
call_other(ob,"set_alias","sword");
call_other(ob,"set_short","An Elvis Long Sword");
call_other(ob,"set_alt_name","elvis long sword");
call_other(ob,"set_long","This is a finely crafted steel long sword.\n"+
   "It feels exceptionally lite\n");
call_other(ob,"set_read","'Elvanilara'");
call_other(ob,"set_class",11);
call_other(ob,"set_weight",2);
call_other(ob,"set_value",500);
call_other(ob,"set_hit_fun",this_object());
move_object(ob,ob2);
