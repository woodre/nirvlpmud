inherit "obj/weapon";
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("stave");
   set_short("A Stave of Power");
   set_alias("stave");
   set_long("This stave is inscribed with mystical runes.\n");
   set_hit_func(this_object());
   set_class(18);
   set_weight(5);
   set_value(25000);
   call_other(this_object(),"set_save_flag",0);
}
weapon_hit(attacker) {
   if(random(60) < 5) {
      say("The runes on the Stave glow brightly and a hand reaches out and strikes!\n");
      write("The runes on the Stave glow brightly and a giant hand strikes!\n");
      return 10;
   }
}
