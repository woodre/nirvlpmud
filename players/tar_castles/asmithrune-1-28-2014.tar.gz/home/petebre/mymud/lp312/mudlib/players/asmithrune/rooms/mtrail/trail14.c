inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="As you continue on the trail, a stank stench floats\n"+
   "in on a cloud of smoke.  You wonder what is on the trail\n"+
   "ahead.  The trail continues north.\n";
   dest_dir=({"/players/asmithrune/rooms/trail15","north",
         "players/asmithrune/rooms/trail13","south"});
}
