inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="Here the tunnel continues to the east.  There isn't\n"+
   "much else interesting here.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave7","east",
         "/players/asmithrune/rooms/cave/cave5","west"});
}
