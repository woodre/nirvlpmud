inherit "obj/treasure";
reset(arg) {
   if(arg) return;
   set_id("gem");
   set_alias("redgem");
   set_short("A Red Gem");
   set_long("This is a red gem of exceptionable beauty.  It looks very valuable.");
   set_weight(1);
   set_value(875);
}
