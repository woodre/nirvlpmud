inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="As you walk upon the trail, you realize how beautiful the\n"+
   "forest is.  The birds are chirpping quietly and the forest animals peer\n"+
   "at you with the wonder of children.  Here the trail continues east, or\n"+
   "it turns north into a well managed and controled rock path.\n";
   dest_dir=({"/players/asmithrune/rooms/trail5","east",
         "/players/asmithrune/rooms/trail6","north",
         "/players/asmithrune/rooms/trail3","west"});
}
