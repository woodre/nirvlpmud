inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("secretary");
   set_alias("secretary");
   set_short("The King's secretary");
   set_long("This is the person(?) in charge of taking care of the\n"+
      "kingdoms affairs.  He is apparently human, except for his eyes\n"+
      "which seem to be feline in apperance.\n");
   set_level(10);
   set_hp(150);
   set_al(100);
   set_wc(18);
   set_ac(11);
   set_chat_chance(20);
   load_chat("The secretary scribbles something down.\n");
   load_chat("The secretary says 'The King wishes to see you.'\n");
   gold=clone_object("obj/money");
   gold->set_money(400);
   move_object(gold, this_object());
}
