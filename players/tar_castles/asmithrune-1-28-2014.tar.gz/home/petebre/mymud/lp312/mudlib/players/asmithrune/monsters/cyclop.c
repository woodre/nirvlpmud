inherit "obj/monster";
object gold;
object club;
reset(arg) {
   ::reset(arg);
   set_name("cyclopskin");
   set_alias("cyclopskin");
   set_short("A Cyclopskin");
   set_long("This is a relative of the Cyclops.  Although much smaller,\n"+
      "he is much faster and still very tough.\n");
   set_level(20);
   set_al(-300);
   set_hp(500);
   set_wc(30);
   set_ac(17);
   set_chat_chance(30);
   load_chat("The Cyclopskin stares at you.\n");
   set_a_chat_chance(30);
   load_a_chat("The Cyclopskin crushes you with his club!\n");
   gold=clone_object("obj/money");
   club=clone_object("players/asmithrune/weapons/club");
   gold->set_money(random(1500)+1000);
   move_object(gold,this_object());
   move_object(club,this_object());
}
