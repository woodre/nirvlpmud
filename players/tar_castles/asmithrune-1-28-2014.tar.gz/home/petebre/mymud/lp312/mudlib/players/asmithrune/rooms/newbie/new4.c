reset(arg) {
   int i;
   if(arg) return;
   set_light(1);
   if(!present("kobold",this_object())) {
      while(i <4) {
         i = i +1;
         move_object(clone_object("/players/asmithrune/monsters/kobold"),this_object());
      }
   }
}
init() {
   add_action("north","north");
}
north() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/newbie/new2");
   return 1;
}

long() {
   write("As you turn south on the path, a nasty\n"+
      "smell overcomes you.  You continue, and\n"+
      "eventually find it's source, a group of\n"+
      "foul smelling kobolds.\n"+
      "     There is one obvious exit: north.\n");
}
short() {
   return "Newbie Zone";
}
