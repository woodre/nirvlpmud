inherit "obj/weapon";
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("sword");
   set_short("A Ice Sword");
   set_alias("sword");
   set_long("This is a sword made of pure ice.\n");
   set_hit_func(this_object());
   set_class(18);
   set_weight(5);
   set_value(25000);
   call_other(this_object(),"set_save_flag",0);
}
weapon_hit(attacker) {
   if(random(15) < 2) {
      say("The ice sword casts a bolt of ice at it's target!\n");
      write("The Ice Sword glows and sends an ice bolt towards it's target!\n");
      return 8;
   }
}
