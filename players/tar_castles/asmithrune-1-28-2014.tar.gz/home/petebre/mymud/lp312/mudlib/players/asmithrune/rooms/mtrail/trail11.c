inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(1);
   short_desc="A Trail";
   long_desc="As you continue north along the trail, the bushes grow into\n"+
   "small trees.  The trail itself is made from dirt, rocks and leaves.  The\n"+
   "trail turns west here.\n";
   dest_dir=({"/players/asmithrune/rooms/trail12","west",
         "/players/asmithrune/rooms/trail2","south"});
}
