inherit "obj/monster";
object gold;
reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("troll");
   set_alias("troll");
   set_short("A Cave Troll");
   set_long("This is a man-shaped creature about 7 feet tall.\n"+
      "It's gray skin allows it to blend in well with the rocks.\n");
   set_level(15);
   set_hp(225);
   set_al(-3000);
   set_wc(20);
   set_ac(12);
   set_chat_chance(30);
   load_chat("The Troll looks at you and disappears into the rock.\n");
   load_chat("The Troll reappears.\n");
   set_a_chat_chance(30);
   load_a_chat("The troll bites you!\n");
   gold=clone_object("obj/money");
   gold->set_money(random(500)+500);
   move_object(gold,this_object());
}
