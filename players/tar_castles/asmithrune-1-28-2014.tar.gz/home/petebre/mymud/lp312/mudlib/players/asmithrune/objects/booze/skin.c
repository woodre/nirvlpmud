inherit "obj/treasure";
string name;
int lev;

reset(arg) {
   if(arg) return;
   set_short("A Drinking Skin");
   set_alias("skin");
   set_id("skin");
   set_long("This is a drinking skin.  Type 'drink' and you will take\n"+
      "a drink of it.  Depending on your level, a more alcholic drink will\n"+
      "come out.\n");
   set_weight(3);
   set_value(1000);
}
init() {
   add_action("drink","drink");
}
drink() {
   lev=this_player()->query_level();
   name =  this_player()->query_real_name();
   if(this_player()->query_alcohol()<(lev*4)) {
      if(lev>20) {
         write("You knock the skin back, and drink all of the fire breath that is\n"+
            "inside!\n");
         say(capitalize(name)+" knocks back the skin and drains the fire breath\n"+
            "that is inside.\n");
         this_player()->drink_alcohol(30);
         this_player()->add_money(-30000);
         this_player()->add_hit_points(250);
         this_player()->add_spell_points(250);
         return 1;
      }
   }
}
