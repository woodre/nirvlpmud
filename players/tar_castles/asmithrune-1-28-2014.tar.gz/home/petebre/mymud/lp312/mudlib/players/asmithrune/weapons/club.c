inherit "obj/weapon";
reset(arg) {
   if(arg) return;
   ::reset(arg);
   set_name("club");
   set_alias("club");
   set_short("A Large Wooden Club");
   set_long("This is a large wooden club wrapped with two metal bands.\n");
   set_class(14);
   set_weight(6);
   set_value(5000);
}
