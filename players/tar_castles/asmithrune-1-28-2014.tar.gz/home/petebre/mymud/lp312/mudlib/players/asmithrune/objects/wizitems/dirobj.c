inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_short("A DIR Object");
   set_alias("dirobj");
   set_long("A direction information object, type  dirs  to activate.\n");
   set_value(0);
}

init() {
   add_action("dirs","dirs");
}

dirs() {
   string *dest_dir;
   string directions;
   
if(sizeof(dest_dir) != 0)
{
   dest_dir=environment(this_player())->query_dest_dir();
   directions=implode(dest_dir,"\n");
   write(directions+"\n");
}
   return(1);
}
