inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="Here the tunnel turns to the east again.  You are beginning\n"+
   "to feel uneasy, as the cave is now completely dry and\n"+
   "there is hardly any noise other than your footsteps.\n";
   dest_dir=({"players/asmithrune/rooms/cave/cave10","east",
         "players/asmithrune/rooms/cave/cave8","south"});
}
