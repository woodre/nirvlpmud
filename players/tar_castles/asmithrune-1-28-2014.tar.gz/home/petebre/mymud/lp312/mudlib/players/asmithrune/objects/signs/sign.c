inherit "obj/treasure";

reset(arg) {
   if(arg) return;
   set_id("sign");
   set_short("A really BIG sign");
   set_long("This is a sign.  People usually read them.\n");
   set_weight(1000);
   set_value(0);
}
init() {
   add_action("read","read");
}

read(string str) {
   if(str == "sign") {
      write("This area is not for the light of heart and strenght.  I\n"+
         "would suggest at least a level 10 charcter, and then only\n"+
         "heavily armed and armored or in a party.  There are some\n"+
         "very tough creatures in here, but also alot of neat\n"+
         "stuff.  You may die in my realm so be prepared to\n"+
         "suffer the consequences.  All of it is not yet complete, but the caves\n"+
         "are open.  Go in and look around.  Most of all have fun and\n"+
         "happy Mudding!\n"+
         "Note: please use the bug <bug>, idea <idea>, and typo <typo> commands profusely\n"+
         "throughout my castle.  Also, if I am on, ask me and I will come running if\n"+
         "there is a problem.\n"+
         "\n"+
         "Asmithrune, Master of Darkness\n");
      return 1;
   }
}
