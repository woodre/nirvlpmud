inherit "obj/treasure";

string id, short, info, name, armor_type;
int value, weight, weapon_class, armor_class;
int weapon_wear, weapon_broke, weapon_hits, weapon_misses;
int armor_size, armor_worn, armor_light;

reset(arg) {
   if(arg) return;
   set_short("A Info Object");
   set_alias("infoobj");
   set_long("A info object, type info <object> for info.\n");
   set_weight(0);
   set_value(0);
}
init() {
   add_action("info","info");
}

info(string what) {
   object obj;
   if(obj=present(what)) {
      weight = obj->query_weight();
      value = obj->query_value();
      short = obj->short();
      id=obj->id();
      info=obj->query_info();
      armor_class = obj->armor_class();
      weapon_class = obj->weapon_class();
      write("Information on "+short+" ");
      write("\n");
      write("Weight : "+weight+"\t\tValue : "+value+"\n");
      if(info)
         write("Info : "+info+"\n");
      if(armor_class) {
         armor_type=obj->query_type();
         armor_worn=obj->is_worn();
         armor_size=obj->query_size();
         write("Armor Type : "+armor_type+"\t\tArmor Size : "+armor_size+"\n");
         write("Armor Class : "+armor_class+"\n");
         if(armor_worn) {
            write("It is being worn.\n");
         }
      }
      if(weapon_class) {
         weapon_wear=obj->query_wear();
         weapon_broke=obj->query_broke();
         weapon_hits = obj->query_hits();
         weapon_misses=obj->query_misses();
         write("Weapon Class : "+weapon_class+"\n");
         write("Weapon Wear : "+weapon_wear+"\t\t");
         if(weapon_broke) {
            write("BROKEN\n");
         } else {
            write("\n");
         }
         write("Weapon Misses :"+weapon_misses+"\t\tWeapon Hits :"+weapon_hits+"\n");
         
      }
      
      
      
   }
   else {
      write(""+what+"  couldn't be found on or near you.\n");
   }
   return(1);
}
