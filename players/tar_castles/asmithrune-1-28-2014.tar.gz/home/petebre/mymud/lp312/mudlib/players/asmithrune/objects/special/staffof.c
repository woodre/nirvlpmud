inherit "obj/treasure";
int owea;

reset(arg) {
   if(arg) return;
   set_short("The Staff of the Magi");
   set_alias("staff");
   set_long("This is the Staff of the Magi, it is a powerful\n"+
      "tool in the right hands.  Type 'staff help' for more info.\n");
   set_weight(2);
   set_value(10000);
}
init() {
   add_action("fixtele","fixtele");
   add_action("staff","staff");
   add_action("delve","delve");
   add_action("translate","translate");
}

fixtele(string str) {
   if(!str) {
      write("An image comes to you of a man, he says\n"+
         "'You must place an argument with the command,\n"+
         "master.  Type ''staff help'' for more infomation.'\n");
   }
   if(this_player()->query_spell_point()<61) {
      write("A short man materializes in front of you.  He says "+
         "'You don't have enough spell points for that spell, friend.'\n");
      return 1;
   }
   if(str == "church") {
      write("With a steady meter, you pronounce the words\n"+
         "that you were taught by the great mages.  You\n"+
         "feel yourself being drawn to the sanctuary of the church.\n");
      say(capitalize(this_player()->query_real_name())+" mutters some words and fades from\n"+
         "view.\n");
      this_player()->add_spell_point(-60);
      tell_room("room/church",capitalize(this_player()->query_real_name())+" materializes in the room!\n");
      move_object(this_player(),"room/church");
      command("look",this_player());
      return 1;
   }
   if(str == "shop") {
      write("You mutter the word the ancient Mages taught you, and\n"+
         "reality slowly fades from around you, to be replaced by....\n");
      say(capitalize(this_player()->query_real_name())+" mutters some"+
         "strange words and fades from view!\n");
      this_player()->add_spell_point(-60);
      tell_room("room/shop",capitalize(this_player()->query_real_name())+
         " materializes into the room!\n");
      move_object(this_player(),"room/shop");
      command("look",this_player());
      return 1;
   }
   if(str == "pub") {
      write("You mutter the words of power the ancient Mages taught\n"+
         "you, and reality fades from view, to be replaced by...\n");
      say(capitalize(this_player()->query_real_name())+" mutters some words and fades from\n"+
         "view!\n");
      tell_room("room/pub2",capitalize(this_player()->query_real_name())+" materializes in the"+
         " room!\n");
      this_player()->add_spell_point(-60);
      move_object(this_player(),"room/pub2");
      command("look",this_player());
      return 1;
   }
   else {
      write("You must choose one of these three places: shop,\n"+
         "pub, church.\n");
      return 1;
   }
}
staff(string str) {
   if(!str) {
      return 0;
   }
   if(str == "help") {
      cat("/players/asmithrune/info/staffof");
      return 1;
   }
}
delve(string str) {
   object obj;
   if(!str) {
      write("A quasit appears before you and says/n"+
         "'You must place and argument of an object in your inventory\n"+
         "with the spell delve, master.'\n"+
         "He then hurrys off to do another wizard's biding.\n");
      return 1;
   }
   obj = present(str, this_player());
   if (!obj) {
      obj=present(str, environment(this_player()));
      if(!obj) {
         write("A small demon runs up and hands you a note.\n"+
            "It reads:\n"+
            "    There is no "+capitalize(str)+" near you!\n");
         return 1;
       }
   }
   if(obj->weapon_class()>0) {
      write("This is a weapon.\n");
      owea = obj->weapon_class();
      if(owea>0 || owea<6) {
         write("It is not the best of weapons either.\n");
         return 1;
      }
      if(owea>5 || owea<11) {
         write("It is an ok weapon too.\n");
         return 1;
      }
      if(owea>10 || owea<16) {
         write("This is a pretty decent weapon.\n");
         return 1;
      }
      if(owea>15 || owea<21) {
         write("This is a great weapon!\n");
         return 1;
      }
      return 1;
   }
   if(obj->armour_class()>0) {
      write("This is an armour.\n");
      return 1;
   }
   else {
      write("This is an item.\n");
      return 1;
   }
}
