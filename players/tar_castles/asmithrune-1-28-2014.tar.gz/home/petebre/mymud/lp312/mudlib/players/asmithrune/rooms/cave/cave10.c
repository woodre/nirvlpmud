inherit "room/room";
reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You keep trudgeing down the long cave tunnels.  To tell\n"+
   "the truth, you are getting bored.  But, the feeling in your stomach that\n"+
   "great treasure lies ahead keeps you going on.  The tunnel continues\n"+
   "to the south.\n";
   dest_dir=({"players/asmithrune/rooms/cave/cave11","south",
         "players/asmithrune/rooms/cave/cave26","north",
         "players/asmithrune/rooms/cave/cave9","west"});
}
