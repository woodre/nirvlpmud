reset(arg) {
   int i;
   if(arg) return;
   set_light(1);
   if(!present("bugbear",this_object())) {
      while(i < 5) {
         i = i + 1;
         move_object(clone_object("/players/asmithrune/monsters/bugbear"),this_object());
      }
   }
}
init() {
   add_action("south","south");
}
south() {
   call_other(this_player(),"move_player",
      "east#players/asmithrune/rooms/newbie/new5");
   return 1;
}

long() {
   write("You have entered a large clearing in the forest.\n"+
      "Sitting here, smiling and drink some strange brew, are\n"+
      "a group of fun-loving bugbears.  The look at you and\n"+
      "laugh manically.\n"+
      "     There is one obvious exit: south.\n");
}
short() {
   return "Newbie Zone";
}
