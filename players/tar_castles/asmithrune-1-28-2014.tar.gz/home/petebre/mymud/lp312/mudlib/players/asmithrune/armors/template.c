inherit "obj/armor";

reset(arg) {
   ::reset(arg);
   set_name(" ");
   set_alias(" ");
   set_type(" ");
set_short(" ");
set_long(" ");
   set_ac( );
   set_weight( );
   set_value( );
}

