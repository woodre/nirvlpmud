inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon/"
#define Op "players/asmithrune/obj/"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "A trail";
      long_desc=
"\n"+
"You walk upon the trail a long while, stopping every so often\n"+
"to rest. Seemingly endless grasslands lay all around you.\n"+
"The trail begins to feel hard and rocky as you travel north.\n"+
"Although it may just be a trick of the sun and horizon, you\n"+
"would swear that the land just ended to the nrorth.  Farther\n"+
"to the north yet lies a great twisted mountain with a tall\n"+
"castle upon it's summit.\n";
      items = ({
"grasslands","The grasslands to your east and west are dotted with\n"+
"small trees.  You think you'd probably get lost in them",
            });
      dest_dir=({
RP+"giantcastle/trail2","north",
"/players/asmithrune/workroom","south",
            });
   }
}
