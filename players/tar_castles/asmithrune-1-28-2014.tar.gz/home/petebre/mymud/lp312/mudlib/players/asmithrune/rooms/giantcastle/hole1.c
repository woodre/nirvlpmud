inherit "room/room";

#define RP "players/asmithrune/room/"
#define MP "players/asmithrune/mon/"
#define Op "players/asmithrune/obj/"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "";
      long_desc=
      items = ({
            });
      dest_dir=({
            });
   }
}
