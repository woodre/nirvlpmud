inherit "obj/armor";
int i;

reset(arg) {
   ::reset(arg);
   set_name("aspell");
   set_alias("armor_spell");
   set_ac(1);
   set_weight(0);
   set_value(0);
}
init() {
   add_action("drop","drop");
   set_heart_beat(1);
}

hear_beat() {
   i++;
   if(i==10) {
      write("The field falls, and you feel less protected.\n");
      say("The glowing field around "+capitalize(this_player()->query_real_name())+" falls.\n");
      destruct(this_object());
   }
   return 1;
}
drop(string str) {
   if(str == "armor_spell") {
      write("Can't do that!\n");
      return 0;
   }
   return 1;
}
