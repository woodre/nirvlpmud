inherit "room/room";

#define RP "/players/asmithrune/rooms/"
#define MP "/players/asmithrune/monsters/"
#define OB "/players/asmithrune/objects/"

reset(arg) {
   if(!arg) {
      set_light(1);
      short_desc = "";
      long_desc=
      items = ({
            });
      dest_dir=({
            });
   }
}
