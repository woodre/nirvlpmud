inherit "obj/treasure";
string plastr;
reset(arg) {
   if(arg) return;
   set_alias("airplane");
   set_short("A Paper Airplane");
   set_long("This is a paper airplane.  There is something written\n"+
      "on it.  Why don't you read it. Then type fly <playername> to fly it to someone.\n"+
      "New commands: planewrite <message> - write your own message on the plane.\n"+
      "crumple airplane: get rid of the airplane.  Let's keep our MUD pretty!\n");
   set_weight(0);
   set_value(0);
}
init() {
   add_action("read","read");
   add_action("fly","fly");
   add_action("planewrite","planewrite");
   add_action("crumple","crumple");
}

read(string str) {
   if(str == "airplane") {
      write(plastr + "\n");
      return 1;
   }
   else {
      write("Read what?\n");
      return 1;
   }
}
fly(object plob) {
   if(find_living(plob)) {
      if(!in_editor(find_living(plob))) {
         write("You send the airplane on it's way.\n");
         tell_object(find_living(plob),"You see a paper airplane fly into the room.  You pick it up.\n");
         tell_object(find_living(plob),"When you pick it up, a note falls out that says,\n"+
            "This is from  "+capitalize((this_player()->query_real_name()))+".\n");
         move_object(this_object(),find_living(plob));
         return 1;
      }
      else {
         write("That person is busy.  Try again later.\n");
         return 1;
      }
   }
   else {
      write("That person isn't on the MUD right now.\n");
      return 1;
   }
}
planewrite(string str) {
   plastr = str;
   write("You have written '"+(plastr)+"' on the plane.\n");
   return 1;
}

crumple(object obj) {
   if(obj == "airplane") {
      write("You crumple the airplane into a little ball and\n"+
         "deposit it into the nearest trash can.\n");
      say(capitalize(this_player()->query_real_name())+" throws the airplane away.\n");
      destruct(this_object());
      return 1;
   }
   else {
      write("Crumple what?\n");
      return 1;
   }
}
