int i;
reset(arg) {
   if(arg)
      set_light(0);
   if(!present("mongrel")) {
      while(i<5) {
         i += 1;
         move_object(clone_object("/players/asmithrune/monsters/mongrel"),this_object());
      }
   }
}
init() {
   add_action("east","east");
   add_action("west","west");
}
east() {
   if(!present("mongrel")) {
      call_other(this_player(),"move_player",
         "east#players/asmithrune/rooms/cave/cave22");
      return 1;
   }
   else {
      write("The Mongrel Men stop you.\n");
      return 1;
   }
}
west() {
   call_other(this_player(),"move_player",
      "north#players/asmithrune/rooms/cave/cave20");
   return 1;
}
long() {
   write("You continue down the tunnels when, low and behold,\n"+
      "you run into some more of the beasts.  This time they\n"+
      "are doing something unspeakable to a young donkey.\n"+
      "The tunnel continues east.\n"+
      "There are two obvious exits: east and west.\n");
}
short() {
   return "A Cave";
}
