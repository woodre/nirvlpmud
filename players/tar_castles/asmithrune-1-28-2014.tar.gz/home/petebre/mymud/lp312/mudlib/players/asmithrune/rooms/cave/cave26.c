inherit "room/room";

reset(arg) {
   if(arg) return;
   set_light(0);
   short_desc="A Cave";
   long_desc="You turn north, and start walking down\n"+
   "the tunnel up ahead you think\n"+
   "you hear a terrible moaning.  The tunnel continues\n"+
   "north.\n";
   dest_dir=({"/players/asmithrune/rooms/cave/cave10","south",
         "/players/asmithrune/rooms/cave/cave27","north"});
}
