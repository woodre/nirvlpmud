inherit "/players/wrathchild/mon/gnomes";
inherit "room/room";
object gnome;
int x;

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A gnome village";
    long_desc =
        "   The dense forest opens up into a small clearing containing\n" +
        "a few small huts.  A dusty path leads all around the clearing\n" +
        "and to each of the huts, all of which seem closed except the\n" +
        "slighty larger one to the north.\n";
    dest_dir =
        ({
        "players/wrathchild/realm/river/rvr04", "west",
        "players/wrathchild/realm/river/hut", "enter",
        });
    items =	({
		"forest", "The forest is very dense here",
		"large hut", "The only hut that really stands out looks like an important\n" +
			"place to the local gnomes",
		"hut", "The only hut that really stands out looks like an important\n" +
			"place to the local gnomes",
		"huts", "The few small wooden huts here seem to be the homes of local gnomes",
		"gnomes", "The small creatures seem to have made a home of this clearing",
		"path", "The well-worn path shows that these gnomes are quite active",
		});
	for(x = 0;x < (2 + random(5));x++) {
		gnome = make_gnome();
		if (gnome) move_object(gnome, this_object());
	}
}

init() {
	add_action("west", "west");
	add_action("enter", "enter");
}

west() {
	call_other(this_player(),"move_player", "west#players/wrathchild/realm/river/rvr04");
	return 1;
}

enter() {
	if(present("warrior gnome")) {
		write("The warrior gnome steps in front of the entrance.\n");
		return 1;
	}
	call_other(this_player(),"move_player", "into the hut#players/wrathchild/realm/river/hut");
	return 1;
}
