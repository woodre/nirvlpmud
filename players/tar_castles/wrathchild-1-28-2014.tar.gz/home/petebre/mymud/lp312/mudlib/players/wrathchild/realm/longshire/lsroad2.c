/*      lsroad2.c by Wrathchild         */
inherit "room/room";

reset() {
    set_light(1);
    }

short() {
        return "Road to Longshire";
        }

long() {
        write("Road to Longshire...\n");
        call_other("/players/wrathchild/realm/longshire/longs.c", "get_weather");
        write("\nBefore you is a wide road leading to a walled town.  There are many\n" +
        "tracks and ruts in the road showing thats it's well traveled.\n" +
        "The only obvious exits are: north and south\n");
        }

init() {
        add_action("north", "north");
        add_action("south", "south");
        }

north() {
        call_other(this_player(),"move_player",
                                 "to the north doorway#/players/wrathchild/realm/longshire/lsroad3.c");
        return 1;
        }

south() {
        call_other(this_player(),"move_player",
                                 "to the south doorway#/players/wrathchild/realm/longshire/lsroad1.c");
        return 1;
}
