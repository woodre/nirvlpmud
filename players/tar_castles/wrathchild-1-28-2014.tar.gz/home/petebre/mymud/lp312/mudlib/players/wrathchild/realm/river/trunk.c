inherit "/players/wrathchild/mon/gnomes";
inherit "room/room";
object gnome;
int x;

reset(arg) {
    if (arg) return;
    set_light(0);
    short_desc = "A hollow tree";
    long_desc =
        "   Although this is a very large tree, there isn't much room inside.\n" +
        "Light from outside barely reaches inside the tree trunk.  The wood\n" +
        "surrounding you appears long dead and is marred with years of insect\n" +
        "activity.\n";
    dest_dir =
    	({
        "players/wrathchild/realm/river/rvr06", "out",
        });
    items =
    	({
		"light", "Light from outside barely lights the interior",
		"wood", "The wood of this ancient oak still holds stong, although it is long dead",
	   	"oak", "The wood of this ancient oak still holds stong, although it is long dead",
		});
	if(!present("gnome")) {
		gnome = make_sgnome();
		if (gnome) move_object(gnome, this_object());
	}
}