string weather;
int x,y;

get_weather() {

	weather=
		({
		"The sun is shining bright, and there isn't a cloud in the sky.  There\n" +
		"are many birds chirping and small animals scurrying about the area.",
		"It is cool and breezy with a slightly overcast sky. Trees are rustling\n" +
		"in the light wind, and small creatures skitter away from the road.",
		"A cold wind bites through you, and leaves and dust fly around.  All\n" +
		"living things seem to be seeking cover from an approaching storm.",
		"A chill, dreary atmosphere seems to engulf the area.  A few remaining\n" +
		"birds flutter by, and a few sprinkles of a cool rain hit the ground.",
		"An ominous black sky covers the area, dropping a heavy rain on the\n" +
		"area.  All signs of life appear to have found shelter from the storm."
		});

        if(y != 11) x = random(sizeof(weather));
        y=11;
        write(weather[x]);
        return;
        }
