inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A river bank";
    long_desc =
        "   This wooded area is the west bank of a narrow river.  This\n" +
        "side of the river is much more open than the east side, a trail\n" +
        "can be seen leading north and west from here.  Waist high brush\n" +
        "surrounds this area and the forest remains thinner than can be\n" +
        "seen on the other bank.\n";
    dest_dir =
        ({
		"players/wrathchild/realm/river/rvr10", "north",
		"players/wrathchild/realm/river/rvr07", "south",
        });
    items =	({
		"brush", "Swaying scrub brush covers the area",
		"river", "This small river flows north at a slow pace",
		"forest", "The forest is very dense here",
		"water", "The slow moving water looks fairly warm",
		"light", "The light to the east looks like the doorway that brought you here",
		"trail", "This trail extends north and south of here, but looks rarely used",
		});
}
