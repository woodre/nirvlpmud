inherit "room/room";

int i;

reset(arg) {
    if (arg) return;
 	set_light(0);
 	long_desc =
 		"   A very large rooms open up here and extends around you for a bit.\n" +
 		"The floor and ceiling are made of dirt with wood covering it in various\n" +
 		"places.  To the south is a hallway partially blocked with debris.\n";
 	dest_dir =
        ({
        "players/wrathchild/realm/base/base04", "north",
        "players/wrathchild/realm/base/base02", "south",
        "players/wrathchild/realm/base/base05", "east",
        "players/wrathchild/realm/base/base06", "west",
        });
    items =
    	({
		"light","This area is has light coming from all around, it appears to come\n" +
			"and go with each sprite",
		"walls","The wooden walls are bulging in towards you, and dirt trickles in" +
			"through the cracks",
		"dirt", "A light brown dirt is visible thoughout the walls and floor",
		"debris", "A pile of debris from the ceiling has almost blocked the hall",
		"wood" , "Some of the wood built to hold back the dirt is broken and splintered",
		"hall", "A small hallway opens to the south",
		"floor", "The floor beneath you is warped and uneven",
		"room", "This is a large open room, extending to the north, east and west",
		});
   	for (i = 0; i < random(6); i++)
       	move_object(clone_object("/players/wrathchild/mon/spr.c"), this_object());
}

short() {
	int l;
	string room;
	object inv;
	inv = all_inventory(this_object());
	for(i=0; i<sizeof(inv); i++) {
		if(inv[i]->query_race() == "sprite") l++;
	}
	if(l < 1) room = "dark";
	else if(l < 2) room = "dim";
	else if(l < 3) room = "bright";
	else if(l < 5) room = "very bright";
	else room = "radiant";
	return "A " + room + " room";
}