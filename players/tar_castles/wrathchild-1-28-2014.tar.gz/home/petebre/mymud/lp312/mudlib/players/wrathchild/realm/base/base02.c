inherit "room/room";
#include "/players/wrathchild/ansi.h"

int i;

reset(arg) {
    if (arg) return;
 	set_light(0);
 	long_desc =
 		"   Debris, made mostly of dirt and splintered wood, is partially\n" +
 		"blocking the hall to the north.  The walls on both sides appear to\n" +
 		"be on the verge of collapsing, and the floor has buckled like it\n" +
 		"was squeezed in a vise.  To the south a small room is visible.\n";
 	dest_dir =
        ({
        "players/wrathchild/realm/base/base03", "north",
        "players/wrathchild/realm/base/base01", "south",
        });
    items =
    	({
		"light","This area is has light coming from all around, it appears to come\n" +
			"and go with each sprite",
		"walls","The wooden walls are bulging in towards you, and dirt trickles in" +
			"through the cracks",
		"dirt", "A light brown dirt is visible thoughout the walls and floor",
		"debris", "A pile of debris from the ceiling has almost blocked the hall",
		"wood" , "Some of the wood built to hold back the dirt is broken and splintered",
		"hall", "A small hallway that leads north and south",
		"floor", "The floor beneath you is warped and uneven",
		"room", "To the south, you could enter a small room",
		"cracks", "The wooden walls have small cracks all over them",
		});
   	for (i = 0; i < random(6); i++)
       	move_object(clone_object("/players/wrathchild/mon/spr.c"), this_object());
}

short() {
	int l;
	string room;
	object inv;
	inv = all_inventory(this_object());
	for(i=0; i<sizeof(inv); i++) {
		if(inv[i]->query_race() == "sprite") l++;
	}
	if(l < 1) room = "dark";
	else if(l < 2) room = "dim";
	else if(l < 3) room = "bright";
	else if(l < 5) room = "very bright";
	else room = "radiant";
	return "A " + room + " hallway";
}