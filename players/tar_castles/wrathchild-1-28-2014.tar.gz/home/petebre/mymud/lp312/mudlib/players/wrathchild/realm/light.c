#include "/players/wrathchild/ansi.h"
inherit "room/room";

string *clr;
int i,j,k;

reset(arg) {
    if (arg) return;
    j = 3;
    k = 0;
    set_light(2);
    clr = ({"" + HIB + "blue","" + HIR + "red","" + HIG + "green","" + HIY + "yellow","" + HIW + "white"});
    long_desc =
		"A bright " + clr[random(5)] + NORM + " room...\n" +
		"This room is glowing with a very bright light that swirls before your\n" +
		"eyes.  It seems to come from everywhere making it hard to make out any\n" +
		"details.\n";
	dest_dir =
        ({
        "room/eastroad5", "out",
 		});
    items =
    	({
		"doorways","Each of the bright doorways has writing above it, giving an idea of where it leads",
    	"doorway", "Which doorway would you like to look at?",
    	"light", "This room glows with a bright light that appears to come from everywhere",
    	"writings", "Each doorway has a single word above it describing where it leads\n" +
    		"maybe you could ask the keeper about a specific one",
		});
}


short(str) {
	return "A bright " + clr[random(5)] + NORM +" light";
	}

init() {
	::init();
	i = random(8);
	if (!present("kinsey") && j > 0 && k == 0) {
		k = 1;
		call_out("get_kinsey", i);
	}
	if (!present("note"))
		move_object(clone_object("players/wrathchild/obj/w_note.c"), this_object());
}

get_kinsey() {
	object mob;
	k = 0;
	mob = find_living("k_keep");
	if(mob) {
		move_object(mob, this_object());
		say("Kinsey appears in a flash of light!\n");
		return 1;
	}
	move_object(clone_object("players/wrathchild/mon/kin.c"), this_object());
	say("Kinsey appears in a flash of light!\n");
	j--;
}