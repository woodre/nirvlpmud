inherit "/players/wrathchild/mon/gnomes";
inherit "room/room";
object gnome;
int x;

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A river bank";
    long_desc =
        "   This wooded area is the east bank of a narrow river. The water\n" +
        "flows north at a lazy pace and noises of the forest come from all\n" +
        "around.  The forest is getting thicker to the north and the noises\n" +
        "are getting louder.  There is a light to the south.\n";
    dest_dir =
        ({
        "players/wrathchild/realm/river/rvr04", "north",
        "players/wrathchild/realm/river/rvr02", "south",
        });
    items =	({
		"river", "This small river flows north at a slow pace",
		"water", "The slow moving water looks fairly warm",
	   	"forest", "The forest is quite thick here, and sounds of small animals are heard",
	   	"light", "The light to the south looks like the doorway that brought you here",
		});
    for(x = 0;x < (2 + random(5));x++) {
		gnome = make_gnome();
		if (gnome) move_object(gnome, this_object());
	}
}