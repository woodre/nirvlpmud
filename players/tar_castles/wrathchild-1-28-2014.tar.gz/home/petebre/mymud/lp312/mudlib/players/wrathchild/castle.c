#define NAME "Wrathchild"
#define DEST "room/eastroad5"
#include "/players/wrathchild/ansi.h"

/*
 * This is just the facade to a castle. If you want to enable the
 * "enter" command, move the player to a hall or something (which
 * you have to design yourself).
 * The predefined string DEST is where a player should come when he
 * leaves the castle.
 *
 * This file is loaded automatically from "init_file". We have to move
 * ourself to where we are supposed to be.
 */

id(str) { return str == "light" || "point of light"; }

short() {
	string *clr;
	clr = ({"" + HIB + "blue","" + HIR + "red","" + HIG + "green","" + HIY + "yellow","" + HIW + "white"});
	return "A point of " + clr[random(sizeof(clr))] + NORM + " light";
}

long() {
    write(short() + "...\n");
    write("The colors of the light swirl before your eyes.\n" +
    	  "It constantly flares and pulses with a life of\n" +
    	  "its own.  Thin tendrils of light appears to be\n" +
    	  "reaching out towards you.  Maybe you could touch\n" +
    	  "the light.\n");
}

init() {
    add_action("touch", "touch");
}

touch(str) {
    if (!str || str != "light") {
        write("Now, what were you trying to touch?\n");
        return 1;
    }
    else if(this_player()->query_level() < 21) {
		write("This realm will open soon....\n" +
			"   WC\n");
		return 1;
	}
    write("You are sucked into the light!\n");
    say(call_other(this_player(), "query_name") + " reaches towards the light...\n");
    call_other(this_player(), "move_player", "into the light#players/wrathchild/realm/light");
    return 1;
}

reset(arg) {
    if (arg)
	return;
    move_object(this_object(), DEST);
}
