/*      lsroad1.c by Wrathchild         */

inherit "room/room";

reset() {
    set_light(1);
    }

short() {
        return "Road to Longshire";
        }

long() {
        write("Road to Longshire...\n");
        call_other("/players/wrathchild/realm/longshire/longs.c", "get_weather");
        write("\nBefore you is a wide road leading to the north.  Sparse brush is on\n" +
        "either side of the road.  There are many tracks and ruts in the road\n" +
        "showing that it's well traveled.  A tall wall rises above the trees to\n" +
        "the north.\n" +
        "The only obvious exits are: north and light\n");
        }

init() {
        add_action("north", "north");
        add_action("light", "light");
        }

north() {
        call_other(this_player(),"move_player",
                                 "to the north doorway#/players/wrathchild/realm/longshire/lsroad2.c");
        return 1;
        }

light() {
        call_other(this_player(),"move_player",
                                 "into the 'Light' doorway#/players/wrathchild/realm/light.c");
        return 1;
}
