/*          by Wrathchild 3/15/02
 *			the portal to return to light.c
 *
 */

#define DEST "/players/wrathchild/realm/light"
#define TPN this_player()->query_name()
#include "/players/wrathchild/ansi.h"

id(str) {
	return str == "point" || str == "light" || str == "point of light";
}

short() {
	return "A point of " + WHT + "light" + NORM + "";
}

long() {
	write("\nThis is the point of light that can take you back to the realm,\n" +
		"perhaps you should touch it.\n");
}

init() {
	add_action("touch", "touch");
}


touch(arg) {
	if(!arg) {
		write("Touch what?\n");
		return 1;
	}
	if(arg == "point" || arg == "point of light" || arg == "light") {
		tell_object(this_player(), "You touch the point of light...and appear somewhere else.\n");
		call_other(this_player(), "move_player",
                                  "into the light#" + DEST);
		say("There's a surge of light and " + TPN + " appears.\n");
		return 1;
	}
}