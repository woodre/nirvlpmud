inherit "room/room";

status searched;
object gold;

reset(arg) {
    if (arg) return;
    set_light(1);
	searched = 0;
    short_desc = "An open cavern";
    long_desc =
        "   At what appears to be the end of the cave, a large cavern opens\n" +
        "up before you.  Although much dryer here, a dank, musty smells\n" +
        "invade your nostrils.  A small fire glows at the back corner of\n" +
        "the cave casting shadows on the walls. Many bones clutter the area,\n" +
        "making it look as if something has made this its lair.\n";
	dest_dir =
        ({
		"players/wrathchild/realm/river/hole02", "east",
        });
    items =	({
		"cavern", "This large open cavern looks made from centuries of water erosion",
		"fire", "Glowing softly, it casts an mysterious light on the cave",
		"shadows", "The fire causes shadows to dance around you",
		"bones", "There a many piles of bones around here, you migh try searching them",
		});
	if(!present("haxle"))
		move_object("/players/wrathchild/mon/haxle", this_object());
}

init() {
	::init();
	add_action("search", "search");
}

search(arg) {
	if(present("haxle")) {
		write("Haxle swipes at you as you!\n");
		return 1;
	}
	if(searched) {
		write("You search through the bones and find nothing.\n");
		return 1;
	}
	write("You find some treasure!\n");
	say(this_player()->query_name() + " finds some treasure!\n");
	move_object("/players/wrathchild/weap/ddag", this_object());
	gold = clone_object("/obj/money");
	gold->set_money(800 + random(500));
	move_object(gold, this_object());
	searched = 1;
	return 1;
}