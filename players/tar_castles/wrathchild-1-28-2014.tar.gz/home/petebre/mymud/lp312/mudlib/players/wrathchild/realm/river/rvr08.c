inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A rocky clearing";
    long_desc =
        "   The ground is quite barren this far west of the river.  Large\n" +
        "rocks rise up around you like a giant cage.  Not much can be\n" +
        "seen here except for back towards the river.  The wind whistles\n" +
        "as it whips around the rocks.\n";
    dest_dir =
        ({
		"players/wrathchild/realm/river/rvr07", "east",
        });
    items =	({
		"river", "Although you can't see it, the river can be heard towards the east",
		"ground", "Nothing seems to have grown here in a while",
		"rocks", "Large rocks block any further travel, except the way you came",
		});
}