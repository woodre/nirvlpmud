inherit "room/room";

int x,y;

reset(arg) {
    if (arg) return;
    x = random(7);
	y = random(7);
 	set_light(1);
	short_desc = "A river bank";
	long_desc =
		"   This wooded area is the east bank of a narrow river. The river\n" +
        "swirls around some rocks here and noises of the forest seem to\n" +
        "be getting louder to the north.  Tall grass sways in the breeze\n" +
        "on this side of the river.  There is a bright light to the south.\n";
 	dest_dir =
        ({
        "players/wrathchild/realm/river/rvr03", "north",
        "players/wrathchild/realm/river/rvr01", "south",
        });
    items =	({
		"river", "This small river flows north at a slow pace",
	   	"bank", "The bank is moss covered, with a few rocks and brush around it",
	   	"light", "The light to the south looks like the doorway that brought you here",
	   	"rocks", "A couple of fair sized rocks near the edge of the river,\n" +
	   		"something darts under one of them",
	   	"grass", "The waist-high grass rustles in the wind, or was that something moving...",
	   	"brush", "The waist-high grass rustles in the wind, or was that something moving...",
		});
}

init() {
	::init();
	add_action("search", "search");
}

search(arg) {
	if (!arg) {
		write("What would you like to search?\n");
		return 1;
	}
	if (arg == "rocks" || arg == "rock") {
		if(random(3) && !present("snake") && x > 0) {
			write("As you search the rocks a snake slithers out towards you!\n");
			say(this_player()->query_name() + " searches the rocks.\n");
			move_object(make_snake(), this_object());
			x--;
			return 1;
		}
	write("You don't find anything.\n");
	}
	else if (arg == "grass" || arg == "tall grass" || "brush") {
		if(random(3) && !present("badger") && y > 0) {
			write("You stick your hand into the grass and almost get bitten\n" +
				"as a badger lunges for you!\n");
			say(this_player()->query_name() + " searches the brush.\n");
			move_object(make_badger(), this_object());
			y--;
			return 1;
		}
	write("You don't find anything.\n");
	}
	else write("That doesn't appear very interesting.\n");
	return 1;
}

make_snake() {
	object snake, skin;
	snake = clone_object("obj/monster");
	call_other(snake, "set_name", "snake");
	call_other(snake, "set_level", 2);
	call_other(snake, "set_short", "A water snake");
	call_other(snake, "set_long", "This dark green water snake is about 3ft long.\n" +
								  "It's moving somewhat slow after emerging from\n" +
								  "the cool water, but still looks agitated at\n" +
								  "your presence.\n");
	call_other(snake, "set_wc", 3 + random(7));	/* avg 6 */
	call_other(snake, "set_ac", 3);
	skin = clone_object("/obj/treasure");
	skin->set_id("skin");
	skin->set_value(70 + random(40));
	skin->set_short("A snake skin");
	skin->set_long("A skin from a water snake.  It may be\n" +
		"worth something to someone.\n");
	skin->set_weight(1);
	skin->set_name("skin");
	move_object(skin,snake);
	return snake;
}

make_badger() {
	object badger, skin;
	badger = clone_object("obj/monster");
	call_other(badger, "set_name", "badger");
	call_other(badger, "set_level", 3);
	call_other(badger, "set_short", "A furry badger");
	call_other(badger, "set_long", "A medium size badger.  This furry grey creature\n" +
								   "isn't too big, but is known for its ferocity.\n");
	call_other(badger, "set_wc", 4 + random(7));	/* avg 7 */
	call_other(badger, "set_ac", 4);
	skin = clone_object("/obj/treasure");
	skin->set_value(70 + random(100));
	skin->set_id("hide");
	skin->set_short("A badger hide");
	skin->set_long("The hide of a small badger.  It may be\n" +
		"worth something to someone.\n");
	skin->set_weight(1);
	skin->set_name("hide");
	move_object(skin,badger);
	return badger;
}