inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A river bank";
    long_desc =
        "   This wooded area is the west bank of a narrow river.  There isn't\n" +
        "much here except for a few sparse trees and the surrounding brush.\n" +
        "The river curves around blocking any further travel north and a large\n" +
        "crevice opens to the west.\n";
    dest_dir =
        ({
		"players/wrathchild/realm/river/rvr09", "south",
        });
    items =	({
		"brush", "Swaying scrub brush covers the area",
		"river", "This small river flows north at a slow pace",
		"forest", "The forest is very dense here",
		"water", "The slow moving water looks fairly warm",
		"trail", "This trail extends south of here, but looks rarely used",
		"crevice", "The earth has split to reveal what looks like a cave,\n" +
			"You might be able to climb down into it",
		});
}

init() {
	::init();
	add_action("climb", "climb");
}

climb(str) {
	if(!str) {
		write("Climb where?\n");
		return 1;
	}
	if(str != "cave" && str != "into cave" && str != "crevice" && str != "into crevice" && str != "into the crevice" && str != "down" && str != "down crevice") {
		write("Where do you want to climb?\n");
		return 1;
	}
	call_other(this_player(),"move_player", "into the crevice#players/wrathchild/realm/river/hole01");
	return 1;

}

