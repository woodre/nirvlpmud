inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A river bank";
    long_desc =
        "   This wooded area is the west bank of a narrow river.  This\n" +
        "side of the river is much more open than the east side, a\n" +
        "trail can be seen leading north and west from here.  There\n" +
        "is a tree laying across the river here, and a light can be\n" +
        "seen across the river.\n";
    dest_dir =
        ({
		"players/wrathchild/realm/river/rvr09", "north",
		"players/wrathchild/realm/river/rvr08", "west",
        });
    items =
    	({
		"river", "This small river flows north at a slow pace",
		"forest", "The forest is very dense here",
		"water", "The slow moving water looks fairly warm",
		"light", "The light to the east looks like the doorway that brought you here",
		"trail", "This trail extends north and west of here, but looks rarely used",
		"tree", "A large tree has fallen across the river, it looks big enough to cross",
		});
}

init() {
	::init();
	add_action("cross", "cross");
}

cross(arg) {
	if(arg != "tree" && arg != "log" && arg != "river") {
		write("What are you trying to cross?\n");
		return 1;
	}
	call_other(this_player(),"move_player", "across the river#players/wrathchild/realm/river/rvr01");
	return 1;
}
