#include "/players/wrathchild/ansi.h"
inherit "obj/weapon.c";
#define TPN environment(this_object())->query_name()
#define ATT environment(this_object())->query_attack()->query_name()

reset(arg){
  ::reset(arg);
  if (arg) return;
set_name("dagger");
set_alias("dark dagger");
set_short("Dagger of " + BLK + "Haxle" + NORM +"");
set_long("At almost 9 inches long, this daggers blade is the blackest metal\n" +
	"and razor sharp.  Just holding it you can feel the dagger radiate\n" +
	"some of its previous owners darkness.\n");
set_type("dagger");
set_class(13);
set_weight(3);
set_value(800);
set_hit_func(this_object());
}

weapon_hit(attacker){
	int rnd;
	rnd = random(50);

	if(rnd > 45) {
		write("The dagger " + BLK + "sucks" + NORM + " in the light as it drinks from " + ATT + ".\n");
		say("" + TPN + "'s dagger " + "sucks" + NORM + " in the light as it drinks from " + ATT + ".\n");
		environment()->add_hit_point(5);
		return 5;
	}
	if(rnd > 35) {
		write("Your dagger seems to quiver with the pain of its foe!\n");
		say("The dark dagger quivers in " + TPN + "'s hand!\n");
		return 3;
	}
	if(rnd > 30) {
		write("\nYour dagger " + RED + "S\n" +
			  "             C\n" +
			  "              R\n" +
			  "               E\n" +
			  "                A\n" +
			  "                 M\n" +
			  "                  S" + NORM + "  as it causes pain!\n");
		say("\nThe dark dagger " + RED + "S\n" +
			"                 C\n" +
			"                  R\n" +
			"                   E\n" +
			"                    A\n" +
			"                     M\n" +
			"                      S" + NORM + "  as it causes pain!\n");

		return 2;
	}
	if(rnd > 26) {
		write("\nThe dark dagger feeds on you!\n\n");
		say("" + TPN + " winces in pain!\n");
		environment(this_object())->add_hit_points(-(4 + random(3)));
		return 0;
	}
}