inherit "room/room";
#include "/players/wrathchild/ansi.h"

int i;

reset(arg) {
    if (arg) return;
 	set_light(0);
 	long_desc =
 		"   This room looks like part of a dusty basement with walls made\n" +
 		"from old cracked wood.  The thin layer of dust covering the room\n" +
 		"shows that it is rarely traveled.  The light surrounding you seems\n" +
 		"to come from the sprites living down here.  The light fluctuates\n" +
 		"as they enter and leave the room.\n" +
		"\nThere is a " + BOLD + "ladder " + NORM + "going up here.\n\n";
 	dest_dir =
        ({
        "players/wrathchild/realm/base/base02", "north",
        "players/wrathchild/realm/base/base02", "south",
        "players/wrathchild/realm/base/base02", "east",
        });
    items =
    	({
		"light","This area is has light coming from all around, it appears to come\n" +
			"and go with each sprite",
		"walls","The wood walls look rotten in a few places and are pitted with holes",
		"ladder", "This wooden ladder is leading up into a hole in the ceiling",
		});
   	for (i = 0; i < random(7); i++)
       	move_object(clone_object("/players/wrathchild/mon/spr.c"), this_object());
}

short() {
	int l;
	string room;
	object inv;
	inv = all_inventory(this_object());
	for(i=0; i<sizeof(inv); i++) {
		if(inv[i]->query_race() == "sprite") l++;
	}
	if(l < 1) room = "dark";
	else if(l < 2) room = "dim";
	else if(l < 3) room = "bright";
	else if(l < 5) room = "very bright";
	else room = "radiant";
	return "A " + room + " basement";
}

init() {
	::init();
	add_action("up","climb");
	add_action("up", "up");
}

up() {
	call_other(this_player(),"move_player", "up the ladder#/players/wrathchild/realm/light");
	return 1;
}