/*      a nifty little weapon that will stop an attacker from
        getting an attack about 1/2 the time...
 */
inherit "obj/weapon";

int charge;
string band;

reset(arg)
{
  if (arg) return;
  charge=0;
  band="off";
  set_class(19);
  set_value(3500);
  set_weight(3);
  set_name("sword of speed");
  set_alias("sword");
  set_short("Sword of speed");
  set_alt_name("sword");
  set_heart_beat(1);
}

long()
{
 write("This is the Sword of Speed.\n");
 write("There is an inlaid metal band you could twist.\n");
 write("And a warning engraved. \n");
 write("   'More than 200 seconds of time distortion effect is dangerous'.\n");
 if (band=="on")
 {
  write("   'Control band is in the 'ON' position'.\n");
  write("   'Time distortion total is at "+charge+" seconds and increasing.'\n");
 }
 else
 {
  band="off"; /* just in case */
  write("   'Control band is in the 'OFF' position'.\n");
  write("   'Time distortion total is stable at "+charge+" seconds'.\n");
 }
}

init()
{
 ::init();
 add_action("twist", "twist");
}

twist(str) {
    if (str!="sabre"&& str!="band") return 0;
    if (environment() != this_player()) {
	write("You must be holding the sword first!\n");
	return 1;
    }
    if (band=="off") {
	write("You have turned on the time distortion effect.\n");
	say(this_player()->query_name()+" turns on the time distortion effect.\n");
	band="on";
	return 1;
    } else {
	write("You have turned off the time distortion effect.\n");
	say(this_player()->query_name()+" turns off the time distortion effect.\n");
	band="off";
	return 1;
    }
}

hit(attacker)
{
  object env,ATT;

  if(!(env=environment(wielded_by)))
    return 1;

  if (band=="off") return 1;
  if (charge>200) {
      if (random(3)) return 0;
      write("*Time Dilates*");
      return "miss";
  }
  if (random(3)) return 5;   /* a good hit but no bonus */
  write ("*Time warps*");    /* here is the big bonus   */
  say (capitalize(this_player()->query_name()) + " moves like a blur of mayhem and death.\n");
  call_out("warp",1,attacker);
  return 15;
}
warp(a) {
    if(!a) return;
    if(living(a)) a->stop_fight();
}

query_value() { if (charge<200) return (1000+200-charge);  return 1000; }

heart_beat()
{
  object env,room;

  if(band == "on") {
      charge += 2;
      return;
  }
  charge -= 2;
  if(charge < 0) charge = 0;
}
