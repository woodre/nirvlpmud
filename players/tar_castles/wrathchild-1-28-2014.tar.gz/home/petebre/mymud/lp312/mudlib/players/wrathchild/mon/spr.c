/*              little colorful sprites...by Wrathchild
 *                      quite random
 *				wander function taken from Maledicta's civilian.c
 */

inherit "obj/monster";
#include "/players/wrathchild/ansi.h"

int wander,wander_time;
object wings;

reset(arg) {
	string *x,*y,*typ;
	int i,j;
	::reset(arg);
	set_light(1);
	x=({"clear","white","yellow","green","grey","pink","orange","light blue",
			"silver","gold","tan","copper","bronze","maroon","light red",
			"dark blue","light brown","brown","dark red","black"});
	typ=({"tiny","small","mid-size","medium","big","large",
			"massive","monsterous","huge","gargantuan"});
	i=random(sizeof(x));
	j=i/2;
	if(!arg) {
		wings=clone_object("/obj/treasure");
		wings->set_name(x[i] + " wings");
		wings->set_short("A pair of " + x[i] + " wings");
		wings->set_long("A set of " + typ[j] + " " + x[i] + " sprite wings.\n" +
				"Perhaps they are valuble.\n");
		wings->set_value((i + 1) * ((1 + (i/3) + ((28 + random(4)) * random(i - 10)) + (10 * ((i/4) + 3)))));
		wings->set_weight((i+1)/6);
		wings->set_id("wings");
		wings->set_alias(x[i] + " wings");
		set_name(x[i] + " sprite");
		set_level(i + 1);
		set_race("sprite");
		set_hp((20 + random(10)) * (i + 1));	/* avg 24.5 * lvl */
		set_al(500 - (random(50) * i));
		set_dead_ob(this_object());
		set_wander(0, 20);
		set_heart_beat(2);
		set_aggressive(0);
		set_short("A "+ x[i] +" sprite");
		set_alias("sprite");
		set_long("This " + typ[j] + " sprite appears to be flying around aimlessly.\n" +
				"It has thin delicate features, but much else is hard to\n" +
				"discern because of the bright light radiating from it.\n" +
				"A " + x[i] + " light is surrounding this one.\n");
		set_wc(random(6) + (i + (i/3) + 1)); /* avg (lvl * 1.25) + 2.5 */
		set_ac((random(i/2)) + (i/2) + 3);
		set_chat_chance(2);
		load_chat("The " + x[i] + " sprite's wings hum.\n");
		load_chat("The " + x[i] + " sprite giggles at you.\n");
		load_chat("A wicked sneer crosses the face of the " + x[i] + " sprite.\n");
		set_chance(18);
		set_spell_dam(random(i));
		set_spell_mess1("The sprite hurls a ball of " + x[i] + " light!\n");
		set_spell_mess2("\nThe sprite hurls a ball of " + BOLD + x[i] + NORM + " light at you!\n");
	}
}

void set_wander(int chance, int time) {
	wander = time;
	set_heart_beat(1);
}

heart_beat(){
	::heart_beat();
	if(wander && !query_attack()) {
		if(wander_time++ > wander && !random(4)) {
		random_move();
		}
	}
}

monster_died() {
	say("\nThe sprites lifeless body crumples to the ground.\n");
	move_object(wings,this_object());
	/*
	if(present("players/wrathchild/realm/light","kinsey")
	*/
	tell_room("players/wrathchild/realm/light", "Kinsey says:  Ahh, " +
		this_player()->query_name() + " killed a " + this_object()->query_name() + ".\n");
}