inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A musty cave";
    long_desc =
        "   This area of the cave if very damp and smells of decay.  Dark\n" +
        "mud covers the floor and small pools of water have collected here\n" +
        "and there.  The walls glisten with moisture dripping from above,\n" +
        "and there are a few visible hand holds.\n";
dest_dir =
        ({
		"players/wrathchild/realm/river/hole02", "north",
		"players/wrathchild/realm/river/hole04", "west",
        "players/wrathchild/realm/river/rvr10", "climb",
        });
    items =	({
		"mud", "There are only a few vague footprints in the dark mud",
		"floor", "There are only a few vague footprints in the dark mud",
		"footprints", "Many prints criss-cross the area, it hard to make out any in particular",
		"pools", "Small collections of water draining from above",
		"water", "Small collections of water draining from above",
		"walls", "Made of solid rock, the walls look very slick",
		"hand holds", "Hand holds that might allow you to climb out",
		});
}

