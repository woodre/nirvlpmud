inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A musty cave";
    long_desc =
        "   The once muddy floor is spiderwebed with deep cracks from drying\n" +
        "out, and firms a bit more as it twists deeper into the cave.  The\n" +
        "walls are a pale chisled rock, with some deep gouges visible on the\n" +
        "north wall. Bones are strewn about this entire part of the cave.\n";
	dest_dir =
        ({
		"players/wrathchild/realm/river/hole01", "south",
		"players/wrathchild/realm/river/hole03", "west",
        });
    items =	({
		"floor", "Large footprints crisscross the area, most of which appear west of you",
		"footprints", "It appears that something large has made this area its home",
		"wall", "Along the north wall there are deep gouges",
		"gouges", "Some kind of sharp tool has etched marks deep into the wall",
		"bones", "Bones of all sizes litter the area, many of which appear to be gnome sized",
		"walls", "Made of solid rock, the walls look like they're made of limestone",
		});
}

