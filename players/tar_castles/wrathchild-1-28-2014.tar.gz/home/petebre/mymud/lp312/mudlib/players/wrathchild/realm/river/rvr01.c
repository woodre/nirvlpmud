#include "/players/wrathchild/ansi.h"
inherit "room/room";
object doorway;

reset(arg) {
    if (arg) return;
 	set_light(1);
	short_desc = "A river bank";
	long_desc =
	    "   This wooded area is the east bank of a narrow river. The water\n" +
        "flows north at a lazy pace and noises of the forest come from all\n" +
        "around. A large tree has fallen across the river here.\n";
 	dest_dir =
        ({
        "players/wrathchild/realm/river/rvr02", "north",
        "players/wrathchild/realm/river/rvr06", "south",
        });
    items = ({
		"tree","A large oak tree has fallen across the river here, perhaps you could 'cross' it",
	    "river", "This small river flows north at a slow pace",
	    "bank", "The bank is moss covered, with a few rocks and brush around it",
	});
	if(!doorway) {
		move_object(clone_object("players/wrathchild/realm/doorway.c"), this_object());
	}
}

init() {
	::init();
	add_action("cross", "cross");
    add_action("enter", "enter");
}


enter(arg) {
	if(arg != "doorway" && arg != "light") {
		write("Are you trying to enter the doorway?\n");
		return 1;
	}
	call_other(this_player(),"move_player","portal#/players/wrathchild/realm/light");
	return 1;
}

cross(arg) {
	if(arg != "tree" && arg != "log" && arg != "river") {
		write("What are you trying to cross?\n");
		return 1;
	}
	call_other(this_player(),"move_player", "across the river#players/wrathchild/realm/river/rvr07");
	return 1;
}
