/*              the demon summoned by the WC creature
 *                         by Wrathchild
 *
 */

inherit "obj/monster";

reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("minion");
   set_level(5);
   set_hp(random(50) + 125);
   set_al(-100);
   set_race("minion");
   set_wc(6);
   set_ac(5);
   set_aggressive(1);
   set_alt_name("minion");
   set_alias("minion");
   set_short("a small minion");
   set_long("This little minion was summoned from another plane.\n");

   }

