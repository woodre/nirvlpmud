/*					by Wrathchild 2/10/02
 *
 *		if attacked will randomly push the attacker out of the
 *		room.  Players can also 'ask' it about things in the
 *		area.  It is the only way to get to the areas of my realm,
 *		see the 'send' function.
 *
 *		Lowered wc,ac and hps because of heartbeat function; 30%
 *		chance of pushing attacker out of the room, and 15% chance
 *		of a random(15) heal per heartbeat
 *
 */

inherit "obj/monster";
#include "/players/wrathchild/ansi.h"
#define TPN this_player()->query_name()

object from;
string who;
int wander,wander_time;


reset(arg) {
	::reset(arg);
	if(arg) return;
	set_name("Kinsey");
	set_level(23);
	set_hp(random(200) + 600);  /* avg 700 */
	set_al(600);
	set_race("human");
	set_wc(random(10) + 32);  /* avg 36.5 */
	set_ac(random(4) + 17);  /* avg 18.5 */
	set_dead_ob(this_object());
	set_aggressive(0);
	set_alt_name("kinsey");
	set_alias("k_keep");
	set_short("Kinsey, Keeper of the Light");
	set_long("Kinsey is a fair sized human, he doesn't seem to have any\n"+
        "extra-ordinary features.  He does have an inviting smile, and\n"+
        "is known to give information about this things in this realm, \n"+
        "just 'ask' him.  He has also been known to have a 'list' of\n" +
        "services.\n");
	set_chat_chance(3);
	load_chat("Kinsey says: Would you like me to send you somewhere?\n");
	load_chat("Kinsey rubs his hands together, and they pulse a deep red.\n");
	load_chat("Kinsey says: Would you like ask about something in this realm?\n");
	set_chance(15);
	set_spell_mess1("Kinsey gestures towards his opponent.\n");
	set_spell_mess2("You are lifted above the ground by an unseen force...\n" +
		"Then slammed to the earth!\n");
	set_spell_dam(random(20)+10);  /* avg 19.5 */
}

init() {
	add_action("list","list");
	add_action("ask","ask");
	add_action("send","send");
	add_action("comment","comment");
	add_action("sell", "sell");
/*
	add_action("buy","buy");
	add_action("info", "info");
*/
}

list(arg) {
	if(!arg) {
		kinsey_say("I've been working on a new spell to transport people\n" +
			"	to different areas, would you like to 'list areas'?  If you find\n" +
			"	anything in the areas I might be interested in buying, bring them\n" +
			"	here and try 'sell <item>'.  Also, if you'd like to comment or\n" +
			"	suggest anything about this area use 'comment <message>'.");
		return 1;
	}
	if(arg == "areas") {
		kinsey_say("If you would like to be sent to a certain area just\n" +
			"	use 'send <area>'.  When you want to return touch the point of\n" +
			"	light to return.  Currently the possible areas are: river.");
		return 1;
	}
	write("Kinsey says:  I don't have a list of that.\n");
	return 1;
}

send(arg) {
	string msg1,msg2,where,whr;
	if (!arg || sscanf(arg, "%s", where) != 1) {
		write("Kinsey says: Uhh, where would you like me to send you?\n");
		return 1;
	}
	switch(where) {
		case "river":
			msg1 = "Kinsey mumbles some words and the light flares around you.  When your\n" +
				"vision clears you can see you are near a small river.\n";
			msg2 = "Kinsey mumbles some words...the light flares, and " + TPN + " is gone.\n";
			whr = "players/wrathchild/realm/river/rvr01";
			break;
		default:
			msg1 = "Kinsey says: I'm not sure where that is.\n";
			msg2 = "";
			whr = "";
			break;
	}
	write(msg1);
	if(whr != "")
		move_object(this_player(), whr);
	say(msg2);
	return 1;
}

comment(arg) {
	if(!arg) {
		write("Kinsey says: Use 'comment <message>'.\n");
		return 1;
	}
	say("Kinsey summons some parchment and jots down a note.\n");
	write("Kinsey says: Thanks for your input, I'll see what I can do about that.\n");
	write_file("/players/wrathchild/log/comment", TPN + "(" + ctime() + "): " + arg + "\n");
	return 1;
}

sell(arg) {
	object ob;
	string msg;
	int weight,value;
	if (!arg) {
		write("Kinsey says: What would you like to sell?\n");
		return 1;
	}
	ob = present(arg, this_player());
	if(!ob) {
		write("Kinsey tells you: You don't have that on you.\n");
    	return 1;
    }
	switch(arg) {
		case "wings":
			msg = "a pair of wings";
			break;
		case "skin":
           	msg = "a snake skin";
           	break;
		case "hide":
			msg = "a badger hide";
			break;
		default:
			write("Kinsey says: I don't care much for that.\n");
			return 1;
	}
	value = ob->query_value();
	say(this_player()->query_name() + " sells " + msg + ".\n");
	write("Kinsey gives you " + value + " coins and takes " + msg + ".\n");
	weight = call_other(ob, "query_weight", 0);
	call_other(this_player(), "add_weight", - weight);
	call_other(this_player(), "add_money", value);
	destruct(ob);
	return 1;
}

catch_tell(str) {
    object ob;
    string what;
    from = this_player();
    write_file("/players/wrathchild/log/light.log", str + ": " + ctime() + "\n");
    if (sscanf(str, "%s gives %s to Kinsey.", who, what) == 2) {
        tell_object(from , "Kinsey tells you: \"Thanks, I think...\"\n");
        return;
	}
    if (sscanf(str, "%s arrives", who) == 1) {
		if(from && random(2)) {
			call_out("get_arrives", random(4));
        }
        return;
    }
}


get_arrives(arg) {
	int g,h;
	g = random(6);
	if(g < 4) {
		h = random(4);
		if(h == 0)
			say("Kinsey bows.\n");
		else if(h == 1)
			say("Kinsey smiles.\n");
		else if(h == 2)
			say("Kinsey blinks.\n");
	}
	return 1;
}

ask(str)  {
	string msg;
	if(!str) {
		write("Kinsey tells you: \"What do you want to ask about?  I'll try to answer\n" +
			"	any questions you might have about anything in this realm.\"\n");
			return 1;
		}
	switch(str) {
		case "river":
		case "about river":
		case "about the river":
			msg = "Ahh, the river doorway will lead you to a fairly peaceful\n" +
			"	area surrounding a tranquil river.  There are some small gnomes and\n" +
			"	low-level creatures that make this area their home.";
			break;
		case "gnome":
		case "gnomes":
		case "about gnomes":
		case "about the gnomes":
			msg = "Those little gnomes can be quite pesky, but for the most\n" +
			"	part are peaceful.  They can be protective of their leader though.";
			break;
		case "haxle":
		case "about haxle":
			msg = "Oh, that nasty creature.  I suggest just staying away from\n" +
			"	that evil being.";
			break;
		default:
			msg = "Hmm, I don't know much about that.";
			break;
		}
	kinsey_say(msg);
	return 1;
}

kinsey_say(str) {
	say("Kinsey speaks to " + this_player()->query_name() + ".\n");
	tell_object(this_player(), "Kinsey tells you: \"" + str + "\"\n");
	return 1;
}

heart_beat() {
   string tob;
   object *at,att;
   int X,x,so;
   ::heart_beat();
	for(x=0,at=all_inventory(environment(this_object())),so=sizeof(at);so>x;x++) {
		tob = at[x]->query_name();
		if(at[x]->query_attack() && tob != "Kinsey" && random(10) < 3) {
		say("Kinsey screams:  NO FIGHTING!\n");
		tell_object(at[x],"Kinsey pushes you out!\n");
		command("out",at[x]);
		say("Kinsey pushed " + at[x]->query_name() + " out!\n");
		}
	}
	if(this_object()->query_attack() && random(20) < 3) {
		say("Kinsey is bathed in a healing " + WHT + "light" + NORM + ".\n");
		this_object()->add_hit_point(random(15));
	}
}

monster_died() {
	object corpse;
	say("\n\nKinsey gives you a mischievious wink as he crumples to the ground...\n" +
		"then disappears in a flash of light!\n");
	corpse = present("corpse", environment());
	if(corpse)
		destruct(corpse);
	return 1;
}