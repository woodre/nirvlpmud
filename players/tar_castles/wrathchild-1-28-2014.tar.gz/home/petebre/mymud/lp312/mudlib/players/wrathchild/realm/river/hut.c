inherit "/players/wrathchild/mon/gnomes";
inherit "room/room";
object leader;

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A small hut";
    long_desc =
        "   The hut, although quite small and plainly furnished, appears well\n" +
        "taken care of.  It looks to be some kind of meeting place with a few\n" +
        "chairs arranged facing one slightly larger one.  A rug covering the\n" +
        "entire floor looks very worn, but well made.\n";
    dest_dir =
    	({
        "players/wrathchild/realm/river/rvr05", "out",
        });
    items =	({
		"chairs", "The few chairs here look like they are here for some kind of meeting",
		"chair", "The head chair sits at the back of the hut, it looks well made",
		"rug", "Although most of the color is faded, a few intricate patterns are still visible",
		});
	if(!leader) {
		leader = make_leader();
		if(leader) move_object(leader, this_object());
	}
}

