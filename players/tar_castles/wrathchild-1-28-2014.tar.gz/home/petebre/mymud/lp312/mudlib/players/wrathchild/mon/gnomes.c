/*		Wrathchild 3/10/02
 *
 */

object gold;

make_gnome() {
    int y;
    object gnome;
    string type, long;
    type = ({"young", "old", "villager", "priest", "warrior"});
    long = ({"A young gnome with an inexperienced look in his eyes.\n" +
    	"Standing about 3'2'', this gnome appears to be a child.\n" +
    	"Seemingly lost in his own world this gnome doesn't even\n" +
    	"look up at you.",
    	"An old, stooped gnome with a lost look in his eyes.  It\n" +
    	"looks like the passing of many years has turned this once\n" +
    	"pround gnome into a frail shell of what he was.",
    	"Standing about 4'5'', the plain dressed, somewhat dirty\n" +
    	"gnome, appears to be a local villager.  He is moving about\n" +
    	"as if hurried.",
    	"This mid-sized gnome is dressed in plain robes that have\n" +
		"some ebroidery at the neck.  He has some kind of symbol\n" +
		"hanging around his neck.",
		"This gnome is dressed different than most of the others.\n" +
		"Wearing plain leather armor, he stands with a self-confidence\n" +
		"that most of the other gnomes are lacking.  He seems ready\n" +
		"to react to those around."});
    y = random(sizeof(type));
    gnome = clone_object("obj/monster");
    call_other(gnome, "set_name", type[y] + " gnome");
    call_other(gnome, "set_alias", "gnome");
    call_other(gnome, "set_race", "gnome");
    call_other(gnome, "set_alt_name", type[y]);
    call_other(gnome, "set_level", y + 4);
    call_other(gnome, "set_short", "A " + type[y] + " gnome");
    call_other(gnome, "set_long", "" + long[y] + "\n");
    call_other(gnome, "set_wc", y + 8);
    call_other(gnome, "set_ac", y + 3);
    move_object(gnome, this_object());
	gold=clone_object("/obj/money");
	gold->set_money(random(100) + 100 + (50 * y));
	move_object(gold, gnome);
    if(y == 3) {
		object amulet;
		amulet = make_amulet();
		move_object(amulet, gnome);
		call_other(gnome, "set_chat_chance", 5);
		call_other(gnome, "load_chat", "The priest gnome smiles at you.\n");
		call_other(gnome, "load_chat", "Priest gnome asks: How are you today?\n");
		call_other(gnome, "load_chat", "The priest gnome makes some odd gestures.\n");
		call_other(gnome, "load_chat", "The priest gnome hold his amulet.\n");
		call_other(gnome, "set_a_chat_chance", 20);
		call_other(gnome, "load_a_chat", "The priest prays.\n");
		call_other(gnome, "load_a_chat", "Priest gnome says: Why?\n");
		call_other(gnome, "load_a_chat", "Priest gnome yells: You'll pay for this!\n");
		call_other(gnome, "load_a_chat", "The priest screams: Nooo! Please!!\n");
		}
    if(y == 4) {
		object sword;
		sword = make_sword();
		move_object(sword, gnome);
		call_other(gnome, "set_chat_chance", 5);
		call_other(gnome, "load_chat", "Warrior gnome asks: Where are you going?\n");
		call_other(gnome, "load_chat", "Warrior gnome asks: What are YOU doing here?\n");
		call_other(gnome, "load_chat", "Warrior gnome says: I am here to keep the peace!\n");
		call_other(gnome, "load_chat", "Warrior gnome says: Please don't cause any trouble.\n");
		call_other(gnome, "set_a_chat_chance", 20);
		call_other(gnome, "load_a_chat", "Warrior gnome says: You'll never get to our leader!\n");
		call_other(gnome, "load_a_chat", "Warrior gnome screams: I'll have your head!\n");
		call_other(gnome, "load_a_chat", "Warrior gnome lunges for you!\n");
		call_other(gnome, "load_a_chat", "Warrior gnome parries your attack.\n");
	}
}

make_sgnome() {
	object sgnome;
	sgnome = clone_object("obj/monster");
	call_other(sgnome, "set_name", "scared gnome");
	call_other(sgnome, "set_race", "gnome");
	call_other(sgnome, "set_alias", "gnome");
	call_other(sgnome, "set_level", 3);
	call_other(sgnome, "set_short", "A scared gnome");
	call_other(sgnome, "set_long", "This small gnome is huddled in the corner shaking\n" +
		"horribly.  Wearing but shreds of clothes, he shys away from your gaze and tries\n" +
		"to bury himself deeper into the corner.\n");
	call_other(sgnome, "set_wc", 4);
	call_other(sgnome, "set_ac", 7);
	call_other(sgnome, "set_hp", 45);
	move_object(sgnome, this_object());
	gold=clone_object("/obj/money");
	gold->set_money(100 + random(41)); /* avg 120 */
	move_object(gold, sgnome);
	call_other(sgnome, "set_chat_chance", 10);
	call_other(sgnome, "load_chat", "The gnome whimpers: Watch out for the thing in the caves...\n");
	call_other(sgnome, "load_chat", "The gnome cowers away from you.\n");
	call_other(sgnome, "load_chat", "The gnome hisses: There were bones...bones everywhere...\n");
	call_other(sgnome, "load_chat", "The gnome pleads: It was so dark...he came out of nowhere.\n");
	call_other(sgnome, "load_chat", "The gnome sneers: If only I could have searched that room...\n");
	call_other(sgnome, "set_a_chat_chance", 20);
	call_other(sgnome, "load_a_chat", "The gnome tries to run away.\n");
	call_other(sgnome, "load_a_chat", "The gnome bites at you.\n");
	call_other(sgnome, "load_a_chat", "The gnome hisses: Not me!  Kill the thing!!\n");
	call_other(sgnome, "load_a_chat", "The gnome pleads: Don't hurt me!\n");
}

make_leader() {
    object leader;
    leader = clone_object("obj/monster");
    call_other(leader, "set_name", "gnome leader");
    call_other(leader, "set_alias", "gnome");
    call_other(leader, "set_race", "gnome");
    call_other(leader, "set_alt_name", "leader");
    call_other(leader, "set_level", 12);
    call_other(leader, "set_short", "Gnome leader");
    call_other(leader, "set_long", "A small well dressed gnome stares with a proud look\n" +
    	"in his eyes.  A few lines of age mark his face, but he\n" +
    	"still looks as if he retains the strength of his youth.\n" +
    	"He is unarmed, but looks like he can take care of himself.\n");
    call_other(leader, "set_wc", 13 + random(7));  /* avg 16 */
    call_other(leader, "set_ac", 8 + random(3));  /* avg 9 */
    move_object(leader, this_object());
    gold=clone_object("/obj/money");
	gold->set_money(450 + random(200));	/* avg 550 */
	move_object(gold, leader);
	call_other(leader, "set_chat_chance", 15);
	call_other(leader, "load_chat", "The gnome leader taps his foot.\n");
	call_other(leader, "load_chat", "Gnome leader says: Have you come to speak with me?\n");
	call_other(leader, "load_chat", "Gnome leader says: Where are my guards?\n");
	call_other(leader, "load_chat", "The gnome leader stares at you.\n");
	call_other(leader, "set_a_chat_chance", 20);
	call_other(leader, "load_a_chat", "Gnome leader yells: Do you know who I am?!\n");
	call_other(leader, "load_a_chat", "The gnome leader punches you!\n");
	call_other(leader, "load_a_chat", "The gnome leader kicks you!\n");
	call_other(leader, "load_a_chat", "Gnome leader yells: Guards!\n");}


make_sword() {
    object sword;
    sword = clone_object("obj/weapon");
  	call_other(sword, "set_name",  "sword");
  	call_other(sword, "set_short", "A curved sword");
  	call_other(sword, "set_long", "This small curved sword looks very sharp, but it's fairly small.\n");
  	call_other(sword, "set_class", 8);
  	call_other(sword, "set_weight", 2);
	call_other(sword, "set_hit_func", this_object());
    return sword;
  }

make_amulet() {
	object amulet;
	amulet = clone_object("obj/armor");
  	call_other(amulet, "set_name",  "amulet");
  	call_other(amulet, "set_short", "A small amulet");
  	call_other(amulet, "set_long", "This small amulet is very crude, but appears to be made from silver.\n");
  	call_other(amulet, "set_class", 1);
  	call_other(amulet, "set_weight", 2);
  	call_other(amulet, "set_type", "amulet");
  	call_other(amulet, "set_value", 50);
    return amulet;
  }


weapon_hit(attacker) {
	if(random(10) < 4) {
		write("You slice your opponent!\n");
    	say("The sword rips its opponent!\n");
    	return 0;
    }
    return 0;
}