/*      lsroad3.c by Wrathchild         */
inherit "room/room";

reset() {
    set_light(1);
    }

short() {
        return "Gate to Longshire";
        }

long() {
        write("Gate to Longshire...\n");
        call_other("/players/wrathchild/realm/longshire/longs.c", "get_weather");
        write("\nA tall wall rises before you with a huge gate gate in the center.\n" +
        "The only obvious exits are:  enter and south\n");
        }

init() {
        add_action("enter", "enter");
        add_action("south", "south");
        }

north() {
        call_other(this_player(),"move_player",
                                 "entering the town#/players/wrathchild/realm/longshire/lsroad3.c");
        return 1;
        }

south() {
        call_other(this_player(),"move_player",
                                 "to the south#/players/wrathchild/realm/longshire/lsroad2.c");
        return 1;
}
