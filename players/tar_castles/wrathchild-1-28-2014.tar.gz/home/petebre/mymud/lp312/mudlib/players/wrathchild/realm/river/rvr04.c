inherit "/players/wrathchild/mon/gnomes";
inherit "room/room";
object gnome;
int x;

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "A river bank";
    long_desc =
        "   This wooded area is the east bank of a narrow river. The water\n" +
        "flows north at a lazy pace and the noises of the forest are much\n" +
        "louder here.  The forest north of here is so thick here it looks\n" +
        "impassable.  To the east the sounds of voices becomes clearer and\n" +
        "some small huts are visible.  There is a light to the south.\n";
    dest_dir =
        ({
        "players/wrathchild/realm/river/rvr05", "east",
        "players/wrathchild/realm/river/rvr03", "south",
        });
    items =	({
		"river", "This small river flows north at a slow pace",
		"forest", "The forest is very dense here",
		"water", "The slow moving water looks fairly warm",
		"light", "The light to the south looks like the doorway that brought you here",
		"hut", "A couple small wooden huts are visible to the east",
		"huts", "A couple small wooden huts are visible to the east",
		});
	for(x = 0;x < (2 + random(5));x++) {
		gnome = make_gnome();
		if (gnome) move_object(gnome, this_object());
	}
}

