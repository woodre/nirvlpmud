inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A musty cave";
    long_desc =
        "   This area of the cave if very damp and smells of decay.  The mud\n" +
        "floor slopes down into a large pool of water, with a few small rocks\n" +
        "at the edge.  The walls here shine with moisture, and dripping water\n" +
        "echoes throughout this area.\n";
dest_dir =
        ({
        "players/wrathchild/realm/river/hole01", "east",
        });
    items =	({
		"mud", "A slimy, clay colored mud makes up the floor",
		"rocks", "A few small rocks have collected at the edge of the pool",
		"floor", "A slimy, clay colored mud makes up the floor",
		"pool", "An icy pool of water has collected here",
		"water", "The water looks very cold and deep",
		"walls", "Made of solid rock, the walls look very slick",
		});
}

