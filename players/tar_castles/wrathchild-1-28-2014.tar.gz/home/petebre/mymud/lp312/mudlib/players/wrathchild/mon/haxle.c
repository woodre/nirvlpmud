/*              by Wrathchild 3/15/02
 *
 *		less coins and a bit tougher than a normal
 *		15th lvl mob because once dead the player
 *		can search the room for some treasure (coins
 *		and weapon)
 */

inherit "obj/monster";
#include "/players/wrathchild/ansi.h"

object gold;


reset(arg) {
	::reset(arg);
	if(arg) return;
	set_name("haxle");
	set_level(15);
	set_hp(random(100) + 200); /* avg 250 */
	set_al(-200);
	set_race("gnome");
	set_wc(17 + random(8)); /* avg 20.5 */
	set_ac(9 + random(9)); /* avg 13 */
	set_aggressive(0);
	set_short("" + BLK + "Haxle" + NORM + ", the dark");
	set_long("This crouched figure looks twisted by its own evil. Poised\n" +
		"on muscular legs, the dark creature snarls revealing rows of\n" +
		"dripping teeth.  Wearing but fragments of tattered clothes this\n" +
		"creature looks like it wouldn't mind adding you to one of its\n" +
		"bone piles.\n");
	gold=clone_object("/obj/money");
	gold->set_money(500 + random(400));  /* avg 700 */
	move_object(gold, this_object());
	set_chat_chance(20);
	load_chat("Haxle hisses at you!\n");
	load_chat("Haxle crouches down to attack.\n");
	set_chance(15);
	set_spell_dam(random(15));	/* avg 7 */
	set_spell_mess1(BLK + "Haxle" + NORM + " recklessly claws at its opponent!");
	set_spell_mess2(BLK + "Haxle" + NORM + " recklessly claws at you!");
}