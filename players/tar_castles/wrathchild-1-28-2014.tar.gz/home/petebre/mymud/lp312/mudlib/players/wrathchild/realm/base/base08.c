inherit "room/room";

int i;

reset(arg) {
    if (arg) return;
 	set_light(0);
 	long_desc =
 		"   This large room extends in all directions from here.  A few broken\n" +
 		"crates clutter and some shattered pottery clutter the area.  An opening\n" +
 		"that looks like a hallway is to the south, and the shadows deepen to\n" +
 		"the northeast.\n";
 	dest_dir =
        ({
        "players/wrathchild/realm/base/base04", "north",
        "players/wrathchild/realm/base/base02", "south",
        "players/wrathchild/realm/base/base05", "east",
        "players/wrathchild/realm/base/base06", "west",
        });
    items =
    	({
		"light","This area is has light coming from all around, it appears to come\n" +
			"and go with each sprite",
		"dirt", "A light brown dirt is visible thoughout the walls and floor",
		"hall", "A small hallway opens to the south",
		"crates", "The crates look like they were smashed open long ago",
		"pottery", "What used to be pottery, made of some kind of red material, is smashed here",
		"opening", "A small hallway lies to the south",
		});
   	for (i = 0; i < random(6); i++)
       	move_object(clone_object("/players/wrathchild/mon/spr.c"), this_object());
}

short() {
	int l;
	string room;
	object inv;
	inv = all_inventory(this_object());
	for(i=0; i<sizeof(inv); i++) {
		if(inv[i]->query_race() == "sprite") l++;
	}
	if(l < 1) room = "dark";
	else if(l < 2) room = "dim";
	else if(l < 3) room = "bright";
	else if(l < 5) room = "very bright";
	else room = "radiant";
	return "A " + room + " room";
}