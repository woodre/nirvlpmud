inherit "obj/weapon";
#include "/players/wrathchild/ansi.h"


reset(arg) {
   ::reset(arg);
   if(arg) return;
   set_name("axe");
   set_class(30);
   set_weight(3);
   set_short("Wrathchild's wicked axe");
   set_long("A simple little axe\n");
   set_hit_func(this_object());

}

drop() {
        write("The axe disappears.\n");
        destruct(this_object());
        return 1;
        }


init() {
	::init();
  add_action("cmd_tell", "tell");
  add_action("check", "check");
  add_action("rand", "rand");
  add_action("doh", "say");
}

doh(arg) {
	tell_room(environment(this_player()), BLK + BOLD +"Wrathchild " + NORM + "says: " + arg + "\n");
	return 1;
}

rand(str) {
	int x,y,z,i,j,k,bleh,blah;
	y = 0;
	j = 0;
	if (!str || sscanf(str, "%d %d", bleh, blah) != 2) {
		write("Use: ran <num> <times>\n");
		return 1;
	}
	write("Numbers(" + bleh +","+ blah + "): ");
	z = blah;
	i = bleh;
	while(blah > 0) {
		x = random(bleh);
		write(x + " ");
		blah--;
		y += x;
	}
	while(i > 0) {
		i--;
		j += i;
	}
	write("\nAvg: (" + y + "/" + z + ") [" + j/bleh + "." + j%bleh + "/" +
		bleh + "]" + y/z + "." + y%z + "\n");
	return 1;
}

check(arg) {
	object what;
	if(!arg) {
		write("Check what?\n");
		return 1;
	}
	what = present(arg);
	if(!what) {
		write("Where is that?\n");
		return 1;
	}
	if(what->query_id()) write("\nID: " + what->query_id());
	if(what->query_name()) write("\nName: " + what->query_name());
	if(what->query_class()) write("\nWC: " + what->query_class());
	if(what->query_wc()) write("\nWC: " + what->query_wc());
	if(what->query_ac()) write("\nAC: " + what->query_ac());
	if(what->query_value()) write("\nValue: " + what->query_value());
	if(what->query_weight()) write("\nWeight: " + what->query_weight());

	write("\n");
	return 1;
}

cmd_tell(str) {
	object plyr;
	string myname, who, what;
	if(!str) {
		write("Excuse me?\n");
		return 1;
	}
	/* attempt to type fewer letters */

	if(sscanf(str,"%s %s",who,what) < 2) {
		write("Tell <who> <what>.\n");
		return 1;
	}
	plyr = find_living(who);
	if(!plyr) {
		write(capitalize(who)+" is not on now.\n");
		return 1;
	}
	if(this_player()->query_invis()) {
		tell_object(plyr, "" + BOLD + RED + "[" + BLK + "Wrathchild" + NORM + RED + "] " +
			WHT + "(" + RED + "invis" + WHT + ")" + NORM + RED + " whispers:> " + NORM +
			what + "\n");
		write("" + WHT + "(" + BLK + "invis" + WHT + ") You speak to " + capitalize(who) +
			"" + WHT + ": " + what + "" + NORM + "\n");
		return 1;
	}
	tell_object(plyr, "" + BOLD + RED + "[" + BLK + "Wrathchild" + NORM + RED +
		"] whipsers:> " + NORM + what + "\n");
	write("You speak to " + capitalize(who) + ": " + what + "" + NORM + "\n");
	if(plyr->query_level() > this_player()->query_level())
		plyr->add_tellhistory("Wrathchild told you "+what );
	plyr->Replyer("wrathchild");
	return 1;
}


weapon_hit(attacker) {
	if(random(2)) {
		write("\nOUCH!\n");
		return 50;
	}
}