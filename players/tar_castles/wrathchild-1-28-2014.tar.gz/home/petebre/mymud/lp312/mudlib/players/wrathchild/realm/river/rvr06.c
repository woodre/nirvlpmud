inherit "room/room";

reset(arg) {
    if (arg) return;
    set_light(1);
    short_desc = "A river bank";
    long_desc =
        "   This wooded area is the east bank of a narrow river. The water\n" +
        "of the river gurgles through some rapids here.  To the southeast\n" +
        "is an enormous oak tree that looks like it has seen the weather\n" +
        "of many years.\n";
	dest_dir =
        ({
        "players/wrathchild/realm/river/rvr01", "north",
        });
	items =
		({
		"river", "This small river flows north at a slow pace",
		"forest", "The forest is very dense here",
		"water", "The slow moving water looks fairly warm",
		"light", "The light to the south looks like the doorway that brought you here",
		"tree", "The huge oak tree reaches skyward.\n" +
			"There is a hole near its base",
		"oak", "The huge oak tree reaches skyward.\n" +
			"There is a hole near its base",
		"hole", "The hole in the tree looks almost large enough for you to enter",
		});

}

init() {
	::init();
	add_action("enter", "enter");
}

enter(str) {
	if(!str && str != "hole") {
		write("Enter what?\n");
		return 1;
	}
	call_other(this_player(),"move_player", "into a hole in the tree#players/wrathchild/realm/river/trunk");
	return 1;
}