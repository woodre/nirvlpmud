inherit "room/room";

reset(arg){
 if(!arg){
 set_light(1);
 short_desc="Eye of the Sandstorm";
 long_desc=
"     Perfect white sand dunes stretch into an endless\n"+
"romantic horizon before you. Beaches of aqua gently\n"+
"lap against the surrounding shores, reflecting the\n"+
"starry skies above you.\n";

items=({
 "walkway", "The wide walkway is made of obsidian",
 "flames","Spires of shooting flame surround you on all sides",
 "waves","You can see the bending waves of heat"
 });

  dest_dir=({
 "/players/dune/hotel/office.c","cowbarn",
      });
  }   }

realm() { return "NT"; }
