#define CO   call_other
#define MV   "move_player"
#define TEL  CO(TP, MV
#define R1   return 1
#define TP this_player()
id(str) { return str == "testtool"; }
short () { return "Dunetest's testtool (Dune's test char)"; }

long() {
   write(
"_____________________________________________\n"+
"hm                     heals me to full amount\n"+
"cm                     coins me to richness\n"+
"setxlv <number>        change your xtra level\n"+
"setac <number>         change your ac\n"+
"setwc <number>         change your wc\n"+
"goin     <who>         go inside a player\n"+
"setatt <what> <num>    sets 'what' attrib to 'num'\n"+
"hotelme                go to hotel\n"+
"_____________________________________________\n");
}

get() { return 1; }
query_weight() { return 0; }
query_value() { return 0; }
drop() { destruct(this_object()); return 1; }

init() {
   if((TP->query_real_name() == "dunetest") ||
      (TP->query_real_name() == "dune")) {
   add_action("church","church");
   add_action("shop","shop");
   add_action("lockers","lockers");
   add_action("advance","advance");
   add_action("castle","castle");
   add_action("cm","cm");
   add_action("hm","hm");
   add_action("setatt","setatt");
   add_action("goin", "goin");
   add_action("setac","setac");
   add_action("setwc","setwc");
   add_action("hotelme","hotelme");
   add_action("setxlv","setxlv");
   }
   else {
     write("You are not Dunetest nor Dune!\n");
     destruct(this_object());
     return 1; 
     }
}

advance(){TEL, "advance#room/adv_guild.c"); R1;}
shop(){TEL, "shop#room/shop.c"); R1;}
lockers() {TEL, "lockers#players/catwoman/tl.c"); R1;}
church() {TEL, "church#room/church.c"); R1;}
castle() {TEL, "castle#room/plane8.c"); R1;}
hotelme() {TEL, "hotel#players/dune/hotel/office.c"); R1;}

hm() {
  TP->heal_self(1000);
  write("You are healed.\n");
  return 1;
  }

goin(string str) {
   if (!str) return 0;
   if (!find_player(str)) return 0;
   move_object(this_player(), find_player(str));
   return 1;
}

cm() {
  TP->add_money(100000);
  write("You are rich.\n");
  return 1;
  }

setatt(string str) {
  string what;
  int num;
  if(!str) {
    write("Usage: setatt <what> <num>\n");
    write("Choices are: str, sta, wil, mag, pie, ste, luc, int\n");
    return 1; }
  if(!sscanf(str, "%s %d", what, num)) {
    write("Usage: setatt <what> <num>\n");
    write("Choices are: str, sta, wil, mag, pie, ste, luc, int\n");
    return 1; }
  this_player()->set_attrib(what, num);
  return 1; }

setac(int num) {
  if(!num) { write("Usage: setac <number>\n"); return 1; }
  this_player()->set_ac(num);
  return 1; }

setwc(int num) {
  if(!num) { write("Usage: setwc <number>\n"); return 1; }
  this_player()->set_wc(num);
  return 1; }

setxlv(int num) {
  if(!num) { write("Usage: setxlv <number>\n"); return 1; }
  this_player()->set_extra_level(num);
  return 1; }
