inherit "room/room";
reset(arg){

int i;
int o;

if(!present("shark")) {
   o = random(3)+4;
   for(i = 1; i<=o; i++)
      move_object(clone_object("/players/dune/monsters/shark.c"),
      this_object());
}

 if(!arg){
 set_light(1);
 short_desc="Water";
 long_desc=
"  ~          ~~~      ~~~~~~       ~ ~~~~~    ~~~~~ ~~  \n"+
"    ~~~~~~~      ~~~~   ~~    ~~ ~~      ~~~   ~~~~~~   \n"+
"________________________________________________________\n"+
"\n"+
"\n"+
"\n"+
"________________________________________________________\n"+
"   ~~~~~~  ~~~      ~~~~     ~~     ~~~~~~~      ~~~    \n"+
"~ ~~~    ~~       ~~~~   ~~~~~~~    ~~~~       ~~~~ ~   \n"+
"     The walkway curves around tidal pools and expanses\n"+
"of rough sea.  As you look above you, you are amazed at\n"+
"what you see.  An entire ocean is directly above your head.\n"+
"You are between two oceans.  Yet, the water above does not\n"+
"come crashing down on top of you, like you think it would.\n";

items=({
 "walkway", "The wide walkway is made of coral",
 "ocean","You are between twin oceans",
 "pools","The pools have swarms of small sea-life in them",
 "sea","The sea is rough and too dangerous to swim in",
 });

  dest_dir=({
 "/players/dune/room/center.c","east",
 "/players/dune/room/water2.c","southwest",
      });
  }   }

realm() { return "NT"; }
