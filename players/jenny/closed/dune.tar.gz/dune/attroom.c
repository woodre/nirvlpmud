inherit "room/room";
init() {
   if(this_player()->query_real_name() != "dune") {
   this_player()->command("drop all");
   this_player()->command("soul off");
   add_action("goto","goto");
   add_action("goportal","goportal");
   add_action("quit","quit");
   add_action("tell","tell");
   add_action("shout","shout");
   add_action("gossip","gossip");
   add_action("channel","channel");
   add_action("emergency","emergency");
   add_action("bug","bug");
   add_action("idea","idea");
   add_action("typo","typo");
   add_action("ed","ed");
   add_action("clone","clone");
   add_action("update","update");
   add_action("load","load");
   add_action("mt","mt");
   add_action("sh","sh");
   add_action("home","home");
   add_action("i","i");
   add_action("get","get");
   add_action("wiz","wiz");
   add_action("announce","announce");
   add_action("risque","risque");
   add_action("junk","junk");
   add_action("equip","equip");
   add_action("kill","kill");
   add_action("dest","dest");
   add_action("force","force");
   add_action("invisible","invisible");
   add_action("give","give");
   add_action("soul","soul");
}}

reset(arg){
 if(!arg){
 set_light(0);
 short_desc="Dune's Attention Room";
 long_desc=
"     You are in Dune's Attention Room.\n";
  }   }
