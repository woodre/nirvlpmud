poka(string str) {
 write("blah!!!!\n");
 return 1; }
