#include "/players/dune/closed/guild/DEFS.h"
inherit "/players/dune/closed/guild/boards/board";
#define BOARD_NAME ALTDUNEPATH+"/boards/guildboard"


init() {
    add_action("read",   "read");
    add_action("read",   "output");
}

void description() {
  write("Before you stands the main guild board.\n");
  write("You glance upon the radiance of a Light Board.\n"+
        "Light Boards are high resolution flat panel displays.\n"+
        "This board can only be read, for some odd reason.\n");
}

string short() {
  return ("The "+FUNKYNAME+" Main Light Board(" + num_messages + " msgs)");
}

void restore_me() { restore_object(BOARD_NAME); }
void save_me() {}
