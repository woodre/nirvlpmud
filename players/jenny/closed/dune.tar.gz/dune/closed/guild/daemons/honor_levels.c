#include "../DEFS.h"
#include DEFS_HLEVELS

string honorTitle(int lev) {
  /* Returns honor title for honor points specified */
  string title;
  if(lev >= HONOR_LEVEL_MD1) { title = HONOR_TITLE_MD1; }
  if(lev >= HONOR_LEVEL_MD2) { title = HONOR_TITLE_MD2; }
  if(lev >= HONOR_LEVEL_MD3) { title = HONOR_TITLE_MD3; } 
  if(lev >= HONOR_LEVEL_MD4) { title = HONOR_TITLE_MD4; }
  if(lev >= HONOR_LEVEL_MD5) { title = HONOR_TITLE_MD5; }
  if(lev >= HONOR_LEVEL_MAX) { title = HONOR_TITLE_MAX; }
  if(!title) return HONOR_TITLE_MIN;
  return title;
}


string findRangeNames(object ob) {
    string stone, name;
    if(!IPOB) return 0;
    if(!IPOB->query_stone()) {
      if((int)IPOB->query_honor() < HONOR_LEVEL_MD5) return 0;
      name = HONOR_AWARDNAME_MIN;
      return name;
    }
    stone = (string)IPOB->query_stone();
    name = HONOR_AWARDNAME_MIN+", "+HONOR_AWARDNAME_MD1;

    if(stone == "ruby")
      name += ", " + HONOR_AWARDNAME_MD2;
    else if((stone == "sapphire") || (stone == "emerald") || (stone == "onyx"))
      name += ", " + HONOR_AWARDNAME_MD2 + ", " + HONOR_AWARDNAME_MD3;
    else if(ORN == OWNER1 || ORN == OWNER2) 
      name += ", " + HONOR_AWARDNAME_MD2 + ", " + HONOR_AWARDNAME_MD3 +
              ", " + HONOR_AWARDNAME_MD4 + ", " + HONOR_AWARDNAME_MAX;
    else if(stone == "adamantium") 
      name += ", " + HONOR_AWARDNAME_MD2 + ", " + HONOR_AWARDNAME_MD3 +
              ", " + HONOR_AWARDNAME_MD4;
    return name;
}


int get_points(string test) {
    int points;
    points = 0;
    switch(test) {
      case HONOR_AWARDNAME_MIN: points = HONOR_AWARDNUM_MIN; break;
      case HONOR_AWARDNAME_MD1: points = HONOR_AWARDNUM_MD1; break;
      case HONOR_AWARDNAME_MD2: points = HONOR_AWARDNUM_MD2; break;
      case HONOR_AWARDNAME_MD3: points = HONOR_AWARDNUM_MD3; break;
      case HONOR_AWARDNAME_MD4: points = HONOR_AWARDNUM_MD4; break;
      case HONOR_AWARDNAME_MAX: points = HONOR_AWARDNUM_MAX; break;
      }
    return points;
}


honor_checkup(object ob) {
  object wep, att;
  int hon;
  string me;

  if(!ob) return 1;
  if(!find_player(ob->query_real_name())) return 1;
  if(!ob->query_interactive()) return 1;
  if(ob->query_level() >= 20) return 1;
  me  = (string)ob->query_real_name();
  hon = (int)IPOB->query_honor();
    wep = ob->query_weapon();
  att = ob->query_attack();
  tell_object(ob, BOLD);
  if(!ob->query_ghost()){
  if(att && (random(10) > 4)) {
    if(!wep || !wep->id("guild_weapon") ){
      tell_object(ob, "\n\tYou are shamed by not using a guild weapon!\n\n");
      IPOB->add_honor(-HONOR_AWARDNUM_MIN); 
    }
    if(att->is_pet()) {
      tell_object(ob,"\tYou are shamed for attacking a pet!\n");
      IPOB->add_honor(-HONOR_AWARDNUM_MD1); 
    }
    if(att->is_player() ) {
      if(att->query_guild() != "cyberninja") {
/* Removing due to player.c valid_attack change. -Snow 12/99
      if(att->query_level() < 6) {
        tell_object(ob, "\n\tYou are shamed by your attack of a newbie!\n\n");
        IPOB->add_honor(-HONOR_AWARDNUM_MD2);
      }
*/
      if(att->query_level() > ob->query_level() ||
        att->query_level() > 15) {
        if(!environment(ob)->query_spar_area() && 
              hon < HONOR_LEVEL_MD4){
          tell_object(ob, "You gain honor in combat!\n");
          IPOB->add_honor(HONOR_AWARDNUM_MD2);
        } 
       }
      else if(att->query_attack() == ob && random(3) == 1 &&
      hon < HONOR_LEVEL_MD5) {
if(!environment(ob)->query_spar_area() && hon < HONOR_LEVEL_MD4){
        tell_object(ob, "You gain honor in combat.\n");
        IPOB->add_honor(HONOR_AWARDNUM_MIN);
}
      }
    }
    }
  }
  }
  IPOB->save_me();
  tell_object(ob, OFF);
  if(!ob->query_pl_k()) return 1;
  if(hon < HONOR_LEVEL_MD2) {
    if(random(6) == 1) {
      tell_object(ob,REV_RED+"\tThe Emperors frown on your lack of honor.\n"+OFF);
      ob->heal_self(-random(4)-1); }
  }
  if(hon >= HONOR_LEVEL_MD4) {
    if(random(50) == 1) {
      tell_object(ob,GREEN+"\tYou feel a small blessing for your honor.\n"+OFF);
      ob->heal_self(random(3)+1); }
  }
  if(hon >= HONOR_LEVEL_MD5) {
    if(random(40) == 1) {
      tell_object(ob,BLUE+"\tYou feel a small rush of energy.\n"+OFF);
      ob->heal_self(random(4)+2); }
  }
  /* at least make this noticeable and helpful */
  /* this will happen once every quarter minute or so */
/* Due to the impossibility of players working with a system,
 * these have been made pretty unlikely. -Snow 9/99 */
  if(hon >= HONOR_LEVEL_MAX) {
    if(random(30) == 1) {
      tell_object(ob,REV_BLUE+"\tThe Emperors smile upon your great honor.\n"+OFF);
      ob->heal_self(random(5)+3); }
  }
  return 1;
}
