#include "../DEFS.h"
#include DEFS_OFFICES
#include DEFS_GLEVELS


string findRole(object ob) {
  string stone;
  int glev;
  stone = (string)IPOB->query_stone();
  glev  = (int)IPOB->guild_lev();
  switch(stone) {
    case "adamantium": return ADAMANTIUM;
    case "diamond":    return DIAMOND;
    case "sapphire":   return SAPPHIRE;
    case "emerald":    return EMERALD;
    case "onyx":       return ONYX;
    case "ruby":       return RUBY;
    case "topaz":      return TOPAZ;
  }
  return 0;
}


string findStone(string role) {
  switch(role) {
    case ADAMANTIUM: return "adamantium";
    case DIAMOND:    return "diamond";
    case SAPPHIRE:   return "sapphire";
    case RUBY:       return "ruby";
    case EMERALD:    return "emerald";
    case ONYX:       return "onyx";
    case TOPAZ:      return "topaz";
  }
  return 0;
}


void list(object ob) {
  tell_object(ob, 
  "Roles within the "+FUNKYNAME+" guild\n"+
  ".*.....*.*........*......*.......*.....\n"+
  "standard guild member   \n"+
  ONYX       +"\n"+
  EMERALD    +"\n"+
  RUBY       +"\n"+
  SAPPHIRE   +"\n"+
  TOPAZ      +"\n"+
  DIAMOND    +"\n"+
  ADAMANTIUM +"\n"+
  "....*.........*....*............*..**..\n");
}


status checkStone(object ob, string stones) {
  string * stoneArray;
  int i;

  if(!ob || !IPOB || !stones) return 0;
  if(IPOB->guild_wiz()) return 1;
  stoneArray = explode(stones, " ");
  for(i = 0; i < sizeof(stoneArray); i++) {
    if((string)IPOB->query_stone() == stoneArray[i]) return 1;
  }
  return 0;
}


/* lists spheres of influence that Immortals play a part in */
void listSpheres(string str) {
  write(
      pad(WIZ_TIER3_A, 20)+WIZ_TIER3_A_DUTY+"\n"
    + pad(WIZ_TIER3_B, 20)+WIZ_TIER3_B_DUTY+"\n"
    + pad(WIZ_TIER3_C, 20)+WIZ_TIER3_C_DUTY+"\n"
    + pad(WIZ_TIER3_D, 20)+WIZ_TIER3_D_DUTY+"\n"
    + pad(WIZ_TIER2_A, 20)+WIZ_TIER2_A_DUTY+"\n"
    + pad(WIZ_TIER2_B, 20)+WIZ_TIER2_B_DUTY+"\n"
    + pad(WIZ_TIER1_A, 20)+WIZ_TIER1_A_DUTY+"\n"
    + pad(WIZ_TIER1_B, 20)+WIZ_TIER1_B_DUTY+"\n"
  );
}


/* checks validity of a sphere name for object ob*/
string findSphere(object ob, string str) {
  if(!IPOB) return 0;
  if(ORN == OWNER1) 
    return capitalize(ADMINIUM)+" of "+capitalize(WIZ_TIER1_A);
  if(ORN == OWNER2) 
    return capitalize(ADMINIUM)+" of "+capitalize(WIZ_TIER1_B);
  switch(str) {
    case WIZ_TIER3_A:
    case WIZ_TIER3_B: 
    case WIZ_TIER3_C:
    case WIZ_TIER3_D:
    case WIZ_TIER2_A:
    case WIZ_TIER2_B:
      return capitalize(ADAMANTIUM)+" of "+capitalize(str);
  }
  return 0;
}


void empowerUsage() {
   tell_object(TP, "Usage: empower <who> [type] [yes/no] \n"+
                   "[yes/no] gives/removes the position  \n"+
                   "Choose [type] among the list below...\n");
   list(TP);
}


status empower(string str) {
  object ob;
  string who, type, flag, newStone;
  status verbose;

  verbose = 1;
  if(!TP) verbose = 0;
  if(!sscanf(str, "%s %s %s", who, type, flag)) {
    if(verbose) empowerUsage();
    return 0; 
  }
  if(!type || !flag) { empowerUsage(); return 0; }
  who  = lower_case(who);
  flag = lower_case(flag);
  if(!find_player(who)) {
    if(verbose) write("No such player.\n");
    return 0;
  }
  ob = find_player(who);
  if(!IPOB) return 0;
  if( !(flag == "yes" || flag == "no") ) return 0;
  if(!findStone(type)) return 0;
  newStone = findStone(type);

  if(verbose) {
    if( (type == ADAMANTIUM && !(IPTP->guild_manager())) ||
        (type == DIAMOND    && !(IPTP->guild_wiz())) ) {
      write("You are not THAT powerful!\n");
      return 0;
    }
  }
  if(flag == "yes") {
    if((string)IPOB->query_stone() == newStone) {
      if(verbose) write(OPN+" was already a "+type+".\n");
      return 0;
    }
    else {
      IPOB->set_stone(newStone);
      IPOB->save_me();
      move_object(IPOB, ob); /* force init */
      tell_object(ob, "You have been empowered as "+capitalize(type)+"!\n");
      call_other(CHANNELD, "overchannel", 
        ORN+" has become "+capitalize(type)+"!\n");
      if(verbose) {
        write("You empower "+ORN+
          " with the office of "+capitalize(type)+".\n");
        write_file(LOGDIR + "/EMPOWER", TRN+" made "+ORN+
          " a "+type+". ("+ctime()+")\n");
      }
      else write_file(LOGDIR + "/EMPOWER", 
        ORN+" became "+type+". ("+ctime()+")\n");
    }
  }
  if(flag == "no") {
    if((string)IPOB->query_stone() != newStone) {
      write(OPN+" was not a "+type+" in the first place.\n");
      return 0;
    }
    else {
      IPOB->set_stone(0);
      IPOB->save_me();
      move_object(IPOB, ob); /* force init */
      tell_object(ob, "You have been removed from the office of "+
        capitalize(type)+".\n");
      call_other(CHANNELD, "overchannel", 
        ORN+" is no longer "+capitalize(type)+".\n");
      if(verbose) {
        write("You remove "+ORN+
          " from the office of "+capitalize(type)+".\n");
        write_file(LOGDIR + "/EMPOWER", TRN+" removed "+ORN+
          " from the office of "+type+". ("+ctime()+")\n");
      }
      else write_file(LOGDIR + "/EMPOWER", 
        ORN+" became "+type+". ("+ctime()+")\n");
    }
  }
  if (verbose) write("Deed accomplished.\n");
  return 1;
}
