#include "../DEFS.h"
#include DEFS_ENHANCEMENTS


int findItemCost(string str) {
  /* list in order of cost for convenience*/
  switch(str) {
    case GLIMMER:  return COST_GLIMMER;
    case EYES:     return COST_EYES;
    case EFLUX:    return COST_EFLUX;
    case MFLUX:    return COST_MFLUX;
    case HFLUX:    return COST_HFLUX;
    case BLADES:   return COST_BLADES;
    case ARMOR:    return COST_ARMOR;
    case EMT:      return COST_EMT;
    case MATTER:   return COST_MATTER;
    case ORGANIC:  return COST_ORGANIC;
    case BIONICS:  return COST_BIONICS;
/* Removed 9/98 -Snow
    case DROID:    return COST_DROID;
*/
  }
  return -1;
}


int hasItem(object ob, string str) {
  status flag;
  switch(str) {
    case EYES:    if((status)IPOB->item_eyes()) return 1;
                  break;
    case ORGANIC: if((status)IPOB->item_corpse()) return 1;
                  break;
    case BIONICS: if((status)IPOB->item_bionics()) return 1;
                  break;
    case BLADES:  if((status)IPOB->item_blades()) return 1;
                  break;
    case EFLUX:
    case MFLUX:
    case HFLUX:
                  if((status)IPOB->item_electricflux()) flag=1;
                  if((status)IPOB->item_magneticflux()) flag=1;
                  if((status)IPOB->item_heatflux())     flag=1;
                  if(flag) return 2;
                  break;
    case GLIMMER: if((status)IPOB->item_flash()) return 1;
                  break;
    case EMT:     if((status)IPOB->item_emt()) return 1;
                  break;
    case MATTER:  if((status)IPOB->item_convert()) return 1;
                  break;
    case ARMOR:   if((status)IPOB->item_armor()) return 1;
                  break;
  }
  return 0;
}


status setItem(object ob, string str) {
  switch(str) {
    case EYES:    IPOB->set_eyes(1);           break;
    case ORGANIC: IPOB->set_corpse(1);         break;
    case BIONICS: IPOB->set_bionics(1);        break;
    case BLADES:  IPOB->set_blades(1);         break;
    case EFLUX:   IPOB->set_electricflux(1);   break;
    case MFLUX:   IPOB->set_magneticflux(1);   break;
    case HFLUX:   IPOB->set_heatflux(1);       break;
    case GLIMMER: IPOB->set_flash(1);          break;
    case EMT:     IPOB->set_emt(1);            break;
    case MATTER:  IPOB->set_convert(1);        break;
    case ARMOR:   IPOB->set_armor(1);          break;
    default:      return 0;
  }
  return 1;
}


void list(object ob) {
  tell_object(ob, pad("ITEM",25)+"PRICE (in @'s)\n");
  tell_object(ob,
  "________________________________________\n"+
  pad(EYES,25)    +findItemCost(EYES)    +"\n"+
  pad(ORGANIC,25) +findItemCost(ORGANIC) +"\n"+
  pad(BIONICS,25) +findItemCost(BIONICS) +"\n"+
  pad(BLADES,25)  +findItemCost(BLADES)  +"\n"+
  pad(EFLUX,25)   +findItemCost(EFLUX)   +"\n"+
  pad(MFLUX,25)   +findItemCost(MFLUX)   +"\n"+
  pad(HFLUX,25)   +findItemCost(HFLUX)   +"\n"+
  pad(GLIMMER,25) +findItemCost(GLIMMER) +"\n"+
  pad(EMT,25)     +findItemCost(EMT)     +"\n"+
  pad(MATTER,25)  +findItemCost(MATTER)  +"\n"+
  pad(ARMOR,25)   +findItemCost(ARMOR)   +"\n"+
  "________________________________________\n");
}


void showItemfunc(object ob, object me) {
/* This function is used to determine a player's enhancements */
/* ob stores the member of interest, me stores the checker */
  tell_object(me, "______________________________\n");
  if((status)IPOB->item_eyes())       tell_object(me, "cybereyes\n");
  if((status)IPOB->item_corpse())     tell_object(me, "organic converter\n");
  if((status)IPOB->item_activate_droid()) tell_object(me, "droid\n");
  if((status)IPOB->item_stun())       tell_object(me, "stun ray\n");
  if((status)IPOB->item_bionics())    tell_object(me, "bionics\n");
  if((status)IPOB->item_blades())     tell_object(me, "blades\n");  
  if((status)IPOB->item_electricflux()) tell_object(me, "electric flux\n");
  if((status)IPOB->item_magneticflux()) tell_object(me, "magnetic flux\n");
  if((status)IPOB->item_heatflux())   tell_object(me, "heat flux\n");
  if((status)IPOB->item_flash())      tell_object(me, "biolight\n");
  if((status)IPOB->item_emt())        tell_object(me, "emotion controller\n");
  if((status)IPOB->item_legs())       tell_object(me, "leg actuators\n");
  if((status)IPOB->item_convert())    tell_object(me, "matter converter\n");
  if((status)IPOB->query_armor())     tell_object(me, "sub-dermal armoring\n");
  if((status)IPOB->item_weplink())    
    tell_object(me, "smartweapon link ["+(int)IPOB->item_weplink()+"]\n");
  tell_object(me, "______________________________\n");
}


void inUse(object ob) {
  write("\n    ENHANCEMENTS IN USE   \n\n");
  if((status)IPOB->query_blad_on())  write(RED+"  Blades"+OFF+"\n");
  if((status)IPOB->query_bion_on())  write(RED+"  Bionics"+OFF+"\n");
  if((status)IPOB->query_armor_on()) write(BROWN+"  SubDermal Armor"+OFF+"\n");
  if((status)IPOB->query_regen())    write(BLUE+"  Regeneration"+OFF+"\n");
  if((status)IPOB->query_rejuv())    write(BLUE+"  Rejuvenation"+OFF+"\n");
  if((status)IPOB->query_convert_on()) write(GREEN+"  Conversion"+OFF+"\n");
  if((status)IPOB->query_equil())    write(GREEN+"  Equilibration"+OFF+"\n");
  if((status)IPOB->query_digest())   write(BOLD+"  Digestion"+OFF+"\n");
  if((status)IPOB->query_light_on()) write(YELLOW+"  Biolight"+OFF+"\n");
  write("\n");
}


status purchase(object ob, string str) {
/* Way to buy new enhancements */
  int cost;
  if(!IPOB) return 0;
  if(!str) return 0;
  if(findItemCost(str) == -1) {
    tell_object(ob, "No such enhancement.\n");
    return 0;
  }
  if(hasItem(ob, str) == 2) {
    tell_object(ob, "Only one of this type of enhancement allowed.\n");
    return 0; 
  }
  if(hasItem(ob, str)) {
    tell_object(ob, "You already have the "+str+"\n");
    return 0; 
  }
  cost = findItemCost(str);
  if(IPOB->balance() < cost) {
    tell_object(ob, "Insufficient credits to buy the "+str+"\n");
    return 0; 
  }
  IPOB->addToBalance(-cost);
  setItem(ob, str);
  write_file(LOGDIR + "/PURCHASE",
    ORN+" purchased the "+str+" enhancement. ("+ctime()+")\n");
  tell_object(ob, "You purchase the "+str+"\n");
  IPOB->save_me();
  move_object(IPOB, ob); /* force init */
  return 1;
}

string showStatus(object ob) {
  int hp, mhp, sp, msp, shp, ssp;
  hp = (int)ob->query_hp();
  mhp = (int)ob->query_mhp();
  sp = (int)ob->query_sp();
  msp = (int)ob->query_msp();
  shp = 10 * hp / mhp;
  ssp = 10 * sp / msp;
  return("HP: "+shp+"/10  SP: "+ssp+"/10");
}
