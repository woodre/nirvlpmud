#include "../DEFS.h"

add_recruitpair(str){
  sscanf(str,"%s|%s",recruiter,recruitee);
