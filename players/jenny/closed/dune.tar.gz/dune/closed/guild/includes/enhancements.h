/* Enhancements */
#ifndef  _ENHANCEMENTS_H_
#define  _ENHANCEMENTS_H_

/* Flux damage monitor */
#define FLUX_DAMAGE "/players/dune/closed/guild/includes/flux_damage.h"

/* Enhancement names, for identification purposes */
#define EYES      "cybereyes"
#define ORGANIC   "organic_converter"
#define DROID     "droid"
#define BIONICS   "bionics"
#define BLADES    "blades"
#define EFLUX     "electric_flux"
#define MFLUX     "magnetic_flux"
#define HFLUX     "heat_flux"
#define GLIMMER   "biolight"
#define EMT       "emotion_controller"
#define MATTER    "matter_converter"
#define ARMOR     "subdermal_armor"


/* Enhancement energy (spell point) requirements */
#define ENERGY_BIONICS    15
#define ENERGY_BLADES     10
#define ENERGY_DROID      20
#define ENERGY_EFLUX      40
#define ENERGY_EMT        100
#define ENERGY_GLIMMER     2
#define ENERGY_HFLUX      40
#define ENERGY_MFLUX      40
#define ENERGY_OVERLOAD    1
#define ENERGY_TARGET     40


/* Enhancement monetary requirements */
#define COST_GLIMMER  10000
#define COST_EYES     50000
#define COST_EFLUX    20000
#define COST_MFLUX    20000
#define COST_HFLUX    20000
#define COST_BLADES   30000
#define COST_ARMOR    40000
#define COST_EMT      40000
#define COST_MATTER   50000
#define COST_ORGANIC  60000
#define COST_BIONICS  60000
#define COST_DROID    70000

#endif
