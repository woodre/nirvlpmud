/* Honor levels */
#ifndef  _HLEVELS_H_
#define  _HLEVELS_H_


/* Honor titles */
#define HONOR_TITLE_MIN      "Baneling"
#define HONOR_TITLE_MD1      "Poor"
#define HONOR_TITLE_MD2      "Newbie"
#define HONOR_TITLE_MD3      "Moderate"
#define HONOR_TITLE_MD4      "High"
#define HONOR_TITLE_MD5      "Savant"
#define HONOR_TITLE_MAX      "Divine"


/* Honor level requirements */
#define HONOR_LEVEL_MD1      -9
#define HONOR_LEVEL_MD2       0
#define HONOR_LEVEL_MD3      30
#define HONOR_LEVEL_MD4      60
#define HONOR_LEVEL_MD5      110
#define HONOR_LEVEL_MAX     200


/* Honor award/punishment amounts */
#define HONOR_AWARDNUM_MIN    1
#define HONOR_AWARDNUM_MD1    2
#define HONOR_AWARDNUM_MD2    3
#define HONOR_AWARDNUM_MD3    4
#define HONOR_AWARDNUM_MD4    5
#define HONOR_AWARDNUM_MAX   10


/* Honor award/punishment range names */
#define HONOR_AWARDNAME_MIN  "small"
#define HONOR_AWARDNAME_MD1  "medium"
#define HONOR_AWARDNAME_MD2  "large"
#define HONOR_AWARDNAME_MD3  "huge"
#define HONOR_AWARDNAME_MD4  "monstrous"
#define HONOR_AWARDNAME_MAX  "godly"


#endif
