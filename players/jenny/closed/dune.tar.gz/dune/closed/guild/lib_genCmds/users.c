#include "../DEFS.h"
#include DEFS_ALEVELS
#include DEFS_OFFICES

status main(string str) {
  int b, artlev, deg, honor;
  string brand, type, art, role, sphere;
  object * iter;
  object ob;
  string line;
  line = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
        "~~~~~~~~~~~~~~~~~~~~~~~\n";
  write("\n");
  write(line);

  write(BOLD+YELLOW+"  "+
        pad("Ninja",       12)+
        pad("Sensei",      12)+
        pad("Honor",        9)+
        pad("Chip",        13)+
        pad("Belt",         9)+
        pad("Guild Rank",  22)+
        OFF+"\n");
  write(line);

  iter = users();
  for(b=0;b<sizeof(iter);b+=1)  {
    if(!iter[b]->query_invis()) {
      if(present(GUILD_ID, iter[b]))  {
        ob     = iter[b];

        /* do not show muffled guild wizzes at all */
        if(IPOB->guild_wiz() && IPOB->muffled()) continue;

      if((string)IPOB->query_brand())
        brand  = capitalize((string)IPOB->query_brand());
        artlev = (int)IPOB->query_art_level();
        deg    = artlev - BLACK_BELT;
        role   = (string)call_other(OFFICED, "findRole", ob);
        if(deg <= 0 ) deg = 0;
        if(IPOB->muffled() > 0) write("X");
        else write(" ");
        if( (role == RUBY) && !IPOB->guild_wiz()) write("*");
        else write(" ");
        write(BOLD);
        if(ob->query_pl_k())
        write(RED);
        write(pad(capitalize((string)ob->query_name()), 12));
        write(OFF);
        if(IPOB->query_recruiter())
        write(pad(capitalize((string)IPOB->query_recruiter()), 12));
        else
        write("            ");
        honor = (int)IPOB->query_honor();
      if(!IPOB->query_nohonor()) {
         write(pad((string)call_other(HLEVELD, "honorTitle", honor), 9)); }
        else write(pad("Renegade", 9));

        if((string)IPOB->query_stone() == "adamantium") {
          sphere = (string)IPOB->query_sphere();
/*added by wocket*/
if(environment(IPOB)==find_player("jareel")){
write("---   "+GREEN+"Knight Informant"+OFF+"    ---");
}
else
if(environment(IPOB)==find_player("wocket")){
write("---    "+RED+"Demigod of Cybernetica"+OFF+"    --- ");
}
else
/*end additon*/
          write(pad("---    "+RED+
            (string)call_other(OFFICED, "findSphere", ob, sphere)+OFF+"    ---", 53));
        }
        else {
          write(pad(brand, 12));
          write(" ");
          if(deg > 0)
            write(pad((string)call_other(ALEVELD, "findBeltColor", artlev)+" "+deg,9));
          else write(pad((string)call_other(ALEVELD, "findBeltColor", artlev),9));
          if(!role) type = 
            (string)call_other(GLEVELD, "guild_title", (int)IPOB->guild_lev() + artlev);
          else type = capitalize(role);
          write(pad(type, 22));
        }
        write("\n");
      }
    }
  }

  write(line);
  write("Note:  * = Sensei    X = Muffled\n");
  return 1;
}
