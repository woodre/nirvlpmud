#include "../DEFS.h"

status main(string str) {
  /* Shows xp and title for each guild level */
  call_other(GLEVELD,"chipList",TP);
  return 1;
}
