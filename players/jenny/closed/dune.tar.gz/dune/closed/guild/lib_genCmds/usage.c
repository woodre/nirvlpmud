#include "../DEFS.h"

status main(string str) {
  call_other(ENHANCEMENTD, "inUse", TP);
  return 1;
}
