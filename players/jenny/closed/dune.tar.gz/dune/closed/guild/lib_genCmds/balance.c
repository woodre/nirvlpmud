#include "../DEFS.h"

status main(string str) {
   write("Your credit balance is: @ " + IPTP->balance() + "\n");
   return 1;
}
