#include "../DEFS.h"

status main(string str) {
  write("Connecting to CyberNinja Database...\n");
  previous_object()->restore_me();
  write("Ok.\n");
  return 1;
}
