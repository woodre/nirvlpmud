#include "../DEFS.h"
int title_count;
string *titlelist;
string stone;
int alev, glev;

main(str){
int i,a;
string new_title;
string new_pretitle;
  alev = (int)IPTP->query_art_level();
  glev = (int)IPTP->guild_lev();
  stone = IPTP->query_stone();
  get_titles();
if(!str){
  write_titles();
  return 1;
}
if("list" == str){
  write_titles();
  return 1;
}
sscanf(str,"%d",a);
i = member_array(a,titlelist);
if(-1 == i){
  notify_fail("That is not a valid option.\n");
  return 0;
}
new_title = titlelist[i+1];
new_pretitle = get_pretitle(alev);
  this_player()->set_pretitle(new_pretitle);
  this_player()->set_title(new_title);
  write("Your new pretitle is: "+new_pretitle+"\n");
  write("Your new title is: "+new_title+"\n");
  return 1;
}

get_titles(){
  title_count = 0;
  titlelist = ({ });
  if(glev  > 2){
    titlelist += ({ title_count+1,"the NetRunner",});
    title_count++;
  }
  if(glev > 5){
    titlelist += ({ title_count+1,"the CyberMechanic",});
    title_count++;
  }
  if(glev > 9){
    titlelist += ({ title_count+1,"the CyberMaster",});
    title_count++;
  }
  if(alev > 2){
    titlelist += ({ title_count+1,"the CyberZenist",});
    title_count++;
  }
  if(alev > 5){
    titlelist += ({ title_count+1,"the CyberWarrior",});
    title_count++;
   }
  if(alev > 9){
    titlelist += ({ title_count+1,"the NinjaWarrior",});
    title_count++;
  }
  if(alev > 15){
    titlelist += ({ title_count+1,"the NinjaMaster",});
    title_count++;
  }
  if(alev+glev > 26){
    titlelist += ({ title_count+1,"the CyberNinja Grandlord",});
    title_count++;
  }
switch(stone){
  case "onyx": titlelist += ({ title_count+1,BOLD+BLUE+"the Guardian of Cybernetica"+OFF,});
    title_count++; 
    break;
  case "emerald": titlelist += ({ title_count+1,BOLD+GREEN+"the Intellect of Cybernetica"+OFF,});
    title_count++;
     break;
  case "sapphire": titlelist += ({ title_count+1,BOLD+RED+"the Directive of Cybernetica"+OFF,});
    title_count++;
    break;
  case "topaz": titlelist += ({ title_count+1,"\b, "+BOLD+YELLOW+"the Shidoshi of Cybernetica"+OFF,});
    title_count ++;
    break;
  case "diamond": titlelist += ({ title_count+1,BOLD+"the Chosen One"+OFF,});
    title_count++;
    break;
  default: break;
}
  titlelist += ({title_count+1,YELLOW+"the CyberNinja"+OFF,});
  title_count++;
if(IPTP->query_nohonor()){
  title_count = 1;
  titlelist = ({title_count,RED+"the Renegade"+OFF});
}
}

get_pretitle(alev){
  if(alev > 16) return "Grand Master";
  if(alev > 9) return "Sensei";
  if(alev) return "Warrior";
  return "|";
}
write_titles(){
int i,a;
  write("A list of titles you may choose from:\n");
for(i=0,a=sizeof(titlelist);i<a;i++){
  write("\t["+BOLD+titlelist[i]+OFF+"]\t"+titlelist[i+1]+"\n");
  i++;
}
write("Usage: set_title <number>\n");
return 1;
}
