#include "../DEFS.h"

status main(string str) {
  write("You tap into the cybernet news...\n");
  cat(NEWS);
  write("You close the news connection.\n");
  return 1;
}
