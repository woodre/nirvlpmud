#include "../DEFS.h"

status main(string str) {
/* Process for becoming a CyberNinja Renegade */
  if(!str) {
    write("Usage: renegade <yes/no>.\n\tBe sure to read 'cyber renegade'\n\n");
    write("Current mode: "+BOLD);
    if((int)IPTP->query_nohonor() == 0) write("HONORABLE");
    if((int)IPTP->query_nohonor() == 1) write("RENEGADE");
    write(OFF+"\n");
    return 1; 
  }
  if(str == "yes") {
     if(IPTP->query_nohonor()) { write("You are already Renegade.\n"); return 1; }
    IPTP->set_nohonor();
     write(BOLD+"YOU ARE NOW A RENEGADE CYBERNINJA\n"+
        "NO CYBERNINJA HONOR RULES APPLY.\n\n"+OFF);
    IPTP->set_honor(-5);
      IPTP->save_me();
     call_other(CHANNELD, "overchannel",TPN+" has become a Renegade!\n");
    return 1;
  }
  if(str == "no") {
     if(!IPTP->query_nohonor()) { write("You already follow the Path.\n"); return 1; }
    write("You must now petition Dune or Snow to regain honor status.\n"); return 1; 
     IPTP->remove_nohonor();
     write(BOLD+"\nYou return to the Path of Honor.\n\n"+OFF);
     if(IPTP->query_honor() > 0) IPTP->set_honor(0);
      IPTP->save_me();
     call_other(CHANNELD, "overchannel",TPN+" has returned to the Path!\n");
    return 1;
  }
  write("Usage: renegade <yes/no>.\n\tBe sure to read 'cyber renegade'\n\n");
  return 1;
}
