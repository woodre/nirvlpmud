#include "../DEFS.h"

status main(string str) {
  /* Gives cost of experience for each belt level */
  call_other(ALEVELD, "list", TP);
  return 1;
}
