#include "../DEFS.h"

status main(string str) {
/* shows all enhancements the person has */
  object ob;
  if(!str) {
    write("Your enhancements are....\n");
    call_other(ENHANCEMENTD, "showItemfunc", TP, TP);
    return 1; 
  }
  if(!find_player(str) || find_player(str)->query_invis() > 18) {
    write("No such player.\n");
    return 1; 
  }
  ob = find_player(str);
  if(!IPOB) {
    write(OPN+" is not a guild member.\n");
    return 1; 
  }
  if(IPTP->guild_officer() || call_other(OFFICED, "checkStone",TP,"ruby")){
    write(OPN+"'s enhancements are....\n");
    call_other(ENHANCEMENTD, "showItemfunc", ob, TP);
    return 1; 
  }
  return 1;
}
