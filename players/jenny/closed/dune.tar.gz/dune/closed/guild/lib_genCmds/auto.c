#include "../DEFS.h"

status main(string str) {
  /* sets automatics */
  if(!str) {
    write("Usage: auto [ on/off");
    if(IPTP->item_corpse()) write("/reg/rej");
    if(IPTP->item_blades()) write("/blad");
    if(IPTP->item_bionics()) write("/bion");
    write(" ]\n");
    return 1; 
  }
  if(str == "on") {
    IPTP->set_auto(1);
    write("Your automatics are now on.\n");
    return 1;
  }
  if(str == "off") {
    IPTP->set_auto(0);
    write("Your automatics are now off.\n"); 
    return 1; 
  }
  if(str == "reg" && IPTP->item_corpse()) {
    if(IPTP->query_auto_reg()) {
      IPTP->set_auto_reg(0);
      write("You turn off your auto regeneration.\n"); 
      return 1; 
    }
    IPTP->set_auto_reg(1);
    write("You activate your auto regeneration.\n"); 
    return 1; 
  }
  if(str == "rej" && IPTP->item_corpse()) {
    if(IPTP->query_auto_rej()) {
      IPTP->set_auto_rej(0);
      write("You turn off your auto rejuvenation.\n"); 
      return 1; 
    }
    IPTP->set_auto_rej(1);
    write("You activate your auto rejuvenation.\n"); 
    return 1; 
  }
  if(str == "blad" && IPTP->item_blades()) {
    if(IPTP->query_auto_blad()) {
      IPTP->set_auto_blad(0);
      write("You turn off your auto blades.\n"); 
      return 1; 
    }
    IPTP->set_auto_blad(1);
    write("You activate your auto blades.\n"); 
    return 1; 
  }
  if(str == "bion" && IPTP->item_bionics()) {
    if(IPTP->query_auto_bion()) {
      IPTP->set_auto_bion(0);
      write("You turn off your auto bionics.\n"); 
      return 1; 
    }
    IPTP->set_auto_bion(1);
    write("You activate your auto bionics.\n"); 
    return 1; 
  }
  else write("You have chosen an invalid auto.\n");
  return 1;
}