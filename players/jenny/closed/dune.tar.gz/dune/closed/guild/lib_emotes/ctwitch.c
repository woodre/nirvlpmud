/*  Emote:  cyber kneel     by: Eurale   */

#include "../DEFS.h"

status main(string str) {

write("You twitch and spark, regaining your composure.\n");
say(TPN+" twitches and sparks, regaining "+TP->query_possessive()+" composure.\n"); 

return 1; }
