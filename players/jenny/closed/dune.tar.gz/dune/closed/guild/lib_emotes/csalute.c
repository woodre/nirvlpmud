/*  Emote:  weapon salute     by: Eurale   */

#include "../DEFS.h"

status main(string str) {
  string wep;
  wep = (string)IPTP->query_weapon();
  if(wep == "unarmed") wep = "fist";
  wep = capitalize(wep);

write("You raise your "+wep+" in a formal salute.\n");
say(TPN+" raises "+TP->POS+" "+wep+" in a formal salute.\n");

  return 1;
}
