/*  Emote:  cyber kneel     by: Eurale   */

#include "../DEFS.h"

status main(string str) {

write("You tighten your belt and prepare for battle.\n");
say(TPN+" tightens "+TP->query_possessive()+" belt and prepares for battle.\n");

return 1; }
