/*  Emote:  cyber kneel     by: Eurale   */

#include "../DEFS.h"

status main(string str) {
  object targ;

if(!str) {
write("You grin cybernetically.\n");
say(TPN+" grins cybernetically.\n");
  return 1; }
targ = find_player(str);
  if(!targ || targ->query_invis() > 18) {
  write(capitalize(str)+" is not online.\n");
  return 1; }
  if(environment(targ) == environment(TP)) {
  write("You grin cybernetically at "+capitalize(str)+".\n");
  say(TPN+" grins cybernetically at "+capitalize(str)+".\n");
  return 1; }
  else {
  write("You grin cybernetically at "+capitalize(str)+" from afar.\n");
  tell_object(targ,TPN+" grins cybernetically at you from afar.\n");
  return 1; }

return 1; }
