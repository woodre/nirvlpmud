/*  Emote:  cyber kneel     by: Eurale   */

#include "../DEFS.h"

status main(string str) {

if(!str) {
write("You kneel down on one knee and lower your head in reverence.\n");
say(TPN+" kneels down on one knee and lowers "+TP->POS+" head in "+
	"reverence.\n");
  return 1; }
else {
  write("You kneel down in front of "+capitalize(str)+" and lower\n"+
	"your head in reverence.\n");
  say(TPN+ " kneels down in front of "+capitalize(str)+" and lowers\n"+
	TP->POS+" head in reverence.\n");
  return 1; }

return 1; }
