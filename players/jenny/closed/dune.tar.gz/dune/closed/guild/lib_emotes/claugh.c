/*  Emote:  cyber kneel     by: Eurale   */

#include "../DEFS.h"

status main(string str) {

write("You laugh so hard your Flux generators spark and flare!\n");
say(TPN+" laughs so hard "+TP->query_possessive()+
  " Flux generators spark and flare!\n");

return 1; }
