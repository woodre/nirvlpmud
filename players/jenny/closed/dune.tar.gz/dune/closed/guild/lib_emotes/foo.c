/* 
 * CyberNinja emote: foo
 * Author: Dune
 */
#include "../DEFS.h"

/* this is an example emote, modify only where specified */
status main(string str) {

  /* modify the write and say functions below */
  write("You raise your head to the stars and foo.\n");
  say(TPN+" raises "+TP->POS+" head to the stars and foos.\n");

  return 1;
}
