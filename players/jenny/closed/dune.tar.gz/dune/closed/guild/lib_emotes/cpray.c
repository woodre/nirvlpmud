/* Emote: cyber pray     By:  Snow */

#include "../DEFS.h"

status main(string str) {

if(!str) {
write("You pray to the dark gods for success.\n");
say(TPN+" prays to the dark gods for success.\n");
  return 1; }
if(str == "snow" || str == "dune") {
  write("You pray to "+capitalize(str)+" for success.\n\n");
  if(random(6) == 1) write("\t\t"+capitalize(str)+" gives you a dark blessing.\n\n");
  say(TPN+" prays to "+capitalize(str)+" for success.\n");  return 1; }
else {
  write("You pray to "+capitalize(str)+" for success.\n");
  say(TPN+" prays to "+capitalize(str)+" for success.\n");
  return 1;  }

return 1; }
