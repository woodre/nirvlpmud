#include "/players/dune/closed/guild/lib/DEFS.h"
#include "/players/dune/closed/guild/lib/COLOR.h"

get() { return 0; }
query_weight() { return 0; }
query_value() { return 0; }
id(str) { return str == "cyberdaemon" ||
                 str == "processor" ||
                 str == "computer" ||
                 str == "CYBERDAEMON"; }

string oldphase, phase;

short() { return "CYBERDAEMON, the CyberNinja Central Processor"; }
long() {
      write(   
"     CYBERDAEMON is the central processing unit for the CyberNinja\n"+
"guild. It towers high above and around you. Various sub-supercomputer\n"+
"hubs connect via white-hot high bandwidth links to create a web\n"+
"of pure computation. At the center, a black orb sparkles with\n"+
"multitudes of atomic stardust process executions. Within the dazzling\n"+
"black orb floats a tiny blue chrysanthemum. For along with all the\n"+
"incredible quantitative might before you, a precious natural element\n"+
"maintains a perfect system-wide balance.\n"+
"     You may view the system 'diags' to display the current computation\n"+
"phase. CYBERDAEMON runs in cycles of repeating phases which act to\n"+
"change and control energy flow and network routing between CyberNinjas.\n");
}

init() {
  add_action("readmap","diags");
  if( (RN == EMP1) || (RN == EMP2) ||
      (TP->query_level() >= 100) ) {
     add_action("forcephase","forcephase");
     add_action("history", "phases");
     }
  }

reset(arg) {
   computer_sequence();
   if(!arg) {}
   }

computer_sequence() {
  int tyme, phasenum;

  /* get the current time in seconds, since 1970 */
  tyme = time();
  /* reduce it to the last 12 hours */
  while(tyme > 10000000000) tyme -= 10000000000;
  while(tyme > 1000000000) tyme -= 1000000000;
  while(tyme > 100000000) tyme -= 100000000;
  while(tyme > 10000000) tyme -= 10000000;
  while(tyme > 1000000) tyme -= 1000000;
  while(tyme > 100000) tyme -= 100000;
  while(tyme > 43200) tyme -= 43200;
  /* convert from seconds to hours */
  tyme = tyme / 3600;
  /* monthnum in a range of 0 to 12 hours */
  phasenum = tyme;

  switch(phasenum) {  /* phases change every 1 hour */
   case 0:      phase = "solosomatic"; break;
   case 1:      phase = "metamorphic"; break;
   case 2:      phase = "halcyon nexus"; break;
   case 3:      phase = "neurosonic"; break;
   case 4:      phase = "holotech"; break;
   case 5:      phase = "robotronic"; break;
   case 6:      phase = "synthellectual"; break;
   case 7:      phase = "hyperdream"; break;
   case 8:      phase = "androidal"; break;
   case 9:      phase = "cybernautic"; break;
   case 10:     phase = "teledigital"; break;
   case 11..12: phase = "deathmachine"; break;
   }

  if(phase != oldphase) {
   say("CyberDaemon says: phase transformation executed.\n");
   cyberdaemon_talk(CAP(phase)+" phase transformation executed\n");
   oldphase = phase;
   }
  call_out("computer_sequence", 300);
  return 1; 
} /* end computer_sequence()

string query_phase() { return phase; } /* let other objects find */
                                       /* out what phase it is   */

forcephase() { 
  say(TPN+" tinkers with a few of CyberDaemon's switches and buttons.\n");
  write("Jumpstarting CyberDaemon phase sequence.\n");
  computer_sequence(); 
  return 1; 
}

history() {
  write("Phase List of CyberDaemon:.\n");
  write(  "solosomatic\n"+
          "metamorphic\n"+
          "halcyon nexus\n"+
          "neurosonic\n"+
          "holotech\n"+
          "robotronic\n"+
          "synthellectual\n"+
          "hyperdream\n"+
          "androidal\n"+
          "cybernautic\n"+
          "teledigital\n"+
          "deathmachine\n");
  return 1;
}

readmap() {
  say(TPN+" analyzes CyberDaemon's diagnostics.\n");
  write("~~~~~CyberDaemon Diagnostics~~~~~\n");
  write("CyberDaemon is in the "+CAP(phase)+" phase.\n");
  return 1;
}

cyberdaemon_talk(str) {
  if(!str) return 1;
  overchannel("Msg from CyberDaemon: "+str+"\n");
  return 1;
}

overchannel(str) {
/* For announcements */
   object everyone, member;
   int i;
   everyone = users();
   for(i = 0; i < sizeof(everyone); i++) {
      member = present("implants", everyone[i]);
      if(member && member->muffled() < 1) 
        tell_object(everyone[i],
                 BLINK+BOLD+"<<_CYBERNET_>>>"+OFF+OFF+" "+str+"\n");
      }
   return 1;
}
