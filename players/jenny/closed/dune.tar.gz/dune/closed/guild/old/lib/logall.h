#include "DEFS.h"

all_file_watcher(string str) {
  string file;
  if(!str) {
    write("You may access the following data logs.\n");
   ls(log);
    return 1; }
  file = log +""+ str;
  if(file_size(file) >= 0) {
    write("You access the "+str+" data log.\n");
    call_other(MOREPATH, "more_file", file);
    return 1; }
  write("There is no "+str+" data log.\n");
  return 1; }
