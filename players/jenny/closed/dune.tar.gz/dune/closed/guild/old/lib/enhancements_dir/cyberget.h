#include "../DEFS.h"

cyber_get(str) {
    string item;
    string container;
    object item_o;
    object container_o;
    int weight;

    if (!str) {
        write("Usage: cyberget <item>\n");
        return 1; }
    if (TP->query_ghost()) {
        write("Your incorporeal hand passes right through it.\n");
        return 1; }

    if (str == "all") {
      get_all(environment(TP));
        return 1; }

    if (sscanf(str, "%s from %s", item, container) != 2) {
        if(!PRE(str,ENV(TP))) {
          write(BOLD+"[[ "+OFF+GREEN+str+OFF+BOLD+" ]] is not here."+
                OFF+"\n");
        return 1; }
        else if(get_ob(PRE(str,ENV(TP))) == 2) 
             say(TPN+" takes: "+str+ ".\n");
        return 1; }
    container_o = present(container,TP);
    if(!container_o) container_o = PRE(container,ENV(TP));
    if (!container_o) {
        write("  [[ "+GREEN+container+OFF+" ]] is not here.\n");
        return 1; }
    if (!call_other(container_o, "can_put_and_get", 0)) {
        write("You can't do that!\n");
        return 1; }
    if (item == "all") {
        get_all(container_o);
        return 1; }
    item_o = present(item, container_o);
    if(!item_o) {
      write("There is no "+item+" in the "+container+".\n");
      return 1; }
    if(get_ob(item_o) == 2) {
    weight = item_o->query_weight();
    call_other(container_o, "add_weight", -weight);
    say(TPN+" takes "+item+" from "+container+".\n"); }
    return 1;
}



get_all(object from) {
  object ob, ob2;
   ob = first_inventory(from);
  while(ob) {
    ob2 = next_inventory(ob);
   if(get_ob(ob) == 2)
   say(TPN+" takes: "+ob->short()+ ".\n");
    ob = ob2;
  }
}



get_ob(object ob) {
  int weight;
  string item;
  if(  ob->short() && ob->get() && !ob->query_invis() &&
       !living(ob) && !call_other(ob, "drop", 1) &&
     !call_other(ob, "id", "soul") ) {
      weight = call_other(ob, "query_weight");
      item = ob->short();
      if(TP->add_weight(weight)) {
        write(BOLD+"You take [[ "+OFF+GREEN+item+OFF+BOLD+" ]]"+OFF+"\n");
        transfer(ob, this_player());
        TP->recalc_carry();
        return 2;
       }
    else
    write(BOLD+"[[ "+OFF+GREEN+item+OFF+BOLD+
               " ]] is too heavy or ungettable."+OFF+"\n");
  return 1; }
  return 0;
}
