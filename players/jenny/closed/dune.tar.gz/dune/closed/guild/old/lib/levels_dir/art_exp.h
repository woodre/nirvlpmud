#include "../DEFS.h"

int art_exp(int level) {
 int xp;
 switch(level) {
   case 1:    xp = 5000; break;
   case 2:    xp = 15000; break;
   case 3:    xp = 30000; break;
   case 4:    xp = 60000; break;
   case 5:    xp = 100000; break;
   case 6:    xp = 120000; break;
   case 7:    xp = 150000; break;
   }
 return xp;
}
