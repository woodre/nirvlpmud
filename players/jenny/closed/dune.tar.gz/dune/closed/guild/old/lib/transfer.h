#include "DEFS.h"

goToGuild() {
  object here;
  string here_realm;
  here = environment(this_player());
  here_realm = here->realm();
  if(TP->query_spell_point() < 40) {
    write("You cannot atomize yourself, you are too low on power.\n");
    return; }
  if(here_realm == "NT") {
    write("Matter transfer is too dangerous from your location.\n");
    return; }
  say(TPN+"s body vaporizes into nothing.\n");
  write("Your body disintegrates into invisible matter particles.\n");
  write("A magnetic transfer beam sucks you away...\n\n");
  TR("/players/snow/closed/cyber/rooms/teleport.c",
    TPN+" transfers in.\n");
  move_object(this_player(),
    "/players/snow/closed/cyber/rooms/teleport.c");
  command("look",TP);
  call_other(TP, "add_spell_point", -40);
}
