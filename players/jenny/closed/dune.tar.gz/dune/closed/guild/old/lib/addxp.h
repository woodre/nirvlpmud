#include "DEFS.h"

addxp(string str) {
/* Used for guild xp promotion/demotion/setting */
  int amount;
  string who;
  object ob;
  if(!str) {
    write("Usage: addxp <member> <amount>.\n");
    return;}
  if(!sscanf(str, "%s %d", who, amount)) {
    write("Usage: addxp <member> <amount>.\n");
    return;}
  ob = find_player(who);
  if(!IPOB) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  IPOB->add_xp(amount);
  ob->add_guild_exp(amount);
  ob->save_me();
  IPOB->save_me();
  if(amount >= 0)
    write("You alter "+capitalize(who)+"'s guild xp by +"
      +amount+".\n");
  else write("You alter "+capitalize(who)+"'s guild xp by "
      +amount+".\n");
  write_file(log+"ADDXP", RN+" altered "+ob->query_real_name()+
                          "'s guild xp by "+amount+". ("+ctime()+")\n");
}
