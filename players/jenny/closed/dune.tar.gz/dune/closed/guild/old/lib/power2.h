#include "DEFS.h"

power_wield2(str) {
  object meat;
  if(GLEV < 6) return 1;
  if(TP->query_level() < 12) {
    write("You must be player level 12 to use this.\n"); return 1; }
  if(str) {
    meat = PRE(str, ENV(TP) );
    if(!meat) { write("You cannot see [ "+str+" ] here.\n"); RE; }
  }
  if(!str) {
    meat = MEAT;
    if(!meat) {
      write("What do you want to power2?\n"); RE; }
  }
  if(!meat || !PRE(meat, ENV(TP)) ) {
    write("Your opponent is not here to fight.\n"); RE; }
  TP->spell_object(meat,"Power Wield",random(24)+8,20,
               "You strike viciously into "+
                capitalize(meat->query_real_name())+".\n",
               TPN+" strikes viciously into you!\n",
               TPN+" strikes viciously into "+
                   capitalize(meat->query_real_name())+".\n");
return 1;
}
