#include "DEFS.h"

info_database(string str) {
/* takes str and refers to files in docs directory */
  string file, topic, all;
  if(!str) {
     cat(DOCPATH+"main_menu");
    return; }
  if(sscanf(str, "%s %s", topic, all)) {
     file = DOCPATH +""+ topic;
    file = shorted_file(file);
    if(all == "all") {
      if (file_size(file) >= 0) {
        cat(file);
        return; }
      else {
        write("There is no help on that cyber topic.\n");
        return; }
      }
    if(all != "all") {
      write("Usage: cyber [topic]   or   cyber [topic] all.\n");
      return; }
    }
  if(sscanf(str, "%s", topic)) {
      file = DOCPATH +""+ topic;
      file = shorted_file(file);
      if (file_size(file) >= 0) {
         if(find_menu(file)) {
           cat(file);
           return; }
         call_other(MOREPATH, "more_file", file);
         return; }
      write("There is no help on that cyber topic.\n");
      return; }
  write("Usage: cyber [topic]   or   cyber [topic] all.\n");
}
