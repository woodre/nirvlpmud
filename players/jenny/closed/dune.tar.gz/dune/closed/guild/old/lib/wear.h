#include "DEFS.h"

wear(string str) {
/* Ninjas are unable to wear armor  */
  write("CyberNinjas use Ninjitsu, not armor.\n");
  return 1;
}
