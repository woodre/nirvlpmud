#include "DEFS.h"

set_guild_title() {
/* Changes the member's guild title */
  string new_title;
  if(IP(TP)) {
    new_title = guild_title(IP(TP)->guild_lev());
    if(new_title == "defective") {
       write("There is no title for your quality level.\n");
       write("Please have your quality level changed.\n");
       return; }
    TP->set_title(new_title);
    write("Your title is now "+new_title+".\n");
    TP->save_character();
    return;}
}
