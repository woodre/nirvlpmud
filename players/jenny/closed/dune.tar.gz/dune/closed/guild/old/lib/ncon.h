#include "DEFS.h"

n_con() {
  int hps, sps;
  string name, loc;
  int b;
  object ob;
  ob = users();
  write("\n");
  write("<>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
        "~~~~~~~~~<>\n"+
  " Ninja           HP    SP     Location\n"+
  "<>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
        "~~~~~~~~~<>\n");
  for(b=0;b<sizeof(ob);b+=1) {
  if(!ob[b]->query_invis()) {
      if(present("either implants",ob[b])) {
  name = ob[b]->query_name();
  loc = environment(ob[b])->short();
  hps = (ob[b]->query_hp() * 100) / ob[b]->query_mhp();
  sps = (ob[b]->query_sp() * 100) / ob[b]->query_msp();
  write(" "+
    pad(name,15)+" "+pad(hps+"%",5)+" "+pad(sps+"%",7)+" "+loc+"\n");
      }
    }
  }
  write("<>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
        "~~~~~~~~~<>\n");
  return 1;
}
