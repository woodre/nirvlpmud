#include "DEFS.h"

new_start() {
  if(TP->query_home() == "/room/church.c" ||
     TP->query_home() == "room/church.c"  ||
     TP->query_home() == "/room/church"   ||
     TP->query_home() == "room/church"    ) {
     call_other(TP,"set_home",
                   "/players/snow/closed/cyber/rooms/guildhall.c");
     TP->save_me();
     write("You will now start in CyberNinja Grand Hall.\n");
     return 1; }
  write("You will now start in the Church.\n");
  call_other(TP,"set_home","/room/church.c");
  TP->save_me();
  return 1;
}
