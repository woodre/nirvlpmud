#include "DEFS.h"

log_my_deathmatch(string jumble) {
  object winner, loser;
  string mename, targname;
  if(!IP(TP)->query_deathmatch_permission()) return 0;
  sscanf(jumble, "%s %s", mename, targname);
  winner = find_player(mename);
  loser  = find_player(targname);
  write_file("/players/dune/closed/guild/deathmatches/"+
    winner->query_real_name(), capitalize(winner->query_name())+
    " (level "+winner->query_level()+
    ") killed "+loser->query_real_name()+
    " (level "+loser->query_level()+") on "+ctime()+".\n");
  IP(TP)->get_deathmatch_permission(0);
  return 1;
}
