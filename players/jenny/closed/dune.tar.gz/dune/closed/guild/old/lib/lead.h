#include "DEFS.h"

lead() {
  object ob;
  if(TP->query_spell_point() < 10) {
    write("You are too drained to do this.\n");
    return 1; }
  if(!TP->query_attack()) {
    write("You cannot lead a fight when not in combat.\n");
    return 1; }
  ob = TP->query_attack();
  TP->add_spell_point(-10);
  ob->attack_object(TP);
  TP->attack_object(ob);
  write("You boldly step into the heat of the battle!\n");
  say(TPN+" boldy steps into the heat of the battle!\n");
  return 1;
}
