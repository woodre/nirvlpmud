#include "../DEFS.h"

blades() {
  /* added dmg enhancement */
  if(!TP) return;
  if(TP->query_spell_point() < 10) {
    write("You need more power to protract your blades.\n");
    return 1; }
  if(IP(TP)->query_blad_on()) {
    write("You retract your blades.\n");
    say(TPN+" retracts "+TP->query_possessive()+
        " blades.\n");
    IP(TP)->set_blad_on(0);
    return 1; }
  IP(TP)->set_blad_on(1);
  TP->add_spell_point(-10);
  write("Sharp blades emerge from your body.\n");
  say("Sharp blades emerge from "+TPN+"'s body.\n");
  return 1;
}
