#include "DEFS.h"

combat_retreat() {
  object meat;
  meat = TP->query_attack();
  if(!meat) {
    write("You have nothing to retreat from as you are not in combat!\n");
    return 1; }
      if(TP->query_spell_point() < 15) {
    write("You need more power.\n");
  return 1; }
  TP->add_spell_point(-15);
  write("You retreat from your attack!\n");
  say(TPN+" retreats from "+GEN+" attack!\n");
  if(meat->query_attack() == TP) {
    meat->stop_fight();
    meat->stop_fight();
    meat->stop_hunter();
  }
  TP->stop_fight();
  TP->stop_fight();
  TP->stop_hunter();
return 1;
}
