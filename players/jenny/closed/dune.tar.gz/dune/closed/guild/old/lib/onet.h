#include "DEFS.h"

onet_channel(str) {
/* Guild channel */
   object everyone, member;
   int i;
   if(!str) {
      write("Usage: onet <message>.\n");
      return;}
   everyone = users();
   for(i = 0; i < sizeof(everyone); i++) {
      member = IP(everyone[i]);
      if(member && (member->sensei() || member->minister() ||
         member->shogun() || member->guild_lev() > 10) ) {
        if(member->muffled() < 1) tell_object(everyone[i],
    BLUE+"--OFFICERNET--"+END+" "+BOLD+TPN+END+" "+BLUE+"--"+
    END+" "+str+"\n");
        }
      }
   return 1;
}

