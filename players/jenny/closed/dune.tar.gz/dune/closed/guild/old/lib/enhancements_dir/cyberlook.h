#include "../DEFS.h"

cyber_look(str) {
  string myinv, roominv, myenv;
  object eyesee;
  if(!str) {
    IP(TP)->do_light(2);
    write(BOLD+"**CyberEyes**"+OFF+"\n"+GREEN);
    command("look",TP);
    write(OFF);
    IP(TP)->do_light(-2);
  return 1;
  }
  write(BOLD+"**CyberEyes**"+OFF+"\n");
  myinv = first_inventory(TP);
  eyesee = PRE(str,ENV(TP));
  if(!eyesee) eyesee = PRE(str,myinv);
  if(!eyesee) { write(BOLD+"CyberEyes"+OFF+" do not detect "+str+".\n");
  return 1; }
  write(GREEN);
  IP(TP)->do_light(2);
  command("look at "+str, TP);
  IP(TP)->do_light(-2);
  write(OFF);
   return 1;
}
