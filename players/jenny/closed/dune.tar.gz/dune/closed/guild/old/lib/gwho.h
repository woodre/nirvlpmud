#include "DEFS.h"

all_who()  {
int b, level, pk;
string gname, gen, room;
object * ob;
ob = users();

write("\n");
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");
  write("Player        Level    Guild       Pk   Gender   Location\n");
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");

for(b=0;b<sizeof(ob);b+=1)  {
if(!ob[b]->query_invis()) {
   level = ob[b]->query_level();
   gname = ob[b]->query_guild_name();
   pk = ob[b]->query_pl_k();
   gen = ob[b]->query_gender();
   if(environment(ob[b]))
   room = environment(ob[b])->short();
   else room = "unknown";
   write(pad(CAP(ob[b]->query_name()),15)); write(" ");
   if(level >= 10000) write(pad("GOD",5));
   else write(pad(level,5));
   write(" ");
   if(gname) write(pad(gname, 13));
   else write(pad("none", 13));
   if(pk) write(pad("yes", 4));
   else write(pad("no", 4));
   write(pad(gen, 9));
   write(room);
   write("\n");
   }
 }
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
       "~~~~~~~~~~~~~~~\n\n");
return 1;
}
