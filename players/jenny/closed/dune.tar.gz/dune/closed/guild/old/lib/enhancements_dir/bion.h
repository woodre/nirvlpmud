#include "../DEFS.h"

bionics() {
  /* added dmg enhancement */
  if(!TP) return;
  if(TP->query_spell_point() < 15) {
    write("Use of bionics is too draining for your state.\n");
    return 1; }
  if(IP(TP)->query_bion_on()) {
    write("You manually de-activate your bionics.\n");
    say(TPN+" manually de-activates "+TP->query_possessive()+
        " bionics.\n");
    IP(TP)->set_bion_on(0);
    return 1; }
  IP(TP)->set_bion_on(1);
  TP->add_spell_point(-15);
  write("Bionics engaged.\n");
  say(TPN+" engages "+GEN+" bionics.\n");
  return 1;
}
