#include "DEFS.h"

net_channel_emote(str) {
/* Guild channel emote */
   int i;
   object people, memb;
   if(!str) {
      write("Usage nem <emote>.\n");
      return 1;}
   people = users();
   for(i = 0; i<sizeof(people); i++) {
      memb=IP(people[i]);
      if(memb && memb->muffled() < 1) {
         tell_object(people[i],"\n"+
           RED+"(CYBER)"+OFF+" "+TPN+" "+str+"\n");
       }
   }
   return 1;
}

