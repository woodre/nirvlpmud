#include "DEFS.h"

query_balance() {
   write("Your credit balance is: "+
   IP(TP)->balance()+" @'s\n");
}
