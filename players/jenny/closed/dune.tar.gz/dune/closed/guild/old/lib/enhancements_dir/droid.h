#include "../DEFS.h"

activate_droid() {
  /* droid is not a pet, just a moving 'bag'... enhancement */
  object obdroid;
    obdroid = clone_object("/players/snow/closed/cyber/droid.c");
    if(find_object(TP->query_real_name()+"droid")) {
    write("You already have a droid.\n");
    return 1; }
  if(TP->query_spell_point() < 20) {
    write("You do not have enough energy to supply your droid.\n");
    return 1; }
  TP->add_spell_point(-20);
  move_object(obdroid,ET);
    obdroid->set_follname(TP->query_real_name());
    obdroid->set_droidid(TP->query_real_name()+"droid");
  write("Your droid's lights turn on.  It is active now.\n");
  say(TPN+" turns on "+GEN+" droid.\n");
  command("droidlink",TP);
  return 1;
}
