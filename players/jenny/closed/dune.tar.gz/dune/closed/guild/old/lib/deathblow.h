#include "DEFS.h"

death_blow(string str) {
  /* process for finishing off opponents
      attempts to counteract the inability of other attacks to kill */
  object ob;
  string name;
  int level, hp;
  if(!str) {
    if(!TP->query_attack()) {
      write("Usage: deathblow or db <monster>.\n");
      return 1; }
      ob = TP->query_attack();
  }
  if(str) {
     if(!present(str, environment(TP))) {
       write(capitalize(str)+" is not here.\n");
       return 1; }
     ob = present(str, environment(TP));
  }
  if(!ob->query_npc() && !check_location(TP,ob)) {
    write("You cannot use death blow on that!\n"); return 1; }
  if(ob->query_ghost()) {
    write("Your target is already dead.\n");
    return 1; }
  name = RED+capitalize(ob->query_name())+OFF;
  hp = ob->query_hp();
  level = IP(TP)->query_art_level();
  level = level * 2;
  if(TP->query_spell_point() < level) {
    write("You lack power to perform the killing blow!\n");
    return 1; }
  if(hp <= level) {
    write("You strike "+name+" with a razor fist!\n");
    TP->add_spell_point(-(level+hp));
    ob->heal_self(-hp);
    ob->hit_player(level);
    return 1;
  }
  else write(name+" is too healthy to die.\n");
}
