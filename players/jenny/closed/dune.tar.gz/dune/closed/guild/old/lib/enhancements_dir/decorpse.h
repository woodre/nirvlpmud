#include "../DEFS.h"

corpse() {
  object ob;
  ob = present("corpse",ENV(TP));
  if(!ob) {
    write("There is no corpse here!\n");
    return 1; }
  call_other(TP,"heal_self",ob->heal_value());
  write("You dismember a corpse and burn it for fuel.\n");
  say(TPN+" dismembers a corpse and burns it for fuel.\n");
destruct(ob);
return 1;
}
