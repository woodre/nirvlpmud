#include "DEFS.h"

deaths(string str) {
  string file, namme;
  object everyone;
  int i, kills;
  if(!str) {
    file = "/players/dune/closed/guild/deathmatches/"+RN+"";
  if ((file_size(file) >= 0) && (file_size(file) < 1000)) {
    write("Your death match record....\n");
    cat(file);
    return 1; }
  if (file_size(file) >= 1000) {
    write("Your death match record....\n");
    call_other("/players/dune/closed/guild/_more.c","more_file",file);
    return 1; }
    write("You have no death match record.\n");
    return 1; }
  if(str == "list") {
    everyone = users();
    write("~~~~~~~~~~~~~~~~~Death Match Kills~~~~~~~~~~~~~~~~~\n");
    write("Name              Kills          Title\n");
    write("___________________________________________________\n");
    for(i = 0; i < sizeof(everyone); i++) {
       if(IP(everyone[i]) && !everyone[i]->query_invis()) {
        kills = IP(everyone[i])->query_kills();
        namme = everyone[i]->query_name();
        write(pad(CAP(namme), 20));
        write(pad(kills, 10));
        if(kills <= 0) write("Commoner\n");
        if(kills >= 1 && kills <= 4) write("Initiate Assassin\n");
        if(kills >= 5 && kills <= 10) write("Assassin\n");
        if(kills >= 11 && kills <= 20) write("Expert Assassin\n");
        if(kills >= 21 && kills <= 40) write("Senior Assassin\n");
        if(kills >= 41 && kills <= 60) write("Elder Assassin\n");
        if(kills >= 61 && kills <= 99) write("Master of Assassins\n");
        if(kills >= 100) write("Grandfather of Assassins\n");
        }
      }
     write("___________________________________________________\n");
     return 1; }
  file = "/players/dune/closed/guild/deathmatches/"+str+"";
  if ((file_size(file) >= 0) && (file_size(file) < 1000)) {
    write(capitalize(str)+"'s death match record....\n");
    cat(file);
    return 1; }
  if (file_size(file) >= 1000) {
    write(capitalize(str)+"'s death match record....\n");
    call_other("/players/dune/closed/guild/_more.c","more_file",file);
    return 1; }
  write("No death match record on file for "+capitalize(str)+".\n");
  return 1;
}
