#include "../DEFS.h"

speed_run() {
  /* way for players to clone up their speedters */
  if(present("leg actuators",TP)) {
    write("Your leg actuators are already activated.\n");
    return 1;
  }
  move_object(clone_object("/players/snow/closed/speed.c"),
              this_player());
  TE(TP, "You have activated your leg actuators.\n");
  tell_room(environment(TP), TPN+"'s leg muscles tense up.\n"+
           "____________________ __________ _____ ___ __ _\n");
  return 1;
}
