#include "../DEFS.h"

emt(string str) {
  /* peace,aggression,nauseating enhancement */
  object ob;
  string name;
    int level, cost, duration;
    object nob;
  if(!str) {
  write("Usage: emt [p/a]\n");
    return 1; }
  if(TP->query_spell_point() < 35) {
    write("Your energy reserves are too low.\n");
    return 1; }
  if(str == "p") {
    TP->add_spell_point(-35);
    ob=first_inventory(ENV(TP));
    while (ob) {
     if (living(ob)) {
      if(ob->query_attack()) {
           (ob->query_attack())->stop_fight();
      (ob->query_attack())->stop_hunter();
     (ob->query_attack())->stop_fight();
      ob->stop_fight();
      ob->stop_hunter();
           ob->stop_fight();
           }
      }
      ob = next_inventory(ob);
     }
    write("A visible wave pattern emanates from you.\n");
    write("A soft blue haze envelopes the room.\n");
    write("You feel at peace.\n");
    say("A visible wave pattern emanates from "+TPN+".\n");
    say("A soft blue haze envelopes the room.\n");
    say("You feel at peace.\n");
    return 1; }
  if(str == "a") {
    write("Removed because of kid killings.\n"); return 1;
    if(!ok_in_room(TP)) {
      write("You cannot do that here.\n");
      return 1; }
    ob=first_inventory(ENV(TP));
    while (ob) {
     if (living(ob)) {
        name = ob->query_name();
        name = lower_case(name);
        /*
        if(find_player(name)) {
          if(find_player(name)->query_pl_k() &&
             find_player(name)->query_level() < 20)
            find_player(name)->attack_object(TP); }
          */
        if(!find_player(name)) {
          if(find_player(name) == TP) ob = next_inventory(ob);
          if(ob->query_attack())
             (ob->query_attack())->attack_object(TP);
          ob->attack_object(TP); }
        }
      ob = next_inventory(ob);
     }
    write("A visible wave pattern emanates from you.\n");
    write("A bright red haze envelopes the room.\n");
    write("You have turned everyone against you!\n");
    say("A visible wave pattern emanates from "+TPN+".\n");
    say("A bright red haze envelopes the room.\n");
    say("You become insane!\n");
    return 1; }
  write("Usage: emt [p/a]\n");
  return 1;
}



int ok_in_room(object ob) {
  object room;
  room = environment(ob);
  if( (room == find_object("/room/church.c")) ||
      (room == find_object("/room/adv_guild.c")) ||
      (room == find_object("/room/shop.c")) ||
      (room == find_object("/room/post.c")) ) 
    return 0;
  return 1; }

