#include "../DEFS.h"

string belt_color(int level) {
 string belt;
 if(level >= 7) level = 7;
 switch(level) {
     case 0:   belt = "none"; break;
     case 1:   belt = "white"; break;
     case 2:   belt = "purple"; break;
     case 3:   belt = "blue"; break;  
     case 4:   belt = "green"; break; 
     case 5:   belt = "brown"; break; 
     case 6:   belt = "red"; break;   
     case 7:   belt = "black"; break; 
     }
 return belt;
}
