#include "DEFS.h"

score() {
  int plev, ptox, ptuf, psok;
  int gbal, gwim;
  int preg;
plev = TP->query_level();
ptox = TP->query_intoxination();
ptuf = TP->query_stuffed();
psok = TP->query_soaked();
gbal = IP(TP)->balance();
gwim = IP(TP)->query_wimpy_hp();
  write(TP->short()+"\n");
  write(pad("Level: "+TP->query_level(), 32));
  write("Extra Level: "+TP->query_extra_level()+"\n");
  write(pad("Coins: "+TP->query_money(), 32));
  write("Experience: "+TP->query_exp()+"\n");
  write("Credits: "+gbal+"\n");
  write(pad("Hit Points: "+
         TP->query_hp()+"/"+TP->query_mhp(), 32));
  write("Energy: "+
         TP->query_sp()+"/"+TP->query_msp()+"\n");
  write("FluXcharges: "+IP(TP)->query_flux_charges()+"\n");
  write("Quest points: "+TP->query_quest_point()+"\n");
  TP->show_age();
  write("Time (CST): "+ctime(time())+"\n");
if(TP->query_wimpy())
  write("Wimpy mode.\n");
else
  write("Brave Mode\n");
  write("Intox ["+(ptox*100)/(plev+3)+"%]   "+
        "Soak ["+(psok*100)/(plev*8)+"%]   "+
        "Stuff ["+(ptuf*100)/(plev*8)+"%]\n\n");
  if(TP->query_pregnancy()) {
    preg = TP->query_age() - TP->query_pregnancy();
    write("Pregnant: "+preg*100/16300+"%\n"); }
  return 1;
}
