#include "DEFS.h"

ninja_speak(str) {
   /* ability to speak own guild language */
   object ob;
   ob = first_inventory(ENV(TP));
   while(ob) {
      if( (IP(ob) && ob != TP) ||
           ob->query_real_name() == "_hide_in_shadows_vehicle_")
          tell_object(ob, TPN+" elates: "+str+"\n");
      else if(ob != TP) 
          tell_object(ob, "You hear quiet voices in the room.\n");
      ob = next_inventory(ob);
   }
   write("You elate: "+str+"\n");
   return 1;
}
