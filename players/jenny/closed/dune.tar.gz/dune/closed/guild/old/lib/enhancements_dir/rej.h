#include "../DEFS.h"

rej() {
  if(IP(TP)->query_rejuv() == 1) {
    write("You stop the rejuvenation process.\n");
    IP(TP)->set_rejuv(0);
    return 1;
  }
  write("Your molecules burn and begin releasing energy.\n");
  IP(TP)->set_rejuv(1);
  IP(TP)->rej_beat();
  return 1;
}



rejuvenate(object ob) {
  int level, value, delay;
  level = IP(ob)->guild_lev();
  if(level > 12) level = 12;
  value = (level * 2 / 3) + 1;
  if(ob->query_hp() < 50) {
    TE(ob, "You are too weak to continue rejuvenation.\n");
    TE(ob, "Rejuvenation terminated...\n");
    IP(ob)->set_rejuv(0);
    return 1; }
  if(ob->query_sp() >= ob->query_msp()) {
    TE(ob, "You have fully rejuvenated.\n");
    TE(ob, "Rejuvenation terminated...\n");
    IP(ob)->set_rejuv(0);
    return 1; }
  ob->add_spell_point(value);            /* up to 6 sp healed */
  ob->add_hit_point(-(value));       /* up to 6 hp drained */
  TE(ob, "Rejuvenating...\n");
  return 1;
}
