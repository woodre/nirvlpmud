#include "../DEFS.h"

reg() {
  if(IP(TP)->query_regen() == 1) {
    write("You stop the regeneration process.\n");
    IP(TP)->set_regen(0);
  return 1;
  }
  write("Your molecules recombine and begin regenerating.\n");
  IP(TP)->set_regen(1);
  IP(TP)->reg_beat();
  return 1;
}



regenerate(object ob) {
  int level, value, delay;
  level = IP(ob)->guild_lev();
  if(level > 12) level = 12;
  value = (level * 2 / 3) + 1;
  if(ob->query_sp() < 50) {
    TE(ob, "You have no more energy to continue regeneration.\n");
    TE(ob, "Regeneration terminated...\n");
    IP(ob)->set_regen(0);
    return 1; }
  if(ob->query_hp() >= ob->query_mhp()) {
    TE(ob, "You have fully regenerated.\n");
    TE(ob, "Regeneration terminated...\n");
    IP(ob)->set_regen(0);
    return 1; }
  ob->add_hit_point(value);              /* up to 6 hp healed */
  ob->add_spell_point(-(value));     /* up to 6 sp drained */
  TE(ob, "Regenerating...\n");
  return 1;
}
