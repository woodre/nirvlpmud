#include "DEFS.h"

mask(string align) {
  return 0;
  TP->set_al_title(align);
  write("You mask your alignment to "+align+".\n");
  return 1;
}