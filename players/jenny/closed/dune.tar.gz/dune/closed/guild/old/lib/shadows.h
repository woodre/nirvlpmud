#include "DEFS.h"

hide_in_shadows() {
  /* command to hide in shadows */
  object ob;
  if(present("_drivers_seat_",
     environment(this_player()))) {
    write("You are already hiding in shadows.\n");
    return 1; }

  if(environment(this_player())->realm() == "NT") {
    write("The shadows magically resist your attempts to use them.\n");
    return 1; }

  if(this_player()->query_attack()) {
    if(this_player()->query_spell_point() < 60) {
      write("You feel too drained to attempt this.\n");
      return 1; }
    this_player()->add_spell_point(-60);
  } else {
   if(this_player()->query_spell_point() < 30) {
    write("Your energies are too weak to hide in shadows.\n");
    return 1; }
   this_player()->add_spell_point(-30);
  }ob = clone_object(
       "/players/snow/closed/cyber/objects/hide.c");
  move_object(ob, environment(this_player()));
  if(!TP->query_invis()) {
    say(TP->query_name()+" disappears into the shadows.\n");
  }
  move_object(this_player(), ob);
  write("You hide in shadows.\n");
  write("For info, type 'look at shadows'.\n");
  return 1;
}
