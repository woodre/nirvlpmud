#include "DEFS.h"

check_time() {
/* Command to find time on church clock */
  call_other("/room/church.c","long","clock");
  write("\nTime: "+ctime(time())+"\n");
  return;
}
