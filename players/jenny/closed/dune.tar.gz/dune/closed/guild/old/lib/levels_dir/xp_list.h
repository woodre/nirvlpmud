#include "../DEFS.h"

int xp_list(int xp) {
/* Returns guild level for xp specified */
  if(xp <  5000)    { return 0;  }
  if(xp <  20000)   { return 1;  }
  if(xp <  50000)   { return 2;  }
  if(xp <  90000)  { return 3;  } 
  if(xp <  140000)  { return 4;  }
  if(xp <  230000)  { return 5;  }
  if(xp <  330000)  { return 6;  }
  if(xp <  450000) { return 7;  } 
  if(xp <  600000) { return 8;  } 
  if(xp <  800000) { return 9;  } 
  if(xp >= 800000) { return 10; } 
  return 0;
}
