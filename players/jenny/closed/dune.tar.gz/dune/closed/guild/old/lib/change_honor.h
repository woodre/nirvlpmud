#include "DEFS.h"

change_honor(string str) {
  object ob;
  string who, new_honor_name;
  int amount, current_honor;
  if(!str) {
    write("Usage: change_honor <player> <amount>\n");
    return;}
  if(!sscanf(str, "%s %d", who, amount)) {
    write("Usage: change_honor <player> <amount>\n");
    return;}
  if(!find_player(who)) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  if(!IP(find_player(who))) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}  
  ob = IP(find_player(who));
  if(amount == 0) {
    write("You must specify a non-zero amount.\n");
    return; }
  new_honor_name = honor_title(amount);
  current_honor = ob->query_honor();
  write("You change "+WHO+"'s honor from "+current_honor+
        " to "+amount+"\n");
  if(honor_title(current_honor) != new_honor_name) 
    TE(EO, "Your honor has been changed to "+
           new_honor_name+" by "+TPN+".\n");
  else
    TE(EO, "Your honor has been slightly adjusted by "+TPN+".\n");
  write_file(log+"HONOR",
    RN+" set "+WHO+"'s honor from "+current_honor+" to "+
    amount+". ("+ctime()+")\n");
  ob->set_honor(amount);
  ob->save_me();
  ob->update_implants();
}
