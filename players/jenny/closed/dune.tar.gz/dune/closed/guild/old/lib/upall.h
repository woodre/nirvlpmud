#include "DEFS.h"

upall()  {
  /* command to update all cyberninja implants */
  int b;
  object ob;
  ob = users();
 write("~~~~~~~~~~~~~~~~~~~~~~~~~\n");
 for(b=0;b<sizeof(ob);b+=1)  {
  if(IP(ob[b]))  {
   IP(ob[b])->save_me();
   destruct(IP(ob[b]));
   move_object(clone_object(
               "/players/snow/closed/cyber/implants.c"),
               ob[b]);
   write(pad(ob[b]->query_name(),15));
   write(" updated.\n");
   }
 }
 write("~~~~~~~~~~~~~~~~~~~~~~~~~\n");
return 1;
}
