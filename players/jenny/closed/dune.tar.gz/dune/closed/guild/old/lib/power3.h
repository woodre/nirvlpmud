#include "DEFS.h"

power_wield3(str) {
  object meat;
  if(GLEV < 10) return 1;
  if(TP->query_level() < 19) {
    write("You must be player level 19 to use this.\n"); return 1; }
  if(str) {
    meat = PRE(str, ENV(TP) );
    if(!meat) { write("You cannot see [ "+str+" ] here.\n"); RE; }
  }
  if(!str) {
    meat = MEAT;
    if(!meat) {
      write("What do you want to power3?\n"); RE; }
  }
  if(!meat || !PRE(meat, ENV(TP)) ) {
    write("Your opponent is not here to fight.\n"); RE; }
  TP->spell_object(meat,"Power Wield",random(30)+10,25,
               BOLD+"You strike viciously into "+
                capitalize(meat->query_real_name())+OFF+".\n",
               TPN+" strikes viciously into you!\n",
               TPN+" strikes viciously into "+
                   capitalize(meat->query_real_name())+".\n");
return 1;
}
