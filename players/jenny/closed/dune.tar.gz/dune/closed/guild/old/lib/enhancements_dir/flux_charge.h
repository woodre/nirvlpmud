#include "../DEFS.h"

charge_flux() {
  if(IP(TP)->query_charge_on()) {
    TE(TP, "You stop charging your FluX generator.\n");
    IP(TP)->set_charge_on(0); RE; }
  TE(TP, "You start charging your FluX generator.\n");
  flux_charge(TP);
  IP(TP)->set_charge_on(1); RE; }

flux_charge(object ob) {
  int charges;
  if(!ob) RE;
  charges = IP(ob)->query_flux_charges();
  if(charges >= (OGLEV/2)+1) {
    TE(ob, BOLD+"FluX charger full [ "+charges+" ]"+OFF+"\n");
  IP(ob)->set_charge_on(0); RE; }
  if(ob->query_sp() < 50) {
    TE(ob, "FluX charging would drain your energy supply too much.\n"+
           "Process halted.\n");
    IP(ob)->set_charge_on(0); RE; }
  ob->add_spell_point(-8);
  IP(ob)->add_flux_charges(1);
    TE(ob, "FluX charging... [ "+charges+" ]\n");
  RE;
}
