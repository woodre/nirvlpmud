#include "DEFS.h"

enhance(string str) {
/* Used for guild level promotions/demotions */
  int new_lev, current_lev, low_new_xp;
  string who;
  object targ;
  if(!str) {
    write("Usage: enhance <member> <newlevel>.\n");
    return;}
  if(!sscanf(str, "%s %d", who, new_lev)) {
    write("Usage: enhance <member> <newlevel>.\n");
    return;}
  if(!IP(find_player(who))) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  targ = find_player(who);
  current_lev = IP(targ)->guild_lev();
  if (new_lev == current_lev) {
    write(capitalize(who)+" is already of quality "+new_lev+"\n");
    return;}
  if (new_lev < 0) {
    write("You cannot drop a member below quality 0.\n");
    return;}
  if((new_lev > 10) && (targ->query_level() > 19)) {
    write("Be sure to read the help files on levels.\n");
    write_file(log+"ENHANCE", RN+" enhanced "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    TE(targ, "You have been changed to quality "+new_lev+".\n");
    TE(targ, "You should read the help files on wiz members.\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    IP(targ)->save_me();
    targ->save_me();
    return;}
  if (new_lev > 10) {
    write("Be sure to read the help files on levels.\n");
    write_file(log+"ENHANCE", RN+" enhanced "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    TE(targ, "You have been promoted to level "+new_lev+".\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    IP(targ)->save_me();
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    targ->save_me();
    IP(targ)->update_implants();
    return;
    }
  if (new_lev > current_lev) {
    TE(targ, "You have been enhanced to quality "+new_lev+".\n");
    write_file(log+"ENHANCE", RN+" promoted "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    IP(targ)->save_me();
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    targ->save_me();
    IP(targ)->update_implants();
    return;}
  if(new_lev < current_lev) {
    TE(targ, "You have been demoted to a quality of "+new_lev+"\n");
    write_file(log+"ENHANCE", RN+" demoted "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    IP(targ)->save_me();
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    targ->save_me();
    IP(targ)->update_implants();
    return;}
}

