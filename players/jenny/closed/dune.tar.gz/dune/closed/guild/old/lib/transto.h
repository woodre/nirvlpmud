#include "DEFS.h"

trans_to(string str) { /*Transport to other ninja*/
  object here, there, ninto;
  string here_realm, there_realm;
  here = environment(this_player());
  here_realm = here->realm();
  if(!str) { write("Usage: transto <ninja>\n"); return; }
  ninto = find_player(str);
  if(!ninto) { write("<~>"+CAP(str)+" cannot be found.\n");
               return; }
  if(ninto->query_guild_name() != "cyberninja") {
    write(CAP(str)+" is not a CyberNinja.\n"); return; }
  if(ninto->query_level() > 19) {
    write("<~>"+CAP(str)+" cannot be found.\n"); RE; }
  there = ENV(ninto);
  there_realm = there->realm();
  if(TP->query_spell_point() < 200) {
    write("You cannot trans yourself, you are too low on power.\n");
    return; }
  if(here_realm == "NT") {
    write("You cannot trans from your location.\n");
    return; }
  if(there_realm == "NT") {
    write("You cannot trans to that location.\n");
    return; }

  say(TPN+"s body vaporizes into nothing.\n");
  TR(there, TPN+" transfers in.\n");
  move_object(this_player(), there);
  write("Your body disintegrates into invisible matter particles.\n");
  write("You trans yourself to "+CAP(str)+"...\n\n");
  command("look",TP);
  call_other(TP, "add_spell_point", -200);
  return 1;
}
