#include "DEFS.h"

stun_blow(string str) {
  object targ, stunob;
  int mysp, mylev, oplev;
  int ARTLEV;
  ARTLEV = IP(TP)->query_art_level();
  stunob = clone_object("/players/snow/closed/cyber/stun_blow.c");
  mysp = TP->query_sp();
  mylev = TP->query_level();
  if(!str) { write("Usage: stun <player>.\n"); return 1; }
  targ = PRE(str,ENV(TP));
  if(!targ) { write(CAP(str)+" is not here.\n"); return 1; }
  if(!living(targ)) { write(CAP(str)+" is not alive!\n"); return 1; }
  if(targ != TP->query_attack()) {
    write("You must be fighting what you want to stun.\n"); return 1; }
  oplev = targ->query_level();
  if(PRE("stun_blow",targ)) {
    write(CAP(str)+" is already stunned!\n"); return 1; }
  if(mysp < ARTLEV) {
    write("You lack the energy to perform the stunning blow.\n");
    return 1; }
  if(targ->is_player() && mylev < oplev) {
    write(CAP(str)+" is too strong for your stunning blow.\n");
    return 1; }
  write("You smash your fingers into "+CAP(str)+"'s neck!\n");
  TE(targ, "You feel a brief blinding pain!\n");
  TR(ENV(TP), CAP(str)+" goes limp and is stunned!\n");
  move_object(stunob, targ);
  stunob->destruct_stun(ARTLEV * 2);
  TP->add_spell_point(-ARTLEV);
  return 1;
}
