#include "DEFS.h"

suspend(string str) {
  int guild_xp, guild_rank, real_exp;
  object corpse, ob;
  if(!str) {
    write("Suspend who?\n");
    return; }
  if(!find_player(str)) {
    write("No such player.\n");
    return; }
  ob = find_player(str);
  if(!IP(ob)) {
    write("User "+capitalize(str)+" does not have implants.\n");
    return; }
  IP(ob)->set_suspended(1);
  ob->set_title("is suspended from the CyberNinjas");
  TE(ob, "You have been suspended from the CyberNinjas.\n");
  overchannel(OPN+" has been suspended from the CyberNinjas.\n");
  TE(ob, "Mail an Emperor or Regent if you have a problem with this.\n");
  write_file(log+"SUSPEND",
    capitalize(str)+" was suspended by "+RN+". ("+ctime()+")\n");
  IP(ob)->save_me();
  IP(ob)->update_implants();
}
