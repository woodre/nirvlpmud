#include "DEFS.h"

show_attacks() {
  cat("/players/dune/closed/guild/docs/attacks");
  return 1;
}
