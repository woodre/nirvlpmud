#include "DEFS.h"

execute(string str) {
  string file;
  int guild_xp, guild_rank, real_exp;
  object corpse, ob;
  if(!str) {
    write("Execute who?\n");
    write("Note: This is to be done in only drastic circumstances.\n");
    write("Use the 'suspend' command for lighter situations.\n");
    return; }
  if(!IP(find_player(str))) {
    write("User "+capitalize(str)+" is not valid.\n");
    return; }
  ob = find_player(str);
  guild_xp = IP(ob)->guild_exp();
  guild_rank = IP(ob)->guild_lev();
  real_exp = call_other(ob, "query_exp", 0);
  IP(ob)->set_xp(-guild_xp);
  IP(ob)->set_rank(-guild_rank);
  IP(ob)->set_guild_name(0);
  ob->set_guild_name(0);
  ob->add_guild_exp(-ob->query_guild_exp());
  ob->add_guild_rank(-ob->query_guild_rank());
  ob->set_title("the Dishonored CyberNinja");
  ob->set_guild_file(0);
  ob->set_home("room/church");
  file = "/players/snow/closed/cyber/ninjas/"+
         ((string)ob->query_real_name())+".o";
  "/players/snow/closed/cyber/execute_ob.c"->killninja(file);
  TR(EO, OPN+"'s cyberlinks are disconnected.\n");
  TR(EO, OPN+"'s implants are removed, painfully.\n");
  TR(EO, OPN+" is forced to kneel upon a small platform.\n");
  TR(EO, "An attendant hands "+TPN+" a sharp long-bladed katana.\n");
  TR(EO, TPN+" wields the katana and raises it high in the air.\n");
  TR(EO, "With one quick swing "+OPN+"'s head flies off.\n");
  overchannel(OPN+
              " has been banished with great dishonor from the Ninjas.\n");
  write_file(log+"EXECUTE", capitalize(str)+" was executed by "+
                         RN+". ("+ctime()+"\n");
  ob->save_me();
  ob->hit_player(100000);
  destruct(present("implants", ob));
}
