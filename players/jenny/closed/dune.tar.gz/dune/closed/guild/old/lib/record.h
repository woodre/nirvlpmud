#include "DEFS.h"

record(string str) {
  if(!str) {
    write("What do you wish to record?\n");
    return; }
  write_file(log+"RECORD",
    "--------------------------------------------------\n"+
    "->"+capitalize(this_player()->query_real_name())+
    "   ("+ctime()+")\n"+
    str+"\n");
  write("Your message will be added to the guild record.\n");
  return 1;
}
