#include "DEFS.h"

help_belt_levels() {
  /* Gives cost of experience for each belt level */
  int i;
  TE(TP, "Belt          Experience\n");
  TE(TP,"============================================\n");
  for(i = 1; i <= 7; i++) {
    write(pad(
    capitalize((string)belt_color(i,0))
    +"          ", 15));
    write(art_exp(i)+"\n");
    }
  TE(TP,"... 100000 for each black belt degree\n");
  TE(TP,"============================================\n");
  return 1;
}
