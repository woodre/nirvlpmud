#include "DEFS.h"

spy_room(string str) {
  /* Shows environment of a player and what players are wielding */
  object player, room, allroom;
  int i;
  if(!str) { write("Usage: roomspy <player>.\n"); return 1; }
  player = find_player(str);
  if(!player) { write("Player ["+CAP(str)+"] not found.\n"); return 1; }
  if(player->query_invis()) {
    write("Player ["+CAP(str)+"] not found.\n"); return 1; }
  if(player->query_level() > 19) {
    write("The spy satellite does not function on wizards.\n"); return 1; }
  room = environment(player);
  allroom = all_inventory(room);
  write(BOLD+"~~~ CYBERNINJA SPY SATELLITE DOWNLOAD ~~~"+OFF+"\n");
  write("\n\n"+GREEN+"--["+room->short()+"]--"+OFF+"\n");
  write(room->long());
  for(i=0; i < sizeof(allroom); i++) {
    if(!allroom[i]->query_invis()) {
    if(allroom[i]->short()) write(allroom[i]->short());
    if(allroom[i]->query_weapon()) {
      write("\n");
      write("  "+BOLD+"Using:"+OFF+":  "+
                allroom[i]->query_weapon()->short());
    }
    write("\n");
    } }
  write("\n\n");
  TP->add_spell_point(-25);
  return 1;
}
