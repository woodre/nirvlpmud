#include "../DEFS.h"

matter_burn() {
  object meat;
  int mhp, hps;
  int damage, snum;
  hps = TP->query_hp();
  snum = TP->query_attrib("str");
  if(hps < 60) {
    write("The matter converter shuts down before critical damage is done.\
n");
    return 1;
  }
  if(TP->query_sp() < 1) {
    write("You lack the energy to power the converter.\n");
    return 1; }
  damage = IP(TP)->guild_lev() + random(snum);
  TR(environment(TP),"***>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
  write("You overload your matter converter!\n"+
        "Intense, burning pain rips through your musculature!\n");
  TR(environment(TP),TP->query_name()+" crumples in agony!\n");
  if(!TP->query_attack() ||
    (environment(TP->query_attack()) != environment(TP)) ) {
    TP->add_hit_point(-random(damage));
  TR(environment(TP),"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<***\n");
    return 1;
  }
  meat = TP->query_attack();
  if(!meat->is_player() || check_location(TP,meat)) {
  write("You channel some excess energy into "+meat->query_name()+"!\n");
TR(environment(TP),"Matter energy crashes into "+meat->query_name()+"!\n");
  meat->hit_player(random(damage*2));
  TP->add_hit_point(-damage);
  }
  if(snum > 10) {
    if(random(snum*5) == 1) {
      write("The conversion overload resulted in permanent damage!\n");
      call_other(TP,"add_attrib","str",-1);
    }
  }
  TR(environment(TP),"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<***\n");
  return 1;
}
