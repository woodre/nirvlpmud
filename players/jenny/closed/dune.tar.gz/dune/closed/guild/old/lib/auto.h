#include "DEFS.h"

auto(string str) {
  /* sets the following automatics */
  if(!str) {
    write("Usage: auto [on/off]\n");
    return; }
  if(str == "on") {
    IP(TP)->set_auto(1);
    write("Your automatics are now on.\n");
    return; }
  if(str == "off") {
    IP(TP)->set_auto(0);
    write("Your automatics are now off.\n");
    return; }
  write("Usage: auto [on/off]\n");
}
