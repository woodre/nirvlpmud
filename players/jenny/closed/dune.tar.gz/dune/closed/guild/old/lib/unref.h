#include "DEFS.h"

unref(string who) {
  object ob;
  if(!who) {
    write("Who do you want to fire?\n");
    return 1; }
  if(!present(who, environment(TP))) {
    write(capitalize(who)+" is not here.\n");
    return 1; }
  if(!find_player(who)) {
    write(capitalize(who)+" is not a player.\n");
    return 1; }
  ob = find_player(who);
  if(!IP(ob)->referee()) {
    write(capitalize(who)+" is not a referee in the first place.\n");
    return 1; }
  IP(ob)->set_referee(0);
  IP(ob)->add_honor(-2);
  IP(ob)->save_me();
  IP(ob)->update_implants();
  tell_object(ob, TPN+" has fired you from the referee position.\n");
  tell_object(ob, "You lose honor.\n");
  write("You fire "+OPN+" from the referee position.\n");
  overchannel("Referee "+OPN+" has been fired by "+TPN+".\n");
  write_file(log+"REFEREE",
    RN+" fired referee "+ob->query_real_name()+". ("+ctime()+")\n");
  return 1;
}
