#include "DEFS.h"

advance_art(string str) {
   object ob;
   object mem;
   int artlevel, newlevel, level, xp, honor, 
       lowxp, reqxp, freexp, temp, degree;
   string art;
   if(!str) {
      write("Usage: train <who>\n");
      return;}
   if(!IP(present(str, environment(this_player())))) {
      write("There is no member named "+capitalize(str)+" here.\n");
      return;}
   ob = find_player(str);
   art = "Ninjitsu";
   mem = present("CyberNinja Implants", ob);
   honor = mem->query_honor();
   artlevel = mem->query_art_level();
   newlevel = artlevel + 1;
   if(newlevel > 17) {
     write(str+" cannot advance further in Ninjitsu.\n");
     TE(ob, "You are already Grandmaster of Ninjitsu.\n");
     return; }
   level = mem->guild_lev();
   if(level == 0) {
     write(str+" is too low of quality to train in any disciplines.\n");
     TE(ob, "You try to train but fail.\n");
     return; }
   if((artlevel >= 4) && (level < 3)) {
     write(str+" is too low of quality to train in any disciplines.\n");
     TE(ob, "You try to train but fail.\n");
     return; }
   if((artlevel >= 6) && (level < 6)) {
     write(str+" is too low of quality to train in any disciplines.\n");
     TE(ob, "You try to train but fail.\n");
     return; }
   xp = mem->guild_exp();
   lowxp = low_exp(level);
   if(newlevel <= 7) reqxp = art_exp(newlevel);
   else reqxp = 100000; /* 100k xp to advance in black belt degrees */
   freexp = xp - lowxp;
   degree = newlevel - 7;
   if(degree > 0) mem->set_degree(degree);
   if(freexp >= reqxp) {
     if(artlevel == 0) {
       mem->set_art(art);
       TE(ob, "You are introduced to the discipline of Ninjitsu.\n");
       TR(EO, TPN+" introduces "+str+" to the discipline of "+art+".\n");
       TR(EO, str+" is now a white belt in "+art+".\n");
       TE(ob, "A white belt is given to you.\n");
       write("You introduce "+str+" to the discipline of "+art+".\n");
       write(str+" begins as a white belt.\n");
       }
     if((newlevel < 7) && (newlevel > 1)) {
   TE(ob, "You advance in the discipline of Ninjitsu!\n");
   TR(EO, TPN+" trains "+str+" in the discipline of Ninjitsu\n");
   TR(EO, str+" is now a "+belt_color(newlevel,art)+" in Ninjitsu.\n");
       write(str+" advances in the discipline of "+art+".\n");
       write("You remove "+str+"'s "+belt_color(artlevel,art)+
             " belt and replace it with a "+belt_color(newlevel,art)+
             " belt.\n");
       TE(ob, "You take off your "+belt_color(artlevel,art)+
             " belt and put on a "+belt_color(newlevel,art)+" belt.\n");
          }
     if((newlevel == 7) && (honor < MODERATE)) {
         write(str+" is not honorable enough for a black belt.\n");
         TE(ob, "You try to train but fail.\n");
         return; }
     if((newlevel == 16) && (honor < HIGH)) {
         write(str+" is not honorable enough to be a Sensei.\n");
         TE(ob, "You try to train but fail.\n");
         return; }
     if(newlevel > 7) {
       TE(ob, "You advance to a black belt of degree "+degree+".\n");
       write("You place a shiny red mark on "+str+"'s black belt.\n");
       TR(EO, str+" advances to a black belt of degree "+degree+".\n");
       TR(EO, TPN+" places a shiny red mark on "+str+"'s black belt.\n");
       TE(ob, "Shiny red markings are added to your black belt.\n");
       }
     if((belt_color(newlevel,art) == "black") && (newlevel == 10)) {
       TE(ob, "You have mastered the discipline of "+art+"!\n");
       TR(EO, str+" has just mastered the discipline of "+art+".\n");
       mem->add_honor(5);
       TE(ob, "You gain honor.\n");
       overchannel(ob->query_real_name()+
                   " has mastered the discipline of "+art+"!\n");
       }
     if((belt_color(newlevel,art) == "black") && (newlevel == 17)) {
       TE(ob, "You have achieved Grandmaster status in the\n"+
              "the discipline of "+art+"!\n");
       TR(EO, str+" has become Grandmaster of "+capitalize(art)+".\n");
       mem->add_honor(10);
       TE(ob, "You gain much honor.\n");
       overchannel(OPN+
                   " has become Grandmaster of "+art+"!\n");
       empower(ob->query_real_name()+" sensei yes");
       }
     temp = newlevel - 7;
     if(temp == 10) {
       TE(ob,"You have achieved the status of Sensei!\n");
      mem->add_honor(GODLY);
       }
     mem->set_art_level(newlevel);
     mem->add_honor(SMALL);
     mem->add_xp(-reqxp);
     TE(ob, "You gain honor.\n");
     if(degree > 0) mem->set_degree(degree);
     write_file(log+"TRAIN", TPN+" trained "+str+" to level "+newlevel+
       " in "+capitalize(art)+". ("+ctime()+")\n");
     mem->save_me();
     mem->update_implants();
     return;}
   if(freexp < reqxp) {
     temp = reqxp - freexp;
     write(str+" does not have enough free guild experience.\n");
     TE(ob, "You do not have enough free guild experience.\n");
     TE(ob, "You need "+temp+
           " more experience points to learn "+art+".\n");
     return;}
}

