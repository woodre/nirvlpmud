#include "DEFS.h"

net_muffle_channel(str) {
/* Guild channel muffle */
  int muff;
  muff = IP(TP)->muffled();
   if(!str) {
      write("Useage: line <on/off>\n");
      return;
   }
  if(str == "off") {
      if(muff == 1) {
         write("You already are muffled.\n");
         return;}
      else
         muff = 1;
      write("You are now muffled.\n");
      IP(TP)->set_muffle(muff);
      return;
   }
   if(str == "on") {
      if(muff == 0) {
         write(" You were not muffled.\n");
         return;
         }
      else muff = 0;
      write("You are now on the CyberNet.\n");
      IP(TP)->set_muffle(muff);
      return;
      }
}

