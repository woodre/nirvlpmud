#include "DEFS.h"

coinsTocredits(string str) {
int num, bal, total;
 if(!str) {
   write("Usage: creditcoins or cc <amount>\n");
   return; }
 if(!sscanf(str, "%d", num)) {
   write("Usage: creditcoins or cc <amount>\n");
   return; }
 if(num < 0) {
   write("You cannot change credits back to coins.\n");
   return;}
 if(num == 0) {
   write("To change coins to credits, enter an amount > 0\n");
   return;}
 if(TP->query_money() < num) {
   write("You do not have that much coins.\n");
   return;}
 bal = IP(TP)->balance();
 total = bal + num;
 if(total > 200000) {
   total = 200000 - bal;
   write("The maximum credit limit is 200000 @'s.\n");
   write("You can change only "+total+" more coins into @'s.\n");
   return; }
 TP->add_money(-num);
 IP(TP)->addToBalance(num);
 write("You change "+num+" coins to credits.\n");
 IP(TP)->save_me();
return;
}
