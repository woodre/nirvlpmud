#include "../DEFS.h"

equil() {
  if(IP(TP)->query_equil() == 1) {
    write("Bodily equilibration discontinued.\n");
    IP(TP)->set_equil(0);
  return 1;
  }
  write("Bodily equilibration begun.\n");
  IP(TP)->set_equil(1);
  IP(TP)->equil_beat();
  return 1;
}



equilibrate(object ob) {
  int ohp, osp;
  ohp = ob->query_hp();
  osp = ob->query_sp();
  if(osp - ohp < 3 && ohp - osp < 3) {
    write("Body equilibrated. Process stopped.\n");
    IP(ob)->set_equil(0);
  return 1;
  }
  if(ohp > osp) {
    ob->add_hit_point(-2);
    ob->add_spell_point(2);
  }
  if(osp > ohp) {
    ob->add_hit_point(2);
    ob->add_spell_point(-2);
  }
  TE(ob,"Equilibrating...\n");
  return 1;
}
