#include "DEFS.h"

up_who()  { /*A high-rank who that shows pk stuff with color*/
int b, level, pk, xlev;
string gname, room;
object * ob;
ob = users();

write("\n");
write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");
write("Player          Level    Guild         Location\n");
write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");

 for(b=0;b<sizeof(ob);b+=1)  {
   if(!ob[b]->query_invis()) {
     level = ob[b]->query_level();
     xlev = ob[b]->query_extra_level();
     gname = ob[b]->query_guild_name();
     pk = ob[b]->query_pl_k();
     if(environment(ob[b]))
     room = environment(ob[b])->short();
     else room = "unknown";
       if(level >= 12 && level < 20) {
         if(pk) write(RED+pad(CAP(ob[b]->query_name()),15)+OFF);
           else write(pad(CAP(ob[b]->query_name()),15));
          write(" ");
         if(!xlev) write(pad(level,6));
           else write(pad(level+"+"+xlev,6));
         write(" ");
         if(gname) {
           if(gname == "cyberninja")
             write(BOLD+pad("CyberNinja",15)+OFF);
             else write(pad(gname, 15)); }
           else write(pad("none", 15));
         write(" ");
         if(ob[b]->query_fight_area() == file_name(ENV(ob[b])))
           write(RED+"->"+OFF+room);
           else write(room);
         write("\n");
       }
   }
 }
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
       "~~~~~~~~~~~~~~~\n\n");
return 1;
}
