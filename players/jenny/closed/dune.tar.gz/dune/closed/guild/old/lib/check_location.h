#include "DEFS.h"

int check_location(object ob, object targ) {
  if(EO->is_guild_arena() && targ->is_player()) return 1;
  return 0;
}
