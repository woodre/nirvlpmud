#include "../DEFS.h"

int low_exp(int level) {
/* Returns the base xp for the level specified */
  int xp;
  switch(level) {
    case 0:     xp = 0;         break;
    case 1:     xp = 5000;       break;
    case 2:     xp = 20000;      break;
    case 3:     xp = 50000;     break;
    case 4:     xp = 90000;    break;
    case 5:     xp = 140000;    break;
    case 6:     xp = 230000;    break;
    case 7:     xp = 330000;    break;
    case 8:     xp = 450000;    break;
    case 9:     xp = 600000;    break;
    case 10:    xp = 800000;    break;
    }
  if(level > 10) xp = 800000;
  return xp;
}
