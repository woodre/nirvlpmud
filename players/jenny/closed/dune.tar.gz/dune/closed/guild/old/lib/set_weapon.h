#include "DEFS.h"

setWeapon(string str) {
  object ob;
  string who, weapon, currentweapon;
  if(!str) {
    write("Usage: set_weapon <player> <weapon>\n");
    return;}
  if(!sscanf(str, "%s %s", who, weapon)) {
    write("Usage: set_weapon <player> <weapon>\n");
    return;}
  if(!IP(find_player(who))) {
    write("Not a valid user.\n");
    return; }
  if( !("/players/snow/closed/cyber/rooms/weaponry.c"->
      isAweapon(weapon))) {
    write("Not a valid weapon.\n");
    write("Weapon will be set anyway.\n");
    }
  ob = IP(find_player(who));
  currentweapon = ob->query_weapon();
  if(weapon == currentweapon) {
    write(WHO+" is already using that weapon.\n");
    return; }
  TE(EO, "Your weapon has been changed to "+weapon+" by "+TPN+".\n");
  write_file(log+"WEPS",
    RN+" set "+WHO+"'s weapon from "+currentweapon+" to "+
    weapon+". ("+ctime()+")\n");
  ob->set_weapon(weapon);
  ob->save_me();
  ob->update_implants();
}
