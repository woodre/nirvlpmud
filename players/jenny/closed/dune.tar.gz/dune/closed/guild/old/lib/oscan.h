#include "DEFS.h"

other_rank_info(string str) {
/* To find another person's guild info */
  int level, degree, honor;
  object ob;
  if(!str) {
    write("Usage: oscan <player>.\n"); return 1;}
  if(!find_player(str)) {
    write(capitalize(str)+" is not on now or does not exist.\n");
    return; }
  ob = find_player(str);
    if(ob->query_invis()) {
    write(capitalize(str)+" is not on or does not exist.\n");
    return 1;}
  if(!IP(ob)) {
    write(capitalize(str)+" is not a guild member.\n");
    return; }
  degree = IP(ob)->query_degree();
  level = IP(ob)->query_art_level();
  honor = IP(ob)->query_honor();
  TE(TP,OPN+"'s CyberNinja guild info......\n");
  TE(TP,"(* )( *)(* )( *)(* )( *)(* )( *)(* )( *)(* )( *)\n");
  if(ORN == EMP1 || RN == EMP2) TE(TP,"You are the EMPEROR.\n");
  if(IP(ob)->regent()) TE(TP,"You hold the title of Grand Regent.\n");
  if(IP(ob)->shogun()) TE(TP,"You hold the title of Shogun.\n");
  if(IP(ob)->sensei()) TE(TP,"You hold the title of Sensei.\n");
  if(IP(ob)->head_referee()) TE(TP,"You hold the title of Head Referee.\n");
  if(IP(ob)->referee()) TE(TP,"You hold the title of Referee.\n");
  if(IP(ob)->minister()) TE(TP,"You hold the title of Minister.\n");
  TE(TP,"Honor: "+honor_title(honor)+"\n");
  TE(TP,"Quality Level: "+IP(ob)->guild_lev()+"\n");
  TE(TP,"Guild Xp: "+IP(ob)->guild_exp()+"\n");
  TE(TP,"Belt: "+belt_color(level)+"");
  if(degree > 0) TE(TP,", degree "+degree+"\n");
  else TE(TP,"\n");
  TE(TP,"Choice of Weapon: "+IP(ob)->query_weapon()+"\n");
  TE(TP,"Credit Balance: "+IP(ob)->balance()+"\n");
  TE(TP,"( *)(* )( *)(* )( *)(* )( *)(* )( *)(* )( *)(* )\n");
}
