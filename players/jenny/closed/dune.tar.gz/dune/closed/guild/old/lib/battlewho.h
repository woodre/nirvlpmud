#include "DEFS.h"

bwho() {
  object * all;
  object opp;
  int i, total, hp, mhp;
  string statss, oppn;
  all = users();
  write("Player          Opponent            Opp's Health     Location.\n");
  write("_______________________________________________________________\n");
  for(i=0; i < sizeof(all); i++) {
    if(all[i]->query_attack() &&
       all[i]->query_invis() < TP->query_level() ) {
      opp = all[i]->query_attack();
      oppn = opp->query_name();
      write(pad(capitalize(all[i]->query_name()), 16));
      write(pad(oppn, 20));
      hp = opp->query_hp();
      mhp = opp->query_mhp();
      statss = "good shape";
      if(hp < mhp - 20) statss = "slightly hurt";
      if(hp < mhp/2) statss = "somewhat hurt";
      if(hp < mhp/5) statss = "bad shape";
      if(hp < mhp/10) statss = "very bad shape";
      if(hp < mhp/20) statss = "verge of death";
      write(" ");
      write(pad(statss, 16));
      write(ENV(opp)->short()+"\n");
      total += 1;
      }
    }
  if(total == 0) write("Nobody is in battle.\n");
  write("_______________________________________________________________\n");
  return 1;
}
