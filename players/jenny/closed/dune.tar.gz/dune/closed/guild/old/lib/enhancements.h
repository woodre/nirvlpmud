#include "DEFS.h"

listEnhancements(string str) {
/* shows all enhancements the person has */
object ob;
if(!str) {
  write("Your enhancements are....\n");
  showItemfunc(TP, TP);
  return; }
if(!find_player(str)) {
  write("No such player.\n");
  return; }
ob = find_player(str);
if(!IP(ob)) {
  write(OPN+" is not a CyberNinja.\n");
  return; }
  if(IP(TP)->shogun()   ||
       RN == EMP1 || RN == EMP2) {
  write(OPN+"'s enhancements are....\n");
  showItemfunc(ob, TP);
  return; }
}



showItemfunc(object ob, object me) {
/* ob stores the member of interest, me stores the checker */
write("______________________________\n");
if(IP(ob)->item_eyes()) TE(me, "cybereyes\n");
if(IP(ob)->item_corpse()) TE(me, "organic converter\n");
if(IP(ob)->item_activate_droid()) TE(me, "droid\n");
if(IP(ob)->item_stun()) TE(me, "stun ray\n");
if(IP(ob)->item_bionics()) TE(me, "bionics\n");
if(IP(ob)->item_blades()) TE(me, "blades\n");  
if(IP(ob)->item_electricflux()) TE(me, "electric flux\n");
if(IP(ob)->item_magneticflux()) TE(me, "magnetic flux\n");
if(IP(ob)->item_heatflux()) TE(me, "heat flux\n");
if(IP(ob)->item_flash()) TE(me, "biolight\n");
if(IP(ob)->item_emt()) TE(me, "emotion controller\n");
if(IP(ob)->item_legs()) TE(me, "leg actuators\n");
if(IP(ob)->item_convert()) TE(me, "matter converter\n");
if(IP(ob)->query_armor()) TE(me, "sub-dermal armoring\n");
if(IP(ob)->item_weplink()) TE(me, "smartweapon link ["+ 
  IP(ob)->item_weplink()+"]\n");
write("______________________________\n");
}
