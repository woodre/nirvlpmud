#include "DEFS.h"

help_levels() {
/* Shows xp and title for each guild level */
  int i;
  write("List of levels and experience for CyberNinja guild\n");
  write("________________________ ____________ ______ ____ ___ __\n");
  write(" LEVEL       XP          TITLE                     COST\n");
  write("________________________ ____________ ______ ____ ___ __\n");
  for(i = 0; i <= 10; i++) {
    write(pad("Level "+i, 12));
    write(pad(low_exp(i), 10));
    write("  ");
    write(pad(guild_title(i), 27));
    write(pad(call_other(
              "/players/snow/closed/cyber/rooms/meditation.c",
              "cost_to_advance", i), 10));
    write("\n");
    }
  write("________________________ ____________ ______ ____ ___ __\n");
}
