#include "DEFS.h"

net_deaths() {
  write("You tap into the cybernet to check on recent player deaths...\n\n");
  tail("/log/DEATHS");
  write("\n"+"Perhaps you should help some pk'rs make this list...\n");
  return 1;
}
