#include "DEFS.h"

guild_balance() {
   object everyone, member;
   int i, bal;
   everyone = users();
        write("Guild balances...........................\n");
   for(i = 0; i < sizeof(everyone); i++) {
    if(!everyone[i]->query_invis()) {
      if(IP(everyone[i])) {
        member = IP(everyone[i]);
        bal = member->balance();
        write(pad(CAP(everyone[i]->query_name()), 20));
        write(bal+" @'s\n");
      }
    }
   }
}
