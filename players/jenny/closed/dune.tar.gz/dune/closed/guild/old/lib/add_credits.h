#include "DEFS.h"

addCredits(string str) {
/* Used for guild credit promotion/demotion/fixing */
  int amount;
  string who;
  object whoob, ipwhoob;
  if(!str) {
    write("Usage: add_credits <member> <amount>.\n");
    return;}
  if(!sscanf(str, "%s %d", who, amount)) {
    write("Usage: add_credits <member> <amount>.\n");
    return;}
  if(!IP(find_player(who))) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  whoob = find_player(who);
  ipwhoob = present("implants", whoob);
  ipwhoob->addToBalance(amount);
  ipwhoob->save_me();
  if(amount >= 0)
    write("You alter "+capitalize(who)+"'s guild credits by +"
      +amount+".\n");
  else write("You alter "+capitalize(who)+"'s guild credits by "
      +amount+".\n");
  write_file(log+"BANK",
    RN+" altered "+whoob->query_real_name()+"'s guild credits by "+
    amount+". ("+ctime()+")\n");
}
