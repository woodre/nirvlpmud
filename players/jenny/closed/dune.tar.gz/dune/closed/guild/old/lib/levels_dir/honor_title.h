#include "../DEFS.h"

string honor_title(int lev) {
/* Returns honor title for honor points specified */
  if(lev <= -10) { return "Baneling"; }
  if(lev <=  -1) { return "Poor";     }
  if(lev <=   9) { return "Newbie";   }
  if(lev <=  29) { return "Moderate"; } 
  if(lev <=  69) { return "High";     }
  if(lev <= 149) { return "Savant";   }
  if(lev >= 150) { return "Divine";   } 
  return "Defective";
}
