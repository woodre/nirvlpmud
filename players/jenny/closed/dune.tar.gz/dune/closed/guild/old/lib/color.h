#include "DEFS.h"

color() {
  if(IP(TP)->query_color() == 1) {
    write("Color is now off.\n");
    IP(TP)->set_color(0);
    IP(TP)->save_me();
    update_implants();
    return; }
  write("Color is now on.\n");
  IP(TP)->set_color(1);
  IP(TP)->save_me();
  update_implants();
  return;
}
