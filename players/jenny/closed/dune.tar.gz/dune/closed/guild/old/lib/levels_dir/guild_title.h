#include "../DEFS.h"

string guild_title(int level) {
/* Returns guild title for guild level specified */
  string title;
  switch(level) {
    case 100:title = "the __Emperor__";           break;
    case 50: title = "the Grand Regent";          break;
    case 30: title = "the Regent";               break;
    case 13: title = "the Daimyo";                break;
    case 12: title = "the Shogun";                break;
    case 11: title = "the CyberNinja WarLord";    break;
    case 10: title = "the CyberNinja WarLord";    break;
    case 9:  title = "the Elder CyberNinja";      break;
    case 8:  title = "the Master CyberNinja";     break;
    case 7:  title = "the Adept CyberNinja";      break;
    case 6:  title = "the CyberNinja";            break;
    case 5:  title = "the CyberKnight";           break;
    case 4:  title = "the CyberWarrior";          break;
    case 3:  title = "the CyberBlade";            break;
    case 2:  title = "the CyberPunk";             break;
    case 1:  title = "the CyberPuke";             break;
    case 0:  title = "the NetRunner";             break;
    }
  if ((level > 13) && (level != 50) && (level != 100))
    title = "the Defective";
  return title;
}
