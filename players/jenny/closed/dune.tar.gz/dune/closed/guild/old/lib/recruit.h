#include "DEFS.h"

recruit_member(string who) {
/* Way to recruit new guild members */
  object ob;
  if(!who) {
    write("Usage: recruit <who>\n");
    return;}
  if(!find_player(who) || find_player(who)->query_level() > 19) {
    write("User "+WHO+" not found.\n");
    return;}
  ob = find_player(who);
  if(present("way of the cyberninja", ob)) {
    TE(TP, OPN+" is already recruited in the CyberNinjas.\n");
    return; }
  if(already_in_a_guild(ob)) {
     TE(TP,OPN+
       " is already in a guild.\n");
     return;}
  if(ob->query_level() < 6) {
     TE(TP,OPN+
       " is not level six yet.\n");
     return;}
  else {
    IP(TP)->add_honor(2);
    write_file(log+"RECRUIT", RN+" recruited "+WHO+" ("+ctime()+")\n");
    write("You have shown "+WHO+" the Way of the CyberNinja.\n");
    write("You gain honor.\n");
    TR(EO, TPN+" has shown "+WHO+" the Way of the CyberNinja.\n");
    move_object(clone_object("/players/snow/closed/cyber/recruitob.c"),
                ob);
    TE(ob, "You have been shown the Way of the CyberNinja.\n"+
           "Learn it, and you will soon be along the path\n"+
           "to greater destiny.\n");
    IP(TP)->save_me();
    return; 
    }
}



int already_in_a_guild(object ob) {
/* Checks if player is in another guild */
  if((ob->query_guild_name() != 0) ||
     (ob->query_guild_exp() != 0)  ||
     (ob->query_guild_file() != 0) ||
     (ob->query_guild_rank() != 0)) {
       return 1;}
  return 0;
}
