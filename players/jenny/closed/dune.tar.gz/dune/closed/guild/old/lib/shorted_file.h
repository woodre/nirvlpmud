#include "DEFS.h"

string shorted_file(string str) {
  string files;
  files = str + "short";
  if(file_size(files) >= 0) str = files;
  return str;
}
