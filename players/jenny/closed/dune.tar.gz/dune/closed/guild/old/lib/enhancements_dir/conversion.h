#include "../DEFS.h"

matter_conversion() {
  object pob, ob;
  pob = present("transferobj",TP);
  if(pob) {
    destruct(pob);
    IP(TP)->set_convert_on(0);
    write("Matter conversion stopped.\n");
    return 1;
  }
  ob = clone_object("/players/snow/closed/transfer.c");
  move_object(ob,TP);
  pob = present("transferobj",TP);
  pob->energy_transfer();
  IP(TP)->set_convert_on(1);
  write("Matter conversion begun.\n");
  return 1;
}
