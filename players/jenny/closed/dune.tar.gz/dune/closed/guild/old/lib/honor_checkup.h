#include "DEFS.h"
 
honor_checkup(object ob) {
  object wep, att;
  int al, hon;
  string me;
  if(!ob) return 1;
  if(ob->query_level() >= 20 && ob->query_real_name() != "snow") RE;
  me = ob->query_real_name();
  al = ob->query_alignment();
  hon = IP(ob)->query_honor();
  wep = present("nwep", ob);
  att = ob->query_attack();
  TE(ob, BOLD);
/* Taken out for confusing reason: why is cybernija evil?
  if(al > 0) {
    if(al > 500 && random(5) == 1) {
      TE(ob,"\n\tYour shining goodness shames you!\n\n");
      IP(ob)->add_honor(-2); 
    }
    else if(random(20) == 1) {
      TE(ob,"\n\tYour lack of dark intent causes you to lose honor.\n\n");
      IP(ob)->add_honor(-1);
    }
  }
  if(al < -500) {
    if(random(25) == 1 && hon < 50) {
      TE(ob,"\n\tYour dark achievements have gained you honor!\n\n");
      IP(ob)->add_honor(1);
    }
  }
*/
  if(!wep && !att && random(80) == 1) {
    TE(ob, "\n\tYou lose honor by being unprepared for battle.\n\n");
    IP(ob)->add_honor(-1); }
  if(wep && wep->wielded() ) {
    if(!att && random(30) == 1 && hon < 50) {
      TE(ob,"\n\tYou gain honor by being prepared for battle!\n\n");
      IP(ob)->add_honor(1);
    } }
  if(att) {
      if(!wep) {
        TE(ob, "\n\tYou are shamed by not using a CyberNinja weapon!\n\n");
        IP(ob)->add_honor(-1); }
      if(att->is_pet()) {
        TE(ob, "/tYou greatly shamed for attacking a pet!\n");
        IP(ob)->add_honor(-4); }
      if(att->is_player() ) {
        if(att->query_level() < 6) {
          TE(ob, "\n\tYou are shamed by your attack of a newbie!\n\n");
          IP(ob)->add_honor(-4);
        }
        if(att->query_level() > ob->query_level() ||
           att->query_level() > 15) {
          if(!ENV(ob)->query_spar_area() && 
             att->query_attack() == ob && random(3) == 1 &&
             hon < 100) {
            TE(ob, "You gain great honor in combat!\n");
            IP(ob)->add_honor(2);
        } }
        else if(att->query_attack() == ob && random(3) == 1 &&
                hon < 70) {
          TE(ob, "You gain honor in combat!\n");
          IP(ob)->add_honor(1);
        }
      }
/* Taken out: Why are Cyberninjas evil? This is a confusing hardship
      if(att->query_alignment() > 0) {
        if(random(10) == 1 && hon < 50) {
          TE(ob, "Your evil actions gain you honor!\n");
          IP(ob)->add_honor(1); 
      } }
*/
  }
  IP(ob)->save_me();
  TE(ob, OFF);
  if(hon < 0) {
    if(random(10) == 1) ob->heal_self(-random(4)-1);
  }
  if(hon > 20) {
    if(random(10) == 1) ob->heal_self(random(3)+1);
  }
  if(hon > 50) {
    if(random(10) == 1) ob->heal_self(random(5)+1);
  }
  if(hon > 100) {
    if(random(10) == 1) ob->heal_self(random(5)+3);
  }
  return 1;
}
