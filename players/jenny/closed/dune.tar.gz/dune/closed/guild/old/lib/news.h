#include "DEFS.h"

scan_news() {
  write("You tap into the cybernet news...\n");
  cat("/players/dune/closed/guild/docs/news");
  write("You close the news connection.\n");
return 1;
}
