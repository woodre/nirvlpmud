#include "DEFS.h"

mode_change(str) {
  object boo;
  if(!str) {
    write("Usage: mode <none/attack/defense>\n");
    write("Current mode: "+BOLD);
      if(IP(TP)->query_attack_mode() == 0) write("NONE");
      if(IP(TP)->query_attack_mode() == 1) write("ATTACK");
      if(IP(TP)->query_attack_mode() == 2) write("DEFENSE");
    write(OFF+"\n"); RE; }
  if(str == "none") {
    IP(TP)->set_attack_mode(0);
    write(BOLD+"Attack mode set to: NONE"+OFF+"\n");
    RE; }
  if(str == "attack") {
    IP(TP)->set_attack_mode(1);
    write(BOLD+"You set your attack mode to: ATTACK"+OFF+"\n");
    RE; }
  if(str == "defense") {
    IP(TP)->set_attack_mode(2);
    write(BOLD+"Attack mode set to: DEFENSE"+OFF+"\n");
    RE; }
  write("You have chosen an invalid attack mode.\n");
  RE;
}
