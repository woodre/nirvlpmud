#include "DEFS.h"

restart() {
  write("You restart your mechanical heart...\n");
  IP(TP)->reset(0);
  return 1;
}
