#include "../DEFS.h"

meta_conversion() {
  if(IP(TP)->query_digest()) {
    write("Metabolic amelioration stopped.\n");
    IP(TP)->set_digest(0);
    return 1;
  }
  write("Metabolic amelioration begun.\n");
  IP(TP)->set_digest(1);
  call_out("digestion",10,TP);
  return 1;
}



digestion(object ob) {
  int INUM, in, st;   
  int SNUM;
  st = ob->query_stuffed();
  in = ob->query_intoxination();
  INUM = (in * 10) / (ob->query_level() + 3);
  SNUM = (st * 10)/(ob->query_level() * 8);  
  if(!IP(ob)->query_digest()) return 1;
  if(INUM > 7) call_out("digestion",10,ob);
  else call_out("digestion",15,ob);
  if(ob->query_spell_point() < 1) return 1;
  if(in > 1) {
    ob->add_intoxination(-1);
    ob->heal_self(2);
  }
  if(st > 2) {
    ob->add_stuffed(-2);
  }
  if(!in && !st) {
    TE(ob,"No matter to metabolize.\n");
    IP(ob)->set_digest(0);
    return 1;
  }
  ob->add_spell_point(-1);
  return 1;
}
