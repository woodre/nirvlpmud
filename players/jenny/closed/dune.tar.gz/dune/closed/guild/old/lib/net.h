#include "DEFS.h"

net_channel(str) {
/* Guild channel */
   object everyone, member;
   int i;
   if(!str) {
      write("Usage: net <message>.\n");
      return;}
   everyone = users();
   for(i = 0; i < sizeof(everyone); i++) {
      member = IP(everyone[i]);
      if(member && member->muffled() < 1) {
        tell_object(everyone[i],
    RED+"CYBERNET~~~"+END+" "+BOLD+TPN+END+" "+RED+">>>"+
    END+" "+str+"\n");
        }
      }
   return 1;
}

