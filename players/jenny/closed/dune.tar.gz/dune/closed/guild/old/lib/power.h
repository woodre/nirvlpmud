#include "DEFS.h"

power_wield(str) {
  object meat;
  if(GLEV < 4) return 1;
  if(str) {
    meat = PRE(str, ENV(TP) );
    if(!meat) { write("You cannot see [ "+str+" ] here.\n"); RE; }
  }
  if(!str) {
    meat = MEAT;
    if(!meat) {
      write("What do you want to power?\n"); RE; }
  }
  if(!meat || !PRE(meat, ENV(TP)) ) {
    write("Your opponent is not here to fight.\n"); RE; }
  TP->spell_object(meat,"Power Wield",random(20)+5,15,
               "You strike viciously into "+
                capitalize(meat->query_real_name())+".\n",
               TPN+" strikes viciously into you!\n",
               TPN+" strikes viciously into "+
                   capitalize(meat->query_real_name())+".\n");
return 1;
}
