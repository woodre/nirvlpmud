#include "DEFS.h"

officer_database(string str) {
/* takes str and refers to files in fax directory */
  string file, topic, all;
  if(!str) {
    cat(FAXPATH+"fax_menu");
    return; }
  if(sscanf(str, "%s %s", topic, all)) {
    file = FAXPATH +""+ topic;
    file = shorted_file(file);
    if(all == "all") {
      if (file_size(file) >= 0) {
        cat(file);
        return; }
      else {
        write("There is no help on that fax topic.\n");
        return; }
      }
    if(all != "all") {
      write("Usage: fax [topic]   or   fax [topic] all.\n");
      return; }
    }
  if(sscanf(str, "%s", topic)) {
      file = FAXPATH +""+ topic;
      file = shorted_file(file);
      if (file_size(file) >= 0) {
         if(find_menu(file)) {
           cat(file);
           return; }
         call_other(MOREPATH, "more_file", file);
         return; }
      write("There is no help on that fax topic.\n");
      return; }
  write("Usage: fax [topic]   or   fax [topic] all.\n");
}

