#include "../DEFS.h"

heatflux(string who) {
  /* concentrated dmg enhancement */
  object ob;
  int dmg;
  if(!who) {
    if(!TP->query_attack()) { write("Usage: hflux <target>\n"); RE; }
    else ob = TP->query_attack(); }
  if(who) {
    if(!present(who, ENV(TP))) {
      write("There is no "+capitalize(who)+" here.\n"); RE; }
    else ob = present(who,ENV(TP)); }
  if(ob->query_ghost()) {
    write("Your target is already dead.\n"); RE; }
  if(!ob->query_npc() && !check_location(TP,ob)) {
    write("You cannot flux that!\n"); RE; }
  if(TP->query_spell_point() < 40) {
    write("Your energy reserves are too low.\n"); RE; }
  if(!IP(TP)->query_flux_charges() ) {
    write("You must charge your FluX before you can use it.\n");
    RE; }
  IP(TP)->add_flux_charges(-1);
  if(IP(TP)->guild_lev() + 85 < random(100) ) {
    write("Your flux generator backfires!\n");
    if(TP->query_attrib("wil") < random(25)) {
      write("Built-up heat makes your skin smoke and burn!\n");
       TP->hit_player(random(IP(TP)->guild_lev()) + 1); }
    TP->add_spell_point(-(random(20))); RE; }
  dmg = IP(TP)->guild_lev();
  dmg = dmg * random(4);
  dmg = random(20) + dmg;
  if(dmg > 50) dmg = 50;
  TP->add_spell_point(-random(dmg) - 10);
  TR(ET, "\n"+TPN+" releases a burst of heat flux into "+OPN+"\n\n");
  if(dmg <= 15) {
  TR(ET,
RED+"                "+OFF+"\n"+
RED+"  f         f   "+OFF+"\n"+
RED+" ff       ff    "+OFF+"\n\n");
  }
  if(dmg >= 16 && dmg <= 35) {
  TR(ET,
RED+"   f         f          "+OFF+"\n"+
RED+"  f         f        f  "+OFF+"\n"+
RED+" fff      ff        fff "+OFF+"\n\n");
  }
  if(dmg >= 36) {
  TR(ET,
RED+"    ff                           f                  "+OFF+"\n"+
RED+"   ff        f                   ff         f     f "+OFF+"\n"+
RED+"  ff        f        f         fff        f     ff  "+OFF+"\n"+
RED+" fff      ff        fff      fffff       ff    ffff "+OFF+"\n\n");
  }
  ob->hit_player(dmg);
  if(ob) {
    if(!TP->query_attack()) TP->attack_object(ob);
    if(!ob->query_attack()) ob->attack_object(TP); }
  return 1;
}
