#include "DEFS.h"

purge(string str) {
  string file;
  int guild_xp, guild_rank, real_exp;
  object corpse, ob;
  if(!str) {
    write("Purge which baneling?\n");
    return; }
  if(!IP(find_player(str))) {
    write("User "+capitalize(str)+" is not valid.\n");
    return; }
  ob = find_player(str);
  guild_xp = IP(ob)->guild_exp();
  guild_rank = IP(ob)->guild_lev();
  real_exp = call_other(ob, "query_exp", 0);
  IP(ob)->set_xp(-guild_xp);
  IP(ob)->set_rank(-guild_rank);
  IP(ob)->set_guild_name(0);
  ob->set_guild_name(0);
  ob->add_guild_exp(-ob->query_guild_exp());
  ob->add_guild_rank(-ob->query_guild_rank());
  ob->set_title("the Dishonored CyberNinja");
  ob->set_guild_file(0);
  ob->set_home("room/church");
  file = "/players/snow/closed/cyber/ninjas/"+
         ((string)ob->query_real_name())+".o";
  "/players/snow/closed/cyber/execute_ob.c"->killninja(file);
  TR(EO, OPN+"'s cyberlinks are disconnected.\n");
  TR(EO, OPN+"'s implants are removed, painfully.\n");
  TR(EO, OPN+" is purged along with the rest of the CyberNinja trash.\n");
  overchannel("Baneling "+OPN+
              " has been purged from the CyberNinjas.\n");
  write_file(log+"EXECUTE", capitalize(str)+" was purged by "+
                         RN+". ("+ctime()+"\n");
  ob->save_me();
  ob->hit_player(100000);
  destruct(present("implants", ob));
}
