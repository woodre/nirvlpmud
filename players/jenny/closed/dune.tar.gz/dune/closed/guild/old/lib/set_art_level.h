#include "DEFS.h"

setArtLevel(string str) {
  object ob;
  string who, art, belt;
  int currentlevel, level, degreelevel;
  if(!str) {
    write("Usage: set_art_level <player> <level>\n");
    return;}
  if(!sscanf(str, "%s %d", who, level)) {
    write("Usage: set_art_level <player> <level>\n");
    return;}
  if(!IP(find_player(who))) {
    write("Not a valid user.\n");
    return; }
  if(level < 0) {
    write("Not a valid level.\n");
    return;}
  ob = IP(find_player(who));
  currentlevel = ob->query_art_level();
  if(level == currentlevel) {
    write(WHO+" is already of discipline level "+level+".\n");
    return; }
   art = "Ninjitsu";
  belt = belt_color(level, art);
  if(level < 7)
    TE(EO, "Your belt has been changed to "+belt+" by "+TPN+".\n");
  if(level >= 7) {
    degreelevel = level - 6;
    TE(EO, "Your black belt degree has been changed to "+
           degreelevel+".\n"); }
  if(degreelevel > 0) ob->set_degree(degreelevel);
  write_file(log+"ARTS",
    RN+" changed "+WHO+"'s discipline level from "+currentlevel+
    " to "+level+". ("+ctime()+")\n");
  ob->set_art_level(level);
  ob->save_me();
  ob->update_implants();
}
