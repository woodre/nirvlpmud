
#include "DEFS.h"

view_honor(string str) {
  object ob;
  int honor;
  if(!str) {
    write("Usage: view_honor <ninja>\n");
    return;}
  if(!IP(find_player(str))) {
    write("Not a valid user.\n");
    return; }
  ob = find_player(str);
  honor = IP(ob)->query_honor();
  write(OPN+"'s honor statistics...\n"+
        "Rank:         "+honor_title(honor)+"\n"+
        "Honor points: "+honor+"\n");
}
