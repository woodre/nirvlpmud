#include "DEFS.h"

empower (string str) {
   object ob;
   string who, type, flag;
   if(!str) {
    write("Usage: empower <who> [type] [yes/no]\n");
    write("Where type is: referee\n"+
          "               head_referee\n"+
          "               sensei\n"+
          "               minister\n"+
          "               shogun\n"+
          "               regent\n");
     return;}
   if(!sscanf(str, "%s %s %s", who, type, flag)) {
    write("Usage: empower <who> [type] [yes/no]\n");
    write("Where type is: referee\n"+    
          "               head_referee\n"+
          "               sensei\n"+
          "               minister\n"+
          "               shogun\n"+   
          "               regent\n");
     return;}
   if(!find_player(who)) {
     write("No such player.\n");
     return; }
   ob = find_player(who);
   if(!IP(ob)) {
     write(WHO+" is not a CyberNinja.\n");
     return; }
   if( (type == "sensei") ||
       (type == "minister") || 
       (type == "shogun") || 
       (type == "regent") ||
       (type == "head_referee") || 
       (type == "referee") ) {
     if((flag == "yes") || (flag == "no")) {

       if(type == "regent") {
         if(RN == EMP1 || RN == EMP2) {}
         else {
           write("Only an Emperor can empower Regents.\n");
           return; }
         if(flag == "yes") {
           if(IP(ob)->regent()) {
             write(WHO+" is already regent.\n");
             return;}
           else {
             write("You empower "+WHO+" with Regent abilities!\n");
             IP(ob)->set_regent(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Regent!\n");
             overchannel(OPN+" has become the Regent!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Regent. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->regent()) {
             write(WHO+" is not Regent in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Regent abilities.\n");
             IP(ob)->set_regent(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Regent abilities.\n");
             overchannel(OPN+" is no longer Regent.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Regent. ("+ctime()+")\n");
         return;}
           }}

       if(type == "sensei") {
         if(flag == "yes") {
           if(IP(ob)->sensei()) {
             write(WHO+" is already Sensei.\n");
             return;}
           else {
             write(WHO+" is empowered with Sensei abilities.\n");
             IP(ob)->set_sensei(1);
             IP(ob)->add_honor(10);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, "You have become Sensei!\n");
             TE(ob, "You gain much honor!\n");
             overchannel(OPN+" has become sensei!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Sensei. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->sensei()) {
             write(WHO+" is not Sensei in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Sensei abilities.\n");
             IP(ob)->set_sensei(0);
             IP(ob)->add_honor(-10);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Sensei abilities.\n");
             TE(ob, "You lose honor.\n");
             overchannel(OPN+" is no longer Sensei.\n");
             write_file(log+"EMPOWER", RN+" removed "+
                          ob->query_real_name()+
                          " from Sensei. ("+ctime()+")\n");
             return;}
           }}

       if(type == "minister") {  
         if(flag == "yes") {
           if(IP(ob)->minister()) {
             write(WHO+" is already a Minister.\n");
             return;}
           else {
             write("You empower "+WHO+" with Minister abilities.\n");
             IP(ob)->set_minister(1);
             IP(ob)->add_honor(10);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, "You have become Minister!\n");
             TE(ob, "You gain much honor!\n");
             overchannel(OPN+" has become Minister!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Minister. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->minister()) {
             write(WHO+" is not Minister in the first place.\n");
             return;}
           else {
             write("You remove "+WHO+" from the Ministry.\n");
             IP(ob)->set_minister(0);
             IP(ob)->add_honor(-10);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed you from the Ministry.\n");
             TE(ob, "You lose honor.\n");
             overchannel(TPN+" has removed "+OPN+" from the Ministry.\n");
             write_file(log+"EMPOWER", RN+" removed "+
                          ob->query_real_name()+
                          " from Minister. ("+ctime()+")\n");
             return;}
           }}

       if(type == "shogun") {
         if(RN == EMP1 || RN == EMP2 || IP(TP)->regent()) {}
         else {
           write("Only an Emperor or Regent can empower Shoguns.\n");
           return; }
         if(flag == "yes") {
           if(IP(ob)->shogun()) {
             write(WHO+" is already Shogun.\n");
             return;}
           else {
             write("You empower "+WHO+" with Shogun abilities.\n");
             IP(ob)->set_shogun(1);
             IP(ob)->add_honor(10);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Shogun!\n");
             TE(ob, "You gain much honor!\n");
             overchannel(OPN+" has become Shogun!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Shogun. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->shogun()) {
             write(WHO+" is not Shogun in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Shogun abilities.\n");
             IP(ob)->set_shogun(0);
             IP(ob)->add_honor(-10);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Shogun abilities.\n");
             TE(ob, "You lose honor.\n");
             overchannel(OPN+" is no longer Shogun.\n");
             write_file(log+"EMPOWER", RN+" removed "+
                          ob->query_real_name()+
                          " from Shogun. ("+ctime()+")\n");
             return;}
           }}

       if(type == "referee") {
         if(flag == "yes") {
           if(IP(ob)->referee()) {
             write(WHO+" is already Referee.\n");
             return;}
           else {
             write("You empower "+WHO+" with Referee abilities.\n");
             IP(ob)->set_referee(1);
             IP(ob)->add_honor(2);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Referee!\n");
             TE(ob, "You gain honor.\n");
             overchannel(OPN+" has become Referee!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Referee. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->referee()) {
             write(WHO+" is not Referee in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Referee abilities.\n");
             IP(ob)->set_referee(0);
             IP(ob)->add_honor(-2);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Referee abilities.\n");
             TE(ob, "You lose honor.\n");
             overchannel(OPN+" is no longer Referee.\n");
             write_file(log+"EMPOWER", RN+" removed "+
                          ob->query_real_name()+
                          " from Referee. ("+ctime()+")\n");
             return;}
           }}

       if(type == "head_referee") {
         if(flag == "yes") {
           if(IP(ob)->head_referee()) {
             write(WHO+" is already Head Referee.\n");
             return;}
           else {
             write("You empower "+WHO+" with Head Referee abilities.\n");
             IP(ob)->set_head_referee(1);
             IP(ob)->add_honor(4);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Head Referee!\n");
             TE(ob, "You gain honor!\n");
             overchannel(OPN+" has become head referee!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Head Referee. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->head_referee()) {
             write(WHO+" is not Head Referee in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Head Referee abilities.\n");
             IP(ob)->set_head_referee(0);
             IP(ob)->add_honor(-4);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Head Referee abilities.\n");
             TE(ob, "You lose honor.\n");
             overchannel(OPN+" is no longer Head Referee.\n");
             write_file(log+"EMPOWER", RN+" removed "+
                        ob->query_real_name()+
                          " from Head Referee. ("+ctime()+")\n");
             return;}
           }}

     }
    write("Usage: empower <who> [type] [yes/no]\n");
    write("Where type is: referee\n"+    
          "               head_referee\n"+
          "               sensei\n"+
          "               minister\n"+
          "               shogun\n"+   
          "               regent\n");
    return;
   }
   write("Usage: empower <who> [type] [yes/no]\n");
   write("Where type is: referee\n"+    
          "               head_referee\n"+
          "               sensei\n"+
          "               minister\n"+
          "               shogun\n"+   
          "               regent\n");
   return;
}

