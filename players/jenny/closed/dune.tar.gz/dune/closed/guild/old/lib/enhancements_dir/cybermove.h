#include "../DEFS.h"

cyber_move(str) {
  if(!str) { write(BOLD+"**CyberMove**"+OFF+" in which direction?\n");
             return 1; }
  write(BOLD+"**CyberMove** "+CAP(str)+OFF+"\n"+GREEN);
  IP(TP)->do_light(2);
  command(str,TP);
  IP(TP)->do_light(-2);
  write(OFF);
  return 1;
}
