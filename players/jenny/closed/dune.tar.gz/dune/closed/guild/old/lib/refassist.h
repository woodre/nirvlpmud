#include "DEFS.h"

refassist(string who) {
  object ob;
  if(!who) {
    write("Who do you want to make referee?\n");
    return 1; }
  if(!present(who, environment(TP))) {
    write(capitalize(who)+" is not here.\n");
    return 1; }
  if(!find_player(who)) {
    write("You can only make players referees.\n");
    return 1; }
  ob = find_player(who);
  if(IP(ob)->referee()) {
    write(capitalize(who)+" is already a referee.\n");
    return 1; }
  IP(ob)->set_referee(1);
  IP(ob)->add_honor(2);
  IP(ob)->save_me();
  IP(ob)->update_implants();
  tell_object(ob, TPN+" has made you referee.\n");
  tell_object(ob, "You gain honor.\n");
  write("You make "+OPN+" a referee.\n");
  overchannel(OPN+" has become referee.\n");
  write_file(log+"REFEREE", RN+" made "+ob->query_real_name()+
    " a referee. ("+ctime()+")\n");
  return 1;
}
