#include "DEFS.h"

int find_menu(string str) {
  string menustr;
  if(sscanf(str, "%smenu", menustr) == 1) return 1;
  if(sscanf(str, "%sshort", menustr) == 1) return 1;
  return 0;
}
