#include "DEFS.h"

dishonor(string str) {
/* Used to take away honor points from a player */
  int honor_range, new_honor;
  string who, honor_amount, reason, honor_name;
  object ob;
  honor_range = find_honor_range(TP, RN);
  honor_name = find_range_names(TP, RN);
  if(!str) {
    write("Usage: dishonor <member> <amount> <reason>.\n");
    write("Your range of dishonoring is:\n\t"+honor_name+"\n");
    return;}
  if(!sscanf(str, "%s %s %s", who, honor_amount, reason)) {
    write("Usage: dishonor <member> <amount> <reason>.\n");
    write("Your range of dishonoring is:\n\t"+honor_name+"\n");
    return;}
  if(!reason) {
    write("You must also state your reason.\n");
    return;}
  if(!find_player(who)) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  ob = find_player(who);
  if(!IP(ob)) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;} 
  if((TP->query_level() < 20) && 
     (ob->query_level() >= 20)) {
    write("Wizards are immune to this.\n");
    return;}
  if((TP->query_level() < 20) && 
     (ob->query_real_name() == RN)) {
    write("You cannot dishonor yourself.\n");
    return;}
  if(!valid_range(honor_amount, honor_range)) {
    write("You have entered an invalid amount.\n");
    write("Your range of dishonoring is:\n\t"+honor_name+"\n");
    return;}
  new_honor = get_points(honor_amount);
  write_file(log+"HONOR", RN+" dishonored "+ORN+
             " in a "+honor_amount+" manner. Reason: "+
             reason+". ("+ctime()+")\n");
  write("You dishonor "+OPN+" in a "+honor_amount+
             " manner.\n");
  TE(ob, "You have been dishonored in a "+honor_amount+
           " manner by "+TPN+".\n");
  overchannel(OPN+
              " has been dishonored in a "+honor_amount+
              " manner by "+TPN+"!\n");
  IP(ob)->add_honor(-new_honor);
  IP(ob)->save_me();
  IP(ob)->update_implants();
  return;}

honor(string str) {
/* Used to give honor points to a player */
  int honor_range, new_honor;
  string who, honor_amount, reason, honor_name;
  object ob;
  honor_range = find_honor_range(TP, RN);
  honor_name = find_range_names(TP, RN);
  if(!str) {
    write("Usage: honor <member> <amount> <reason>.\n");
    write("Your range of honoring is:\n\t"+honor_name+"\n");
    return;}
  if(!sscanf(str, "%s %s %s", who, honor_amount, reason)) {
    write("Usage: honor <member> <amount> <reason>.\n");
    write("Your range of honoring is:\n\t"+honor_name+"\n");
    return;}
  if(!reason) {
    write("You must also state your reason.\n");
    return;}
  if(!find_player(who)) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  ob = find_player(who);
  if(!IP(ob)) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  if((TP->query_level() < 20) && 
     (ob->query_level() >= 20)) {
    write("Wizards are immune to this.\n");
    return;}
  if((TP->query_level() < 20) && 
     (ob->query_real_name() == RN)) {
    write("You cannot honor yourself.\n");
    return;}
  if(!valid_range(honor_amount, honor_range)) {
    write("You have entered an invalid amount.\n");
    write("Your range of honoring is:\n\t"+honor_name+"\n");
    return;}
  new_honor = get_points(honor_amount);
  write_file(log+"HONOR", RN+" honored "+ORN+
             " in a "+honor_amount+" manner. Reason: "+
             reason+". ("+ctime()+")\n");
  write("You honor "+OPN+" in a "+honor_amount+
             " manner.\n");
  TE(ob, "You have been honored in a "+honor_amount+
           " manner by "+TPN+".\n");
  overchannel(OPN+
              " has been honored in a "+honor_amount+
              " manner by "+TPN+"!\n");
  IP(ob)->add_honor(new_honor);
  IP(ob)->save_me();
  IP(ob)->update_implants();
  return;}

int find_honor_range(object targ, string myname) {
    int range;
    object ob;
    ob = present("CyberNinja Implants", targ);
    if(ob->sensei())   range = 2;
    if(ob->shogun())   range = 3;
    if(ob->minister()) range = 4;
    if(ob->regent())   range = 20;
    if((myname == "dune") || (myname == "snow")) range = 500;
    return range;
}

string find_range_names(object targ, string myname) {
    string name;
    object ob; 
    ob = present("CyberNinja Implants", targ);
    name = "small, medium";
    if(ob->shogun())   name = "small, medium, large";
    if(ob->minister()) name = "small, medium, large, huge";
    if(ob->regent()) 
      name = "small, medium, large, huge, monstrous";
    if((myname == "dune") || (myname == "snow")) 
      name = "small, medium, large, huge, monstrous, godly";
    return name;
}

int valid_range(string test, int range) {
    if((test == "small") || (test == "medium")) return 1;
    if((test == "large") && (range >= 3))       return 1;
    if((test == "huge") && (range >= 4))        return 1;
    if((test == "monstrous") && (range >= 20))  return 1;
    if((test == "godly") && (range >= 500))     return 1;
    return 0;
}

int get_points(string test) {
    int points;
    points = 0;
    switch(test) {
      case "small":     points = 1;  break;
      case "medium":    points = 2;  break;
      case "large":     points = 3;  break;
      case "huge":      points = 4;  break;
      case "monstrous": points = 5;  break;
      case "godly":     points = 10; break;
      }
    return points;
}
