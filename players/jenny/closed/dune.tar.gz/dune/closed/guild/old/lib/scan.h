#include "DEFS.h"

rank_info() {
/* Simple sc command for a member, showing guild info */
  int level, degree, honor;
  int glev, gxp, lowxp, freexp;
  int amode;
  level = IP(TP)->query_art_level();
  degree = level - 7;
  if(degree < 0) degree = 0;
  honor = IP(TP)->query_honor();
  glev = IP(TP)->guild_lev();
  gxp = IP(TP)->guild_exp();
  lowxp = low_exp(glev);
freexp = gxp - lowxp;
  amode = IP(TP)->query_attack_mode();
  write(TPN+"'s CyberNinja guild info......\n");
  write("(O )( O)(O )( O)(O )( O)(O )( O)(O )( O)(O )( O)\n");
  if(RN == EMP1 || RN == EMP2) write("You are the EMPEROR.\n");
  if(IP(TP)->regent()) write("You hold the title of Grand Regent.\n");
  if(IP(TP)->shogun()) write("You hold the title of Shogun.\n");
  if(IP(TP)->sensei()) write("You hold the title of Sensei.\n");
  if(IP(TP)->head_referee()) write("You hold the title of Head Referee.\n");
  if(IP(TP)->minister()) write("You hold the title of Minister.\n");
  if(IP(TP)->referee()) write("You hold the title of Referee.\n");
  write("Honor: "+honor_title(honor)+"\n");
  write("Quality Level: "+glev+"\n");
  write("Guild Xp: "+gxp+"\n");
  write("Free Xp: "+freexp+"\n");
  write("Belt: "+belt_color(level)+"");
  if(degree > 0) write(", degree "+degree+"\n");
  else write("\n");
  write("Choice of Weapon: "+IP(TP)->query_weapon()+"\n");
  write("Strike Attack: ");
    if(!IP(TP)->query_strike_attack()) write("None\n");
    if(IP(TP)->query_strike_attack())
      write(IP(TP)->query_strike_attack()+"\n");
  write("Attack Mode: ");
    if(!amode) write("NONE\n");
    if(amode == 1) write("ATTACK\n");
    if(amode == 2) write("DEFENSE\n");
  write("Credit Balance: "+IP(TP)->balance()+"\n");
  write("( O)(O )( O)(O )( O)(O )( O)(O )( O)(O )( O)(O )\n");
}

