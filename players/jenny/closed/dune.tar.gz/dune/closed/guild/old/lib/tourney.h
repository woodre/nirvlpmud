#include "DEFS.h"

tourney() {
   write("Looking up tournament info...\n");
   call_other(MOREPATH, "more_file",
              "/players/dune/closed/guild/tournaments/reports");
   return 1;
}
