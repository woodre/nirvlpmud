#include "../DEFS.h"

cyberware() {
  /* method for players to see enhancement info */
  TE(TP, "You take out your handy CyberWare Manual.\n");
  move_object(clone_object(
    "/players/snow/closed/cyber/objects/cyberware_manual.c"),
    this_player());
  say(TPN+" takes out a thick manual.\n");
  return 1;
}
