#include "../DEFS.h"

flash() {
  /* light spell enhancement */
  int time;
  string name;
  mixed jumble;
  time = present("implants",TP)->guild_lev();
  time = time * 80;
  time = time + 1000;
  if(TP->query_spell_point() < 2) {
    write("You are too drained to do this.\n");
    return 1; }
  write("Glowing liquid courses through your veins.\n");
  write("Your body glows with an inner flourescent light.\n");
  say("Glowing liquid courses through "+TPN+"'s veins.\n");
  say(TPN+"'s body glows with an inner flourescent light.\n");
  IP(TP)->do_light(1);
  IP(TP)->set_light_on(1);
  TP->add_spell_point(-2);
  name = lower_case(TP->query_real_name());
  jumble = name+" "+time;
  call_out("stop", 1, jumble);
  return 1;
}



stop(mixed jumble) {
  string name;
  object ob;  
  int time;   
  sscanf(jumble, "%s %d", name, time);
  ob = find_player(name);
  time -= 1;
  if(time > 0) {
     jumble = name+" "+time;
     call_out("stop", 1, jumble);
     return 1; }
  TE(ob, "Your bodily glow fades away.\n");
  TE(ENV(ob), capitalize(ob->query_name())+
              "'s bodily glow fades.\n"+   
              "The room light dims.\n");   
  IP(TP)->do_light(-1);
  IP(TP)->set_light_on(0);
  return 1;
}
