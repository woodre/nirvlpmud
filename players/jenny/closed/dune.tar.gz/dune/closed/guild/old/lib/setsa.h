#include "DEFS.h"

enable_strike_attack(str) {
  if(!str) { write("Usage: setsa <attack>.\n"); return 1; }
  if(!valid_strike(str, TP->query_level()) ) {
    write("Usage: setsa <attack name>.\n"); return 1; }
  IP(TP)->set_strike_attack(str);
  write("Strike attack set to < "+str+" >. Now 'sa' to use.\n");
  return 1;
}
