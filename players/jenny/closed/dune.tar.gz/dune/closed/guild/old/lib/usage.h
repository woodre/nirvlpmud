#include "DEFS.h"

show_use() { /* Shows enhancements in use */
  write("\n");
  write("    ENHANCEMENTS IN USE   \n");
  write("\n");
  if(IP(TP)->query_blad_on()) write(RED+"  Blades"+OFF+"\n");
  if(IP(TP)->query_bion_on()) write(RED+"  Bionics"+OFF+"\n");
  if(IP(TP)->query_armor_on()) write(BROWN+"  SubDermal Armor"+OFF+"\n");
  if(IP(TP)->query_regen()) write(BLUE+"  Regeneration"+OFF+"\n");
  if(IP(TP)->query_rejuv()) write(BLUE+"  Rejuvenation"+OFF+"\n");
  if(IP(TP)->query_convert_on()) write(GREEN+"  Conversion"+OFF+"\n");
  if(IP(TP)->query_equil()) write(GREEN+"  Equilibration"+OFF+"\n");
  if(IP(TP)->query_digest()) write(BOLD+"  Digestion"+OFF+"\n");
  if(IP(TP)->query_light_on()) write(YELLOW+"  Biolight"+OFF+"\n");
  write("\n");
  return 1;
}
