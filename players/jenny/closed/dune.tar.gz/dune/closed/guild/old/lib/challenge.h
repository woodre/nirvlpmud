#include "DEFS.h"

match(string str) { /* counts kills for pk fights */
  object ob;
  int mylevel, targlevel, combatlevel;
  mylevel = this_player()->query_level();
  if(!str) {
    write("Who do you want to challenge?\n");
    return 1; }
  if(!present(str, environment(this_player()))) {
    write(capitalize(str)+" is not here.\n");
    return 1; }
  if(present("deathmatch_object", TP)) {
    write("You are already involved in a deathmatch.\n");
    return 1; }
  if(!find_player(str)) {
    write("You can only challenge other players.\n");
    return 1; }
  ob = find_player(str);
  if(ob == this_player()) {
    write("You cannot challenge yourself to a death match.\n");
    return 1; }
  targlevel = ob->query_level();
  combatlevel = mylevel - targlevel;
  if(combatlevel >= 5) {
    write("Your little death match is deemed unworthy.\n");
    return 1; }
  if(ob->query_ghost()) {
    write("You cannot challenge a ghost!\n");
    return 1; }
  if(!ob->query_pl_k()) {
    write("You can only attack other player killers.\n");
    return 1; }
  if(!this_player()->query_pl_k()) {
    write("You are not a player killer!\n");
    write("Type 'kill_players' to set your pk flag.\n");
    return 1; }
  write("You have challenged "+capitalize(str)+
        " to a match of death.\n");
  tell_object(ob, "You have been challenged by "+
                  TPN+" to a match of death.\n");
  move_object(clone_object(
        "/players/dune/closed/guild/deathmatches/deathob.c"),
        TP);
  call_out("observe_match", 1, RN+" "+str);
  return 1;
}



observe_match(string str) {
  object targ, ob;
  string mename, targname, name;
  sscanf(str, "%s %s", mename, targname);
  mename = lower_case(mename);
  targname = lower_case(targname);
  ob = find_player(mename);
  targ = find_player(targname);
  name = targ->query_name();   
  name = capitalize(name);     
  if(!present(targ, environment(ob))) {
    tell_object(ob, "The death match is terminated.\n");
    if(present("deathmatch_object", ob))
      destruct(present("deathmatch_object", ob));
    return 1; }
  if(targ->query_ghost()) {
    overchannel(OPN+" has defeated "+capitalize(targ->query_real_name())
    +" in a death match!\n");
    IP(ob)->add_kills(1);
    IP(ob)->save_me();   
    IP(ob)->get_deathmatch_permission(1);
    command("log_my_deathmatch "+mename+" "+targname, ob);
    tell_object(ob, "You have received one kill.\n");
    tell_object(ob, "You now have "+IP(ob)->query_kills()+" kills.\n");
    if(present("deathmatch_object", ob))
      destruct(present("deathmatch_object", ob));
    return 1; }
  call_out("observe_match", 1, mename+" "+targname);
  return 1;
}
