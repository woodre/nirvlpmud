#include "DEFS.h"

unsuspend(string str) {
  object ob, imp;
  string file;
  if(!str) {
    write("Unsuspend who?\n");
    return; }
  if(!find_player(str)) {
    write("No such player.\n");
    return; }
  ob = find_player(str);
  if(ob->query_guild_name() != "cyberninja") {
    write("User "+capitalize(str)+" is not a CyberNinja.\n");
    return; }
  if(IP(ob)) {
    write(capitalize(str)+" already has implants.\n");
    return; }
  imp = clone_object("/players/snow/closed/cyber/implants.c");
  move_object(imp, ob);
  IP(ob)->set_suspended(0);
  IP(ob)->save_me();
  ob->set_guild_title();
  TE(ob, "You have been reestablished into the CyberNinjas.\n");
  overchannel(OPN+" has been reinstated as a CyberNinja.\n");
  write_file(log+"SUSPEND",
    capitalize(str)+" was reestablished by "+RN+". ("+ctime()+")\n");
}
