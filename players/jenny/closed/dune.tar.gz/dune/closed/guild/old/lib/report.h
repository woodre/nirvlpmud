#include "DEFS.h"

report(string str) {
  if(!str) {
    write("What do you wish to report?\n");
    write("Remember to include the name of the tournament.\n");
    return 1; }
  write_file("/players/dune/closed/guild/tournaments/reports",
     RN+" reports: "+str+"  ("+ctime()+")\n");
  write("You file your report.\n");
  return 1;
}
