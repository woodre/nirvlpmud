#include "../DEFS.h"

void digestion(object ob);

status main(string str) {
  if(!((status)IPTP->item_corpse()) && !IPTP->guild_wiz()) return 0;
  if((status)IPTP->query_digest()) {
    write("Metabolic amelioration stopped.\n");
    IPTP->set_digest(0);
    return 1;
  }
  write("Metabolic amelioration begun.\n");
  IPTP->set_digest(1);
  call_out("digestion", 10, TP);
  return 1;
}


int digestion(object ob) {
  int INUM, in, st, SNUM;
     if(!ob) return 1;
  remove_call_out("digestion");
  st = (int)ob->query_stuffed();
  in = (int)ob->query_soaked();
  INUM = (in * 10) / ((int)ob->query_level() * 8);
  SNUM = (st * 10)/((int)ob->query_level() * 8);  
  if(!((status)IPOB->query_digest())) return 1;
  if((int)ob->query_spell_point() < 1) return 1;
  if(in > 2) {
    ob->add_soaked(-2);
  }
  if(st > 2) {
    ob->add_stuffed(-2);
  }
  if(!in && !st) {
    tell_object(ob,"No matter to metabolize.\n");
    IPOB->set_digest(0);
    return 1;
  }
  ob->add_spell_point(-1);
  call_out("digestion",10,ob);
return 1;
}
