#include "../DEFS.h"
#include DEFS_ENHANCEMENTS
#include FLUX_DAMAGE

status main(string who) {
  /* concentrated dmg enhancement */
  object ob;
  int dmg, messnum;

  if(!((status)IPTP->item_heatflux()) && !IPTP->guild_wiz()) 
    return 0;
  if(!gotsp(TP, ENERGY_HFLUX)) return 1;
  /* Feldegast 2-25-01 */
  if(this_player()->query_dead()) {
    notify_fail("You are a ghost!\n");
    return 0;
  }
  if(!who) {
    if(!TP->query_attack()) { 
      write("Usage: hflux <target>\n"); 
      return 1; }
    else ob = (object)TP->query_attack(); }
  if(who) {
    if(!present(who, environment(TP))) {
      write("There is no "+capitalize(who)+" here.\n"); 
      return 1; }
    else ob = present(who,environment(TP)); }
  if(!call_other(COMBATD, "valid_attack", ob, TP)) {
    write("You cannot flux that!\n");
    return 1;
  }
  if(!TP->query_interactive()) return 1;
  if(!((int)IPTP->query_flux_charges())) {
    write("You must charge your FluX before you can use it.\n");
    return 1; }
  IPTP->add_flux_charges(-1);
  if((int)IPTP->guild_lev() + 85 < random(100) ) {
    write("Your flux generator backfires!\n");
    if((int)TP->query_attrib("wil") < random(25)) {
      write("Built-up heat makes your skin smoke and burn!\n");
      TP->hit_player(random((int)IPTP->guild_lev()) + 1); 
    }
    TP->add_spell_point(-(random(20))); 
    return 1; 
  }

/* Cost of charging, failure, and enhancement are in addition */
   dmg = (int)IPTP->guild_lev() / 2;
    dmg = dmg * (random(6)+5);
    TP->add_spell_point(-dmg - 10);

  tell_room(environment(TP), 
    "\n"+TPN+" releases a burst of heat flux into "+OPN+"\n\n");
  if(dmg <= 15) {
    tell_room(environment(TP),
RED+"                "+OFF+"\n"+
RED+"  f         f   "+OFF+"\n"+
RED+" ff       ff    "+OFF+"\n\n");
  }
  if(dmg >= 16 && dmg <= 29) {
    tell_room(environment(TP),
RED+"   f         f          "+OFF+"\n"+
RED+"  f         f        f  "+OFF+"\n"+
RED+" fff      ff        fff "+OFF+"\n\n");
  }
  if(dmg >= 30) {
    tell_room(environment(TP),
RED+"    ff                           f                  "+OFF+"\n"+
RED+"   ff        f                   ff         f     f "+OFF+"\n"+
RED+"  ff        f        f         fff        f     ff  "+OFF+"\n"+
RED+" fff      ff        fff      fffff       ff    ffff "+OFF+"\n\n");
  }
  messnum = (int)ob->hit_player(dmg);
  if(ob) write(ob->query_name()+get_flux_damage(dmg, messnum));
  if(ob) {
    if(!TP->query_attack()) TP->attack_object(ob);
    if(!ob->query_attack()) ob->attack_object(TP); 
  }
  return 1;
}
