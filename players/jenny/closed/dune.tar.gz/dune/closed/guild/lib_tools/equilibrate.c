#include "../DEFS.h"

status main(string str) {
  if(!((status)IPTP->item_convert()) && !IPTP->guild_wiz()) return 0;
  if((status)IPTP->query_equil()) {
    write("Bodily equilibration discontinued.\n");
    IPTP->set_equil(0);
    return 1;
  }
  write("Bodily equilibration begun.\n");
  IPTP->set_equil(1);
  return 1;
}

equilibrate(object ob) {
  int ohp, osp;
  ohp = (int)ob->query_hp();
  osp = (int)ob->query_sp();
  if(osp - ohp < 3 && ohp - osp < 3) {
    write("Body equilibrated. Process stopped.\n");
    IPOB->set_equil(0);
    return 1;
  }
  if(ohp > osp) {
    ob->add_hit_point(-2);
    ob->add_spell_point(2);
  }
  if(osp > ohp) {
    ob->add_hit_point(2);
    ob->add_spell_point(-2);
  }
  tell_object(ob,"Equilibrating...\n");
  return 1;
}
