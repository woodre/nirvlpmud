#include "/players/dune/closed/guild/DEFS.h"
inherit "room/room";

reset(arg){
  if(!present("terminal")) {
    move_object(clone_object(BOARDDIR+"/guildboard2.c"),
    this_object());
  }

/* Comment out when no elections are being held
  if(!present("ballot box")) {
    move_object(clone_object
    (DUNEPATH + "/ballot_box.c"), this_object());
  }
*/

  if(!arg){
  set_light(1);
  short_desc=FUNKYNAME+" Main Guild Hall";
  long_desc=
"     The Grand Hall of the "+FUNKYNAME+" lies before you.\n"+
"Columns of raging fire stand along the sides of the black\n"+
"marble floor.  Gigantic red statues of past ninja warriors\n"+
"cast their flickering shadows upon the high white walls.\n"+
"The Hall is circular in shape, with the ceiling tapering to\n"+
"a glass dome overhead.\n";

  items=({
"fire", "The blazing fire shoots from the top of the columns",
"columns","Several large marble columns encircle the center of the room",
"floor","The black marble floor shines with a polished surface",
"statues","The statues stand over 20 feet high, near each column",
"ceiling","The ceiling opens up into a glass viewing window",
"dome","The glass dome gives you a clear view of the sky outside",
  });

  dest_dir=({
    ROOMDIR + "/hallway1.c", "north",
    ROOMDIR + "/entrance.c", "east",
    ROOMDIR + "/hallway2.c", "west",
    ROOMDIR + "/teleport.c", "up",
    ROOMDIR + "/archives.c", "down", 
  });
  }
}

init(){
    ::init();
if(this_player()->query_player() && !present("wockettell",this_player())){
string str;
str = BOLD+RED+this_player()->query_name()+" has invaded the guild hall!!!"+OFF;
call_other(CHANNELD,"overchannel",str);
}
}

realm() { return "NT"; }
feel() { return "no"; }
