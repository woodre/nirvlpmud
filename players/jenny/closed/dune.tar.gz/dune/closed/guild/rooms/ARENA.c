#include "/players/dune/closed/guild/DEFS.h"
inherit "room/room";

init() { 
  if(TP->query_ghost()) {
    if(!present(AFFILIATE, TP)) TP->quit();
    move_object(this_player(), "/room/church");
    call_other(TP, "glance");
  }
  add_action("revive","revive"); 
  add_action("leave_arena","leave");
  TP->set_fight_area();
  ::init();
  }

reset(arg){
  if(!arg){
  set_light(1);
  short_desc="The Guild Arena";
  long_desc=
"     You are in a large metallic dome.  At one end rests the giant\n"+
"statue of a kneeling ninja.  Its head reaches to the ceiling.\n"+
"A wide flat field stretches for hundreds of yards all around you.\n"+
"Overhead, a reader board hovers in mid-air.\n";

  items=({
"statue", "The black statue is a huge replica of an ancient ninja warrior",
"field","The field is of a hard synthetic surface",
"board","You read the digital display:\n"+
"If you die, type 'revive' to come back to life. If you wish to leave\n"+
"the Guild Arena, type 'leave' to return to the arenalounge",
"dome","Neon lights suspend from the metal dome ceiling",
  });

  dest_dir=({
      });
  }
}


revive() {
  if(this_player()->query_ghost()) {
    this_player()->remove_ghost();
    write("Your systems draw from backup power supplies.\n");
    write("Your body quivers with life again.\n");
  }
  return 1; 
}


leave_arena() {
  if(TP->query_attack()) {
    write("You cannot leave while fighting.\n"); 
    return 1; 
  }
  this_player()->rm_spar();
  write("You remove the sparring mark and leave the arena.\n");
  move_object(TP, ROOMDIR + "/arenalounge.c");
  call_other(TP, "glance");
  return 1;
}


realm() { return "NT"; }
int is_guild_arena() { return 1; }
query_spar_area() { return 1; }
feel() { return "no"; }