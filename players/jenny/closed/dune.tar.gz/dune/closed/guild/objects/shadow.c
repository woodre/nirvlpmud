/*
 * CyberNinja Defensive Skills
 * Reduces damage from 0-51% depending on mode
 */

#include "/players/dune/closed/guild/DEFS.h"
#define MAX_REDUX 20

object player;
int damage;

query_defense() { return 1; }

start_defense(who) {
   player = who;
   shadow(player, 1);
   return 1;
}

stop_defense() {
   shadow(player, 0);
   destruct(this_object());
   return 1;
}

quit() {
   shadow(player, 0);
   player->quit();
   return 1;
}

/* Attempt to make CyberEyes more thematically effective */

test_dark() {
  object gob;
  gob = present(GUILD_ID, player);
  if(gob && gob->item_eyes()) return 0;
  else return player->test_dark(); }

look(str) {
  object gob;
  gob = present(GUILD_ID, player);
  if(gob && gob->item_eyes()) {
    gob->do_light(2); player->look(str); gob->do_light(-2); }
  else { player->look(str); }
  return 1; }

move_player(str) {
  object gob;
  gob = present(GUILD_ID, player);
  if(player->query_level() > 19 || !gob || !gob->item_eyes()) {
    player->move_player(str); }
  else {
  if(!gob) player->move_player(str);
  if(!gob->item_eyes()) player->move_player(str);
  gob->do_light(2);
  if(player->query_real_name() == "snowtest") shadow_move(str);
  else player->move_player(str);
  gob->do_light(-2);
  }
}

/* HIDE IN SHADOWS CODE */
check_shadows() {
  object gob;
  gob = present(GUILD_ID, player);
  if(!gob) return 0;
  return gob->query_shadows(); }

short() {
  if(check_shadows()) {
  if(TP) if(TP->query_level() > 19)
    return player->short()+" (hiding in shadows)";
  return; }
  return player->short(); }

long() {
  if(check_shadows()) shadows_spotted();
  player->long(); }

shadows_spotted() {
  object gob;
  tell_object(player,"You are no longer hidden.\n");
  if(TP) tell_object(TP, "You spot "+player->query_name()+" in the shadows.\n");
  gob = present(GUILD_ID, player);
  if(gob) gob->set_shadows(0); return 1; }

/* DAMAGE REDUCTION CODE */
hit_player(dam) {
   int tmp_dam, modenum, defnum, basered;
   object att_obj, gob;
   string attname, defmsg;
   gob = present(GUILD_ID, player);
  if(!gob) destruct(this_object());
   modenum = gob->query_attack_mode();

/* Make sure we don't interfere with objects or spells that damage ourself */
  if(this_player())
  if(this_player() == player) { player->hit_player(dam); return dam; }

/* DEFENSE MODE - MAX OF 5 + 41% DAMAGE REDUCTION */
  if(modenum == 2) {
    defnum = gob->query_art_level() * 2;
    defnum += random(gob->query_art_level());
    basered = gob->query_art_level() / 3;
    if(defnum > 41) defnum = 41;
  }

/* ATTACK MODE - 30% DAMAGE INCREASE */
  if(modenum == 1) { defnum = -30; }

/* NORMAL MODE - DAMAGE REDUCTION MAX OF RANDOM(25)% */
  if(!modenum) {
    defnum = random(gob->query_art_level() + gob->query_art_level()/2);
    if(defnum > 25) defnum = 25; }

/* SHOW DEFENSIVE MESSAGE */
  if(defnum > 0 && defnum <= 10)
    show_move(random(5), player, environment(this_object()));
  if(defnum > 10 && defnum <= 25)
    show_move((random(10)+4), player, environment(this_object()));
  if(defnum > 25)
    show_move(random(18)+4, player, environment(this_object()));
/* SUB-DERMAL ARMORING - DAMAGE REDUCTION OF (RANDOM(10)+ 1) % */
  if(gob->query_armor()) defnum += (random(10)+ 1);
/* Bonus for Chosen One (guild leader) */
  if(gob->query_stone() == "diamond") defnum += 5;
/* Negative for Renegade */
  if(gob->query_nohonor()) defnum -= 20;
   tmp_dam = (100-defnum)*dam/100;
    tmp_dam -= basered;
/* Set damage reduction limit */
      if( (dam - tmp_dam) > MAX_REDUX) tmp_dam = dam - MAX_REDUX;
   player->hit_player(tmp_dam);
/* Testing for Snow */
  if(player->query_real_name() == "snow") tell_object(player, "DAMAGE TAKEN: "+tmp_dam+"/"+dam+"\n");
  if(gob->query_blad_on() && gob->guild_lev() > random(40)) {
/* this_player check added by wocket 2/25/99 */
if(this_player() && modenum != 2){
int bladedam;
    tell_room(environment(player),
    RED+this_player()->query_name()+" is impaled on "+player->query_name()+
    "'s blades!\n"+OFF);
bladedam = random(gob->guild_lev());
    this_player()->heal_self(-bladedam);
    this_player()->add_spell_point(bladedam);
}
}
   return tmp_dam;
}

show_move(int num, object player, object room) {
  string pmsg, rmsg, me;
  me = player->query_name()+" ";

if(num == 0) {
pmsg = "You cringe.";
rmsg = me+"cringes."; }

if(num == 1) {
pmsg = "You duck and pray.";
rmsg = me+"ducks and prays."; }

if(num == 2) {
pmsg = "You exhale at the moment of impact!";
rmsg = me+"exhales at the moment of impact!"; }

if(num == 3) {
pmsg = "You step back slightly.";
rmsg = me+"steps back slightly."; }

if(num == 4) {
pmsg = "You lean back.";
rmsg = me+"leans back."; }

if(num == 5) {
pmsg = "You twist slightly to the left.";
rmsg = me+"twists slightly to the left."; }

if(num == 6) {
pmsg = "You twist slightly to the right.";
rmsg = me+"twists slightly to the right."; }

if(num == 7) {
pmsg = "You step to the right.";
rmsg = me+"steps to the right."; }

if(num == 8) {
pmsg = "You step to the left.";
rmsg = me+"steps to the left."; }

if(num == 9) {
pmsg = "You perform a left forearm cross-parry.";
rmsg = me+"performs a left forearm cross-parry."; }

if(num == 10) {
pmsg = "You perform a right forearm cross-parry.";
rmsg = me+"performs a right forearm cross-parry."; }

if(num == 11) {
pmsg = "You shoulder-roll to your left.";
rmsg = me+"shoulder-rolls to the left."; }

if(num == 12) {
pmsg = "You shoulder-roll to your right.";
rmsg = me+"shoulder-rolls to the right."; }

if(num == 13) {
pmsg = "You flash-roll to your left!";
rmsg = me+"flash-rolls to the left!"; }

if(num == 14) {
pmsg = "You flash-roll to your right!";
rmsg = me+"flash-rolls to the right!"; }

if(num == 15) {
pmsg = "You flash-roll back!";
rmsg = me+"flash-rolls back!"; }

if(num == 16) {
pmsg = "You perform a back handspring!";
rmsg = me+"performs a back handspring!"; }

if(num == 17) {
pmsg = "You flip to your left!";
rmsg = me+"flips to the left!"; }

if(num == 18) {
pmsg = "You flip to your right!";
rmsg = me+"flips to the right!"; }

if(num == 19) {
pmsg = "You flip-turn left!";
rmsg = me+"flip-turns left!"; }

if(num == 20) {
pmsg = "You flip-turn right!";
rmsg = me+"flip-turns right!"; }

if(num == 21) {
pmsg = "You flip-turn back!";
rmsg = me+"flip-turns back!"; }

  tell_object(player, BOLD+pmsg+OFF+"\n");
  room_tell(rmsg+"\n");
  return; }

room_tell(string rmsg) {
  object allroom;
  int i;
  allroom = all_inventory(environment(player));
  for(i=0; i < sizeof(allroom); i++) {
    if(allroom[i] != player) tell_object(allroom[i], rmsg); }
  return; }

#include "shadow_move.h"
