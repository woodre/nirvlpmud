#include "/players/dune/closed/guild/DEFS.h"

status id(string str) { 
  return str == "box" || str == "suggestion box"; 
}

string short() { return "The Emote Suggestion Box"; }

void long() {
  write("Usage: 'suggest <emote>'\n"+
        "Please drop a suggestion in this box if you\n"+
        "would like to see guild emotes. If enough\n"+
        "suggestions are given, the Cyberninjas will\n"+
        "have special guild emotes.\n"+
        "Example: 'suggest You smile, exposing your fangs'\n");
}

status get()  { return 0; }
status drop() { return 1; }

void init() {
  add_action("suggest","suggest");
  add_action("show_suggest","show_suggest");
}


status suggest(string str) {
  string name;
  if(!str) {
    write("What emote do you suggest?\n");
    return 1; }
  name = capitalize((string)this_player()->query_real_name());
  write_file(EMOTES, "["+name+"] "+str+"\n");
  write("Thank you for your emote.\n");
  return 1; 
}


status show_suggest() {
  if(this_player()->query_level() > 20) tail(EMOTES);
  return 1;
}
