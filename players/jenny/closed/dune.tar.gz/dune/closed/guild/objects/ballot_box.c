#include "/players/dune/closed/guild/DEFS.h"

void init() {
  add_action("vote","vote");
  add_action("tally","tally"); 
}

status id(string str) { 
  return str == "ballot box" || str == "box"; 
}

status get()          { return 0; }
status drop()         { return 1; }
int query_weight()  { return 0; }
int query_value()   { return 0; }

string short() { return "--@ The Ballot Box @--"; }

void long() { 
  write(
  "     Drop your vote here if you wish to own a\n"+
  "guild office. Or, you may vote for a different\n"+
  "person instead. However, you may only vote once\n"+
  "for each office.\n"+
  "The guild office available is the Minister.\n"+      
  "If you think you or another person can role-play\n"+
  "and come up with ideas on your own, then vote!\n"+
  "Read the CyberNinja Terminal for more info.\n"+            
  "****Just type 'vote <person>'\n");                         
}

status vote(string str) {
  string person, office, name;
  if(!str) {
    write("Usage: vote <person>\n");
    return 1; }
  name = capitalize((string)this_player()->query_real_name());
  write_file(BALLOTS, name+
    " voted for "+capitalize(str)+", office: Minister"+
    ".\n     "+ctime()+"\n");
  write("You slip a ballot into the ballot box.\n");
  say(name+" slips a ballot into the ballot box.\n");
  return 1; 
}


status tally() {
  object imp;
  string name, file;
  if(!IPTP) {
    write("You dare tally another guild's votes?!\n");
    return 1; }
  imp = IPTP;
  name = (string)this_player()->query_real_name();
  if(!call_other(OFFICED, "checkStone", TP, "ruby sapphire diamond")) 
    return 0;
  file = BALLOTS;
  write("You begin tallying the votes.\n");
  write("Note: Each person gets only\n"+
        "two votes (yourself and one other\n");
  call_other(MORED, "more_file", file);
  return 1; 
}
