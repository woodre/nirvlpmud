shadow_move(dest_dir) {
  string dir, dest;
  object gob;
  gob = present(GUILD_ID, player);
  if(!check_shadows()) { player->move_player(dest_dir); return; }
  if(!dest_dir) { write("No destdir.\n"); return; }
  if(sscanf(dest_dir, "%s#%s", dir, dest) != 2) {
    write("Bad movement.\n"); return; }
  if(random(30) > (total_stealth() - gob->shadows_modifier()) ) {
  write("You step out of the shadows by mistake.\n");
  gob->set_shadows(0);
  player->move_player(dest_dir); return;
  }
  move_object(player, dest);
  gob->add_shadows_modifier(8);
  command("look", player);
  return 1; }

total_stealth() {
  int stealth, rank;
  stealth = player->query_attrib("ste");
  rank = present(GUILD_ID, player)->guild_lev();
  return stealth+rank;
}
