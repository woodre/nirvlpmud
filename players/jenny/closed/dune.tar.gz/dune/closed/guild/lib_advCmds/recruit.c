#include "../DEFS.h"
#include DEFS_GLEVELS
#include DEFS_HLEVELS
#define  LEVEL  8

status main(string who) {
/* Way to recruit new guild members */
  object ob;
  if((string)TP->query_real_name()=="armblessed"){ write("You have been restricted from recruting.\n"); return 1; }

  if(!gotrank(TP,LEVEL)){
    notify_fail("Your chip level is not advanced enough to recruit.n");
    return 0;
  }
  if(!call_other(OFFICED, "checkStone", TP, "diamond ruby sapphire emerald"))
    return 0;
  if(!who || !find_player(who) || 
     find_player(who)->query_level() > 19) {
    write("Usage: recruit <player>.\n");
    return 1; }
  ob = find_player(who);
  if(IPTP->query_recruitee()){
    call_other(RECRUITD,"check_recruitee",this_player());
    if(IPTP->query_recruitee()){
      write("You are still training "+IPTP->query_recruitee()+".\n");
      return 1;
    }
  }
  if(present(RECRUIT, ob)) {
    tell_object(TP, OPN+" is already recruited.\n");
    return 1; }
  if(call_other(MEMBERD, "already_in_a_guild", ob)) {
     tell_object(TP, OPN+" is already in a guild.\n");
     return 1;}
  if((int)ob->query_level() < MIN_JOIN_LEVEL) {
     tell_object(TP,
       OPN+" is not level "+MIN_JOIN_LEVEL+" yet.\n");
     return 1; }
  write_file(LOGDIR + "/RECRUIT", 
    TRN+" recruited "+capitalize(who)+" ("+ctime()+")\n");
  write("You have shown "+capitalize(who)+" the Way.\n");
  tell_room(environment(ob), 
    TPN+" has shown "+capitalize(who)+" the Way.\n");
  move_object(clone_object(OBJDIR + "/recruitob.c"), ob);
  present(RECRUIT,ob)->set_recruiter(this_player()->query_real_name());
  tell_object(ob, "You have been shown the Way.\n"+
    "Learn it, and you will soon be along the path\n"+
    "to greater destiny.\n");
  IPTP->save_me();
  return 1; 
}
