#include "../DEFS.h"
#include DEFS_GLEVELS

status main(string str) {
  string brand;
  object ob;
  if(!gotrank(TP, MAX_QUALITY_LEVEL)) return 0;
  if(!str || !find_player(str)) {
    write("Usage: upgrades <member>.\n");
    return 1; }
  ob = find_player(str);
  write("\n~~Available Upgrades for "+OPN+"\n");
  call_other(GLEVELD, "checkBrand", TP, ((int)IPOB->guild_lev())+1, 0);
  write(  "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
  return 1;
}
