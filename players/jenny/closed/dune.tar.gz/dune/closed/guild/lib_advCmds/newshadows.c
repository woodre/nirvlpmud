#include "../DEFS.h"
#define LEVEL         8

status main(string str) {
  /* command to hide in shadows */
  object ob, gob;
  gob = present(GUILD_ID, TP);
  if(!gotrank(TP, LEVEL)) return 0;
  if((string)TP->query_real_name() != "snowtest" ) return 0;
  if(gob->query_shadows()) {
    write("You step out of the shadows.\n");
    say(TPN+" steps out of the shadows.\n");
    gob->set_shadows(0);
    return 1; }
  if(!this_object()->check_can()) { write("You cannot hide in shadows right now.\n");
    return 1; }
  if( !((int)TP->query_invis()) ) say(TPN + " disappears into the shadows.\n");
  write("You hide in shadows.\n");
  gob->set_shadows(1);
  return 1;
}

int check_can() {
  object env, ob;
/*
  if(TP->query_hunter() || TP->query_hunted()) return 0;
*/
  env = environment(TP);
  ob = first_inventory(env);
  while(ob) {
    if(living(ob)) {
      if(!present(GUILD_ID, ob)) return 0; }
    ob = next_inventory(ob); }
  return 1; }
