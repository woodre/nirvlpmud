These are modified off the pet guidelines in the following manner:

They, except rollingmech, have lower hps ( alot lower)
They, except rollingmech, do more damage (note- special attack is in place
  of the regular attack, not in addition)
They return is_pet() and have a higher healing rate than most pets.
They are expensive (from 2k for weakest to 20k for strongest)
They cannot attack players or other pets.
The expensive mechs are protected against player attacks.
