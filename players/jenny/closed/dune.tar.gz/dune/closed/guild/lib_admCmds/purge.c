#include "../DEFS.h"

status main(string str) {
  string file;
  int guild_xp, guild_rank, real_exp;
  object corpse, ob;

  if(!call_other(OFFICED, "checkStone", TP, "diamond")) return 0;
  if(!str || !find_player(str) || 
     !present(GUILD_ID, find_player(str))) {
    write("Purge which baneling?\n");
    return 1; }
  ob = find_player(str);
  if(!call_other(MEMBERD, "leave_ninjas", ob)) {
    write("You were not able to purge "+capitalize(str)+"\n");
    return 1; }
  tell_room(environment(ob), 
    OPN+"'s cyberlinks are disconnected.\n"+
    OPN+"'s implants are removed, painfully.\n"+
    OPN+" is purged along with the rest of the guild trash.\n");
  call_other(CHANNELD, "overchannel", 
    "Baneling "+OPN+" has been purged from the guild.\n");
  write_file(LOGDIR + "/EXECUTE", 
    capitalize(str)+" was purged by "+TRN+". ("+ctime()+"\n");
  return 1;
}
