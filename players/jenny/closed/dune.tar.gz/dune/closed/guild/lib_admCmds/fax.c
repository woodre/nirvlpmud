#include "../DEFS.h"

status main(string str) {
/* takes str and refers to files in fax directory */
  if(!call_other(OFFICED,"checkStone",TP,"diamond ruby sapphire emerald onyx"))
    return 0;
  if(!str) {
    cat(FAXDIR+"/fax_menu.txt");
    return 1; 
  }
  if(!call_other(MORED, "view_doc", str, FAXDIR))
    write("You have requested a fax of a non-existant document.\n");
  return 1;
}
