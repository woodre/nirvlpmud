#include "../DEFS.h"
#include DEFS_ALEVELS
#include DEFS_OFFICES

status main(string str) {
/* Simple sc command for a member, showing guild info */
  int level, degree, honor, amode, glev;
  int gxp, lowxp, freexp;
  string brand, role, stone;
  object ob;

  if(IPTP->guild_lev() < 10) return 0;
  if(!str || !find_player(str) ||
     !present(GUILD_ID, find_player(str)) ||
     find_player(str)->query_invis() > TP->query_level()) {
    write("Which ninja do you want to scan?\n");
    return 1;
  }
  ob = find_player(str);
  level  = (int)IPOB->query_art_level();
  degree = level - BLACK_BELT;
  if(degree < 0) degree = 0;
  honor  = (int)IPOB->query_honor();
  brand  = capitalize((string)IPOB->query_brand());
  gxp    = (int)IPOB->guild_exp();
  glev   = (int)IPOB->guild_lev();
  lowxp  = (int)call_other(GLEVELD, "low_exp", glev);
  freexp = gxp - lowxp;
  amode  = (int)IPOB->query_attack_mode();
  stone  = (string)IPOB->query_stone();
  if(role = (string)call_other(OFFICED, "findRole", ob)) {}
  else role = 0;
  if(!stone) stone = NOSTONE; 
  write(LINE+BOLD+YELLOW);
  write(OPN+"'s guild info......\n");
  write(OFF+LINE);
  if(ORN == OWNER1 || ORN == OWNER2) write(OPN+" is a Guild Owner.\n");
  else if(role) write(OPN+" holds the title of "+role+".\n");
  write(OPN+"'s "+stone+" eyes sparkle with inner light.\n"); 
  write("Honor: "+(int)call_other(HLEVELD, "honorTitle", honor)+"\n");
  write("Neural Chip: "+brand+"\n");
  write("Guild Xp: "+gxp+"\n");
  write("Free Xp: "+freexp+"\n");
  write("Belt: "+(string)call_other(ALEVELD, "findBeltColor", level)+"");
  if(degree > 0) write(", degree "+degree+"\n");
  else write("\n");
  write("Choice of Weapon: "+(string)IPOB->query_weapon()+"\n");
  write("Attack Mode: ");
  if(!amode) write("NONE\n");
  if(amode == 1) write("ATTACK\n");
  if(amode == 2) write("DEFENSE\n");
  write("Credit Balance: "+(int)IPOB->balance()+"\n");
  write(LINE);
  return 1;
}

