#include "../DEFS.h"

status main(string str) {

  if(!str) {
      write("Usage: overchannel <msg>\n");
    return 1;
  }
    call_other(CHANNELD,"overchannel",str);
  return 1;
}

