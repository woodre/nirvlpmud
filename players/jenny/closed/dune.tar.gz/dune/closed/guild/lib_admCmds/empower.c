#include "../DEFS.h"

status main(string str) {
  if(!call_other(OFFICED, "checkStone", TP, "diamond ruby sapphire")) 
    return 0;
  if(!str) {
    call_other(OFFICED, "empowerUsage");
    return 1;
  }
  if(call_other(OFFICED, "empower", str)) {
    write("Your delegation of authority succeeded.\n");
  }
  else write("Your delegation of authority failed.\n");
  return 1;
}