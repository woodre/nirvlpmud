#include "../DEFS.h"

status main(string str) {
  object * everyone;
  object member;
  int i, bal;

  if(!call_other(OFFICED, "checkStone", TP, "diamond ruby sapphire")) 
    return 0;
  everyone = users();
  write("Guild balances...........................\n");
  for(i = 0; i < sizeof(everyone); i++) {
    if(!everyone[i]->query_invis()) {
      if(present(GUILD_ID, everyone[i])) {
        member = present(GUILD_ID, everyone[i]);
        bal = (int)member->balance();
        write(pad(capitalize((string)everyone[i]->query_name()), 20));
        write(bal+" @'s\n");
      }
    }
  }
  return 1;
}
