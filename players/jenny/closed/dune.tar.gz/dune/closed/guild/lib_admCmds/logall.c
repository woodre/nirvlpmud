#include "../DEFS.h"

status main(string str) {
  string file;

  if(!call_other(OFFICED, "checkStone", TP, "onyx")) return 0;
  if(!str) {
    write("You may access the following data logs.\n");
    ls(LOGDIR);
    return 1; 
  }
  file = LOGDIR +"/"+ str;
  if(file_size(file) >= 0) {
    write("You access the " + str + " data log.\n");
    call_other("/obj/_more.c","more_file",file);
    return 1; 
  }
  write("There is no " + str + " data log.\n");
  return 1; 
}
