#include "../DEFS.h"

status main(string str) {
  string who, what, sphere;
  object ob;
  
  if(!IPTP->guild_manager()) return 0;
  if(!str || !sscanf(str, "%s %s", who, what) ||
  !find_player(who) || !present(GUILD_ID, find_player(who))) {
    write("Usage: set_immortal <wizard> <sphere>\n"+
          "   Where type is:\n");
    call_other(OFFICED, "listSpheres");
    return 1; 
  }
  ob = find_player(who);
  sphere = ((string)call_other(OFFICED, "findSphere", ob, what));
  if(!sphere) {
    write("Usage: set_immortal <wizard> <sphere>\n"+
          "   Where type is:\n");
    call_other(OFFICED, "listSpheres");
    return 1; 
  }
  IPOB->set_sphere(what);
  write("Done.\n");
  return 1;
}