inherit "obj/armor";

reset(arg){
   ::reset(arg);
   set_name("coral warplate");
   set_short("A suit of coral warplate");
   set_alias("warplate");
   set_long("The coral warplate is a piece of art.\n"+
            "Jagged polished shells stud the metal.\n"+
            "The inside of the armor is lined with\n"+
            "comfortable leather.\n");
   set_ac(random(4)+3);
   set_weight(random(3)+5);
   set_value(600);
}
