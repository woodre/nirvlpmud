inherit "obj/monster";
reset(arg){
   int a;
   ::reset(arg);
   if(arg) return;
   a = random(3) + 1;
   set_name("aerial servant");
   set_race("air elemental");
   set_alias("servant");
   if (a == 1) {
set_short("A vaporous aerial servant");
set_long("The vapor servant is hard to see, but its\n"+
         "movements give it away.  It has the body\n"+
         "of a humanoid.\n");}
   if (a == 2) {
set_short("A solid aerial servant");
set_long("The(solid servant is large and its body\n"+
         "is of solid cloud.  Two black holes mark\n"+
         "where its eyes should be.\n");}
   if (a == 3) {
set_short("A greater aerial servant");
set_long("The greater servant is massive.  It stands,\n"+
         "or rather 'floats', up to 12 feet high.\n"+
         "It moans in eternal servitude.  But who\n"+
         "is its master?\n");}
if (a == 1) { set_level(10);
   set_hp(random(20)+140); set_wc(14); set_ac(8);}
if (a == 2) { set_level(11);
   set_hp(random(25)+150); set_wc(15); set_ac(9); }
if (a == 3) { set_level(12);
   set_hp(random(30)+160); set_wc(16); set_ac(9); }
   set_al(0);
   set_move_at_reset();
   if (a <= 2) set_chance(15);
   if (a > 2) set_chance(20);
   if (a == 1) set_spell_dam(10);
   if (a == 2) set_spell_dam(15);
   if (a == 3) set_spell_dam(20);
   set_spell_mess1("The aerial servant blasts you with a magic wind.");
   set_spell_mess2("The aerial servant sucks the air from your body.");
}

heart_beat(){
  object more;
  if((this_object()->query_attack()) && (random(35) == 5)){
       more=clone_object("/players/dune/monsters/airservant.c");
       move_object(more, this_object());
       write("The aerial servant summons another of its kind.\n");
}
  ::heart_beat();
}
