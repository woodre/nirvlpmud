inherit "obj/monster";

int once;
object gold, more;
int a;
string Name, name;

reset(arg){
   once = 0;
   ::reset(arg);
   if(arg) return;
   a = random(9) + 1;
   if (a == 1) name = "simon";
   if (a == 2) name = "malachias";
   if (a == 3) name = "groomshu";
   if (a == 4) name = "jiriki";
   if (a == 5) name = "hubert";
   if (a == 6) name = "molgar";
   if (a == 7) name = "shanker";
   if (a == 8) name = "pryrates";
   if (a == 9) name = "isgrimnur";
   set_name(name);
   set_race("human");
   set_alias(name);
   Name = capitalize(name);
   set_short(Name+", the Tower guard");
   set_long(Name+" has long served as stairwell guard for\n"+
         "the Tower ever since he was a wee little kid. He\n"+
         "trained and worked hard to tone his skills up.\n"+
         "However, he looks like he will never be\n"+
         "the warrior he always wanted to be.\n");
   set_level(5);
   set_hp(random(10)+70);
   set_al(0);
   set_wc(9);
   set_ac(5);
   set_whimpy();
   gold=clone_object("obj/money");
   gold->set_money(random(100)+50);
   move_object(gold,this_object());
}

heart_beat(){
  if((this_object()->query_attack()) &&
    (this_object()->query_hit_point() < 40) && (once == 0)) {
       more=clone_object("/players/dune/monsters/otherguard.c");
       move_object(more, environment(this_object()));
       say(Name+" SHOUTS FOR HELP, and another guard answers!\n");
       say("A big burly man comes running down the stairs.\n");
       say("The man comes to a halt when he reaches the bottom\n");
       say("and shouts, 'Hey YOU, leave "+Name+" alone!\n");
       once = 1;
}
::heart_beat();
}

 id(str)  {
  return str == "guard" || str == name || str == Name;
 }
