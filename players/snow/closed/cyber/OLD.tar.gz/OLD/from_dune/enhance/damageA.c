id(str) { return str == "damagetypeA"; }

get() { return 1; }
drop() { return 0; }
query_weight() { return 0; }
query_value() { return 0; }
