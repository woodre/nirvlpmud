id(str) { return str == "armortypeB"; }

get() { return 1; }
drop() { return 0; }
query_weight() { return 0; }
query_value() { return 0; }
