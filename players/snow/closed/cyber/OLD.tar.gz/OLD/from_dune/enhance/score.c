id(str) { return str == "ss"; }

init() { add_action("score","ss"); }

score() {
  write(TP->short()+"\n");
  write(pad("Level: "+TP->query_level(), 32));
  write("Extra Level: "+TP->query_extra_level()+"\n");
  write(pad("Coins: "+TP->query_money(), 32));
  write("Experience: "+TP->query_exp()+"\n");
  write(pad("Hit Points: "+
         TP->query_hp()+"/"+TP->query_mhp(), 32));
  write("Energy: "+
         TP->query_sp()+"/"+TP->query_msp()+"\n");
  write("Quest points: "+TP->query_quest_point()+"\n");
  TP->show_age();
if(TP->query_wimpy()) 
  write("Wimpy mode.\n");
else
  write("Brave mode... Yeah, that's a CyberNinja!\n");
  return 1;
}
