#define TP  this_player()
#define ENV environment
#define TPN capitalize(TP->query_name())
#define TE  tell_object
#define TR  tell_room

int time;

id(str) { return str == "bioflash" || str == "flash"; }

init() {
  add_action("flash","fl");
  }

short() { return "A bioflash";}

long() {
  TE(TP,"     This is a light device.\n"+
        "This code will be in ninjadaem.c\n"+
        "The flash verb will be in implants.c\n"+
        "Type 'fl' to use.\n");}

flash() {
  time = present("implants",TP)->guild_lev();
  time = time + 5;
  time = time * 3;
  if(time >= 50) time = 50;
  if(TP->query_spell_point() < 2) {
    write("You are too drained to do this.\n");
    return 1; }
  write("Your body glows with flourescent blue light.\n");
  say(TPN+"'s body glows with flourescent blue light.\n");
  set_light(1);
  TP->add_spell_point(-2);
  call_out("stop", 1, TP);
  return 1;
}

stop(object ob) {
  time -= 1;
  if(time > 0) call_out("stop", 1, TP);
  TE(ob, "Your bodily glow fades away.\n");
  TE(ENV(ob), capitalize(ob->query_name())+
              "'s bodily glow flickers and fades out.\n");
  set_light(0);
  return 1;
}
