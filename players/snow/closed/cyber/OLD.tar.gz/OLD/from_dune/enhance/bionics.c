#define TP  this_player()
#define ENV environment
#define TPN capitalize(TP->query_name())
#define TE  tell_object
#define TR  tell_room

id(str) { return str == "bionics"; }

short() { return "Bionics";}

long() {
  TE(TP,"Bionics adds damage to your attacks.\n"+
        "code will be in ninjadaem.c\n"+
        "At higher quality levels, it\n"+
        "does more damage\n"+
        "Usage: 'bionics'\n");
   /* lesser form of bionics: adrenalin surge  */
}

init() {
add_action("bionics","bionics");
}

string gen(object ob) {
  string gender, gen;
  gender = ((string)ob->query_gender());
  switch(gender) {
    case "male": gen = "his"; break;
    case "female": gen = "her"; break;
    case "creature": gen = "its"; break;
    }
  return gen;
}

bionics() {
  if(TP->query_spell_point() < 15) {
    write("Use of bionics is too draining for your state.\n");
    return 1; }
  if(present("bionics", TP)) {
    write("You already have activated your bionics.\n");
    return 1; }
  TP->add_spell_point(-15);
  /* move_object and clone_object to TP, will be invis */
  /* the bionics verb will be in init() of implants.c */
  write("Bionics engaged.\n");
  say(TPN+" engages "+gen(TP)+" bionics.\n");
  call_out("biodam", 1, TP);
  return 1;
}

biodam(object ob) {
  object targ;
  int lev;
  if(!ob->query_attack()) {
    TE(ob, "Bionics disengaged.\n");
    /* dest bionics object */
    return 1;}
  lev = present("implants", ob)->guild_lev();
  if(lev >= 12) lev = 12;
  lev = lev / 3;
  targ = ob->query_attack();
  call_other(targ, "heal_self", -lev);
  call_out("biodam", 3, ob);
  return 1;
}
