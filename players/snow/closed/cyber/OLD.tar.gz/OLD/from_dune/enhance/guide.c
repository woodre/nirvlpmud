#define TP  this_player()
#define ENV environment
#define TPN capitalize(TP->query_name())
#define TE  tell_object
#define TR  tell_room
#define WHO capitalize(who)

id(str) { return str == "guide" || str == "guide"; }

short() { return "A guide";}

long() {
  TE(TP,"This guides a player.\n"+
        "code will be in ninjadaem.c\n"+
        "This is not an enhancement\n"+
        "Usage: guide <who> <where>\n");}

init() {
add_action("guide","guide");
}

guide(string str) {
  string place, who;
  string * exits;
  object ob;
  int size, i;
  if(!str) {
    write("Usage: guide <player> <direction>\n");
    return 1;}
  if(!sscanf(str, "%s %s", who, place)) {
    write("Usage: guide <player> <direction>\n");
    return 1;}
  if(!find_player(who)) {
    write("You can only guide players.\n");
    return 1;}
  ob = find_player(who);
  if(ob->query_level() > 19) {
    write("You seem unable to affect that type of cyberspace.\n");
    return 1; }
  exits = ENV(TP)->query_dest_dir();
  if(!exits) {
    write("There is no place to guide "+WHO+".\n");
    return 1;}
  size = sizeof(exits);
  size = size - 1;
  for(i = 0; i <= size; i++) {
   if(exits[i]) {
    if(place == exits[i]) {
      command(exits[i], ob);
      write("You guide "+WHO+" "+exits[i]+"\n");
      TE(ob, TPN+" guides you "+exits[i]+".\n");
      return 1;
      }
     }
    }
  write("You were unable to guide "+WHO+" "+place+".\n");
  return 1;
}
