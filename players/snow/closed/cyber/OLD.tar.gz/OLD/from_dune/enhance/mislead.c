#define TP  this_player()
#define ENV environment
#define TPN capitalize(TP->query_name())
#define TE  tell_object
#define TR  tell_room
#define STR capitalize(str)

id(str) { return str == "mislead" || str == "mis"; }

short() { return "A mislead";}

long() {
  TE(TP,"This misleads a player.\n"+
        "code will be in ninjadaem.c\n"+
        "This is not an enhancement\n"+
        "Usage: 'guide <who>'\n");}

init() {
add_action("mislead","mislead");
}

mislead(string str) {
  string * exits;
  int size, rand;
  if(!str) {
    write("Usage: mislead <player>\n");
    return 1;}
  if(!find_player(str)) {
    write("You can only mislead players.\n");
    return 1;}
  if(find_player(str)->query_level() > 19) {
    write("You seem unable to affect that type of cyberspace.\n");
    return 1; }
  if(!present(str, ENV(TP))) {
    write(STR+" is not here.\n");
    return 1; }
  exits = ENV(TP)->query_dest_dir();
  if(!exits) {
    write("There is no place to mislead "+STR+".\n");
    return 1;}
  size = sizeof(exits);
  if(!random(size)) {
    write("Your misdirection has failed.\n");
    return 1; }
  rand = random(size);
  write("You mislead "+STR+" "+exits[rand]+"\n");
  command(exits[rand], find_player(str));
  TE(find_player(str), "You have been misled.\n");
  return 1;
}
