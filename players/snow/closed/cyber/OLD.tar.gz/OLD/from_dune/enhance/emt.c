#define TP  this_player()
#define ENV environment
#define TPN capitalize(TP->query_name())
#define TE  tell_object
#define TR  tell_room

id(str) { return str == "emt"; }

short() { return "An emt";}

long() {
  TE(TP,"The emt controls emotion.\n"+
        "code will be in ninjadaem.c\n"+
        "At higher quality levels, it allows\n"+
        "user to force people to attack him.\n");
  if(present("implants",TP)->guild_lev() < 7) write("Usage: emt p\n");
  else write("Usage: emt [p/a]\n");
}

init() {
add_action("emt","emt");
}

emt(string str) {
  object ob;
  string name;
  if(!str) {
    write("Usage: emt [p/a]\n");
    return 1; }
  if(TP->query_spell_point() < 35) {
    TP->add_spell_point(-35);
    write("Your energy reserves are too low.\n");
    return 1; }
  if(str == "p") {
    TP->add_spell_point(-35);
    write("You generate a sense of peace.\n");
    ob=first_inventory(ENV(TP));
    while (ob) {
     if (living(ob)) {
      if(ob->query_attack()) {
           (ob->query_attack())->stop_fight();
           ob->stop_fight();
           }
      }
      ob = next_inventory(ob);
     }
    say(TPN+ " generates a sense of peace.\n");
    return 1; }
  if(str == "a") {
    if(present("implants",TP)->guild_lev() < 7) {
      write("Such an emotion requires higher quality of enhancements.\n");
      return 1; }
    write("You generate a sense of aggression.\n");
    ob=first_inventory(ENV(TP));
    while (ob) {
     if (living(ob)) {
        name = ob->query_name();
        name = lower_case(name);
        if(find_player(name)) {
          if(find_player(name)->query_pl_k() &&
             find_player(name)->query_level() < 20)
            find_player(name)->attack_object(TP); }
        if(!find_player(name)) {
          if(ob->query_attack())
             (ob->query_attack())->attack_object(TP);
          ob->attack_object(TP); }
        }
      ob = next_inventory(ob);
     }
    say(TPN+ " generates a sense of aggression.\n");
    return 1; }
  write("Usage: emt [p/a]\n");
  return 1;
}
