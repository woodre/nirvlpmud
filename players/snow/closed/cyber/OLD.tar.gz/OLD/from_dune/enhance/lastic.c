#define TP  this_player()
#define ENV environment
#define TPN capitalize(TP->query_name())
#define TE  tell_object
#define TR  tell_room

int prot;

id(str) { return str == "superlastic" || str == "armor"; }

short() { return "Superlastic";}

long() {
  TE(TP,"Superlastic is an enhancement that adds 1 ac.\n"+
        "code will be in ninjadaem.c\n"+
        "It must be powered up in order to use.\n");
  /* enduro meld, metal hide, superlastic */
}

init() {
add_action("lastic","lastic");
}

lastic() {
  if(TP->query_spell_point() < 30) {
    write("The lastic armor needs more juice than you have.\n");
    return 1; }
  if(present("superlastic", TP)) {
    write("You already powered up your lastic armor.\n");
    return 1; }
  prot = present("implants",TP)->guild_lev();
  if(prot > 12) prot = 12;
  prot = prot / 4;
  if(prot <= 0) prot = 1;
  TP->add_spell_point(-30);
  /* move object clone_object to TP, will be invis */
  /* the lastic verb will be in init() of implants.c */
  write("You power on your superlastic armor.\n");
  say(TPN+"  powers up "+gen(TP)+" superlastic armor.\n");
  TP->add_ac(prot);
  call_out("powerOn", 1, TP);
  return 1;
}

string gen(object ob) {
  string gender, gen;
  gender = ((string)ob->query_gender());
  switch(gender) {
    case "male": gen = "his"; break;
    case "female": gen = "her"; break;
    case "creature": gen = "its"; break;
    }
  return gen;
}

powerOn(object ob) {
/* waits for player to stop attacking, then restores ac */
  object targ;
  int lev;
  if(!ob->query_attack()) {
    TE(ob, "Your superlastic armor shuts off.\n");
    ob->add_ac(-prot);
    /* dest lastic object */
    return 1;}
  call_out("powerOn", 1, ob);
  return 1;
}
