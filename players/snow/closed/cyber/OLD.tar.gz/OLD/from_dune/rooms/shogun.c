#include "guildward.c"
inherit "room/room";

init() { ::init(); officeward("shogun", this_player()); }

reset(arg){

  if(!present("officerboard")) {
   move_object(clone_object
   ("/players/dune/closed/guild/boards/officerboard.c"),
   this_object());
   }


 if(!arg){
 set_light(1);
 short_desc="Office of the Shogun";
 long_desc=
"     The Shoguns' Office is decorated with a military theme.\n"+
"Nasty blades and enhanced suits of armor rest in display cases\n"+
"along the sides of the room.  Two black burning pillars with\n"+
"torched tops stand near the door back to the hallway.  To the\n"+
"back of the room, a large area is set aside for combat training\n"+
"and weapons testing.\n";

items=({
 "blades", "Priceless decorated katanas and curved blades lie displayed",
 "suits","The suits of armor are both historic and hi-tech",
 "armor","The suits of armor are both historic and hi-tech",
 "cases","The display cases are made of clear crystal, quite a prize indeed",
 "pillars","The onyx pillars spew fire into the ventilated air above",
 "door","The wooden door leads back to the hallway",
 "area","A training area is set apart for those who enjoy action",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/lore1.c","west",
      });
  }   }

