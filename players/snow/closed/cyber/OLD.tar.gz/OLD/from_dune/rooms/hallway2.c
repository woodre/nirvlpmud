inherit "room/room";

init() {
 ::init();
}

reset(arg){


if(!present("ideaterminal")) {
   move_object(clone_object("/players/dune/closed/guild/boards/ideaboard.c"),
   this_object());
   }

if(!present("suggestion box")) {
  move_object(clone_object
    ("/players/dune/closed/guild/objects/emote_box.c"),
    this_object()); }

 if(!arg){
 set_light(1);
 short_desc="Streets of Netropolis";
 long_desc=
"     The electronic streets of Netropolis glow with\n"+
"the streaming lights of optical wires and heated lines\n"+
"of central processing units.  Yet you can see a strong\n"+
"influence of warrior pride.  Arches of gigantic blades\n"+
"and columns stand decorated with ancient suits of armor.\n";

items=({
 "streets", "The streets are made of dark-colored metal",
 "wires","Thick colorful wires lace along the roadside",
 "lines","CPU lines glow red with all the info passing through them",
 "arches","Several gigantic arches tower over the streets",
 "blades","The blades are symbols of ninja strength",
 "columns","Several columns hold up the dark ceiling above",
 "armor","These suits of armor serve as fitting decorations",
 "suits","These suits of armor serve as fitting decorations",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/shop.c","north",
 "/players/dune/closed/guild/rooms/guildhall.c","east",
 "/players/dune/closed/guild/rooms/lore1.c","south",
 "/players/dune/closed/guild/rooms/arenalounge.c","west",
      });
  }   }
