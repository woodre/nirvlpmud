#include "guildward.c"
inherit "room/room";

init() { ::init(); officeward("emperor", this_player()); }

reset(arg){

if(!present("officerboard")) {
   move_object(clone_object
   ("/players/dune/closed/guild/boards/officerboard.c"),
   this_object());
   }

 if(!arg){
 set_light(1);
 short_desc="Pagoda of the Emperors";
 long_desc=
"     A blue checkerboard of optical fibers intertwine in the black\n"+
"field of cyberspace.  In the center of the field stands a mini stone\n"+
"pagoda.  Lines of streaming energy pour into the pagoda from the ceiling\n"+
"above.  The energy flux creates spirals of electrical breakdown which\n"+
"add an odd haze to the air about you.  You feel the pure power that\n"+
"flows into the pagoda.  For this is the CPU of the CyberNet, the\n"+
"source of CyberNinja strength.  The Pagoda contains the master code\n"+
"and hardware for the entire CyberNinja Guild.\n";

items=({
 "checkerboard","The optical fibers cross to make a checkerboard pattern",
 "fibers","Each fiber is the cyberlink of every guild member",
 "pagoda","The pagoda is made of stone and stands 12' high",
 "lines","The energy lines seem to leave a psuedo-image behind them",
 "energy","You can taste the energy which flows",
 "ceiling","The ceiling changes color with every hearbeat",
 "hardware","The core hardware is forever running",
 "code","The master code checks itself for bugs and security breaches",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/palace.c","up",
      });
  }   }
