officeward(string str, object ob) {
  if(!present("implants", ob)) {
      warn(ob);
      move_object(ob, "/players/dune/closed/guild/rooms/lore2.c");
      return 1;
      }
  if(str == "sensei") {
   if( (present("implants", ob)->sensei())  ||
       (present("implants", ob)->regent())  ||
       (ob->query_real_name() == "dune")    ||
       (ob->query_real_name() == "snow")    ||
       (ob->query_name()      == "__dm__"))
       { return 1; }
    else { 
      warn(ob);
      move_object(ob, "/players/dune/closed/guild/rooms/lore1.c");
      return 1;
      }
    }
  if(str == "shogun") {
    if((present("implants", ob)->shogun()) ||
       (present("implants", ob)->regent())  ||
       (ob->query_real_name() == "dune")    ||
       (ob->query_real_name() == "snow")    ||
       (ob->query_name()      == "__dm__"))
       { return 1; }
    else {
      warn(ob);
      move_object(ob, "/players/dune/closed/guild/rooms/lore1.c");
      return 1;
      }
    }
  if(str == "daimyo") {
    if((ob->query_level() > 19) &&
       (present("implants", ob)) )
       { return 1; }
    if(ob->query_name() == "__dm__") return 1;
    else {
      warn(ob);
      move_object(ob, "/players/dune/closed/guild/rooms/lore2.c");
      return 1;
      }
    }
  if(str == "regent") {
    if((present("implants", ob)->regent()) ||
       (ob->query_real_name() == "dune")   ||
       (ob->query_real_name() == "snow")    ||
       (ob->query_name()      == "__dm__"))
       { return 1; }
    else {
      warn(ob);
      move_object(ob, "/players/dune/closed/guild/rooms/lore2.c");
      return 1;
      }
    }
  if(str == "emperor") {
    if( (ob->query_real_name() == "dune")    ||
       (ob->query_real_name() == "snow")    ||
       (ob->query_name()      == "__dm__"))
       { return 1; }
    else {
      warn(ob);
      move_object(ob, "/players/dune/closed/guild/rooms/lore2.c");
      return 1;
      }
    }
return 1;
}

warn(object ob) {
 tell_object(ob, "You do not have the proper access to enter here.\n");
 tell_object(ob, "Minor Security Breach.\n");
 return 1;
}
