#include "guildward.c"
inherit "room/room";

init() { ::init(); officeward("daimyo", this_player()); }

reset(arg){

if(!present("officerboard")) {
   move_object(clone_object
   ("/players/dune/closed/guild/boards/officerboard.c"),
   this_object());
   }


 if(!arg){
 set_light(1);
 short_desc="Office of Guild Wizzes";
 long_desc=
"     The CyberNinja Guild Wiz Office is rather elaborate and\n"+
"well decorated.  Soft white carpet rests upon black marble floor.\n"+
"A few neon lights hang upon the walls, and several sconces burn with\n"+
"ceremonial flame.  This room serves as a comfortable lounge for\n"+
"relaxing as well as catching up on guild events.\n";

items=({
 "floor","The black marble floor is hard, yet warm to the touch",
 "lights","The neon lights cast flourescent light upon the room",
 "sconces","Small flames burn from the scented candles",
 "carpet","The white carpet is made of long soft fur",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/lore2.c","east",
      });
  }   }
