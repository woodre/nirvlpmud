inherit "room/room";
#define TR tell_room
#define TP this_player()

init() { 
/* remove this when arena is fixed */

  if(this_player()) tell_object(this_player(), "\n\n\n\n\n\nThis arena is closed for the moment,\n\n"+
  "A bug exists in the player object which lets people unset their\n"+
  "pk flag, among other things. It will be fixed soon.\n"+
  "\n  --the management\n\n");
  if(this_player()) {
    this_player()->move_player("X#room/church");
    return 1;
  }

/* end addition by mizan */

  if(TP->query_ghost()) {
    if(!present("either object",TP)) {
      TP->quit();
    }
    command("followoff",TP);
    move_object(this_player(),"/room/church");
    command("look",TP);
  }
  add_action("revive","revive"); 
  TP->set_fight_area();
  ::init();
  }

reset(arg){

if(!present("__statue__")) {
   move_object(clone_object
   ("/players/dune/closed/guild/rooms/arenamon.c"),
   this_object());}

 if(!arg){
 set_light(1);
 short_desc="The CyberNinja Arena";
 long_desc=
"     You are in a large metallic dome.  At one end rests the giant\n"+
"statue of a kneeling ninja.  Its head reaches to the ceiling.\n"+
"A wide flat field stretches for hundreds of yards all around you.\n"+
"Overhead, a reader board hovers in mid-air.\n";

items=({
 "statue", "The black statue is a huge replica of an ancient ninja warrior",
 "field","The field is of a hard synthetic surface",
 "board","You read the digital display:\n"+
"If you die, type 'revive' to return to your bodily form.\n"+
"You will suffer no experience loss, though you will still\n"+
"lose a random attribute",
 "dome","Neon lights suspend from the metal dome ceiling",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/arenalounge.c","leave",
      });

 }
}

revive() {
  int amount;
  int currentxp;
  if(this_player()->query_ghost()) {
    currentxp = this_player()->query_exp();
    amount = currentxp * 4;
    amount = currentxp / 3;
    this_player()->remove_ghost();
    this_player()->add_exp(amount);
    this_player()->set_pl_k();
    this_player()->save_me();
    write("Your systems draw from backup power supplies.\n");
    write("Your body quivers with life again.\n");
    return 1; }
  write("You are not in a state to be revived.\n");
  return 1; 
}

realm() { return "NT"; }

int is_cyberninja_arena() { return 1; }
