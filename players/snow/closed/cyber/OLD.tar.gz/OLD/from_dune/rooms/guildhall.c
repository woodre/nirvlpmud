#define TP this_player()
inherit "room/room";

init() {
  ::init();
  call_out("move_me", 0, TP);
}

move_me(object ob) {
  if(!present("either implants", ob)) {
  tell_object(ob, "------------>\n");
  tell_object(ob,"You have infiltrated Netropolis without authorization.\n");
  tell_object(ob, "------------>\n");
  if(ob->is_player() && ob->query_level() < 20) move_object(ob,"/room/church");
  }
}


reset(arg){

if(!present("terminal")) {
   move_object(clone_object("/players/dune/closed/guild/boards/guildboard.c"),
   this_object());
   }

/* For Guild Elections only
if(!present("ballot box")) {
   move_object(clone_object
   ("/players/dune/closed/guild/objects/ballot_box.c"),
   this_object());
   }
*/

 if(!arg){
 set_light(1);
 short_desc="CyberNinja Main Guild Hall";
 long_desc=
"     The Grand Hall of the CyberNinja lies before you.\n"+
"Columns of raging fire stand along the sides of the black\n"+
"marble floor.  Gigantic red statues of past ninja warriors\n"+
"cast their flickering shadows upon the high white walls.\n"+
"The Hall is circular in shape, with the ceiling tapering to\n"+
"a glass dome overhead.\n";

items=({
 "fire", "The blazing fire shoots from the top of the columns",
 "columns","Several large marble columns encircle the center of the room",
 "floor","The black marble floor shines with a polished surface",
 "statues","The statues stand over 20 feet high, near each column",
 "ceiling","The ceiling opens up into a glass viewing window",
 "dome","The glass dome gives you a clear view of the sky outside",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/hallway1.c","north",
 "/players/dune/closed/guild/rooms/entrance.c","east",
/* "/players/dune/closed/guild/rooms/bar.c","south", */
 "/players/dune/closed/guild/rooms/hallway2.c","west",
 "/players/dune/closed/guild/rooms/meeting.c","down",
 "/players/dune/closed/guild/rooms/teleport.c","up",
      });
  }   }
