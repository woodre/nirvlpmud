#define RN this_player()->query_real_name()

inherit "room/room";

int open;

init() {
 if(RN == "dune" || RN == "snow") {
 add_action("open","open");
 add_action("close","close");
 }
 ::init();
 if(RN == "dune" || RN == "snow") return 1;
 if(!open) {
   move_object(this_player(), "/players/dune/closed/guild/rooms/lore2.c");
   write("The doors are locked by a godly force.\n");
   return 1; }
}

reset(arg){
 open = 0;
 if(!arg){
 set_light(1);
 short_desc="Grand Palace of Emperors";
 long_desc=
"     You are in the Grand Palace of Emperors!!\n"+
" ('''')    ('''')    ('''')    ('''')    ('''')    ('''')    ('''')\n"+
" |{}{}|    |{}{}|    |{}{}|    |{}{}|    |{}{}|    |{}{}|    |{}{}|\n"+
" |    |    |    |    |    |    |    |    |    |    |    |    |    |\n"+
" |    |    | N  |    | I  |    | N  |    | J  |    | A  |    |    |\n"+
" |    |    |    |    |    |    |    |    |    |    |    |    |    |\n"+
" |    |    |    |    |    |    |    |    |    |    |    |    |    |\n"+
" |{}{}|    |{}{}|    |{}{}|    |{}{}|    |{}{}|    |{}{}|    |{}{}|\n"+
" (....)    (....)    (....)    (....)    (....)    (....)    (....)\n"+
"Only the very priviliged are allowed to enter the Grand Palace.\n"+
"Laced columns of spiraling gold and ruby dance about the walls\n"+
"and ceiling overhead.  Huge arches of bone thrust powerfully\n"+
"through the heart of the golden palace.  Super-ancient artifacts\n"+
"decorate the walls.  A feeling of ancient pride and tradition\n"+
"overwhelm you.  For you are in the heart of the CyberNinja.\n";

items=({
 "columns","The columns are made of ruby and gold",
 "gold","Shining gold and riches beyond belief surround you",
 "ruby","Huge gems and other workings of ruby dazzle the eyes",
 "bone","Ancient dragonbone gracefully pierce the golden floor",
 "arches","Arches of dragonbone gracefully pierce the golden floor",
 "artifacts","Artifacts of long lost eras remain untouched here",
 "walls","The walls are adorned with priceless treasures",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/lore2.c","north",
 "/players/dune/closed/guild/rooms/emperor.c","down",
      });
  }   }

open() {
  write("The massive double doors swing open.\n");
  tell_room("/players/dune/closed/guild/rooms/lore2.c",
    "The massive double doors to the Emperor's Palace swing open.\n");
  open = 1;
  return 1; 
}

close() {
  write("The massive double doors swing shut.\n");
  tell_room("/players/dune/closed/guild/rooms/lore2.c",
    "The massive double doors to the Emperor's Palace swing shut.\n");
  open = 0;
  return 1; 
}
