#define TP this_player()
#define TE tell_object
inherit "room/room";

init() {
 add_action("buy","buy");
 add_action("list","list");
 ::init();
}

reset(arg){

if(!present("bartender")) {
   move_object(clone_object("/players/dune/closed/guild/rooms/BartendeR.c"),
   this_object());}

 if(!arg){
 set_light(1);
 short_desc="The CyberPunk";
 long_desc=
"     New age rock blasts in your ears the moment you step into the\n"+
"CyberPunk bar.  The large room is filled with neon lights and\n"+
"futuristic decor.  You can 'buy item' and 'list'.\n";

items=({
 "lights","The flashing neon floods the room with unnatural light",
 "decor","The decoration here is purely CyberPunk",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/guildhall.c","north",
      });
  }   }

object IP(object ob) {
/* This function is similar to a #define, it just
 * returns the guild object on the player specified.
 */
   object guild_object;
   guild_object = present("implants", ob);
   return guild_object;
}

buy(string str) {
  int cost;
  int name;
  if(!present("bartender")) {
    TE(TP, "There is no bartender here to run the bar.\n");
    return 1;}
  if(!str) {
    write("Bartender says: What do you wish to buy?\n");
  return 1;
  }
  str = lower_case(str);
  if(!findDrink(str)) {
    write("Bartender says: I don't make that here.\n");
    return 1; }
  name = findGoodDrinkName(str);
  cost = findCostOfDrink(name);
  if(IP(TP)->balance() < cost) {
    TE(TP, "Bartender says: You don't have enough credits to buy a "+str+"\n");
    return 1;}
  IP(TP)->addToBalance(-cost);
    IP(TP)->save_me();
  giveCustomerDrink(name);
  TE(TP, "Bartender says: Thanks for your service.\n");
  return 1;
}

int findDrink(string str) {
  switch(str) {
    case "umorph":   return 1;
    case "UM":       return 1;
    case "um":       return 1;
    case "morph":    return 1;
    case "usober":   return 1;
    case "US":       return 1;
    case "us":       return 1;
    case "sober":    return 1;
  }
  return 1;
}

string findGoodDrinkName(string str) {
  switch(str) {
    case "umorph":   return "umorph";
    case "UM":       return "umorph";
    case "um":       return "umorph";
    case "morph":    return "umorph";
    case "usober":   return "usober";
    case "US":       return "usober";
    case "us":       return "usober";
    case "sober":    return "usober";
  }
  return "error (this shouldn't happen)";
}

int findCostOfDrink(string str) {
  switch(str) {
    case "umorph":    return 15000;
    case "usober":   return 5000;
    }  return 1;
}

giveCustomerDrink(string str) {
  object drink;
  switch(str) {
case "umorph":   drink = clone_object("/players/snow/heals/umorph.c"); break;
case "usober":   drink = clone_object("/players/snow/heals/usober.c"); break;
    }
  move_object(drink, this_player());  return 1;
}

list() {
  write(
"   You take a look at the menu:\n\n"+
"ITEM                              COST\n"+
"*********************************************\n"+
"An injector tab (UM)              15000\n"+
"An injector tab (US)              5000\n"+
"*********************************************\n");
    return 1;
}
