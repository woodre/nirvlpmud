#include </players/dune/closed/guild/rooms/guildward.c>
inherit "room/room";

init() { ::init(); officeward("regent", this_player()); }

reset(arg){

if(!present("officerboard")) {
   move_object(clone_object
   ("/players/dune/closed/guild/boards/officerboard.c"),
   this_object());
   }


 if(!arg){
 set_light(1);
 short_desc="Office of the Grand Regent";
 long_desc=
"     The Regent's Office is richly decorated with fine furnishings\n"+
"brought from the rarest sources.  Gold and platinum lace the white\n"+
"marble walls in intricate looping patterns.  A fountain sputters\n"+
"crystal clear water near the room entrance.  Further into the\n"+
"broad room, up a flight of stairs, an impressive system of network\n"+
"computers and moniters record every event that transpires in the guild\n";

items=({
 "walls","The walls are made of pure white marble",
 "patterns","The patterns are purely decorative",
 "gold","Gold leaf patterns interlace with the platinum",
 "platinum","Platinum vines weave with gold leaf",
 "fountain","The fountain has the statue of a ninja on top",
 "water","The faint blue water shines with intense radiance",
 "stairs","Marble stairs ascend to a computer lab",
 "computers","Large host computers link clients via neural nets",
 "moniters","Huge raised screens span across the room walls",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/lore2.c","west",
      });
  }   }
