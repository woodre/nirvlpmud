#include "guildward.c"
inherit "room/room";

init() { ::init(); officeward("sensei", this_player()); }

reset(arg){

if(!present("officerboard")) {
   move_object(clone_object
   ("/players/dune/closed/guild/boards/officerboard.c"),
   this_object());
   }


 if(!arg){
 set_light(1);
 short_desc="Office of the Sensei";
 long_desc=
"     The Senseis' Office contains all sorts of guild papers and notes.\n"+
"Manuals and electronic datapads rest upon several tables.  Miscellaneous\n"+
"computer printouts are scattered upon desks.  A few referendums dealing\n"+
"with various guild issues are piled neatly upon shelves.\n"+
"In a seperate section of the office, new hi-tech training equipment\n"+
"stand newly assembled and ready to be tested.\n";

items=({
 "datapads", "The hand-held datapads might be handy for jotting things down",
 "manuals","Thick manuals of aging paper contain ancient ninja history",
 "printouts","Several printouts dangle loosely from ever-active printers",
 "papers","Guild papars contain miscellaneous info, none too interesting",
 "notes","Notes of training techniques and supply lists are scattered about",
 "desks","Long desks and chairs serve as comfortable work stations",
 "referendums","These nicely packaged referendums await enactment",
 "shelves","The shelves hold office supplies and guild referendums",
 "equipment","These massive machines serve as instructional tools",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/lore1.c","east",
      });
  }   }
