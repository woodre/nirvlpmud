inherit "obj/monster";

   int a;
   string Name, name;

reset(arg){
   object gold;
   ::reset(arg);
   if(arg) return;
   a = random(9) + 1;
   if (a == 1) name = "neon";
   if (a == 2) name = "hypercard";
   if (a == 3) name = "heavy D";
   if (a == 4) name = "zod";
   if (a == 5) name = "doom";
   if (a == 6) name = "zephyr";
   if (a == 7) name = "sasha";
   if (a == 8) name = "shard";
   if (a == 9) name = "jabba";
   set_name(name);
   set_race("human");
   set_alias(name);
   Name = capitalize(name);
   set_short(Name+", the bartender");
   set_long(Name+" has served the toughest joints and knows\n"+
         "every drink in the datalog.  Only the pure joy of\n"+
         "serving you the nastiest concoctions on this side\n"+
         "of cyberspace keeps this bartender going.\n");
   set_level(8);
   set_hp(random(20)+110);
   set_al(0);
   set_wc(13);
   set_ac(8);
   gold=clone_object("obj/money");
   gold->set_money(random(150)+150);
   move_object(gold,this_object());
}

 id(str)  {
  return str == "bartender" || str == "tender" ||
         str == name || str == Name;
 }

