inherit "room/room";

init() {
 add_action("holodeckA","holodeckA");
 add_action("holodeckB","holodeckB");
 add_action("holodeckC","holodeckC");
 ::init();
}

reset(arg){
 if(!arg){
 set_light(1);
 short_desc="Streets of Netropolis";
 long_desc=
"     The electronic streets of Netropolis glow with\n"+
"the streaming lights of optical wires and heated lines\n"+
"of central processing units.  Yet you can see a strong\n"+
"influence of warrior pride.  Arches of gigantic blades\n"+
"and columns stand decorated with ancient suits of armor.\n"+
"Three large hexagonal domes surround the outer edges of\n"+
"of the wide street square.  They are entrances to:\n"+
"'holodeckA', 'holodeckB', and 'holodeckC'\n";

items=({
 "streets", "The streets are made of dark-colored metal",
 "wires","Thick colorful wires lace along the roadside",
 "lines","CPU lines glow red with all the info passing through them",
 "arches","Several gigantic arches tower over the streets",
 "blades","The blades are symbols of ninja strength",
 "columns","Several columns hold up the dark ceiling above",
 "armor","These suits of armor serve as fitting decorations",
 "suits","These suits of armor serve as fitting decorations",
 });

  dest_dir=({
 "/players/dune/closed/guild/rooms/meditation.c","east",
 "/players/dune/closed/guild/rooms/chopshop.c","west",
 "/players/dune/closed/guild/rooms/guildhall.c","south",
      });
  }   }

holodeckA() {
  say(capitalize(this_player()->query_name())+
      " decides to enter Holodeck A.\n");
  write("You decide to enter Holodeck A.\n");
  write("Type 'cyber holodeck' for information.\n");
  move_object(this_player(),
      "/players/dune/closed/guild/rooms/holodeckA.c");
  return 1; }

holodeckB() {
  say(capitalize(this_player()->query_name())+
      " decides to enter Holodeck B.\n");
  write("You decide to enter Holodeck B.\n");
  write("Type 'cyber holodeck' for information.\n");
  move_object(this_player(),
      "/players/dune/closed/guild/rooms/holodeckB.c");
  return 1; }


holodeckC() {
  say(capitalize(this_player()->query_name())+
      " decides to enter Holodeck C.\n");
  write("You decide to enter Holodeck C.\n");
  write("Type 'cyber holodeck' for information.\n");
  move_object(this_player(),
      "/players/dune/closed/guild/rooms/holodeckC.c");
  return 1; }
