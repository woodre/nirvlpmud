inherit "room/room";

init() {
 add_action("meetings"); add_xverb("");
 ::init();
}

reset(arg){

if(!present("meetingboard")) {
   move_object(clone_object
   ("/players/dune/closed/guild/boards/meetingboard.c"),
   this_object());}

 if(!arg){
 set_light(1);
 short_desc="The CyberNinja Meeting Room";
 long_desc=
"     You are in the CyberNinja Meeting Room.\n"+
"Several comfortable chairs surround a large round table.\n"+
"Cameras rest upon wall mounts in the corners of the room.\n";

  dest_dir=({
 "/players/dune/closed/guild/rooms/guildhall.c","up",
      });

  items=({
  "cameras","Surveillance cameras record every important decision",
      });
  }   }

meetings(string str) {
  write_file("/players/dune/closed/guild/log/MEETING",
             this_player()->query_real_name()+": "+str+"\n");
}

