id(str) { return str == "deathmatch_object"; }
get() { return 0; }
drop() { return 1; }
query_weight() { return 0; }
query_value() { return 0; }

long() { write(
"     This is a tool for the operation of CyberNinja death matches.\n"); }
