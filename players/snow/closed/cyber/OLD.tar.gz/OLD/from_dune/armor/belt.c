inherit "obj/armor";

id(str) { return str == "belt" || str == "CyberNinja belt" ||
                 str == "discipline belt"; }

reset(arg){
   ::reset(arg);
   set_name("discipline belt");
   set_short("A CyberNinja belt");
   set_alias("belt");
   set_long("This is a CyberNinja discipline belt.\n"+
            "It represents proficiency in a CyberNinja's\n"+
            "martial discipline and also provides added\n"+
            "protection in combat.\n");
   set_type("misc");
   set_ac(1);
   set_weight(1);
   set_value(500);
}
