inherit "obj/armor";

id(str) { return str == "boots" || str == "CyberNinja boots" ||
                 str == "tabi boots"; }

reset(arg){
   ::reset(arg);
   set_name("tabi boots");
   set_short("A pair of CyberNinja tabi boots");
   set_alias("boots");
   set_long("This is a pair of CyberNinja tabi boots.\n"+
            "They are made mostly of cloth, with only a pad\n"+
            "of rubber-like substance on the soles and\n"+
            "sides.  Being not entirely closed-toed, the\n"+
            "tabi boots allow for a wide range of movements.\n"+
            "The boots are made of an unknown material.\n");
   set_type("boots");
   set_ac(1);
   set_weight(1);
   set_value(500);
}
