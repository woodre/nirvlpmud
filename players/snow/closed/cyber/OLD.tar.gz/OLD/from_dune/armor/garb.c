#define TP this_player()

inherit "obj/armor";

string armor_color;


init() { add_action("fold","fold"); ::init(); }

reset(arg){
   ::reset(arg);
   set_name("ninja garb");
   set_short("A CyberNinja garb");
   set_alias("garb");
   set_long("The CyberNinja garb is a tight-fitting comfortable\n"+
            "armor that covers almost the entire body.  It is\n"+
            "divided into two pieces: a jacket-like upper half\n"+
            "and a lower half that extends down to the feet.\n"+
            "Though the garb may seem like cloth, it is actually\n"+
            "a type of space-age metal.\n");
   set_type("armor");
   set_ac(2);
   set_weight(2);
   set_value(500);
}

set_color(string new) { armor_color = new; }

fold() {
  object package, cowl, belt, boots;
  if(!present("cowl", TP)) {
    write("You cannot fold your garbs with an incomplete set.\n");
    return 1; }
  if(!present("CyberNinja belt", TP)) {
    write("You cannot fold your garbs with an incomplete set.\n");
    return 1; }
  if(!present("CyberNinja boots", TP)) {
    write("You cannot fold your garbs with an incomplete set.\n");
    return 1; }
  package = clone_object("players/dune/closed/guild/armor/fold.c");
  package->set_color(armor_color);
  cowl = present("cowl", TP);
  belt = present("CyberNinja belt", TP);
  boots = present("CyberNinja boots", TP);
  write("You fold your garbs and wrap them up for later.\n");
  destruct(cowl);  destruct(belt);  destruct(boots);
  move_object(package, TP);
  destruct(this_object());
  return 1;
}
