inherit "obj/armor";

reset(arg){
   ::reset(arg);
   set_name("ninja cowl");
   set_short("A CyberNinja cowl");
   set_alias("cowl");
   set_long("The CyberNinja cowl is a hi-tech piece of\n"+
            "armor that fits around the head, like a mask.\n"+
            "It feels like cloth, yet it has the strength\n"+
            "of metal.\n");
   set_type("helmet");
   set_ac(1);
   set_weight(1);
   set_value(500);
}
