#define TP this_player()

string color;

id(str) { return str == "garbs" || str == "garb" ||
                 str == "folds" || str == "folding" ||
                 str == "foldings" || str == "fold"; }

short () { return "Folded CyberNinja garbs"; }

long() {
  write("This is the complete set of nicely folded\n"+
        "CyberNinja garbs.  Contained within this package\n"+
        "is a ninja cowl, ninja garb, belt, and tabi boots.\n"+
        "Type 'instructions' for info on use.\n");
}

get() { return 1; }
query_weight() { return 5; }
query_value() { return 100; }

init() {
  add_action("unfold","unfold");
  add_action("instructions","instructions");
  add_action("wash","wash");
}

set_color(string new) { color = new; }

instructions() {
  write("Use of CyberNinja garbs.\n");
  write("*********************************************\n");
  write("unfold.............unfolds the garbs for use.\n");
  write("wash...............restores lost color\n");
  write("*********************************************\n");
  return 1;
  }

unfold() {
  string arm, bclr, art;
  object cowl, garb, belt, boots;
  int artlev;
  if(!present("implants", TP)) {
    write("You don't know how to unfold the garbs!\n");
    return 1; }
  art = present("implants", TP)->query_art();
  artlev = present("implants", TP)->query_art_level();
  bclr = call_other("players/dune/closed/guild/ninjadaem.c",
                    "belt_color", artlev, art);
  arm = "players/dune/closed/guild/armor";
  if(!color) color = "";
  else color += " ";

  cowl =  clone_object(arm+"/cowl.c");
  garb =  clone_object(arm+"/garb.c");
  belt =  clone_object(arm+"/belt.c");
  boots = clone_object(arm+"/boots.c");

  if(artlev >= 2) { boots->set_ac(2);
	boots->set_value(1000); }
  if(artlev >= 4) { cowl->set_ac(2);
	cowl->set_value(1000); }
  if(artlev >= 6) { belt->set_ac(2);
	belt->set_value(1000); }
  if(artlev >= 8) { garb->set_ac(3);
	garb->set_value(1500); }
  if(bclr == "orange") belt->set_short("An "+bclr+" belt in "+art);
  else belt->set_short("A "+bclr+" belt in "+art);
  garb->set_color(color);
  boots->set_short("A pair of "+color+"tabi boots");

  if( (color[0] == 97) || (color[0] == 101) || (color[0] == 105) ||
      (color[0] == 111) || (color[0] == 117) ) {
      cowl->set_short("An "+color+"CyberNinja cowl");
      garb->set_short("An "+color+"CyberNinja garb");
      }
  else {
      cowl->set_short("A "+color+"CyberNinja cowl");
      garb->set_short("A "+color+"CyberNinja garb");
      }

  move_object(cowl, TP);
  move_object(garb, TP);
  move_object(boots, TP);
  move_object(belt, TP);

  write("You carefully unfold your ninja garbs.\n");
  destruct(this_object());
  return 1;
}

wash() {
   string clr;
   if(!present("implants", TP)) {
     write("You do not know how to wash ninja garbs.\n");
     return 1; }
   clr = present("implants", TP)->query_garbcolor();
   write("You wash your ninja garbs good and hard.\n");
   write("The "+clr+" color seems to be coming back.\n");
   set_color(clr);
   return 1;
}
query_save_flag() { return 1; }
