get() { return 1; }
query_weight() { return 0; }
query_value() { return 0; }
id(str) { return str == "datapad" || str == "pad"; }
short() { return "A CyberNinja Datapad"; }
long() { sign_disp(); }
init() { add_action("read","read"); }

read(str) {
  if(!str) return 0;
  if(str == "datapad" || str == "pad") { 
    sign_disp();
    return 1; }
  return 0; }

sign_disp() {
  write(
"      C Y B E R N I N J A\n"+ 
"\n"+
"Highlights of the CyberNinja guild__________ _____ ___ __ _\n"+
"\n"+
"->Fighter-style combat... guild weapons, attack 'spells'\n"+
"->Choices... choice of weapon, choice of armor,\n"+
"             choice of martial discipline\n"+
"->Role-playing... guild positions, player run guild operations\n"+
"->Enhancements... cost of coins, no experience cost for these\n"+
"                  guild abilities\n"+
"->Sensei-guild member... training method of advancing in levels\n"+
"->Guild tournaments... player organized and run\n"+
"->Pk... allowed\n"+
"->Guild credits... store more coins to use on guild enhancements\n"+
"->Pets, speedsters, and other usual features for convenience\n"+
"->Entirely new... not like any other guild\n");
}
