/* Do not remove - mizan */

#define S10flag "/players/dune/closed/guild/ninjadaem"
#define S10DAM_CAP 50

/* end change */

#include "color.h"
#include "definitions.h"

id(str) { return str == "daemon"; }
short () {return "CyberNinja daemon";}
long() {write("This is the CyberNinja guild daemon.\n");}

info_database(string str) {
/* takes str and refers to files in docs directory */
  string file, topic, all;
  if(!str) {
    cat("/players/dune/closed/guild/docs/main_menu");
    return; }
  if(sscanf(str, "%s %s", topic, all)) {
    file = "/players/dune/closed/guild/docs/" + topic;
    file = shorted_file(file);
    if(all == "all") {
      if (file_size(file) >= 0) {
        cat(file);
        return; }
      else {
        write("There is no help on that cyber topic.\n");
        return; }
      }
    if(all != "all") {
      write("Usage: cyber [topic]   or   cyber [topic] all.\n");
      return; }
    }
  if(sscanf(str, "%s", topic)) {
      file = "/players/dune/closed/guild/docs/" + topic;
      file = shorted_file(file);
      if (file_size(file) >= 0) {
         if(find_menu(file)) {
           cat(file);
           return; }
         call_other("/players/dune/closed/guild/_more.c",
                   "more_file", file);
         return; }
      write("There is no help on that cyber topic.\n");
      return; }
  write("Usage: cyber [topic]   or   cyber [topic] all.\n");
}

officer_database(string str) {
/* takes str and refers to files in fax directory */
  string file, topic, all;
  if(!str) {
    cat("/players/dune/closed/guild/fax/fax_menu");
    return; }
  if(sscanf(str, "%s %s", topic, all)) {
    file = "/players/dune/closed/guild/fax/" + topic;
    file = shorted_file(file);
    if(all == "all") {
      if (file_size(file) >= 0) {
        cat(file);
        return; }
      else {
        write("There is no help on that fax topic.\n");
        return; }
      }
    if(all != "all") {
      write("Usage: fax [topic]   or   fax [topic] all.\n");
      return; }
    }
  if(sscanf(str, "%s", topic)) {
      file = "/players/dune/closed/guild/fax/" + topic;
      file = shorted_file(file);
      if (file_size(file) >= 0) {
         if(find_menu(file)) {
           cat(file);
           return; }
         call_other("/players/dune/closed/guild/_more.c",
                   "more_file", file);
         return; }
      write("There is no help on that fax topic.\n");
      return; }
  write("Usage: fax [topic]   or   fax [topic] all.\n");
}

int find_menu(string str) {
  string menustr;
  if(sscanf(str, "%smenu", menustr) == 1) return 1;
  if(sscanf(str, "%sshort", menustr) == 1) return 1;
  return 0;
}

string shorted_file(string str) {
  string files;
  files = str + "short";
  if(file_size(files) >= 0) str = files;
  return str;
}


object IP(object ob) {
/* This function is similar to a #define, it just
 * returns the guild object on the player specified.
 */
   object guild_object;
   guild_object = present("implants", ob);
   return guild_object;
}

update_implants() {
/* Simply updates the guild object */
   object implants, this_ob;
   implants=clone_object("/players/dune/closed/guild/implants.c");
   move_object(implants, this_player());
   this_ob = present("implants", this_player());
   destruct(this_ob);
   present("implants", this_player())->init(1);
   return 1;
}


enhance(string str) {
/* Used for guild level promotions/demotions */
  int new_lev, current_lev, low_new_xp;
  string who;
  object targ;
  if(!str) {
    write("Usage: enhance <member> <newlevel>.\n");
    return;}
  if(!sscanf(str, "%s %d", who, new_lev)) {
    write("Usage: enhance <member> <newlevel>.\n");
    return;}
  if(!IP(find_player(who))) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  targ = find_player(who);
  current_lev = IP(targ)->guild_lev();
  if (new_lev == current_lev) {
    write(capitalize(who)+" is already of quality "+new_lev+"\n");
    return;}
  if (new_lev < 0) {
    write("You cannot drop a member below quality 0.\n");
    return;}
  if((new_lev > 10) && (targ->query_level() > 19)) {
    write("Be sure to read the help files on levels.\n");
    write_file(log+"ENHANCE", RN+" enhanced "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    TE(targ, "You have been changed to quality "+new_lev+".\n");
    TE(targ, "You should read the help files on wiz members.\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    IP(targ)->save_me();
    targ->save_me();
    return;}
  if (new_lev > 10) {
    write("Be sure to read the help files on levels.\n");
    write_file(log+"ENHANCE", RN+" enhanced "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    TE(targ, "You have been promoted to level "+new_lev+".\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    IP(targ)->save_me();
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    targ->save_me();
    IP(targ)->update_implants();
    return;
    }
  if (new_lev > current_lev) {
    TE(targ, "You have been enhanced to quality "+new_lev+".\n");
    write_file(log+"ENHANCE", RN+" promoted "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    IP(targ)->save_me();
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    targ->save_me();
    IP(targ)->update_implants();
    return;}
  if(new_lev < current_lev) {
    TE(targ, "You have been demoted to a quality of "+new_lev+"\n");
    write_file(log+"ENHANCE", RN+" demoted "+targ->query_real_name()+
                              " from quality "+current_lev+" to "+
                              new_lev+". ("+ctime()+")\n");
    IP(targ)->set_rank(new_lev);
    targ->add_guild_rank(new_lev - current_lev);
    low_new_xp = low_exp(new_lev);
    IP(targ)->set_xp(low_new_xp);
    IP(targ)->save_me();
    targ->add_guild_exp(-targ->query_guild_exp());
    targ->add_guild_exp(low_new_xp);
    targ->save_me();
    update_implants();
    return;}
}

addxp(string str) {
/* Used for guild xp promotion/demotion/setting */
  int amount;
  string who;
  object whoob;
  if(!str) {
    write("Usage: addxp <member> <amount>.\n");
    return;}
  if(!sscanf(str, "%s %d", who, amount)) {
    write("Usage: addxp <member> <amount>.\n");
    return;}
  if(!IP(find_player(who))) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  whoob = find_player(who);
  IP(whoob)->add_xp(amount);
  whoob->add_guild_exp(amount);
  whoob->save_me();
  IP(whoob)->save_me();
  if(amount >= 0)
    write("You alter "+capitalize(who)+"'s guild xp by +"
      +amount+".\n");
  else write("You alter "+capitalize(who)+"'s guild xp by "
      +amount+".\n");
  write_file(log+"ADDXP", RN+" altered "+whoob->query_real_name()+
                          "'s guild xp by "+amount+". ("+ctime()+")\n");
}


int low_exp(int level) {
/* Returns the base xp for the level specified */
  int xp;
  switch(level) {
    case 0:     xp = 0;         break;
    case 1:     xp = 5000;       break;
    case 2:     xp = 20000;      break;
    case 3:     xp = 50000;     break;
    case 4:     xp = 120000;    break;
    case 5:     xp = 230000;    break;
    case 6:     xp = 430000;    break;
    case 7:     xp = 700000;    break;
    case 8:     xp = 1000000;    break;
    case 9:     xp = 1500000;    break;
    case 10:    xp = 2000000;    break;
    }
  if(level > 10) xp = 2000000;
  return xp;
}

int xp_list(int xp) {
/* Returns guild level for xp specified */
  if(xp <  5000)    { return 0;  }
  if(xp <  20000)   { return 1;  }
  if(xp <  50000)   { return 2;  }
  if(xp <  120000)  { return 3;  }
  if(xp <  230000)  { return 4;  }
  if(xp <  430000)  { return 5;  }
  if(xp <  700000)  { return 6;  }
  if(xp <  1000000) { return 7;  }
  if(xp <  1500000) { return 8;  }
  if(xp <  2000000) { return 9;  }
  if(xp >= 2000000) { return 10; }
  return 0;
}

string guild_title(int level) {
/* Returns guild title for guild level specified */
  string title;
  switch(level) {
    case 100:title = "the __Emperor__";           break;
    case 50: title = "the Grand Regent";          break;
    case 13: title = "the Daimyo";                break;
    case 12: title = "the Shogun";                break;
    case 11: title = "the CyberNinja WarLord";    break;
    case 10: title = "the CyberNinja WarLord";    break;
    case 9:  title = "the Elder CyberNinja";      break;
    case 8:  title = "the Master CyberNinja";     break;
    case 7:  title = "the Adept CyberNinja";      break;
    case 6:  title = "the CyberNinja";            break;
    case 5:  title = "the CyberKnight";           break;
    case 4:  title = "the CyberWarrior";          break;
    case 3:  title = "the CyberBlade";            break;
    case 2:  title = "the CyberPunk";             break;
    case 1:  title = "the CyberPuke";             break;
    case 0:  title = "the NetRunner";             break;
    }
  if ((level > 13) && (level != 50) && (level != 100))
    title = "the Defective";
  return title;
}

set_guild_title() {
/* Changes the member's guild title */
  string new_title;
  if(IP(TP)) {
    new_title = guild_title(IP(TP)->guild_lev());
    if(new_title == "defective") {
       write("There is no title for your quality level.\n");
       write("Please have your quality level changed.\n");
       return; }
    TP->set_title(new_title);
    write("Your title is now "+new_title+".\n");
    TP->save_character();
    return;}
}

help_levels() {
/* Shows xp and title for each guild level */
  int i;
  write("List of levels and experience for CyberNinja guild\n");
  write("________________________ ____________ ______ ____ ___ __\n");
  write(" LEVEL       XP          TITLE                     COST\n");
  write("________________________ ____________ ______ ____ ___ __\n");
  for(i = 0; i <= 10; i++) {
    write(pad("Level "+i, 12));
    write(pad(low_exp(i), 10));
    write("  ");
    write(pad(guild_title(i), 27));
    write(pad(call_other(
              "/players/dune/closed/guild/rooms/meditation.c", 
              "cost_to_advance", i), 10));
    write("\n");
    }
  write("________________________ ____________ ______ ____ ___ __\n");
}

rank_info() {
/* Simple sc command for a member, showing guild info */
  int level, degree;
  string art;
  degree = IP(TP)->query_degree();
  level = IP(TP)->query_art_level();
  art = IP(TP)->query_art();
  write(TPN+"'s CyberNinja guild info......\n");
  write("(O )( O)(O )( O)(O )( O)(O )( O)(O )( O)(O )( O)\n");
  if(RN == EMP1 || RN == EMP2) write("You are the EMPEROR.\n");
  if(IP(TP)->regent()) write("You hold the title of Grand Regent.\n");
  if(IP(TP)->shogun()) write("You hold the title of Shogun.\n");
  if(IP(TP)->judge())  write("You hold the title of Judge.\n");
  if(IP(TP)->sensei()) write("You hold the title of Sensei.\n");
  if(IP(TP)->head_referee()) write("You hold the title of Head Referee.\n");
  if(IP(TP)->senator()) write("You hold the title of Senator.\n");
  if(IP(TP)->referee()) write("You hold the title of Referee.\n");
  if(IP(TP)->loremaster()) write("You hold the title of Loremaster.\n");
  if(IP(TP)->watcher()) write("You hold the title of Watcher.\n");
  write("Quality Level: "+IP(TP)->guild_lev()+"\n");
  write("Guild Xp: "+IP(TP)->guild_exp()+"\n");
  write("Ninjitsu Discipline: "+art+"\n");
  write("Belt: "+belt_color(level, art)+"");
  if(degree > 0) write(", degree "+degree+"\n");
  else write("\n");
  write("Choice of Weapon: "+IP(TP)->query_weapon()+"\n");
  write("Credit Balance: "+IP(TP)->balance()+"\n");
  write("( O)(O )( O)(O )( O)(O )( O)(O )( O)(O )( O)(O )\n");
}
 
other_rank_info(string str) {
/* To find another person's guild info */
  int level, degree;
  string art;
  object ob;
  if(!find_player(str)) {
    write(capitalize(str)+" is not on now or does not exist.\n");
    return; }
  ob = find_player(str);
  if(!IP(ob)) {
    write(capitalize(str)+" is not a guild member.\n");
    return; }
  degree = IP(ob)->query_degree();
  level = IP(ob)->query_art_level();
  art = IP(ob)->query_art();
  TE(TP,OPN+"'s CyberNinja guild info......\n");
  TE(TP,"(* )( *)(* )( *)(* )( *)(* )( *)(* )( *)(* )( *)\n");
  if(ORN == EMP1 || RN == EMP2) TE(TP,"You are the EMPEROR.\n");
  if(IP(ob)->regent()) TE(TP,"You hold the title of Grand Regent.\n");
  if(IP(ob)->shogun()) TE(TP,"You hold the title of Shogun.\n");
  if(IP(TP)->judge())  write("You hold the title of Judge.\n");
  if(IP(ob)->sensei()) TE(TP,"You hold the title of Sensei.\n");
  if(IP(ob)->head_referee()) TE(TP,"You hold the title of Head Referee.\n");
  if(IP(ob)->senator()) TE(TP,"You hold the title of Senator.\n");
  if(IP(ob)->referee()) TE(TP,"You hold the title of Referee.\n");
  if(IP(ob)->loremaster()) TE(TP,"You hold the title of Loremaster.\n");
  if(IP(ob)->watcher()) TE(TP,"You hold the title of Watcher.\n");
  TE(TP,"Quality Level: "+IP(ob)->guild_lev()+"\n");
  TE(TP,"Guild Xp: "+IP(ob)->guild_exp()+"\n");
  TE(TP,"Ninjitsu Discipline: "+art+"\n");
  TE(TP,"Belt: "+belt_color(level, art)+"");
  if(degree > 0) TE(TP,", degree "+degree+"\n");
  else TE(TP,"\n");
  TE(TP,"Choice of Weapon: "+IP(ob)->query_weapon()+"\n");
  TE(TP,"Credit Balance: "+IP(ob)->balance()+"\n");
  TE(TP,"( *)(* )( *)(* )( *)(* )( *)(* )( *)(* )( *)(* )\n");
}

net_channel_emote(str) {
/* Guild channel emote */
   int i;
   object people, memb;
   if(!str) {
      write("Usage nem <emote>.\n");
      return 1;}
   people = users();
   for(i = 0; i<sizeof(people); i++) {
      memb=IP(people[i]);
      if(memb && memb->muffled() < 1) {
         tell_object(people[i],"\n"+
           RED+"(CYBER)"+OFF+" "+TPN+" "+str+"\n");
       }
   }
   return 1;
}

net_muffle_channel(str) {
/* Guild channel muffle */
  int muff;
  muff = IP(TP)->muffled();
   if(!str) {
      write("Useage: line <on/off>\n");
      return;
   }
  if(str == "off") {
      if(muff == 1) {
         write("You already are muffled.\n");
         return;}
      else
         muff = 1;
      write("You are now muffled.\n");
      IP(TP)->set_muffle(muff);
      return;
   }
   if(str == "on") {
      if(muff == 0) {
         write(" You were not muffled.\n");
         return;
         }
      else muff = 0;
      write("You are now on the CyberNet.\n");
      IP(TP)->set_muffle(muff);
      return;
      }
}

net_who()  {
int b,glev,artlev,deg;
string type,art;
object ob;
ob = users();

write("\n");
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");
  write("Ninja          Quality    Discipline     Belt     Line      Rank\n");
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");

for(b=0;b<sizeof(ob);b+=1)  {
 if(ob[b]->query_invis() <= this_player()->query_level()) {
  if(present("CyberNinja Implants",ob[b]))  {
   glev = IP(ob[b])->guild_lev();
   art = IP(ob[b])->query_art();
   artlev = IP(ob[b])->query_art_level();
   deg = IP(ob[b])->query_degree();
   write("  ");
   write(pad(CAP(ob[b]->query_name()),15));
   write(pad(IP(ob[b])->guild_lev(),6));
   write("  ");
   if(art)
   write(pad(art, 14));
   else write(pad("none",14));
   write("  ");
   if(deg > 0)
    write(pad(belt_color(artlev,art)+" "+deg,10));
   else write(pad(belt_color(artlev,art),10));
   if(IP(ob[b])->muffled() > 0) {write(pad("Off",6));}
   else write(pad("On",6));
   type = guild_title(glev);
   if(IP(ob[b])->loremaster()) type = "Loremaster";
   if(IP(ob[b])->referee()) type = "Referee";
   if(IP(ob[b])->senator()) type = "Senator";
   if(IP(ob[b])->head_referee()) type = "Head Referee";
   if(IP(ob[b])->sensei()) type = "Sensei";
   if(IP(ob[b])->judge())  type = "Judge";
   if(IP(ob[b])->shogun()) type = "Shogun";
   if(IP(ob[b])->daimyo()) type = "Daimyo";
   if(IP(ob[b])->regent()) type = "Regent";
   if(ob[b]->query_real_name() == EMP1) type = "Emperor";
   if(ob[b]->query_real_name() == EMP2) type = "Emperor";
   write(pad(type,16));
   write("\n");
   }
  }
 }
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
       "~~~~~~~~~~~~~~~\n\n");
return 1;
}

n_con() {
  int hps, sps;
  string name, loc;
  int b;
  object ob;
  ob = users();
  write("\n");
  write("<>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
        "~~~~~~~~~<>\n"+
  " Ninja           HP    SP     Location\n"+
  "<>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
        "~~~~~~~~~<>\n");
  for(b=0;b<sizeof(ob);b+=1) {
    if(ob[b]->query_invis() <= TP->query_level()) {
      if(present("either implants",ob[b])) {
  name = ob[b]->query_name();
  loc = environment(ob[b])->short();
  hps = (ob[b]->query_hp() * 100) / ob[b]->query_mhp();
  sps = (ob[b]->query_sp() * 100) / ob[b]->query_msp();
  write(" "+
    pad(name,15)+" "+pad(hps+"%",5)+" "+pad(sps+"%",7)+" "+loc+"\n");
      }
    }
  }
  write("<>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
        "~~~~~~~~~<>\n");
  return 1;
}

net_channel(str) {
/* Guild channel */
   object everyone, member;
   int i;
   if(!str) {
      write("Usage: net <message>.\n");
      return;}
   everyone = users();
   for(i = 0; i < sizeof(everyone); i++) {
      member = IP(everyone[i]);
      if(member && member->muffled() < 1) {
        tell_object(everyone[i],
    RED+"CYBERNET~~~"+END+" "+BOLD+TPN+END+" "+RED+">>>"+END+" "+str+"\n");
        }
      }
   return 1;
}

overchannel(str) {
/* For announcements */
   object everyone, member;
   int i;
   everyone = users();
   for(i = 0; i < sizeof(everyone); i++) {
      member = IP(everyone[i]);
      if(member && member->muffled() < 1) 
        tell_object(everyone[i],
                 BLINK+BOLD+"<<_CYBERNET_>>>"+OFF+OFF+" "+str+"\n");
      }
   return 1;
}

check_time() {
/* Command to find time on church clock */
  call_other("/room/church.c","long","clock");
  return;
}

execute(string str) {
  string file;
  int guild_xp, guild_rank, real_exp;
  object corpse, ob;
  if(!str) {
    write("Execute who?\n");
    write("Note: This is to be done in only drastic circumstances.\n");
    write("Use the 'suspend' command for lighter situations.\n");
    return; }
  if(!IP(find_player(str))) {
    write("User "+capitalize(str)+" is not valid.\n");
    return; }
  ob = find_player(str);
  guild_xp = IP(ob)->guild_exp();
  guild_rank = IP(ob)->guild_lev();
  real_exp = call_other(ob, "query_exp", 0);
  IP(ob)->set_xp(-guild_xp);
  IP(ob)->set_rank(-guild_rank);
  IP(ob)->set_guild_name(0);
  ob->set_guild_name(0);
  ob->add_guild_exp(-ob->query_guild_exp());
  ob->add_guild_rank(-ob->query_guild_rank());
  ob->set_title("the Dishonored CyberNinja");
  ob->set_guild_file(0);
  ob->set_home("room/church");
  file = "/players/dune/closed/guild/ninjas/"+
         ((string)ob->query_real_name())+".o";
  if(file_size(file) >= 0) rm(file);
  TR(EO, OPN+"'s cyberlinks are disconnected.\n");
  TR(EO, OPN+"'s implants are removed, painfully.\n");
  TR(EO, OPN+" is forced to kneel upon a small platform.\n");
  TR(EO, "An attendant hands "+TPN+" a sharp long-bladed katana.\n");
  TR(EO, TPN+" wields the katana and raises it high in the air.\n");
  TR(EO, "With one quick swing "+OPN+"'s head flies off.\n");
  overchannel(OPN+
              " has been banished with great dishonor from the Ninjas.\n");
  write_file(log+"EXECUTE", capitalize(str)+" was executed by "+
                         RN+". ("+ctime()+"\n");
  IP(ob)->save_me();
  ob->save_me();
  ob->hit_player(100000);
  destruct(present("implants", ob));
}

unsuspend(string str) {
  object ob, imp;
  if(!str) {
    write("Unsuspend who?\n");
    return; }
  if(!IP(find_player(str))) {
    write("User "+capitalize(str)+" is not valid.\n");
    return; }
  ob = find_player(str);
  imp = clone_object("/players/dune/closed/guild/implants.c");
  IP(ob)->set_suspended(0);
  move_object(imp, ob);
  IP(ob)->save_me();
  ob->set_guild_title();
  TE(ob, "You have been reestablished into the CyberNinjas.\n");
  write_file(log+"SUSPEND", 
    capitalize(str)+" was reestablished by "+RN+". ("+ctime()+")\n");
}

suspend(string str) {
  int guild_xp, guild_rank, real_exp;
  object corpse, ob;
  if(!str) {
    write("Suspend who?\n");
    return; }
  if(!IP(find_player(str))) {
    write("User "+capitalize(str)+" is not valid.\n");
    return; }
  ob = find_player(str);
  IP(ob)->set_suspended(1);
  ob->set_title("is suspended from the CyberNinjas");
  TE(ob, "You have been suspended from the CyberNinjas.\n");
  TE(ob, "Mail an Emperor or Regent if you have a problem with this.\n");
  write_file(log+"SUSPEND", 
    capitalize(str)+" was suspended by "+RN+". ("+ctime()+")\n");
  IP(ob)->save_me();
  destruct(IP(ob));
}

recruit_member(string who) {
/* Way to recruit new guild members */
  object ob;
  if(!who) {
    write("Usage: recruit <who>\n");
    return;}
  if(!find_player(who)) {
    write("User "+WHO+" not found.\n");
    return;}
  ob = find_player(who);
  if(present("way of the cyberninja", ob)) {
    TE(TP, OPN+" is already recruited in the CyberNinjas.\n");
    return; }
  if(already_in_a_guild(ob)) {
     TE(TP,OPN+
       " is a member of another guild.\n");
     return;}
  if(ob->query_level() < 6) {
     TE(TP,OPN+
       " is not level six yet.\n");
     return;}
  else {
    write_file(log+"RECRUIT", RN+" recruited "+WHO+" ("+ctime()+")\n");
    write("You have shown "+WHO+" the Way of the CyberNinja.\n");
    TR(EO, TPN+" has shown "+WHO+" the Way of the CyberNinja.\n");
    move_object(clone_object("/players/dune/closed/guild/recruitob.c"),
                ob);
    TE(ob, "You have been shown the Way of the CyberNinja.\n"+
           "Learn it, and you will soon be along the path\n"+
           "to greater destiny.\n");
    return; }
}

int already_in_a_guild(object ob) {
/* Checks if player is in another guild */
  if((ob->query_guild_name() != 0) ||
     (ob->query_guild_exp() != 0)  ||
     (ob->query_guild_file() != 0) ||
     (ob->query_guild_rank() != 0)) {
       return 1;}
  return 0;
}

listEnhancements(string str) {
/* shows all enhancements the person has */
object ob;
if(!str) {
  write("Your enhancements are....\n");
  showItemfunc(TP, TP);
  return; }
if(!find_player(str)) {
  write("No such player.\n");
  return; }
ob = find_player(str);
if(!IP(ob)) {
  write(OPN+" is not a CyberNinja.\n");
  return; }
if(IP(TP)->shogun() || IP(TP)->judge() || IP(TP)->regent() ||
       RN == EMP1 || RN == EMP2) {
  write(OPN+"'s enhancements are....\n");
  showItemfunc(ob, TP);
  return; }
}

showItemfunc(object ob, object me) {
/* ob stores the member of interest, me stores the checker */
write("______________________________\n");
if(IP(ob)->item_corpse()) TE(me, "organic converter\n");
if(IP(ob)->item_activate_droid()) TE(me, "droid\n");
if(IP(ob)->item_stun()) TE(me, "stun ray\n");
if(IP(ob)->item_bionics()) TE(me, "bionics\n");
if(IP(ob)->item_blades()) TE(me, "blades\n");
if(IP(ob)->item_electricflux()) TE(me, "electric flux\n");
if(IP(ob)->item_magneticflux()) TE(me, "magnetic flux\n");
if(IP(ob)->item_heatflux()) TE(me, "heat flux\n");
if(IP(ob)->item_flash()) TE(me, "biolight\n");
if(IP(ob)->item_lastic()) TE(me, "superlastic\n");
if(IP(ob)->item_meld()) TE(me, "enduro meld\n");
if(IP(ob)->item_plate()) TE(me, "pressure plate\n");
if(IP(ob)->item_hide()) TE(me, "metal hide\n");
if(IP(ob)->item_emt()) TE(me, "emotion controller\n");
if(IP(ob)->item_legs()) TE(me, "leg actuators\n");
if(IP(ob)->item_convert()) TE(me, "matter converter\n");
if(IP(ob)->item_weplink()) TE(me, "smartweapon link ["+
  IP(ob)->item_weplink()+"]\n");
write("______________________________\n");
}

listMyAttacks(string str) {
/* shows all attacks the person has */
object ob;
if(!str) {
  write("Your attacks are....\n");
  showAttackfunc(TP, 0, TP);
  return;}
if(!find_player(str)) {
  write("No such player.\n");
  return; }
ob = find_player(str);
if(!IP(ob)) {
  write(OPN+" is not a CyberNinja.\n");
  return; }
if(IP(TP)->shogun() || IP(TP)->judge() || 
   IP(TP)->regent() || IP(TP)->sensei() ||
       RN == EMP1 || RN == EMP2) {
  write(OPN+"'s attacks are....\n");
  showAttackfunc(ob, 0, TP);
  return; }
}

int showAttackfunc(object ob, int flag, object me) {
/* if flag = 1, we're just counting total # attacks */
/* for flag = 0, me is the checker */
int counter;
counter = 0;
if(flag == 0)
   TE(me, "______________________________\n");
if(IP(ob)->query_chop()) { if(flag == 0) TE(me, "chop\n");
                           else counter++; }
if(IP(ob)->query_forearm()) { if(flag == 0) TE(me, "forearm\n");
                           else counter++; }
if(IP(ob)->query_finger_jab()) { if(flag == 0) TE(me, "finger_jab\n");
                           else counter++; }
if(IP(ob)->query_palm_flail()) { if(flag == 0) TE(me, "palm_flail\n");
                           else counter++; }
if(IP(ob)->query_quick_punch()) { if(flag == 0) TE(me, "quick_punch\n");
                           else counter++; }
if(IP(ob)->query_side_kick()) { if(flag == 0) TE(me, "side_kick\n");
                           else counter++; }
if(IP(ob)->query_reverse_kick()) { if(flag == 0) TE(me, "reverse_kick\n");
                           else counter++; }
if(IP(ob)->query_backfist()) { if(flag == 0) TE(me, "backfist\n");
                           else counter++; }
if(IP(ob)->query_drop_kick()) { if(flag == 0) TE(me, "drop_kick\n");
                           else counter++; }
if(IP(ob)->query_front_kick()) { if(flag == 0) TE(me, "front_kick\n");
                           else counter++; }
if(IP(ob)->query_grab()) { if(flag == 0) TE(me, "grab\n");
                           else counter++; }
if(IP(ob)->query_palm_thrust()) { if(flag == 0) TE(me, "palm_thrust\n");
                           else counter++; }
if(IP(ob)->query_strong_punch()) { if(flag == 0) TE(me, "strong_punch\n");
                           else counter++; }
if(IP(ob)->query_fierce_punch()) { if(flag == 0) TE(me, "fierce_punch\n");
                           else counter++; }
if(IP(ob)->query_head_clap()) { if(flag == 0) TE(me, "head_clap\n");
                           else counter++; }
if(IP(ob)->query_hook()) { if(flag == 0) TE(me, "hook\n");
                           else counter++; }
if(IP(ob)->query_elbow_jab()) { if(flag == 0) TE(me, "elbow_jab\n");
                           else counter++; }
if(IP(ob)->query_knee()) { if(flag == 0) TE(me, "knee\n");
                           else counter++; }
if(IP(ob)->query_roundhouse()) { if(flag == 0) TE(me, "roundhouse\n");
                           else counter++; }
if(IP(ob)->query_thrust_kick()) { if(flag == 0) TE(me, "thrust_kick\n");
                           else counter++; }
if(IP(ob)->query_uppercut()) { if(flag == 0) TE(me, "uppercut\n");
                           else counter++; }
if(IP(ob)->query_head_butt()) { if(flag == 0) TE(me, "head_butt\n");
                           else counter++; }
if(IP(ob)->query_lock_and_punch()) { if(flag == 0)
                           TE(me, "lock_and_punch\n");
                           else counter++; }
if(IP(ob)->query_choke_grab()) { if(flag == 0) TE(me, "choke_grab\n");
                           else counter++; }
if(IP(ob)->query_headlock()) { if(flag == 0) TE(me, "headlock\n");
                           else counter++; }
if(IP(ob)->query_lock_and_twist()) { if(flag == 0)
                           TE(me, "lock_and_twist\n");
                           else counter++; }
if(IP(ob)->query_rapid_fist_strike()) { if(flag == 0)
                           TE(me,"rapid_fist_strike\n");
                           else counter++; }
if(IP(ob)->query_rapid_kick()) { if(flag == 0) TE(me, "rapid_kick\n");
                           else counter++; }
if(IP(ob)->query_lock_and_elbow()) { if(flag == 0)
                           TE(me, "lock_and_elbow\n");
                           else counter++; }
if(IP(ob)->query_lock_and_throw()) { if(flag == 0)
                           TE(me, "lock_and_throw\n");
                           else counter++; }
if(IP(ob)->query_bear_hug()) { if(flag == 0) TE(me, "bear_hug\n");
                           else counter++; }
if(IP(ob)->query_over_the_back_slam()) { if(flag == 0)
                           TE(me, "over_the_back_slam\n");
                           else counter++; }
if(IP(ob)->query_pressure_point()) { if(flag == 0)
                           TE(me, "pressure_point\n");
                           else counter++; }
if(flag == 0)
   TE(me, "______________________________\n");

return counter;
}

coinsTocredits(string str) {
int num, bal, total;
 if(!str) {
   write("Usage: creditcoins or cc <amount>\n");
   return; }
 if(!sscanf(str, "%d", num)) {
   write("Usage: creditcoins or cc <amount>\n");
   return; }
 if(num < 0) {
   write("You cannot change credits back to coins.\n");
   return;}
 if(num == 0) {
   write("To change coins to credits, enter an amount > 0\n");
   return;}
 if(TP->query_money() < num) {
   write("You do not have that much coins.\n");
   return;}
 bal = IP(TP)->balance();
 total = bal + num;
 if(total >= 200000) {
   total = 200000 - bal;
   write("The maximum credit limit is 200000 @'s.\n");
   write("You can change only "+total+" more coins into @'s.\n");
   return; }
 TP->add_money(-num);
 IP(TP)->addToBalance(num);
 write("You change "+num+" coins to credits.\n");
 IP(TP)->save_me();
return;
}

query_balance() {
   write("Your credit balance is: "+
   IP(TP)->balance()+" @'s\n");
}

guild_balance() {
   object everyone, member;
   int i, bal;
   everyone = users();
        write("Guild balances...........................\n");
   for(i = 0; i < sizeof(everyone); i++) {
    if(IP(everyone[i]) && !everyone[i]->query_invis())
{
        member = IP(everyone[i]);
        bal = member->balance();
/* THIS DID NOT CHECK FOR INVIS WIZZES -mizan*/
        write(pad(CAP(everyone[i]->query_name()), 20));
        write(bal+" @'s\n");
      }
   }
}

advance_art(string str) {
   object ob;
   object mem;
   string who, art, currentart;
   int artlevel, newlevel, level, xp,
       lowxp, reqxp, freexp, temp, degree;
   int num_atts, allowed_atts;
   if(!str) {
      write("Usage: train <who> <discipline>\n");
      return;}
   if(!sscanf(str, "%s %s", who, art)) {
      write("Usage: train <who> <discipline>\n");
      return;}
   if(!IP(present(who, environment(this_player())))) {
      write("There is no member named "+capitalize(who)+" here.\n");
      return;}
   if(!isAnArt(art)) {
      write("There is no '"+art+"' discipline.\n");
      return;}
   ob = find_player(who);
   mem = present("CyberNinja Implants", ob);
   art = findGoodNameForArt(art);
   currentart = mem->query_art();
   artlevel = mem->query_art_level();
   newlevel = artlevel + 1;
   if(newlevel >= 17) {
     write(WHO+" cannot advance this discipline further.\n");
     TE(ob, "You are already Grandmaster of "+capitalize(art)+".\n");
     return; }
   level = mem->guild_lev();
   if(level == 0) {
     write(WHO+" is too low of quality to train in any disciplines.\n");
     TE(ob, "You try to train but fail.\n");
     return; }
   if((artlevel >= 4) && (level < 3)) {
     write(WHO+" is too low of quality to train in any disciplines.\n");
     TE(ob, "You try to train but fail.\n");
     return; }
   if((artlevel >= 6) && (level < 6)) {
     write(WHO+" is too low of quality to train in any disciplines.\n");
     TE(ob, "You try to train but fail.\n");
     return; }
   xp = mem->guild_exp();
   lowxp = low_exp(level);
   if(newlevel <= 7) reqxp = art_exp(newlevel);
   else reqxp = 200000; /* 200k xp to advance in black belt degrees */
   freexp = xp - lowxp;
   degree = newlevel - 6;
   if(degree > 0) mem->set_degree(degree);
   if(currentart) {
     if(currentart != art) {
       write(WHO+" is already trained in the discipline of "+currentart+".\n");
       write(WHO+" can only concentrate on one discipline at a time.\n");
       return;}
   }
   if(freexp >= reqxp) {
     if(artlevel == 0) {
       mem->set_art(art);
       TE(ob, "You are introduced to the discipline of "+art+".\n");
       TR(EO, TPN+" introduces "+WHO+" to the discipline of "+art+".\n");
       TR(EO, WHO+" is now a white belt in "+art+".\n");
       TE(ob, "A "+belt_color(newlevel,art)+" belt is given to you.\n");
       TE(ob, "A "+belt_color(newlevel,art)+" belt is given to you.\n");
       write("You introduce "+WHO+" to the discipline of "+art+".\n");
       write(WHO+" begins as a white belt.\n");
       }
     if((newlevel < 7) && (newlevel > 1)) {
       TE(ob, "You advance in the discipline of "+art+"!\n");
       TR(EO, TPN+" trains "+WHO+" in the discipline of "+art+".\n");
       TR(EO, WHO+" is now a "+belt_color(newlevel,art)+
                  " belt in "+art+".\n");
       write(WHO+" advances in the discipline of "+art+".\n");
       write("You remove "+WHO+"'s "+belt_color(artlevel,art)+
             " belt and replace it with a "+belt_color(newlevel,art)+
             " belt.\n");
       TE(ob, "You take off your "+belt_color(artlevel,art)+
             " belt and put on a "+belt_color(newlevel,art)+" belt.\n");
          }
     if(newlevel >= 7) {
       TE(ob, "You advance to a black belt of degree "+degree+".\n");
       write("You place a shiny red mark on "+WHO+"'s black belt.\n");
       TR(EO, WHO+" advances to a black belt of degree "+degree+".\n");
       TR(EO, TPN+" places a shiny red mark on "+WHO+"'s black belt.\n");
       TE(ob, "Shiny red markings are added to your black belt.\n");
       }
     if((belt_color(newlevel,art) == "black") && (newlevel == 10)) {
       TE(ob, "You have mastered the discipline of "+art+"!\n");
       TR(EO, WHO+" has just mastered the discipline of "+art+".\n");
       write_file("/players/dune/closed/guild/docs/masters",
                  OPN+", Master of "+capitalize(art)+". ("+ctime()+")\n");
       overchannel(ob->query_real_name()+
                   " has mastered the discipline of "+art+"!\n");
       }
     if((belt_color(newlevel,art) == "black") && (newlevel == 16)) {
       TE(ob, "You have achieved Grandmaster status in the\n"+
              "the discipline of "+art+"!\n");
       TR(EO, WHO+" has become Grandmaster of "+capitalize(art)+".\n");
       write_file("/players/dune/closed/guild/docs/grandmasters",
                  OPN+", Grandmaster of "+capitalize(art)+". ("+ctime()+")\n");
       overchannel(OPN+
                   " has become Grandmaster of "+art+"!\n");
       empower(ob->query_real_name()+" sensei yes");
       }
     temp = newlevel - 6;
     if(temp == 10) {
       write("You have achieved the status of Sensei!\n");
       }
     num_atts = showAttackfunc(ob, 1);
     allowed_atts = artlevel + 1;
     allowed_atts = allowed_atts + 1;
     write(WHO+" has "+num_atts+" attacks.\n");
     write(WHO+" can learn up to a total of "+allowed_atts+" attacks.\n");
     mem->set_art_level(newlevel);
     mem->add_xp(-reqxp);
     if(degree > 0) mem->set_degree(degree);
     write_file(log+"TRAIN", TPN+" trained "+WHO+" to level "+newlevel+
       " in "+capitalize(art)+". ("+ctime()+")\n");
     mem->save_me();
     mem->update_implants();
     return;}
   if(freexp < reqxp) {
     temp = reqxp - freexp;
     write(WHO+" does not have enough free guild experience.\n");
     TE(ob, "You do not have enough free guild experience.\n");
     TE(ob, "You need "+temp+
           " more experience points to learn "+art+".\n");
     return;}
}


int isAnArt(string art) {
 switch(art) {
   case "aikido":            return 1; break;
   case "bando":             return 1; break;
   case "bersilat":          return 1; break;
   case "capoeira":          return 1; break;
   case "eskrima":           return 1; break;
   case "french boxing":     return 1; break;
   case "french_boxing":     return 1; break;
   case "frenchboxing":      return 1; break;
   case "french-boxing":     return 1; break;
   case "hapkido":           return 1; break;
   case "hsing-i":           return 1; break;
   case "hsingi":            return 1; break;
   case "hsing_i":           return 1; break;
   case "hsing i":           return 1; break;
   case "judo":              return 1; break;
   case "jujitsu":           return 1; break;
   case "kabaddi":           return 1; break;
   case "kalaripayit":       return 1; break;
   case "kajukenbo":         return 1; break;
   case "karate":            return 1; break;
   case "kungfu":            return 1; break;
   case "kung fu":           return 1; break;
   case "ler drit":          return 1; break;
   case "ler_drit":          return 1; break;
   case "lerdrit":           return 1; break;
   case "ler-drit":          return 1; break;
   case "lua":               return 1; break;
   case "muay thai":         return 1; break;
   case "muay_thai":         return 1; break;
   case "muay-thai":         return 1; break;
   case "muaythai":          return 1; break;
   case "pa kua":            return 1; break;
   case "pa_kua":            return 1; break;
   case "pakua":             return 1; break;
   case "pa-kua":            return 1; break;
   case "sambo":             return 1; break;
   case "savate":            return 1; break;
   case "special forces":    return 1; break;
   case "special_forces":    return 1; break;
   case "special":           return 1; break;
   case "special-forces":    return 1; break;
   case "forces":            return 1; break;
   case "sumo wrestling":    return 1; break;
   case "sumo":              return 1; break;
   case "taekwondo":         return 1; break;
   case "tai chi":           return 1; break;
   case "tai_chi":           return 1; break;
   case "taichi":            return 1; break;
   case "tai-chi":           return 1; break;
   }
 return 0;
}

string findGoodNameForArt(string art) {
 string name;
 switch(art) {
   case "aikido":             name = "aikido"; break;
   case "bando":              name = "bando"; break;
   case "bersilat":           name = "bersilat"; break;
   case "capoeira":           name = "capoeira"; break;
   case "eskrima":            name = "eskrima"; break;
   case "french boxing":      name = "french_boxing"; break;
   case "french_boxing":      name = "french_boxing"; break;
   case "frenchboxing":       name = "french_boxing"; break;
   case "french-boxing":      name = "french_boxing"; break;
   case "hapkido":            name = "hapkido"; break;
   case "hsing-i":            name = "hsing_i"; break;
   case "hsingi":             name = "hsing_i"; break;
   case "hsing_i":            name = "hsing_i"; break;
   case "hsing i":            name = "hsing_i"; break;
   case "judo":               name = "judo"; break;
   case "jujitsu":            name = "jujitsu"; break;
   case "kabaddi":            name = "kabaddi"; break;
   case "kalaripayit":        name = "kalaripayit"; break;
   case "kajukenbo":          name = "kajukenbo"; break;
   case "karate":             name = "karate"; break;
   case "kungfu":             name = "kungfu"; break;
   case "kung fu":            name = "kungfu"; break;
   case "ler drit":           name = "ler_drit"; break;
   case "lerdrit":            name = "ler_drit"; break;
   case "ler_drit":           name = "ler_drit"; break;
   case "ler-drit":           name = "ler_drit"; break;
   case "lua":                name = "lua"; break;
   case "muay thai":          name = "muay_thai"; break;
   case "muay-thai":          name = "muay_thai"; break;
   case "muay_thai":          name = "muay_thai"; break;
   case "muaythai":           name = "muay_thai"; break;
   case "pa kua":             name = "pa_kua"; break;
   case "pa_kua":             name = "pa_kua"; break;
   case "pakua":              name = "pa_kua"; break;
   case "pa-kua":             name = "pa_kua"; break;
   case "sambo":              name = "sambo"; break;
   case "savate":             name = "savate"; break;
   case "special forces":     name = "special_forces"; break;
   case "special_forces":     name = "special_forces"; break;
   case "special":            name = "special_forces"; break;
   case "special-forces":     name = "special_forces"; break;
   case "forces":             name = "special_forces"; break;
   case "sumo wrestling":     name = "sumo"; break;
   case "sumo":               name = "sumo"; break;
   case "taekwondo":          name = "taekwondo"; break;
   case "tai chi":            name = "tai_chi"; break;
   case "tai_chi":            name = "tai_chi"; break;
   case "taichi":             name = "tai_chi"; break;
   case "tai-chi":            name = "tai_chi"; break;
   }
 return name;
}

int art_exp(int level) {
 int xp;
 switch(level) {
   case 1:    xp = 5000; break;
   case 2:    xp = 15000; break;
   case 3:    xp = 30000; break;
   case 4:    xp = 60000; break;
   case 5:    xp = 100000; break;
   case 6:    xp = 200000; break;
   case 7:    xp = 400000; break;
   }
 return xp;
}

help_belt_levels() {
  /* Gives cost of experience for each belt level */
  int i;
  TE(TP, "Belt          Experience\n");
  TE(TP,"============================================\n");
  for(i = 1; i <= 7; i++) {
    write(pad(
    capitalize((string)belt_color(i,0))
    +"          ", 15));
    write(art_exp(i)+"\n");
    }
  TE(TP,"... 200000 for each black belt degree\n");
  TE(TP,"============================================\n");
  return 1;
}

string belt_color(int level, string art) {
/* I guess we don't really need the string art */
 string belt;
 if(level >= 7) level = 7;
 switch(level) {
     case 0:   belt = "none"; break;
     case 1:   belt = "white"; break;
     case 2:   belt = "purple"; break;
     case 3:   belt = "blue"; break;
     case 4:   belt = "green"; break;
     case 5:   belt = "brown"; break;
     case 6:   belt = "red"; break;
     case 7:   belt = "black"; break;
     }
 return belt;
}

change_art(string str) {
   object ob;
   string who, art, currentart;
   int artlevel, newlevel, deg;
   if(!str) {
      write("Usage: redirect <who> <discipline>\n");
      return;}
   if(!sscanf(str, "%s %s", who, art)) {
      write("Usage: redirect <who> <discipline>\n");
      return;}
   if(!IP(present(who, environment(this_player())))) {
      write("There is no member named "+WHO+" here.\n");
      return;}
   if(!isAnArt(art)) {
      write("There is no '"+art+"' discipline.\n");
      return;}
   ob = present(who, environment(this_player()));
   art = findGoodNameForArt(art);
   currentart = IP(ob)->query_art();
   if(!currentart) {
      write(WHO+" does not have training in any discipline yet.\n");
      write("You must train "+WHO+" in "+art+" first.\n");
      return;}
   if(currentart == art) {
      write(WHO+" is already training in that discipline.\n");
      return;}
   artlevel = IP(ob)->query_art_level();
   if(artlevel == 0) newlevel = 1;
   if(artlevel == 1) newlevel = 1;
   if(artlevel == 2) newlevel = 1;
   if((artlevel >= 3) && (artlevel <=4)) newlevel = artlevel - 1;
   if((artlevel >= 5) && (artlevel <=7)) newlevel = artlevel - 2;
   if((artlevel >= 8) && (artlevel <=10)) newlevel = artlevel - 3;
   if((artlevel >= 11) && (artlevel <=20)) newlevel = artlevel - 4;
   if(artlevel > 20) newlevel = artlevel - 5;
   deg = newlevel - 6;
   write("You change "+WHO+"'s discipline to "+art+".\n");
   TR(EO, WHO+" chooses to study a different discipline.\n");
   TE(ob, TPN+" teaches you the discipline of "+art+
             ", you no longer study "+IP(ob)->query_art()+".\n");
   TE(ob, "You are now a "+belt_color(newlevel,art)+" belt in "+art+".\n");
   if(deg > 0) TE(ob, "Your black belt is now of degree "+deg+".\n");
   write(WHO+" is now a "+belt_color(newlevel,art)+" belt in "+art+".\n");
   write_file(log+"ARTS", RN+" changed "+ob->query_real_name()+
     "'s discipline from "+currentart+" to "+art+". ("+ctime()+")\n");
   if(deg > 0) IP(ob)->set_degree(deg);
   IP(ob)->set_art(art);
   IP(ob)->set_art_level(newlevel);
   IP(ob)->save_me();
   IP(ob)->update_implants();
}

report(string str) {
  if(!str) {
    write("What do you wish to report?\n");
    write("Remember to include the name of the tournament.\n");
    return 1; }
  write_file("/players/dune/closed/guild/tournaments/reports",
     RN+" reports: "+str+"  ("+ctime()+")\n");
  write("You file your report.\n");
  return 1;
}

tourney() {
   write("Looking up tournament info...\n");
   call_other("/players/dune/closed/guild/_more.c",
              "more_file", 
              "/players/dune/closed/guild/tournaments/reports");
   return 1;
}

refassist(string who) {
  object ob;
  if(!who) {
    write("Who do you want to make referee?\n");
    return 1; }
  if(!present(who, environment(TP))) {
    write(capitalize(who)+" is not here.\n");
    return 1; }
  if(!find_player(who)) {
    write("You can only make players referees.\n");
    return 1; }
  ob = find_player(who);
  if(IP(ob)->referee()) {
    write(capitalize(who)+" is already a referee.\n");
    return 1; }
  IP(ob)->set_referee(1);
   IP(ob)->save_me();
   IP(ob)->update_implants();
  tell_object(ob, TPN+" has made you referee.\n");
  write("You make "+OPN+" a referee.\n");
  overchannel(OPN+" has become referee.\n");
  write_file(log+"REFEREE", RN+" made "+ob->query_real_name()+
    " a referee. ("+ctime()+")\n");
  return 1;
}

unref(string who) {
  object ob;
  if(!who) {
    write("Who do you want to fire?\n");
    return 1; }
  if(!present(who, environment(TP))) {
    write(capitalize(who)+" is not here.\n");
    return 1; }
  if(!find_player(who)) {
    write(capitalize(who)+" is not a player.\n");
    return 1; }
  ob = find_player(who);
  if(!IP(ob)->referee()) {
    write(capitalize(who)+" is not a referee in the first place.\n");
    return 1; }
  IP(ob)->set_referee(0);
  IP(ob)->save_me();
  IP(ob)->update_implants();
  tell_object(ob, TPN+" has fired you from the referee position.\n");
  write("You fire "+OPN+" from the referee position.\n");
  overchannel("Referee "+OPN+" has been fired by "+TPN+".\n");
  write_file(log+"REFEREE", 
    RN+" fired referee "+ob->query_real_name()+". ("+ctime()+")\n");
  return 1;
}

all_file_watcher(string str) {
  string file;
  if(!str) {
    write("You may access the following data logs.\n");
    ls("/players/dune/closed/guild/log");
    return 1; }
  file = "/players/dune/closed/guild/log/"+str;
  if(file_size(file) >= 0) {
    write("You access the "+str+" data log.\n");
    call_other("/players/dune/closed/guild/_more.c",
               "more_file", file);
    return 1; }
  write("There is no "+str+" data log.\n");
  return 1; }

end_file_watcher(string str) {
  string file;
  if(!str) {
    write("You may access the following data logs.\n");
    ls("/players/dune/closed/guild/log");
    return 1; }
  file = "/players/dune/closed/guild/log/"+str;
  if(file_size(file) >= 0) {
    write("You access the "+str+" data log.\n");
    tail(file);
    return 1; }
  write("There is no "+str+" data log.\n");
  return 1; }

match(string str) { /* counts kills for pk fights */
  object ob;
  int mylevel, targlevel, combatlevel;
  mylevel = this_player()->query_level();
  if(!str) {
    write("Who do you want to challenge?\n");
    return 1; }
  if(!present(str, environment(this_player()))) {
    write(capitalize(str)+" is not here.\n");
    return 1; }
  if(present("deathmatch_object", TP)) {
    write("You are already involved in a deathmatch.\n");
    return 1; }
  if(!find_player(str)) {
    write("You can only challenge other players.\n");
    return 1; }
  ob = find_player(str);
  if(ob == this_player()) {
    write("You cannot challenge yourself to a death match.\n");
    return 1; }
  targlevel = ob->query_level();
  combatlevel = mylevel - targlevel;
  if(combatlevel >= 5) {
    write("Your little death match is deemed unworthy.\n");
    return 1; }
  if(ob->query_ghost()) {
    write("You cannot challenge a ghost!\n");
    return 1; }
  if(!ob->query_pl_k()) {
    write("You can only attack other player killers.\n");
    return 1; }
  if(!this_player()->query_pl_k()) {
    write("You are not a player killer!\n");
    write("Type 'kill_players' to set your pk flag.\n");
    return 1; }
  write("You have challenged "+capitalize(str)+
        " to a match of death.\n");
  tell_object(ob, "You have been challenged by "+
                  TPN+" to a match of death.\n");
  move_object(clone_object("/players/dune/closed/guild/deathmatches/deathob.c"),
    TP);
  call_out("observe_match", 1, RN+" "+str);
  return 1;
}

observe_match(string str) {
  object targ, ob;
  string mename, targname, name;
  sscanf(str, "%s %s", mename, targname);
  mename = lower_case(mename);
  targname = lower_case(targname);
  ob = find_player(mename);
  targ = find_player(targname);
  name = targ->query_name();
  name = capitalize(name);
  if(!present(targ, environment(ob))) {
    tell_object(ob, "The death match is terminated.\n");
    if(present("deathmatch_object", ob)) 
      destruct(present("deathmatch_object", ob));
    return 1; }
  if(targ->query_ghost()) {
    overchannel(OPN+" has defeated "+capitalize(targ->query_real_name())
    +" in a death match!\n");
    IP(ob)->add_kills(1);
    IP(ob)->save_me();
    IP(ob)->get_deathmatch_permission(1);
    command("log_my_deathmatch "+mename+" "+targname, ob);
    tell_object(ob, "You have received one kill.\n");
    tell_object(ob, "You now have "+IP(ob)->query_kills()+" kills.\n");
    if(present("deathmatch_object", ob))
      destruct(present("deathmatch_object", ob));
    return 1; }
  call_out("observe_match", 1, mename+" "+targname);
  return 1;
}

log_my_deathmatch(string jumble) {
  object winner, loser;
  string mename, targname;
  if(!IP(TP)->query_deathmatch_permission()) return 0;
  sscanf(jumble, "%s %s", mename, targname);
  winner = find_player(mename);
  loser  = find_player(targname);
  write_file("/players/dune/closed/guild/deathmatches/"+
    winner->query_real_name(), capitalize(winner->query_name())+
    " (level "+winner->query_level()+
    ") killed "+loser->query_real_name()+
    " (level "+loser->query_level()+") on "+ctime()+".\n");
  IP(TP)->get_deathmatch_permission(0);
  return 1;
}

deaths(string str) {
  string file, namme;
  object everyone;
  int i, kills;
  if(!str) {
    file = "/players/dune/closed/guild/deathmatches/"+RN+"";
  if ((file_size(file) >= 0) && (file_size(file) < 1000)) {
    write("Your death match record....\n");
    cat(file);
    return 1; }
  if (file_size(file) >= 1000) {
    write("Your death match record....\n");
    call_other("/players/dune/closed/guild/_more.c","more_file",file);
    return 1; }
    write("You have no death match record.\n");
    return 1; }
  if(str == "list") {
    everyone = users();
    write("~~~~~~~~~~~~~~~~~Death Match Kills~~~~~~~~~~~~~~~~~\n");
    write("Name              Kills          Title\n");
    write("___________________________________________________\n");
    for(i = 0; i < sizeof(everyone); i++) {
      if(IP(everyone[i])) {
        kills = IP(everyone[i])->query_kills();
        namme = everyone[i]->query_name();
        write(pad(CAP(namme), 20));
        write(pad(kills, 10));
        if(kills <= 0) write("Commoner\n");
        if(kills >= 1 && kills <= 4) write("Initiate Assassin\n");
        if(kills >= 5 && kills <= 10) write("Assassin\n");
        if(kills >= 11 && kills <= 20) write("Expert Assassin\n");
        if(kills >= 21 && kills <= 40) write("Senior Assassin\n");
        if(kills >= 41 && kills <= 60) write("Elder Assassin\n");
        if(kills >= 61 && kills <= 99) write("Master of Assassins\n");
        if(kills >= 100) write("Grandfather of Assassins\n");
        }
      }
     write("___________________________________________________\n");
     return 1; }
  file = "/players/dune/closed/guild/deathmatches/"+str+"";
  if ((file_size(file) >= 0) && (file_size(file) < 1000)) {
    write(capitalize(str)+"'s death match record....\n");
    cat(file);
    return 1; }
  if (file_size(file) >= 1000) {
    write(capitalize(str)+"'s death match record....\n");
    call_other("/players/dune/closed/guild/_more.c","more_file",file);
    return 1; }
  write("No death match record on file for "+capitalize(str)+".\n");
  return 1;
}

empower (string str) {
   object ob;
   string who, type, flag;
   if(!str) {
     write("Usage: empower <who> [type] [yes/no]\n");
     write("Where type is: sensei/regent/shogun/referee/judge\n"+
           "               head_referee/senator/loremaster/watcher\n");
     return;}
   if(!sscanf(str, "%s %s %s", who, type, flag)) {
     write("Usage: empower <who> [type] [yes/no]\n");
     write("Where type is: sensei/regent/shogun/referee/judge\n"+
           "               head_referee/senator/loremaster/watcher\n");
     return;}
   if(!find_player(who)) {
     write("No such player.\n");
     return; }
   ob = find_player(who);
   if(!IP(ob)) {
     write(WHO+" is not a CyberNinja.\n");
     return; }
   if( (type == "sensei") || (type == "shogun") || (type == "judge") ||
       (type == "regent") || (type == "referee") ||
       (type == "senator") || (type == "loremaster") ||
       (type == "head_referee") || (type == "watcher") ) {
     if((flag == "yes") || (flag == "no")) {

       if(type == "regent") {
         if(RN == EMP1 || RN == EMP2) {}
         else {
           write("Only an Emperor can empower Regents.\n");
           return; }
         if(flag == "yes") {
           if(IP(ob)->regent()) {
             write(WHO+" is already regent.\n");
             return;}
           else {
             write("You empower "+WHO+" with Regent abilities!\n");
             IP(ob)->set_regent(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Regent!\n");
             overchannel(OPN+" has become the Regent!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Regent. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->regent()) {
             write(WHO+" is not Regent in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Regent abilities.\n");
             IP(ob)->set_regent(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Regent abilities.\n");
             overchannel(OPN+" is no longer Regent.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Regent. ("+ctime()+")\n");
         return;}
           }}

       if(type == "sensei") {
         if(flag == "yes") {
           if(IP(ob)->sensei()) {
             write(WHO+" is already Sensei.\n");
             return;}
           else {
             write(WHO+" is empowered with Sensei abilities.\n");
             IP(ob)->set_sensei(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, "You have become Sensei!\n");
             overchannel(OPN+" has become sensei!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Sensei. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->sensei()) {
             write(WHO+" is not Sensei in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Sensei abilities.\n");
             IP(ob)->set_sensei(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Sensei abilities.\n");
             overchannel(OPN+" is no longer Sensei.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Sensei. ("+ctime()+")\n");
             return;}
           }}
       if(type == "shogun") {
         if(flag == "yes") {
           if(IP(ob)->shogun()) {
             write(WHO+" is already Shogun.\n");
             return;}
           else {
             write("You empower "+WHO+" with Shogun abilities.\n");
             IP(ob)->set_shogun(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Shogun!\n");
             overchannel(OPN+" has become Shogun!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Shogun. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->shogun()) {
             write(WHO+" is not Shogun in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Shogun abilities.\n");
             IP(ob)->set_shogun(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Shogun abilities.\n");
             overchannel(OPN+" is no longer Shogun.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Shogun. ("+ctime()+")\n");
             return;}
           }}
       if(type == "senator") {
         if(flag == "yes") {
           if(IP(ob)->senator()) {
             write(WHO+" is already Senator.\n");
             return;}
           else {
             write("You empower "+WHO+" with Senator abilities!\n");
             IP(ob)->set_senator(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Senator!\n");
             overchannel(OPN+" has become Senator!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Senator. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->senator()) {
             write(WHO+" is not Senator in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Senator abilities.\n");
             IP(ob)->set_senator(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Senator abilities.\n");
             overchannel(OPN+" is no longer Senator.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Senator. ("+ctime()+")\n");
             return;}
           }}
       if(type == "loremaster") {
         if(flag == "yes") {
           if(IP(ob)->loremaster()) {
             write(WHO+" is already Loremaster.\n");
             return;}
           else {
             write("You empower "+WHO+" with Loremaster abilities!\n");
             IP(ob)->set_loremaster(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Loremaster!\n");
             overchannel(OPN+" has become Loremaster!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Loremaster. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->loremaster()) {
             write(WHO+" is not Loremaster in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Loremaster abilities.\n");
             IP(ob)->set_loremaster(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Loremaster abilities.\n");
             overchannel(OPN+" is no longer Loremaster.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Loremaster. ("+ctime()+")\n");
             return;}
           }}
       if(type == "watcher") {
         if(flag == "yes") {
           if(IP(ob)->watcher()) {
             write(WHO+" is already a Watcher.\n");
             return;}
           else {
             write("You empower "+WHO+" with Watcher abilities.\n");
             IP(ob)->set_watcher(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Watcher.\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Watcher. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->watcher()) {
             write(WHO+" is not a Watcher in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Watcher abilities.\n");
             IP(ob)->set_watcher(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Watcher abilities.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Watcher. ("+ctime()+")\n");
             return;}
           }}
       if(type == "referee") {
         if(flag == "yes") {
           if(IP(ob)->referee()) {
             write(WHO+" is already Referee.\n");
             return;}
           else {
             write("You empower "+WHO+" with Referee abilities.\n");
             IP(ob)->set_referee(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Referee!\n");
             overchannel(OPN+" has become Referee!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Referee. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->referee()) {
             write(WHO+" is not Referee in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Referee abilities.\n");
             IP(ob)->set_referee(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Referee abilities.\n");
             overchannel(OPN+" is no longer Referee.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Referee. ("+ctime()+")\n");
             return;}
           }}
       if(type == "head_referee") {
         if(flag == "yes") {
           if(IP(ob)->head_referee()) {
             write(WHO+" is already Head Referee.\n");
             return;}
           else {
             write("You empower "+WHO+" with Head Referee abilities.\n");
             IP(ob)->set_head_referee(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Head Referee!\n");
             overchannel(OPN+" has become head referee!\n");
             write_file(log+"EMPOWER", RN+" made "+ob->query_real_name()+
                          " a Head Referee. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->head_referee()) {
             write(WHO+" is not Head Referee in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Head Referee abilities.\n");
             IP(ob)->set_head_referee(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Head Referee abilities.\n");
             overchannel(OPN+" is no longer Head Referee.\n");
             write_file(log+"EMPOWER", RN+" removed "+ob->query_real_name()+
                          " from Head Referee. ("+ctime()+")\n");
             return;}
           }}
       if(type == "judge") {
         if(flag == "yes") {
           if(IP(ob)->judge()) {
             write(WHO+" is already Judge.\n");
             return;}
           else {
             write("You empower "+WHO+
                   " with Judge abilities.\n");
             IP(ob)->set_judge(1);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has made you Judge!\n");
             overchannel(OPN+" has become JUDGE!\n");
             write_file(log+"EMPOWER", RN+
                        " made "+ob->query_real_name()+
                        " a Judge. ("+ctime()+")\n");
             return;}
           }
         if(flag == "no") {
           if(!IP(ob)->judge()) {
             write(WHO+" is not Judge in the first place.\n");
             return;}
           else {
             write("You take away "+WHO+"'s Judge abilities.\n");
             IP(ob)->set_judge(0);
             IP(ob)->save_me();
             IP(ob)->update_implants();
             TE(ob, TPN+" has removed your Judge abilities.\n");
             overchannel(OPN+" is no longer Judge.\n");
             write_file(log+"EMPOWER", RN+" removed "+
                        ob->query_real_name()+
                        " from Judge. ("+ctime()+")\n");
             return;}
           }}
     }
     write("Usage: empower <who> [type] [yes/no]\n");
     write("Where type is: sensei/regent/shogun/referee/judge\n"+
           "               head_referee/senator/loremaster/watcher\n");
     return;
   }
   write("Usage: empower <who> [type] [yes/no]\n");
write("Where type is: sensei/regent/shogun/referee/judge\n"+
         "               head_referee/senator/loremaster/watcher\n");
   return;
}

weapon() {
/* gives a player their ninja weapon */
  int currentwep, artcost;
  string wepmaster;
  wepmaster = "/players/dune/closed/guild/rooms/weaponry.c";
  currentwep = IP(TP)->query_weapon();
  if(!currentwep) {
    write("You do not have a weapon in the first place.\n");
    return;}
  if(! (wepmaster->isAweapon(currentwep)) ) {
    write("Your weapon does not exist.\n");
    return;}
  if(TP->query_spell_point() < 40) {
    write("You try to retrieve your weapon from cyberspace.\n");
    write("However, you are too low in energy.\n");
    return;}
  if(present("nwep",TP)) {
    write("You already have a weapon.\n");
  return 1;
  }
  call_other(TP, "add_spell_point", -40);
  currentwep = (wepmaster->findGoodNameForWeapon(currentwep));
  wepmaster->get_weapon(currentwep);
  write("You draw a "+currentwep+" out from cyberspace.\n");
  say(TPN+" draws a "+currentwep+" out from cyberspace.\n");
}

pick_attack(string str) {
/* used by senseis to choose an art for someone */
  object ob;
  string who, att, art, alreadyHasString, stringlevel, tempatt;
  int artlev, attlevel, num_atts;
  int allowed_atts;
  if(!str) {
    write("Usage: pick <player> <attack>\n");
    return;}
  if(!sscanf(str, "%s %s", who, att)) {
    write("Usage: pick <player> <attack>\n");
    return;}
  if(!find_player(who)) {
    write(WHO+" is not a player.\n");
    return 1; }
  if(!IP(present(who, environment(this_player())))) {
    write("Member "+WHO+" is not here.\n");
    return;}
  ob = present(who, environment(this_player()));
  art = IP(ob)->query_art();
  tempatt = att;
  att = attackFunc(ob, att, 1, 0);
  if(!att) {
    write("There is no attack called '"+tempatt+"'.\n");
    return;}
  if(!isAnArt(art)) {
    write(WHO+" doesn't even have a discipline to begin with.\n");
    return;}
  artlev = IP(ob)->query_art_level();
  stringlevel = attackFunc(ob, att, 2, 0);
  sscanf(stringlevel, "%d", attlevel);
  if(attlevel > artlev) {
    write(WHO+" is too low of belt to learn that attack.\n");
    return;}
  num_atts = showAttackfunc(ob, 1);
  allowed_atts = artlev + 1;
  if( (ORN == EMP1) ||
      (ORN == EMP2) ||
      (IP(ob)->regent()) )
      allowed_atts = 1000;
  if(num_atts >= allowed_atts) {
    write(WHO+" cannot learn any more attacks.\n");
    TE(ob, "You are unable to learn another attack.\n");
    return; }
  alreadyHasString = attackFunc(ob, att, 3, 0);
  if(alreadyHasString == "1") {
    write(WHO+" already has the "+att+" attack.\n");
    return;}
  attackFunc(ob, att, 4, 1);
  write_file(log+"ATTACKS", "Sensei "+
    RN+" taught "+WHO+" the "+att+" attack. ("+ctime()+")\n");
  write("You teach "+WHO+" the "+att+" attack form.\n");
  TE(ob, RN+" has taught you the "+att+" attack form.\n");
  TR(EO, TPN+" instructs "+WHO+" in an attack form.\n");
  IP(ob)->save_me();
  IP(ob)->update_implants();
}

change_attack(string str) {
/* allow for changing of attacks */
  string oldatt, newatt, art, alreadyHasString, stringlevel, who,
         tempnew, tempold;
  object ob;
  int artlev, attlevel;
  if(!str) {
    write("Usage: change_attack <who> <attack1> <attack2>\n");
    write("...Where attack1 will be changed to attack2.\n");
    return;}
  if(!sscanf(str, "%s %s %s", who, oldatt, newatt)) {
    write("Usage: change_attack <who> <attack1> <attack2>\n");
    write("...Where attack1 will be changed to attack2.\n");
    return;}
  who = lower_case(who);
  if(!IP(present(who, environment(this_player())))) {
    write("Member "+WHO+" is not here.\n");
    return;}
  ob = present(who, ENV(TP));
  art = IP(ob)->query_art();
  tempnew = newatt;
  tempold = oldatt;
  oldatt = attackFunc(ob, oldatt, 1, 0);
  newatt = attackFunc(ob, newatt, 1, 0);
  if(!oldatt) {
    write("There is no attack called '"+tempold+"'.\n");
    return;}
  if(!newatt) {
    write("There is no attack called '"+tempnew+"'.\n");
    return;}
  if(!isAnArt(art)) {
    write(WHO+" doesn't even have a discipline to begin with.\n");
    TE(ob, TPN+" tries to change your attack but fails.\n");
    return;}
  artlev = IP(ob)->query_art_level();
  stringlevel = attackFunc(ob, newatt, 2, 0);
  sscanf(stringlevel, "%d", attlevel);
  if(attlevel > artlev) {
    write(WHO+" is too low of belt to have that attack.\n");
    TE(ob, TPN+" tries to change your attack but fails.\n");
    return;}
  alreadyHasString = attackFunc(ob, oldatt, 3, 0);
  if(alreadyHasString != "1") {
    write(WHO+" does not have the "+oldatt+" attack.\n");
    TE(ob, TPN+" tries to change your attack but fails.\n");
    return;}
  alreadyHasString = attackFunc(ob, newatt, 3, 0);
  if(alreadyHasString == "1") {
    write(WHO+" already has the "+newatt+" attack.\n");
    TE(ob, TPN+" tries to change your attack but fails.\n");
    return;}
  attackFunc(ob, newatt, 4, 1); /* set newatt to 1 (add)*/
  attackFunc(ob, oldatt, 4, 0); /* set oldatt to 0 (remove)*/
  write(WHO+" unlearns the "+oldatt+" attack and learns the "+newatt+".\n");
  TE(ob, "You unlearn the "+oldatt+" attack and learn the "+newatt+".\n");
  IP(ob)->save_me();
  IP(ob)->update_implants();
}

string attackFunc(object ob, string att, int runthrough, int new) {
/* beast of a function that does various lookups */
  string name, flag, level;
  name = 0;
  flag = 0;
  switch(att) {
case "chop":
     name = "chop"; level = "1"; 
     if(IP(ob)->query_chop()) flag = "1";
     if(runthrough == 4) IP(ob)->set_chop(new);
     break;
case "forearm":
     name = "forearm"; level = "1"; 
     if(IP(ob)->query_forearm()) flag = "1";
     if(runthrough == 4) IP(ob)->set_forearm(new);
     break;
case "finger_jab":
     name = "finger_jab"; level = "1"; 
     if(IP(ob)->query_finger_jab()) flag = "1";
     if(runthrough == 4) IP(ob)->set_finger_jab(new);
     break;
case "palm_flail": 
     name = "palm_flail"; level = "1"; 
     if(IP(ob)->query_palm_flail()) flag = "1";
     if(runthrough == 4) IP(ob)->set_palm_flail(new);
     break;
case "quick_punch":
     name = "quick_punch"; level = "1"; 
     if(IP(ob)->query_quick_punch()) flag = "1";
     if(runthrough == 4) IP(ob)->set_quick_punch(new);
     break;
case "side_kick":
     name = "side_kick"; level = "1"; 
     if(IP(ob)->query_side_kick()) flag = "1";
     if(runthrough == 4) IP(ob)->set_side_kick(new);
     break;
case "reverse_kick":
     name = "reverse_kick"; level = "2"; 
     if(IP(ob)->query_reverse_kick()) flag = "1";
     if(runthrough == 4) IP(ob)->set_reverse_kick(new);
     break;
case "backfist":
     name = "backfist"; level = "2"; 
     if(IP(ob)->query_backfist()) flag = "1";
     if(runthrough == 4) IP(ob)->set_backfist(new);
     break;
case "drop_kick":
     name = "drop_kick"; level = "2"; 
     if(IP(ob)->query_drop_kick()) flag = "1";
     if(runthrough == 4) IP(ob)->set_drop_kick(new);
     break;
case "front_kick":
     name = "front_kick"; level = "2"; 
     if(IP(ob)->query_front_kick()) flag = "1";
     if(runthrough == 4) IP(ob)->set_front_kick(new);
     break;
case "grab":
     name = "grab"; level = "2"; 
     if(IP(ob)->query_grab()) flag = "1";
     if(runthrough == 4) IP(ob)->set_grab(new);
     break;
case "palm_thrust":
     name = "palm_thrust"; level = "2"; 
     if(IP(ob)->query_palm_thrust()) flag = "1";
     if(runthrough == 4) IP(ob)->set_palm_thrust(new);
     break;
case "strong_punch":
     name = "strong_punch"; level = "2"; 
     if(IP(ob)->query_strong_punch()) flag = "1";
     if(runthrough == 4) IP(ob)->set_strong_punch(new);
     break;
case "fierce_punch":
     name = "fierce_punch"; level = "3"; 
     if(IP(ob)->query_fierce_punch()) flag = "1";
     if(runthrough == 4) IP(ob)->set_fierce_punch(new);
     break;
case "head_clap":
     name = "head_clap"; level = "3"; 
     if(IP(ob)->query_head_clap()) flag = "1";
     if(runthrough == 4) IP(ob)->set_head_clap(new);
     break;
case "hook":
     name = "hook"; level = "3"; 
     if(IP(ob)->query_hook()) flag = "1";
     if(runthrough == 4) IP(ob)->set_hook(new);
     break;
case "elbow_jab":
     name = "elbow_jab"; level = "3"; 
     if(IP(ob)->query_elbow_jab()) flag = "1";
     if(runthrough == 4) IP(ob)->set_elbow_jab(new);
     break;
case "knee":
     name = "knee"; level = "3"; 
     if(IP(ob)->query_knee()) flag = "1";
     if(runthrough == 4) IP(ob)->set_knee(new);
     break;
case "roundhouse":
     name = "roundhouse"; level = "3"; 
     if(IP(ob)->query_roundhouse()) flag = "1";
     if(runthrough == 4) IP(ob)->set_roundhouse(new);
     break;
case "thrust_kick":
     name = "thrust_kick"; level = "3"; 
     if(IP(ob)->query_thrust_kick()) flag = "1";
     if(runthrough == 4) IP(ob)->set_thrust_kick(new);
     break;
case "uppercut":
     name = "uppercut"; level = "3"; 
     if(IP(ob)->query_uppercut()) flag = "1";
     if(runthrough == 4) IP(ob)->set_uppercut(new);
     break;
case "head_butt":
     name = "head_butt"; level = "4"; 
     if(IP(ob)->query_head_butt()) flag = "1";
     if(runthrough == 4) IP(ob)->set_head_butt(new);
     break;
case "lock_and_punch":
     name = "lock_and_punch"; level = "5"; 
     if(IP(ob)->query_lock_and_punch()) flag = "1";
     if(runthrough == 4) IP(ob)->set_lock_and_punch(new);
     break;
case "choke_grab":
     name = "choke_grab"; level = "5"; 
     if(IP(ob)->query_choke_grab()) flag = "1";
     if(runthrough == 4) IP(ob)->set_choke_grab(new);
     break;
case "headlock":
     name = "headlock"; level = "4"; 
     if(IP(ob)->query_headlock()) flag = "1";
     if(runthrough == 4) IP(ob)->set_headlock(new);
     break;
case "lock_and_twist":
     name = "lock_and_twist"; level = "4"; 
     if(IP(ob)->query_lock_and_twist()) flag = "1";
     if(runthrough == 4) IP(ob)->set_lock_and_twist(new);
     break;
case "rapid_fist_strike":
     name = "rapid_fist_strike"; level = "7"; 
     if(IP(ob)->query_rapid_fist_strike()) flag = "1";
     if(runthrough == 4) IP(ob)->set_rapid_fist_strike(new);
     break;
case "rapid_kick":
     name = "rapid_kick"; level = "5"; 
     if(IP(ob)->query_rapid_kick()) flag = "1";
     if(runthrough == 4) IP(ob)->set_rapid_kick(new);
     break;
case "lock_and_elbow":
     name = "lock_and_elbow"; level = "6"; 
     if(IP(ob)->query_lock_and_elbow()) flag = "1";
     if(runthrough == 4) IP(ob)->set_lock_and_elbow(new);
     break;
case "lock_and_throw":
     name = "lock_and_throw"; level = "6"; 
     if(IP(ob)->query_lock_and_throw()) flag = "1";
     if(runthrough == 4) IP(ob)->set_lock_and_throw(new);
     break;
case "bear_hug":
     name = "bear_hug"; level = "7"; 
     if(IP(ob)->query_bear_hug()) flag = "1";
     if(runthrough == 4) IP(ob)->set_bear_hug(new);
     break;
case "over_the_back_slam":
     name = "over_the_back_slam"; level = "7"; 
     if(IP(ob)->query_over_the_back_slam()) flag = "1";
     if(runthrough == 4) IP(ob)->set_over_the_back_slam(new);
     break;
case "pressure_point":
     name = "pressure_point"; level = "6"; 
     if(IP(ob)->query_pressure_point()) flag = "1";
     if(runthrough == 4) IP(ob)->set_pressure_point(new);
     break;
    }
 if(runthrough == 1) return name;
 if(runthrough == 2) return level;
 if(runthrough == 3) return flag;
 return "nevermindThis";
}

setArt(string str) {
  object ob;
  string who, art, currentart;
  if(!str) { 
    write("Usage: set_art <player> <discipline>\n");
    return;}
  if(!sscanf(str, "%s %s", who, art)) {
    write("Usage: set_art <player> <discipline>\n");
    return;}
  if(!IP(find_player(who))) {
    write("Not a valid user.\n");
    return; }
  if(!isAnArt(art)) {
    write("Not a valid art.\n");
    return;}
  ob = IP(find_player(who));
  currentart = ob->query_art();
  art = findGoodNameForArt(art);
  if(art == currentart) {
    write(WHO+" already has that discipline.\n");
    return; }
  TE(EO, "Your discipline has been changed to "+art+" by "+TPN+".\n");
  write_file(log+"ARTS", 
    RN+" changed "+WHO+"'s discipline to "+art+". ("+ctime()+")\n");
  ob->set_art(art);
  ob->save_me();
  ob->update_implants();
}

setArtLevel(string str) {
  object ob;
  string who, art, belt;
  int currentlevel, level, degreelevel;
  if(!str) { 
    write("Usage: set_art_level <player> <level>\n");
    return;}
  if(!sscanf(str, "%s %d", who, level)) {
    write("Usage: set_art_level <player> <level>\n");
    return;}
  if(!IP(find_player(who))) {
    write("Not a valid user.\n");
    return; }
  if(level < 0) {
    write("Not a valid level.\n");
    return;}
  ob = IP(find_player(who));
  currentlevel = ob->query_art_level();
  if(level == currentlevel) {
    write(WHO+" is already of discipline level "+level+".\n");
    return; }
  art = ob->query_art();
  belt = belt_color(level, art);
  if(level < 7) 
    TE(EO, "Your belt has been changed to "+belt+" by "+TPN+".\n");
  if(level >= 7) {
    degreelevel = level - 6;
    TE(EO, "Your black belt degree has been changed to "+
           degreelevel+".\n"); }
  if(degreelevel > 0) ob->set_degree(degreelevel);
  write_file(log+"ARTS",
    RN+" changed "+WHO+"'s discipline level from "+currentlevel+
    " to "+level+". ("+ctime()+")\n");
  ob->set_art_level(level);
  ob->save_me();
  ob->update_implants();
}

setWeapon(string str) {
  object ob;
  string who, weapon, currentweapon;
  if(!str) { 
    write("Usage: set_weapon <player> <weapon>\n");
    return;}
  if(!sscanf(str, "%s %s", who, weapon)) {
    write("Usage: set_weapon <player> <weapon>\n");
    return;}
  if(!IP(find_player(who))) {
    write("Not a valid user.\n");
    return; }
  if( !("/players/dune/closed/guild/rooms/weaponry.c"->
      isAweapon(weapon))) {    
    write("Not a valid weapon.\n");
    write("Weapon will be set anyway.\n");
    }
  ob = IP(find_player(who));
  currentweapon = ob->query_weapon();
  if(weapon == currentweapon) {
    write(WHO+" is already using that weapon.\n");
    return; }
  TE(EO, "Your weapon has been changed to "+weapon+" by "+TPN+".\n");
  write_file(log+"WEPS", 
    RN+" set "+WHO+"'s weapon from "+currentweapon+" to "+
    weapon+". ("+ctime()+")\n");
  ob->set_weapon(weapon);
  ob->save_me();
  ob->update_implants();
}

addCredits(string str) {
/* Used for guild credit promotion/demotion/fixing */
  int amount;
  string who;
  object whoob;
  if(!str) {
    write("Usage: add_credits <member> <amount>.\n");
    return;}
  if(!sscanf(str, "%s %d", who, amount)) {
    write("Usage: add_credits <member> <amount>.\n");
    return;}
  if(!IP(find_player(who))) {
    write("User "+capitalize(who)+" is not valid.\n");
    return;}
  whoob = find_player(who);
  IP(whoob)->addToBalance(amount);
  IP(whoob)->save_me();
  if(amount >= 0)
    write("You alter "+capitalize(who)+"'s guild credits by +"
      +amount+".\n");
  else write("You alter "+capitalize(who)+"'s guild credits by "
      +amount+".\n");
  write_file(log+"BANK", 
    RN+" altered "+whoob->query_real_name()+"'s guild credits by "+
    amount+". ("+ctime()+")\n");
}

strike(string str) {
  /* This allows the player to just do one attack */
  /* Instead of an attack sequence                */
  string att, who, tpp, jumble;  if(!str) {
    write("Usage: st/strike <attack> <who>\n");
    return 1; }
  if(!sscanf(str, "%s %s", att, who)) {
    if(MEAT) att = MEAT->query_real_name(); /*who variable not needed*/
    else {
      write("Usage: st/strike <attack> <who>\n");
      return 1; }
    }
  if(!who) att = str;
  tpp = lower_case(this_player()->query_real_name());
  jumble = tpp+" "+att+" "+who;
  genAttacks(jumble);
  return 1;
}

genAttacks(string str) {
  string side, name, Name, where;
  string gen, att, who, has, tpp;
  object g_ob, targ, ob;
  int dam, rand_dam, maxdam, cost, artlev, ran, yards;
  int xdam, sdmg, randnum, percent, fail, hp;
  if(!str) return; /* this shouldn't happen */
  if(!sscanf(str, "%s %s %s", tpp, att, who)) { return; }
  ob = find_player(tpp);
  if(who == "0") {
    if( !(ob->query_attack()) ) {
      TE(ob,"Who do you want to attack?\n");
      return; }
    who = (ob->query_attack())->query_name();
    }
  who = lower_case(who);
  targ = present(who, environment(ob));
  if(!targ) targ = MEAT; if(!targ) {
    TE(ob,"There is no "+who+" here.\n"); return; }
  /* Because I have asked this to be put in and that request hasnt been complied with
    I have taken th eliberty of adding it.  -mythos <12/5/95>
   DO NOT REMOVE
*/
   if(targ->is_player()) { TE(ob,"You cannot attack "+WHO+".\n"); return; }

/* end of change */

  if(!valid_attack(targ, ob)) {
    if(check_location(ob, targ)) { }
    else {
      TE(ob,"You cannot attack "+WHO+".\n");
      return; }
    }
  if(att == "-----") return;
  has = attackFunc(ob, att, 3, 0);
  if(has != "1") {
    return;}
  g_ob = present("implants", ob);
  if (ob->query_spell_point() < 1) {
    TE(ob,"You are low on power.\n");
    return;}
  gen = ob->query_possessive();
  name = targ->query_name();
  Name = CAP(name);
  yards = (random(7))+10;
  ran = (random(2))+1;
  if(ran == 1) side = "left";
  if(ran == 2) side = "right";
  where = randhit();
  switch(att) {
case "chop":
  TE(ob,"You make a knife-hand and chop "+Name+" "+where+".\n");
  TR(EO,OPN+" makes a knife-hand and chops "+Name+" "+where+".\n");
  dam = 3; cost = 3; break;
case "forearm":
  TE(ob,"You quickly thrust your forearm upwards, snapping "+Name+"'s\n");
  TE(ob,"head painfully backwards.\n");
  TR(EO,OPN+" quickly thrusts "+gen+" forearm upwards, snapping "+Name+"'s\n");
  TR(EO,"head painfully backwards.\n");
  dam = 2; cost = 2; break;
case "finger_jab":
  TE(ob,"You fuse your fingers together and thrust them "+where+
        " of "+Name+".\n");
  TR(EO,OPN+" fuses "+gen+" fingers together and thrusts them "+where+
        " of "+Name+".\n");
  dam = 3; cost = 3; break;
case "palm_flail":
  TE(ob,"With a sudden snapping action, your "+side+" palm hits "+Name+" "+
        where+".\n");
  TR(EO,"With a sudden snapping action, "+OPN+"'s "+side+" palm hits "+Name+" "+

        where+".\n");
  dam = 2; cost = 2; break;
case "quick_punch":
  TE(ob,"You punch "+Name+" "+where+".\n");
  TR(EO,OPN+" punches "+Name+" "+where+".\n");
  dam = 2; cost = 2; break;
case "side_kick":
  TE(ob,"You spin sidewards and kick "+Name+" "+where+".\n");
  TR(EO,OPN+" spins sidewards and kicks "+Name+" "+where+".\n");
  dam = 3; cost = 3; break;
case "reverse_kick":
  TE(ob,"You turn completely around and back-kick "+Name+" "+where+".\n");
  TR(EO,OPN+" turns completely around and back-kicks "+Name+" "+where+".\n");
  dam = 7; cost = 7; break;
case "backfist":
  TE(ob,"You snap your "+side+" wrist and hit "+Name+" "+where+".\n");
  TR(EO,OPN+" snaps "+gen+" "+side+" wrist and hits "+Name+" "+where+".\n");
  dam = 6; cost = 6; break;
case "drop_kick":
  TE(ob,"You acrobatically drop to the ground and kick upwards.\n");
  TE(ob,"You hit "+Name+" "+where+"!\n");
  TR(EO,OPN+" acrobatically drops to the ground and kicks upwards.\n");
  TR(EO,OPN+" hit "+Name+" "+where+"!\n");
  dam = 7; cost = 7; break;
case "front_kick":
  TE(ob,"You kick "+Name+" "+where+"!\n");
  TR(EO,OPN+" kicks "+Name+" "+where+"!\n");
  dam = 7; cost = 7; break;
case "grab":
  TE(ob,"You clench "+Name+" "+where+" and squeeze real hard!\n");
  TR(EO,OPN+" clenches "+Name+" "+where+" and squeezes real hard!\n");
  dam = 6; cost = 6; break;
case "palm_thrust":
  TE(ob,"You thrust out your "+side+" palm with all your bodily might,\n");
  TE(ob,"and hit "+Name+" "+where+"!\n");
  TR(EO,OPN+" thrusts out "+gen+" "+side+" palm with all \n"+
          gen+" bodily might and hits "+Name+" "+where+"!\n");
  dam = 6; cost = 6; break;
case "strong_punch":
  TE(ob,"You smack "+Name+" "+where+" with a mean punch.\n");
  TR(EO,OPN+" smacks "+Name+" "+where+" with a mean punch.\n");
  dam = 7; cost = 7; break;
case "fierce_punch":
  TE(ob,"You punch "+Name+" "+where+" with one hell of a whopper!\n");
  TR(EO,OPN+" punches "+Name+" "+where+" with one hell of a whopper!\n");
  dam = 10; cost = 10; break;
case "head_clap":
  TE(ob,"You smack both your hands right between "+Name+"'s head.\n");
  TR(EO,OPN+" smacks both "+gen+" hands right between "+Name+"'s head.\n");
  dam = 11; cost = 11; break;
case "hook":
  TE(ob,"Bang!, your "+side+" hook hits "+Name+" "+where+"!\n");
  TR(EO,"Bang!, "+OPN+"'s "+side+" hook hits "+Name+" "+where+"!\n");
  dam = 10; cost = 10; break;
case "elbow_jab":
  TE(ob,"You force your "+side+" elbow at "+Name+", "+where+"!\n");
  TR(EO,OPN+" forces "+gen+" "+side+" elbow at "+Name+", "+where+"!\n");
  dam = 10; cost = 10; break;
case "knee":
  TE(ob,"You force your "+side+" knee "+where+" of "+Name+".\n");
  TR(EO,OPN+" forces "+gen+" "+side+" knee "+where+" of "+Name+".\n");
  dam = 11; cost = 11; break;
case "roundhouse":
  TE(ob,"You spin around your "+side+" foot and kick "+Name+" "+
         where+"!\n");
  TR(EO,OPN+" spins around "+gen+" "+side+" foot and kicks "+Name+" "+
         where+"!\n");
  dam = 11; cost = 11; break;
case "thrust_kick":
  TE(ob,"You force all your weight into your kick, and hit\n"+
        ""+Name+" "+where+"!\n");
  TR(EO,OPN+" forces all "+gen+" weight into "+gen+" kick, and hits\n"+
        ""+Name+" "+where+"!\n");
  dam = 11; cost = 11; break;
case "uppercut":
  TE(ob,"You smoothly smack "+Name+" "+where+" with a "+side+
        "uppercut!\n");
  TR(EO,OPN+" smoothly smacks "+Name+" "+where+" with a "+side+
        "uppercut!\n");
  dam = 10; cost = 10; break;
case "head_butt":
  TE(ob,"You head butt "+Name+" "+where+", ouch!\n");
  TR(EO,OPN+" head butts "+Name+" "+where+", ouch!\n");
  dam = 14; cost = 14; break;
case "lock_and_punch":
  TE(ob,"You grapple "+Name+" and connect a solid punch "+where+"!\n");
  TR(EO,OPN+" grapples "+Name+" and connects a solid punch "+where+"!\n");
  dam = 18; cost = 18; break;
case "choke_grab":
  TE(ob,"You grab "+Name+"'s throat and choke like there's no tomorrow!\n");
  TR(EO,OPN+" grabs "+Name+"'s throat and chokes like there's no tomorrow!\n");
  dam = 18; cost = 18; break;
case "headlock":
  TE(ob,"You take "+Name+" in a headlock and start poundin' away!\n");
  TR(EO,OPN+" takes "+Name+" in a headlock and starts poundin' away!\n");
  dam = 14; cost = 14; break;
case "lock_and_twist":
  TE(ob,"You grap "+Name+" "+where+" and twist all the juices out!\n");
  TR(EO,OPN+" graps "+Name+" "+where+" and twists all the juices out!\n");
  dam = 14; cost = 14; break;
case "rapid_fist_strike":
  TE(ob,"You deliver a few thousand fist strikes "+where+" of "+Name+"!!\n");
  TR(EO,OPN+" delivers a few thousand fist strikes "+where+" of "+Name+"!!\n");
  dam = 30; cost = 30; break;
case "rapid_kick":
  TE(ob,"You kick "+Name+" a few times, a few more, and a few more!\n");
  TE(ob,"Whoa, and they all hit "+where+"!\n");
  TR(EO,OPN+" kicks "+Name+" a few times, a few more, and a few more!\n");
  TR(EO,"Whoa, and they all hit "+where+"!\n");
  dam = 18; cost = 18; break;
case "lock_and_elbow":
  TE(ob,"You cleverly lock "+Name+" and force your elbow "+where+"!\n");
  TR(EO,OPN+" cleverly locks "+Name+" and forces "+gen+" elbow "+where+"!\n");
  dam = 24; cost = 24; break;
case "lock_and_throw":
  TE(ob,"With a quick maneuver, you take hold and toss "+Name+" "+
        yards+" yards!\n");
  TR(EO,"With a quick maneuver, "+OPN+" takes hold and tosses "+Name+" "+
        yards+" yards!\n");
  dam = 24; cost = 24; break;
case "bear_hug":
  TE(ob,"You put "+Name+" in a bear hug and squish REAL hard!!\n");
  TR(EO,OPN+" puts "+Name+" in a bear hug and squishes REAL hard!!\n");
  dam = 30; cost = 30; break;
case "over_the_back_slam":
  TE(ob,"You devastate "+Name+" with an OVER THE BACK SLAM!!\n");
  TR(EO,OPN+" devastates "+Name+" with an OVER THE BACK SLAM!!\n");
  dam = 30; cost = 30; break;
case "pressure_point":
  TE(ob,"You strike "+Name+" in a VITAL pressure point!\n");
  TR(EO,OPN+" strikes "+Name+" in a VITAL pressure point!\n");
  dam = 24; cost = 24; break;
    }

  /* Certain places hurt more than others */
  if(where == "right in the kisser") dam = dam + 3;
  if(where == "in the groin") dam = dam + 2;
  if(where == "in the neck") dam = dam + 1;
  if(where == "in the torso") dam = dam - 1;
  if(where == "in the chest") dam = dam - 2;

  artlev = g_ob->query_art_level();
  if(artlev > 16) artlev = 16;
  hp = targ->query_hp();
  if(ob->query_sp() < (4 * cost / 3)) {
	TE(ob, "you become weak and fall flat on your face!\n");
	return 1; }
	if(hp < (dam + 30)) {
    TE(ob, "sequence ended, monster dying :)\n");
    while(remove_call_out("genAttacks") != -1) {
	TE(ob, "removing\n");
	}
}
  if(dam >= hp) {
    TE(ob, "^You pull your blow^\n");
    /* Attacks can never kill a foe */
    return 1; }
  if(ob->query_ghost()) {
    write("Your insubstantial body does not allow physical attacks.\n");
    return 1;
  }
  if(targ->query_ghost()) {
    TE(ob, "Your attack swishes through thin air.\n");
    return 1; }

  randnum = random(100) + 1;
  fail = 100 - ((4 + artlev) * 4);
  if(randnum <= fail) {
    if(random(3) == 1) {
      /* total of 5% to 20% of failure */
      TE(ob, "()You fumble your attack()\n");
      return 1; }
    }
  if(randnum <= (artlev / 2)) {
    /* 0 to 8% chance for special hit */
    TE(ob, "-->You score a ~~SPECIAL~~ hit!\n");
    percent = dam;
    sdmg = (hp * percent) / 100;
    if(sdmg >= hp) return 1;
    if(sdmg > 50) sdmg = 50;
    targ->hit_player(sdmg);
    }

  rand_dam = dam + (artlev * 2);
  maxdam = rand_dam + dam;
  dam += random(rand_dam);
  cost += random(rand_dam);
  if(dam > 50) {
    cost = cost - (dam - 50)/2;  dam = 50; }
  if(maxdam > 50) maxdam = 50;
  if(cost >50) xdam = (cost - 50)/2;

  dam = dam + xdam;

/* ADDED BY MIZAN
 this can go WAY over 50 */
 
  if(dam > S10DAM_CAP) dam = S10DAM_CAP;
  
/* end of changes */ 
 
  call_other(targ,"hit_player", dam);
  call_other(ob, "add_spell_point", -cost);

  if(targ) {
    if(!ob->query_attack()) ob->attack_object(targ);
    if(!targ->query_attack()) targ->attack_object(ob);
    }

  if(dam < (maxdam/4)) {
     TR(EO, Name+" whimpers from the impact.\n");
     return; }
  if(dam < (maxdam/2)) {
     TR(EO, Name+" screams in pain from the impact.\n");
     return; }
  if(dam <= ((maxdam * 3)/4)) {
     TR(EO, Name+" staggers in shock from the strong blow!\n");
     return; }
  if(dam > ((maxdam*3)/4) && dam < maxdam) {
     TR(EO, Name+" is DEVASTATED by "+OPN+"'s hideous attack!\n");
     return; }
  if(dam >= maxdam) {
     TR(EO, OPN+" scores a PERFECT hit!!!\n");
     return; }
}

/* do not remove */

query_s10shell() { return S10DAM_CAP; }
query_s10() { return S10DAM_CAP; }
query_s10_filename() { return S10flag; }
query_s10_serial() { return "879424"; }

string randhit() {
  int a;
  string msg;
  a = random(11) + 1;
  switch(a) {
    case 1:   msg = "right in the kisser"; break;
    case 2:   msg = "in the neck"; break;
    case 3:   msg = "in the groin"; break;
    case 4:   msg = "in the right shoulder"; break;
    case 5:   msg = "in the left shoulder"; break;
    case 6:   msg = "in the chest"; break;
    case 7:   msg = "in the chest"; break;
    case 8:   msg = "in the left leg"; break;
    case 9:   msg = "in the right leg"; break;
    case 10:  msg = "in the torso"; break;
    case 11:  msg = "right in the behind"; break;
    }
  return msg;
}

int check_location(object ob, object targ) {
  if(EO->is_cyberninja_arena() && targ->is_player()) return 1;
  return 0;
}

valid_attack(object ob, object too) {
    int their_level, can_attack;
    string fight_area, name;
    object attacker_ob;
    attacker_ob = ob->query_attack();
    name = ob->query_name();
    if(call_other(ob, "is_player") && !call_other(ob, "query_interactive")) {
     TE(too,"You cannot attack disconnected players.\n");
    return 0;
    }
    if (call_other(ob, "is_player")) {
      if (call_other(ob, "query_level", 0) > 19) {
         if(check_location(too, ob)) return 0;
         TE(too,"You can't attack a wizard!\n");
        return 0;
       }
      if (call_other(too, "query_level", 0) > 19) {
         if(check_location(too, ob)) return 0;
        TE(too,"Wizards cannot attack players!\n");
        return 0;
       }
   }
   if(name=="guest" && !ob->query_npc()) return 0;
    /* If we're already fighting them, then it must be OK. */
   if(ob->query_fight_area() &&
      fight_area == file_name(environment(too))) {
     clear_crime();
     return 1;
     }
    if (ob == attacker_ob) return 1;
    /* They can always attack NPCs */
    if (call_other(ob, "query_npc")) return 1;
    if (call_other(ob, "is_player")) {
        if(check_location(too, ob)) return 0;
        TE(too, "Game rule: guild abilities such as this one\n"+
                 "are not to be used on players.\n");
         return 0; }
  /* Utter novices can't attack any other players */
  return 0;
}

sequenceError() {
  write("To change a position:      seq [#sequence] [attack] [#position]\n");
  write("To clear a position:       seq [#sequence] clear [#position]\n");
  write("To clear entire sequence:  seq [#sequence] clearall\n");
  write("To name your own sequence: seq [#sequence] name [name]\n");
}

attack_seq(string str) {
/* main code for altering attack sequences */
  int seq, pos, maxpos;
  string att, tempatt, place, gen, oldname, name;
  string * arry;
  if(!str) {
    sequenceError();
    return; }
  gen = TP->query_possessive();
  if(!sscanf(str, "%d %s %d", seq, att, pos)) {
    sequenceError();
    return; }
  if(!validSeq(seq)) {
    write("Invalid attack sequence specified.\n");
    write("You do not have attack sequence number "+seq+".\n");
    return; }
  if(sscanf(str, "%d %s", seq, att)) {
    if(att == "clearall") {
       arry = allocate(0);
       attackMaster(seq, arry, 1);
       write("Attack sequence "+seq+" cleared.\n");
       say(TPN+" rethinks "+gen+" plan of attack.\n");
       IP(TP)->save_me();
       update_implants();
       return; } 
    }
  if(sscanf(str, "%d %s %s", seq, att, name)) {
    if(att == "name") {
       if(!sscanf(str, "%d %s %s", seq, att, name)) {
         sequenceError(); return; }
       oldname = attackName(seq, name, 0);
       write("You give a new name to attack sequence #"+seq+".\n");
       if(oldname) write("It used to be named "+oldname+".\n");
       write("It is now known as "+name+"!\n");
       attackName(seq, name, 1);
       IP(TP)->save_me();
       update_implants();
       return; }
    }
  if(sscanf(str, "%d %s %d", seq, att, pos)) {
    tempatt = att;
    if(att != "clear")
      att = attackFunc(TP, att, 1, 0);
    if(!att && att != "clear") {
      write("There is no attack called '"+tempatt+"'.\n");
      return;}
    if(attackFunc(TP, att, 3, 0) == 0) {
      write("You do not have that attack.\n");
      return 1; 
      }
    maxpos = IP(TP)->query_art_level();
    maxpos += 1;
    if(maxpos > 13) maxpos = 13;
    if( (pos > maxpos) || (pos < 1) ) {
      write("Attack position out of range.\n");
      write("Your position range is 1 to "+maxpos+".\n");
      return; }
    if(pos == 1) place = "st";
    if(pos == 2) place = "nd";
    if(pos == 3) place = "rd";
    if(pos > 3)  place = "th";
    arry = attackMaster(seq, arry, 0);
    if(sizeof(arry) == 0) arry = allocate(14);
    /* invariant: arry size is at least 13 */
    if(att == "clear") {
      arry[pos] = "-----";
      attackMaster(seq, arry, 1);
      write(pos+place+" position in attack sequence "+seq+" cleared.\n");
      say(TPN+" thinks upon a "+gen+" plan of attack.\n");
      IP(TP)->save_me();
      update_implants();
      return; }
    arry[pos] = att;
    attackMaster(seq, arry, 1);
    write(pos+place+" position in attack sequence "+seq+
                    " changed to "+att+".\n");
    say(TPN+" alters "+gen+" plan of attack.\n");
    IP(TP)->save_me();
    update_implants();
    return; }
  sequenceError();
}

string * attackMaster(int seq, string * new, int flag) {
/* if flag = 0, just query *
 * if flag = 1, set value  */
string * arry;
  switch(seq) {
    case 1:  if(flag == 0) {
               arry = ((string *)IP(TP)->query_attack_seq1());
               return arry; }
             IP(TP)->set_attack_seq1(new);
             break;
    case 2:  if(flag == 0) {
               arry = ((string *)IP(TP)->query_attack_seq2());
               return arry; }
             IP(TP)->set_attack_seq2(new);
             break;
    case 3:  if(flag == 0) {
               arry = ((string *)IP(TP)->query_attack_seq3());
               return arry; }
             IP(TP)->set_attack_seq3(new);
             break;
    case 4:  if(flag == 0) {
               arry = ((string *)IP(TP)->query_attack_seq4());
               return arry; }
             IP(TP)->set_attack_seq4(new);
             break;
    }
return arry;
}

attackName(int seq, string new, int flag) {
/* flag = 0 is just query */
/* flag = 1 is set */
string name;
switch(seq) {
  case 1: if(flag == 0) {
            name = IP(TP)->query_seq1_name();
            return name; }
          IP(TP)->set_seq1_name(new);
          break;
  case 2: if(flag == 0) {
            name = IP(TP)->query_seq2_name();
            return name; }
          IP(TP)->set_seq2_name(new);
          break;
  case 3: if(flag == 0) {
            name = IP(TP)->query_seq3_name();
            return name; }
          IP(TP)->set_seq3_name(new);
          break;
  case 4: if(flag == 0) {
            name = IP(TP)->query_seq4_name();
            return name; }
          IP(TP)->set_seq4_name(new);
          break;
  }
return name; 
}

int validSeq(int seq) {
  int artlev, allowedSeqs;
  if(seq <= 0) return 0; 
  artlev = ((int)IP(TP)->query_art_level());
  if( (artlev >= 0) && (artlev <= 2) ) allowedSeqs = 1;
  if( (artlev >= 3) && (artlev <= 4) ) allowedSeqs = 2;
  if( (artlev >= 5) && (artlev <= 6) ) allowedSeqs = 3;
  if(artlev >= 7) allowedSeqs = 4;
  if(seq > allowedSeqs) return 0;
  return 1;
}

executeSequence(string str) {
 string * arry;
 object sob;
 string who, name, gen, jumble;
 int seq, i, rnd, counter;
 if(!str) {
   write("Usage: att [#sequence] [target]\n");
   write("You must specify which attack sequence to execute.\n");
   write("You do not need a [target] if already in combat.\n");
   return; }
 gen = TP->query_gender();
 if(gen == "male") gen = "his";
 if(gen == "female") gen = "her";
 if(gen == "creature") gen = "its";
 if(!sscanf(str, "%d %s", seq, who)) { 
   write("Usage: att [#sequence] [target]\n");
   write("You must specify which attack sequence to execute.\n");
   write("You do not need a [target] if already in combat.\n");
   return; }
 if(who) {
   if(!present(who, ENV(TP))) {
     write(WHO+" is not here.\n");
     return; }
     }
 if(!validSeq(seq)) {
   write("Invalid attack sequence specified.\n");
   write("You do not have attack sequence number "+seq+".\n");
   return; }
 arry = attackMaster(seq, arry, 0);
 if(sizeof(arry) == 0) {
   write("Attack sequence "+seq+" is empty.\n");
   return; }
if(present("sequence_check", TP)) {
  if(!TP->query_attack()) { 
    destruct(present("sequence_check", TP)); }
  else {
    write("You are too tired to initiate another attack maneuver.\n");
   return 1; }
   }
  sob = clone_object("/players/dune/closed/guild/objects/sequence_check.c");
  move_object(sob, TP);
  sob->activate(IP(TP)->query_art_level());
 name = attackName(seq, name, 0);
 if(!name) {
   write("Attack sequence "+seq+".\n\n");
   say(TPN+" performs an attack maneuver.\n\n"); }
 else {
   write("Sequence "+seq+" initiated.\n");
   write("You perform your "+name+" maneuver!\n\n");
   say(TPN+" unleashes "+gen+" "+name+" maneuver!\n\n"); }
   for(i = 1; i <= 12; i++) {
     while(!arry[i] && i<=12) { i++; }
     jumble = lower_case(TP->query_name());
     jumble += " "+arry[i]+" "+who;
     rnd = i*3;
     call_out("genAttacks", rnd, jumble);
     }
}


listMySequences(string str) {
  string * arry;
  string name;
  int seq, i, num;
  if(!str) {
    write("Which sequence do you want displayed.\n");
    return; }
  if(!sscanf(str, "%d", seq)) {
    write("Usage: sequence [#sequence]\n");
    return; }
  if(!validSeq(seq)) {
    write("Invalid attack sequence specified.\n");
    write("You do not have attack sequence number "+seq+".\n");
    return; }
  arry = attackMaster(seq, arry, 0);
  if(sizeof(arry) == 0) {
    write("Attack sequence "+seq+" is empty.\n");
    write("Use the 'seq' command to create an attack sequence.\n");
    return; }
  name = attackName(seq, name, 0);
  write(TPN+"'s attack sequence # "+seq+".\n");
  if(name) write("The "+name+" maneuver.\n");
  write("______________________________________________\n");
  write("POSITION\tATTACK\n");
  num = IP(TP)->query_art_level();
  num += 1;
  if(num > 13) num = 13;
  for(i = 1; i <= num; i++) {
    if(arry[i]) {
      write(i+"\t\t"+arry[i]+"\n"); }
    else {
      write(i+"\t\t-----\n"); }
    } 
  write("______________________________________________\n");
}

goToGuild() {
  object here;
  string here_realm;
  here = environment(this_player());
  here_realm = here->realm();
  if(TP->query_spell_point() < 40) {
    write("You cannot atomize yourself, you are too low on power.\n");
    return; }
  if(here_realm == "NT") {
    write("Matter transfer is too dangerous from your location.\n");
    return; }
  say(TPN+"s body vaporizes into nothing.\n");
  move_object(this_player(),
    "/players/dune/closed/guild/rooms/teleport.c");
  write("Your body disintegrates into invisible matter particles.\n");
  write("A magnetic transfer beam sucks you away...\n\n");
  TR("/players/dune/closed/guild/rooms/teleport.c",
    TPN+" transfers in.\n");
  call_other(TP, "add_spell_point", -40);
}

guild_follow1(str) {
  object meat;
  if(!str) {
     write("Follow who?\n");
     return 1; }
  if(!find_player(str)) {
    write(CAP(str)+" is nowhere to be found.\n");
    return 1; }    
  if( !present(str,ENV(TP)) ) {
    write("That player is not in the room.\n");
    return 1; }
  meat = present(str, ENV(TP));
  if(meat->query_level() >= 20) {
    write("You cannot follow deities.\n");
    return 1; }
  IP(TP)->set_gfollow(4);
  IP(TP)->set_follow_ob(str);
  call_other(TP,"add_spell_point",-10);
  write("You begin to follow "+CAP(str)+".\n");
  tell_object(meat, TPN+" begins to follow you.\n");
  call_out("follow_move",4, TP);
  return 1;
}

guild_follow2(str) {
  string targ;
  object meat;
  int num, tmp;
  if(!str || sscanf(str, "%s %s", targ, num) != 2) {
    write("Usage: stalk <player> <time>.\n");
    return 1; }
  targ = lower_case(targ);
  if(!find_player(targ)) {
    write(CAP(targ)+" is nowhere to be found.\n");
    return 1; }    
  if(!PRE(targ,ENV(TP))) {
    write("That player is not in the room.\n");
    return 1; }
  meat = present(targ, ENV(TP));
  if(meat->query_level() >= 20) {
    write("You cannot follow deities.\n");
    return 1; }
  tmp += 10;
  tmp = tmp * -1;
  call_other(TP, "add_spell_point", tmp);
  write("You begin to stalk "+CAP(targ)+".\n");
  sscanf(num, "%d", num);
  num = num + 4;
  IP(TP)->set_gfollow(num);
  IP(TP)->set_follow_ob(targ);
  call_out("follow_move", num, TP);
}

follow_move(object ob) {
  object objective;
  string obname;
  int num;
  if(!FP(IP(ob)->query_follow_ob())) return 1;
  objective = FP(IP(ob)->query_follow_ob());
  obname = objective->query_name();
  if(IP(ob)->query_gfollow() == 0) return 1;
  if(IP(ob)->query_gfollow() == 4) { /* following */
    if( !PRE(objective,ENV(ob)) ) {
      if(ENV(objective)->realm() != "NT" ||
        ENV(objective)->query_srealm() == "shad" ||
         ENV(objective)->query_chaos() == "devour") {
       TR(ENV(ob), CAP(ob->query_name())+" leaves following "+CAP(obname)+"\n");
      move_object(ob, ENV(objective));
      command("look",ENV(IP(ob)));
      TR(ENV(objective), CAP(ob->query_name())+
      " arrives following "+CAP(obname)+".\n");
      }
      }
    call_out("follow_move",4, ob);
    return 1;
    }
  if(IP(ob)->query_gfollow() > 4) { /* stalking */
    num = IP(ob)->query_gfollow();
    if( !PRE(objective,ENV(ob)) ) {
      if(ENV(objective)->realm() != "NT" ||
      ENV(objective)->query_srealm() == "shad" ||
         ENV(objective)->query_chaos() == "devour") {
      move_object(ob, ENV(objective));
      command("look",ENV(IP(ob)));
      }
      }
    call_out("follow_move", num, ob);
    return 1;
    }
}

follow_off() {
  int follownum;
  string followed;
  follownum = IP(TP)->query_gfollow();
  followed = IP(TP)->query_follow_ob();
  if(follownum == 0) {
    write("You are not following anyone.\n");
    return 1;
    }
  if(follownum == 1) {
    IP(TP)->set_gfollow(0);
    write("You stop following "+CAP(followed)+".\n");
    tell_object(FP(followed),TPN+" stops following you.\n");
    }
  if(follownum > 1) {
    IP(TP)->set_gfollow(0);
    write("You stop stalking "+CAP(followed)+".\n");
    return 1;
    }
}

auto(string str) {
  /* sets the following automatics */
  if(!str) {
    write("Usage: auto [on/off]\n");
    return; }
  if(str == "on") {
    IP(TP)->set_auto(1);
    write("Your automatics are now on.\n");
    IP(TP)->save_me();
    IP(TP)->update_implants();
    return; }
  if(str == "off") {
    IP(TP)->set_auto(0);
    write("Your automatics are now off.\n");
    IP(TP)->save_me();
    IP(TP)->update_implants();
    return; }
  write("Usage: auto [on/off]\n"); 
}

mon() {
/* combat monitor */
  if(IP(TP)->query_hpmon()) {
    IP(TP)->set_hpmon(0);
    write("Your combat moniter is now off.\n");
    return 1; }
  if(IP(TP)->query_hpmon() == 0) {
    write("You turn on your combat moniter.\n");
    IP(TP)->set_hpmon(1);
     IP(TP)->fake_beat(1);
    return 1; }
}

combat_monitor(object ob) {
  object targ;
  string tgname, mybar, tgbar, myiter, tgiter;
  int mymhp, tgmhp, mysp, mymsp, myhp, tghp, i,
      mypercent, tgpercent, myspace, tgspace;
  if(ob) {
    myhp = ob->query_hp();
    mymhp = ob->query_mhp();
    mysp = ob->query_sp();
    mymsp = ob->query_msp();
    if(ob->query_attack()) {
      targ = ob->query_attack();
      tghp = targ->query_hp();
      tgmhp = targ->query_mhp();
      tgpercent = (tghp * 100) / tgmhp;
    }
    TE(ob,"==PHYSICAL <>"+myhp+"/"+mymhp+"<>");
    TE(ob,"==ENERGY <>"+mysp+"/"+mymsp+"<>");
    if(targ) TE(ob,"==OPPONENT <>"+tgpercent+"%<>");
    TE(ob,"\n");
    if(targ && ENV(targ) == ENV(ob)) {
      if(myhp <= IP(ob)->query_wimpy_hp()) {
        ob->run_away();
         if(IP(TP)->query_gfollow()) {
           IP(TP)->set_gfollow(0);
          TE(ob,"Guild follow turned off.\n");
        }
      }
    }
    return 1;
  }
  if(ob->query_attack()) {
    targ = ob->query_attack();
    tgname = capitalize(targ->query_name());
    myhp = ob->query_hp();
    tghp = targ->query_hp();
    mymhp = ob->query_mhp();
    tgmhp = targ->query_mhp();
    mysp = ob->query_spell_point();
    mymsp = ob->query_msp();
    if(tghp < 0) tghp = 1;
    if(myhp < 0) myhp = 1;
    if(tgmhp > 0) tgpercent = (tghp * 100) / tgmhp;
    if(mymhp > 0) mypercent = (myhp * 100) / mymhp;
    mybar = moniterReading(mypercent, ob, 0);
    myiter = moniterReading(mypercent, ob, 1);
    sscanf(myiter, "%d", myspace);
    tgbar = moniterReading(tgpercent, ob, 0);
    tgiter = moniterReading(tgpercent, ob, 1);
    sscanf(tgiter, "%d", tgspace);
    if(targ->query_invis()) tgbar = "unseen opponent";

    TE(ob, "\n");
    TE(ob, pad("          ", 10));
    TE(ob, pad(tgname, 22));
    TE(ob, pad("     ", 5));
    TE(ob, "YOU\n");
    TE(ob, pad("     ", 5));
    TE(ob, ""+OFF+"{"+END+"");
    TE(ob, tgbar);
    for(i = 1; i <= tgspace; i++) TE(ob, " ");
    TE(ob, ""+OFF+"}"+END+"");
    TE(ob, pad("          ", 10));
    TE(ob, ""+OFF+"{"+END+"");
    TE(ob, mybar);
    for(i = 1; i <= myspace; i++) TE(ob, " ");
    TE(ob, ""+OFF+"}"+END+"\n");
    TE(ob, pad("", 37));
    TE(ob, "Energy: "+mysp+"/"+mymsp+"\n");

  if(myhp <= IP(ob)->query_wimpy_hp()) ob->run_away();

    return 1; }
 return 1;
}

string moniterReading(int percent, object ob, int flag) {
  string bar, spcs;
  int colorstatus;
  colorstatus = ((int)present("implants",ob)->query_color());
  if(colorstatus) {
  switch(percent) {
case 0..5:   bar = BLINK+RED+">"; spcs = "19"; break;
case 6..10:  bar = BLINK+RED+">>";  spcs = "18"; break;
case 11..15: bar = BLINK+RED+">>>";  spcs = "17"; break;
case 16..20: bar = BLINK+RED+">>>>";  spcs = "16"; break;
case 21..25: bar = YELLOW+">>>>>";  spcs = "15"; break;
case 26..30: bar = YELLOW+">>>>>>";  spcs = "14"; break;
case 31..35: bar = YELLOW+">>>>>>>";  spcs = "13"; break;
case 36..40: bar = YELLOW+">>>>>>>>";  spcs = "12"; break;
case 41..45: bar = YELLOW+">>>>>>>>>";  spcs = "11"; break;
case 46..50: bar = GREEN+">>>>>>>>>>";  spcs = "10"; break;
case 51..55: bar = GREEN+">>>>>>>>>>>";  spcs = "9"; break;
case 56..60: bar = GREEN+">>>>>>>>>>>>";  spcs = "8"; break;
case 61..65: bar = GREEN+">>>>>>>>>>>>>";  spcs = "7"; break;
case 66..70: bar = GREEN+">>>>>>>>>>>>>>";  spcs = "6"; break;
case 71..75: bar = GREEN+">>>>>>>>>>>>>>>";  spcs = "5"; break;
case 76..80: bar = GREEN+">>>>>>>>>>>>>>>>";  spcs = "4"; break;
case 81..85: bar = GREEN+">>>>>>>>>>>>>>>>>";  spcs = "3"; break;
case 86..90: bar = GREEN+">>>>>>>>>>>>>>>>>>";  spcs = "2"; break;
case 91..95: bar = GREEN+">>>>>>>>>>>>>>>>>>>";  spcs = "1"; break;
case 96..100: bar = GREEN+">>>>>>>>>>>>>>>>>>>>";  spcs = "0"; break;
    } 
  }

  else {
  switch(percent) {
case 0..5:   bar = ">"; spcs = "19"; break;
case 6..10:  bar = ">>"; spcs = "18"; break;
case 11..15: bar = ">>>"; spcs = "17"; break;
case 16..20: bar = ">>>>"; spcs = "16"; break;
case 21..25: bar = ">>>>>"; spcs = "15"; break;
case 26..30: bar = ">>>>>>"; spcs = "14"; break;
case 31..35: bar = ">>>>>>>"; spcs = "13"; break;
case 36..40: bar = ">>>>>>>>"; spcs = "12"; break;
case 41..45: bar = ">>>>>>>>>"; spcs = "11"; break;
case 46..50: bar = ">>>>>>>>>>"; spcs = "10"; break;
case 51..55: bar = ">>>>>>>>>>>"; spcs = "9"; break;
case 56..60: bar = ">>>>>>>>>>>>"; spcs = "8"; break;
case 61..65: bar = ">>>>>>>>>>>>>"; spcs = "7"; break;
case 66..70: bar = ">>>>>>>>>>>>>>"; spcs = "6"; break;
case 71..75: bar = ">>>>>>>>>>>>>>>"; spcs = "5"; break;
case 76..80: bar = ">>>>>>>>>>>>>>>>"; spcs = "4"; break;
case 81..85: bar = ">>>>>>>>>>>>>>>>>"; spcs = "3"; break;
case 86..90: bar = ">>>>>>>>>>>>>>>>>>"; spcs = "2"; break;
case 91..95: bar = ">>>>>>>>>>>>>>>>>>>"; spcs = "1"; break;
case 96..100: bar = ">>>>>>>>>>>>>>>>>>>>"; spcs = "0"; break;
    } 
  }

    if(percent < 0) bar = "";
    if(percent > 100) bar = "off the scale";
    if(flag == 1) return spcs;
    return bar;
}

wear(string str) {
/* ninjas are only able to wear light armor */
  object ob;
  if(!str) {
    write("Wear what?\n");
    return 0;
    }
  if(!present(str, TP)) {
    write("You do not have a "+str+" to wear.\n");
    return 1; }
  ob = present(str, TP);
  if(ob->query_weight() > 3) {
    write("You cannot wear such heavy and restricting armor.\n");
    return 1; }
  call_other(ob, "wear", str);
}

color() {
  if(IP(TP)->query_color() == 1) {
    write("Color is now off.\n");
    IP(TP)->set_color(0);
    IP(TP)->save_me();
    update_implants();
    return; }
  write("Color is now on.\n");
  IP(TP)->set_color(1);
  IP(TP)->save_me();
  update_implants();
  return;
}

mislead(string str) {
  string * exits;
  int size, rand;
  if(!str) {
    write("Usage: mislead <player>\n");
    return 1;}
  if(!find_player(str)) {
    write("You can only mislead players.\n");
    return 1;}
  /*if(find_player(str)->query_level() > 19) { */  
  /* change made by mythos , authorized by mizan */
  if((this_player()->query_level()) < (find_player(str)->query_level()) ) {
    write("You seem unable to affect that type of cyberspace.\n");
    return 1; }
  if(!present(str, ENV(TP))) {
    write(STR+" is not here.\n");
    return 1; }
  exits = ENV(TP)->query_dest_dir();
  if(!exits) {
    write("There is no place to mislead "+STR+".\n");
    return 1;}
  size = sizeof(exits);
  if(!random(size)) {
    write("Your misdirection has failed.\n");
    return 1; }
  rand = random(size);
  write("You mislead "+STR+" "+exits[rand]+"\n");
  command(exits[rand], find_player(str));
  TE(find_player(str), "You have been misled.\n");
  return 1;
}

/* removed 5/29/95 for reason that players may lead
   newbies into wastelands.
guide(string str) {
  string place, who;
  string * exits;
  object ob;
  int size, i;
  if(!str) {
    write("Usage: guide <player> <direction>\n");
    return 1;}
  if(!sscanf(str, "%s %s", who, place)) {
    write("Usage: guide <player> <direction>\n");
    return 1;}
  if(!find_player(who)) {
    write("You can only guide players.\n");
    return 1;}
  ob = find_player(who);
  if(ob->query_level() > 19) {
    write("You seem unable to affect that type of cyberspace.\n");
    return 1; }
  exits = ENV(TP)->query_dest_dir();
  if(!exits) {
    write("There is no place to guide "+WHO+".\n");
    return 1;}
  size = sizeof(exits);
  size = size - 1;
  for(i = 0; i <= size; i++) {
   if(exits[i]) {
    if(place == exits[i]) {
      command(exits[i], ob);
      write("You guide "+WHO+" "+exits[i]+"\n");
      TE(ob, TPN+" guides you "+exits[i]+".\n");
      return 1;
      }
     }
    }
  write("You were unable to guide "+WHO+" "+place+".\n");
  return 1;
}
*/

score() {
  int plev, ptox, ptuf, psok;
  int gbal, gwim;
plev = TP->query_level();
ptox = TP->query_intoxination();
ptuf = TP->query_stuffed();
psok = TP->query_soaked();
gbal = IP(TP)->balance();
gwim = IP(TP)->query_wimpy_hp();
  write(TP->short()+"\n");
  write(pad("Level: "+TP->query_level(), 32));
  write("Extra Level: "+TP->query_extra_level()+"\n");
  write(pad("Coins: "+TP->query_money(), 32));
  write("Experience: "+TP->query_exp()+"\n");
  write("Credits: "+gbal+"\n");
  write(pad("Hit Points: "+
         TP->query_hp()+"/"+TP->query_mhp(), 32));
  write("Energy: "+
         TP->query_sp()+"/"+TP->query_msp()+"\n");
  write("Quest points: "+TP->query_quest_point()+"\n");
  TP->show_age();
  write("Time (CST): "+ctime(time())+"\n");
if(TP->query_wimpy()) 
  write("Wimpy mode.\n");
else
  write("Brave Mode\n");
  write("Wimpy set at: "+gwim+"\n\n");
  write("Intox ["+(ptox*100)/(plev+3)+"%]   "+
        "Soak ["+(psok*100)/(plev*8)+"%]   "+
        "Stuff ["+(ptuf*100)/(plev*8)+"%]\n\n");
  return 1;
}

bwho() {
  object * all;
  object opp;
  int i, total, hp, mhp;
  string statss;
  all = users();
  write("Player          Opponent            Opp's Health     Location.\n");
  write("____________________________________________________________________\n");
  for(i=0; i < sizeof(all); i++) {
    if(all[i]->query_attack()) {
      opp = all[i]->query_attack();
      write(pad(capitalize(all[i]->query_name()), 16));
      write(pad(opp->query_name(), 20));
      hp = opp->query_hp();
      mhp = opp->query_mhp();
      statss = "good shape";
      if(hp < mhp - 20) statss = "slightly hurt";
      if(hp < mhp/2) statss = "somewhat hurt";
      if(hp < mhp/5) statss = "bad shape";
      if(hp < mhp/10) statss = "very bad shape";
      if(hp < mhp/20) statss = "verge of death";
      write(" ");
      write(pad(statss, 16));
      write(ENV(opp)->short()+"\n");
      total += 1;
      }
    }
  if(total == 0) write("Nobody is in battle.\n");
  write("____________________________________________________________________\n");
  return 1; 
}

new_start() {
  if(TP->query_home() == "/room/church.c" || 
     TP->query_home() == "room/church.c"  ||
     TP->query_home() == "/room/church"   ||
     TP->query_home() == "room/church"    ) {
     call_other(TP,"set_home","/players/dune/closed/guild/rooms/guildhall.c");
     TP->save_me();
     write("You will now start in CyberNinja Grand Hall.\n");
     return 1; }
  write("You will now start in the Church.\n");
  call_other(TP,"set_home","/room/church.c");
  TP->save_me();
  return 1;
}

wimpy_set(str) {
  int desired;
  if(!str) {
    write("Usage: wimpyset <number>\n");
    return 1; }
  if(sscanf(str,"%d",desired) != 1) {
    write("Usage: wimpyset <number>\n");
    return 1;                       }
  IP(TP)->set_wimpy_hp(desired);
  write("Your wimpy is set at ["+desired+"].\n"+
        "It will only work when your moniter is on.\n");
  IP(TP)->save_me();
  return 1;
}

lead() {
  object ob;
  if(TP->query_spell_point() < 10) {
    write("You are too drained to do this.\n");
    return 1; }
  if(!TP->query_attack()) {
    write("You cannot lead a fight when not in combat.\n");
    return 1; }
  ob = TP->query_attack();
  TP->add_spell_point(-10);
  ob->attack_object(TP);
  TP->attack_object(ob);
  write("You boldly step into the heat of the battle!\n");
  say(TPN+" boldy steps into the heat of the battle!\n");
  return 1;
}

all_who()  {
int b, level, pk;
string gname, gen, room;
object * ob;
ob = users();

write("\n");
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");
  write("Player        Level    Guild       Pk   Gender   Location\n");
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
      "~~~~~~~~~~~~~\n");

for(b=0;b<sizeof(ob);b+=1)  {
 if(ob[b]->query_invis() <= this_player()->query_level()) {
   level = ob[b]->query_level();
   gname = ob[b]->query_guild_name();
   pk = ob[b]->query_pl_k();
   gen = ob[b]->query_gender();
   if(environment(ob[b]))
   room = environment(ob[b])->short();
   else room = "unknown";
   write(pad(CAP(ob[b]->query_name()),15)); write(" ");
   if(level >= 10000) write(pad("GOD",5));
   else write(pad(level,5));
   write(" ");
   if(gname) write(pad(gname, 13));
   else write(pad("none", 13));
   if(pk) write(pad("yes", 4));
   else write(pad("no", 4));
   write(pad(gen, 9));
   write(room);
   write("\n");
   }
 }
 write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+
       "~~~~~~~~~~~~~~~\n\n");
return 1;
}

ninja_speak(str) {
   /* ability to speak own guild language */
   object ob;
   ob = first_inventory(ENV(TP));
   while(ob) {
      if(IP(ob) && ob != TP)
          tell_object(ob, TPN+" elates: "+str+"\n");
      else if(ob != TP) tell_object(ob, "You hear quiet voices in the room.\n");
      ob = next_inventory(ob);
   }
   write("You elate: "+str+"\n");
   return 1;
}

align(int align) {
  int num;
  int alignment;
  if(!align) alignment = 0;
  else sscanf(align, "%d", alignment);
  num = TP->query_alignment();
  if(alignment > 1500 || alignment < -1500) {
    write("You cannot set your alignment to such extremes!\n");
  return 1;
  }
  if ((num > 1000) && (alignment < 0)) {
    write("Your alignment too far fetched.\n");
    return 1; }
  if ((num < -1000) && (alignment > 0)) {
    write("Your alignment too far fetched.\n");
    return 1; }
  TP->add_alignment(alignment);
  write("You have changed your alignment.\n");
  return 1;
}

mask(string align) { 
  TP->set_al_title(align);
  write("You mask your alignment to "+align+".\n");
  return 1;  
}

hide_in_shadows() {
  /* command to hide in shadows */
  object ob;
  if(present("_drivers_seat_",
     environment(this_player()))) {
    write("You are already hiding in shadows.\n");
    return 1; }
/* ADDED BY MIZAN
   this abil is etechnically a free teleport. I spoke to your guilders
  and struck up a compromise. DO NOT undo changes.
  input from mythos was very helpful.
 */

/* NT check added */
  if(this_player()->query_level() > 20) {
  write("This ability has been removed for the moment.\n"+
  "read mizan's note on the board for more info.\n");
   return 1;
}

  if(environment(this_player())->realm() == "NT") {
    write("Your sensitive space notices a wrongness in mind [tm].\n");
    return 1;
  }

  if(this_player()->query_attack()) {
    if(this_player()->query_spell_point() < 60) {
      write("You feel too drained to attempt this.\n");
      return 1;
    } 
    this_player()->add_spell_point(-60);
  } else {
   if(this_player()->query_spell_point() < 30) {
    write("You feel too weak to hide in shadows.\n");
    return 1;
   }
   this_player()->add_spell_point(-30);
  }
 /* end of changes */
  ob = clone_object(
       "/players/dune/closed/guild/objects/hide.c");
  move_object(ob, environment(this_player()));
  if(!TP->query_invis()) {
    say(TP->query_name()+" disappears into the shadows.\n");
  }
  move_object(this_player(), ob);
  write("You hide in shadows.\n");
  write("For info, type 'look at shadows'.\n");
  return 1;
}




/* ENHANCEMENT CODE */
cyberware() {
  /* method for players to see enhancement info */
  TE(TP, "You take out your handy CyberWare Manual.\n");
  move_object(clone_object(
    "/players/dune/closed/guild/objects/cyberware_manual.c"),
    this_player());
  say(TPN+" takes out a thick manual.\n");
  return 1; 
}

string gen(object ob) {
  /* Not an enhancement.  This just calculates possessive */
  string gender, gen;
  gender = ((string)ob->query_gender());
  switch(gender) {
    case "male": gen = "his"; break;
    case "female": gen = "her"; break;
    case "creature": gen = "its"; break;
    }
  return gen;
}

corpse() {
  object ob;
  ob = present("corpse",ENV(TP));
  if(!ob) {
    write("There is no corpse here!\n");
    return 1; }
  call_other(TP,"heal_self",ob->heal_value());
  write("You dismember a corpse and burn it for fuel.\n");
  say(TPN+" dismembers a corpse and burns it for fuel.\n");
destruct(ob);
return 1;
}

regenerate() {
  if(remove_call_out("regeneration") != -1) {
    write("You stop the regeneration process.\n");
    return 1;                               }
  if(remove_call_out("rejuvenation") != -1) {
    write("You stop the rejuvenation process.\n"); }
  call_out("regeneration", 0, TP);
  write("Your molecules recombine and begin regeneration.\n");
  TR(TP, TPN+"'s molecules recombine and begin regenerating.\n");
  return 1; }

rejuvenate() {
  if(remove_call_out("rejuvenation") != -1) {
    write("You stop the rejuvenation process.\n");
    return 1;                               }
  if(remove_call_out("regeneration") != -1) {
    write("You stop the regeneration process.\n"); }
  call_out("rejuvenation", 0, TP);
  write("Your molecules burn and begin releasing energy.\n");
  TR(TP, TPN+"'s molecules burn and begin releasing energy.\n");
  return 1; }

regeneration(object ob) {
  int level, value, delay;
  level = IP(ob)->guild_lev();
  if(level > 12) level = 12;
  value = level / 3;
  delay = 4 - value;
  if(ob->query_sp() < (value * 2)) {
    TE(ob, "You have no more energy to continue regeneration.\n");
    TE(ob, "Regeneration terminated...\n");
    return 1; }
  if(ob->query_hp() >= ob->query_mhp()) {
    TE(ob, "You have fully regenerated.\n");
    TE(ob, "Regeneration terminated...\n");
    return 1; }
  ob->add_hit_point(value);              /* up to 4 hp healed */
  ob->add_spell_point(-(value));     /* up to 4 sp drained */
  TE(ob, "Regenerating...\n");
  call_out("regeneration", delay, ob);   /* delayed healing */
}

rejuvenation(object ob) {
  int level, value, delay;
  level = IP(ob)->guild_lev();
  if(level > 12) level = 12;
  value = level / 3;
  delay = 4 - value;
  if(ob->query_hp() < 10) {
    TE(ob, "You are too weak to continue rejuvenation.\n");
    TE(ob, "Rejuvenation terminated...\n");
    return 1; }
  if(ob->query_sp() >= ob->query_msp()) {
    TE(ob, "You have fully rejuvenated.\n");
    TE(ob, "Rejuvenation terminated...\n");
    return 1; }
  ob->add_spell_point(value);            /* up to 4 sp healed */
  ob->add_hit_point(-(value));       /* up to 4 hp drained */
  TE(ob, "Rejuvenating...\n");
  call_out("rejuvenation", delay, ob);   /* delayed healing */
}

electricflux(string who) { 
  /* concentrated dmg enhancement */
  object ob;
  int dmg;
  if(!who) {
    if(!TP->query_attack()) {
      write("Usage: eflux <target>\n");
    return 1;
    }
  else ob = TP->query_attack();
  }
  if(who) {
    if(!present(who, ENV(TP))) {
      write("There is no "+capitalize(who)+" here.\n");
    return 1;
    }
  else ob = present(who,ENV(TP));
  }
  if(ob->query_ghost()) {
    write("Your target is already dead.\n");
    return 1; }
  if(!ob->query_npc() && !check_location(TP,ob)) {
    write("You cannot flux that!\n"); return 1; }
  if(TP->query_spell_point() < 40) {
    write("Your energy reserves are too low.\n");
    return 1; }
  if(TP->query_attrib("wil") + IP(TP)->guild_lev()/2 + 1 < random(25)) {
    write("Your flux generator backfires!\n");
    if(TP->query_attrib("ste") < random(25)) {
      write("Electricity crackles through your body!\n");
       TP->hit_player(random(IP(TP)->guild_lev()) + 1); }
    TP->add_spell_point(-(random(20)));
  return 1;
  }
  
  dmg = IP(TP)->guild_lev();
  dmg = dmg * 2;
  dmg = dmg + 10;
  dmg = random(20) + dmg;
  if(dmg > 45) dmg = 45;
  TR(ET,
"                  |        \n"+
"                  |        \n"+
"                  |        \n"+
"          - -- ---*--- -- -\n"+
"                  |        \n"+
"                  |        \n"+
"                  |        \n");
  TR(ET, TPN+" releases a burst of electric flux into "+OPN+"\n\n");
 ob->hit_player(dmg);
  TP->add_spell_point(-(random(dmg) + random(20)));
  if(ob) {
    if(!ob->query_attack()) ob->attack_object(TP);
    if(!TP->query_attack()) TP->attack_object(ob);
    }
  return 1;
}

magneticflux(string who) { 
  /* concentrated dmg enhancement */
  object ob;
  int dmg;
  if(!who) {
    if(!TP->query_attack()) {
      write("Usage: mflux <target>\n");
    return 1;
    }
  else ob = TP->query_attack();
  }
  if(who) {
    if(!present(who, ENV(TP))) {
      write("There is no "+capitalize(who)+" here.\n");
    return 1;
    }
  else ob = present(who,ENV(TP));
  }
  if(ob->query_ghost()) {
    write("Your target is already dead.\n");
    return 1; }
  if(!ob->query_npc() && !check_location(TP,ob)) {
    write("You cannot flux that!\n"); return 1; }
  if(TP->query_spell_point() < 40) {
    write("Your energy reserves are too low.\n");
    return 1; }
  if(TP->query_attrib("wil") + IP(TP)->guild_lev()/2 + 1 < random(25)) {
    write("Your flux generator backfires!\n");
    if(TP->query_attrib("ste") < random(30)) {
      write("Magnetic energy fries your links!\n");
       TP->hit_player(random(IP(TP)->guild_lev()) + 1); }
    TP->add_spell_point(-(random(20)));
  return 1;
  }
  dmg = IP(TP)->guild_lev();
  dmg = dmg * 2;
  dmg = dmg + 10;
  dmg = random(20) + dmg;
  if(dmg > 45) dmg = 45;
  TR(ET, "||||||||||\n");
  TR(ET, "||||||||||||||||||||\n");
  TR(ET, "||||||||||||||||||||||||||||||||||||||||\n");
  TR(ET, TPN+" releases a burst of magnetic flux into "+OPN+"\n");
  TR(ET, "||||||||||||||||||||||||||||||||||||||||\n");
  TR(ET, "||||||||||||||||||||\n");
  TR(ET, "||||||||||\n");
 ob->hit_player(dmg);
  TP->add_spell_point(-(random(dmg) + random(20)));
  if(ob) {
    if(!ob->query_attack()) ob->attack_object(TP);
    if(!TP->query_attack()) TP->attack_object(ob);
    }
  return 1;
}

heatflux(string who) { 
  /* concentrated dmg enhancement */
  object ob;
  int dmg;
  if(!who) {
    if(!TP->query_attack()) {
      write("Usage: hflux <target>\n");
    return 1;
    }
  else ob = TP->query_attack();
  }
  if(who) {
    if(!present(who, ENV(TP))) {
      write("There is no "+capitalize(who)+" here.\n");
    return 1;
    }
  else ob = present(who,ENV(TP));
  }
  if(ob->query_ghost()) {
    write("Your target is already dead.\n");
    return 1; }
  if(!ob->query_npc() && !check_location(TP,ob)) {
    write("You cannot flux that!\n");  return 1; }
  if(TP->query_spell_point() < 40) {
    write("Your energy reserves are too low.\n");
    return 1; }
  if(TP->query_attrib("wil") + IP(TP)->guild_lev()/2 + 1 < random(25)) {
    write("Your flux generator backfires!\n");
    if(TP->query_attrib("ste") < random(30)) {
      write("Built-up heat makes your skin smoke and burn!\n");
       TP->hit_player(random(IP(TP)->guild_lev()) + 1); }
    TP->add_spell_point(-(random(20)));
  return 1;
  }
  dmg = IP(TP)->guild_lev();
  dmg = dmg * 2;
  dmg = dmg + 10;
  dmg = random(20) + dmg;
  if(dmg > 45) dmg = 45;
  if(dmg > ob->query_hp()) dmg = ob->query_hp() -1;
  TR(ET,
"    ff                           f                     \n"+
"   ff        f                   ff         f     f    \n"+
"   ff        f        f         fff        f     ff    \n"+
"   fff      ff        f        fffff       ff    ffff  \n");
  TR(ET, TPN+" releases a burst of heat flux into "+OPN+"\n\n");
 ob->hit_player(dmg);
  TP->add_spell_point(-(random(dmg) + random(20)));
  if(ob) {
    if(!ob->query_attack()) ob->attack_object(TP);
    if(!TP->query_attack()) TP->attack_object(ob);
    }
  return 1;
}

speed_run() {
  /* way for players to clone up their speedters */
  if(present("leg actuators",TP)) {
    write("Your leg actuators are already activated.\n");
    return 1;
  }
  move_object(clone_object("/players/snow/closed/speed.c"),
              this_player());
  TE(TP, "You have activated your leg actuators.\n");
  tell_room(environment(TP), TPN+"'s leg muscles tense up.\n"+
           "____________________ __________ _____ ___ __ _\n");
  return 1;
}

flash() {
  /* light spell enhancement */
  int time;
  string name;
  mixed jumble;
  time = present("implants",TP)->guild_lev();
  time = time * 20;
  time = time + 10;
  if(TP->query_spell_point() < 2) {
    write("You are too drained to do this.\n");
    return 1; }
  write("Glowing liquid courses through your veins.\n");
  write("Your body glows with an inner flourescent light.\n");
  say("Glowing liquid courses through "+TPN+"'s veins.\n");
  say(TPN+"'s body glows with an inner flourescent light.\n");
  IP(TP)->do_light(1);
  TP->add_spell_point(-2);
  name = lower_case(TP->query_real_name());
  jumble = name+" "+time;
  call_out("stop", 1, jumble);
  return 1;
}

stop(mixed jumble) {
  string name;
  object ob;
  int time;
  sscanf(jumble, "%s %d", name, time);
  ob = find_player(name);
  time -= 1;
  if(time > 0) {
     jumble = name+" "+time;
     call_out("stop", 1, jumble);
     return 1; }
  TE(ob, "Your bodily glow fades away.\n");
  TE(ENV(ob), capitalize(ob->query_name())+
              "'s bodily glow fades.\n"+
              "The room light dims.\n");
  IP(TP)->do_light(-1);
  return 1;
}

lastic() {
  /* added ac enhancement, only during combat */
  int prot, ac, temp;
  string name;
  mixed jumble;
  if(TP->query_spell_point() < 30) {
    write("The lastic armor needs more juice than you have.\n");
    return 1; }
  if(present("armortypeB", TP)) {
    write("You already powered up your lastic armor.\n");
    return 1; }
  move_object(clone_object("/players/dune/closed/guild/enhance/armorB.c"),
              TP);
  prot = present("implants",TP)->guild_lev();
  if(prot > 12) prot = 12;
  prot = prot / 4;
  if(prot <= 0) prot = 1;
  ac = TP->armor_class(); 
  temp = ac + prot;
  if(ac >= 12) {
    write("Your armor is maxed out!\n");
    return 1; }
  if(temp > 12) {
    temp = temp - 12; 
    prot = prot - temp; }
  if(prot < 0) prot = 0;
  TP->add_spell_point(-30);
  write("You power on your superlastic armor.\n");
  write("You hear the solidifying of liquid.\n");
  say("You hear the solidifying of liquid.\n");
  say(TPN+" powers up "+GEN+" superlastic armor.\n");
  TP->add_ac(prot);
  name = lower_case(TP->query_real_name());
  jumble = name+" "+prot;
  call_out("powerOn", 1, jumble);
  return 1;
}

meld() {
  /* added ac enhancement, only during combat */
  int prot, ac, temp;
  string name;
  mixed jumble;
  if(TP->query_spell_point() < 30) {
    write("The meld armor needs more juice than you have.\n");
    return 1; }
  if(present("armortypeB", TP)) {
    write("You already powered up your meld armor.\n");
    return 1; }
  move_object(clone_object("/players/dune/closed/guild/enhance/armorB.c"),
              TP);
  prot = present("implants",TP)->guild_lev();
  if(prot > 12) prot = 12;
  prot = prot / 4;
  if(prot <= 0) prot = 1;
  ac = TP->armor_class();
  temp = ac + prot;
  if(ac >= 12) {
    write("Your armor is maxed out!\n");
    return 1; }
  if(temp > 12) {
    temp = temp - 12; 
    prot = prot - temp; }
  if(prot < 0) prot = 0;
  if(TP->query_ac() < 9) TP->add_spell_point(-30);
  write("You power on your enduro meld.\n");
  write("You hear the sound of twisting metal.\n");
  say("You hear the sound of twisting metal.\n");
  say(TPN+" powers up "+GEN+" enduro meld armor.\n");
  TP->add_ac(prot);
  name = lower_case(TP->query_real_name());
  jumble = name+" "+prot;
  call_out("powerOn", 1, jumble);
  return 1;
}

plate() {
  /* added ac enhancement, only during combat */
  int prot, ac, temp;
  string name;
  mixed jumble;
  if(TP->query_spell_point() < 30) {
    write("The pressure armor needs more juice than you have.\n");
    return 1; }
  if(present("armortypeB", TP)) {
    write("You already powered up your pressure armor.\n");
    return 1; }
  move_object(clone_object("/players/dune/closed/guild/enhance/armorB.c"),
              TP);
  prot = present("implants",TP)->guild_lev();
  if(prot > 12) prot = 12;
  prot = prot / 4;
  if(prot <= 0) prot = 1;
  ac = TP->armor_class();
  temp = ac + prot;
  if(ac >= 12) {
    write("Your armor is maxed out!\n");
    return 1; }
  if(temp > 12) {
    temp = temp - 12; 
    prot = prot - temp; }
  if(prot < 0) prot = 0;
  if(TP->query_ac() < 9) TP->add_spell_point(-30);
  write("You power on your pressure plate.\n");
  write("Your pressure plates bend under pressure.\n");
  write(TPN+"'s pressure plates bend under pressure.\n");
  say(TPN+" powers up "+GEN+" pressure plate.\n");
  TP->add_ac(prot);
  name = lower_case(TP->query_real_name());
  jumble = name+" "+prot;
  call_out("powerOn", 1, jumble);
  return 1;
}

hide() {
  /* added ac enhancement, only during combat */
  int prot, ac, temp;
  string name;
  mixed jumble;
  if(TP->query_spell_point() < 30) {
    write("The hide armor needs more juice than you have.\n");
    return 1; }
  if(present("armortypeB", TP)) {
    write("You already powered up your metal hide.\n");
    return 1; }
  move_object(clone_object("/players/dune/closed/guild/enhance/armorB.c"),
              TP);
  prot = present("implants",TP)->guild_lev();
  if(prot > 12) prot = 12;
  prot = prot / 4;
  if(prot <= 0) prot = 1;
  ac = TP->armor_class();
  temp = ac + prot;
  if(ac >= 12) {
    write("Your armor is maxed out!\n");
    return 1; }
  if(temp > 12) {
    temp = temp - 12; 
    prot = prot - temp; }
  if(prot < 0) prot = 0;
  if(TP->query_ac() < 9) TP->add_spell_point(-30);
  write("You power on your metal hide.\n");
  write("Electric sparks fly off your body.\n");
  say("Electric sparks fly off "+TPN+"'s body.\n");
  say(TPN+" powers up "+GEN+" metal hide armor.\n");
  TP->add_ac(prot);
  name = lower_case(TP->query_real_name());
  jumble = name+" "+prot;
  call_out("powerOn", 1, jumble);
  return 1;
}

powerOn(mixed jumble) {
/* waits for player to stop attacking, then restores ac */
  string name;
  int prot;
  object ob;
  sscanf(jumble, "%s %d", name, prot);
  ob = find_player(name);
  if(!ob->query_attack()) {
    TE(ob, "Your armor shuts off.\n");
    ob->add_ac(-prot);
    if(present("armortypeB", ob))
      destruct(present("armortypeB", ob));
    return 1;}
  call_out("powerOn", 1, jumble);
  return 1;
}

emt(string str) {
  /* peace,aggression,nauseating enhancement */
  object ob;
  string name;
    int level, cost, duration;
    object nob;
  if(!str) {
  write("Usage: emt [p/a]\n");
    return 1; }
  if(TP->query_spell_point() < 35) {
    write("Your energy reserves are too low.\n");
    return 1; }
  if(str == "p") {
    TP->add_spell_point(-35);
    ob=first_inventory(ENV(TP));
    while (ob) {
     if (living(ob)) {
      if(ob->query_attack()) {
           (ob->query_attack())->stop_fight();
      (ob->query_attack())->stop_hunter();
     (ob->query_attack())->stop_fight();
      ob->stop_fight();
      ob->stop_hunter();
           ob->stop_fight();
           }
      }
      ob = next_inventory(ob);
     }
    write("A visible wave pattern emanates from you.\n");
    write("A soft blue haze envelopes the room.\n");
    write("You feel at peace.\n");
    say("A visible wave pattern emanates from "+TPN+".\n");
    say("A soft blue haze envelopes the room.\n");
    say("You feel at peace.\n");
    return 1; }
  if(str == "a") {
    if(!ok_in_room(TP)) {
      write("You cannot do that here.\n");
      return 1; }
    ob=first_inventory(ENV(TP));
    while (ob) {
     if (living(ob)) {
        name = ob->query_name();
        name = lower_case(name);
        if(find_player(name)) {
          if(find_player(name)->query_pl_k() &&
             find_player(name)->query_level() < 20)
            find_player(name)->attack_object(TP); }
        if(!find_player(name)) {
          if(ob->query_attack())
             (ob->query_attack())->attack_object(TP);
          ob->attack_object(TP); }
        }
      ob = next_inventory(ob);
     }
    write("A visible wave pattern emanates from you.\n");
    write("A bright red haze envelopes the room.\n");
    write("You have turned everyone against you!\n");
    say("A visible wave pattern emanates from "+TPN+".\n");
    say("A bright red haze envelopes the room.\n");
    say("You become insane!\n");
    return 1; }
/* TAKEN OUT BECUASE OF ILLEGALITIES.. DUNE
  if(str == "n") {
    if(!ok_in_room(TP)) {
      write("You cannot do that here.\n");
      return 1; }
    level = IP(TP)->guild_lev();
    if(level > 12) level = 12;
    cost = 30 - level;
    duration = level * 30;
    if(TP->query_sp() < cost) {
      write("You are low on energy.\n");
      return 1; }
    TP->add_spell_point(-cost);
    nob = clone_object("/players/dune/closed/guild/objects/nausea.c");
    move_object(nob, environment(TP));
    nob->nauseate(TP, duration);
    write("A visible wave pattern emanates from you.\n");
    write("A soft green haze envelopes the room.\n");
    write("You feel nauseous.\n");
    say("A visible wave pattern emanates from "+TPN+".\n");
    say("A soft green haze envelopes the room.\n");
    say("You feel nauseous.\n");
    return 1; }
  if(str == "c") {
    if(!ok_in_room(TP)) {
      write("You cannot do that here.\n");
      return 1; }
    level = IP(TP)->guild_lev();
    if(level > 12) level = 12;
    cost = 30 - level;
    duration = level * 30;
    if(TP->query_sp() < cost) {
      write("You are low on energy.\n");
      return 1; }
    TP->add_spell_point(-cost);
    nob = clone_object("/players/dune/closed/guild/objects/confusion.c");
    move_object(nob, environment(TP));
    nob->confuse(TP, duration);
    write("A visible wave pattern emanates from you.\n");
    write("A soft yellow haze envelopes the room.\n");
    write("You seem confused.\n");
    say("A visible wave pattern emanates from "+TPN+".\n");
    say("A soft yellow haze envelopes the room.\n");
    say("You seem confused.\n");
    return 1; }
*/
  write("Usage: emt [p/a]\n");
  return 1; 
}

int ok_in_room(object ob) {
  object room;
  room = environment(ob);
  if( (room == find_object("/room/church.c")) ||
      (room == find_object("/room/adv_guild.c")) ||
      (room == find_object("/room/shop.c")) ||
      (room == find_object("/room/post.c")) )
    return 0;
  return 1; }
 
bionics() {
  /* added dmg enhancement */
  if(TP->query_spell_point() < 15) {
    write("Use of bionics is too draining for your state.\n");
    return 1; }
  if(IP(TP)->query_bion_on() && !TP->query_attack()) {
    write("You manually de-activate your bionics.\n");
    say(TPN+" manually de-activates "+TP->query_possessive()+
        " bionics.\n");
    IP(TP)->set_bion_on(0);
    return 1; }
  if(IP(TP)->query_bion_on()) {
    write("You already have activated your bionics.\n");
    return 1; }
  IP(TP)->set_bion_on(1);
  IP(TP)->fake_beat(2);
  TP->add_spell_point(-15);
  write("Bionics engaged.\n");
  say(TPN+" engages "+GEN+" bionics.\n");
  return 1;
}

biodam(object ob) {
  object targ;
  int lev;
  if(!ob->query_attack()) {
    TE(ob, "Bionics disengaged.\n");
    IP(TP)->set_bion_on(0);
    return 1;
  }
  lev = present("implants", ob)->guild_lev();
  if(lev >= 12) lev = 12;
  lev = lev / 2;
  targ = ob->query_attack();
  if(targ->query_hp() < 10) {
    TE(ob, "Bionics disengaged.\n");
    IP(TP)->set_bion_on(0);
    return 1;
  }
  if(targ->query_npc() || check_location(ob, targ)) {
    TE(ob,"  +-+crunch+-+\n");
    if(targ->query_hp() >= 3) targ->heal_self(-2);
    /* at least 2 dmg done */
    targ->hit_player(lev);
  }
  return 1; 
}

blades() {
  /* added dmg enhancement */
  if(TP->query_spell_point() < 10) {
    write("You need more power to protract your blades.\n");
    return 1; }
  if(IP(TP)->query_blad_on() && !TP->query_attack()) {
    write("You retract your blades.\n");
    say(TPN+" retracts "+TP->query_possessive()+
        " blades.\n");
    IP(TP)->set_blad_on(0);
    return 1; }
  if(IP(TP)->query_blad_on()) {
    write("You already have protracted your blades.\n");
    return 1; }
  IP(TP)->set_blad_on(1);
  IP(TP)->fake_beat(3);
  TP->add_spell_point(-10);
  write("Sharp blades emerge from your body.\n");
  say("Sharp blades emerge from "+TPN+"'s body.\n");
  return 1;
}

bladedam(object ob) {
  object targ;
  int lev;
  if(!ob->query_attack()) {
    TE(ob, "Your blades retract.\n");
    IP(TP)->set_blad_on(0);
    return 1;
  }
  lev = present("implants", ob)->guild_lev();
  if(lev >= 12) lev = 12;
  lev = lev / 3;
  targ = ob->query_attack();
  if(targ->query_hp() < 10) {
    TE(ob, "Your blades retract.\n");
    IP(TP)->set_blad_on(0);
    return 1;
  }
  if(targ->query_npc() || check_location(ob, targ)) {
    TE(ob,"  <->slice<->\n");
    if(targ->query_hp() >= 2) targ->heal_self(-1);
    /* at least 1 dmg done */
    targ->hit_player(lev);
  }
  return 1; 
}


matter_conversion() {
  object pob, ob;
  pob = present("transferobj",TP);
  if(pob) {
    destruct(pob);
    write("Matter conversion stopped.\n");
    return 1;
  }
  ob = clone_object("/players/snow/closed/transfer.c");
  move_object(ob,TP);
  pob = present("transferobj",TP);
  pob->energy_transfer();
  write("Matter conversion begun.\n");
  return 1;
}

activate_droid() {
  /* droid is not a pet, just a moving 'bag'... enhancement */
  if(present("droid", TP)) {
    write("You already have a droid.\n");
    return 1; }
  if(TP->query_spell_point() < 20) {
    write("You do not have enough energy to supply your droid.\n");
    return 1; }
  TP->add_spell_point(-20);
  move_object(clone_object(
              "/players/dune/closed/guild/enhance/droid.c"),
              this_player());
  write("Your droid's lights turn on.  It is active now.\n");
  say(TPN+" turns on "+GEN+" droid.\n");
  return 1; 
}

net_deaths() {
  write("You tap into the cybernet to check on recent player deaths...\n"+"\n");
  tail("/log/DEATHS");
  write("\n"+"Perhaps you should help some pk'rs make this list...\n");
return 1;
}

combat_retreat() {
  object meat;
  meat = TP->query_attack();
  if(!meat) {
    write("You have nothing to retreat from as you are not in combat!\n");
    return 1; }
  TP->add_spell_point(-10);
  write("You retreat from your attack!\n");
  say(TPN+" retreats from "+GEN+" attack!\n");
  if(meat->query_attack() == TP) {
    meat->stop_fight();
    meat->stop_fight();
    meat->stop_hunter();
  }
  TP->stop_fight();
  TP->stop_fight();
  TP->stop_hunter();
return 1;
}

scan_news() {
  write("You tap into the cybernet news...\n");
  cat("/players/dune/closed/guild/docs/news");
  write("You close the news connection.\n");
return 1;
}

record(string str) {
  if(!str) {
    write("What do you wish to record?\n");
    return; }
  write_file(log+"RECORD", 
    "--------------------------------------------------\n"+
    "->"+capitalize(this_player()->query_real_name())+
    "   ("+ctime()+")\n"+
    str+"\n");
  write("Your message will be added to the guild record.\n");
  return 1;
}

upall()  {
  /* command to update all cyberninja implants */
  int b;
  object ob;
  ob = users();
 write("~~~~~~~~~~~~~~~~~~~~~~~~~\n");
 for(b=0;b<sizeof(ob);b+=1)  {
  if(IP(ob[b]))  {
   IP(ob[b])->save_me();
   destruct(IP(ob[b]));
   move_object(clone_object(
               "/players/dune/closed/guild/implants.c"),
               ob[b]);
   write(pad(ob[b]->query_name(),15));
   write(" updated.\n");
   }
 }
 write("~~~~~~~~~~~~~~~~~~~~~~~~~\n");
return 1;
}

ninja_kill(string str) {
/* This function is activated upon a 'kill' command */
/* This function must not have a return statement */
  int level;
  object meat;
  level = IP(TP)->guild_lev();
  meat = present(str,environment(this_player()));
  if(!meat) { write(capitalize(str)+" is not here to fight...\n"); return 1; }
  if(!living(meat)) { write("You cannot attack that...\n"); return 1; }
  call_out("wait_for_kill",5,TP);
  /* We could put neat ninja output messages specific to */
  /* a discipline here.  Perhaps working on a call_out and */
  /* checking for TP in combat every time. */
}

wait_for_kill(object me) {
  if(!me->query_attack()) return 1;
    if(IP(me)->query_auto() == 1) {
  if(IP(me)->item_bionics()) command("bion",me);
  if(IP(me)->item_blades()) command("blad",me);
  if(IP(me)->guild_lev() >= 2 && IP(me)->query_hpmon() != 1) command("mon",me);
  }
  return 1;
}

death_blow(string str) {
  /* process for finishing off opponents */
  /* attempts to counteract the inability of the attack */
  /* sequences and strikes to kill */
  object ob;
  string name;
  int level, hp;
  if(!str) {
    if(!TP->query_attack()) {
      write("Usage: deathblow or db <monster>\n");
      return 1; }
      ob = TP->query_attack();
    }
  if(str) {
    if(!present(str, environment(TP))) {
      write(capitalize(str)+" is not here.\n");
      return 1; }
    ob = present(str, environment(TP));
    }
  if(!ob->query_npc() && !check_location(TP,ob)) {
    write("You cannot use death blow on that!\n"); return 1; }
  if(ob->query_ghost()) {
    write("Your target is already dead.\n");
    return 1; }
  name = capitalize(ob->query_name());
  hp = ob->query_mhp();
  hp = hp / 20;    /* 5% of max hp */
  level = IP(TP)->query_art_level();
  level = level / 2;
  hp = hp + level; /* up to 8 more */
  if(hp >= ob->query_hp()) {
    TR(ET, TPN+" decapitates "+name+".\n");
    TR(ET, name+"'s head rolls to the ground.\n");
    ob->hit_player(50);
    }
  else write(name+" is too healthy to die.\n");
}

power_scan(str) {
  object meat;
  int mlev, mhp, mmaxhp, msp, mmaxsp, mac, mwc;
  string levmsg, wearmsg, tmsg, spmsg, acmsg, powermsg;
  string wcmsg;
  int mpower, mtough;
  if(!str) {
    write("Powerscan what monster or player?\n");
  return 1;
  }
  meat = present(str,environment(TP));
  if(!meat) {
    write(capitalize(str)+" is not present.\n");
  return 1;
  }
  mlev = meat->query_level();
  mhp = meat->query_hp();
  mmaxhp = meat->query_mhp();
  msp = meat->query_sp();
  mmaxsp = meat->query_msp();
  mac = meat->query_ac();
  mwc = meat->query_wc();
   if(mlev > 50) levmsg = "Oodles and Oodles";
   if(mlev > 25 && mlev < 51) levmsg = "Insane amounts";
   if(mlev > 20 && mlev < 26) levmsg = "Incredible";
   if(mlev > 15 && mlev < 21) levmsg = "Great";
   if(mlev > 10 && mlev < 16) levmsg = "Good";
   if(mlev > 5 && mlev < 11) levmsg = "Poor";
   if(mlev < 6) levmsg = "Very little";
   if(!levmsg) levmsg = "Unknown";
   if(mac > 50) acmsg = "Nearly Untouchable";
   if(mac > 30 && mac < 51) acmsg = "Tremendously tough";
   if(mac > 20 && mac < 31) acmsg = "Extremely hard to hit";
   if(mac > 15 && mac < 21) acmsg = "Very hard to damage";
   if(mac > 10 && mac < 16) acmsg = "Hard to damage";
   if(mac > 5 && mac < 11) acmsg = "Easy to damage";
   if(mac < 6) acmsg = "Very easy to hit and damage";
   if(!mac) acmsg = "Unknown";
   if(mwc > 100) wcmsg = "A godlike force **FEAR THIS**";
   if(mwc > 70 && mwc < 101) wcmsg = "Insane damage. You will be hurt";
   if(mwc > 50 && mwc < 71) wcmsg = "Extreme damage capabilities";
   if(mwc > 30 && mwc < 51) wcmsg = "Huge damage capability";
   if(mwc > 20 && mwc < 31) wcmsg = "Large damage capability";
   if(mwc > 15 && mwc < 21) wcmsg = "Average damage capability";
   if(mwc > 5 && mwc < 16) wcmsg = "Weak damage capability";
   if(mwc < 6) wcmsg = "Extremely weak damage capacity";
   if(!mwc) wcmsg = "Unknown";
   if(mhp > ((mmaxhp * 1) / 10)) wearmsg = "Extreme";
   if(mhp > ((mmaxhp * 3) /10)) wearmsg = "Very heavy";
   if(mhp > ((mmaxhp * 5) / 10)) wearmsg = "Heavy";
   if(mhp > ((mmaxhp * 7) / 10)) wearmsg = "Moderate";
   if(mhp > ((mmaxhp * 9) / 10)) wearmsg = "Slight";
   if(mhp == mmaxhp) wearmsg = "None";
   if(mhp < (mmaxhp / 10)) wearmsg = "Destruction imminent";
   if(!wearmsg) wearmsg = "Unknown";
   mpower = mac + mwc;
   if(mpower > 150) powermsg = "Godlike. Run... NOW";
   if(mpower < 151) powermsg = "Tremendously powerful. To be feared";
   if(mpower < 100) powermsg = "Incredibly powerful";
   if(mpower < 70) powermsg = "Extremely powerful";
   if(mpower < 50) powermsg = "Very powerful";
   if(mpower < 30) powermsg = "Moderate power";
   if(mpower < 20) powermsg = "Weak";
   if(mpower < 10) powermsg = "Very weak";
   if(!powermsg) powermsg = "Unknown";
   mtough = (mmaxhp / 25) + mac;
   if(mtough > 150) tmsg = "Godlike resistance to attacks";
   if(mtough < 151) tmsg = "Insanely tough. Protracted battle";
   if(mtough < 100) tmsg = "Tremendously tough. Protracted battle";
   if(mtough < 70) tmsg = "Incredibly tough. Long battle";
   if(mtough < 50) tmsg = "Very tough. Long battle";
   if(mtough < 30) tmsg = "Tough. Mid-length battle";
   if(mtough < 20) tmsg = "Fairly easy. Mid-length battle";
   if(mtough < 15) tmsg = "Easy. Short battle";
   if(mtough < 10) tmsg = "Very easy. Short battle";
   if(mtough < 5) tmsg = "Extremely easy. Very short battle";
   if(!tmsg) tmsg = "Unknown";
   if(mmaxsp > 0) {
     if(msp == mmaxsp) spmsg = "Full";
     if(msp < ((mmaxsp * 9) / 10)) spmsg = "Nearly full";
     if(msp < ((mmaxsp * 7) / 10)) spmsg = "Somewhat full";
     if(msp < ((mmaxsp * 5) / 10)) spmsg = "Mostly drained";
      if(msp < ((mmaxsp * 3) / 10)) spmsg = "Nearly depleted";
     if(msp < (mmaxsp / 10)) spmsg = "Depleted";
   }
   if(!spmsg) spmsg = "Unknown";
  TE(meat,"A scanning beam passes through your body.\n");
   write("BEGINNING SCANNING PROCESS...\n\n"+
         "--POWER:       "+powermsg+"\n"+
         "--TOUGHNESS:   "+tmsg+"\n"+
         "--ARMOR:       "+acmsg+"\n"+
         "--WEAPON:      "+wcmsg+"\n"+
         "--EXP VALUE:   "+levmsg+"\n\n"+
         "--BODY DAMAGE: "+wearmsg+"\n"+
         "--ENERGY:      "+spmsg+"\n\n"+
         "SCANNING COMPLETE.\n");
  return 1;
}

matter_burn() {
  object meat;
  int mhp, hps;
  int damage, snum;
  hps = TP->query_hp();
  snum = TP->query_attrib("str");
  if(hps < 60) {
    write("The matter converter shuts down before critical damage is done.\n");
    return 1;
  }
  damage = IP(TP)->guild_lev() + random(snum);
  TR(environment(TP),"***>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
  write("You overload your matter converter!\n"+
        "Intense, burning pain rips through your musculature!\n");
  TR(environment(TP),TP->query_name()+" crumples in agony!\n");
  if(!TP->query_attack() ||
    (environment(TP->query_attack()) != environment(TP)) ) {
    TP->add_hit_point(-random(damage));
  TR(environment(TP),"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<***\n");
    return 1;
  }
  meat = TP->query_attack();
  if(!meat->is_player() || check_location(TP,meat)) {
  write("You channel some excess energy into "+meat->query_name()+"!\n");
TR(environment(TP),"Matter energy crashes into "+meat->query_name()+"!\n");
  meat->hit_player(random(damage*2));
  TP->add_hit_point(-damage);
  }
  if(snum > 10) {
    if(random(snum*5) == 1) {
      write("The conversion overload resulted in permanent damage!\n");
      call_other(TP,"add_attrib","str",-1);
    }
  }
  TR(environment(TP),"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<***\n");
  return 1;
}

meta_conversion() {
  if(IP(TP)->query_digest()) {
    write("Metabolic amelioration stopped.\n");
    IP(TP)->set_digest(0);
    return 1;
  }
  write("Metabolic amelioration begun.\n");
  IP(TP)->set_digest(1);
  call_out("digestion",10,TP);
  return 1;
}

digestion(object ob) {
  int INUM, in, st;
  int SNUM;
  st = ob->query_stuffed();
  in = ob->query_intoxination();
  INUM = (in * 10) / (ob->query_level() + 3);
  SNUM = (st * 10)/(ob->query_level() * 8);
  if(!IP(ob)->query_digest()) return 1;
  if(INUM > 7) call_out("digestion",10,ob);
  else call_out("digestion",15,ob);
  if(ob->query_spell_point() < 1) return 1;
  if(in > 1) {
    ob->add_intoxination(-1);
    ob->heal_self(3);
  }
  if(st > 2) {
    ob->add_stuffed(-2);
/*
  NO NO NO -Bp
    ob->add_hit_point(1);
*/
  }
  if(!in && !st) {
    TE(ob,"No matter to metabolize.\n");
    IP(ob)->set_digest(0);
    return 1;
  }
  ob->add_spell_point(-1);
  /*TE(ob,"DIGESTION-> INTOX["+INUM+"/10]  STUFF["+SNUM+"/10]\n");*/
  return 1;
}
