id(str) { return str == "sequence_check"; }

get() { return 1; }
drop() { return 0; }
query_weight() { return 0; }
query_value() { return 0; }

activate(int art_level) {
  int time;
  time = 17 - art_level;
  call_out("destroyme", time);
  }

destroyme() {
  destruct(this_object()); }
