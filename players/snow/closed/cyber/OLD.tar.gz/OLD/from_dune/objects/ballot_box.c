init() {
  add_action("vote","vote");
  add_action("tally","tally"); }
id(str) { return str == "ballot box" || str == "box"; }
get() { return 0; }
drop() { return 1; }
query_weight() { return 0; }
query_value() { return 0; }
reset() { }
short() { return "--@ The Ballot Box @--"; }
long() { write(
"     Drop your vote here if you wish to own a\n"+
"guild office. Or, you may vote for a different\n"+
"person instead. However, you may only vote once\n"+
"for each office.\n"+
"The guild office available is Judge. Judges are\n"+
"a step higher than Senator, and are equals with\n"+
"Shoguns (the highest player position in the guild.\n"+
"****Just type 'vote <person>'\n");
}

vote(string str) {
  string person, office, name;
  if(!str) {
    write("Usage: vote <person>\n");
    return 1; }
  name = capitalize(this_player()->query_real_name());
  write_file("/players/dune/closed/guild/votes/ballots",
    name+
    " voted for "+capitalize(str)+", office: Judge"+
    ".\n     "+ctime()+"\n");
  write("You slip a ballot into the ballot box.\n");
  say(name+" slips a ballot into the ballot box.\n");
  return 1; }


tally() {
  object imp;
  string name, file;
  if(!present("implants", this_player())) {
    write("You dare tally another guild's votes?!\n");
    return 1; }
  imp = present("implants",this_player());
  name = this_player()->query_real_name();
  if(imp->senator() || name == "dune" ||
     name == "snow" || imp->regent()) { }
  else {
    write("You do not have proper authority to tally votes.\n");
    return 1; }
  file = "/players/dune/closed/guild/votes/ballots";
  write("You begin tallying the votes.\n");
  write("Note: Each person gets only one vote for each office.\n");
  call_other("/players/dune/closed/guild/_more.c",
    "more_file", file);
  return 1; }
