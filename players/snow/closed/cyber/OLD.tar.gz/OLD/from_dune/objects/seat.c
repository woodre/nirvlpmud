id(str) { return "_drivers_seat_"; }

init() { 
  add_action("sneak","sneak");
  add_action("sneak","sk");
  add_action("out","out");
  add_action("say","say");
  add_action("loook","look");
  add_action("loook","l");
  add_action("go_north","north");         add_action("go_north","n");
  add_action("go_northeast","northeast"); add_action("go_northeast","ne");
  add_action("go_northwest","northwest"); add_action("go_northwest","nw");
  add_action("go_south","south");         add_action("go_south","s");
  add_action("go_southeast","southeast"); add_action("go_southeast","se");
  add_action("go_southwest","southwest"); add_action("go_southwest","sw");
  add_action("go_east","east");           add_action("go_east","e");
  add_action("go_west","west");           add_action("go_west","w");
  add_action("go_up","up");               add_action("go_up","u");
  add_action("go_down","down");           add_action("go_down","d");
}

get() { return 0; }
drop() { return 1; }
reset() {}
short() { return "shadows"; }
long() { write("The shadows are dark.\n"); }

sneak(string str) {
  object ob;
  ob = environment(this_object());
  switch(str) {
    case "n":   str = "north"; break;
    case "s":   str = "south"; break;
    case "e":   str = "east"; break;
    case "w":   str = "west"; break;
    case "ne":  str = "northeast"; break;
    case "nw":  str = "northwest"; break;
    case "se":  str = "southeast"; break;
    case "sw":  str = "southwest"; break;
    case "u":   str = "up"; break;
    case "d":   str = "down"; break;
    }
  command(str, ob);
  command("look", this_player());
  if(1 == random(13)) {
    tell_room(environment(ob), "You feel a slight breeze as a shadow passes by you.\n");
    write("You ruffle about a bit excessively. You may have been spotted.\n");
  }
  return 1; }

out() {
  move_object(this_player(),
    environment(environment(this_player())));
  write("You leave the shadows.\n");
  if(!this_player()->query_invis()) {
    say(this_player()->query_name()+" emerges from the shadows.\n");
  }
  destruct(this_object());
  return 1; }

say(string str) {
  if(!str) {
    write("Say what?\n");
    return 1; }
  tell_room(environment(environment(this_player())),
    "A voice from the shadows says: "+str+"\n");
  write("You say: "+str+".\n");
  return 1; }

loook(string str) {
  object ob, eob;
  ob = environment(this_player());
  eob = environment(ob);
  move_object(this_player(), eob);
  if(!str) {
    command("look", this_player());
    move_object(this_player(), ob);
    return 1; }
  if(str == "at shadows") {
    move_object(this_player(), ob);
    write(
"     You are hiding in the shadows.\n"+
"To return from the shadows, type 'out'.\n"+
"You may look and say as normal.\n"+
"To walk among the shadows, use 'sneak or sk <direction>'.\n"+
"Normal n,e,s,w,u,d,etc. commands don't need the sneak or sk prefix.\n"+
"Your current location is: "+environment(environment(
 this_player()))->short()+"\n");
    return 1; }
  command("look "+str, this_player());
  move_object(this_player(), ob);
  return 1;
}

go_north() { command("sneak north", this_player()); return 1; }
go_northeast() { command("sneak northeast", this_player()); return 1; }
go_northwest() { command("sneak northwest", this_player()); return 1; }
go_south() { command("sneak south", this_player()); return 1; }
go_southeast() { command("sneak southeast", this_player()); return 1; }
go_southwest() { command("sneak southwest", this_player()); return 1; }
go_up() { command("sneak up", this_player()); return 1; }
go_down() { command("sneak down", this_player()); return 1; }
