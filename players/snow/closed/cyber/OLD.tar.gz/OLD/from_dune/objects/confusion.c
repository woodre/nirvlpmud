/* object to prevent casting of missile, shock, sonic */
/* and fireball within a whole room */
/* ninja is affected as well */
id(str) { return str == "__confusion__"; }
init() {
  tell_object(this_player(), "You seem confused.\n");
  add_action("missile","missile");
  add_action("missile","mi");
  add_action("shock","shock");
  add_action("shock","sh");
  add_action("fireball","fireball");
  add_action("fireball","fi");
  add_action("sonic","sonic");
  add_action("sonic","so");
  }
long() {
  write("This object stays in a room for a temporary\n"+
        "amount of time.  During its stay, it prevents\n"+
        "all casting of mi, fi, sh, and so.\n"); }
get() { return 0; }
drop() { return 1; }
query_value() { return 0; }
query_weight() { return 0; }

object obj;

missile(string str) {
  write("You get confused and fumble the spell.\n"); return 1; }
fireball(string str) {
  write("You get confused and fumble the spell.\n"); return 1; }
shock(string str) {
  write("You get confused and fumble the spell.\n"); return 1; }
sonic(string str) {
  write("You get confused and fumble the spell.\n"); return 1; }

set_ob(object ob) { obj = ob; }
object query_ob() { return obj; }

confuse(object ob, int duration) {
  set_ob(ob);
  wait(duration);
  return 1; }

wait(int duration) {
  object ob, room_occ;
  ob = query_ob();
  if(duration <= 0) {
    tell_room(environment(this_object()),
      "Suddenly your confusion clears away.\n");
    destruct(this_object());
    return 1; }
  duration -= 1;
  room_occ = first_inventory(environment(ob));
  while(room_occ) {
     if(room_occ != ob) {
       if(present(room_occ, environment(this_object())))
         tell_object(room_occ, "You are in a daze.\n"); }
     room_occ = next_inventory(room_occ);
     }
  call_out("wait", 100, duration);
}
