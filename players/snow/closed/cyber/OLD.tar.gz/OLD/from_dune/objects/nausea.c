/* object to prevent eating and drinking within a whole room */
/* ninja is affected as well */
id(str) { return str == "__nausea__"; }
init() {
  tell_object(this_player(), "You feel nauseous.\n");
  add_action("eat","eat");
  add_action("drink","drink");
  add_action("swallow","swallow");
  add_action("quaff","quaff");
  add_action("sip","sip");
  add_action("devour","devour");
  add_action("chew","chew");
  add_action("consume","consume");
  }
long() {
  write("This object stays in a room for a temporary\n"+
        "amount of time.  During its stay, it prevents\n"+
        "all digestion of food and drink.\n");}
get() { return 0; }
drop() { return 1; }
query_value() { return 0; }
query_weight() { return 0; }

eat(string str) { write("You throw it all up.\n"); return 1; }
drink(string str) { write("You throw it all up.\n"); return 1; }
swallow(string str) { write("You throw it all up.\n"); return 1; }
quaff(string str) { write("You throw it all up.\n"); return 1; }
sip(string str) { write("You throw it all up.\n"); return 1; }
devour(string str) { write("You throw it all up.\n"); return 1; }
chew(string str) { write("You throw it all up.\n"); return 1; }
consume(string str) { write("You throw it all up.\n"); return 1; }

object obj;

set_ob(object ob) { obj = ob; }
object query_ob() { return obj; }

nauseate(object ob, int duration) {
  set_ob(ob);
  wait(duration);
  return 1; }

wait(int duration) {
  object room_occ, ob;
  ob = query_ob();
  if(duration <= 0) {
    tell_room(environment(this_object()),
      "The feeling of nausea weakens and is gone.\n");
    destruct(this_object());
    return 1; }
  duration -= 1;
  room_occ = first_inventory(environment(ob));
  while(room_occ) {
     if(room_occ != ob) {
       if(present(room_occ, environment(this_object())))
         tell_object(room_occ, "You puke!\n"); }
     room_occ = next_inventory(room_occ);
     }
  call_out("wait", 100, duration);
}
