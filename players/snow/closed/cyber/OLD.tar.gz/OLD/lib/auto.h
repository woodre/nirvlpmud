auto(string str) {
  /* sets automatics */
  if(!str) {
    write("Usage: auto [ on/off");
      if(IP(TP)->item_corpse()) write("/reg/rej");
      if(IP(TP)->item_blades()) write("/blad");
      if(IP(TP)->item_bionics()) write("/bion");
    write(" ]\n"); RE; }
  if(str == "on") {
    IP(TP)->set_auto(1);
    write("Your automatics are now on.\n"); RE; }
  if(str == "off") {
    IP(TP)->set_auto(0);
    write("Your automatics are now off.\n"); RE; }
  if(str == "reg" && IP(TP)->item_corpse()) {
    if(IP(TP)->query_auto_reg()) {
      IP(TP)->set_auto_reg(0);
      write("You turn off your auto regeneration.\n"); RE; }
    IP(TP)->set_auto_reg(1);
    write("You activate your auto regeneration.\n"); RE; }
  if(str == "rej" && IP(TP)->item_corpse()) {
    if(IP(TP)->query_auto_rej()) {
      IP(TP)->set_auto_rej(0);
      write("You turn off your auto rejuvenation.\n"); RE; }
    IP(TP)->set_auto_rej(1);
    write("You activate your auto rejuvenation.\n"); RE; }
  if(str == "blad" && IP(TP)->item_blades()) {
    if(IP(TP)->query_auto_blad()) {
      IP(TP)->set_auto_blad(0);
      write("You turn off your auto blades.\n"); RE; }
    IP(TP)->set_auto_blad(1);
    write("You activate your auto blades.\n"); RE; }
  if(str == "bion" && IP(TP)->item_bionics()) {
    if(IP(TP)->query_auto_bion()) {
      IP(TP)->set_auto_bion(0);
      write("You turn off your auto bionics.\n"); RE; }
    IP(TP)->set_auto_bion(1);
    write("You activate your auto bionics.\n"); RE; }
  else
  write("You have chosen an invalid auto.\n");
  RE;
}
 
