fake_beat(ob) {
  int att, atthp, mymaxhp, mymaxsp, myhp, mysp;
  if(ob) {
    if(IP(ob)) IP(ob)->add_beats();
    mymaxhp = ob->query_mhp();
    mymaxsp = ob->query_msp();
    myhp = ob->query_hp();
    mysp = ob->query_sp();
    if(IP(ob)->query_equil_on()) equilibrate(ob);
    if(IP(ob)->query_regen_on()) regenerate(ob);
    if(IP(ob)->query_rejuv_on()) rejuvenate(ob);
    if(IP(ob)->query_charge_on()) flux_charge(ob);
    if(IP(ob)->query_bion_on() ||
       IP(ob)->query_blad_on() &&
      !ob->query_attack()) {
      if(IP(ob)->query_blad_on()) {
        TE(ob,"Your blades retract.\n"); blad_on = 0; }
      if(IP(ob)->query_bion_on()) {
        TE(ob,"Your bionics de-activate.\n"); bion_on = 0; }
    }
    if(IP(ob)->query_auto_on() && ob->query_attack()) {
      att = ob->query_attack();
      atthp = att->query_hp();
      if(atthp > 50) {
        if(IP(ob)->query_auto_bion() &&
          !IP(ob)->query_bion_on()) {
          write(BOLD+"AUTO BIONICS"+OFF+"\n");
          command("bion",ob); }
        if(IP(ob)->query_auto_blad() &&
          !IP(ob)->query_blad_on()) {
          write(BOLD+"AUTO BLADES"+OFF+"\n");
          command("blad",ob); }
      }
      if(IP(ob)->query_auto_reg()) {
        if(myhp < mymaxhp/2 &&
          !IP(ob)->query_regen_on() &&
          !IP(ob)->query_rejuv_on()) {
          TE(ob,BOLD+"[*] AUTO REGENERATION [*]"+OFF+"\n");
          command("reg",ob); }
      }
      if(IP(ob)->query_auto_rej()) {
        if(myhp > mymaxhp*2/3 && 
           mysp < mymaxsp/2 &&
           !IP(ob)->query_regen_on() && 
           !IP(ob)->query_rejuv_on()) {
          TE(ob,BOLD+"[*] AUTO REJUVENATION [*]"+OFF+"\n");
          command("rej",ob); }
      }
    }
  }
  RE;
}
