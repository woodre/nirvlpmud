#include "DEFS.h"
#define snow ob->query_real_name() == "snow"

fake_beat(object ob) {
  int att, atthp, mymaxhp, mymaxsp, myhp, mysp;
  int newac, bdam;
  object wep, awep;
  if(ob) {
    if(IP(ob)) IP(ob)->add_beats();

/* CLONING UNARMED COMBAT WEAPON */
    if(!ob->query_weapon()) {
      if(ob->query_level() < 20 || snow)
      TE(ob, BOLD+"NO WEAPON WIELDED\n"+OFF);
     if(!present("nwep", ob)) {
      if(ob->query_level() < 20 || snow)
      TE(ob, BOLD+"NO CYBERWEAPON PRESENT\n"+OFF);
      command("wep", ob); }
      awep = present("nwep", ob);
      if(awep) {
        if(ob->query_level() < 20 || snow)
        TE(ob, BOLD+"CYBERWEAPON PRESENT\n"+OFF);        
        call_other(ob, "wield", awep, 1);
        awep->set_wielded(1);
        awep->set_wielded_by(ob); 
        if(ob->query_level() < 20 || snow)
        TE(ob, BOLD+"CYBERWEAPON READIED\n"+OFF); }
     }
/* ------------- */

    mymaxhp = ob->query_mhp();
    mymaxsp = ob->query_msp();
    myhp = ob->query_hp();
    mysp = ob->query_sp();
    if(ob->query_attack()) att = ob->query_attack();
    if(att) atthp = att->query_hp();
    if(IP(ob)->query_equil()) equilibrate(ob);
    if(IP(ob)->query_regen()) regenerate(ob);
    if(IP(ob)->query_rejuv()) rejuvenate(ob);
    if(IP(ob)->query_charge_on()) flux_charge(ob);
    if( (IP(ob)->query_bion_on() ||
         IP(ob)->query_blad_on() ) && !att) {
      if(IP(ob)->query_blad_on()) {
        TE(ob,"Your blades retract.\n");
        IP(ob)->set_blad_on(0); }
      if(IP(ob)->query_bion_on()) {
        TE(ob,"Your bionics de-activate.\n");
        IP(ob)->set_bion_on(0); }
    }
    if(!att && random(15) == 1) honor_checkup(ob);
    if(att) {
      if(IP(ob)->query_blad_on()) { 
        if(random(100) < IP(ob)->guild_lev() + 5) { 
          TE(ob, BOLD+" ^^ Your blades cut into "+att->query_name()+
                "! ^^"+OFF+"\n");
          TE(att, "You are cut by "+ob->query_name()+"'s blades!\n");
           bdam = random(IP(ob)->guild_lev())+1;
          if(bdam > atthp) bdam = atthp - 1;
          att->hit_player(bdam);
          if(random(1000) < 20 - IP(ob)->guild_lev()) {
            TE(ob, BOLD+" YOUR BLADES BREAK!"+OFF+"\n");
            IP(ob)->item_blades(0); IP(ob)->save_me(); IP(ob)->reset(); }
        }
        if(random(100) < IP(ob)->guild_lev() -2) {
          if(att->query_attack() == ob) {
            TE(ob, REV_RED+"\t"+att->query_name()+                            
              " is impaled on your blades!"+OFF+"\n");
            TE(att, " You impale yourself on "+ob->query_name()+"'s blades!\n");
          bdam = IP(ob)->guild_lev();
          if(bdam > atthp) bdam = atthp - 1;
          att->heal_self(-bdam); }}
       } 
    honor_checkup(ob);
      newac = random(ARTR/2)+1;
      if(IP(ob)->query_armor()) newac ++;
      if(call_other(ob, "query_attrib", "pie") >= random(400))
          newac += random(4);
      if(IP(ob)->query_attack_mode() == 2) newac = newac + 4;
      if(IP(ob)->query_attack_mode() == 1) newac = 0;
      if(newac > 9) newac = 9;
      if(ob->query_level() > 60) TE(ob, "NEWAC = "+newac+"\n");
      ob->set_ac(newac);
      if(att->query_attack() == ob) {
      if(newac > 3 && newac <= 6)
        TE(ob, "You partially block "+att->query_name()+"'s attack!\n");
      if(newac >= 7)
        TE(ob, "You block most of "+att->query_name()+"'s attack!\n");
      }
      }
    if(IP(ob)->query_auto_on() && att) {
      if(atthp > 50) {
        if(IP(ob)->query_auto_bion() &&
          !IP(ob)->query_bion_on()) {
          write(BOLD+"AUTO BIONICS"+OFF+"\n");
          command("bion",ob); }
        if(IP(ob)->query_auto_blad() &&
          !IP(ob)->query_blad_on()) {
          write(BOLD+"AUTO BLADES"+OFF+"\n");
          command("blad",ob); }
      }
      if(IP(ob)->query_auto_reg()) {
        if(myhp < mymaxhp/2 &&
          !IP(ob)->query_regen() &&
          !IP(ob)->query_rejuv()) {
          TE(ob,BOLD+"[*] AUTO REGENERATION [*]"+OFF+"\n");
          command("reg",ob); }
      }
      if(IP(ob)->query_auto_rej()) {
        if(myhp > mymaxhp*2/3 && 
           mysp < mymaxsp/2 &&
           !IP(ob)->query_regen() && 
           !IP(ob)->query_rejuv()) {
          TE(ob,BOLD+"[*] AUTO REJUVENATION [*]"+OFF+"\n");
          command("rej",ob); }
      }
    }
  }
  RE;
}

