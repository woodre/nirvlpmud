/*CyberNinja Guild weapon*/
 
#include "color.h"
#include "wepdefs.h"
#define NAGIN "/players/snow/closed/cyber/nagidaem.c"

inherit "/players/snow/closed/cyber/weapon.c";
inherit "/obj/armor.c";

int totaldam;
query_totaldam() { return totaldam; }
set_totaldam(num) { totaldam = num; }
mod_totaldam(num) { totaldam += num; }
 
query_pro_weapon() { return 1; }
proficiency_hit(ob) {
  if(ob->query_attack_mode() == 1) return ARTR/2;
  return 0; }

query_paladin_shield() {
  if(GOB && GOB->query_attack_mode() == 2) return 1;
  return 0; }
shield_bonus(ob) {
  if(ob->query_attack_mode() == 2) return ARTR/2;
  return 0; }
wear() { if(GOB->query_attack_mode() != 2) return 1; ::wear(); }

 reset(arg) {
  int artwc;
  string ninshort;
    ::reset(arg);
ninshort = "A Naginata <steel>";
artwc = (ARTR/3)+1;
if(TP->query_level() < 20) {if(artwc > 5) artwc = 5;}
if(artwc == 3) ninshort = "A Naginata <titanium>";
if(artwc == 4) ninshort = "A Naginata <adamantium>";
if(artwc == 5) ninshort = "A Naginata <ether-alloy>";
if(artwc > 5) ninshort = "A Naginata<vortex-forged>";
 
 
    if (arg) return;
    set_name("naginata");
    set_alias("nagi");
    set_short(ninshort);
    set_long(
"A deadly CyberNinja Guild weapon, the Naginata is a polearm about\n"+
"5 1/2 feet long with a razor-edged blade and a stout black staff. When\n"+
"wielded by an expert of the art of Ninjitsu, the Naginata becomes a\n"+
"whirling instrument of destruction.\n");
    set_class(artwc + 12);
    set_type("shield");
    set_ac(ARTR/5);
    set_weight(2);
    set_hit_func(this_object());
}
 
init() {
  ::init();
  if(GOB) add_action("offer_naginata","offer");
}
 
offer_naginata(arg) {NAGIN->offer_naginata(arg); return 1;}
weapon_hit() {NAGIN->weapon_hit(); return 1;}
nag_slice() {NAGIN->nag_slice(); return 1;}
nag_leg_sweep() {NAGIN->nag_leg_sweep(); return 1;}
nag_bar_bash() {NAGIN->nag_bar_bash(); return 1;}
nag_multi_hit() {NAGIN->nag_multi_hit(); return 1;}
r_attack() {NAGIN->r_attack(); return 1;}
nag_bar_smash() {NAGIN->nag_bar_smash(); return 1;}
nag_strike() {NAGIN->nag_strike(); return 1;}
nag_throat_blow() {NAGIN->nag_throat_blow(); return 1;}
nag_aura() {NAGIN->nag_aura(); return 1;}
nag_finish() {NAGIN->nag_finish(); return 1;}
 
