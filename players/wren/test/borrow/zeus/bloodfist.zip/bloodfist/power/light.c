#include "/players/zeus/closed/bloodfist/defs.h"

status main(string str, object PO, object User)
{
  if(str != "torch") return 0;
  if(User->query_ghost()) return 0;
  if(!PO->level_check(1)) return 0;
  if(PO->query_torch())
  {
    TOU"You already have a torch lit.\n");
    return 1;
  }
  
  TOU"You light your torch.\n");
  TRU Name+" lights "+User->POS+" torch.\n", ({ User }));
  PO->toggle_torch();
  return 1;
}
