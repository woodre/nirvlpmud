#include "/players/zeus/closed/bloodfist/defs.h"

status main(string str, object PO, object User)
{
  cat(DIR+"doc/login_news");
  return 1;
}
