#include "path.h"
inherit SQUARE;

reset() {
  name="Ventnor Avenue";
  price=260;
  rent=({22,110,330,800,975,1150});
}

