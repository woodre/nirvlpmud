#include "path.h"
inherit SQUARE;

reset() {
  name="Indiana Avenue";
  price=220;
  rent=({18,90,250,700,875,1050});
}

