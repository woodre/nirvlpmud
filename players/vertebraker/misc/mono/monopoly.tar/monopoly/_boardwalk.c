#include "path.h"
inherit SQUARE;

reset() {
  name="Boardwalk";
  price=400;
  rent=({50,200,600,1400,1700,2000});
}

