#include "path.h"
inherit SQUARE;

reset() {
  name="States Avenue";
  price=140;
  rent=({10,50,150,450,625,750});
}

