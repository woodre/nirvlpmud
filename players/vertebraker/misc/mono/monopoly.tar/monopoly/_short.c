#include "path.h"
inherit SQUARE;

reset() {
  name="Short Line RailRoad";
  price=200;
}
