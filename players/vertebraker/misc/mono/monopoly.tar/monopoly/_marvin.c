#include "path.h"
inherit SQUARE;

reset() {
  name="Marvin Gardens";
  price=280;
  rent=({24,120,360,850,1025,1200});
}

