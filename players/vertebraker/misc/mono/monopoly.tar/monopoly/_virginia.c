#include "path.h"
inherit SQUARE;

reset() {
  name="Virginia Avenue";
  price=160;
  rent=({12,60,180,500,700,900});
}

