#include "path.h"
inherit SQUARE;

reset() {
  name="Pennsylvania RailRoad";
  price=200;
}
