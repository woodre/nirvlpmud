#include "path.h"
inherit SQUARE;

reset() {
  name="Mediterranean Avenue";
  price=60;
  rent=({2,10,30,90,160,250});
}
