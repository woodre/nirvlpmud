
#include "path.h"
inherit SQUARE;

reset() {
  name="Water Works";
  price=200;
}
