#include "path.h"
inherit SQUARE;

reset() {
  name="Tennessee Avenue";
  price=180;
  rent=({14,70,200,550,750,950});
}

