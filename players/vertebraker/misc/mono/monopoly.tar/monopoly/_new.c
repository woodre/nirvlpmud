#include "path.h"
inherit SQUARE;

reset() {
  name="New York Avenue";
  price=200;
  rent=({16,80,220,600,800,1000});
}

