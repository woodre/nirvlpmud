#include "path.h"
inherit SQUARE;

reset() {
  name="B. & O. RailRoad";
  price=200;
}
