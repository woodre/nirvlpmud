#include "path.h"
inherit SQUARE;

reset() {
  name="Park Place";
  price=350;
  rent=({35,175,500,1100,1300,1500});
}

