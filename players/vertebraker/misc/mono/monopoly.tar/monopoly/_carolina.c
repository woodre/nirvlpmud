#include "path.h"
inherit SQUARE;

reset() {
  name="No. Carolina Avenue";
  price=300;
  rent=({26,130,390,900,1100,1275});
}

