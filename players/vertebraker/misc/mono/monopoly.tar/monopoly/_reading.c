#include "path.h"
inherit SQUARE;

reset() {
  name="Reading RailRoad";
  price=200;
}
