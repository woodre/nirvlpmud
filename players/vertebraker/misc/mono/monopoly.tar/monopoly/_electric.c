
#include "path.h"
inherit SQUARE;

reset() {
  name="Electric Company";
  price=200;
}
