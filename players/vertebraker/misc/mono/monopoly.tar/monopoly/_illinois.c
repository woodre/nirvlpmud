#include "path.h"
inherit SQUARE;

reset() {
  name="Illinois Avenue";
  price=240;
  rent=({20,100,300,750,925,1100});
}

