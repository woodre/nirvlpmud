#include "path.h"
inherit SQUARE;

reset() {
  name="Pacific Avenue";
  price=300;
  rent=({26,130,390,900,1100,1275});
}

