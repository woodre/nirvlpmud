#include "path.h"
inherit SQUARE;

reset() {
  name="Pennsylvania Avenue";
  price=320;
  rent=({28,150,450,1000,1200,1400});
}

