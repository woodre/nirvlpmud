#include "path.h"
inherit SQUARE;

reset() {
  name="Vermont Avenue";
  price=100;
  rent=({6,30,90,270,400,550});
}

