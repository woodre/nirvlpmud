#include "path.h"
inherit SQUARE;

reset() {
  name="Baltic Avenue";
  price=60;
  rent=({4,20,60,180,320,450});
}

