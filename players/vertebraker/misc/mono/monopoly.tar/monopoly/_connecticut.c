#include "path.h"
inherit SQUARE;

reset() {
  name="Connecticut Avenue";
  price=120;
  rent=({8,40,100,300,450,600});
}

