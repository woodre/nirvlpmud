#include "/players/reflex/lib/lib.h"
#include "/players/reflex/lib/include/ansi.h"
#define tp this_player()->query_name()
inherit "room/room";
int t;
reset(int arg){
 if(!arg){
  set_light(1);
 short_desc="Cloak Room";
long_desc=
 "You have entered the anteroom of Orin's Inn.  There are various pegs on\n"+
 "the wall where customers may hang their cloaks.  You may wish to hang\n"+
 "your cloak as well, for while the wind outside might have chilled your\n"+
 "bones, the interior of Orin's Inn is always comfortably warm.  Through\n"+
 "the door to the east you see the common room of the inn.\n\n"+
 "Unfortunatly there is a sign up that says 'Out of business, thank you\n"+
 "for your patronage' and a board nailed across the door.\n\n";

items=({
 "door","A mahogany door leading to the inn's common room",
 "floor","The floor is made from a beautiful mahogany wood",
 });

  dest_dir=({
 "/players/saber/ryllian/ryllian2.c","west",
           });
  }   }
