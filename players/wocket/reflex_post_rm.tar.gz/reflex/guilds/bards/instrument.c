#include "/players/reflex/lib/include/ansi.h"

init(){
   if(!environment()) return;
        this_player()->set_home(0);
        this_player()->set_guild_file(0);
        this_player()->set_guild_rank(0);
        this_player()->set_guild_name(0);
        this_player()->add_guild_exp(-this_player()->query_guild_exp());
        this_player()->add_guild_rank(-this_player()->query_guild_rank());
        tell_object(this_player(), HIM+
            "The Bardic Guild of Ryllian is now closed.  Thank you for\n"+
            "being a part of the fun.  If you have any questions about\n"+
            "this, or wish to stay in touch, email me at:\n"+
            "reflex_croft@yahoo.com\n\n"+NORM);
        destruct(this_object());
        return 1;
}
