#include "/players/reflex/lib/include/ansi.h"

init(){
   if(!environment()) return;
        tell_object(this_player(), HIB+
            "The harem is now closed.  Thank you for all the fun times\n"+
            "and I hope you all do well.  The reasons for this closure\n"+
            "will be in your mailboxes ASAP, and hopefully it will make\n"+
            "everything clear.  If you wish to stay in touch, please do\n"+
            "so through email, my address is: reflex_croft@yahoo.com\n"+
            NORM);
        destruct(this_object());
        return 1;
}
