#include "security.h" 
inherit "/players/vertebraker/closed/std/room";

reset(arg){
if(!present("city_object")){
move_object(clone_object("/players/maledicta/cont/castles/dock"), this_object())
;
}
  if(arg) return;
    set_short("A large tower");
    set_long(
        "Before you stands the imposing Tower of Hope.\n");
   add_exit("/room/orc_dump","east");
   set_light(1);
   }
